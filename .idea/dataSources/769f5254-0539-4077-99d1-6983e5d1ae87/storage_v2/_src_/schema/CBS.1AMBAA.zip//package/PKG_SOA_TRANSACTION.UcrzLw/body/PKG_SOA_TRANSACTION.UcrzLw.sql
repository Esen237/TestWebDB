create PACKAGE BODY     pkg_soa_transaction is

/******************************************************************************
   NAME        : FUNCTION booktobooktransfer
   Prepared By : Almas Nurhozhaev
   Date        : 03.07.08
   Purpose     : book to book transfer transaction
******************************************************************************/
function booktobooktransfer(pn_fromaccountno in varchar2,
                            pn_toaccountno   in varchar2,
                            ps_amount        in varchar2,
                            ps_description   in varchar2,
                            ps_currencycode  in varchar2,
                            ps_isdekont      in varchar2,
                            ps_paymentcode   in varchar2,
                            pc_ref           out cursorreferencetype) return varchar2 is
      ls_returncode        varchar2 (3)  := '000';
      pn_islem_no          number;
      pn_islem_kod         number;
      pc_modul_tur_kod     varchar2 (20);
      pc_urun_tur_kod      varchar2 (20);
      pc_urun_sinif_kod    varchar2 (20);
      ps_fromaccountno     number        := to_number (pn_fromaccountno);
      ps_toaccountno       number        := to_number (pn_toaccountno);
      ln_tutar             number :=to_number(ps_amount,'99999999999.99');
      ps_bolum_kodu        varchar2 (3):= pkg_hesap.hesapsubeal (pn_fromaccountno);
      pc_bolum_kodu        varchar (10)  := ps_bolum_kodu;
      pc_amir_bolum_kodu   varchar (10)  := ps_bolum_kodu;
      pc_rol               number        := 7777;
      pc_doviz_kod         varchar (10)  := ps_currencycode;
      pn_musteri_numara    number:= pkg_hesap.hesaptanmusterinoal (to_number (pn_fromaccountno));
      pc_hesap_numara      number        := to_number (pn_fromaccountno);
      pc_kasa_kod          number;
      pn_kanal_numara      number        := 1;
      exacc_b               varchar2(16);
      exacc_a               varchar2(16);
      ls_istatistik_kodu    varchar2(10);
      ls_prefix_stat        varchar2(4);
      ln_toaccno            number;
      ln_charge_amount        number;

      notenoughbalance      exception;--ernestk 29042014 cqdb00001011 if balance is not enough

begin

      pn_islem_no := pkg_tx.islem_no_al;
      pn_islem_kod := 1203;
      exacc_b := to_char(pkg_soa_inquiry.Active_external_hesapno_al(ps_fromaccountno));--,'FM000000000');
      exacc_a := lpad(ps_toaccountno,16,'0');--TO_CHAR(pkg_soa_inquiry.Active_external_hesapno_al(ps_toaccountno),'FM000000000');
      ln_toaccno:=pkg_soa_inquiry.Active_gethesapnofromexternal(exacc_a,ps_currencycode);

      ls_prefix_stat := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ps_fromaccountno))) ||
                        pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ps_fromaccountno))) ||
                        pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_toaccno))) ||
                        pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_toaccno))) ;

      ls_istatistik_kodu:=pkg_message.split(ps_paymentcode,';',0);

        pkg_tx1203.sp_urun_tur_sinif_al(  pn_fromaccountno,
                                            ln_toaccno  ,
                                           ps_currencycode ,
                                           'E',
                                           pc_modul_tur_kod,
                                            pc_urun_tur_kod,
                                            pc_urun_sinif_kod);

      if pc_doviz_kod=pkg_genel.lc_al then
          if pkg_musteri.sf_musteri_tipi_al(pn_musteri_numara)=3 then
              ln_charge_amount:=pkg_aps.chargeautocalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
          else
                ln_charge_amount:=pkg_aps.chargeautocalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
          end if;
      else
            ln_charge_amount:=pkg_aps.chargeautocalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
      end if;

      --B-O-M ernestk 29042014 cqdb00001011 check balance with ccommission
      if pkg_hesap.kullanilabilir_bakiye_al(pc_hesap_numara) < (ln_tutar + ln_charge_amount) then
        raise notenoughbalance;
      end if;
      --E-O-M ernestk 29042014 cqdb00001011 check balance with ccommission

      open pc_ref for select pn_islem_no from dual;

      insert into cbs_virman_islem
                  (tx_no, borc_hesap_no, doviz_kodu, tutar,alacak_hesap_no, aciklama, dekont_basim_f,
                  borc_external_hesap,alacak_external_hesap, borc_vergi_no,alacak_vergi_no,prefix_istatistik_kodu, istatistik_kodu,charge_amount)
           values (pn_islem_no, ps_fromaccountno, ps_currencycode, ln_tutar,
                   ln_toaccno, ps_description, ps_isdekont,exacc_b,exacc_a,pkg_musteri.sf_vergino_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno)),
                   pkg_musteri.sf_vergino_al(pkg_hesap.hesaptanmusterinoal(ln_toaccno)),  ls_prefix_stat ,ls_istatistik_kodu,ln_charge_amount);

      pkg_int_api.create_transaction (pn_islem_no,
                                      pn_islem_kod,
                                      pc_modul_tur_kod,
                                      pc_urun_tur_kod,
                                      pc_urun_sinif_kod,
                                      ln_tutar,
                                      pc_amir_bolum_kodu,
                                      pc_bolum_kodu,
                                      pc_rol,
                                      pc_doviz_kod,
                                      pn_musteri_numara,
                                      pc_hesap_numara,
                                      pc_kasa_kod,
                                      pn_kanal_numara);

      pkg_int_api.process_transaction (pn_islem_no);

   return ls_returncode;

exception
    --B-O-M ernestk 29042014 cqdb00001011 if balance is not engough
    when notenoughbalance then
        rollback;
        ls_returncode := '502';
        log_at('Bakiye yeterli degil',pc_hesap_numara,pkg_hesap.kullanilabilir_bakiye_al(pc_hesap_numara), ln_tutar + ln_charge_amount);
        open pc_ref for select pn_islem_no from dual;
        return ls_returncode;
    --E-O-M ernestk 29042014 cqdb00001011 if balance is not engough
    when others   then
        ls_returncode := pkg_int_api.geterrorcode (sqlerrm);
        log_at ('B2OBHVL',sqlerrm, ls_returncode);
        rollback;
        open pc_ref for select sysdate from dual;
    return ls_returncode;
end;
--------------------------------------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION MakeEFT
   Prepared By : Almas Nurhozhaev
   Date        : 04.07.08
   Purpose     : Make clearing transaction
******************************************************************************/
function makeeft(ps_from_acc          varchar2,
                 ps_payee_info        varchar2,
                 pd_trandate          varchar2,
                 ps_sender_name       varchar2,
                 ps_sender_phone      varchar2,
                 ps_bank_code         varchar2,
                 ps_payee_name        varchar2,
                 ps_to_account        varchar2,
                 pn_amount            varchar2,
                 ps_description       varchar2,
                 ps_save_payee_flag   varchar2,
                 ps_payee_nick        varchar2,
                 ps_payee_phone       varchar2,
                 pn_rnn               varchar2,
                 pn_doc_no            varchar2,
                 pn_stat              varchar2,
                 pn_paycode           varchar2,
                 pn_income            varchar2,
                 ps_payment_type      varchar2,
                 pc_ref               out   cursorreferencetype) return varchar2 is

      lc_refno            varchar2(16) ;
      ld_date             date;
      ls_returncode       varchar2(3):= '000';
      ls_stat             varchar2(4);
      ln_charge_amount    number;
      ln_islem_no         number;
      ln_islem_kod        number;
      lc_modul_tur_kod    varchar2(10);
      lc_urun_tur_kod     varchar2(10);
      lc_urun_sinif_kod   varchar2(20);
      lc_doviz_kod        varchar2(3):= pkg_genel.lc_al;
      lc_hesap_no         number:= to_number (ps_from_acc);
      lc_from_exacc          varchar2(16):=pkg_soa_inquiry.Active_external_hesapno_al(lc_hesap_no);
      ln_musteri_no       number:= pkg_hesap.hesaptanmusterinoal (to_number (lc_hesap_no));
      lc_bolum_kodu       varchar2(3):= pkg_hesap.hesapsubeal (lc_hesap_no);
      ls_from_rnn         varchar2(20):=pkg_musteri.sf_vergino_al(ln_musteri_no);
      ls_from_okpo        varchar2(20):=pkg_musteri.sf_okpo_al(ln_musteri_no);
      ls_from_social      varchar2(20):=pkg_musteri.sf_sosyal_fon_no_al(ln_musteri_no);
      ls_bank_code        varchar2(14):=pkg_message.split(ps_bank_code ,';',0);
      ln_payment_code     number:=to_number(pkg_message.split(pn_paycode  ,';',0));
      ln_tutar            number;
      ps_starthour        varchar2(10);
      ps_endhour          varchar2(10);
      ps_tmp              number:= 0;
      lc_rol              number:= 7777 ;
      ls_description      varchar2(250);
      lc_kasa_kod         number;
      ln_kanal_numara     number:= 1;
      ln_detailid         number:= 1;
      ps_ileritarihli      varchar2(1):='0';
      ln_currenthour      number;
      ls_ref_no              varchar2(15);
      eft_time_expired    exception;
      timeexception          exception;
      ls_retval              varchar2(3):='000';

      notenoughbalance      exception;--ernestk 24092014 cqdb00001011 if balance is not enough
begin
    ld_date := to_date(pd_trandate,'YYYYMMDD');
    ls_retval:=pkg_int_limit.checktimelimit('CLEARING');
    ln_tutar:=to_number(pn_amount,'99999999999.99');
    if (ld_date > pkg_muhasebe.banka_tarihi_bul) then ps_ileritarihli:='1'; end if;

    ln_islem_no       :=pkg_tx.islem_no_al;
    ln_islem_kod      :=3555;
    --lc_modul_tur_kod  :=ps_payment_type ;
    pkg_parametre.deger('G_RIBCLEARING_MODUL_TYPE', lc_modul_tur_kod);
    pkg_parametre.deger('G_RIBCLEARING_PRODUCT_TYPE', lc_urun_tur_kod);
    pkg_parametre.deger('G_RIBCLEARING_PRODUCT_CLASS', lc_urun_sinif_kod);
    --lc_modul_tur_kod  :='CLEARING';
    --lc_urun_tur_kod   :='OUTGOING';
    --lc_urun_sinif_kod :='RIBCLEARING';

    /*Begin_Bakdoolot ib-52 02.03.22*/
    IF ps_payment_type='CLEARING' THEN
       SELECT DECODE(MUSTERI_TIPI_KOD,1,'RIBCLEARING','CIBCLEARING')
       INTO   lc_urun_sinif_kod
       FROM CBS_MUSTERI
       WHERE musteri_no=ln_musteri_no;
    END IF;
    /*End_Bakdoolot ib-52 02.03.22*/

    --B-O-M almasn 04092014 cqdb1107 tax payment thought IB
    if ps_payment_type = 'IB_TAX_PAYMENT' then
        lc_urun_sinif_kod :='RIBTAXPAY';
        if (length(pn_income) > 0) then
            ls_from_rnn := pn_income;
        end if;

        ls_ref_no := 'T'||pkg_tx.islem_no_al;
        ls_from_okpo   := '99999999';
        ls_from_social := '99999999999999';
    else
        ls_ref_no := 'I'||pkg_tx.islem_no_al;
    end if;
    --E-O-M almasn 04092014 cqdb1107 tax payment thought IB

    lc_doviz_kod      :=pkg_genel.lc_al;
    ln_charge_amount  := 0;

    ls_description:=nvl(ps_description,'CLEARING PAYMENT');

    ln_charge_amount  :=pkg_aps.chargeautocalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                               ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_no, lc_hesap_no, lc_kasa_kod);

    --B-O-M ernestk 29042014 cqdb00001011 check balance with ccommission
    if pkg_hesap.kullanilabilir_bakiye_al(lc_hesap_no) < (ln_tutar + ln_charge_amount) then
        raise notenoughbalance;
    end if;
    --E-O-M ernestk 29042014 cqdb00001011 check balance with ccommission

    ls_ref_no := 'I'||pkg_tx.islem_no_al;

    insert into cbs_clearing_islem
    (tx_no, urun_tur_kod, ref_no, payment_type, maturity_date,
    from_account, from_account_external_number, from_rnn, from_okpo, from_social_fund_number,
    to_account_external_number, to_subaccount, to_name, to_bank_bic, code_of_payment,
    amount, explanation, charge_amount, yaratildigi_tarih, yaratan_kullanici,
    musteri_no, from_description, to_account_number, gl_flag, gl_account,
    to_subaccount_name, bolum_kodu, giris_kullanici, onay_kullanici, internal_no,
    sira_no, msg_status)
    values
    (ln_islem_no, lc_urun_tur_kod, ls_ref_no, lc_modul_tur_kod, ld_date,
    lc_hesap_no, lc_from_exacc, ls_from_rnn, ls_from_okpo, ls_from_social,
    ps_to_account, pn_rnn, ps_payee_name, ls_bank_code, ln_payment_code,
    ln_tutar, ps_description, ln_charge_amount, sysdate, 'CINT_CALLER',
    ln_musteri_no, ps_sender_name, null, null, null,
    pn_doc_no, lc_bolum_kodu, 'CINT_CALLER', 'CINT_CALLER', null,
    null, 'sNEW');

    pkg_int_api.create_transaction(ln_islem_no,
                                   ln_islem_kod,
                                   lc_modul_tur_kod,
                                   lc_urun_tur_kod,
                                   lc_urun_sinif_kod,
                                   ln_tutar,
                                   lc_bolum_kodu,
                                   lc_bolum_kodu,
                                   lc_rol,
                                   lc_doviz_kod,
                                   ln_musteri_no,
                                   lc_hesap_no,
                                   lc_kasa_kod,
                                   ln_kanal_numara);

    pkg_int_api.process_transaction (ln_islem_no);

    select ref_no into lc_refno
    from cbs_clearing_islem
    where tx_no = ln_islem_no ;

    open pc_ref for select lc_refno,ln_islem_no    from dual;
    commit;
    return ls_returncode;
exception
    --B-O-M ernestk 29042014 cqdb00001011 if balance is not engough
    when notenoughbalance then
        rollback;
        ls_returncode := '502';
        log_at('Bakiye yeterli degil',lc_hesap_no,pkg_hesap.kullanilabilir_bakiye_al(lc_hesap_no), ln_tutar + ln_charge_amount);
        open pc_ref for select lc_refno,ln_islem_no    from dual;
        return ls_returncode;
    --E-O-M ernestk 29042014 cqdb00001011 if balance is not engough
    when timeexception then
        open pc_ref for select sysdate from dual;
        return ls_returncode;
    when eft_time_expired then
        open pc_ref for select sysdate from dual;
        return ls_returncode;
    when others then
        ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
        log_at('MakeEFT',ln_islem_no,sqlerrm);
        rollback;
        raise_application_error(-20100,sqlerrm);
        open pc_ref for    select to_char(ln_islem_no) islem_no from dual;
        return ls_returncode;
end;

/******************************************************************************
   NAME        : FUNCTION CancelClearing
   Prepared By : Almas Nurhozhaev
   Date        : 04.07.08
   Purpose     : Cancel clearing transaction
******************************************************************************/
function cancelclearing(p_txno in varchar2,
                        pc_ref out cursorreferencetype) return varchar2 is
    ls_returncode    varchar2(3):='000';
    ln_count        number;
    ln_fis_no       number;

    cl_count        number;
    restrictederror exception;

    cursor c1 is
        select numara
        from cbs_fis
        where islem_numara=p_txno;

    r1    c1%rowtype;
begin

    select count(*)
    into cl_count
    from CBS_CLEARING t
    where t.YARATAN_TX_NO = TO_NUMBER(p_TXNO)
    and t.MSG_STATUS='sDONE';

    if cl_count > 0 then
        raise restrictederror;
    end if;

    open pc_ref for select sysdate from dual;

    pkg_tx3555.iptal_onay_sonrasi(p_txno);

    open c1;
    fetch c1 into r1;
        if c1%found then
            while c1%found
            loop
                pkg_muhasebe.fis_iptal(r1.numara);
            fetch c1 into r1;
            end loop;
        end if;
    close c1;

    /*UPDATE CBS_CLEARING t
    SET t.MSG_STATUS = 'sCANCEL'
    WHERE t.YARATAN_TX_NO = TO_NUMBER(p_TXNO);

    UPDATE CBS_ISLEM
    SET durum='2'
    WHERE NUMARA=TO_NUMBER(p_TXNO);

    DELETE FROM CBS_SATIR
    WHERE FIS_NUMARA IN (SELECT NUMARA FROM CBS_FIS WHERE ISLEM_NUMARA=TO_NUMBER(p_TXNO) AND TUR='T');

    DELETE FROM CBS_FIS
    WHERE ISLEM_NUMARA=TO_NUMBER(p_TXNO)
    AND TUR='T';*/

    return ls_returncode;
exception
    when restrictederror then
        ls_returncode:='030';
        rollback;
        open pc_ref for
        select to_char(p_txno) islem_no from dual;
        return ls_returncode;
    when others then
    ls_returncode := '999';
    raise_application_error(-20100,sqlerrm);
    log_at('CancelClearing',p_txno,sqlerrm);
    return ls_returncode;
end;

/******************************************************************************
*  Method Name   : MakeContact
*  Description   : Gets Message Information
*  Prepared By   : Almas Nurhozhaev
*  Modified Date : 03.04.2008
******************************************************************************/
function makecontact(ps_optioncd in varchar2,
                     ps_from_personid in varchar2,
                     ps_channelcd in varchar2,
                     ps_content in varchar2,
                     ps_toperson in varchar2,
                     pc_ref out cursorreferencetype)  return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_message_id number := 0;
begin

    if (ps_optioncd='WRITE_MESSAGES') then
        ln_message_id := corpint.pkg_common.getsequenceid('sqMESSAGEID');

        insert into corpint.tbl_contact_message_list
        (msg_id, from_person_id, msg_date, msg_content, channel_cd, to_person_id)
        values
        (ln_message_id, ps_from_personid, sysdate, substr(ps_content,1,4000), ps_channelcd, ps_toperson);
    end if;

    if (ps_channelcd='cDKBRIB') then
        open pc_ref for
            select msg_id,
                   case channel_cd when 'cDKBRIB' then (select firstname from corpint.tbl_person where person_id=from_person_id and rownum=1) end from_name,
                   from_person_id, msg_date, msg_content, to_char(msg_date,'dd/mm/yyyy hh24:mi:ss') write_date
            from corpint.tbl_contact_message_list
            where (from_person_id=ps_from_personid
            and channel_cd='cDKBRIB')
            or
            (to_person_id=ps_from_personid
            and channel_cd='cOFFICE')
            order by msg_id desc;
    else
        open pc_ref for
            select msg_id,
                   decode(channel_cd,'cDKBRIB',(select firstname||' '||lastname from corpint.tbl_person where person_id=from_person_id and rownum=1)) name_surname,
                   from_person_id, msg_date, msg_content, to_char(msg_date,'dd/mm/yyyy hh24:mi:ss')
            from corpint.tbl_contact_message_list
            order by msg_id desc;
    end if;

    return ls_returncode;
exception
   when others   then
      ls_returncode := '999';
      open pc_ref for select sysdate from dual;
      raise_application_error(-20100,sqlerrm);
      return ls_returncode;
end;

/******************************************************************************
   NAME        : FXBuySell
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Foreign Exchange Buy Sell
******************************************************************************/
function  fxbuysell(ps_trantype in varchar2,
                    pn_borc_hesap_no in varchar2,
                    ps_doviz_kodu in varchar2,
                    pn_kur in varchar2,
                    pn_tutar in varchar2,
                    pn_alacak_hesap_no in varchar2,
                    ps_istatistik_kodu in varchar2,
                    ps_aciklama in varchar2,
                    pn_rezervasyon_no in varchar2,
                    ps_masraf in varchar2,
                    ps_tahsil_adilen_toplam_tutar in varchar2,
                    pc_ref out cursorreferencetype) return varchar2 is
    pn_islem_no        number;
    pn_islem_kod number;
    pc_modul_tur_kod varchar2(10);
    pc_urun_tur_kod varchar2(10);
    pc_urun_sinif_kod varchar2(20);
    pc_rol number:=7777;
    pc_kasa_kod number;
    pc_doviz_kod varchar(3):=ps_doviz_kodu;
    pc_hesap_numara number:=pn_borc_hesap_no;
    pn_musteri_numara number:=pkg_hesap.hesaptanmusterinoal(to_number(pn_borc_hesap_no));
    ps_bolum_kodu varchar2(3):=pkg_hesap.hesapsubeal(pn_borc_hesap_no);
    pc_bolum_kodu varchar(10):=ps_bolum_kodu;
    pc_amir_bolum_kodu varchar(10):=ps_bolum_kodu;
    pn_kanal_numara       number:=1;
    ls_istatistik_kodu       varchar2(10);
    ls_doviz_ulke_kodu       varchar2(3);
    ls_dekont_basim_f       varchar2(1);
    ls_stat_buy       varchar2(4);
    ls_stat_sell       varchar2(4);
    ln_tutar               number;
    ln_tahsil_adilen_toplam_tutar number;
    ls_returncode           varchar2(3):='000';
    fxbuysellover           exception;
    ls_explanation           varchar2(100);
    norezervationerror       exception;
    ln_count               number;
    ln_rezervasyon_no       number;
    ln_amount_in_kgs       number;
    ln_kur                 number;
    retail_ib_fx_limit       varchar2(200):='-1';
    use_ib_product        cbs_parametre.deger%type;
begin
    pkg_parametre.deger('RETAIL_IB_FX_LIMIT', retail_ib_fx_limit);
    pn_islem_no:=pkg_tx.islem_no_al;

    ln_tutar:=to_number(pn_tutar,'99999999999.99');
    ln_kur:=to_number(pn_kur,'99999999999.9999');

    ln_amount_in_kgs:=pn_tutar*ln_kur;

    if pn_rezervasyon_no is not null and length(ltrim(rtrim(pn_rezervasyon_no)))>0 then
       ln_rezervasyon_no:=to_number(pn_rezervasyon_no);

       select count(*)
       into ln_count
       from cbs_vw_kur_rezervasyon r
       where r.rezervasyon_no=ln_rezervasyon_no
       and r.bakiye<>0
       and musteri_no=pn_musteri_numara;

       if ln_count=0 then
             raise norezervationerror;
       end if;

       pkg_kur_rezervasyon.rezervasyon_kullanim_kaydet(ln_rezervasyon_no,pn_islem_no,ln_tutar,pkg_muhasebe.banka_tarihi_bul,ps_bolum_kodu);
    end if;

    select ulke_kodu
   into ls_doviz_ulke_kodu
    from cbs_doviz_kodlari
    where doviz_kodu = ps_doviz_kodu;

    ls_stat_buy := '14' || pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_borc_hesap_no))) ||
                 pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_borc_hesap_no))) ;

    ls_stat_sell := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_borc_hesap_no))) ||
                 pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_borc_hesap_no))) || '14';

    ln_tahsil_adilen_toplam_tutar:=to_number(ps_tahsil_adilen_toplam_tutar,'99999999999.99');--TO_NUMBER(REPLACE(REPLACE(ps_TAHSIL_ADILEN_TOPLAM_TUTAR,',',''),'.',','));

    pkg_hesap.urunbilgial(pn_borc_hesap_no,pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);

    pkg_parametre.deger('G_RIBFXBUYSELL_USE_IB_PRODUCT', use_ib_product);
    if (use_ib_product = 'Y') then
        pc_modul_tur_kod := 'IB' || pc_modul_tur_kod;
    end if;

    if ps_trantype='A' then
        pn_islem_kod:=4025;
        ls_istatistik_kodu := '213';
        ls_explanation:='Currency Code '|| ps_doviz_kodu|| ' Currency Rate' || pn_kur;
        insert into cbs_dth_doviz_satis_islem
        (tx_no, islem_tarihi, musteri_no, musteri_hesap_no, doviz_kodu,
         doviz_tutari, rezervasyon_no, kur, dth_musteri_no, dth_musteri_hesap_no,
         aciklama, masraf, tahsil_adilen_toplam_tutar, islem_sube, musteri_external_hesap,
         musteri_vergi_no, dth_musteri_external_hesap, dth_musteri_vergi_no)
        values
        (pn_islem_no, pkg_muhasebe.banka_tarihi_bul, pn_musteri_numara, pn_borc_hesap_no, ps_doviz_kodu,
         ln_tutar, ln_rezervasyon_no, to_number(pn_kur,'99999999999.9999'), pn_musteri_numara, pn_alacak_hesap_no,
         substr(ps_aciklama ||ls_explanation,1,100), to_number(ps_masraf,'99999999999.99'), ln_tahsil_adilen_toplam_tutar,
         ps_bolum_kodu, lpad(nvl(pkg_soa_inquiry.Active_external_hesapno_al(pn_borc_hesap_no),0),16,'0'),
         nvl(pkg_musteri.sf_vergino_al(pn_musteri_numara),0),
         lpad(nvl(pkg_soa_inquiry.Active_external_hesapno_al(pn_alacak_hesap_no),0),16,'0'),
         nvl(pkg_musteri.sf_vergino_al(pn_musteri_numara),0));

    pkg_int_api.create_transaction (pn_islem_no, pn_islem_kod,
                               pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                               ln_tutar,pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                               pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                               pc_kasa_kod,pn_kanal_numara);


if to_number(retail_ib_fx_limit)>0 and ln_amount_in_kgs<=to_number(retail_ib_fx_limit) then
    pkg_int_api.process_transaction (pn_islem_no);
end if;
    elsif ps_trantype='S' then
         pn_islem_kod:=1202;
            ls_istatistik_kodu := '223';
         ls_explanation:='Currency Code '|| ps_doviz_kodu|| ' Currency Rate ' || pn_kur;
         insert into cbs_dth_tl_odeme_islem
         (tx_no, borc_hesap_no, doviz_kodu, kur, tutar,
          alacak_hesap_no, istatistik_kodu_alis, doviz_ulke_kodu, aciklama,
          dekont_basim_f, rezervasyon_no, prefix_istatistik_kodu_alis,
          prefix_istatistik_kodu_satis, istatistik_kodu_satis,
          borc_external_hesap, borc_vergi_no, alacak_external_hesap, alacak_vergi_no)
         values
         (pn_islem_no, pn_borc_hesap_no, ps_doviz_kodu, to_number(pn_kur,'99999999999.9999'),
          ln_tutar, pn_alacak_hesap_no, ls_istatistik_kodu, ls_doviz_ulke_kodu,
          ls_explanation, ls_dekont_basim_f, null, to_number(ls_stat_buy),
          to_number(ls_stat_sell), ls_istatistik_kodu,
          lpad(nvl(pkg_soa_inquiry.Active_external_hesapno_al(pn_borc_hesap_no),0),16,'0'),
          nvl(pkg_musteri.sf_vergino_al(pn_musteri_numara),0),
          lpad(nvl(pkg_soa_inquiry.Active_external_hesapno_al(pn_alacak_hesap_no),0),16,'0'),
          nvl(pkg_musteri.sf_vergino_al(pn_musteri_numara),0));

        pkg_int_api.create_transaction (pn_islem_no, pn_islem_kod,
                                   pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                   ln_tutar,pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                   pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                                   pc_kasa_kod,pn_kanal_numara);
if to_number(retail_ib_fx_limit)>0 and ln_amount_in_kgs<=to_number(retail_ib_fx_limit) then
        pkg_int_api.process_transaction (pn_islem_no);
end if;
    end if;

    open pc_ref for
    select 'aaa',to_char(pn_islem_no) islem_no
    from dual;

    return ls_returncode;
exception
    when norezervationerror then
        ls_returncode:='402';
        rollback;
        open pc_ref for
        select to_char(pn_islem_no) islem_no from dual;
        return ls_returncode;
    when others then
        ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
        log_at(pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod);
        log_at(sqlerrm,ls_returncode,ln_rezervasyon_no,pn_musteri_numara);
        raise_application_error(-20100,sqlerrm);
        rollback;
        open pc_ref for
        select to_char(pn_islem_no) islem_no from dual;
        raise_application_error(-20100,sqlerrm);
        return ls_returncode;
end;

/******************************************************************************
   NAME        : FUNCTION MakeArbitrage
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Make Arbitraje
******************************************************************************/
function makearbitrage(pn_fromaccountno in varchar2,
                       pn_toaccountno in varchar2,
                       ps_fromcurrency in varchar2,
                       ps_tocurrency in varchar2,
                       pn_parity in varchar2,
                       pn_fromamount in varchar2,
                       pn_toamount in varchar2,
                        pc_ref out cursorreferencetype) return varchar2 is
        pn_islem_no            number;
        pn_islem_kod              number;
        pc_modul_tur_kod          varchar2(10);
        pc_urun_tur_kod          varchar2(10);
        pc_urun_sinif_kod          varchar2(20);
        pc_rol                  number:=7777;
        pc_kasa_kod              number;
        pn_kanal_numara         number:=1;
        pc_bolum_kodu             varchar2(10);
        pc_amir_bolum_kodu      varchar2(10);
        pc_doviz_kod              varchar2(3);
        pn_musteri_numara          number;
        pc_hesap_numara          number;
        ln_buy_rate              number;
        ln_sell_rate              number;
        ln_debit_extaccount     varchar(9);
        ln_credit_extaccount     varchar(9);
        ln_debit_taxno         number;
        ln_credit_taxno         number;
        ls_stat_buy            number;
        ls_stat_sell            number;
        ln_parity              number;
        ls_istatistik_kodu_alis        varchar2(10);
        ls_istatistik_kodu_satis        varchar2(10);
        ls_doviz_ulke_kodu           varchar2(3);
        ln_tutar                   number;
        ln_tahsil_adilen_toplam_tutar number;
        ls_returncode            varchar2(3):='000';
        fxbuysellover            exception;
        ls_explanation            varchar2(100);
begin
          pn_islem_no:=pkg_tx.islem_no_al;
         pn_islem_kod:=1207;
         --pc_modul_tur_kod:='CURR.OPS.';
         --pc_urun_tur_kod:='ACC-ACC';
         --pc_urun_sinif_kod:='FC-FC';

         pkg_parametre.deger('G_RIBARBITRAGE_MODUL_TYPE', pc_modul_tur_kod);
         pkg_parametre.deger('G_RIBARBITRAGE_PRODUCT_TYPE', pc_urun_tur_kod);
         pkg_parametre.deger('G_RIBARBITRAGE_PRODUCT_CLASS', pc_urun_sinif_kod);

         ls_istatistik_kodu_alis:= '213';
         ls_istatistik_kodu_satis:= '223';
         pc_hesap_numara:=to_number(pn_fromaccountno);
         pn_musteri_numara:=pkg_hesap.hesaptanmusterinoal(pc_hesap_numara);
         pc_bolum_kodu:=pkg_musteri.sf_bolum_kodu_al(pn_musteri_numara);
         pc_amir_bolum_kodu:=pc_bolum_kodu;
         pc_doviz_kod:=ps_fromcurrency;
         ln_buy_rate:=pkg_kur.doviz_doviz_karsilik(ps_fromcurrency,pkg_genel.lc_al,null,1,1,null,null,'O','A');
         ln_sell_rate:=pkg_kur.doviz_doviz_karsilik(ps_tocurrency,pkg_genel.lc_al,null,1,1,null,null,'O','S');
         ln_debit_extaccount:=lpad(pkg_soa_inquiry.Active_external_hesapno_al(pn_toaccountno),9,0);
         ln_credit_extaccount:=lpad(pkg_soa_inquiry.Active_external_hesapno_al(pn_fromaccountno),9,0);
         ln_debit_taxno:=pkg_musteri.sf_vergino_al(pkg_hesap.getmusterinofromexternal(lpad(pkg_soa_inquiry.Active_external_hesapno_al(pn_toaccountno),9,0)));
         ln_credit_taxno:=pkg_musteri.sf_vergino_al(pkg_hesap.getmusterinofromexternal(lpad(pkg_soa_inquiry.Active_external_hesapno_al(pn_fromaccountno),9,0)));
         ls_explanation:='ToCurrency ' ||ps_tocurrency||'-'||ps_fromcurrency||pn_parity;
         ls_stat_buy := '14' || pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno))) ||
         pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno))) ;
         ls_stat_sell := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno))) ||
         pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno))) || '14';
         ln_tutar:=to_number(pn_fromamount,'99999999999.99');
         ln_parity:=to_number(pn_parity,'99999999999.99999');

         --Pkg_Hesap.UrunBilgiAl(pn_fromaccountno,pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);

         insert into cbs_arbitraj_islem
         (tx_no, alis_doviz_kodu, satis_doviz_kodu, alis_kuru, satis_kuru,
          parite,carp_bol_secimi, alis_tutari,satis_tutari, alis_hesap_no,
          satis_hesap_no, aciklama, kayit_giris_tarihi, kayit_yaratan_kullanici_kodu, kur_parite_secim,
          islem_kod, urun_tur_kod, urun_sinif_kod, musteri_no, islem_tarihi,kur_tipi)
          values
         (pn_islem_no,ps_fromcurrency,ps_tocurrency,ln_buy_rate,ln_sell_rate,
          ln_parity,'CARP',ln_tutar, to_number(pn_toamount,'99999999999.99'),to_number(pn_fromaccountno),
          to_number(pn_toaccountno),ls_explanation,sysdate,'CINT_CALLER','P',
          1204, pc_urun_tur_kod, pc_urun_sinif_kod, pn_musteri_numara,pkg_muhasebe.banka_tarihi_bul, 'COMMERCIAL');

          pkg_int_api.create_transaction (pn_islem_no, pn_islem_kod,
                                             pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                          ln_tutar,pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                             pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                                             pc_kasa_kod,pn_kanal_numara);

          pkg_int_api.process_transaction (pn_islem_no);

          open pc_ref for select 'aaa',to_char(pn_islem_no) islem_no from dual;

    return ls_returncode;
exception
      when others   then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('ARBITRAGE',sqlerrm, ls_returncode);
         rollback;
         raise_application_error(-20100,sqlerrm);
         open pc_ref for select sysdate from dual;
         return ls_returncode;
end;
/******************************************************************************
   NAME        : FUNCTION CreateTimeDepositeAccount
   Prepared By : Muzaffar Khalyknazarov
   Date        : 21.12.2007
   Purpose     : Create Time Deposit Account
******************************************************************************/
function createtimedepositeaccount(ps_customerid in varchar2,
                                   ps_modultur in varchar2,
                                   ps_uruntur in varchar2,
                                   ps_urunsinif in varchar2,
                                   ps_nickname in varchar2,
                                   ps_currcode in varchar2,
                                   ps_anapara in varchar2,
                                   ps_valortarihi in varchar2,
                                   ps_borckaydi in varchar2,
                                   ps_borcluhesapnumarasi in varchar2,
                                   ps_muhabirhesapnumarasi in varchar2,
                                   ps_dknumarasi in varchar2,
                                   ps_vade_islem_bilgisi in varchar2,
                                   ps_ara_odeme_bilgisi in varchar2,
                                   ps_otomatik_temdit in varchar2,
                                   ps_periodsure in varchar2,
                                   ps_periodcins in varchar2,
                                   ps_sonraki_baslangic_tarihi in varchar2,
                                   ps_ara_odeme_islem_bilgisi in varchar2,
                                   ps_vade_tarihi in varchar2,
                                   ps_geri_donus_hesap_numarasi in varchar2,
                                   ps_esas_gun_sayisi in varchar2,
                                   ps_faiz_orani in varchar2,
                                   ps_aciklama in varchar2,
                                   ps_sube in varchar2,
                                   ps_acilistarihi in varchar2,
                                   ps_net_faiz in varchar2,
                                     pc_ref out cursorreferencetype) return varchar2 is

   ls_returncode            varchar2(3):='000';
   ln_hesap_no                number;
   pn_islem_no number;
   pn_islem_kod number;
   pc_modul_tur_kod varchar2(20):=ps_modultur;
   pc_urun_tur_kod varchar2(20):=ps_uruntur;
   pc_urun_sinif_kod varchar2(20):=ps_urunsinif;

   ps_bolum_kodu varchar2(3):=pkg_hesap.hesapsubeal(ps_borcluhesapnumarasi);
   pc_bolum_kodu varchar(10):=ps_bolum_kodu;
   pc_amir_bolum_kodu varchar(10):=ps_bolum_kodu;
   pc_rol number:=7777;
   ln_tutar number:= to_number(replace(replace(ps_anapara,',',''),'.',','));
   pc_doviz_kod varchar(10):= ps_currcode ;
   pn_musteri_numara number:= pkg_hesap.hesaptanmusterinoal(to_number(ps_borcluhesapnumarasi));
   pc_hesap_numara number:= to_number(ps_borcluhesapnumarasi);
   pc_kasa_kod number;
   pn_kanal_numara number:= 1;
   ps_sistem_tarih date:= pkg_muhasebe.banka_tarihi_bul;
   ls_istatistik varchar2(3):='322';
   ln_prefix number:=pkg_soa_common.getcustomerprefixcode(ps_customerid);

   LD_VALUE_DATE DATE; --CBS-217 AntonPa 22.09.21
begin

    pn_islem_no:=pkg_tx.islem_no_al;
    pn_islem_kod:=2003 ;
    ln_hesap_no:=pkg_genel.genel_kod_al('HESAP.VDSZ');
--BOM CBS-217 AntonPa 22.09.21
    IF TRUNC(ps_sistem_tarih) <= TRUNC(SYSDATE) THEN
        LD_VALUE_DATE := ps_sistem_tarih + 1;
    ELSE
        LD_VALUE_DATE := TRUNC(SYSDATE + 1);
    END IF;
--EOM CBS-217 AntonPa 22.09.21
    open pc_ref for
    select sysdate from dual;

    insert into cbs_hesap_vadeli_basvuru(
    tx_no, hesap_numarasi, musteri_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod, kisa_isim,
    doviz_kodu, tutar, valor_tarihi, borc_kaydi, borclu_hesap_no, muhabir_hesap_no, dk_no,
    vade_islem_bilgisi, ara_odeme_bilgisi, otomatik_temdit, period_sure, period_cins, sonraki_baslangic_tarihi,
    ara_odeme_islem_bilgisi, vade_tarihi, geri_donus_hesapno, esas_gun_sayisi, faiz_orani, aciklama,
    ekstre_basim_kodu,ekstre_sikligi, dekont, sube_kodu, acilis_tarihi, min_imza_adedi, musteri_dk_no, muhasebe_tarihi,
    istatistik_kodu_alis, prefix_istatistik_kodu_alis, istatistik_kodu_kapama,
    prefix_istatistik_kodu_kapama, istatistik_kodu_faiz, prefix_istatistik_kodu_faiz,ref_staff)
    values (pn_islem_no,ln_hesap_no,to_number(ps_customerid),ps_modultur,ps_uruntur,ps_urunsinif,substr(ps_nickname,1,20),
            ps_currcode,to_number(ps_anapara,'999,999,999,999,999.999'),
            LD_VALUE_DATE --CBS-217 AntonPa 22.09.21
            ,ps_borckaydi,to_number(ps_borcluhesapnumarasi),ps_muhabirhesapnumarasi,ps_dknumarasi,
            ps_vade_islem_bilgisi,to_number(ps_ara_odeme_bilgisi),ps_otomatik_temdit,ps_periodsure,ps_periodcins,ps_sonraki_baslangic_tarihi,
            ps_ara_odeme_islem_bilgisi,to_date(ps_vade_tarihi,'YYYYMMDD'),to_number(ps_borcluhesapnumarasi),to_number(ps_esas_gun_sayisi),to_number(ps_faiz_orani,'999,999,999,999,999.999'),ps_aciklama,
            'X','','',ps_sube,ps_sistem_tarih,'','',ps_sistem_tarih,
            ls_istatistik,ln_prefix,ls_istatistik,322,ls_istatistik,ln_prefix,user);

    pkg_int_api.create_transaction (pn_islem_no, pn_islem_kod,
                               pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                               ln_tutar, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                               pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                               pc_kasa_kod,pn_kanal_numara);

    pkg_int_api.process_transaction (pn_islem_no);

    open pc_ref for
    select to_char(ln_hesap_no), pn_islem_no from dual;

    return ls_returncode;
exception
    when others then
    ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
    log_at('CreateTimeDepositeAccount:'||sqlerrm);
    rollback;
    raise_application_error(-20100,sqlerrm);
    open pc_ref for
    select sysdate from dual;
    return ls_returncode;
end;
function makeratedemand(ps_option in varchar2,
                        ps_customerid in varchar2,
                        ps_buysell in varchar2,
                        ps_currcode in varchar2,
                        ps_amount in varchar2,
                        pc_ref out cursorreferencetype) return varchar2 is
    pn_islem_no        number;
    pn_islem_kod number;
    pc_modul_tur_kod varchar2(10);
    pc_urun_tur_kod varchar2(10);
    pc_urun_sinif_kod varchar2(20);
    pc_rol number:=7777;
    pc_kasa_kod number;
    pc_doviz_kod varchar(3);
    pc_hesap_numara number;
    pn_musteri_numara number;
    pc_bolum_kodu varchar(10);
    pn_kanal_numara       number:=1;-- 0==CBS 1 =INTERNET  2= CALLCENTER

    ls_istatistik_kodu       varchar2(10);
    ls_doviz_ulke_kodu       varchar2(3);
    ln_tutar               number;
    ls_returncode           varchar2(3):='000';
    fxbuysellover           exception;
    ls_explanation           varchar2(100);
    ls_trantype               varchar2(1);
    ls_trankind               varchar2(10);
    ls_alis_doviz           varchar2(3);
    ls_satis_doviz           varchar2(3);
    ln_alis_tutar           number;
    ln_satis_tutar           number;
    ln_musteri_alis_kuru   number;
    ln_musteri_satis_kuru  number;
    ln_maliyet_alis_kuru  number;
    ln_maliyet_satis_kuru number;
    ls_content              varchar2(2000);
begin

    pn_islem_no:=pkg_tx.islem_no_al;
    pn_islem_kod:=4020;
    pc_modul_tur_kod:='SYSTEM';
    pc_urun_tur_kod:='RATE';
    pc_urun_sinif_kod:='COST_DEMAND';
    ln_tutar:=to_number(ps_amount,'99999999999.99');
    pn_musteri_numara:=to_number(ps_customerid);
    pc_doviz_kod:=ps_currcode;
    pc_bolum_kodu:=pkg_musteri.sf_bolum_kodu_al(pn_musteri_numara);

    if ps_option='RATEDEMAND' then
       ls_trantype:='M';
    else--REZERVATION
       ls_trantype:='R';
    end if;

    if ps_buysell='BUY' then
        ls_trankind:='ALIS';
        ls_alis_doviz:=pc_doviz_kod;
        ls_satis_doviz:=null;
        ln_alis_tutar:=ln_tutar;
        ln_satis_tutar:=null;
        ln_musteri_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz,pkg_genel.lc_al,null,1,1,null,null,'O','A');
        ln_maliyet_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz,pkg_genel.lc_al,null,1,3,null,null,'N','A');
        ln_musteri_satis_kuru:=null;
        ln_maliyet_satis_kuru:=null;
    else--SELL
        ls_trankind:='SATIS';
        ls_alis_doviz:=null;
        ls_satis_doviz:=pc_doviz_kod;
        ln_alis_tutar:=null;
        ln_satis_tutar:=ln_tutar;
        ln_musteri_alis_kuru:=null;
        ln_maliyet_alis_kuru:=null;
        ln_musteri_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz,pkg_genel.lc_al,null,1,1,null,null,'O','S');
        ln_maliyet_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz,pkg_genel.lc_al,null,1,3,null,null,'N','S');
    end if;

    /*if to_number(to_char(sysdate,'HH24'))>15 then
       raise FXBuySellOver;
    end if;*/

    insert into cbs_kur_rezervasyon_talep
    (tx_no, tarih, sube_kodu, rezervasyon_no, musteri_no, islem_tipi, islem_sekli, alis_doviz, satis_doviz, alis_tutar, satis_tutar, musteri_parite, musteri_alis_kuru, musteri_satis_kuru, maliyet_parite, maliyet_alis_kuru, maliyet_satis_kuru, durum_kodu, kur_parite)
    values
    (pn_islem_no, pkg_muhasebe.banka_tarihi_bul, pc_bolum_kodu, null, pn_musteri_numara, ls_trantype, ls_trankind, ls_alis_doviz, ls_satis_doviz,ln_alis_tutar, ln_satis_tutar, null, ln_musteri_alis_kuru, ln_musteri_satis_kuru, null, ln_maliyet_alis_kuru, ln_maliyet_satis_kuru, null, null);

    pkg_int_api.create_transaction (pn_islem_no, pn_islem_kod,
                               pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                               ln_tutar,pc_bolum_kodu, pc_bolum_kodu,pc_rol,
                               pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                               pc_kasa_kod,pn_kanal_numara);

    --Onay olmayacak.Cunku once kontrol etmek istiyorlar
    pkg_int_api.process_transaction (pn_islem_no);

    ls_content:='Customer No:' ||pn_musteri_numara || '<BR>Customer Name:' || pkg_musteri.sf_musteri_adi(pn_musteri_numara) || '<BR>Transaction Type:' || ps_buysell || '<BR>Amount:' || ln_tutar || '<BR>Currency:' || pc_doviz_kod;
    pkg_email.addtoemailqueue('RATEDEMAND', 50, 'info@demirbank.kg', 'treasurygroup@demirbank.kg;ITgroup@demirbank.kg', 'Rate Demand Request From Customer',ls_content,'HTML');

    open pc_ref for    select 'aaa',to_char(pn_islem_no) islem_no    from dual;


    return ls_returncode;

exception
         when fxbuysellover then
               ls_returncode:='268';
              rollback;
              open pc_ref for
                select to_char(pn_islem_no) islem_no from dual;
                return ls_returncode;
         when others then
            ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
            log_at(sqlerrm);
            rollback;
            open pc_ref for     select to_char(pn_islem_no) islem_no from dual;
            return ls_returncode;
end;
/******************************************************************************
   NAME        : FUNCTION MakeClosingTimeDeposit
   Prepared By : Almas Nurkhozhayev
   Date        : 26.05.10
   Purpose     : Make closing time deposit account
******************************************************************************/
function makeclosingtimedeposit(pn_tdaccount  in varchar2,
                                pn_amount     in varchar2,
                                ps_doviz_kodu in varchar2,
                                pc_ref        out   cursorreferencetype) return varchar2 is

      ls_returncode       varchar2(3):= '000';
      pn_islem_no number;
      pn_islem_kod number;
      la_aciklama  varchar2(100):='CLOSING TIME DEPOSIT BEFORE MATURITY ';
      ln_tdaccount_no number:=to_number(pn_tdaccount);
      ln_musteri_no number:=pkg_hesap.hesaptanmusterinoal(ln_tdaccount_no);
      lc_bolum_kodu varchar2(3):=pkg_hesap.hesapsubeal(ln_tdaccount_no);
      lc_modul_tur_kod    varchar2(10);
      lc_urun_tur_kod     varchar2(10);
      lc_urun_sinif_kod   varchar2(20);
      lc_rol              number:= 7777 ;
      lc_kasa_kod         number;
      ln_kanal_numara     number:= 1;
      ln_tutar number;--:=to_number(pn_amount,'99999999999999.99');
      ln_kur number;

      ln_gecen_yil_faiz number;
      ln_birikmis_faiz number;
begin
    open pc_ref for select '-' from dual;

    begin
        pkg_int_api.eodcontrol(null); -- if there is EOD, then system will raise application error
    exception
        when others then
            ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
            return ls_returncode;
    end;

    ln_kur:= pkg_kur.doviz_doviz_karsilik(ps_doviz_kodu, pkg_genel.lc_al, null, 1,1,null,null,'N','A');
    ln_tutar:=to_number(pn_amount,'99999999999999.99');
    pn_islem_no:=pkg_tx.islem_no_al;
    pn_islem_kod:=2004;

    pkg_hesap.urunbilgial(ln_tdaccount_no,lc_modul_tur_kod,lc_urun_tur_kod,lc_urun_sinif_kod);

    pkg_hesap.faizbilgial(ln_tdaccount_no,ln_tutar,ln_gecen_yil_faiz,ln_birikmis_faiz);

    insert into cbs_hesap_vdli_kapama_basvuru(tx_no, musteri_no, hesap_no, doviz_kodu, dk_no, bakiye_tutari, birikmis_faiz, gecen_yil_faizi, gecmis_aylarin_faizi, toplam_faiz_tutari, aciklama, net_odenen_tutar, tl_odeme_tutari, tl_odeme_sekli, tl_odeme_hesap_no, yp_odeme_tutari, yp_odeme_sekli, yp_odeme_hesap_no, tl_karsilik,kur, value_date)
    select pn_islem_no, musteri_no, hesap_no, doviz_kodu, dk_no, ln_tutar, ln_birikmis_faiz, ln_gecen_yil_faiz, gecmis_aylarin_faizi, ln_birikmis_faiz+ln_gecen_yil_faiz+gecmis_aylarin_faizi, la_aciklama, ln_tutar, decode(doviz_kodu,'KGS',ln_tutar,null), 2, decode(doviz_kodu,'KGS',geri_donus_hesapno,null), decode(doviz_kodu,'KGS',null,ln_tutar), 2, decode(doviz_kodu,'KGS',null,geri_donus_hesapno), decode(doviz_kodu,'KGS',ln_tutar,null),ln_kur, vade_tarihi
    from cbs_hesap_vadeli
    where  hesap_no=ln_tdaccount_no;

    pkg_int_api.create_transaction(pn_islem_no,
                                   pn_islem_kod,
                                   lc_modul_tur_kod,
                                   lc_urun_tur_kod,
                                   lc_urun_sinif_kod,
                                   ln_tutar,
                                   lc_bolum_kodu,
                                   lc_bolum_kodu,
                                   lc_rol,
                                   ps_doviz_kodu,
                                   ln_musteri_no,
                                   ln_tdaccount_no,
                                   lc_kasa_kod,
                                   ln_kanal_numara);

    pkg_int_api.process_transaction (pn_islem_no);

    commit;
    open pc_ref for select '-'    from dual;
    return ls_returncode;
exception
    when others then
        ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
        log_at('MakeClosingTimeDeposit',pn_islem_no,sqlerrm);
        rollback;
        raise_application_error(-20100,sqlerrm);
        open pc_ref for    select '-' from dual;
        return ls_returncode;
end;
/******************************************************************************
   NAME        : FUNCTION MakeClosingTimeDeposit
   Prepared By : Muzaffar Khalyknazarov
   Date        : 03.02.09
   Purpose     : Make clearing transaction
******************************************************************************/
function makereptimedeposit(pn_fromaccountno    in varchar2,
                            pn_tdaccount        in varchar2,
                            pn_amount           in varchar2,
                            ps_doviz_kodu       in varchar2,
                            pc_ref              out   cursorreferencetype) return varchar2 is


      ls_returncode       varchar2(3):= '000';
      pn_islem_no number;
      pn_islem_kod number;
      la_aciklama  varchar2(100):='INCREASE TD AMOUNT';
      ln_tdaccount_no number:=to_number(pn_tdaccount);
      ln_fromaccount_no number:=to_number(pn_fromaccountno);
      ln_musteri_no number:=pkg_hesap.hesaptanmusterinoal(ln_fromaccount_no);
      lc_bolum_kodu varchar2(3):=pkg_hesap.hesapsubeal(ln_fromaccount_no);
      lc_modul_tur_kod    varchar2(10);
      lc_urun_tur_kod     varchar2(10);
      lc_urun_sinif_kod   varchar2(20);
      lc_rol              number:= 7777 ;
      lc_kasa_kod         number;
      ln_kanal_numara     number:= 1;
      ln_tutar number:=to_number(pn_amount,'99999999999999.99');
      ld_date date :=pkg_muhasebe.banka_tarihi_bul;
      ln_kur number;
      ln_lctutar number;
begin

    pn_islem_no:=pkg_tx.islem_no_al;
    pn_islem_kod:=3199;
    lc_modul_tur_kod:='ACCOUNTING';
    lc_urun_tur_kod:='F-DBCR';
    lc_urun_sinif_kod:='DBCR';
    ln_kur:= pkg_kur.doviz_doviz_karsilik(ps_doviz_kodu, pkg_genel.lc_al, null, 1,1,null,null,'N','A');
    ln_lctutar:=pkg_kur.doviz_doviz_karsilik(ps_doviz_kodu, pkg_genel.lc_al, null,ln_tutar,1,ln_kur,1,'N','A');


   /* Pkg_Tx1203.sp_urun_tur_sinif_al(pn_fromaccountno,
                                    pn_tdaccount  ,
                                    ps_doviz_kodu ,
                                    'E',
                                    lc_modul_tur_kod,
                                    lc_urun_tur_kod,
                                    lc_urun_sinif_kod);*/


    insert into cbs_sba_fis_islem(tx_no, aciklama, yaratildigi_tarih, gecerli_oldugu_tarih, yaratan_kullanici_kodu, amount_lc_db, amount_lc_cr, urun_sinif)
    values (pn_islem_no, la_aciklama, ld_date,ld_date,'CINT_CALLER',0,0,'DBCR');

    insert into cbs_sba_satir_islem(tx_no, numara, tur, hesap_bolum_kodu, hesap_tur_kodu, hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod, banka_aciklama, musteri_aciklama, referans, kur, yaratan_kullanici_kodu)
    values (pn_islem_no,1,'B',lc_bolum_kodu,'VS',ln_fromaccount_no,ld_date, ln_lctutar,ln_tutar,ps_doviz_kodu, la_aciklama,la_aciklama, 'IB',ln_kur,'CINT_CALLER');

    insert into cbs_sba_satir_islem(tx_no, numara, tur, hesap_bolum_kodu, hesap_tur_kodu, hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod, banka_aciklama, musteri_aciklama, referans, kur, yaratan_kullanici_kodu)
    values (pn_islem_no,2,'A',lc_bolum_kodu,'VD',ln_tdaccount_no,ld_date, ln_lctutar,ln_tutar,ps_doviz_kodu, la_aciklama,la_aciklama, 'IB',ln_kur,'CINT_CALLER');



    pkg_int_api.create_transaction(pn_islem_no,
                                   pn_islem_kod,
                                   lc_modul_tur_kod,
                                   lc_urun_tur_kod,
                                   lc_urun_sinif_kod,
                                   ln_tutar,
                                   lc_bolum_kodu,
                                   lc_bolum_kodu,
                                   lc_rol,
                                   ps_doviz_kodu,
                                   ln_musteri_no,
                                   ln_tdaccount_no,
                                   lc_kasa_kod,
                                   ln_kanal_numara);

    pkg_int_api.process_transaction (pn_islem_no);


    open pc_ref for select '-'    from dual;
    commit;
    return ls_returncode;
exception
    when others then
        ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
        log_at('MakeRepTimeDeposit',pn_islem_no,sqlerrm);
        rollback;
        raise_application_error(-20100,sqlerrm);
        open pc_ref for    select '-' from dual;
        return ls_returncode;
end;

/******************************************************************************
   NAME        : FUNCTION MAKESwift
   Prepared By : Almas Nurkhozhayev
   Date        : 17.08.10
   Purpose     : Make SWIFT transaction
******************************************************************************/
function makeswift(pd_amount        in varchar2,
                   pd_currency      in varchar2,
                   pd_accountid     in varchar2,
                   ps_ulkekodu      in varchar2,
                   ps_valor_tarihi  in varchar2,
                   ps_aciklama      in varchar2,
                   ps_acilistarihi  in varchar2,
                   p_payeename      in varchar2,
                   p_payeeaddress   in varchar2,
                   ps_toaccountno   in varchar2,
                   ps_muhabirmasraf in varchar2,
                   pn_paymentno     in varchar2,
                   ps_swiftcode     in varchar2,
                   ps_statcode      in varchar2,
                   ps_bankname      in varchar2,
                   pn_charge_amount in varchar2,
                   ps_telpass       in varchar2,
                   ps_recdesc       in varchar2,
                   ps_recvisite     in varchar2,
                   ps_cityname      in varchar2,
                   pn_commaccount   in varchar2,
                   pc_ref out cursorreferencetype) return varchar2  is pragma autonomous_transaction;

        ls_returncode varchar2(3):='000';
        ld_date date;

        pn_islem_no number;
        pn_islem_kod number;
        pc_modul_tur_kod varchar2(10);
        pc_urun_tur_kod varchar2(10);
        pc_urun_sinif_kod varchar2(20);
        pc_rol number:=7777;
        pc_kasa_kod number;
        pc_doviz_kod varchar(3):=pd_currency;
        pc_hesap_numara number:=to_number(pd_accountid);
        pn_musteri_numara number:=pkg_hesap.hesaptanmusterinoal(to_number(pd_accountid));
        ps_bolum_kodu varchar2(3):=pkg_hesap.hesapsubeal(pd_accountid);

        pc_bolum_kodu varchar(10):=ps_bolum_kodu;
        pc_amir_bolum_kodu varchar(10):=ps_bolum_kodu;
        pc_cek  varchar2(1):='H';
        ps_transfer_doviz varchar2(20):=pd_currency;
        ln_tutar number;
        ps_net_brut varchar2(1):='N';
        pc_tahsil_doviz varchar2(3):=pkg_hesap.hesaptandovizkodual(pd_accountid);
        pd_valor_tarihi date := to_date(ps_valor_tarihi,'YYYYMMDD');
        pc_transfer_sekli varchar2(1):='M';
        pn_muhabir_hesap_no number;
        pn_muhabir_musteri_no number;
        pn_muhabir_masraf number := 0;
        ps_muhabir_bic varchar2(11);
        ps_payeeacc varchar2(34):=ps_toaccountno;

        ps_ist_kod varchar2(10);

        pc_aciklama varchar2(200) := 'TRANSFER FROM'||pkg_hesap.hesapkisaisimal(pc_hesap_numara)||'TO'||upper(p_payeename);
        pd_acilis_tarih date := to_date(ps_acilistarihi,'YYYYMMDD');
        ps_bank_opr_code varchar2(4):='CRED';
        ps_ordering_customer varchar2(1):='K';
        ps_ben_customer varchar2(1):='N';
        ps_detail_charges varchar2(3);
        ps_acc_ins varchar2(1):='A';
        ls_referans varchar2(16);
        pd_bugun date := pkg_muhasebe.banka_tarihi_bul;

        pc_oc_isim_adres_1 varchar2(35 char);
        pc_oc_isim_adres_2 varchar2(35 char);
        pc_oc_isim_adres_3 varchar2(35 char);
        pc_bc_isim_adres_1 varchar2(35 char);
        pc_bc_isim_adres_2 varchar2(35 char);
        pc_bc_isim_adres_3 varchar2(35 char);
        pc_ri_isim_1 varchar2(35 char);
        pc_ri_isim_2 varchar2(35 char);
        pc_ri_isim_3 varchar2(35 char);
        ln_tahsil_tutari number;
        ln_bdsk          number;
        ln_net_transfer_tutar  number:=0;
        pc_ri_1 varchar2(35 char);
        pc_ri_2 varchar2(35 char);
        pc_ri_3 varchar2(35 char);
        pc_ri_4 varchar2(35 char);

        ps_mesaj_kodu     varchar2(5):='103';
        ls_sonuc varchar2(2000);
        ln_kur number;
        ln_bloke_tutar number;
        ln_count number:=0;
        ln_charge_amount number := to_number(pn_charge_amount,'999999.9999');
        ln_correspondent_charge number := 0;
        ps_paymentcode     varchar2(6):='040302';

        ln_musteri_tipi number:=0;
        ls_address varchar2(2000):='';
        ls_bc_address varchar2(2000):='';
        ls_aciklama varchar2(2000);
        ls_message_type varchar2(10):='';
        ls_message_103 varchar2(1):='E';
        ls_message_202 varchar2(1):='E';
        ls_swiftcode varchar2(20) := ps_swiftcode;
        ls_corres varchar2(20):='';
        ls_corres_bic varchar2(20):='';
        ls_ii_bic  varchar2(11):='';

        ls_bankname varchar2(50):=ps_bankname;
        ls_72 varchar2(10):='';
        ls_telpass varchar2(35):=ps_telpass;
        ls_recdesc varchar2(40) := ps_recdesc;
        ls_rec     varchar2(3):='REC';
        ls_recvisite varchar2(3):=ps_recvisite;
        ls_awi_bic  varchar2(15);
        ls_cityname varchar2(30):=ps_cityname;

        ls_commaccount varchar2(30):=pn_commaccount;

        ls_user_name   varchar2(100):='CINT_CALLER';
        ls_branch_no   varchar2(3):='010';
        ln_sicil_no    number:=0;
        ls_related_ref cbs_yphavale_giden_acilis.related_reference%type := null;
        ls_senders_dvz   cbs_yphavale_giden_acilis.senders_dvz%type;
        ls_senders_charges cbs_yphavale_giden_acilis.senders_charges%type;

        ln_swttrnpf_sasrn number;

        ls_cia_doviz cbs_yphavale_giden_acilis.cia_doviz%type;
        ln_cia_tutar cbs_yphavale_giden_acilis.cia_tutar%type;

        ln_staff_count number;
        ln_insider_count number;

        ps_iibic           varchar2(15);
        notenoughbalance    exception; --ernestk 24092014 cqdb00001011 exception when balance is not enough

        pn_client_name_from varchar2(200);
        
        ln_paymentcodeben_index number:= 7;
        ps_paymentcodeben varchar2(17); --Bakdoolot IB-174 added ps_paymentcodeben 30.05.22
        ln_tr_amount number := 0;--AndreiD CBS-868
        ln_eqv_amount number;--AndreiD CBS-868
begin

        select instr(pn_paymentno, '#') into ln_paymentcodeben_index FROM dual;
        if ln_paymentcodeben_index=4 then
            select concat('/BENEFRES/AE//', substr(pn_paymentno,1,3)) into ps_paymentcodeben from dual;
            select substr(pn_paymentno,5,6) into ps_paymentcode from dual;
        else
            select substr(pn_paymentno,1,6) into ps_paymentcode from dual;
        end if;  --Bakdoolot IB-174 30.05.22
        
        pn_islem_no:=pkg_tx.islem_no_al;
        pn_islem_kod := '4003';
        pc_modul_tur_kod:='FCTRANSFER';
        pc_urun_tur_kod:='OUTGOING';


        ln_tutar:= to_number(replace(pd_amount,',',''),'99999999999.99');

        ps_iibic := nvl(pkg_message.split(ps_muhabirmasraf,'###',2),'');

        if (nvl(length(trim(substr(ls_cityname,1,25))),0)>0) then ls_72:='ACC'; end if;

        if (pkg_message.split(ps_muhabirmasraf,'###',0) = 'N') then
            pc_urun_sinif_kod:=upper('OUR ' || pkg_message.split(ps_muhabirmasraf,'###',1) || ' ' || pd_currency);
        else
            pc_urun_sinif_kod:=upper('BEN ' || pkg_message.split(ps_muhabirmasraf,'###',1) || ' ' || pd_currency);
        end if;

        -- THIS PART OF CODE FOR STAFF COMMISSION
        select count(*) into ln_staff_count
        from cbs_musteri
        where musteri_no = pn_musteri_numara
        and personel_sicil_no is not null;

        select count(*) into ln_insider_count
        from corpint.tbl_swift_insiders
        where person_id in (select person_id from corpint.tbl_person where customer_id=pn_musteri_numara);

        if (ln_staff_count > 0) and (ln_insider_count = 0) then
            pc_urun_sinif_kod := 'STAFF SWIFT';
        end if;



           
       
        
        /*BOM  CBS-868 AndreiD*/
        
        pkg_parametre.deger('COMM_TR', ln_tr_amount);
        ln_eqv_amount := Pkg_Kur.doviz_doviz_karsilik(pc_doviz_kod,'USD', NULL,ln_tutar,1,NULL,NULL,'O','A');
        
        
        log_at('tr_help1',1,ln_tr_amount||' '|| ln_eqv_amount);
                                
        IF ps_ulkekodu = 'TR' AND ln_eqv_amount <= ln_tr_amount  AND ln_tr_amount <> 0 THEN
           ln_charge_amount:=0;
         
        log_at('tr_help1',2,ln_tr_amount);    
        ELSE
        ln_charge_amount  :=pkg_aps.chargeautocalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                   ln_tutar, ls_branch_no, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, null);   
             log_at('tr_help1',3,ln_charge_amount);                              
        END IF;
        /*EOM  CBS-868 AndreiD*/                         
                                   
                                   
        -----------------------------------------
        --B-O-M ernestk 29042014 cqdb00001011 check balance with commission
        if pkg_hesap.kullanilabilir_bakiye_al(pc_hesap_numara) < (ln_tutar + ln_charge_amount) then
            raise notenoughbalance;
        end if;
        --E-O-M ernestk 29042014 cqdb00001011 check balance with commission

        ls_referans:=to_char(pd_bugun,'YY')||'.'||ps_bolum_kodu||'.'||'OMT'||'.'|| lpad(pkg_genel.genel_kod_al('YPHAVALE.GIDEN'||to_char(pd_bugun,'YY')||ps_bolum_kodu),5,'0');
        ps_net_brut := pkg_message.split(ps_muhabirmasraf,'###',0);

        --NurmilaZ 18012022
        if pkg_musteri.Sf_Musteri_Eng_Adi(to_number(pn_musteri_numara)) is null then
           pc_oc_isim_adres_1 := substr(pkg_report4.cyr2lat(pkg_musteri.sf_musteri_adi(to_number(pn_musteri_numara))),0,33);
        else
           pc_oc_isim_adres_1 := substr(pkg_musteri.Sf_Musteri_Eng_Adi(to_number(pn_musteri_numara)),0,33);
        end if;
        --NurmilaZ 18012022

        pc_oc_isim_adres_2 := substr(pkg_report4.cyr2lat(pkg_musteri.sf_adres_al(to_number(pn_musteri_numara))),0,33);
        pc_oc_isim_adres_3 := substr(pkg_report4.cyr2lat(pkg_musteri.sf_adres_al(to_number(pn_musteri_numara))),33,33);
        pc_ri_isim_1 := substr(upper(pkg_report4.cyr2lat(ps_aciklama)),1,33);
        pc_ri_isim_2 := substr(upper(pkg_report4.cyr2lat(ps_aciklama)),34,33);
        pc_ri_isim_3 := substr(upper(pkg_report4.cyr2lat(ps_aciklama)),67,33);
        pc_bc_isim_adres_1 := substr(ls_telpass||' '||p_payeeaddress,1,33);
        pc_bc_isim_adres_2 := substr(ls_telpass||' '||p_payeeaddress,34,33);
        pc_bc_isim_adres_3 := substr(ls_telpass||' '||p_payeeaddress,67,33);
        --pc_ri_1 := SUBSTR(UPPER(pkg_report4.cyr2lat(ps_aciklama)),0,33);
        --pc_ri_2 := SUBSTR(UPPER(pkg_report4.cyr2lat(ps_aciklama)),33,33);
        --pc_ri_3 := SUBSTR(UPPER(pkg_report4.cyr2lat(ps_aciklama)),66,33);
        pc_ri_1 := substr( upper(ps_aciklama || ' ' || ls_recdesc ),1,33);
        pc_ri_2 := substr( upper(ps_aciklama || ' ' ||  ls_recdesc ),34,33);
        pc_ri_3 := substr( upper(ps_aciklama || ' ' ||  ls_recdesc ),67,33);
        pc_ri_4 := substr( upper(ps_aciklama || ' ' ||  ls_recdesc ),100,33);

        ln_tahsil_tutari := pkg_kur.doviz_doviz_karsilik (ps_transfer_doviz,pc_tahsil_doviz,null,ln_tutar,1,null, null,'O', 'S');
        ln_bdsk:=pkg_kur.doviz_doviz_karsilik (ps_transfer_doviz,pkg_genel.lc_al,null,1,1,null, null,'O', 'S');
        pn_muhabir_hesap_no:=pkg_soa_inquiry.getcorrespondentaccountno(pd_currency);
        pn_muhabir_musteri_no:=pkg_hesap.hesaptanmusterinoal(pn_muhabir_hesap_no);

        pn_client_name_from:=upper(pkg_musteri.Sf_Musteri_Eng_Adi(to_number(pn_musteri_numara)));

        if pn_client_name_from is null or pn_client_name_from = '' then
            pn_client_name_from := upper(pkg_report4.cyr2lat(pkg_musteri.sf_musteri_adi(to_number(pn_musteri_numara))));
        end if;

        ls_aciklama:='TRANSFER FROM '|| pn_client_name_from ||' TO '||upper(pkg_report4.cyr2lat(p_payeename));

        --ls_aciklama:='TRANSFER FROM '||upper(pkg_report4.cyr2lat(pkg_musteri.sf_musteri_adi(to_number(pn_musteri_numara))))||' TO '||upper(pkg_report4.cyr2lat(p_payeename));

        ps_muhabir_bic:=pkg_swift.getmubabirbiccode(pn_muhabir_musteri_no);

        select count(*)
        into ln_count
        from cbs_bic_kodlari
        where bic_kodu=ps_swiftcode
        and substr(bic_kodu,1,4) in (select substr(sbkekd,1,4) from swtbkepf);

        if (ln_count>0) then
            ls_message_type := '103';
            ls_message_202 := 'H';
            ls_corres:='A';
            ls_corres_bic:=ps_muhabir_bic;
            ls_awi_bic:=ps_swiftcode;
        else
            ls_message_type := '202_103';
            ls_message_202 := 'H';
            ls_swiftcode:=ps_muhabir_bic;
            ls_corres:='';
            ls_corres_bic:='';
            if length(ps_swiftcode) = 11 then
               ls_awi_bic:=substr(ps_swiftcode,1,length(ps_swiftcode)-3)||'XXX';
            else
               ls_awi_bic:= ps_swiftcode ||'XXX';
            end if;

            ls_related_ref:=null;--'NONREF';
        end if;

        if length(ps_iibic) = 8 then
           ls_ii_bic :=ps_iibic ||'XXX';
        end if;


        if (upper(ps_ulkekodu) = 'KZ' ) then
            ps_ist_kod := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||
                             pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||'19';
        else
            ps_ist_kod := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||
                             pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||ps_statcode;
        end if;

        if ps_net_brut = 'N' then
            ln_net_transfer_tutar := ln_tutar;
            ps_detail_charges := 'OUR';
        else
            ln_net_transfer_tutar := ln_tutar;
            ps_detail_charges := 'BEN';
            ls_senders_charges:=0;
            ls_senders_dvz:=ps_transfer_doviz;

            ls_cia_doviz:=ps_transfer_doviz;
            ln_cia_tutar:=ln_net_transfer_tutar;
        end if;

        ln_musteri_tipi := pkg_musteri.sf_musteri_tipi_al(pn_musteri_numara);

        ls_address := pkg_report4.cyr2lat(pc_oc_isim_adres_1);
        pc_oc_isim_adres_1 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_oc_isim_adres_2 := upper(substr(ls_address,35)) || ' ' || pc_oc_isim_adres_2; end if;

        ls_address := pkg_report4.cyr2lat(pc_oc_isim_adres_2);
        pc_oc_isim_adres_2 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_oc_isim_adres_3 := upper(substr(ls_address,35)) || ' ' || pc_oc_isim_adres_3; end if;

        ls_address := pkg_report4.cyr2lat(pc_oc_isim_adres_3);
        pc_oc_isim_adres_3 := upper(substr(ls_address,1,34));
------------------------------------------------------------------
        ls_address := pkg_report4.cyr2lat(pc_bc_isim_adres_1);

        pc_bc_isim_adres_1 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_bc_isim_adres_2 := upper(substr(ls_address,35)) || ' ' || pc_bc_isim_adres_2; end if;

        ls_address := pkg_report4.cyr2lat(pc_bc_isim_adres_2);
        pc_bc_isim_adres_2 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_bc_isim_adres_3 := upper(substr(ls_address,35)) || ' ' || pc_bc_isim_adres_3; end if;

        ls_address := pkg_report4.cyr2lat(pc_bc_isim_adres_3);
        pc_bc_isim_adres_3 := upper(substr(ls_address,1,34));

        if ((length(pc_bc_isim_adres_3))<35)and(length(pc_bc_isim_adres_2)>0) then  pc_bc_isim_adres_3 := substr(pc_bc_isim_adres_3,1,34);
        elsif ((length(pc_bc_isim_adres_2))<35)and(length(pc_bc_isim_adres_1)>0) then  pc_bc_isim_adres_2 := substr(pc_bc_isim_adres_2,1,34);
        else pc_bc_isim_adres_1 := substr(pc_bc_isim_adres_1,1,34); end if;
        
        pc_oc_isim_adres_1 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_oc_isim_adres_1, '-');
        pc_oc_isim_adres_2 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_oc_isim_adres_2, '-');
        pc_oc_isim_adres_3 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_oc_isim_adres_3, '-');
        
        pc_ri_1 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_1, '-');
        pc_ri_2 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_2, '-');
        pc_ri_3 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_3, '-');
        pc_ri_4 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_4, '-'); --Bakdoolot IB-177 27.06.2022

         insert into cbs_yphavale_giden_acilis
        (tx_no, referans, gonderen_sube, musteri_no, modul_tur_kod,
         urun_tur_kod, urun_sinif_kod, ulke_kodu, cek_ile_f, cek_no,
         transfer_doviz_kodu, tutar, net_brut, tahsil_doviz_kodu, kur,
         parite, carpma_bolme, tahsil_tutari, net_transfer_tutari, valor_tarihi,
         transfer_sekli, borclu_hesap_no, borclu_dk_no, muh_bank_musteri_no, muh_bank_hesap_no,
         istatistik_kodu, aciklama, masraf_komisyon_hesap_no, boc, oc,
         bc, doc, awi, oc_hesap_no_k, durum_kodu,
         acilis_tarihi, masraf_toplami, related_reference, prefix_istatistik_kod, swift_tutari,
         rg_mesaj_olustur, alici_bic, muhabir_bic, mesaj_103, mesaj_202,
         oc_isim_adres_1, oc_isim_adres_2, oc_isim_adres_3, bc_hesap_no_n, bc_isim_adres_1,
         bc_isim_adres_2, bc_isim_adres_3, valor_tarihi_ch, tutar_ch, bc_hesap_no_ch,
         bi, ii_bic,awi_bic, sc, sc_bic, awi_location,
         ri_1, ri_2, ri_3, ri_4, ii,
         senders_charges, senders_dvz, pre_stri_1, post_stri_1, cia_doviz, cia_tutar, RR_1) --Bakdoolot IB-174 added RR_1 30.05.22
        values
        (pn_islem_no, ls_referans, ps_bolum_kodu, pn_musteri_numara, pc_modul_tur_kod,
         pc_urun_tur_kod, pc_urun_sinif_kod, ps_ulkekodu, 'H', null,
         ps_transfer_doviz, ln_tutar, 'N', pc_tahsil_doviz, null,
         null, null, null, ln_net_transfer_tutar, pd_valor_tarihi,
         'M', pc_hesap_numara, null, pn_muhabir_musteri_no, pn_muhabir_hesap_no,
         ps_paymentcode, substr(ls_aciklama,1,80), pn_commaccount, ps_bank_opr_code, ps_ordering_customer,
         ps_ben_customer, ps_detail_charges, ps_acc_ins, pkg_soa_inquiry.Active_external_hesapno_al(pc_hesap_numara), null,
         pd_acilis_tarih, ln_charge_amount + ln_correspondent_charge, ls_related_ref, /*ps_ist_kod*/null, ln_net_transfer_tutar,
         'E', ps_muhabir_bic/*SUBSTR(ls_swiftcode,1,LENGTH(ls_swiftcode)-3)||'XXX'*/, ps_muhabir_bic, ls_message_103, ls_message_202,
         pc_oc_isim_adres_1, pc_oc_isim_adres_2, pc_oc_isim_adres_3, ps_payeeacc, substr(p_payeename,1,33),
         pc_bc_isim_adres_1, pc_bc_isim_adres_2, pd_valor_tarihi, ln_tutar, /*ps_payeeacc*/null,
         /*'B'*/null, ls_ii_bic, ls_awi_bic, /*ls_corres*/null, /*SUBSTR(ls_corres_bic,1,11)*/null, null,
         pc_ri_1, pc_ri_2, pc_ri_3, pc_ri_4, 'A',
         ls_senders_charges, ls_senders_dvz, ls_72, trim(substr(ls_cityname,1,25)), ls_cia_doviz, ln_cia_tutar, ps_paymentcodeben); --Bakdoolot IB-174 added ps_paymentcodeben 30.05.22

         open pc_ref for
            select to_char(pn_islem_no),ls_referans islem_no from dual;

            pkg_baglam.yarat(pc_bolum_kodu,to_number(pc_rol));

            pkg_int_api.create_transaction(pn_islem_no, pn_islem_kod,
                                           pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                           pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                                           pc_kasa_kod,null);

            commit;

        pkg_swift.sp_mesaj_sil(pn_islem_no);

        pkg_swift.mesaj_olustur(4003,pn_islem_no,1,'103',/*ls_message_type*/null,null,null,null,ls_sonuc);

        if (ls_sonuc = 'SKYACK') then
            ls_returncode:='000';

            select musteri_tipi_kod into ln_staff_count
            from cbs_musteri
            where musteri_no = pn_musteri_numara;

            if (ln_staff_count = 1) then
                pkg_int_api.process_transaction(pn_islem_no);
            end if;
        else
            ls_returncode:='777';

            if (ls_sonuc like '%BICNACK%') then
                ls_returncode:='761';
            elsif (ls_sonuc like '%SKYBLCK') then
                ls_returncode:='762';
            elsif (ls_sonuc like '%SKYE01%' or ls_sonuc like '%SKYE02%' or ls_sonuc like '%SKYE03%') then
                ls_returncode:='763';
            elsif (ls_sonuc like '%SKYE04%') then
                ls_returncode:='764';
            elsif (ls_sonuc like '%SKYE05%') then
                ls_returncode:='765';
            elsif (ls_sonuc like '%SKYE06%') then
                ls_returncode:='766';
            elsif (ls_sonuc like '%SKYE07%') then
                ls_returncode:='767';
            elsif (ls_sonuc like '%SKYE08%' or ls_sonuc like '%SKYE09%') then
                ls_returncode:='768';
            elsif (ls_sonuc like '%SKYE10%') then
                ls_returncode:='769';
            elsif (ls_sonuc like '%SKYE11%') then
                ls_returncode:='770';
            elsif (ls_sonuc like '%SKYE12%') then
                ls_returncode:='771';
            elsif (ls_sonuc like '%SKYE13%') then
                ls_returncode:='772';
            elsif (ls_sonuc like '%SKYE14%' or ls_sonuc like '%SKYE15%') then
                ls_returncode:='773';
            elsif (ls_sonuc like '%SKYE14 (57A)%') then
                ls_returncode:='774';
            elsif (ls_sonuc like '%SKYNACK (59N)%') then
                ls_returncode:='775';
            end if;
            select sasrn into ln_swttrnpf_sasrn
            from swttrnpf
            where tx_no = pn_islem_no
            and rownum=1;
            for i in (select araerr from swtarapf_cbs
                      where arasrn = ln_swttrnpf_sasrn) loop
                if i.araerr is not null then
                    log_at('MAKE_SWIFT','SKY_ERROR: ' || ls_sonuc,substr(i.araerr,1,2000));
                end if;
            end loop;

            --ROLLBACK;
        end if;

        commit;
        return ls_returncode;
exception
       --B-O-M ernestk 29042014 cqdb00001011 if balance is not engough
       when notenoughbalance then
            rollback;
            ls_returncode := '502';
            log_at('Bakiye yeterli degil',pc_hesap_numara,pkg_hesap.kullanilabilir_bakiye_al(pc_hesap_numara), ln_tutar + ln_charge_amount);
            open pc_ref for select to_char(pn_islem_no) islem_no from dual;
            return ls_returncode;
       --E-O-M ernestk 29042014 cqdb00001011 if balance is not engough
       when others then
            ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
            log_at('MAKE_SWIFT',sqlcode||':'||sqlerrm,ls_returncode||'-'||pn_islem_no);
            rollback;

            select count(*)
            into ln_count
            from cbs_yphavale_giden_acilis t
            where t.tx_no = pn_islem_no;

            if (ln_count > 0) then
                  delete from cbs_yphavale_giden_acilis t
                  where t.tx_no = pn_islem_no;
            end if;

            select count(*)
            into ln_count
            from cbs_islem t
            where t.numara = pn_islem_no;

            if (ln_count > 0) then
                  delete from cbs_islem t
                  where t.numara = pn_islem_no;
            end if;

            commit; --2011.07.26

            open pc_ref for
             select to_char(pn_islem_no) islem_no from dual;
            raise_application_error(-20100,sqlerrm);
            return ls_returncode;
end;

/******************************************************************************
   NAME        : SendEmailMessage
  Prepared By : Almas Nurhozhaev
   Date        : 21.01.2008
   Purpose     : Send Email Message
******************************************************************************/
function sendemailmessage(ps_sender  in varchar2,
                        ps_recipient  in varchar2,
                        ps_subject  in varchar2,
                        ps_body_content in varchar2,
                        pc_ref out cursorreferencetype) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_musterino  number;

    ls_recipient varchar2(200):='';
    ls_subject varchar2(200):='';

begin
    if (ps_recipient='') then ls_recipient:='info@demirbank.kg'; else ls_recipient:=ps_recipient; end if;
    if (ps_subject='') then ls_subject:='For IT Group'; else ls_subject:=ps_subject; end if;

    pkg_email.addtoemailqueue('INTCONTACTUS','50',ps_sender,ls_recipient,ls_subject,ps_body_content,'HTML');

    open pc_ref for  select 'OK'  from dual;

    return ls_returncode;
end;
/******************************************************************************
   NAME        : VirtualCardRequest
   Prepared By : Almas Nurhozhaev
   Date        : 13.02.2011
   Purpose     : Virtual Card Transactions
******************************************************************************/
function virtualcardrequest(ps_optioncd in varchar2,
                            ps_pseudopan in varchar2,
                            ps_limitamount in varchar2,
                            ps_suppcashlimitamount in varchar2,
                            pc_ref out cursorreferencetype) return varchar2 is
    ls_returncode     varchar2(3):='000';

    serviceurl varchar2(2000);
    soapaction varchar2(2000);
    namespace varchar2(2000);
    methodname varchar2(2000);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ld_starttime date;
    ld_endtime date;

    rcode  varchar2(2000) := '0';
    rdesc  varchar2(2000) := '0';
    virtualcardno    varchar2 (2000) := ps_pseudopan; --CQ522 set default virtual card no 13.02.2014 almasn
    virtualcardcvc2  varchar2(2000) := '0';
    virtualcardexpirydateymd  varchar2(2000) := '0';

    --WS_SERVICE_URL VARCHAR2(200)  := 'http://bstest/service/KirgizDemirWs.asmx';
    ws_service_url varchar2(200)  := 'http://10.0.0.16/virtualcard/kirgizdemirws.asmx';

    ls_sourecode varchar2(10):='10';
    ls_usercode  varchar2(10):='IBANKING';
    ls_cardstatus varchar2(10):='S';
    ls_cardsubstatus varchar2(10):='BR';
begin
    pkg_parametre.deger('WS_VIRTUAL_CARD_URL', ws_service_url); --AlmasN virtual card system server was parametrized

    ld_starttime:=sysdate;

    open pc_ref for select sysdate from dual;

    serviceurl := ws_service_url;

    if (ps_optioncd = 'CREATE') then

        namespace := 'http://www.banksoft.com.tr';
        methodname := 'VirtualCardReq';
        soapaction := namespace || '/KirgizDemirWS/' || methodname;
        namespace := 'xmlns="' || namespace || '"';

        req := pkg_soap.new_request(methodname, namespace);

        pkg_soap.add_parameter(
        req, 'VirtualCardParams', null,
        '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCreateRequestType">' || ps_pseudopan || '</PSEUDOPAN>' ||
        '<SCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCreateRequestType">' || ls_sourecode || '</SCODE>' ||
        '<UCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCreateRequestType">' || ls_usercode || '</UCODE>');

        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);

        result := resp.doc.getclobval();
        result:= replace(result,' xmlns="http://www.banksoft.com.tr"','');
        result:= replace(result,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCreateResponseType"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'VirtualCardReqResponse/VirtualCardReqResult');

        for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1 loop
            l_n := dbms_xmldom.item(l_nl, cur_emp);

            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueof(l_n,'RCODE/text()',rcode);
            dbms_xslprocessor.valueof(l_n,'RDESC/text()',rdesc);
            dbms_xslprocessor.valueof(l_n,'VIRTUALPSEUDOPAN/text()',virtualcardno);
            dbms_xslprocessor.valueof(l_n,'VIRTUALCARDCVC2/text()',virtualcardcvc2);
            dbms_xslprocessor.valueof(l_n,'VIRTUALCARDEXPIRYDATEYMD/text()',virtualcardexpirydateymd);
        end loop;

    elsif (ps_optioncd = 'LIMIT_UPDATE') then

        namespace := 'http://www.banksoft.com.tr';
        methodname := 'VirtualCardLimitUpdateReq';
        soapaction := namespace || '/KirgizDemirWS/' || methodname;
        namespace := 'xmlns="' || namespace || '"';

        req := pkg_soap.new_request(methodname, namespace);

        pkg_soap.add_parameter(
        req, 'VirtualCardParams', null,
        '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardLimitUpdateRequestType">' || ps_pseudopan || '</PSEUDOPAN>' ||
        '<SUPPLIMITAMOUNT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardLimitUpdateRequestType">' || ps_limitamount || '</SUPPLIMITAMOUNT>' ||
        '<SUPPCASHLIMITAMOUNT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardLimitUpdateRequestType">' || ps_suppcashlimitamount || '</SUPPCASHLIMITAMOUNT>' ||
        '<SCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardLimitUpdateRequestType">' || ls_sourecode || '</SCODE>' ||
        '<UCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardLimitUpdateRequestType">' || ls_usercode || '</UCODE>');

        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);

        result := resp.doc.getclobval();
        result:= replace(result,' xmlns="http://www.banksoft.com.tr"','');
        result:= replace(result,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardLimitUpdateResponseType"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'VirtualCardLimitUpdateReqResponse/VirtualCardLimitUpdateReqResult');

        for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1 loop
            l_n := dbms_xmldom.item(l_nl, cur_emp);

            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueof(l_n,'RCODE/text()',rcode);
            dbms_xslprocessor.valueof(l_n,'RDESC/text()',rdesc);
        end loop;
    elsif (ps_optioncd = 'CANCEL') then

        namespace := 'http://www.banksoft.com.tr';
        methodname := 'VirtualCardCancelReq';
        soapaction := namespace || '/KirgizDemirWS/' || methodname;
        namespace := 'xmlns="' || namespace || '"';

        req := pkg_soap.new_request(methodname, namespace);

        pkg_soap.add_parameter(
        req, 'VirtualCardParams', null,
        '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCancelRequestType">' || ps_pseudopan || '</PSEUDOPAN>' ||
        '<CARDSTATUS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCancelRequestType">' || ls_cardstatus || '</CARDSTATUS>' ||
        '<CARDSUBSTATUS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCancelRequestType">' || ls_cardsubstatus || '</CARDSUBSTATUS>' ||
        '<SCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCancelRequestType">' || ls_sourecode || '</SCODE>' ||
        '<UCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCancelRequestType">' || ls_usercode || '</UCODE>');

        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);

        result := resp.doc.getclobval();
        result:= replace(result,' xmlns="http://www.banksoft.com.tr"','');
        result:= replace(result,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardCancelResponseType"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'VirtualCardCancelReqResponse/VirtualCardCancelReqResult');

        for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1 loop
            l_n := dbms_xmldom.item(l_nl, cur_emp);

            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueof(l_n,'RCODE/text()',rcode);
            dbms_xslprocessor.valueof(l_n,'RDESC/text()',rdesc);
        end loop;

      elsif (ps_optioncd = 'VCARDPROLONG') then --CQ522 virtual card prolongation logic BEGIN 13.02.2014 almasn
         namespace := 'http://www.banksoft.com.tr';
         methodname := 'VirtualCardExtendExpDate';
         soapaction := namespace || '/KirgizDemirWS/' || methodname;
         namespace := 'xmlns="' || namespace || '"';

         req := pkg_soap.new_request (methodname, namespace);

         pkg_soap.add_parameter(req, 'VirtualCardParams', null,
            '<VIRTUALPSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardExtendExpDateRequestType">' || ps_pseudopan || '</VIRTUALPSEUDOPAN>' ||
            '<SCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardExtendExpDateRequestType">' || ls_sourecode || '</SCODE>' ||
            '<UCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardExtendExpDateRequestType">' || ls_usercode || '</UCODE>');

         resp := pkg_soap.invoke_utf8_v11 (req, serviceurl, soapaction);

         result := resp.doc.getclobval ();
         result := replace (result, ' xmlns="http://www.banksoft.com.tr"', '');
         result := replace (result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/VirtualCardExtendExpDateResponseType"', '');

         l_parser := dbms_xmlparser.newparser;
         dbms_xmlparser.parseclob (l_parser, result);
         l_doc := dbms_xmlparser.getdocument (l_parser);
         l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode (l_doc),'VirtualCardExtendExpDateResponse/VirtualCardExtendExpDateResult');

         for cur_emp in 0 .. dbms_xmldom.getlength (l_nl) - 1
         loop
            l_n := dbms_xmldom.item (l_nl, cur_emp);

            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueof (l_n, 'RCODE/text()', rcode);
            dbms_xslprocessor.valueof (l_n, 'RDESC/text()', rdesc);
            dbms_xslprocessor.valueof (l_n, 'VIRTUALCARDCVC2/text()', virtualcardcvc2);
            dbms_xslprocessor.valueof (l_n, 'VIRTUALCARDEXPIRYDATEYMD/text()', virtualcardexpirydateymd);
         end loop;
      end if; --CQ522 virtual card prolongation logic END 13.02.2014 almasn


    if (rcode = '003') then
        ls_returncode := '680'; --Customer has a card with the same product
    elsif (rcode = '001') then
        ls_returncode := '681'; --Customer could not be found
    elsif (rcode = '002') then
        ls_returncode := '683';    --There is no valide primary card is defined for this virtual card. Card No:
    elsif (rcode = '004') then --CQ522 virtual card error handler 13.02.2014 almasn
        ls_returncode := '684';    --Virtual Card Status is not Valid. Card Status:
    elsif (rcode = '005') then --CQ522 virtual card error handler 13.02.2014 almasn
        ls_returncode := '685';    --Primary Card Status is not Valid. Card Status:
    elsif (rcode = '006') then --CQ522 virtual card error handler 13.02.2014 almasn
        ls_returncode := '686';    --Virtual Card expire date is already later than primary card exp date. V. Card Exp date:
    elsif (rcode <> '000') then
        ls_returncode := '682'; --Other virtual card error
    end if;

    open pc_ref for
        select rcode, rdesc, virtualcardno, virtualcardcvc2, virtualcardexpirydateymd from dual;

    insert into cbs.cbs_virtual_card_tran_log
    (log_no, tran_type, card_no, limit_amount, request_xml, response_xml)
    values
    (corpint.pkg_common.getsequenceid('pqVCARDLOG'), ps_optioncd, ps_pseudopan, ps_limitamount, req.body, resp.doc.getclobval());

    ld_endtime:=sysdate;

    return ls_returncode;
exception
    when others then
        log_at('VirtualCard:'||ps_optioncd||'::'||to_char(ld_endtime)||'-'||to_char(ld_starttime), sqlerrm);
        return ls_returncode;
end;
/******************************************************************************
   NAME        : CCDebtPayment
   Prepared By :  Nurhat UCA
   Date        : 17.12.2012
   Purpose     : Credit Card Debt Payment
******************************************************************************/
function ccdebtpayment(     ps_cardno in varchar2,
                            ps_amount in varchar2,
                            ps_currency in varchar2,
                            ps_branchcode in varchar2, --4 digit branch code, left padded with 0
                            ps_trandate in varchar2, --YYYYMMDD
                            ps_valdate in varchar2 ,--YYYYMMDD
                            ps_trandesc in varchar2 ,--YYYYMMDD
                            ps_ficheno in varchar2,
                            ps_fichedate in varchar2,--YYYYMMDD
                            ps_reconcilation_no  in varchar2,
                            ps_pseudopan in varchar2) return varchar2 is -- AdiletK CQ5541 PCI DSS pseudopan
    ls_returncode     varchar2(2000):='000';

    serviceurl varchar2(2000);
    soapaction varchar2(2000);
    namespace varchar2(2000);
    methodname varchar2(2000);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ld_starttime date;
    ld_endtime date;

    rcode  varchar2(3) := '0';
    rdesc  varchar2(40) := '0';

    ws_service_url varchar2(200)  := 'http://10.0.0.16/virtualcard/kirgizdemirws.asmx';
    ls_scode varchar2(10):='10'; --  02: Branch 10: Internet 11: Call Center
    ls_ucode  varchar2(10):='IBANKING';
    ls_msgcode varchar2(1):='0'; --Message Code    0: odeme, 1: iptal
    ls_trncur varchar2(3);--417 for KGS 840 for USD
    ls_trntype varchar2(2);-- YI: for KGS payment YD: for USD payment
    ls_trnscode varchar2(1):='I';--N: Cash payment from branch H: Payment from account Paymen A: Payment from ATM I:  Payment from Internet C: Payment from call center


    invalid_currency  exception;
    /*
    DMMDDBBBBMMMMMMM
    D: Direction 2
    MM: Month
    DD: Day
    BBBB: BranchCode
    MMMMMMM:  Reconcilation number When MSGCODE is 0, this value must be unique, When MSGCODE is 1, this value must be same as original request transaction.
    */
    ls_reference varchar(16);
    ls_branch varchar(4);
    ls_trandesc varchar(15) := lpad(ps_trandesc, 15, ' ');
    ls_ficheno varchar(6) := lpad(ps_ficheno, 6, '0');
    ls_trandate date :=to_date(ps_trandate,'YYYYMMDD');
    ls_cardno varchar2(30);
begin
    pkg_parametre.deger('WS_DEBT_PAY_CARD_URL', ws_service_url); --AlmasN debt pay card system server was parametrized

    --select SQ_CBS_CCDEBTPAYMENT_RECONCNO.nextval into ls_RECONCILATION_NO from dual;
   ls_branch :=lpad(ps_branchcode, 4, '0');
   ls_reference := '2' || to_char(ls_trandate,'MM') || to_char(ls_trandate,'DD') || ls_branch || lpad(ps_reconcilation_no, 7, '0');

    if ps_currency = 'KGS' then
        ls_trncur := '417';
        ls_trntype := 'YI';
    elsif  ps_currency = 'USD' then
        ls_trncur := '840';
        ls_trntype := 'YD';
    else
        --raise error
        raise invalid_currency;
    end if;

    if ps_pseudopan is null or ps_pseudopan = '' then -- AdiletK CQ5541 PCI DSS pseudopan
        ls_cardno := ps_cardno;
    end if;

    ld_starttime:=sysdate;

    serviceurl := ws_service_url;


    namespace := 'http://www.banksoft.com.tr';
    methodname := 'Payment';
    soapaction := namespace || '/KirgizDemirWS/' || methodname;
    namespace := 'xmlns="' || namespace || '"';

    req := pkg_soap.new_request(methodname, namespace);

    pkg_soap.add_parameter(
    req, 'PT', null,
        '<MSGCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_msgcode || '</MSGCODE>' ||
        '<CARDNUMBER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_cardno || '</CARDNUMBER>' ||
        '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_pseudopan || '</PSEUDOPAN>' || -- AdiletK CQ5541 PCI DSS pseudopan
        '<BRANCH xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_branch || '</BRANCH>' ||
        '<TRNDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_trandate || '</TRNDATE>' ||
        '<VALDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_valdate || '</VALDATE>' ||
        '<TRNCUR xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trncur || '</TRNCUR>' ||
        '<TRNAMOUNT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_amount || '</TRNAMOUNT>' ||
        '<TRNSCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trnscode || '</TRNSCODE>' ||
        '<TRNTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trntype || '</TRNTYPE>' ||
        '<REFERANCE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_reference || '</REFERANCE>' ||
        '<UCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_ucode || '</UCODE>' ||
        '<SCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_scode || '</SCODE>' ||
        '<TRNDESC xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trandesc || '</TRNDESC>' ||
        '<FICHENUMBER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_ficheno || '</FICHENUMBER>' ||
        '<FICHEDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_fichedate || '</FICHEDATE>'); 
    resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
 
    result := resp.doc.getclobval(); 
    result:= replace(result,' xmlns="http://www.banksoft.com.tr"','');
    result:= replace(result,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"','');

    l_parser := dbms_xmlparser.newparser;
    dbms_xmlparser.parseclob(l_parser, result);
    l_doc := dbms_xmlparser.getdocument(l_parser);
    l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'PaymentResponse/PaymentResult');

    for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1 loop
        l_n := dbms_xmldom.item(l_nl, cur_emp);
        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'RCODE/text()',rcode);
        dbms_xslprocessor.valueof(l_n,'RDESC/text()',rdesc);
    end loop;
    ld_endtime:=sysdate;
   
   log_at('card payment', rcode, rdesc);

    if (rcode <> '000') then
       log_at('CCDebtPayment',to_char(ld_endtime)||' '||to_char(ld_starttime)||' '|| ls_reference , rcode||' '||rdesc);
       ls_returncode :=rcode||' '||rdesc;
    else
       ls_returncode :=rcode;
    end if;
    return ls_returncode;
exception
    when others then
        ls_returncode :='999';
        log_at('CCDebtPayment',to_char(ld_endtime)||' '||to_char(ld_starttime) ||' '|| ls_reference, rcode||' '||rdesc,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
        return ls_returncode;
end;
/******************************************************************************
   NAME        : sendSMS
   Prepared By : Almas Nurhozhaev
   Date        : 14.02.2011
   Purpose     : Send SMS
******************************************************************************/
function sendsms(ps_option in varchar2,
                 ps_subject in varchar2,
                 ps_message_body in varchar2,
                 ps_mobile_no in varchar2,
                 ps_pwd_id in varchar2,
                 pc_ref out cursorreferencetype) return varchar2 is

    ls_returncode varchar2(3):='000';
    --ws variables
   serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result varchar2(4000 char);

    ls_sessionid varchar2(100);
    ls_result varchar2(100);

    ls_login constant varchar2(10) := 'DEMIRKG';
    ls_password constant varchar2(10) := '123demir';

    gs_bpktran_service_url varchar2(200 char):='http://10.0.0.38/services.demirbank.kg/SmsRestServices.asmx';

    cursor cursor_otp_pwds is
        select * from corpint.tbl_otp_pwds s
        where s.status_cd not like 'sDONE%'
        and s.try > 0;

    row_otp_pwds cursor_otp_pwds%rowtype;

    ls_status_cd varchar2(100) := '';
    ln_pwd_id number := 0;
    ls_tag_name varchar2(50) := '';
begin

    open pc_ref for select '-' from dual;

    if (ps_option = 'SEND_BY_JOB') then

        update corpint.tbl_otp_pwds
        set subject = ps_subject,
            message_body = ps_message_body,
            status_cd = 'sWAIT_01'
        where id = ps_pwd_id;

    elsif (ps_option = 'SEND_FROM_LIST') then

        open cursor_otp_pwds;
        fetch cursor_otp_pwds into row_otp_pwds;
        while  cursor_otp_pwds%found loop

            if (substr(row_otp_pwds.status_cd,1,5) = 'sWAIT') then
                if (row_otp_pwds.status_cd = 'sWAIT_01') then
                    ls_status_cd := 'SEND_DIRECTLY';
                elsif (row_otp_pwds.status_cd = 'sWAIT_02') then
                    ls_status_cd := 'SEND_SURAT_SMS';
                end if;

                ls_returncode := cbs.pkg_soa_transaction.sendsms(ls_status_cd, row_otp_pwds.subject, row_otp_pwds.message_body, row_otp_pwds.mobile_number, row_otp_pwds.id, pc_ref);
            elsif (substr(row_otp_pwds.status_cd,1,8) = 'sSENDING') then
                if (row_otp_pwds.status_cd = 'sSENDING_01') then
                    serviceurl := gs_bpktran_service_url;

                    begin
                        --GET STATUS 1
                        namespace := 'http://services.demirbank.kg/';
                        methodname := 'GetSMSStatus';
                        soapaction := namespace || methodname;
                        namespace := 'xmlns="' || namespace || '"';

                        --create new request
                        req := pkg_soap.new_request(methodname, namespace);

                        --add parameters to request
                        pkg_soap.add_parameter(req, 'sessionId', 'xsd:string', row_otp_pwds.session_id);
                       pkg_soap.add_parameter(req, 'messageId', 'xsd:string', row_otp_pwds.result);

                        --call web service, and get response
                        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
                        result := resp.doc.getstringval();

                        --extract data from xml
                        select xmltype(result).extract('//GetSMSStatusResponse/GetSMSStatusResult/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_0
                        into ls_status_cd
                        from dual;

                    exception
                        when others then
                            if result<>'' then
                               log_at('sendSMS',result);
                            end if;
                            log_at('sendSMS',sqlerrm);
                            ls_status_cd := 99;
                    end;

                    if (ls_status_cd in ('-97','-98','10','11','41','42','46','69','99','255')) then
                        update corpint.tbl_otp_pwds
                        set status_cd = 'sERROR_01',
                            response_xml = nvl(result,response_xml)
                        where id = row_otp_pwds.id;
                    elsif (ls_status_cd in ('-1','0')) then
                        update corpint.tbl_otp_pwds
                        set status_cd = 'sDONE_01',
                            response_xml = nvl(result,response_xml)
                        where id = row_otp_pwds.id;
                    end if;
                elsif (row_otp_pwds.status_cd = 'sSENDING_02') then
                    serviceurl := 'http://10.0.0.138/services.demirbank.kg/SuratSMS.asmx';

                    begin
                        --GET STATUS 2
                        namespace := 'http://services.demirbank.kg/';
                        methodname := 'smsReportDetailedPacket';
                        soapaction := namespace || methodname;
                        namespace := 'xmlns="' || namespace || '"';

                        --create new request
                        req := pkg_soap.new_request(methodname, namespace);

                        --add parameters to request
                        pkg_soap.add_parameter(req, 'packetNumber', 'xsd:string', row_otp_pwds.result);

                        --call web service, and get response
                        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
                        result := resp.doc.getstringval();

                        ls_tag_name := 'MessageStatus';
                        ls_status_cd := substr(result, instr(result,ls_tag_name,1,1)+length(ls_tag_name||'>'), instr(result,'</'||ls_tag_name,1,1)-instr(result,ls_tag_name,1,1)-length(ls_tag_name||'>') );
                    exception
                        when others then
                            result := sqlerrm;
                            ls_status_cd := 1;
                    end;

                    if (ls_status_cd in ('5','4')) then
                        update corpint.tbl_otp_pwds
                        set status_cd = 'sERROR_02',
                            response_xml = nvl(result,response_xml)
                        where id = row_otp_pwds.id;
                    elsif (ls_status_cd in ('3','1')) then
                        update corpint.tbl_otp_pwds
                        set status_cd = 'sDONE_02',
                            response_xml = nvl(result,response_xml)
                        where id = row_otp_pwds.id;
                    end if;

                end if;
            elsif (substr(row_otp_pwds.status_cd,1,6) = 'sERROR') then
                ln_pwd_id := corpint.pkg_common.getsequenceid('pqSMSOTP');

                if (row_otp_pwds.status_cd = 'sERROR_01') then

                    update corpint.tbl_otp_pwds
                    set status_cd = 'sDONE_ERROR_01'
                    where id = row_otp_pwds.id;

                    ls_status_cd := 'SEND_SURAT_SMS';

                    insert into corpint.tbl_otp_pwds
                    (id, pwd_hashed, customer_no, person_id, mobile_number, session_id, result, subject, message_body, status_cd, try)
                    values
                    (ln_pwd_id, row_otp_pwds.pwd_hashed, row_otp_pwds.customer_no, row_otp_pwds.person_id, row_otp_pwds.mobile_number,
                    row_otp_pwds.session_id, row_otp_pwds.result, row_otp_pwds.subject, row_otp_pwds.message_body, 'sSENDING_02', row_otp_pwds.try);

                elsif (row_otp_pwds.status_cd = 'sERROR_02') then
                    update corpint.tbl_otp_pwds
                    set status_cd = 'sDONE_ERROR_02'
                    where id = row_otp_pwds.id;

                    ls_status_cd := 'SEND_DIRECTLY';

                    insert into corpint.tbl_otp_pwds
                    (id, pwd_hashed, customer_no, person_id, mobile_number, session_id, result, subject, message_body, status_cd, try)
                    values
                    (ln_pwd_id, row_otp_pwds.pwd_hashed, row_otp_pwds.customer_no, row_otp_pwds.person_id, row_otp_pwds.mobile_number,
                    row_otp_pwds.session_id, row_otp_pwds.result, row_otp_pwds.subject, row_otp_pwds.message_body, 'sSENDING_01', row_otp_pwds.try);

                end if;

                ls_returncode := cbs.pkg_soa_transaction.sendsms(ls_status_cd, row_otp_pwds.subject, row_otp_pwds.message_body, row_otp_pwds.mobile_number, to_char(ln_pwd_id), pc_ref);
            end if;

            update corpint.tbl_otp_pwds
            set try = try - 1
            where id = row_otp_pwds.id;

            fetch cursor_otp_pwds into row_otp_pwds;
        end loop;
        close cursor_otp_pwds;

    elsif (ps_option = 'SEND_DIRECTLY') then
        ls_status_cd:='sSENDING_01';
        serviceurl := gs_bpktran_service_url;

    --GETTING SESSION ID
        namespace := 'http://services.demirbank.kg/';
        methodname := 'GetSessionId';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'login', 'xsd:string', ls_login);
        pkg_soap.add_parameter(req, 'password', 'xsd:string', ls_password);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();

        --extract data from xml
        select xmltype(result).extract('//GetSessionIdResponse/GetSessionIdResult/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_0
        into ls_sessionid
        from dual;

    --SENDING SMS
        namespace := 'http://services.demirbank.kg/';
        methodname := 'SendSMS';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'mobileNumber', 'xsd:string', ps_mobile_no);
        pkg_soap.add_parameter(req, 'subject', 'xsd:string', ps_subject);
        pkg_soap.add_parameter(req, 'messageBody', 'xsd:string', ps_message_body);
        pkg_soap.add_parameter(req, 'sessionId', 'xsd:string', ls_sessionid);

        begin
            --call web service, and get response
            resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
            result := resp.doc.getstringval();

            --extract data from xml
            select xmltype(result).extract('//SendSMSResponse/SendSMSResult/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_0
            into ls_result
            from dual;
        exception
            when others then
                if result<>'' then
                   log_at('sendSMS',result);
                end if;
                log_at('sendSMS',sqlerrm);
                ls_status_cd := 'sERROR_01';
        end;

        update corpint.tbl_otp_pwds
        set subject = ps_subject,
            message_body = ps_message_body,
            status_cd = ls_status_cd,
            session_id = ls_sessionid,
            result = ls_result,
            request_xml = req.body,
            response_xml = result
        where id = ps_pwd_id;

    elsif (ps_option = 'SEND_SURAT_SMS') then
        ls_status_cd:='sSENDING_02';
        serviceurl := 'http://10.0.0.38/services.demirbank.kg/SuratSMS.asmx';

    --SENDING SMS
        namespace := 'http://services.demirbank.kg/';
        methodname := 'SendSms';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'mobileNumber', 'xsd:string', ps_mobile_no);
        pkg_soap.add_parameter(req, 'subject', 'xsd:string', ps_subject);
        pkg_soap.add_parameter(req, 'messageBody', 'xsd:string', ps_message_body);

        begin
            --call web service, and get response
            resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
            result := resp.doc.getstringval();

            --extract data from xml
            select xmltype(result).extract('//SendSmsResponse/SendSmsResult/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_0
            into ls_result
            from dual;
        exception
            when others then
                result := sqlerrm;
                ls_status_cd := 'sERROR_02';
        end;

        update corpint.tbl_otp_pwds
        set subject = ps_subject,
            message_body = ps_message_body,
            status_cd = 'sSENDING_02',
            result = ls_result,
            request_xml = req.body,
            response_xml = result
        where id = ps_pwd_id;

    end if;

    open pc_ref for
        select ls_sessionid, ls_result from dual;

    return ls_returncode;
exception
    when others then
        ls_returncode := '999'; --system error
        if result<>'' then
           log_at('sendSMS',result);
        end if;
        log_at('sendSMS',sqlerrm);
        return ls_returncode;
end;

/******************************************************************************
   NAME        : FUNCTION makeKTWSRequest
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : make KT Request through WS
******************************************************************************/
function makektwsrequest(ps_param1 in varchar2,
                         ps_service_id in varchar2,
                         ps_supplier_id in varchar2,
                         ps_qid in varchar2,
                         ps_qm in varchar2,
                         ps_sid in varchar2,
                         ps_op in varchar2,
                         ps_sum in varchar2,
                         ps_agent_id in varchar2,
                         pc_ref       out cursorreferencetype) return varchar2 is
pragma autonomous_transaction;

    ls_returncode varchar2(3):='60';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_status varchar2(100);
    ls_sum varchar2(100);
    ls_msg varchar2(2000);

    gs_bpktran_service_url varchar2(200 char):='http://10.0.0.38/services.demirbank.kg/KTServices.asmx';
begin

    pkg_parametre.deger('G_KTWS_SERVICE', gs_bpktran_service_url);
    serviceurl := gs_bpktran_service_url;

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'makeRequest';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'p_PARAM1', 'xsd:string', ps_param1);
        pkg_soap.add_parameter(req, 'p_SERVICE_ID', 'xsd:string', ps_service_id);
        pkg_soap.add_parameter(req, 'p_SUPPLIER_ID', 'xsd:string', ps_supplier_id);
        pkg_soap.add_parameter(req, 'p_QID', 'xsd:string', ps_qid);
        pkg_soap.add_parameter(req, 'p_QM', 'xsd:string', ps_qm);
        pkg_soap.add_parameter(req, 'p_SID', 'xsd:string', ps_sid);
        pkg_soap.add_parameter(req, 'p_OP', 'xsd:string', ps_op);
        pkg_soap.add_parameter(req, 'p_SUM', 'xsd:string', ps_sum);
        pkg_soap.add_parameter(req, 'p_AGENT_ID', 'xsd:string', ps_agent_id);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'makeRequestResponse/makeRequestResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Status',ls_status);
        dbms_xslprocessor.valueof(l_n,'Sum',ls_sum);
        dbms_xslprocessor.valueof(l_n,'Msg/text()',ls_msg);

        open pc_ref for
            select ls_status, ls_sum, ls_msg from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_status;

    exception
        when others then
            ls_returncode:='998';
            ls_msg:=sqlerrm;
            log_at('makeKTWSRequest',sqlerrm);
            open pc_ref for select ls_returncode,null,ls_msg from dual;
    end;

    /*insert into CBS.CBS_USIP_WS_CALL_LOG (LOG_NO, TRAN_TYPE,
    TRANSACTION_NUMBER, RESULTCODE, BANK_DATE,
    REQUEST_XML, RESPONSE_XML)
    values (CORPINT.Pkg_Common.GetSequenceID('pqUSIPLOG'), 'makeWSCancelPayment',
    ps_transaction_number, ls_ResultCode, PKG_MUHASEBE.BANKA_TARIHI_BUL,
    REQ.BODY, result);*/

    commit;
    return ls_returncode;
exception
    when others then
        rollback;
        ls_msg:=sqlerrm;
        ls_returncode:='999';
        log_at('makeKTWSRequest',sqlerrm);
        open pc_ref for select ls_returncode,null,ls_msg from dual;
        return '999';
end;
/******************************************************************************
   NAME        : FUNCTION payforservices
   Prepared By : Almas Nurhozhaev
   Date        : 07.03.11
   Purpose     : transaction to pay for services
******************************************************************************/
function payforservices(pn_fromaccountno   in varchar2,
                        ps_amount          in varchar2,
                        ps_description     in varchar2,
                        ps_currencycode    in varchar2,
                        ps_institution     in varchar2,
                        ps_phone_area_code in varchar2,
                        ps_phone_no        in varchar2,
                        ps_service_code    in varchar2,
                        ps_service_no      in varchar2,
                        pc_ref           out cursorreferencetype) return varchar2 is

      ls_returncode        varchar2 (3) := '000';
      pn_islem_no          number;
      pn_islem_kod         number;
      pc_modul_tur_kod     varchar2 (20);
      pc_urun_tur_kod      varchar2 (20);
      pc_urun_sinif_kod    varchar2 (20);
      ps_fromaccountno     number := to_number(pn_fromaccountno);
      ln_toaccno           number := to_number('1180000029223680');--21111000'); --292236 --66718
      ln_tutar             number := to_number(ps_amount,'99999999999.99');
      LN_TOTAL_AMOUNT      NUMBER := TO_NUMBER(ps_amount,'99999999999.99');  --IB-80 AntonPa 22.07.21
      ps_bolum_kodu        varchar2 (3) := pkg_hesap.hesapsubeal(pn_fromaccountno);
      pc_bolum_kodu        varchar (10) := ps_bolum_kodu;
      pc_amir_bolum_kodu   varchar (10) := ps_bolum_kodu;
      pc_rol               number := 7777;
      pc_doviz_kod         varchar2 (10) := ps_currencycode;
      pn_musteri_numara    number := pkg_hesap.hesaptanmusterinoal(to_number(pn_fromaccountno));
      pc_hesap_numara      number := to_number (pn_fromaccountno);
      pc_kasa_kod          number;
      pn_kanal_numara      number := 1;
      exacc_b              varchar2 (16);
      exacc_a              varchar2 (16);
      ls_istatistik_kodu   varchar2 (10);
      ls_prefix_stat       varchar2 (4);
      ln_charge_amount     number := 0;

         -- begin CQ 527 Commission Charging USIP 24506 KonstantinJ 14022014
      pc_commission_type_bank      varchar2 (10);
      pc_commission_type_company   varchar2 (10);
      pn_comm_amount_bank          number;
      pn_comm_amount_company       number;
      pn_comm_rate_bank            number;
      pn_comm_rate_company         number;
           cursor c_commission
      is
         select a.kurum_kodu,
                a.use_intervals_for_company,
                a.use_intervals_for_bank,
                a.commission_type_bank,
                a.commission_type_company,
                a.commission_rate_bank,
                a.commission_rate_company,
                a.commission_amount_bank,
                a.commission_amount_company
           from cbs_tahsilat_kurum_tanim a
          where a.kurum_kodu = ps_institution;


      cursor i_commission (
         for_type varchar2)
      is
         select *
           from cbs_usip_commission_amount a
          where     a.company_id = ps_institution
                and a.begining_amount <= ln_tutar
                and a.ending_amount >= ln_tutar
                and a.commission_type_for = for_type;

      r_commission                 c_commission%rowtype;
      ic_commission                i_commission%rowtype;
   -- end CQ 527 Commission Charging USIP 24506 KonstantinJ 14022014

begin

    log_at('ebilimfortest1', ln_toaccno, ps_currencycode);
    pn_islem_no := pkg_tx.islem_no_al;
    pn_islem_kod := 6330;
    exacc_b := to_char(pkg_soa_inquiry.Active_external_hesapno_al(ps_fromaccountno));
    exacc_a := lpad(ln_toaccno,16,'0');
    ln_toaccno:=pkg_soa_inquiry.Active_GetHesapNoFromExternal(exacc_a,ps_currencycode);
log_at('ebilimfortest2', ln_toaccno, ps_currencycode);
    ls_prefix_stat := null;

    ls_istatistik_kodu:='022902';

    pc_modul_tur_kod     := pkg_tahsilat_islemleri.modul_tur_tahsilat ;
    pc_urun_tur_kod      := pkg_tahsilat_islemleri.urun_tur_kod(2); -- ONLINE
    pc_urun_sinif_kod    := 'ACCOUNT';

  -- begin CQ 527 Commission Charging USIP 24506 KonstantinJ 14022014
      open c_commission;

      fetch c_commission into r_commission;

      close c_commission;

log_at('ebilimfortest3', r_commission.use_intervals_for_bank);

       if r_commission.use_intervals_for_bank  = 'E'    then
         --BANK
         open i_commission ('BANK');

         fetch i_commission into ic_commission;

         if i_commission%found         then
            if ic_commission.commission_type = 'AMOUNT'
            then

               pc_commission_type_bank := ic_commission.commission_type;
               pn_comm_amount_bank := ic_commission.commission_amount;

               LN_TUTAR := LN_TUTAR - nvl(pn_comm_amount_bank, 0);  --IB-80 AntonPa 22.07.21
            --  ln_tutar := (ln_tutar-pn_commission_amount);

            else
               pc_commission_type_bank := ic_commission.commission_type;
               /*pn_comm_amount_bank :=
                  (ln_tutar * ic_commission.commission_rate / 100);*/ --IB-80 AntonPa 22.07.21
               pn_comm_rate_bank := ic_commission.commission_rate;
            --ln_tutar := (ln_tutar-pn_commission_amount);
            end if;
         end if;
         close i_commission;
      else

         if r_commission.commission_type_bank = 'AMOUNT'
         then
            pc_commission_type_bank := r_commission.commission_type_bank;
            pn_comm_amount_bank := r_commission.commission_amount_bank;

            LN_TUTAR := LN_TUTAR - nvl(pn_comm_amount_bank, 0);  --IB-80 AntonPa 22.07.21
            end if;
         --  ln_tutar := (ln_tutar-pn_commission_amount);
          if r_commission.commission_type_bank = 'RATE' then
            pc_commission_type_bank := r_commission.commission_type_bank;
            /*pn_comm_amount_bank :=               (ln_tutar * r_commission.commission_rate_bank / 100);*/ --IB-80 AntonPa 22.07.21
            pn_comm_rate_bank := r_commission.commission_rate_bank;
         --ln_tutar := (ln_tutar-pn_commission_amount);
         end if;
      end if;

log_at('ebilimfortest4', r_commission.use_intervals_for_company);
      if r_commission.use_intervals_for_company  = 'E'     then
         --Company
         open i_commission ('COMPANY');

         fetch i_commission into ic_commission;

         if i_commission%found         then
            if ic_commission.commission_type= 'AMOUNT'            then

               pc_commission_type_company := ic_commission.commission_type;
               pn_comm_amount_company := ic_commission.commission_amount;

               LN_TUTAR := LN_TUTAR - nvl(pn_comm_amount_company, 0);  --IB-80 AntonPa 22.07.21
            --  ln_tutar := (ln_tutar-pn_commission_amount);

            else
               pc_commission_type_company := ic_commission.commission_type;
               /*pn_comm_amount_company :=
                  (ln_tutar * ic_commission.commission_rate / 100);*/  --IB-80 AntonPa 22.07.21
               pn_comm_rate_company := ic_commission.commission_rate;
            --ln_tutar := (ln_tutar-pn_commission_amount);
            end if;

         end if;
          close i_commission;
      else
         if r_commission.commission_type_company = 'AMOUNT'         then
            pc_commission_type_company := r_commission.commission_type_company;
            pn_comm_amount_company := r_commission.commission_amount_company;

            LN_TUTAR := LN_TUTAR - nvl(pn_comm_amount_company, 0);  --IB-80 AntonPa 22.07.21
         --  ln_tutar := (ln_tutar-pn_commission_amount);
         end if;
         if r_commission.commission_type_company = 'RATE' then
            pc_commission_type_company := r_commission.commission_type_company;
            /*pn_comm_amount_company :=     (ln_tutar * r_commission.commission_rate_company / 100);*/ --IB-80 AntonPa 22.07.21
            pn_comm_rate_company := r_commission.commission_rate_company;
         --ln_tutar := (ln_tutar-pn_commission_amount);
         end if;

      end if;

--BOM IB-80 AntonPa 22.07.21
      LN_TUTAR := (LN_TUTAR * 100) / (100 + NVL(pn_comm_rate_BANK, 0) + NVL(pn_comm_rate_company, 0));
log_at('ebilimfortest5', LN_TUTAR);
      PKG_SOA_COMMON.GET_CORRECT_COMMISSION(PS_INSTITUTION,
                                          LN_TOTAL_AMOUNT,
                                          LN_TUTAR,
                                          R_COMMISSION.USE_INTERVALS_FOR_BANK,
                                          R_COMMISSION.USE_INTERVALS_FOR_COMPANY,
                                          PC_COMMISSION_TYPE_BANK,
                                          PC_COMMISSION_TYPE_COMPANY,
                                          PN_COMM_AMOUNT_BANK,
                                          PN_COMM_AMOUNT_COMPANY,
                                          PN_COMM_RATE_BANK,
                                          PN_COMM_RATE_COMPANY);

LN_TUTAR := LN_TOTAL_AMOUNT-PN_COMM_AMOUNT_COMPANY-PN_COMM_AMOUNT_BANK;
--EOM IB-80 AntonPa 22.07.21

   -- end CQ 527 Commission Charging USIP 24506 KonstantinJ 14022014
log_at('ebilimfortest6', LN_TUTAR);
    if pc_doviz_kod=pkg_genel.lc_al then
        if pkg_musteri.sf_musteri_tipi_al(pn_musteri_numara)=3 then
            ln_charge_amount:=pkg_aps.chargeautocalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                                          ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
        else
            ln_charge_amount:=pkg_aps.chargeautocalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                                          ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
        end if;
    else
        ln_charge_amount:=pkg_aps.chargeautocalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                                      ln_tutar, pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
    end if;

    open pc_ref for select pn_islem_no from dual;
log_at('ebilimfortest7', pn_islem_no, ls_returncode);
    insert into cbs_tahsilat_ana_islem(islem_no, tahsilat_tarihi, tahsil_sekli, musteri_no, hesap_no, isim_unvan, doviz_kodu, odeme_sekli, tahsilat_kanali)
    values (pn_islem_no, pkg_muhasebe.banka_tarihi_bul, pc_urun_sinif_kod,pn_musteri_numara, ps_fromaccountno, pkg_musteri.sf_musteri_adi(pn_musteri_numara), pc_doviz_kod, 6, 1) ; -- tahsilat kanali =1 internet

   insert into cbs_tahsilat_detay_islem (islem_no,
                                            kurum_kodu,
                                            tutar,
                                            telefon_alan_kod,
                                            telefon_no,
                                            service_kodu,
                                            kurum_ozel_no,
                                            sira_no,
                                            abone_adi,
                                            payment_id,
                                            commission_type_bank,
                                            commission_type_company,
                                            commission_amount_bank,
                                            commission_amount_company,
                                            commission_rate_bank,
                                            commission_rate_company)
           values (pn_islem_no,
                   ps_institution,
                   ln_tutar,
                   ps_phone_area_code,
                   ps_phone_no,
                   ps_service_code,
                   ps_service_no,
                   1,
                   ps_description,
                   pkg_genel.genel_kod_al ('INVOICE_PAYMENT_ID'),
                   pc_commission_type_bank,
                   pc_commission_type_company,
                   pn_comm_amount_bank,
                   pn_comm_amount_company,
                   pn_comm_rate_bank,
                   pn_comm_rate_company);
log_at('ebilimfortest8', pn_islem_no, ls_returncode);
    pkg_int_api.create_transaction(pn_islem_no,
                                   pn_islem_kod,
                                   pc_modul_tur_kod,
                                   pc_urun_tur_kod,
                                   pc_urun_sinif_kod,
                                   ln_tutar,
                                   pc_amir_bolum_kodu,
                                   pc_bolum_kodu,
                                   pc_rol,
                                   pc_doviz_kod,
                                   pn_musteri_numara,
                                   pc_hesap_numara,
                                   pc_kasa_kod,
                                   pn_kanal_numara);
log_at('ebilimfortest8.1');
      pkg_int_api.process_transaction (pn_islem_no);
log_at('ebilimfortest9', ls_returncode);
   return ls_returncode;
exception
    when others then
        ls_returncode := pkg_int_api.geterrorcode (sqlerrm);
        log_at('PayForServices',sqlerrm, ls_returncode);
        rollback;
        open pc_ref for select pn_islem_no from dual;
        return ls_returncode;
end;

/******************************************************************************
   NAME        : FUNCTION payforservices
   Prepared By : Almas Nurhozhaev
   Date        : 07.03.11
   Purpose     : transaction to pay for services
******************************************************************************/
function cancelpayment(pn_option    in varchar2,
                       ps_person_id in varchar2,
                       ps_customer_id in varchar2,
                       ps_payment_id in varchar2,
                       pc_ref       out cursorreferencetype) return varchar2 is

      ls_returncode        varchar2 (3) := '000';
      pn_islem_no          number;
      pn_islem_kod         number;
      pc_modul_tur_kod     varchar2 (20);
      pc_urun_tur_kod      varchar2 (20);
      pc_urun_sinif_kod    varchar2 (20);
      pc_rol               number := 7777;
      pc_kasa_kod          number;
      pn_kanal_numara      number := 1;

    cursor cancelpayments_cursor is
        select  payment_id, islem_no tx_no, sira_no order_no, kurum_kodu institution_code,
                decode(telefon_alan_kod,null,telefon_no,telefon_alan_kod || ' - ' || telefon_no) telefon_no ,
                decode(service_kodu,null,kurum_ozel_no,service_kodu || ' - ' || kurum_ozel_no) service_no,
                tutar  amount, to_char(tahsilat_tarihi,'YYYYMMDD') payment_date, hesap_no, doviz_kodu
        from cbs_tahsilat
        where tahsilat_tarihi >= pkg_muhasebe.onceki_banka_tarihi_bul
        and   durum_kodu = 'ACIK'
        and   musteri_no = ps_customer_id
        and   instr(ps_payment_id, ',' || to_char(payment_id) || ',')>0
        and   pkg_tahsilat_islemleri.kurum_iptal_max_datetime(kurum_kodu, tahsilat_saati ) >= sysdate;

    row_cancelpayment cancelpayments_cursor%rowtype;

begin
    open pc_ref for select sysdate from dual;

    if (pn_option='CANCEL') then
        open cancelpayments_cursor;
        fetch cancelpayments_cursor into row_cancelpayment;
        while  cancelpayments_cursor%found
        loop

            pn_islem_no := pkg_tx.islem_no_al;
            pn_islem_kod := 6331;

            pc_modul_tur_kod     := pkg_tahsilat_islemleri.modul_tur_tahsilat ;
            pc_urun_tur_kod      := pkg_tahsilat_islemleri.urun_tur_kod(2); -- ONLINE
            pc_urun_sinif_kod    := 'ACCOUNT';

            open pc_ref for select pn_islem_no from dual;

            insert into cbs_tahsilat_iptal_talep_islem
            (tx_no, tahsilat_islem_no, tahsilat_islem_sira_no, payment_id, tahsilat_tarihi,
             tahsil_sekli, tahsilat_kanali, sube_kodu, musteri_no, hesap_no,
             isim_unvan, kurum_kodu, doviz_kodu, tutar, son_odeme_tarihi,
             odeme_sekli, telefon_alan_kod, telefon_no, kurum_ozel_no, aciklama,
             dk_no, abone_adi, islem_sube_kodu, service_kodu, kurum_grup_kod,
             kurum_alt_grup_kod,tahsilat_saati)
            select pn_islem_no tx_no, islem_no tahsilat_islem_no, sira_no tahsilat_islem_sira_no, payment_id, tahsilat_tarihi,
                   tahsil_sekli, tahsilat_kanali, sube_kodu, musteri_no, hesap_no,
                   isim_unvan, kurum_kodu, doviz_kodu, tutar, son_odeme_tarihi,
                   odeme_sekli, telefon_alan_kod, telefon_no, kurum_ozel_no, aciklama,
                   dk_no, abone_adi, islem_sube_kodu, service_kodu, kurum_grup_kod,
                   kurum_alt_grup_kod ,tahsilat_saati
            from cbs_tahsilat
            where payment_id = row_cancelpayment.payment_id;


            pkg_int_api.create_transaction(pn_islem_no,
                                           pn_islem_kod,
                                           pc_modul_tur_kod,
                                           pc_urun_tur_kod,
                                           pc_urun_sinif_kod,
                                           row_cancelpayment.amount,
                                           pkg_hesap.hesapsubeal(row_cancelpayment.hesap_no),
                                           pkg_hesap.hesapsubeal(row_cancelpayment.hesap_no),
                                           pc_rol,
                                           row_cancelpayment.doviz_kodu,
                                           ps_customer_id,
                                           row_cancelpayment.hesap_no,
                                           pc_kasa_kod,
                                           pn_kanal_numara);

            pkg_int_api.process_transaction (pn_islem_no);

        fetch cancelpayments_cursor into row_cancelpayment;
        end loop;
        close cancelpayments_cursor;
    end if;


   return ls_returncode;
exception
    when others then
        ls_returncode := pkg_int_api.geterrorcode (sqlerrm);
        log_at('CancelPayment',sqlerrm, ls_returncode);
        rollback;
        open pc_ref for select sysdate from dual;
        return ls_returncode;
end;
/******************************************************************************
   NAME        : FUNCTION makeWSPaymentRequest
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : Payment Request for web service USIP
******************************************************************************/
function makewspaymentrequest(ps_amount    in varchar2,
                              ps_transaction_number in varchar2,
                              ps_service_id in varchar2,
                              ps_account_number in varchar2,
                              ps_receipt_number in varchar2,
                              ps_receipt_datetime in varchar2 default to_char(sysdate, 'YYYYMMDDHH24MISS'),
                              pc_ref       out cursorreferencetype) return varchar2
is
pragma autonomous_transaction;

    ls_returncode varchar2(3):='60';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_status varchar2(100);
    ls_resultcode varchar2(100);
    ls_transactionnumber varchar2(100);
    ls_serviceid varchar2(100);
    ls_amount varchar2(100);
    ls_accountnumber varchar2(100);

    ls_username varchar2(100) := 'DemirIB';
    ls_password varchar2(100) := '9b6ebe3746a3f9f904b85d1956d0fb18';

    gs_bpktran_service_url varchar2(200 char):='http://10.0.0.38/services.demirbank.kg/USIPServices.asmx';
begin

    pkg_parametre.deger('WS_USIP_SERVICE_URL', gs_bpktran_service_url);

    serviceurl := gs_bpktran_service_url;

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'makeSinglePayment';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'p_username', 'xsd:string', ls_username);
        pkg_soap.add_parameter(req, 'p_password', 'xsd:string', ls_password);
        pkg_soap.add_parameter(req, 'p_amount', 'xsd:string', ps_amount);
        pkg_soap.add_parameter(req, 'p_transaction_number', 'xsd:string', ps_transaction_number);
        pkg_soap.add_parameter(req, 'p_service_id', 'xsd:string', ps_service_id);
        pkg_soap.add_parameter(req, 'p_account_number', 'xsd:string', ps_account_number);
        pkg_soap.add_parameter(req, 'p_receipt_datetime', 'xsd:string', ps_receipt_number);
        pkg_soap.add_parameter(req, 'p_receipt_number', 'xsd:string', ps_receipt_datetime);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'makeSinglePaymentResponse/makeSinglePaymentResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Status',ls_status);
        dbms_xslprocessor.valueof(l_n,'ResultCode',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'TransactionNumber/text()',ls_transactionnumber);
        dbms_xslprocessor.valueof(l_n,'ServiceId/text()',ls_serviceid);
        dbms_xslprocessor.valueof(l_n,'Amount/text()',ls_amount);
        dbms_xslprocessor.valueof(l_n,'AccountNumber/text()',ls_accountnumber);

        open pc_ref for
            select ls_status, ls_resultcode, ls_transactionnumber, ls_serviceid, ls_amount, ls_accountnumber from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_status;

        IF ls_resultcode = '10'  THEN
       ls_returncode := ls_resultcode; --Nurs Kazbekov, ib-169, duplicate payment error from pay24
      END IF;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
    end;

    insert into cbs.cbs_usip_ws_call_log (log_no, tran_type,
    amount, transaction_number, service_id, account_number, receipt_datetime, receipt_number, status, resultcode, bank_date,
    request_xml, response_xml)
    values (corpint.pkg_common.getsequenceid('pqUSIPLOG'), 'makeWSPaymentRequest',
    ps_amount, ps_transaction_number, ps_service_id, ps_account_number, ps_receipt_datetime, ps_receipt_number, ls_status, ls_resultcode, pkg_muhasebe.banka_tarihi_bul,
    req.body, result);

    commit;
    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        rollback;
        log_at('makeWSPaymentRequest',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION getWSPaymentStatus
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : gets Payment Status for web service USIP
******************************************************************************/
function getwspaymentstatus(ps_amount    in varchar2,
                            ps_transaction_number in varchar2,
                            pc_ref       out cursorreferencetype) return varchar2
is
pragma autonomous_transaction;

    ls_returncode varchar2(3):='60';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_status varchar2(100);
    ls_resultcode varchar2(100);
    ls_transactionnumber varchar2(100);
    ls_serviceid varchar2(100);
    ls_amount varchar2(100);
    ls_accountnumber varchar2(100);

    ls_username varchar2(100) := 'DemirIB';
    ls_password varchar2(100) := '9b6ebe3746a3f9f904b85d1956d0fb18';

    ls_service_id varchar2(100) := '';
    ls_account_number varchar2(100) := '';

    gs_bpktran_service_url varchar2(200 char):='http://10.0.0.38/services.demirbank.kg/USIPServices.asmx';
begin

    pkg_parametre.deger('WS_USIP_SERVICE_URL', gs_bpktran_service_url);

    serviceurl := gs_bpktran_service_url;

    --AlmasN 20170605 get extra info for ws
    select service_id, usip_accountnumber into ls_service_id, ls_account_number
    from cbs.cbs_tahsilat_usip_webserv_log
        where tahsilat_islem_no=to_number(ps_transaction_number)
        and transaction_type='PAYMENT-REQUEST'
        and rownum=1;

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'getSinglePaymentStatus';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'p_username', 'xsd:string', ls_username);
        pkg_soap.add_parameter(req, 'p_password', 'xsd:string', ls_password);
        pkg_soap.add_parameter(req, 'p_amount', 'xsd:string', ps_amount);
        pkg_soap.add_parameter(req, 'p_transaction_number', 'xsd:string', ps_transaction_number);
        pkg_soap.add_parameter(req, 'p_service_id', 'xsd:string', ls_service_id);
        pkg_soap.add_parameter(req, 'p_account_number', 'xsd:string', ls_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'getSinglePaymentStatusResponse/getSinglePaymentStatusResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Status',ls_status);
        dbms_xslprocessor.valueof(l_n,'ResultCode',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'TransactionNumber/text()',ls_transactionnumber);
        dbms_xslprocessor.valueof(l_n,'ServiceId/text()',ls_serviceid);
        dbms_xslprocessor.valueof(l_n,'Amount/text()',ls_amount);
        dbms_xslprocessor.valueof(l_n,'AccountNumber/text()',ls_accountnumber);

        open pc_ref for
            select ls_status, ls_resultcode, ls_transactionnumber, ls_serviceid, ls_amount, ls_accountnumber from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_status;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
    end;


    insert into cbs.cbs_usip_ws_call_log (log_no, tran_type,
    amount, transaction_number, status, resultcode, bank_date,
    request_xml, response_xml)
    values (corpint.pkg_common.getsequenceid('pqUSIPLOG'), 'getWSPaymentStatus',
    ps_amount, ps_transaction_number,ls_status, ls_resultcode, pkg_muhasebe.banka_tarihi_bul,
    req.body, result);
    commit;
    return ls_returncode;
exception
    when others then
        rollback;
        log_at('getWSPaymentStatus',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION makeWSCancelPayment
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : Cancel Payment Request for web service USIP
******************************************************************************/
function makewscancelpayment(ps_transaction_number in varchar2,
                             pc_ref       out cursorreferencetype) return varchar2
is
pragma autonomous_transaction;

    ls_returncode varchar2(3):='60';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_transactionnumber varchar2(100);

    ls_username varchar2(100) := 'DemirIB';
    ls_password varchar2(100) := '9b6ebe3746a3f9f904b85d1956d0fb18';

    ls_service_id varchar2(100) := '';
    ls_account_number varchar2(100) := '';

    gs_bpktran_service_url varchar2(200 char):='http://10.0.0.38/services.demirbank.kg/USIPServices.asmx';
begin

    pkg_parametre.deger('WS_USIP_SERVICE_URL', gs_bpktran_service_url);

    serviceurl := gs_bpktran_service_url;

    --AlmasN 20170605 get extra info for ws
    select service_id, usip_accountnumber into ls_service_id, ls_account_number
    from cbs.cbs_tahsilat_usip_webserv_log
        where tahsilat_islem_no=to_number(ps_transaction_number)
        and transaction_type='PAYMENT-REQUEST'
        and rownum=1;

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'makeSingleCancelPayment';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'p_username', 'xsd:string', ls_username);
        pkg_soap.add_parameter(req, 'p_password', 'xsd:string', ls_password);
        pkg_soap.add_parameter(req, 'p_transaction_number', 'xsd:string', ps_transaction_number);
        pkg_soap.add_parameter(req, 'p_service_id', 'xsd:string', ls_service_id);
        pkg_soap.add_parameter(req, 'p_account_number', 'xsd:string', ls_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'makeSingleCancelPaymentResponse/makeSingleCancelPaymentResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'ResultCode',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'TransactionNumber/text()',ls_transactionnumber);

        open pc_ref for
            select ls_resultcode, ls_transactionnumber from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_resultcode;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
    end;

    insert into cbs.cbs_usip_ws_call_log (log_no, tran_type,
    transaction_number, resultcode, bank_date,
    request_xml, response_xml)
    values (corpint.pkg_common.getsequenceid('pqUSIPLOG'), 'makeWSCancelPayment',
    ps_transaction_number, ls_resultcode, pkg_muhasebe.banka_tarihi_bul,
    req.body, result);

    commit;
    return ls_returncode;
exception
    when others then
        rollback;
        log_at('makeWSCancelPayment',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/*******************************************************************************
    Name        : FUNCTION payWsTax
    Prepared By : Almas Nurkhozhayev
    Date:       : 01.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : send info that customer will pay for given tax
*******************************************************************************/
function paywstax(ps_tin_number      in varchar2,
                  ps_amount          in varchar2,
                  ps_tax_type        in varchar2,
                  ps_tax_district    in varchar2,
                  ps_tax_subdistrict in varchar2,
                  ps_tx_no           in varchar2,
                  ps_datetime        in varchar2,
                  ps_vehicle_plate   in varchar2,
                  pc_ref        out cursorreferencetype) return varchar2 is

    ls_returncode varchar2(3):='000';

    ln_tx_no number;
    ln_check_num varchar2(3);
    ln_terminal_num varchar2(3);

    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_osmp_txn_id varchar2(100);
    ls_prv_txn varchar2(100);
    ls_sum varchar2(100);
    ls_result varchar2(100);
    ls_comment varchar2(200);

    url_web varchar2(200 char);
begin
    pkg_parametre.deger('TAX_SERVICE_URL', url_web);
    serviceurl := url_web;

    ln_tx_no := ps_tx_no;
    pkg_parametre.deger('IB_TAX_PAY_CHECK_NUM', ln_check_num);
    pkg_parametre.deger('IB_TAX_PAY_TERMINAL_NUM', ln_terminal_num);

    begin
        namespace := 'http://services.demirbank.kg/';
        methodname := 'PayLocTax';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'tin', 'xsd:string', ps_tin_number);
        pkg_soap.add_parameter(req, 'amount', 'xsd:string', ps_amount);
        pkg_soap.add_parameter(req, 'tax_type', 'xsd:string', ps_tax_type);
        pkg_soap.add_parameter(req, 'tax_district', 'xsd:string', ps_tax_district);
        pkg_soap.add_parameter(req, 'tax_subdistrict', 'xsd:string', ps_tax_subdistrict);
        pkg_soap.add_parameter(req, 'tx_no', 'xsd:string', ln_tx_no);
        pkg_soap.add_parameter(req, 'check_num', 'xsd:string', ln_tx_no);
        pkg_soap.add_parameter(req, 'terminal_num', 'xsd:string', ln_terminal_num);
        pkg_soap.add_parameter(req, 'datetime', 'xsd:string', ps_datetime);
        pkg_soap.add_parameter(req, 'vehicle_plate', 'xsd:string', ps_vehicle_plate);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'PayLocTaxResponse/PayLocTaxResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'response/osmp_txn_id',ls_osmp_txn_id);
        dbms_xslprocessor.valueof(l_n,'response/prv_txn',ls_prv_txn);
        dbms_xslprocessor.valueof(l_n,'response/sum',ls_sum);
        dbms_xslprocessor.valueof(l_n,'response/result',ls_result);
        dbms_xslprocessor.valueof(l_n,'response/comment',ls_comment);

        corpint.pkg_log.addcustomlog('payWsTax', substr(req.body, 1000), substr(result, 1, 1000));

        open pc_ref for
            select ls_osmp_txn_id, ls_prv_txn, ls_sum, ls_result, ls_comment from dual;

    exception
        when others then
            if pc_ref%isopen then
                close pc_ref;
            end if;
            result := sqlerrm;
            ls_returncode:='999';
            log_at('payWsTax', result, dbms_utility.format_error_backtrace);
            open pc_ref for select sysdate from dual;
    end;

    return ls_returncode;
end;

/*******************************************************************************
    Name        : FUNCTION makeTaxPayment
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : make payment for tax house over clearing
*******************************************************************************/
function maketaxpayment(ps_tin_number      in varchar2,
                        ps_namesurname     in varchar2,
                        ps_type_id         in varchar2,
                        ps_region_id       in varchar2,
                        ps_district_id     in varchar2,
                        ps_sub_district_id in varchar2,
                        ps_amount          in varchar2,
                        ps_explanation_id  in varchar2,
                        ps_from_account    in varchar2,
                        ps_person_id       in varchar2,
                        ps_vehicle_plate   in varchar2,
                        pc_ref         out cursorreferencetype) return varchar2 is

    ls_returncode varchar2(3):='000';
    pc_result  cursorreferencetype;

    ls_result varchar2(3):='000';

    ls_osmp_txn_id varchar2(100);
    ls_prv_txn varchar2(100);
    ls_sum varchar2(100);
    ls_res varchar2(100);
    ls_comment varchar2(100);

    ls_eftdate varchar2(10);
    ls_makedatetime varchar2(20):=to_char(sysdate, 'yyyymmddhh24miss');

    ls_param_val corpint.tbl_int_parametre.param_val%type;
    ls_parent_code corpint.tbl_int_parametre.parent_code%type;
    ls_explanation corpint.tbl_int_parametre.explanation%type;
    ls_param_option corpint.tbl_int_parametre.param_option%type;
    ls_sub_district corpint.tbl_int_parametre.explanation%type;
    ls_description corpint.tbl_txtodo.field10%type;

    ln_txid number;
    ls_refno varchar2(15);
    ln_islem_no number;
    ln_amount number;
    ls_vehicle_plate varchar2(50); -- AdiletK CQ5412 vehicle plate addition
begin
    /* -- get clearing date --- */

    ls_result := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', pc_result);

    if (ls_result <> '000') then

        open pc_ref for
            select sysdate from dual;

        return ls_result;

    end if;

    fetch pc_result into ls_eftdate, ls_res, ls_res, ls_res, ls_res;
    close pc_result;

    -- get treasury account info
    select param_val, parent_code, explanation, param_option
    into ls_param_val, ls_parent_code, ls_explanation, ls_param_option
    from corpint.tbl_int_parametre t
    where param_code='TAX_ROK'
    and (parent_code = ps_district_id or parent_code is null)
    and (param_option = nvl(ps_sub_district_id, param_option) or param_option is null or param_option = 'DEFAULT')
    and lang_cd='RUS'
    and rownum = 1;

    -- get tax type explanation
    select explanation into ls_description
    from corpint.tbl_int_parametre t
    where param_code='TAX_TYPE'
    and (parent_code = '' or parent_code is null)
    and (param_option = nvl('', param_option) or param_option is null or param_option = 'DEFAULT')
    and lang_cd='RUS'
    and param_val = ps_type_id
    and rownum = 1;

    -- get subdistrict explanation
    if (length(ps_sub_district_id) > 0) then
        select explanation into ls_sub_district
        from corpint.tbl_int_parametre t
        where param_code='TAX_SUB_DISTRICT'
        and (parent_code = ps_district_id or parent_code is null)
        and (param_option = nvl('', param_option) or param_option is null or param_option = 'DEFAULT')
        and lang_cd='RUS'
        and param_val = ps_sub_district_id
        and rownum = 1;
    else
        ls_sub_district := '';
    end if;

    -- AdiletK CQ5412 vehicle plate addition
    if ps_vehicle_plate is not null and ps_vehicle_plate != '' then
        ls_vehicle_plate := ', гос. № ' || ps_vehicle_plate;
    end if;
    /* -- save clearing in tx_todo --- */

    --BOM NurmilaZ 07122021
    /*ls_result := corpint.pkg_auth.clearingtodo(ps_from_account, '', ls_eftdate, ps_namesurname, ps_type_id || ';' || ps_region_id || ';' || ps_district_id || ';' || ps_sub_district_id,
                                               pkg_message.split(ls_param_val, ';',0) || ';' || pkg_message.split(ls_explanation, ';',0), pkg_message.split(ls_explanation, ';',1),
                                               pkg_message.split(ls_param_val, ';',1), ln_amount, ls_description || ', ' || ps_sub_district_id || ' ' || ls_sub_district || ls_vehicle_plate,
                                               '', '', '', 'sAPPROVE', ps_person_id,
                                               '', ps_tin_number, '', '', '', '', pc_result);*/

    ls_result := corpint2.pkg_todo.createtaxpayments('TAXPAYMENT',
                               ps_person_id,
                               'sAPPROVE' ,
                               ps_from_account,
                               ps_tin_number  ,
                               ps_type_id || ';' || ps_region_id || ';' || ps_district_id || ';' || ps_sub_district_id,
                               ln_amount  ,
                               'KGS'   ,
                               pkg_message.split(ls_param_val, ';',1) ,
                               ls_description || ', ' || ps_sub_district_id || ' ' || ls_sub_district || ls_vehicle_plate,
                               pc_result);


    if (ls_result <> '000') then

        open pc_ref for
            select sysdate from dual;

        return ls_result;

    end if;

    fetch pc_result into ln_txid;
    close pc_result;

    /* -- make tax pay ws call --- */

    /*select to_char(makedate, 'yyyymmddhh24miss') into ls_makedatetime
    from corpint.tbl_txtodo
    where tx_no = ln_txid;*/

    select to_char(makedate, 'yyyymmddhh24miss') into ls_makedatetime
      from corpint2.tbl_tax_payments_todo
        where tx_no = ln_txid;

    --EOM NurmilaZ 07122021

    ln_amount := to_number(ps_amount, '999999999.99');

    ls_result := pkg_soa_transaction.paywstax(ps_tin_number, ln_amount, pkg_message.split(ps_type_id, ';',0), ps_district_id, ps_sub_district_id, ln_txid, ls_makedatetime, ps_vehicle_plate, pc_result);

    fetch pc_result into ls_osmp_txn_id, ls_prv_txn, ls_sum, ls_res, ls_comment;
    close pc_result;

    if (ls_result <> '000' or ls_res <> '0') then

        open pc_ref for
            select sysdate from dual;

        return '999';

    end if;

    /* -- make clearing transaction --- */

    /* -- aisuluukas cqdb4660 23072015 add ps_explanation_id to save technical passport number   --- */
    ls_result := pkg_soa_transaction.makeeft(ps_from_account, '', ls_eftdate, ps_namesurname, '',
                                             pkg_message.split(ls_param_val, ';',0) || ';' || pkg_message.split(ls_explanation, ';',0), pkg_message.split(ls_explanation, ';',1),
                                             pkg_message.split(ls_param_val, ';',1), ln_amount, ps_explanation_id, --Bakdoolot ib-161
                                             '', '', '', '', '',
                                             '', pkg_message.split(ps_type_id, ';',1), ps_tin_number, 'IB_TAX_PAYMENT', pc_result);

    if (ls_result <> '000') then

        open pc_ref for
            select sysdate from dual;

        return ls_result;

    end if;

    fetch pc_result into ls_refno, ln_islem_no;
    close pc_result;

    --BOM NurmilaZ 07122021
    /*update corpint.tbl_txtodo
    set trancd='TAXPAYMENT',
        status='sEXECUTED',
        field18=ln_islem_no,
        field16=ls_prv_txn
    where tx_no=ln_txid;*/

    update corpint2.TBL_TAX_PAYMENTS_TODO
    set status='sEXECUTED',
        TAX_TX_NO=ln_islem_no,
        TAX_PRV_TX_NO=ls_prv_txn
    where tx_no=ln_txid;

    --EOM NurmilaZ 07122021

    /* -- save txtodo --- */

    open pc_ref for
        select ln_islem_no, to_char(sysdate, 'dd-mm-yyyy hh24:mi:ss') OPDATETIME from dual;

    return ls_returncode;
exception
    when others then
        if pc_ref%isopen then
            close pc_ref;
        end if;
        log_at('makeTaxPayment', sqlerrm, dbms_utility.format_error_backtrace);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/*******************************************************************************
    Name        : FUNCTION makeCampusSattlement
    Prepared By : Almas Nurkhozhayev
    Date:       : 19.08.2020
    Base Project: CBS-56 - Tuition fee via Payment Terminals Settlement
    Purpose     : Tuition fee via Payment Terminals Settlement by clearing
*******************************************************************************/
function makecampussattlement(pc_ref out cursorreferencetype) return varchar2 is

    ls_returncode varchar2(3):='000';
    pc_result  cursorreferencetype;

    ls_result varchar2(3):='000';

    ls_to_account corpint.tbl_int_parametre.param_val%type;
    ls_bank_code corpint.tbl_int_parametre.param_val%type;
    ls_payee_name corpint.tbl_int_parametre.explanation%type;
    ls_explanation corpint.tbl_int_parametre.explanation%type;

    cursor c1 is
        select cc.kurum_kodu, cc.musteri_no, cc.kurum_hesap_no, sum(bb.tutar) amount
        from cbs_tahsilat_kurum_tanim cc, cbs_tahsilat_ana_islem aa, cbs_tahsilat_detay_islem bb
        where aa.islem_no = bb.islem_no
        and cc.kurum_kodu = bb.kurum_kodu
        and instr((select deger from cbs_parametre where kod='AVN_TREASURY_CLEARING_LIST' and rownum=1), cc.provider_code, 1) > 0
        and (select kayit_tarih from cbs_islem where numara=aa.islem_no)=pkg_muhasebe.onceki_banka_tarihi_bul
        and trunc(sysdate)=pkg_muhasebe.banka_tarihi_bul
        and ticket_id is null
        group by cc.kurum_kodu, cc.musteri_no, cc.kurum_hesap_no;

    r1    c1%rowtype;
begin
    /* -- get clearing date --- */
    ls_result := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', pc_result);

    if (ls_result <> '000') then
        open pc_ref for
            select sysdate from dual;
        return ls_result;
    end if;

    open c1;
    fetch c1 into r1;
        if c1%found then
            while c1%found
            loop

                -- get treasury account info
                select param_val, explanation
                into ls_to_account, ls_payee_name
                from corpint.tbl_int_parametre t
                where param_code='CAMPUS_' || r1.kurum_kodu
                and rownum = 1;

                select param_val, explanation
                into ls_bank_code, ls_explanation
                from corpint.tbl_int_parametre t
                where param_code='CAMPUS_BIC_' || r1.kurum_kodu
                and rownum = 1;

                /* -- make clearing transaction --- */
                ls_result := pkg_int_transfer.makeeft(r1.kurum_hesap_no, '', to_char(pkg_muhasebe.banka_tarihi_bul,'YYYYMMDD'), pkg_musteri.sf_musteri_adi(r1.musteri_no), '',
                                 pkg_message.split(ls_bank_code, ';',0), ls_payee_name, ls_to_account, r1.amount, ls_explanation,
                                 '', '', pkg_message.split(ls_bank_code, ';',1), '', '', '',
                                 'CLEARING', '', pc_result);

                if (ls_result <> '000') then
                    open pc_ref for
                        select sysdate from dual;
                    return ls_result;
                end if;

            fetch c1 into r1;
            end loop;
        end if;
    close c1;

    open pc_ref for
        select 'OK' from dual;

    return ls_returncode;
exception
    when others then
        if pc_ref%isopen then
            close pc_ref;
        end if;
        log_at('makeCampusSattlement', sqlerrm, dbms_utility.format_error_backtrace);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/*******************************************************************************
    Name        : FUNCTION sendTaxHouseReport
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : calls tax house report with xml parameter
*******************************************************************************/
function sendtaxhousereport(ps_xml_data out clob) return varchar2 is

    ls_returncode varchar2(3):='000';
    ls_result varchar2(3):='000';

    ls_xml_data varchar2(4000):='';

    ld_startdate date;
    ld_enddate date;
    ln_report_period number:=7;
    ln_check_num varchar2(100);
    ln_terminal_num varchar2(3);
    ln_operator_num varchar2(3);

    ln_total_amount number := 0;
    ln_count number:=0;
    ls_vehicle_plate varchar2(100);

    cursor pc_result is
        select * from cbs_clearing aa, corpint2.TBL_TAX_PAYMENTS_TODO bb --NurmilaZ 07122021
        where bb.trancd='TAXPAYMENT'
        and aa.from_account = bb.TAX_FROM_ACCOUNT
        and aa.yaratan_tx_no = bb.TAX_TX_NO
        and aa.yaratildigi_tarih >= ld_startdate
        and aa.yaratildigi_tarih <= ld_enddate
        and aa.msg_status = 'sDONE'
        order by aa.yaratan_tx_no desc;

    row_pc_result pc_result%rowtype;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    url_web varchar2(200 char);
begin
    pkg_parametre.deger('TAX_SERVICE_URL', url_web);

    /* -- make tax pay ws call --- */

    pkg_parametre.deger('IB_TAX_PAY_CHECK_NUM', ln_check_num);
    pkg_parametre.deger('IB_TAX_PAY_TERMINAL_NUM', ln_terminal_num);
    pkg_parametre.deger('IB_TAX_PAY_OPERATOR_NUM', ln_operator_num);

    -- Get period val
    select count(1) into ln_count
    from corpint.tbl_configuration
    where key='tax.pay.register.period';

    if (ln_count > 0) then
        select to_number(value) into ln_report_period
        from corpint.tbl_configuration
        where key='tax.pay.register.period';
    else
        ln_report_period := 7;

        insert into corpint.tbl_configuration (key, value)
        values ('tax.pay.register.period', to_char(ln_report_period));
    end if;

    -- Get last start date or init
    select count(1) into ln_count
    from corpint.tbl_configuration
    where key='tax.pay.register.startdate';

    if (ln_count > 0) then
        select to_date(value, 'yyyymmdd hh24:mi:ss') into ld_startdate
        from corpint.tbl_configuration
        where key='tax.pay.register.startdate';
    else
        ld_startdate := trunc(sysdate);

        insert into corpint.tbl_configuration (key, value)
        values ('tax.pay.register.startdate', to_char(ld_startdate, 'yyyymmdd hh24:mi:ss'));
    end if;

    -- Get last end date or init
    select count(1) into ln_count
    from corpint.tbl_configuration
    where key='tax.pay.register.enddate';

    if (ln_count > 0) then
        select to_date(value, 'yyyymmdd hh24:mi:ss') into ld_enddate
        from corpint.tbl_configuration
        where key='tax.pay.register.enddate';
    else
        ld_enddate := trunc(sysdate)+1;

        insert into corpint.tbl_configuration (key, value)
        values ('tax.pay.register.enddate', to_char(ld_enddate, 'yyyymmdd hh24:mi:ss'));
    end if;

    --ls_result := pkg_soa_inquiry.getTaxPaymentInfo('', '', to_char(ld_startdate, 'yyyymmdd'), to_char(ld_enddate, 'yyyymmdd'), '', pc_result);

    /*if (ls_result <> '000') then
        return '999';
    end if;*/

    -- #1 = <
    -- #2 = >
    -- #3 = </
    -- #4 = />

    ls_xml_data := '#1registry#2';

    open pc_result;
    fetch pc_result into row_pc_result;
    while pc_result%found
    loop
        ln_check_num := row_pc_result.tx_no;
        if instr(row_pc_result.explanation, 'гос. №') > 0 then
            ls_vehicle_plate :=  substr(row_pc_result.explanation, instr(row_pc_result.explanation, 'гос. №')+6, length(row_pc_result.explanation));
        else
            ls_vehicle_plate := '';
        end if;

        ls_xml_data := ls_xml_data || '#1payment tranID=''' || row_pc_result.tx_no || ''' type=''' || pkg_message.split(row_pc_result.tax_address_id, ';', 0) || ''' sum=''' || trim(to_char(row_pc_result.amount, '999999990.99')) || ''' tin=''' || row_pc_result.tax_tin || ''' name=''' || row_pc_result.from_description || ''' rayon=''' || pkg_message.split(row_pc_result.tax_address_id, ';', 3) || ''' okmot=''' || pkg_message.split(row_pc_result.tax_address_id, ';', 4) || ''' date=''' || to_char(row_pc_result.makedate, 'dd.mm.yyyy hh24:mi:ss') || ''' terminalNum=''' || ln_terminal_num || ''' checkNum=''' || ln_check_num || ''' vehicleNum=''' || ls_vehicle_plate || '''#4';

        ln_total_amount := ln_total_amount + row_pc_result.amount;

    fetch pc_result into row_pc_result;
    end loop;
    close pc_result;

    ls_xml_data := ls_xml_data || '#1registrySum#2' || trim(to_char(ln_total_amount, '999999990.99')) || '#3registrySum#2';
    ls_xml_data := ls_xml_data || '#1dateFrom#2' || to_char(ld_startdate, 'dd.mm.yyyy hh24:mi:ss') || '#3dateFrom#2';
    ls_xml_data := ls_xml_data || '#1dateTo#2' || to_char(ld_enddate, 'dd.mm.yyyy hh24:mi:ss') || '#3dateTo#2';
    ls_xml_data := ls_xml_data || '#1operatorNum#2' || ln_operator_num || '#3operatorNum#2';

    ls_xml_data := ls_xml_data || '#3registry#2';

    -- Send xml data to Tax House via WS
    begin

        serviceurl := url_web;

        begin
            namespace := 'http://services.demirbank.kg/';
            methodname := 'Register';
            soapaction := namespace || methodname;
            namespace := 'xmlns="' || namespace || '"';

            --create new request
            req := pkg_soap.new_request(methodname, namespace);

            --add parameters to request
            pkg_soap.add_parameter(req, 'strRegister', 'xsd:string', ls_xml_data);

            --call web service, and get response

            resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
            result := resp.doc.getstringval();
            result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

            l_parser := dbms_xmlparser.newparser;
            dbms_xmlparser.parseclob(l_parser, result);
            l_doc := dbms_xmlparser.getdocument(l_parser);
            l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'RegisterResponse/RegisterResult');
            l_n := dbms_xmldom.item(l_nl, 0);

            -- Use XPATH syntax to assign values to he elements of the collection.
            ps_xml_data := result;

            corpint.pkg_log.addcustomlog('sendTaxHouseReport', substr(ls_xml_data, 1, 1000), substr(ps_xml_data, 1, 1000));

        exception
            when others then
                log_at('sendTaxHouseReport', sqlerrm, dbms_utility.format_error_backtrace);
                return '999';
        end;

    end;

    -- Update start date and end date
    update corpint.tbl_configuration
    set corpint.tbl_configuration.value = to_char( trunc(ld_enddate) + 1, 'yyyymmdd hh24:mi:ss' )
    where key='tax.pay.register.startdate';

    update corpint.tbl_configuration
    set corpint.tbl_configuration.value = to_char( ld_enddate + ln_report_period, 'yyyymmdd hh24:mi:ss' )
    where key='tax.pay.register.enddate';

    return ls_returncode;
exception
    when others then
        log_at('sendTaxHouseReport', sqlerrm, dbms_utility.format_error_backtrace);
        return '999';
end;

/*******************************************************************************
    Name        : FUNCTION notifyCustomer
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial and non-financial transactions
    Purpose     : notify customer about processed transactions
*******************************************************************************/
function notifycustomer(pn_islem_no      in number,
                        pn_islem_kod     in number,
                        pn_musteri_no    in number,
                        ps_eod                in varchar2) return varchar2 is

    ln_musteri_no number;
    ls_musteri_adi varchar2(200);  --bahianab cbs-481 15072021 --varchar2(150);
    ls_baska_musteri_adi varchar2(150);
    ln_islem_no    number;
    ln_visa_islem_no number;
    ln_islem_kod  number;
    ln_cancel_code number;
    ln_satir_numara number;
    ln_fis_numara  number;
    ls_card_no varchar2(100);
    ls_content       clob :='';
    ls_header_1     varchar2(2000);
    ls_header_2     varchar2(2000);
    ls_footer          varchar2(2000);
    ls_divisor         varchar2(500);
    ls_outflows       varchar2(800);
    ls_inflows         varchar2(800);
    ls_other           varchar2(800);
    ls_cbs_codes    varchar2(800);
    ls_card_codes   varchar2(800);
    ls_visa_codes   varchar2(300);
    ls_no_cust_no varchar2(300);
    ls_ib_codes       varchar2(800);
    ls_ib_use_custno_list varchar2(200);
    ls_spec_codes  varchar2(300);
    ls_all_amount_tran varchar2(300);
    ls_incoming_tran varchar2(300);
    ls_outgoing_tran varchar2(300);
    ls_res               varchar2(30);
    ls_isreceiver     varchar2(30);
    ls_country_name varchar2(100);
    ls_merchant_place varchar2(100);
    ls_tran_name varchar2(200);
    ls_template      clob :='';
    ls_fullname       clob :='';
    ls_dates            clob :='';
    ls_no_tran         clob :='';
    ld_start_date      date;
    ld_end_date      date;
    ln_counter        number := 0;
    ln_counter_prev number := 0;
    ls_eow             varchar2(10) := 'H';
    ls_eom             varchar2(10) := 'H';
    ls_sendmobilenotification varchar2(10);
    ls_sender_address varchar2(100);
    ls_unsubscribe_address varchar2(300);
    ls_subject varchar2(200);
    ls_reconno varchar2(100);
    ls_sender_param varchar2(50);
    ls_receiver_param varchar2(50);
    ls_s_service_param varchar2(50);
    ls_r_service_param varchar2(50);
    ls_sender_name varchar2(200);
    ls_receiver_name varchar2(200);
    ls_service_name varchar2(200);
    ln_customer_no cbs_customer_notification.customer_no%type;
    ls_status cbs_customer_notification.status%type;
    ls_cust_outflows cbs_customer_notification.outflows%type;
    ls_cust_inflows cbs_customer_notification.inflows%type;
    ls_cust_other cbs_customer_notification.other%type;
    ls_cust_ads cbs_customer_notification.ads%type;
    ls_frequency cbs_customer_notification.frequency%type;
    ls_cust_email cbs_customer_notification.email%type;
    ls_cust_sms cbs_customer_notification.sms%type;
    ls_cust_push cbs_customer_notification.push%type;
    ls_lang cbs_customer_notification.lang%type;
    -- customer email list
    cursor emailinfo is
        select distinct email
        from cbs_musteri_adres
        where musteri_no = ln_musteri_no and
                    email is not null;

    res_emailinfo emailinfo%rowtype;

    -- customer fx convert setting change
    cursor cust_fx is
        select decode(nvl(m.fx_convert, 'H'), 'E', 'YES', 'NO') fx_convert
        from cbs_musteri m,
                 (select nvl(g.fx_convert, b.fx_convert) fx_convert,
                            nvl(g.musteri_no, b.musteri_no) musteri_no
                 from cbs_musteri_basvuru b,
                         cbs_musteri_guncellenen g
                 where g.musteri_no = b.musteri_no and
                           b.tx_no = (select max(tx_no)
                                           from cbs_musteri_basvuru
                                           where musteri_no = ln_musteri_no) and
                          g.tx_no = (select max(tx_no)
                                           from cbs_musteri_guncellenen
                                           where musteri_no = ln_musteri_no and
                                                     tx_no <> ln_islem_no and
                                                     exists (select numara
                                                                from cbs_islem
                                                                where numara = tx_no))) gb
        where gb.musteri_no = m.musteri_no and
                    gb.fx_convert <> m.fx_convert;

    res_cust_fx cust_fx%rowtype;

    -- customer mobile phone change
    cursor cust_gsm_new is
         select (k.adres_tipi) adres_kod,
                  gsm_alan_kod, gsm_no,
                  gsm_alan_kod_2, gsm_no_2,
                  gsm_alan_kod_3, gsm_no_3
        from cbs_adres_kodlari k
        left join cbs_musteri_adres m
        on k.adres_tipi = m.adres_kod and
            musteri_no = ln_musteri_no
        where ls_sendmobilenotification <> 'NO';

    res_cust_gsm_new cust_gsm_new%rowtype;

    cursor cust_gsm_old is
        select (k.adres_tipi) adres_kod, t.gsm_alan_kod, t.gsm_no, t.gsm_alan_kod_2, t.gsm_no_2, t.gsm_alan_kod_3, t.gsm_no_3
        from cbs_adres_kodlari k
        left join (select nvl(ga.adres_kod, b.adres_kod) adres_kod,
                               nvl(ga.gsm_alan_kod, b.gsm_alan_kod) gsm_alan_kod, nvl(ga.gsm_no, b.gsm_no) gsm_no,
                               nvl(ga.gsm_alan_kod_2, b.gsm_alan_kod_2) gsm_alan_kod_2, nvl(ga.gsm_no_2, b.gsm_no_2) gsm_no_2,
                               nvl(ga.gsm_alan_kod_3, b.gsm_alan_kod_3) gsm_alan_kod_3, nvl(ga.gsm_no_3, b.gsm_no_3) gsm_no_3
                     from cbs_musteri_guncel_adres ga,
                             cbs_musteri_guncellenen g,
                             cbs_musteri_basvuru_adres b
                     where ga.tx_no = g.tx_no and
                               g.musteri_no = ln_musteri_no and
                               g.tx_no = (select max(tx_no)
                                               from cbs_musteri_guncellenen
                                               where musteri_no = ln_musteri_no and
                                               tx_no <> ln_islem_no and
                                               exists (select numara
                                                          from cbs_islem
                                                          where numara = tx_no)) and
                             b.tx_no = (select max(ba.tx_no)
                                                     from cbs_musteri_basvuru ba
                                                     where ba.musteri_no = ln_musteri_no)) t
        on k.adres_tipi = t.adres_kod
        where ls_sendmobilenotification <> 'NO'
        order by k.adres_tipi;

    res_cust_gsm_old cust_gsm_old%rowtype;

    -- customer debit card primary account change
    cursor cust_debit_acc_new is
        select a.account_no, h.doviz_kodu
        from cbs_debit_card_account_tran ta,
                 cbs_hesap h,
                 cbs_debit_card_account a
        left join (select customer_no,
                                  card_no,
                                  card_account_type,
                                  account_no
                        from cbs_debit_card_account_tran
                        where customer_no = ln_musteri_no and
                                  card_account_type = 'PRIMARY' and
                                  tx_no = (select max(tx_no)
                                                 from cbs_debit_card_account_tran
                                                 where tx_no <> ln_islem_no and
                                                           customer_no = ln_musteri_no and
                                                           card_no = ls_card_no)) t
       on t.customer_no = a.customer_no and
             t.card_no = a.card_no
        where a.card_account_type = 'PRIMARY' and
                    a.customer_no = ln_musteri_no and
                    a.card_no = ta.card_no and
                    h.hesap_no = a.account_no and
                    nvl(t.account_no, 0) <> nvl(a.account_no, 0) and
                    ta.card_account_type = a.card_account_type and
                    ta.tx_no = ln_islem_no;

    res_cust_debit_acc_new cust_debit_acc_new%rowtype;

    -- get necessary template
    cursor templateinfo is
        select *
        from cbs_notification_templates
        where tran_code = ln_islem_kod and
                    prepared_for = decode(ls_isreceiver, 'FALSE', 'SENDER', 'TRUE', 'RECEIVER')
        order by order_nbr;

    res_tempinfo templateinfo%rowtype;

    -- get tx_no, tran_code for VISA file procecssing transactions
    cursor specvisatran is
        select f.islem_kod islem_kod,
                    f.tx_no islem_no
        from cbs_atm_file_debit_clearing fd,
                 cbs_atm_finansal_islem f
        where fd.reconno  = ls_reconno and
                    f.referance = fd.reconno;

    res_specvisatran specvisatran%rowtype;

    -- get transaction info for sender and receiver of funds
    cursor traninfo is
        select s.numara,c.kayit_sistem_tarihi, c.kayit_kullanici_kodu, c.islem_kod,
                    nvl(s.hesap_bolum_kodu, c.amir_bolum_kodu) bolum_kodu, s.doviz_kod,
                    case
                        when instr(ls_all_amount_tran, ln_islem_kod) <> 0 then (select sum(dv_tutar) from cbs_satir where fis_islem_numara = s.fis_islem_numara and hesap_numara = s.hesap_numara)
                        else s.dv_tutar
                    end dv_tutar,
                    (substr(to_char(pkg_soa_inquiry.Active_external_hesapno_al(s.hesap_numara)),1,3) || '*****' || substr(to_char(pkg_soa_inquiry.Active_external_hesapno_al(s.hesap_numara)),9,6) || '**') hesap_numara,
                    pkg_hesap.hesaptanmusterinoal(sa.hesap_numara) musteri_numara,
                    pkg_hesap.kullanilabilir_bakiye_al(s.hesap_numara) balance,
                    it.aciklama,
                    decode (ln_islem_kod, 6330, td.kurum_kodu, ta.kurum_kodu) kurum_kodu,
                    decode (ln_islem_kod, 2010 /*2012*/, g.gonderen_adi, ci.from_description) sender_desc,--aisuluud cq 5882 defect 2010 email notification, commented out 2012 and added 2010
                    decode (ln_islem_kod, 4003, ga.bc_isim_adres_1, ci.to_name) receiver_desc,
                    s.dv_tutar settlement_amount, s.doviz_kod  settlement_currency_code,
                    case
                        when instr(ls_spec_codes, to_char(ln_islem_kod)) <> 0 then p.aciklama
                        else f.merchant_location
                    end  merchant_location,
                    case
                        when instr(ls_spec_codes, to_char(ln_islem_kod)) <> 0 then d.card_no
                        else substr(to_char(f.card_number),1,6) || 'XXXXXX' || substr(to_char(f.card_number),13,16)
                    end  card_number
        from cbs_satir s
        left join cbs_islem c
        on c.numara = s.fis_islem_numara
        left join cbs_satir sa
        on sa.fis_islem_numara = ln_islem_no and
             sa.hesap_tur_kodu = 'VS' and
             sa.dv_tutar >= s.dv_tutar and
             sa.doviz_kod = s.doviz_kod and
             sa.tur <> s.tur and
             sa.hesap_numara <> s.hesap_numara
        left join cbs_atm_finansal_islem f
        on f.tx_no = ln_visa_islem_no
        left join cbs_atm_sorgu_islem i
        on c.numara = i.tx_no
        left join cbs_atm_parametre p
        on trim(i.terminal_id) = trim(p.terminal_id)
        left join cbs_islem_tanim it
        on it.kod = ln_islem_kod
        left join cbs_debit_card_account d
        on d.account_no = i.hesap_no
        left join cbs_tahsilat_detay_islem td
        on c.numara = td.islem_no
        left join cbs_tahsilat_iptal_talep_islem ta
        on c.numara = ta.tx_no
        --BOM aisuluud cq 5882 defect 2010 email notification
        --LEFT JOIN cbs_yphavale_gelen_odeme_basvu bg
        --ON bg.tx_no = c.numara
        left join cbs_yphavale_gelen_basvuru bg
        on bg.tx_no = c.numara
        --EOM aisuluud cq 5882 defect 2010 email notification
        left join cbs_yphavale_gelen g
        on g.ref_no = bg.ref_no
        left join cbs_yphavale_giden_acilis ga
        on ga.tx_no = c.numara
        left join cbs_clearing_islem ci
        on ci.tx_no = c.numara
        where s.fis_islem_numara = ln_islem_no and
                    s.fis_tur = 'G' and
                    s.fis_numara = ln_fis_numara and
                    ((s.numara = ln_satir_numara and
                      s.hesap_tur_kodu = 'VS') or
                    (instr(ls_no_cust_no, to_char(ln_islem_kod)) <> 0 and
                    s.numara = 1));

    res_traninfo traninfo%rowtype;

    -- EOD, EOW, EOM: list of transactions with info for necessary period for particular customer
    cursor custtransactions is -- instant financial transactions
        select s.fis_islem_numara islem_no, c.islem_kod, s.numara, s.fis_numara, decode(s.tur, 'B', 'FALSE', 'A', 'TRUE') isreceiver
        from cbs_satir s, cbs_islem c
        where ln_musteri_no is null and
                    s.fis_islem_numara = c.numara  and
                    s.hesap_tur_kodu = 'VS' and
                    c.numara = ln_islem_no and
                    ps_eod = 'H' and
                    (instr(ls_outflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_inflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_other, to_char(c.islem_kod)) <> 0) and
                    lower(s.banka_aciklama) not like '%нсп%' and
                    lower(s.banka_aciklama) not like '%ндс%' and
                    lower(s.banka_aciklama) not like '%комиссия%' and
                    lower(s.banka_aciklama) not like '%коммиссия%' and
                    lower(s.banka_aciklama) not like '%commission%' and
                    lower(s.banka_aciklama) not like '%налог%' and
                    lower(s.banka_aciklama) not like '%tax%' and
                    (c.islem_kod <> 1303 or
                     (lower(s.banka_aciklama) not like '%interest%' and
                     exists(select tutar
                                from cbs_hesap_kredi_islem
                                where tx_no = c.numara and
                                          tutar = s.dv_tutar))) and
                    (c.islem_kod <> 6330 or
                     exists (select tutar
                                  from cbs_tahsilat_detay_islem
                                  where islem_no = c.numara and
                                            tutar = s.dv_tutar)) and
                    (instr(ls_all_amount_tran, c.islem_kod) = 0 or
                      s.numara = (select min(numara)
                                           from cbs_satir
                                           where fis_islem_numara = c.numara and
                                                    hesap_tur_kodu = 'VS')) and
                    (c.islem_kod <> 1203 or
                      exists (select count(distinct(pkg_hesap.hesaptanmusterinoal(hesap_numara)))
                                          from cbs_satir
                                          where fis_islem_numara = c.numara and
                                                    hesap_tur_kodu = 'VS'
                                          having count(distinct(pkg_hesap.hesaptanmusterinoal(hesap_numara))) > 1)) and
                    (c.islem_kod <> 8806 or
                     exists (select fi.customer_no
                                  from cbs_atm_finansal_islem fi,
                                          cbs_debit_card_account da,
                                          cbs_satir sa
                                  where fi.tx_no = c.numara and
                                           sa.fis_islem_numara = fi.tx_no and
                                           sa.hesap_tur_kodu = 'VS' and
                                           fi.customer_no <> pkg_hesap.hesaptanmusterinoal(sa.hesap_numara) and
                                           substr(trim(fi.card_number),1,6) = substr(trim(da.card_no),1,6) and
                                           substr(trim(fi.card_number),13,16) = substr(trim(da.card_no),13,16)))
        union -- instant other transactions
        select c.numara islem_no, c.islem_kod, 0 numara, 0 fis_numara, 'FALSE' isreceiver
        from cbs_islem c
        where c.numara = ln_islem_no and
                    ps_eod = 'H' and
                    (instr(ls_outflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_inflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_other, to_char(c.islem_kod)) <> 0) and
                     not exists (select fis_islem_numara
                                        from cbs_satir s
                                        where    s.fis_islem_numara = c.numara  and
                                                       s.hesap_tur_kodu = 'VS' and
                                                       pkg_hesap.hesaptanmusterinoal(s.hesap_numara) = c.musteri_numara)
        union -- EOD, EOW, EOM financial transactions
        select s.fis_islem_numara islem_no, c.islem_kod, s.numara, s.fis_numara, decode(s.tur, 'B', 'FALSE', 'A', 'TRUE') isreceiver
        from cbs_satir s, cbs_islem c
        where ln_musteri_no is not null and
                    ln_islem_no is null and
                    s.fis_islem_numara = c.numara  and
                    s.hesap_tur_kodu = 'VS' and
                    pkg_hesap.hesaptanmusterinoal(s.hesap_numara) = ln_musteri_no and
                    c.kayit_tarih >= ld_start_date and
                    c.kayit_tarih <= ld_end_date and
                    lower(s.banka_aciklama) not like '%нсп%' and
                    lower(s.banka_aciklama) not like '%ндс%' and
                    lower(s.banka_aciklama) not like '%комиссия%' and
                    lower(s.banka_aciklama) not like '%коммиссия%' and
                    lower(s.banka_aciklama) not like '%commission%' and
                    lower(s.banka_aciklama) not like '%налог%' and
                    lower(s.banka_aciklama) not like '%tax%' and
                    c.durum in ('P', 'N') and
                    ps_eod = 'E' and
                    (instr(ls_outflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_inflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_other, to_char(c.islem_kod)) <> 0) and
                     ((c.islem_kod <> 1303 and
                     lower(s.banka_aciklama) not like '%interest%') or
                     exists(select tutar
                                from cbs_hesap_kredi_islem
                                where tx_no = c.numara and
                                          tutar = s.dv_tutar))
        union -- EOD, EOW, EOM other transactions
        select c.numara islem_no, c.islem_kod, 0 numara, 0 fis_numara, 'FALSE' isreceiver
        from cbs_islem c
        where ln_musteri_no is not null and
                    ln_islem_no is null and
                    c.musteri_numara = ln_musteri_no and
                    c.kayit_tarih >= ld_start_date and
                    c.kayit_tarih <= ld_end_date and
                    c.durum in ('P', 'N') and
                    ps_eod = 'E' and
                    (instr(ls_outflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_inflows, to_char(c.islem_kod)) <> 0 or
                     instr(ls_other, to_char(c.islem_kod)) <> 0) and
                     not exists (select fis_islem_numara
                                        from cbs_satir s
                                        where    s.fis_islem_numara = c.numara  and
                                                       s.hesap_tur_kodu = 'VS' and
                                                       pkg_hesap.hesaptanmusterinoal(s.hesap_numara) = ln_musteri_no)
        union -- Internet Banking instant transactions
        select 0 islem_no, pn_islem_kod islem_kod, 0 numara, 0 fis_numara, 'FALSE' isreceiver
        from dual
        where instr(ls_ib_codes, to_char(pn_islem_kod)) <> 0 and
                    ps_eod = 'H'
        union
        select 0 islem_no,
                    case
                        when ch.tran_cd = 'ADDTKN' then 15500
                        when ch.tran_cd = 'DELTOK' then 15600
                        when ch.tran_cd = 'OTPSET' and it.pwd_type = 'PWD_SMS' then 15700
                        when ch.tran_cd = 'OTPSET' and it.pwd_type = 'PWD_PIN_ALWAYS' then 15800
                    end islem_kod,
                    0 numara,
                    0 fis_numara,
                    'FALSE' isreceiver
        from (select decode(a.tran_cd, 'OTPSET', 1, 2) ordering,
                            a.tran_cd,
                            max(a.actv_nbr),
                            a.field1
                 from corpint.tbl_activity a
                 left join corpint.tbl_identification i
                 on instr(i.token_id,a.field1) > 0
                 left join corpint.tbl_person p
                 on p.customer_id = ln_musteri_no
                 where a.field1 is not null and
                            a.actv_time >= ld_start_date and
                            a.actv_time <= ld_end_date and
                            a.error_cd = '000' and
                            ((a.tran_cd = 'OTPSET' and a.page_id = 3) or
                            a.page_id = 0) and
                            ((a.tran_cd in ('OTPSET', 'DELTOK') and a.field1 = p.person_id) or
                              (a.tran_cd = 'ADDTKN' and i.token_id is not null))
                 group by a.tran_cd, a.field1
                 order by ordering, max(a.actv_nbr) desc) ch
        left join corpint.tbl_identification it
        on it.person_id = ch.field1
        where ps_eod = 'E' and
                    ln_musteri_no is not null and
                    rownum <= 2;

    res_custtrans custtransactions%rowtype;
    ls_fx_template varchar2(500);
    ls_gsm_template varchar2(500);
    ls_link varchar2(500);
    ls_ref_result varchar2(10);
    ref_cursor cursorreferencetype;
    ls_rcode varchar2(100);
    ls_rdesc varchar2(150);
    ls_cardno varchar2(100);
    ls_product_code varchar2(150);
    ls_custno varchar2(100);
    ls_emboss_name varchar2(200);
    ls_attach_type varchar2(300); -- AdiletK 17.08.2015 CQ4941 email with attachments
    ls_mail_body varchar2(2000); -- AdiletK 17.08.2015 CQ4941 email with attachments
begin
    -- get mail header, footer and divisor between transactions
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_HEADER_1', ls_header_1);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_HEADER_2', ls_header_2);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_FOOTER', ls_footer);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_DIVISOR', ls_divisor);
    pkg_parametre.deger('CUST_NOTIFICATION_SENDER', ls_sender_address);
    pkg_parametre.deger('CUST_NOTIFICATION_SUBJECT', ls_subject);
    pkg_parametre.deger('CUST_NOTIFICATION_UNSUBSCRIBE', ls_unsubscribe_address);
    pkg_parametre.deger('CUSTOMER_NOTIFY_ATTACHMENT', ls_attach_type); -- AdiletK 17.08.2015 CQ4941 email with attachments
    pkg_parametre.deger('CUSTOMER_NOTIFY_MAIL_BODY', ls_mail_body);     -- AdiletK 17.08.2015 CQ4941 email with attachments
    -- get list of transactions for outflows, inflows, other
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_OUTFLOWS', ls_outflows);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_INFLOWS', ls_inflows);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_OTHER', ls_other);
    --get list of transactions taking place in CBS, Card Operations and Internet Banking
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_CBS', ls_cbs_codes);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_CARD', ls_card_codes);
    pkg_parametre.deger('CUST_NOTIFICATION_IB_CODES', ls_ib_codes);
    pkg_parametre.deger('CUST_NOTIFICATION_VISA_CODES', ls_visa_codes);
    pkg_parametre.deger('CUST_NOTIFICATION_NO_CUST_NO', ls_no_cust_no);
    pkg_parametre.deger('CUST_NOTIFICATION_SPEC_CODES', ls_spec_codes);
    pkg_parametre.deger('CUST_NOTIFY_IB_USE_CUSTNO', ls_ib_use_custno_list);
    pkg_parametre.deger('CUST_NOTIFICATION_CANCEL', ln_cancel_code);
    pkg_parametre.deger('CUST_NOTIFY_ALL_TRAN', ls_all_amount_tran);
    pkg_parametre.deger('CUST_NOTIFY_INCOME_TRAN', ls_incoming_tran);
    pkg_parametre.deger('CUST_NOTIFY_OUTGOING_TRAN', ls_outgoing_tran);

    pkg_parametre.deger('CUST_NOTIFY_SENDER', ls_sender_param);
    pkg_parametre.deger('CUST_NOTIFY_RECEIVER', ls_receiver_param);
    pkg_parametre.deger('CUST_NOTIFY_SERVICE_S', ls_s_service_param);
    pkg_parametre.deger('CUST_NOTIFY_SERVICE_R', ls_r_service_param);

    ln_musteri_no := pn_musteri_no;

    geteoweom(ls_eow, ls_eom);

    if ps_eod = 'E' then
       begin
            select customer_no, status, outflows, inflows, other,
                         ads, frequency, email, sms, push, lang
            into ln_customer_no, ls_status, ls_cust_outflows, ls_cust_inflows, ls_cust_other,
                     ls_cust_ads, ls_frequency, ls_cust_email, ls_cust_sms, ls_cust_push, ls_lang
            from cbs_customer_notification
            where customer_no = ln_musteri_no;
       exception when no_data_found then
            ln_customer_no := 0; ls_status := ''; ls_cust_outflows:= ''; ls_cust_inflows := ''; ls_cust_other := '';
             ls_cust_ads := ''; ls_frequency := ''; ls_cust_email := ''; ls_cust_sms := ''; ls_cust_push := ''; ls_lang := '';
       end;

         -- set time period for the list of transactions
        if ls_frequency = 'EOD' and ps_eod = 'E' then
            ld_start_date := pkg_muhasebe.onceki_banka_tarihi_bul;
            ld_end_date  := pkg_muhasebe.banka_tarihi_bul;
        elsif ls_frequency = 'EOW' and ls_eow = 'E' and ps_eod = 'E' then
            pkg_parametre.deger('CUST_NOTIFICATION_START_EOW', ld_start_date);
            pkg_parametre.deger('CUST_NOTIFICATION_END_EOW', ld_end_date);
        elsif ls_frequency = 'EOM' and ls_eom = 'E' and ps_eod = 'E' then
            pkg_parametre.deger('CUST_NOTIFICATION_START_EOM', ld_start_date);
            pkg_parametre.deger('CUST_NOTIFICATION_END_EOM', ld_end_date);
        else
            ld_start_date := null;
            ld_end_date := null;
        end if;

        pkg_parametre.deger('CUSTOMER_NOTIFICATION_DATES', ls_dates);
        ls_dates := pkg_soa_common.text_translation(ls_dates, ls_lang);
        ls_dates := regexp_replace(to_char(ls_dates), ';', ld_start_date, 1, 1);
        ls_dates := regexp_replace(to_char(ls_dates), ';', ld_end_date, 1, 1);
        ls_content := ls_header_1 || ls_header_2;
        if ls_lang = 'RUS' then
            ls_musteri_adi := pkg_musteri.sf_musteri_adi(ln_musteri_no);
        else
            ls_musteri_adi := pkg_musteri.sf_musteri_eng_adi(ln_musteri_no);
        end if;
        pkg_parametre.deger('CUSTOMER_NOTIFICATION_FULLNAME', ls_fullname);
        ls_fullname := pkg_soa_common.text_translation(ls_fullname, ls_lang);
        ls_fullname := regexp_replace(to_char(ls_fullname), ';', ls_musteri_adi, 1, 1);
        ls_content := ls_content || ls_fullname || ls_dates;
    end if;

    ld_start_date := pkg_muhasebe.onceki_banka_tarihi_bul;
    ld_end_date  := pkg_muhasebe.banka_tarihi_bul;
    ln_islem_no := pn_islem_no;

    open custtransactions;
    fetch custtransactions into res_custtrans;
    while custtransactions%found
    loop -- going through each transaction for the given period
        -- next transaction with information
        ln_islem_no  := res_custtrans.islem_no;
        ln_visa_islem_no := ln_islem_no;
        ln_islem_kod := res_custtrans.islem_kod;
        ln_satir_numara := res_custtrans.numara;
        ln_fis_numara := res_custtrans.fis_numara;
        ls_isreceiver := res_custtrans.isreceiver;
        ln_counter := 0;
        if instr(ls_visa_codes, to_char(ln_islem_kod)) <> 0 then -- changing tx_no and tran_code for VISA file processing related transactions
            begin
                select substr(banka_aciklama, instr(lower(banka_aciklama), 'reference'), length(banka_aciklama))
                into ls_reconno
                from cbs_satir
                where fis_islem_numara = ln_islem_no and
                            numara = 1;
            exception when others then
                ls_reconno := '';
            end;

            if length(ls_reconno) > 1 then
                ls_reconno := substr(ls_reconno, instr(ls_reconno, ':')+1, length(ls_reconno));
            end if;
            open specvisatran;
            fetch specvisatran into res_specvisatran;
            if (specvisatran%found) then
                ln_visa_islem_no := res_specvisatran.islem_no;
                ln_islem_kod := res_specvisatran.islem_kod;
            end if;
            close  specvisatran;
        end if;

        if pn_islem_kod = ln_cancel_code  then
            ln_islem_kod := ln_cancel_code;
        end if;

        if ln_satir_numara = 0 and pn_musteri_no is null then
            begin
                if instr(ls_no_cust_no, to_char(ln_islem_kod)) <> 0 then
                    select card_number
                    into ls_card_no
                    from cbs_atm_finansal_islem
                    where tx_no = ln_islem_no;
                    --ls_ref_result := cbs.pkg_soa_inquiry.getCreditCardOwnerNo(trim(ls_card_no), ref_cursor);
                    fetch ref_cursor into ls_custno;
                    if ref_cursor%notfound then
                        ln_musteri_no := 0;
                        close ref_cursor;
                    else
                        ln_musteri_no := to_number(ls_custno);
                        close ref_cursor;
                    end if;
                else
                    select musteri_numara
                    into ln_musteri_no
                    from cbs_islem
                    where numara = ln_islem_no;
                end if;
            exception when others then
                ln_musteri_no := 0;
                log_at('notifyCustomer', 'Customer_no' || pn_islem_no, sqlerrm, dbms_utility.format_error_backtrace);
            end;
        elsif instr(ls_ib_codes, to_char(ln_islem_kod)) <> 0 and instr(ls_ib_use_custno_list, to_char(ln_islem_kod)) = 0 and ps_eod = 'H' then
             ln_musteri_no := corpint.pkg_customer.getcustomerid(pn_musteri_no);
        elsif pn_musteri_no is null then
            begin
                select pkg_hesap.hesaptanmusterinoal(hesap_numara)
                into ln_musteri_no
                from cbs_satir
                where fis_islem_numara = ln_islem_no and
                          numara = ln_satir_numara and
                          fis_numara = ln_fis_numara and
                          hesap_tur_kodu = 'VS' and
                          fis_tur = 'G';
            exception when no_data_found then
                ln_musteri_no := 0;
            end;
        end if;
        if ps_eod = 'H' then
           begin
                select customer_no, status, outflows, inflows, other,
                             ads, frequency, email, sms, push, lang
                into ln_customer_no, ls_status, ls_cust_outflows, ls_cust_inflows, ls_cust_other,
                         ls_cust_ads, ls_frequency, ls_cust_email, ls_cust_sms, ls_cust_push, ls_lang
                from cbs_customer_notification
                where customer_no = ln_musteri_no;
           exception when no_data_found then
                ln_customer_no := 0; ls_status := ''; ls_cust_outflows:= ''; ls_cust_inflows := ''; ls_cust_other := '';
                 ls_cust_ads := ''; ls_frequency := ''; ls_cust_email := ''; ls_cust_sms := ''; ls_cust_push := ''; ls_lang := '';
           end;
        end if;

        if ls_status = 'A' and ((ps_eod = 'E' and ls_frequency <> 'NOW') or (ps_eod = 'H' and ls_frequency = 'NOW')) then
            if ln_counter_prev > 0 and ps_eod = 'E' then
                ls_content := ls_content || ls_divisor;
            elsif ps_eod = 'H' then
                ls_content:= ls_header_1 || ls_header_2;
            end if;

            open templateinfo;
            fetch templateinfo into res_tempinfo;
            while templateinfo%found
            loop
                if res_tempinfo.notification_type = 'EMAIL' and ls_cust_email = 'E' then
                    if res_tempinfo.lang = 'ENG' then
                        ls_musteri_adi := pkg_musteri.sf_musteri_eng_adi (ln_musteri_no);
                    else
                        ls_musteri_adi := pkg_musteri.sf_musteri_adi(ln_musteri_no);
                    end if;
                    ls_template := regexp_replace(to_char(res_tempinfo.template_body), ';;', ls_musteri_adi, 1, 1);
                    ls_template := regexp_replace(to_char(ls_template), '!!', ls_unsubscribe_address, 1, 1);
                    open traninfo; -- get transaction info for sender of funds
                    fetch traninfo into res_traninfo;
                    if instr(ls_outflows, to_char(ln_islem_kod)) <> 0 and ls_isreceiver = 'FALSE' and ls_cust_outflows = 'E' then

                        if instr(ls_cbs_codes, to_char(ln_islem_kod)) <> 0  then
                            ls_tran_name := pkg_soa_common.text_translation(res_traninfo.aciklama, res_tempinfo.lang);
                            if res_tempinfo.lang = 'ENG' then
                                ls_baska_musteri_adi := pkg_musteri.sf_musteri_eng_adi (res_traninfo.musteri_numara);
                            else
                                ls_baska_musteri_adi := pkg_musteri.sf_musteri_adi(res_traninfo.musteri_numara);
                            end if;
                            if res_traninfo.musteri_numara is not null then
                                if ln_islem_kod = 6330 then
                                    if res_tempinfo.lang = 'KGZ' then
                                         ls_service_name := res_traninfo.kurum_kodu || ' ' || pkg_soa_common.text_translation(ls_s_service_param, res_tempinfo.lang);
                                    else
                                         ls_service_name := pkg_soa_common.text_translation(ls_s_service_param, res_tempinfo.lang) || ' ' || res_traninfo.kurum_kodu;
                                    end if;
                                else
                                    if res_tempinfo.lang = 'KGZ' then
                                        ls_receiver_name := ls_baska_musteri_adi || ' ' || pkg_soa_common.text_translation(ls_receiver_param, res_tempinfo.lang);
                                    else
                                        ls_receiver_name := pkg_soa_common.text_translation(ls_receiver_param, res_tempinfo.lang) || ' ' || ls_baska_musteri_adi;
                                    end if;
                                end if;
                            else
                                ls_receiver_name := '';
                            end if;
                            if instr(ls_outgoing_tran, to_char(ln_islem_kod)) <> 0 then
                                if res_tempinfo.lang = 'KGZ' then
                                    ls_receiver_name := res_traninfo.receiver_desc || ' ' || pkg_soa_common.text_translation(ls_receiver_param, res_tempinfo.lang);
                                else
                                    ls_receiver_name := pkg_soa_common.text_translation(ls_receiver_param, res_tempinfo.lang) || ' ' || res_traninfo.receiver_desc;
                                end if;
                            end if;
                            if res_tempinfo.lang = 'KGZ' then
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.hesap_numara), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(case ln_islem_kod when 6330 then ls_service_name else ls_receiver_name end), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.kayit_sistem_tarihi, 'DD.MM.YYYY HH24:MI:SS'), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', trim(to_char(res_traninfo.dv_tutar,'FM999G999G999G999G999G999G999G999G999D00') || ' ' || res_traninfo.doviz_kod), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(ls_tran_name), 1, 1);
                            else
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.hesap_numara), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(ls_tran_name), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(case ln_islem_kod when 6330 then ls_service_name else ls_receiver_name end), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.kayit_sistem_tarihi, 'DD.MM.YYYY HH24:MI:SS'), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', trim(to_char(res_traninfo.dv_tutar,'FM999G999G999G999G999G999G999G999G999D00') || ' ' ||  res_traninfo.doviz_kod), 1, 1);
                            end if;
                            ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.hesap_numara), 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';;', trim(to_char(res_traninfo.balance,'FM999G999G999G999G999G999G999G999G999D00') || ' ' ||  res_traninfo.doviz_kod), 1, 1);
                        elsif instr(ls_card_codes, to_char(ln_islem_kod)) <> 0 then
                            if instr(ls_spec_codes, to_char(ln_islem_kod)) <> 0 then
                                ls_country_name := pkg_soa_common.text_translation(pkg_genel.ulke_adi_al_hatasiz('KG'), 'RUS');
                                ls_merchant_place := res_traninfo.merchant_location;
                            else
                                ls_country_name := pkg_soa_common.text_translation(pkg_genel.ulke_adi_al_hatasiz(substr(rtrim(res_traninfo.merchant_location), -2, 2)), 'RUS');
                                ls_merchant_place := substr(rtrim(res_traninfo.merchant_location), 1, length(rtrim(res_traninfo.merchant_location))-2);
                            end if;
                            ls_template := regexp_replace(to_char(ls_template), ';', to_char(res_traninfo.card_number), 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', to_char(res_traninfo.kayit_sistem_tarihi, 'DD.MM.YYYY HH24:MI:SS'), 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', to_char(res_traninfo.settlement_amount,'FM999G999G999G999G999G999G999G999G999D00') || ' ' || res_traninfo.settlement_currency_code, 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', case res_traninfo.kayit_kullanici_kodu when 'CINT_CALLER' then pkg_soa_common.text_translation('Internet Banking', ls_lang) when 'ATM' then 'ATM/POS/VISA' else pkg_soa_common.text_translation('Bank System', ls_lang) end, 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', ls_merchant_place, 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', ls_country_name, 1, 1);
                        end if;
                        --CLOSE tranInfoSender;
                        ln_counter := ln_counter + 1;
                    elsif instr(ls_inflows, to_char(ln_islem_kod)) <> 0 and ls_isreceiver = 'TRUE' and ls_cust_inflows = 'E' then
                        --OPEN tranInfoReceiver; -- get transaction info for receiver of funds
                        --FETCH tranInfoReceiver INTO res_tranInfoReceiver;
                        if instr(ls_cbs_codes, to_char(ln_islem_kod)) <> 0  then
                            ls_tran_name := pkg_soa_common.text_translation(res_traninfo.aciklama, res_tempinfo.lang);
                            if res_tempinfo.lang = 'ENG' then
                                ls_baska_musteri_adi := pkg_musteri.sf_musteri_eng_adi (res_traninfo.musteri_numara);
                            else
                                ls_baska_musteri_adi := pkg_musteri.sf_musteri_adi(res_traninfo.musteri_numara);
                            end if;
                            if res_traninfo.musteri_numara is not null then
                                if ln_islem_kod = 6331 then
                                    if res_tempinfo.lang = 'KGZ' then
                                         ls_service_name := res_traninfo.kurum_kodu || ' ' || pkg_soa_common.text_translation(ls_r_service_param, res_tempinfo.lang);
                                    else
                                         ls_service_name := pkg_soa_common.text_translation(ls_r_service_param, res_tempinfo.lang) || ' ' || res_traninfo.kurum_kodu;
                                    end if;
                                else
                                    if res_tempinfo.lang = 'KGZ' then
                                        ls_sender_name := ls_baska_musteri_adi || ' ' || pkg_soa_common.text_translation(ls_sender_param, res_tempinfo.lang);
                                    else
                                        ls_sender_name := pkg_soa_common.text_translation(ls_sender_param, res_tempinfo.lang) || ' ' || ls_baska_musteri_adi;
                                    end if;
                                end if;
                            else
                                ls_sender_name := '';
                            end if;
                            if instr(ls_incoming_tran, to_char(ln_islem_kod)) <> 0 then
                                if res_tempinfo.lang = 'KGZ' then
                                    ls_sender_name := res_traninfo.sender_desc || ' ' || pkg_soa_common.text_translation(ls_sender_param, res_tempinfo.lang);
                                else
                                    ls_sender_name := pkg_soa_common.text_translation(ls_sender_param, res_tempinfo.lang) || ' ' || res_traninfo.sender_desc;
                                end if;
                            end if;
                            if res_tempinfo.lang = 'KGZ' then
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.hesap_numara), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(case ln_islem_kod when 6331 then ls_service_name else ls_sender_name end), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.kayit_sistem_tarihi, 'DD.MM.YYYY HH24:MI:SS'), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', trim(to_char(res_traninfo.dv_tutar,'FM999G999G999G999G999G999G999G999G999D00') || ' ' || res_traninfo.doviz_kod), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(ls_tran_name), 1, 1);
                            else
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.hesap_numara), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(ls_tran_name), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.kayit_sistem_tarihi, 'DD.MM.YYYY HH24:MI:SS'), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', trim(to_char(res_traninfo.dv_tutar,'FM999G999G999G999G999G999G999G999G999D00') || ' ' || res_traninfo.doviz_kod), 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';;', to_char(case ln_islem_kod when 6331 then ls_service_name else ls_sender_name end), 1, 1);
                            end if;
                            ls_template := regexp_replace(to_char(ls_template), ';;', to_char(res_traninfo.hesap_numara), 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';;', trim(to_char(res_traninfo.balance,'FM999G999G999G999G999G999G999G999G999D00') || ' ' || res_traninfo.doviz_kod), 1, 1);
                        elsif instr(ls_card_codes, to_char(ln_islem_kod)) <> 0 then
                            if instr(ls_spec_codes, to_char(ln_islem_kod)) <> 0 then
                                ls_country_name := pkg_soa_common.text_translation(pkg_genel.ulke_adi_al_hatasiz('KG'), 'RUS');
                                ls_merchant_place := res_traninfo.merchant_location;
                            else
                                ls_country_name := pkg_soa_common.text_translation(pkg_genel.ulke_adi_al_hatasiz(substr(rtrim(res_traninfo.merchant_location), -2, 2)), 'RUS');
                                ls_merchant_place := substr(rtrim(res_traninfo.merchant_location), 1, length(rtrim(res_traninfo.merchant_location))-2);
                            end if;
                            ls_template := regexp_replace(to_char(ls_template), ';', to_char(res_traninfo.card_number), 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', to_char(res_traninfo.kayit_sistem_tarihi, 'DD.MM.YYYY HH24:MI:SS'), 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', to_char(res_traninfo.settlement_amount,'FM999G999G999G999G999G999G999G999G999D00') || ' ' || res_traninfo.settlement_currency_code, 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', case res_traninfo.kayit_kullanici_kodu when 'CINT_CALLER' then pkg_soa_common.text_translation('Internet Banking', ls_lang) when 'ATM' then 'ATM/POS/VISA' else pkg_soa_common.text_translation('Bank System', ls_lang) end, 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', ls_merchant_place, 1, 1);
                            ls_template := regexp_replace(to_char(ls_template), ';', ls_country_name, 1, 1);
                        end if;
                        --CLOSE tranInfoReceiver;
                        ln_counter := ln_counter + 1;
                    elsif instr(ls_other, to_char(ln_islem_kod)) <> 0 and ls_cust_other = 'E' then
                        if ln_islem_kod = 1001 then
                            pkg_parametre.deger('SEND_MOBILE_NOTIFY', ls_sendmobilenotification);
                            pkg_parametre.deger('CUST_NOTIFICATION_FX_TEMP', ls_fx_template);
                            ls_fx_template := pkg_soa_common.text_translation(ls_fx_template, ls_lang);
                            open cust_fx; -- get fx_convert new setting
                            fetch cust_fx into res_cust_fx;
                            while cust_fx%found
                            loop
                                ls_fx_template := regexp_replace(to_char(ls_fx_template), ';', res_cust_fx.fx_convert, 1, 1);
                                ls_template := ls_template || ls_fx_template;
                                ln_counter := ln_counter + 1;
                            fetch cust_fx into res_cust_fx;
                            end loop;
                            close cust_fx;

                            open cust_gsm_old; -- get old and old gsm numbers
                            fetch cust_gsm_old into res_cust_gsm_old;

                            open cust_gsm_new; -- get old and new gsm numbers
                            fetch cust_gsm_new into res_cust_gsm_new;
                            while cust_gsm_new%found
                            loop
                                if (nvl(res_cust_gsm_new.gsm_alan_kod,'0') <> nvl(res_cust_gsm_old.gsm_alan_kod,'0')) or (nvl(res_cust_gsm_new.gsm_no, '0') <> nvl(res_cust_gsm_old.gsm_no,'0'))  then
                                    if res_cust_gsm_old.gsm_no is not null and res_cust_gsm_new.gsm_no is not null then
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_CHANGE_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_old.gsm_alan_kod || ' ' || res_cust_gsm_old.gsm_no, 1, 1);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_new.gsm_alan_kod || ' ' || res_cust_gsm_new.gsm_no, 1, 1);
                                    elsif res_cust_gsm_old.gsm_no is not null then
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_DELETE_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_old.gsm_alan_kod || ' ' || res_cust_gsm_old.gsm_no, 1, 1);
                                    else
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_ADD_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_new.gsm_alan_kod || ' ' || res_cust_gsm_new.gsm_no, 1, 1);
                                    end if;
                                    ls_template := ls_template || ls_gsm_template;
                                    ln_counter := ln_counter + 1;
                                end if;
                                if (nvl(res_cust_gsm_new.gsm_alan_kod_2,'0') <> nvl(res_cust_gsm_old.gsm_alan_kod_2,'0')) or (nvl(res_cust_gsm_new.gsm_no_2, '0') <> nvl(res_cust_gsm_old.gsm_no_2,'0')) then
                                    if res_cust_gsm_old.gsm_no_2 is not null and res_cust_gsm_new.gsm_no_2 is not null then
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_CHANGE_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_old.gsm_alan_kod_2 || ' ' || res_cust_gsm_old.gsm_no_2, 1, 1);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_new.gsm_alan_kod_2 || ' ' || res_cust_gsm_new.gsm_no_2, 1, 1);
                                    elsif res_cust_gsm_old.gsm_no_2 is not null then
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_DELETE_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_old.gsm_alan_kod_2 || ' ' || res_cust_gsm_old.gsm_no_2, 1, 1);
                                    else
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_ADD_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_new.gsm_alan_kod_2 || ' ' || res_cust_gsm_new.gsm_no_2, 1, 1);
                                    end if;
                                    ls_template := ls_template || ls_gsm_template;
                                    ln_counter := ln_counter + 1;
                                end if;
                                if (nvl(res_cust_gsm_new.gsm_alan_kod_3,'0') <> nvl(res_cust_gsm_old.gsm_alan_kod_3,'0')) or (nvl(res_cust_gsm_new.gsm_no_3,'0') <> nvl(res_cust_gsm_old.gsm_no_3,'0')) then
                                    if res_cust_gsm_old.gsm_no_3 is not null and res_cust_gsm_new.gsm_no_3 is not null then
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_CHANGE_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_old.gsm_alan_kod_3 || ' ' || res_cust_gsm_old.gsm_no_3, 1, 1);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_new.gsm_alan_kod_3 || ' ' || res_cust_gsm_new.gsm_no_3, 1, 1);
                                    elsif res_cust_gsm_old.gsm_no_3 is not null then
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_DELETE_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_old.gsm_alan_kod_3 || ' ' || res_cust_gsm_old.gsm_no_3, 1, 1);
                                    else
                                        pkg_parametre.deger('CUST_NOTIFY_GSM_ADD_TEMP', ls_gsm_template);
                                        ls_gsm_template := pkg_soa_common.text_translation(ls_gsm_template, ls_lang);
                                        ls_gsm_template := regexp_replace(to_char(ls_gsm_template), ';', res_cust_gsm_new.gsm_alan_kod_3 || ' ' || res_cust_gsm_new.gsm_no_3, 1, 1);
                                    end if;
                                    ls_template := ls_template || ls_gsm_template;
                                    ln_counter := ln_counter + 1;
                                end if;

                            fetch cust_gsm_old into res_cust_gsm_old;
                            fetch cust_gsm_new into res_cust_gsm_new;
                            end loop;
                            close cust_gsm_new;
                            close cust_gsm_old;
                        elsif ln_islem_kod = 2304 then
                            begin
                                select card_no
                                into ls_card_no
                                from cbs_debit_card_account_tran
                                where tx_no = ln_islem_no and
                                            card_account_type = 'PRIMARY';
                            exception when no_data_found then
                                ls_card_no := '';
                            end;
                            open cust_debit_acc_new; -- get new account_no and currency code
                            fetch cust_debit_acc_new into res_cust_debit_acc_new;
                            if (cust_debit_acc_new%found) then
                                ls_template := regexp_replace(to_char(ls_template), ';', ls_card_no, 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';', res_cust_debit_acc_new.account_no, 1, 1);
                                ls_template := regexp_replace(to_char(ls_template), ';', res_cust_debit_acc_new.doviz_kodu, 1, 1);
                                ln_counter := ln_counter + 1;
                            end if;
                            close cust_debit_acc_new;
                        elsif instr(ls_ib_codes, to_char(ln_islem_kod)) <> 0 then
                            ln_counter := ln_counter + 1; -- nothing is needed to do, since the template is inheretly complete.
                        end if;
                    end if;
                    close traninfo;
                    if ln_counter > 0 then
                        ls_content := ls_content || ls_template;
                    end if;
                end if;
                if res_tempinfo.notification_type = 'SMS' and ls_cust_sms = 'E' then
                    null; -- not implemented yet
                end if;
                if res_tempinfo.notification_type = 'PUSH' and ls_cust_push = 'E' then
                    null;-- not implemented yet
                end if;
            fetch templateinfo into res_tempinfo;
            end loop;
            close templateinfo;

            if ln_counter > 0 and ps_eod = 'H' then
                  -- Gulira.Sabirova@demirbank.kg;
                open emailinfo;
                fetch emailinfo into res_emailinfo;
                while emailinfo%found
                loop
                    ls_link := cbs.pkg_subscription.encodebase64(ln_musteri_no || ';' || res_emailinfo.email);
                    ls_link := ls_link || get_hash(ln_musteri_no || res_emailinfo.email);
                    ls_content := regexp_replace(to_char(ls_content || ls_footer), '~', ls_link, 1, 0);
                    -- cbs.pkg_email.addtoemailqueue('E-notify', 50, ls_sender_address, res_emailInfo.email , ls_subject, to_char(ls_content), 'HTML');
                    cbs.pkg_email.addtoemailqueue_atc('E-notify', 50, ls_sender_address, res_emailinfo.email , ls_subject, ls_mail_body, ls_attach_type, to_char(ls_content));-- AdiletK 17.08.2015 CQ4941 email with attachments
                    fetch emailinfo into res_emailinfo;
                end loop;
                close emailinfo;
            end if;
        end if;
        fetch custtransactions into res_custtrans;
        ln_counter_prev := ln_counter;
    end loop;

    if custtransactions%isopen then
        close custtransactions;
    end if;

    if ps_eod = 'E' then
        if ln_counter = 0 then
            pkg_parametre.deger('CUSTOMER_NOTIFICATION_NO_TRAN', ls_no_tran);
            ls_no_tran := pkg_soa_common.text_translation(ls_no_tran, ls_lang);
            ls_content := ls_content || ls_no_tran;
        end if;
        --ls_content := ls_content || ls_footer; -- Gulira.Sabirova@demirbank.kg;
        open emailinfo;
        fetch emailinfo into res_emailinfo;
        while emailinfo%found
        loop
            ls_link := cbs.pkg_subscription.encodebase64(ln_musteri_no || ';' || res_emailinfo.email);
            ls_link := ls_link || get_hash(ln_musteri_no || res_emailinfo.email);
            ls_content := regexp_replace(to_char(ls_content || ls_footer), '~', ls_link, 1, 0);
            cbs.pkg_email.addtoemailqueue('E-notify', 50, ls_sender_address, res_emailinfo.email , ls_subject, to_char(ls_content), 'HTML');
            fetch emailinfo into res_emailinfo;
        end loop;
        close emailinfo;
    end if;

    return '';
exception
    when others then
        log_at('notifyCustomer', ln_islem_no || ' ' || ln_musteri_no, sqlerrm, dbms_utility.format_error_backtrace);
        return '999';
end;

/*******************************************************************************
    Name        : FUNCTION addToNotifyList
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : The transaction is added to notification waiting list
*******************************************************************************/
function addtonotifylist(pn_islem_no      in number,
                        pn_islem_kod      in number,
                        pn_musteri_no in number) return varchar2 is
    ls_cbs_codes varchar2(800);
    ls_card_codes varchar2(800);
    ls_other varchar2(800);
    ls_ret varchar2(10) := '000';
    ln_count number := 0;
begin
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_CBS', ls_cbs_codes);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_CARD', ls_card_codes);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_OTHER', ls_other);
    if instr(ls_cbs_codes || ls_card_codes || ls_other, to_char(pn_islem_kod)) <> 0 then
        select count(*)
        into ln_count
        from cbs_notification_list
        where tx_no = pn_islem_no;

        if ln_count = 0 then
            insert into cbs_notification_list (tx_no, tran_code, customer_no, status)
            values (pn_islem_no, pn_islem_kod, pn_musteri_no, 'sWAIT');
        end if;
    end if;
    return ls_ret;
exception when others then
    log_at('addToNotifyList', pn_islem_no || ' ' || pn_islem_kod, sqlerrm, dbms_utility.format_error_backtrace);
    ls_ret := '999';
    return ls_ret;
end;

/*******************************************************************************
    Name        : FUNCTION sendDynamicNotifications
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : notify customer about his/her accounts, obligations or personal information

    Usage: There are two types of dynamic notifications.
                    First type is plain sql select, which the function runs and gets list of customers with
               already formatted emails. Then the function just sends these email one by one in a loop.
                    Second type is a combination of plain sql select and pl/sql block of code. Plain sql
               select returns list of customers, whom the function is going to send the notifications.
               Pl/sql block of code runs in the loop for this customer list. Pl/sql block prepares
               notifications using the template from the sql select.
*******************************************************************************/

function senddynamicnotifications return varchar2 is
    ls_content_eng clob;
    ls_content_rus clob;
    ls_header varchar2(1000);
    ls_footer_eng varchar2(1000);
    ls_footer_rus varchar2(1000);
    ls_divisor varchar2(500);
    ls_subject cbs_dynamic_notification.subject%type;
    ls_customer_name_eng varchar2(300);
    ls_customer_name_rus varchar2(300);
    ls_notification_type cbs_dynamic_notification.notification_type%type;
    ln_tran_code cbs_dynamic_notification.tran_code%type;
    ln_counter number := 0;
    ls_fullname_eng varchar2(500);
    ls_fullname_rus varchar2(500);
    ls_dyn_code varchar2(32000);
    ls_dyn_block varchar2(32000);
    ln_customer_no cbs_customer_notification.customer_no%type;
    ls_email cbs_musteri_adres.email%type;
    ls_lang varchar2(100);
    ls_sender_address varchar2(100);

    cursor c_dynamic_sql is
        select tran_code,
                    notification_type,
                    subject,
                    dynamic_select
        from cbs_dynamic_notification
        where dynamic_block is null and
                    is_eod = 'YES'
        order by tran_code;

    r_dyn_sql c_dynamic_sql%rowtype;

    cursor c_dynamic_block is
        select tran_code,
                    notification_type,
                    subject,
                    dynamic_select,
                    dynamic_block
        from cbs_dynamic_notification
        where dynamic_block is not null and
                    is_eod = 'YES'
        order by tran_code;

    r_dyn_bl c_dynamic_block%rowtype;

    cur_dyn sys_refcursor;
begin
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_HEADER', ls_header);
    pkg_parametre.deger('CUST_NOTIFY_FOOTER_NO_LINK', ls_footer_eng);
    ls_footer_rus := pkg_soa_common.text_translation(ls_footer_eng, 'RUS');
    pkg_parametre.deger('CUST_NOTIFICATION_SENDER', ls_sender_address);
    pkg_parametre.deger('CUSTOMER_NOTIFICATION_DIVISOR', ls_divisor);

    open c_dynamic_sql;
    fetch c_dynamic_sql into r_dyn_sql;
    while c_dynamic_sql%found
    loop
        ls_notification_type := r_dyn_sql.notification_type;
        ln_tran_code := r_dyn_sql.tran_code;
        ls_dyn_code := replace(to_char(r_dyn_sql.dynamic_select), '"', '''');
        if ls_notification_type = 'EMAIL' then
            open cur_dyn for ls_dyn_code;
            fetch cur_dyn into ls_email, ln_customer_no, ls_content_rus, ls_content_eng;
            while cur_dyn%found
            loop
                ls_customer_name_eng :=  pkg_musteri.sf_musteri_eng_adi(ln_customer_no);
                ls_customer_name_rus :=  pkg_musteri.sf_musteri_adi(ln_customer_no);
                pkg_parametre.deger('CUSTOMER_NOTIFICATION_FULLNAME', ls_fullname_eng);
                ls_fullname_rus := pkg_soa_common.text_translation(ls_fullname_eng, 'RUS');
                ls_fullname_eng := regexp_replace(to_char(ls_fullname_eng), ';', ls_customer_name_eng, 1, 1);
                ls_fullname_rus := regexp_replace(to_char(ls_fullname_rus), ';', ls_customer_name_rus, 1, 1);
                ls_subject := to_char(r_dyn_sql.subject);
                ls_content_rus := ls_header ||  ls_fullname_rus || ls_content_rus || ls_footer_rus;
                ls_content_eng := ls_header || ls_fullname_eng || ls_content_eng || ls_footer_eng;
                pkg_email.addtoemailqueue('E-notify', 50, ls_sender_address, ls_email , ls_subject, ls_content_rus || ls_divisor || ls_content_eng, 'HTML');
            fetch cur_dyn into ls_email, ln_customer_no, ls_content_rus, ls_content_eng;
            end loop;
            close cur_dyn;
        elsif ls_notification_type = 'SMS' then -- later development
            null;
        elsif ls_notification_type = 'PUSH' then -- later development
            null;
        end if;
        ln_counter := ln_counter + 1;
    fetch c_dynamic_sql into r_dyn_sql;
    end loop;
    close c_dynamic_sql;

    open c_dynamic_block;
    fetch c_dynamic_block into r_dyn_bl;
    while c_dynamic_block%found
    loop
        ls_notification_type := r_dyn_bl.notification_type;
        ln_tran_code := r_dyn_bl.tran_code;
        ls_dyn_block := replace(to_char(r_dyn_bl.dynamic_block), '"', '''');
        if ls_notification_type = 'EMAIL' then
            execute immediate ls_dyn_block;
            pkg_email.sendautomessages('');
        elsif ls_notification_type = 'SMS' then -- later development
            null;
        elsif ls_notification_type = 'PUSH' then -- later development
            null;
        end if;
        ln_counter := ln_counter + 1;
    fetch c_dynamic_block into r_dyn_bl;
    end loop;
    close c_dynamic_block;

    return '';

    exception
        when others then
            log_at('dynamicNotifications', ln_counter || ' ' ||ln_tran_code || ' ' || ls_notification_type, sqlerrm, dbms_utility.format_error_backtrace);
            return '999';
end;

/*******************************************************************************
    Name        : FUNCTION dynamicTranProcess
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - Processing transactions with additional dynamical steps
    Purpose     : process transaction using dynamic code fragments

    Usage: After each transaction, this process will be called from pkg_muhasebe.muhasebelestir.
    Its main purpose is to give opportunity to run extra functions after the transaction in a
    dynamic way, so that the code of the dynamic function call be easily modified through
    the time period.
*******************************************************************************/

function dynamictranprocess(pn_islem_no      in number,
                        pn_islem_kod     in number,
                        pn_musteri_no    in number) return varchar2 is
    ln_counter number := 0;
    ls_dyn_block varchar2(32000);
    ls_notification_type cbs_dynamic_notification.notification_type%type;

    cursor c_dynamic_block is
        select tran_code,
                    notification_type,
                    subject,
                    dynamic_block
        from cbs_dynamic_notification
        where dynamic_block is not null and
                    is_eod = 'NO' and
                    tran_code = pn_islem_kod
        order by tran_code;

    r_dyn_bl c_dynamic_block%rowtype;
begin
    open c_dynamic_block;
    fetch c_dynamic_block into r_dyn_bl;
    while c_dynamic_block%found
    loop
        ls_notification_type := r_dyn_bl.notification_type;
        if ls_notification_type = 'EMAIL' then
            ls_dyn_block := replace(to_char(r_dyn_bl.dynamic_block), '"', '');     --bahianab cbs-481--ls_dyn_block := replace(to_char(r_dyn_bl.dynamic_block), '"', '''');

            execute immediate ls_dyn_block
            using in pn_islem_no, in pn_islem_kod, in pn_musteri_no;
            ln_counter := ln_counter + 1;
        elsif ls_notification_type = 'SMS' then
            null;
        elsif ls_notification_type = 'PUSH' then
            null;
        end if;
    fetch c_dynamic_block into r_dyn_bl;
    end loop;
    close c_dynamic_block;

    return '';

    exception
        when others then
            log_at('dynamicTranProcess', pn_islem_no || ' ' ||pn_islem_kod || ' ' || pn_musteri_no || ' ' || ln_counter, sqlerrm, dbms_utility.format_error_backtrace);
            return '999';
end;

/*******************************************************************************
    Name        : FUNCTION addToDynamicNotifyList
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - Processing transactions with additional dynamical steps
    Purpose     : add transaction to dynamic processing list
*******************************************************************************/

function addtodynamicnotifylist(pn_islem_no      in number,
                        pn_islem_kod     in number,
                        pn_musteri_no in number) return varchar2 is
    ls_dynamic_codes varchar2(800);
    ls_ret varchar2(10) := '000';
begin
    pkg_parametre.deger('DYNAMIC_PROCESSING_CODES', ls_dynamic_codes);
    if instr(ls_dynamic_codes, to_char(pn_islem_kod)) <> 0 then
        insert into cbs_dynamic_processing_list (tx_no, tran_code, customer_no, status)
        values (pn_islem_no, pn_islem_kod, pn_musteri_no, 'sWAIT');
    end if;
    return ls_ret;
exception when others then
    log_at('addToDynamicNotifyList', pn_islem_no || ' ' || pn_islem_kod, sqlerrm, dbms_utility.format_error_backtrace);
    ls_ret := '999';
    return ls_ret;
end;

/*******************************************************************************
    Name        : PROCEDURE getEowEom
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : get whether it is end of week or/and end of month
*******************************************************************************/

procedure geteoweom(ps_eow in out varchar2,
                                   ps_eom in out varchar2) is
    ld_end_date_eow date;
    ld_end_date_eom date;
    ld_today_date date;
    ln_check number;
begin
    ps_eow := 'H';
    ps_eom := 'H';
    ld_today_date  := pkg_muhasebe.banka_tarihi_bul;

    pkg_parametre.deger('CUST_NOTIFICATION_END_EOW', ld_end_date_eow);
    if ld_today_date >= ld_end_date_eow then
        ps_eow := 'E';
    end if;

    pkg_parametre.deger('CUST_NOTIFICATION_END_EOM', ld_end_date_eom);
    if ld_today_date >= ld_end_date_eom then
        ps_eom := 'E';
    end if;

    exception
        when others then
            log_at('getEowEom', ld_end_date_eow || ' '  || ld_end_date_eom || ' ' || ps_eow || ' ' || ps_eom, sqlerrm, dbms_utility.format_error_backtrace);
end;

/*******************************************************************************
    Name        : PROCEDURE setNextEowEom
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : set new dates for end of week or/and end of month
*******************************************************************************/

procedure setnexteoweom(ps_eow in varchar2,
                                           ps_eom in varchar2) is
    ld_start_date date;
    ld_end_date date;
    ld_today_date date;
    ld_new_end_date date;
begin
    ld_today_date  := pkg_muhasebe.sonraki_banka_tarihi_bul;

    pkg_parametre.deger('CUST_NOTIFICATION_START_EOW', ld_start_date);
    pkg_parametre.deger('CUST_NOTIFICATION_END_EOW', ld_end_date);
    if ps_eow = 'E' then
        ld_new_end_date := pkg_tarih.haftanin_son_is_gunu(ld_today_date);

        if ld_new_end_date = ld_today_date then
            ld_new_end_date := pkg_tarih.haftanin_son_is_gunu(pkg_muhasebe.sonraki_banka_tarihi_bul);
        end if;

        update cbs_parametre
        set deger = to_char(ld_today_date, 'dd/mm/yyyy')
        where kod = 'CUST_NOTIFICATION_START_EOW';

        update cbs_parametre
        set deger = to_char(ld_new_end_date, 'dd/mm/yyyy')
        where kod = 'CUST_NOTIFICATION_END_EOW';
    end if;

    if ps_eom = 'E' then
        ld_new_end_date := pkg_tarih.ayin_son_gunu(ld_today_date);

        pkg_parametre.deger('CUST_NOTIFICATION_END_EOM', ld_end_date);

        if ld_new_end_date = ld_end_date then
            ld_new_end_date := pkg_tarih.ayin_son_gunu(pkg_muhasebe.sonraki_banka_tarihi_bul);
        end if;

        update cbs_parametre
        set deger = to_char(ld_today_date, 'dd/mm/yyyy')
        where kod = 'CUST_NOTIFICATION_START_EOM';

        update cbs_parametre
        set deger = to_char(ld_new_end_date, 'dd/mm/yyyy')
        where kod = 'CUST_NOTIFICATION_END_EOM';
    end if;

    exception
        when others then
            log_at('getEowEom', ld_start_date || ' ' || ld_end_date || ' ' || ps_eow || ' ' || ps_eom, sqlerrm, dbms_utility.format_error_backtrace);
end;

/*******************************************************************************
    Name        : FUNCTION makeWsDealerPayment
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Make ws call to make dealer payment on the Company's Billing System
*******************************************************************************/
function makewsdealerpayment( ps_company_id in varchar2,
                               ps_dealer_id in varchar2,
                               ps_amount in varchar2,
                               ps_currency in varchar2,
                               ps_current_date in varchar2,
                               ps_bank_date in varchar2,
                               ps_cbs_txno in varchar2,
                               pc_ref out cursorreferencetype) return varchar2
is
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_result varchar2(100);
    ls_error_code varchar2(100);
    ls_error_desc varchar2(100);
    ls_dealer_name varchar2(100);
    ls_amount varchar2(100);
    ls_currency varchar2(100);
    ls_date varchar2(100);
    ls_cbs_txno varchar2(100);
    ls_company_txno varchar2(100);
    ls_receipt_no varchar2(100);

    url_web varchar2(200 char);
begin
    pkg_parametre.deger('DEALER_SERVICE_URL', url_web);
    serviceurl := url_web;
    namespace := 'http://services.demirbank.kg/';
    methodname := 'makePayment';
    soapaction := namespace || methodname;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := pkg_soap.new_request(methodname, namespace);

     --add parameters to request
    pkg_soap.add_parameter(req, 'companyId', 'xsd:string', htf.escape_sc(ps_company_id));
    pkg_soap.add_parameter(req, 'dealerAccNo', 'xsd:string', ps_dealer_id);
    pkg_soap.add_parameter(req, 'amount', 'xsd:string',replace(ps_amount,',','.'));
    pkg_soap.add_parameter(req, 'currency', 'xsd:string', ps_currency);
    pkg_soap.add_parameter(req, 'currentDate', 'xsd:string', ps_current_date);
    pkg_soap.add_parameter(req, 'bankDate', 'xsd:string', ps_bank_date);
    pkg_soap.add_parameter(req, 'cbsTxNo', 'xsd:string', ps_cbs_txno);
    --call web service, and get response
    resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
    result := resp.doc.getstringval();
    result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

    l_parser := dbms_xmlparser.newparser;
    dbms_xmlparser.parseclob(l_parser, result);
    l_doc := dbms_xmlparser.getdocument(l_parser);
    l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'makePaymentResponse/makePaymentResult');
    l_n := dbms_xmldom.item(l_nl, 0);

    -- Use XPATH syntax to assign values to he elements of the collection.
    dbms_xslprocessor.valueof(l_n,'Result',ls_result);
    dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_error_code);
    dbms_xslprocessor.valueof(l_n,'ErrorDesc',ls_error_desc);
    dbms_xslprocessor.valueof(l_n,'DealerName',ls_dealer_name);
    dbms_xslprocessor.valueof(l_n,'Amount',ls_amount);
    dbms_xslprocessor.valueof(l_n,'Currency',ls_currency);
    dbms_xslprocessor.valueof(l_n,'Date',ls_date);
    dbms_xslprocessor.valueof(l_n,'CbsTxNo',ls_cbs_txno);
    dbms_xslprocessor.valueof(l_n,'CompanyTxNo',ls_company_txno);
    dbms_xslprocessor.valueof(l_n,'ReceiptNo',ls_receipt_no);

    open pc_ref for
        select ls_result, ls_error_code, ls_error_desc, ls_dealer_name, ls_amount,
                     ls_currency, ls_date, ls_cbs_txno, ls_company_txno, ls_receipt_no
        from dual;

    log_at('makeWsDealerPayment', ps_cbs_txno, substr(req.body, 1, 2000), substr(result, 1, 2000));

    return '000';
exception
    when others then
        log_at('makeWsDealerPayment',result||' - '|| ps_cbs_txno||'###'||ps_company_id||'###'||ps_dealer_id||'###'||ls_result||'###'||ls_error_code||'###'||ls_error_desc, sqlerrm, dbms_utility.format_error_backtrace);
        --Error occured while sending payment to Company's billing system
        open pc_ref for
            select 'ERROR', '355', ls_error_desc, ls_dealer_name, ls_amount,
                         ls_currency, ls_date, ls_cbs_txno, ls_company_txno, ls_receipt_no
            from dual;

        return '000';
end;

/*******************************************************************************
    Name        : FUNCTION cancelWsDealerPayment
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Make ws call to cancel dealer payment on the Company's Billing System
*******************************************************************************/
function cancelwsdealerpayment(ps_company_id in varchar2,
                               ps_dealer_id in varchar2,
                               ps_amount in varchar2,
                               ps_currency in varchar2,
                               ps_current_date in varchar2,
                               ps_bank_date in varchar2,
                               ps_cbs_txno in varchar2,
                               ps_company_txno in varchar2,
                               pc_ref out cursorreferencetype) return varchar2
is
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_result varchar2(100);
    ls_error_code varchar2(100);
    ls_error_desc varchar2(100);
    ls_dealer_name varchar2(100);
    ls_amount varchar2(100);
    ls_currency varchar2(100);
    ls_date varchar2(100);
    ls_cbs_txno varchar2(100);
    ls_company_txno varchar2(100);
    ls_receipt_no varchar2(100);

    url_web varchar2(200 char);
begin
    pkg_parametre.deger('DEALER_SERVICE_URL', url_web);
    serviceurl := url_web;
    namespace := 'http://services.demirbank.kg/';
    methodname := 'cancelPayment';
    soapaction := namespace || methodname;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := pkg_soap.new_request(methodname, namespace);

    --add parameters to request
    pkg_soap.add_parameter(req, 'companyId', 'xsd:string', htf.escape_sc(ps_company_id));
    pkg_soap.add_parameter(req, 'dealerAccNo', 'xsd:string', ps_dealer_id);
    pkg_soap.add_parameter(req, 'amount', 'xsd:string', ps_amount);
    pkg_soap.add_parameter(req, 'currency', 'xsd:string', ps_currency);
    pkg_soap.add_parameter(req, 'currentDate', 'xsd:string', ps_current_date);
    pkg_soap.add_parameter(req, 'bankDate', 'xsd:string', ps_bank_date);
    pkg_soap.add_parameter(req, 'cbsTxNo', 'xsd:string', ps_cbs_txno);
    pkg_soap.add_parameter(req, 'companyTxNo', 'xsd:string', ps_company_txno);

    --call web service, and get response
    resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
    result := resp.doc.getstringval();
    result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

    l_parser := dbms_xmlparser.newparser;
    dbms_xmlparser.parseclob(l_parser, result);
    l_doc := dbms_xmlparser.getdocument(l_parser);
    l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'cancelPaymentResponse/cancelPaymentResult');
    l_n := dbms_xmldom.item(l_nl, 0);

    -- Use XPATH syntax to assign values to he elements of the collection.
    dbms_xslprocessor.valueof(l_n,'Result',ls_result);
    dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_error_code);
    dbms_xslprocessor.valueof(l_n,'ErrorDesc',ls_error_desc);
    dbms_xslprocessor.valueof(l_n,'DealerName',ls_dealer_name);
    dbms_xslprocessor.valueof(l_n,'Amount',ls_amount);
    dbms_xslprocessor.valueof(l_n,'Currency',ls_currency);
    dbms_xslprocessor.valueof(l_n,'Date',ls_date);
    dbms_xslprocessor.valueof(l_n,'CbsTxNo',ls_cbs_txno);
    dbms_xslprocessor.valueof(l_n,'CompanyTxNo',ls_company_txno);
    dbms_xslprocessor.valueof(l_n,'ReceiptNo',ls_receipt_no);

    open pc_ref for
        select ls_result, ls_error_code, ls_error_desc, ls_dealer_name, ls_amount,
                     ls_currency, ls_date, ls_cbs_txno, ls_company_txno, ls_receipt_no
        from dual;

    log_at('cancelWsDealerPayment', ps_cbs_txno, substr(req.body, 1, 2000), substr(result, 1, 2000));

    return '000';
exception
    when others then
        log_at('cancelWsDealerPayment', ps_cbs_txno||'###'||ps_company_txno||'###'||ps_company_id||'###'||ps_dealer_id||'###'||ls_result||'###'||ls_error_code||'###'||ls_error_desc, sqlerrm, dbms_utility.format_error_backtrace);
        --Error occured during transaction cancellation
        open pc_ref for
            select 'ERROR', '353', ls_error_desc, ls_dealer_name, ls_amount,
                         ls_currency, ls_date, ls_cbs_txno, ls_company_txno, ls_receipt_no
            from dual;

        return '000';
end;
--BOM CQ5717 MederT 13012017
/******************************************************************************
   NAME        : FUNCTION makeElcardWSOutcome
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Decrease Elcard Card balance WS
******************************************************************************/
function makeelcardwsoutcome(pn_amount    in number,
                              ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (10);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_OUTCOME_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_OUTCOME_PASS', ls_payinstr_ref);

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'DecreaseAccountBalance';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);
        --Pkg_Soap.add_parameter(req, 'amount', 'xsd:string', trim(replace(replace(to_char(pn_amount, '9999.99'), '.', ''), ',', '')));
        pkg_soap.add_parameter(req, 'amount', 'xsd:string', trim(to_char(pn_amount, '999999999999999.99')));

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'DecreaseAccountBalanceResponse/DecreaseAccountBalanceResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_resultcode;

        log_at('makeElcardWSOutcomeOK', 'account: ' || ps_account_number || ', amount: ' || pn_amount,  substr(req.body,1,2000), substr(result,1,2000));

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('makeElcardWSOutcome', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('makeElcardWSOutcome',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION makeElcardWSIncome
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Increase Elcard Card balance WS
******************************************************************************/
function makeelcardwsincome(pn_amount    in number,
                              ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (10);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_INCOME_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_INCOME_PASS', ls_payinstr_ref);

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'IncreaseAccountBalance';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);
        pkg_soap.add_parameter(req, 'amount', 'xsd:string', trim(to_char(pn_amount, '999999999999999.99')));

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'IncreaseAccountBalanceResponse/IncreaseAccountBalanceResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_resultcode;

        log_at('makeElcardWSIncomeOK', 'account: ' || ps_account_number || ', amount: ' || pn_amount,  substr(req.body,1,2000), substr(result,1,2000));

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('makeElcardWSIncome', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('makeElcardWSIncome',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWS
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS
******************************************************************************/
function checkelcardbalancews(ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_BALCHECK_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_BALCHECK_PASS', ls_payinstr_ref);

    --Check front WS
    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'CheckAccountBalance';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'CheckAccountBalanceResponse/CheckAccountBalanceResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_returncode);
        dbms_xslprocessor.valueof(l_n,'Amount',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('CheckElcardBalanceWS', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('CheckElcardBalanceWS',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWSFront
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS Front
******************************************************************************/
function checkelcardbalancewsfront(ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_BALCHECK_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_BALCHECK_PASS', ls_payinstr_ref);

    --Check front WS
    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'CheckAccountBalanceFront';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'CheckAccountBalanceFrontResponse/CheckAccountBalanceFrontResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_returncode);
        dbms_xslprocessor.valueof(l_n,'Amount',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('CheckElcardBalanceWSFront', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('CheckElcardBalanceWSFront',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWSBack
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS back
******************************************************************************/
function checkelcardbalancewsback(ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_BALCHECK_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_BALCHECK_PASS', ls_payinstr_ref);

    --Check front WS
    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'CheckAccountBalanceBack';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'CheckAccountBalanceBackResponse/CheckAccountBalanceBackResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_returncode);
        dbms_xslprocessor.valueof(l_n,'Amount',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('CheckElcardBalanceWSBack', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('CheckElcardBalanceWSBack',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : PROCEDURE CallElcardWS
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Decrease/Increase Elcard Card balance WS
******************************************************************************/
procedure callelcardws(ps_tur in varchar2,
                          pn_amount    in number,
                          ps_transaction_number in varchar2,
                          ps_account_number in varchar2,
                          pn_fis    in number,
                          pn_numara    in number,
                          pn_tx_no    in number
                          ) is
    type cursorreferencetype is ref cursor;
    pc_ref cursorreferencetype;
    ls_response varchar2(10) := '';
    ls_resultcode varchar2(100) := '';
    ls_errorcode varchar2(100) := '';
    ls_errordesc varchar2(250) := '';
    ln_try_count number := 0;
    ln_done_count number := 0;
    ln_balance number := 0;
    ls_tx varchar2(2000);
    ls_tx_part varchar2(50);
    ld_bal_time date;
    ln_min number := 0;
    ln_max number := 0;

    g_uc_delimiter constant varchar2(3):=pkg_hata.getucpointer;
    g_ara_delimiter constant varchar2(3):=pkg_hata.getdelimiter;
    notenoughbalance      exception;
    balancepending        exception;
    wserror      exception;
begin
    pkg_parametre.deger('ELCARD_ALLOWED_TX', ls_tx);

    if (length(ls_tx) > 0) then
        ls_tx := ls_tx || ',';
        ls_tx_part := substr(ls_tx, instr(ls_tx, to_char(ps_transaction_number)), instr(ls_tx, ',', instr(ls_tx, to_char(ps_transaction_number))) - instr(ls_tx, to_char(ps_transaction_number)));
        if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
            raise_application_error(-20100,g_uc_delimiter || '6177' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);
        else
            if (ls_tx_part like '%D') or (ls_tx_part like '%C') then
                if ((ps_tur = 'A') and (ls_tx_part not like '%C')) or ((ps_tur = 'B') and (ls_tx_part not like '%D')) then
                    raise_application_error(-20100,g_uc_delimiter || '6177' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);
                end if;
            end if;
        end if;
    end if;

    pkg_parametre.deger('ELCARD_DENIED_TX', ls_tx);

    if (length(ls_tx) > 0) then
        if (instr(ls_tx, to_char(ps_transaction_number)) > 0) then
            raise_application_error(-20100,g_uc_delimiter || '6177' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);
        end if;
    end if;

    pkg_parametre.deger('ELCARD_NO_WS_TX', ls_tx);
    ls_tx := ls_tx || ',';


    if (instr(ls_tx, to_char(ps_transaction_number)) = 0) and (ps_tur = 'B') then
        select count(*)
        into ln_done_count
        from cbs_ipc_ws_log
        where tx_no = pn_tx_no and fis_no = pn_fis and satir_no = pn_numara and account_no = ps_account_number
        and amount = pn_amount and tx_code = ps_transaction_number and status = 'A';

        pkg_parametre.deger('ELCARD_SKIP_BALCHECK_ACC', ls_tx);
        ls_tx := ls_tx || ',';

        if (instr(ls_tx, to_char(ps_account_number)) = 0) and (ln_done_count = 0) then

            pkg_parametre.deger('ELCARD_IMMEDIATE_BAL_TX', ls_tx);
            ls_tx := ls_tx || ',';

            while (nvl(ls_response, '0') != '1') and (ln_try_count <= 3)
            loop

                ln_try_count := ln_try_count + 1;

                if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
                    ls_response := pkg_soa_transaction.checkelcardbalancewsfront(ps_account_number, pc_ref);
                else
                    ls_response := pkg_soa_transaction.checkelcardbalancews(ps_account_number, pc_ref);
                end if;

                if (ls_response = '1') then
                    fetch pc_ref
                    into ls_resultcode, ls_errorcode, ls_errordesc;
                    close pc_ref;

                    ln_balance := to_number(trim(ls_resultcode)) / 100;

                    if (ln_balance < pn_amount) then
                        raise notenoughbalance;
                    end if;
                end if;
            end loop;

            if (ls_response != '1') then
                pkg_parametre.deger('ELCARD_IMMEDIATE_BAL_TX', ls_tx);
                ls_tx := ls_tx || ',';

                if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
                    begin
                        select max(create_date)
                        into ld_bal_time
                        from cbs_ipc_balcheck_log
                        where account_no = ps_account_number;
                    exception
                        when others then
                            ld_bal_time := null;
                    end;

                    pkg_parametre.deger('ELCARD_BAL_MIN', ln_min);
                    pkg_parametre.deger('ELCARD_BAL_MAX', ln_max);

                    if (ld_bal_time is not null) and (ld_bal_time + ln_min/1440  < sysdate) and (ld_bal_time + ln_max/1440  > sysdate) then

                        ln_try_count := 0;

                        while (nvl(ls_response, '0') != '1') and (ln_try_count <= 3)
                        loop

                            ln_try_count := ln_try_count + 1;

                            ls_response := pkg_soa_transaction.checkelcardbalancewsback(ps_account_number, pc_ref);

                            if (ls_response = '1') then
                                fetch pc_ref
                                into ls_resultcode, ls_errorcode, ls_errordesc;
                                close pc_ref;

                                ln_balance := to_number(trim(ls_resultcode)) / 100;

                                if (ln_balance < pn_amount) then
                                    raise notenoughbalance;
                                end if;
                            end if;
                        end loop;
                    else
                        --CQ5717 fix. do not insert before min time call
                        if (ld_bal_time is null) or (ld_bal_time + ln_max/1440  < sysdate) then
                            pkg_soa_transaction.insertelcardbalancelog(ps_account_number, 0);
                        end if;

                        raise balancepending;
                    end if;
                end if;
            end if;

            if (ls_response != '1') then
                raise wserror;
            end if;
        end if;
  end if;
exception
    when balancepending then
        raise_application_error(-20100,g_uc_delimiter || '6179' || pkg_hata.getdelimiter || ln_min || pkg_hata.getdelimiter || ln_max || pkg_hata.getucpointer);     --CQ5717 fix
    when notenoughbalance then
        raise_application_error(-20100,g_uc_delimiter || '6052' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);

    when others then
        log_at('CallElcardWS', pn_fis, ps_account_number || ' ' || ls_response || ' ' || ls_resultcode || ' ' || ls_errorcode || ' ' || ls_errordesc);

        pkg_soa_transaction.insertelcardwslog(pn_tx_no, pn_fis, pn_numara, ps_tur, ps_transaction_number, ps_account_number, pn_amount, 'E', 1);

        raise_application_error(-20100,g_uc_delimiter || '6176' || pkg_hata.getdelimiter || ps_account_number || ' ' || sqlerrm || pkg_hata.getucpointer);
end;

/******************************************************************************
   NAME        : PROCEDURE AddElcardWSQueue
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : Add row to WS queue
******************************************************************************/
procedure addelcardwsqueue(ps_transaction_number in varchar2,
                              pn_tx_no    in number,
                              pn_fis    in number
                          ) is
  /*  -- seval.colak  26072021 elcard performance problem old
          cursor c_satirs(pn_islem_numara number, pn_fis number) is
        select s.fis_islem_numara, s.fis_numara, s.numara, s.tur, s.hesap_numara, s.lc_tutar from cbs_satir s
        join cbs_hesap h on h.hesap_no = s.hesap_numara
        where s.fis_islem_numara = nvl(pn_islem_numara, s.fis_islem_numara) and s.fis_numara = nvl(pn_fis, s.fis_numara)
        and (pn_islem_numara is not null or pn_fis is not null)
        and h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and s.fis_tur = 'G'; -- seval.colak  26072021 elcard performance problem
        */  -- seval.colak  26072021 elcard performance problem

     -- seval.colak  26072021 elcard performance problem- new
      cursor c_satirs(pn_islem_numara number, pn_fis number) is
        select s.fis_islem_numara, s.fis_numara, s.numara, s.tur, s.hesap_numara, s.lc_tutar
        from cbs_satir s  ,cbs_hesap h
        where s.fis_islem_numara = pn_islem_numara  and s.fis_numara = pn_fis
              and h.hesap_no = s.hesap_numara
              and h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and s.fis_tur = 'G'
              and s.hesap_tur_kodu ='VS' ;
       -- seval.colak  26072021 elcard performance problem

    ls_tx varchar2(2000);
    ln_done_count number := 0;
    ls_bloke_referans varchar2(100);
    g_uc_delimiter constant varchar2(3):=pkg_hata.getucpointer;
    g_ara_delimiter constant varchar2(3):=pkg_hata.getdelimiter;
begin
    pkg_parametre.deger('ELCARD_NO_WS_TX', ls_tx);

    ls_tx := ls_tx || ',';
    if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
        for r_satir in c_satirs(pn_tx_no, pn_fis)
        loop
        begin
            select count(*)
            into ln_done_count
            from cbs_ipc_ws_log
            where tx_no = pn_tx_no and fis_no = r_satir.fis_numara and satir_no = r_satir.numara and account_no = r_satir.hesap_numara
            and amount = r_satir.lc_tutar and tx_code = ps_transaction_number and status = 'A';

            if (ln_done_count = 0) then
                --if (r_satir.tur = 'A') and (INSTR(ls_tx, to_char(ps_transaction_number)) > 0) then
                if (r_satir.tur = 'A') then
                    ls_bloke_referans := '';
                    pkg_bloke.sp_bloke_yarat(ls_bloke_referans  ,
                                                  pkg_hesap.hesaptanmusterinoal(r_satir.hesap_numara),
                                                  r_satir.hesap_numara,
                                                  'KGS',
                                                  r_satir.lc_tutar,
                                                  33,
                                                  'Elcard Blocking' ,
                                                  pkg_muhasebe.banka_tarihi_bul,
                                                  pkg_muhasebe.banka_tarihi_bul + 40,
                                                  null,
                                                  null);
                else
                    null;
                end if;
                /*
                if ((r_satir.tur = 'A') and (INSTR(ls_tx, to_char(ps_transaction_number)) > 0)) or
                     ((r_satir.tur = 'B') and (INSTR(ls_tx2, to_char(ps_transaction_number)) > 0)) then
                    pkg_soa_transaction.InsertElcardWSLog(pn_tx_no, r_satir.fis_numara, r_satir.numara, r_satir.tur, ps_transaction_number, r_satir.hesap_numara, r_satir.lc_tutar, 'A', 0);
                end if;
                */
                pkg_soa_transaction.insertelcardwslog(pn_tx_no, r_satir.fis_numara, r_satir.numara, r_satir.tur, ps_transaction_number, r_satir.hesap_numara, r_satir.lc_tutar, 'A', 0);
            end if;
        exception
            when others then
                log_at('AddElcardWSQueue', pn_tx_no, r_satir.hesap_numara);

                pkg_soa_transaction.insertelcardwslog(pn_tx_no, r_satir.fis_numara, r_satir.numara, r_satir.tur, ps_transaction_number, r_satir.hesap_numara, r_satir.lc_tutar, 'E', 0);
        end;
        end loop;

        if (ps_transaction_number != 2150) then
            pkg_soa_transaction.processelcardwsqueue(pn_tx_no, pn_fis);
        end if;
    end if;
exception
    when others then
        raise_application_error(-20100,g_uc_delimiter || '6176' ||g_ara_delimiter || ' ' || sqlerrm||g_uc_delimiter);
end;

/******************************************************************************
   NAME        : PROCEDURE InsertElcardWSLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : InsertElcardWSLog
******************************************************************************/
procedure insertelcardwslog(pn_tx_no    in number,
                              pn_fis    in number,
                              pn_numara    in number,
                              ps_tur in varchar2,
                              ps_transaction_number in varchar2,
                              ps_account_number in varchar2,
                              pn_amount    in number,
                              ps_status in varchar2,
                              pn_is_proc    in number
                              ) is
    pragma autonomous_transaction;
begin
    insert into cbs_ipc_ws_log(tx_no, fis_no, satir_no, account_no, amount, tx_code, status, tur, is_proc)
    values (pn_tx_no, pn_fis, pn_numara, ps_account_number, pn_amount,ps_transaction_number, ps_status, ps_tur, pn_is_proc);

    commit;
end;

/******************************************************************************
   NAME        : PROCEDURE UpdateElcardWSLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : UpdateElcardWSLog
******************************************************************************/
procedure updateelcardwslog(pn_tx_no    in number,
                              pn_fis    in number,
                              pn_numara    in number,
                              ps_account_number in varchar2,
                              pn_amount    in number,
                              ps_status in varchar2,
                              pn_is_proc    in number
                              ) is
    pragma autonomous_transaction;
begin
    update cbs_ipc_ws_log
    set is_proc = pn_is_proc, status = ps_status, update_date = sysdate
    where tx_no = pn_tx_no and fis_no = pn_fis and satir_no = pn_numara and account_no = ps_account_number and amount = pn_amount;

    commit;
end;

/******************************************************************************
   NAME        : PROCEDURE InsertElcardBalanceLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : InsertElcardBalanceLog
******************************************************************************/
procedure insertelcardbalancelog(ps_account_number in varchar2,
                              pn_balance    in number
                              ) is
    pragma autonomous_transaction;
begin
    insert into cbs_ipc_balcheck_log(account_no, balance)
    values (ps_account_number, pn_balance);

    commit;
end;

/******************************************************************************
   NAME        : FUNCTION getElcardIPCBalance
   Prepared By : Meder Toitonov
   Date        : 17.02.2017
   Purpose     : get Elcard Card balance WS
******************************************************************************/
function getelcardipcbalance(ps_account_number in varchar2) return number is
    type cursorreferencetype is ref cursor;
    pc_ref cursorreferencetype;
    ls_response varchar2(10);
    ln_balance number := 0;
    ls_resultcode varchar2(100) := '';
    ls_errorcode varchar2(100) := '';
    ls_errordesc varchar2(250) := '';

    g_uc_delimiter constant varchar2(3):=pkg_hata.getucpointer;
    g_ara_delimiter constant varchar2(3):=pkg_hata.getdelimiter;
begin
    ls_response := pkg_soa_transaction.checkelcardbalancews(to_char(ps_account_number), pc_ref);

    if (ls_response = '1') then
        fetch pc_ref
        into ls_resultcode, ls_errorcode, ls_errordesc;
        close pc_ref;

        ln_balance := to_number(trim(ls_resultcode)) / 100;
        ln_balance := pkg_kur.yuvarla(pkg_genel.lc_al, ln_balance);
    end if;

    if (ls_response != '1') then
        log_at('getElcardIPCBalance', ls_response || ' ' || ls_resultcode || ' ' || ls_errorcode || ' ' || ls_errordesc);

        raise_application_error(-20100,g_uc_delimiter || '6176' ||g_ara_delimiter||ps_account_number || ' ' || sqlerrm || g_uc_delimiter);
    end if;

    return ln_balance;
end;

/******************************************************************************
   NAME        : FUNCTION processElcardWSQueue
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : prcoess Elcard WS queue
******************************************************************************/
procedure processelcardwsqueue(pn_tx_no number default null, pn_fis number default null) is

    type cursorreferencetype is ref cursor;
    pc_ref cursorreferencetype;

    cursor c_queue is
    select * from cbs_ipc_ws_log
    where status = 'A' and is_proc = 0 and (sysdate-create_date) < 40
     and tx_no = nvl(pn_tx_no, tx_no) and fis_no = nvl(pn_fis, fis_no)
    order by create_date;

    r_q c_queue%rowtype;

    cursor c_block(pn_account_no number, pn_amount number) is
    select b.* from cbs_bloke b
    where b.bloke_neden_kodu = 33 and b.aciklama = 'Elcard Blocking' and b.durum_kodu = 'A'
    and b.hesap_no = pn_account_no and b.bloke_tutari = pn_amount;

    r_block c_block%rowtype;

    ln_count number := 0;
    ln_is_proc number := 0;
    ln_try_count number;
    ls_response varchar2(10) := '';
begin
    open c_queue;
    fetch c_queue into r_q;

    while  (c_queue%found) and (ln_count <= 1000)
    loop
    begin
        select is_proc
        into ln_is_proc
        from cbs_ipc_ws_log
        where tx_no = r_q.tx_no and fis_no = r_q.fis_no
        and satir_no = r_q.satir_no and account_no = r_q.account_no;

        if (ln_is_proc = 0) then
            pkg_soa_transaction.updateelcardwslog(r_q.tx_no, r_q.fis_no, r_q.satir_no, r_q.account_no, r_q.amount, 'A', 2);

            ls_response := '';
            ln_try_count := 0;
            while (nvl(ls_response, '0') != '1') and (ln_try_count <= 3)
            loop
                ln_try_count := ln_try_count + 1;

                if (r_q.tur = 'A') then
                    ls_response := pkg_soa_transaction.makeelcardwsincome(r_q.amount, r_q.account_no, pc_ref);
                else
                    ls_response := pkg_soa_transaction.makeelcardwsoutcome(r_q.amount, r_q.account_no, pc_ref);
                end if;
            end loop;

            if (ls_response = '1') then
                pkg_soa_transaction.updateelcardwslog(r_q.tx_no, r_q.fis_no, r_q.satir_no, r_q.account_no, r_q.amount, 'A', 1);

                if (r_q.tur = 'A') then
                    open c_block(r_q.account_no, r_q.amount);
                    fetch c_block into r_block;

                    if (c_block%found) then
                       begin
                            pkg_bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                          r_block.musteri_no,
                                                          r_block.hesap_no,
                                                          r_block.doviz_kodu,
                                                          pn_bloke_tutari=>0,
                                                          ps_bloke_neden_kodu=>33,
                                                          ps_aciklama=>'Releasing Elcard Blocking',
                                                          pd_bloke_tarihi=>pkg_muhasebe.banka_tarihi_bul,
                                                          pd_bloke_bitis_tarihi=>pkg_muhasebe.banka_tarihi_bul,
                                                          p_coz_kayit_tarih => pkg_muhasebe.banka_tarihi_bul,
                                                          p_coz_kayit_sistem_tarih     =>sysdate ,
                                                          p_coz_kayit_kullanici_kodu     => pkg_baglam.kullanici_kodu,
                                                          ps_kapama   => 'KAPAMA');

                            commit;
                       exception
                            when others then
                                log_at('processElcardWSQueueBloke', 'referans:' || r_block.bloke_referans || ', acc_no:' || r_q.account_no, sqlerrm, dbms_utility.format_error_backtrace);
                       end;
                    else
                        log_at('processElcardWSQueue', 'tx:' || r_q.tx_no || ', fis:' || r_q.fis_no || ', satir_no:' || r_q.satir_no || ', acc_no:' || r_q.account_no, 'No Elcard Blocking');
                    end if;
                    close c_block;
                end if;

                ln_count := ln_count + 1;
            else
                pkg_soa_transaction.updateelcardwslog(r_q.tx_no, r_q.fis_no, r_q.satir_no, r_q.account_no, r_q.amount, 'A', 0);
            end if;
        end if;

        fetch c_queue into r_q;
    exception
        when others then
            log_at('processElcardWSQueue', 'tx:' || r_q.tx_no || ', fis:' || r_q.fis_no || ', satir_no:' || r_q.satir_no || ', acc_no:' || r_q.account_no, sqlerrm, dbms_utility.format_error_backtrace);
    end;
    end loop;
    close c_queue;
end;
--EOM CQ5717 MederT 13012017
/******************************************************************************
   NAME        : PROCEDURE processElcardWSQueue
   Prepared By : NurmilaZ
   Date        : 26.08.2020
   Purpose     : process Update Customer
******************************************************************************/
function editcustomerelcard(pn_musteri in number, pn_islem_no in varchar2) return number
is
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    ld_starttime date;
    ld_endtime date;
    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ps_result_code varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
    ln_company_no       varchar2(100);
    pn_company_name     varchar2(1000);
    company_name_notfound   exception;

    cursor cur_musteri is
      select '26' as bank_c,
            '01' as groupc,
            nvl(m.isim_eng, ' ') as f_names, --F_NAMES
            nvl(m.soyadi_eng, ' ') as surname, --SURNAME
            nvl((select ulke_a3_kodu from cbs_ulke_kodlari where cbs_ulke_kodlari.ulke_kodu = adr.ulke_kod), ' ') as r_cntry, --R_CNTRY
            case
               when yerlesim_kod = '1' 
                    then m.vergi_no
               else m.pasaport_no 
            end as person_code, --PERSON_CODE --NurmilaZ CBS-640 28032022
            decode (m.cinsiyet_kod,'F','00','M','01') as title, --TITLE
            decode(m.cinsiyet_kod, 'F', '2', '1') as mar_status, --MARITAL_STATUS Семейный статус частного лица (пояснение элемента дано в разделе: 4.1. CUSTOMERS – MARITAL_STATUS)
            null as m_name, --M_NAME null as m_name, --NurmilaZ CBS-600 28032022 
            nvl(pkg_genel.sehir_adi_al_hatasiz(nvl(adr.il_kod, (select b.il_kodu from cbs_bolum b where b.kodu = '060'))), ' ') as r_city, --R_CITY
            nvl(substr(adr.adres, 0, 60), ' ') as r_street, --R_STREET
            nvl(to_char(nvl(adr.email, adr.email)), ' ') as r_emails, --R_E_MAILS
            nvl(to_char(nvl('+996'||adr.gsm_alan_kod || adr.gsm_no, '+996'||adr.gsm_alan_kod || adr.gsm_no)), ' ') as r_mob_phone, --R_MOB_PHONE
            m.pasaport_no as id_card, --ID_CARD
            m.vergi_no as serial_no, --SERIAL_NO
            m.verildigi_yer as issued_by, --ISSUED_BY
            h.hesap_no as account_no --ACCOUNT_NO
     from cbs_musteri m
    join cbs_hesap h on h.musteri_no = m.musteri_no
    left join cbs_musteri_adres adr on adr.musteri_no = m.musteri_no
    where m.musteri_no = pn_musteri
    and h.doviz_kodu = 'KGS'
    and h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and rownum = 1;

    r_app cur_musteri%rowtype;

    ls_emboss_name varchar2(1000);
begin

    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);

        ld_starttime := sysdate;
        namespace := 'http://services.demirbank.kg/';
        methodname := 'EditCustomerElcard';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        -- make suitable emboss name like ours
        select t3.embossname3 into ls_emboss_name from(
        select t2.*, length(t2.embossname2) l2,
            case
                when length(t2.embossname2)>24 and trim(t2.ikinci_isim_eng) is not null then
                    case
                        when upper(substr(trim(t2.isim_eng), 1, 3)) = 'DZH' then substr(trim(t2.isim_eng),1,3) ||'.' ||' '|| trim(t2.soyadi_eng)
                        when upper(substr(trim(t2.isim_eng), 1, 2)) in ('CH', 'ZH', 'SH', 'PH', 'TS', 'KH') then substr(trim(t2.isim_eng),1,2) ||'.' ||' '|| trim(t2.soyadi_eng)
                        else substr(trim(t2.isim_eng),1,1) ||'.' ||' '|| trim(t2.soyadi_eng)
                    end
            else t2.embossname2 end embossname3
        from (
        select t1.*, length(t1.embossname1) l1,
            case
                when length(t1.embossname1)>24 and trim(t1.ikinci_isim_eng) is not null then
                    case
                        when upper(substr(trim(t1.ikinci_isim_eng), 1, 3)) = 'DZH' then trim(trim(t1.isim_eng) || ' '|| substr(trim(t1.ikinci_isim_eng),1,3) ||'.' ||' '|| trim(t1.soyadi_eng))
                        when upper(substr(trim(t1.isim_eng), 1, 2)) in ('CH', 'ZH', 'SH', 'PH', 'TS', 'KH') then trim(trim(t1.isim_eng) || ' '|| substr(trim(t1.ikinci_isim_eng),1,2) ||'.' ||' '|| trim(t1.soyadi_eng))
                        else trim(trim(t1.isim_eng) || ' '|| substr(trim(t1.ikinci_isim_eng),1,1) ||'.' ||' '|| trim(t1.soyadi_eng))
                    end
            else
                case when ikinci_isim_eng is null or length(ikinci_isim_eng)=0 then trim( trim(isim_eng) || ' '|| trim(soyadi_eng))
                else trim(trim(isim_eng) || ' '|| trim(ikinci_isim_eng) ||' '|| trim(soyadi_eng)) end
            end embossname2
        from (
            select musteri_no, campus_id_no, university_code, isim_eng, ikinci_isim_eng, soyadi_eng,
                case when ikinci_isim_eng is null or length(ikinci_isim_eng)=0 then trim( trim(isim_eng) || ' '|| trim(soyadi_eng))
                else trim(trim(isim_eng) || ' '|| trim(ikinci_isim_eng) ||' '|| trim(soyadi_eng)) end embossname1
            from cbs_musteri
            where musteri_no=pn_musteri
        ) t1
        ) t2
        ) t3
        where rownum=1;

        --create new request
        req := pkg_soap.new_request(methodname, namespace);
      for r_app in cur_musteri loop
        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', r_app.account_no);
        pkg_soap.add_parameter(req, 'f_names', 'xsd:string', r_app.f_names);
        pkg_soap.add_parameter(req, 'surname', 'xsd:string', r_app.surname);
        pkg_soap.add_parameter(req, 'r_cntry', 'xsd:string', r_app.r_cntry);
        pkg_soap.add_parameter(req, 'person_code', 'xsd:string', r_app.person_code);
        pkg_soap.add_parameter(req, 'title', 'xsd:string', r_app.title);
        pkg_soap.add_parameter(req, 'mar_status', 'xsd:string', r_app.mar_status);
        pkg_soap.add_parameter(req, 'm_name', 'xsd:string', r_app.m_name);
        pkg_soap.add_parameter(req, 'r_city', 'xsd:string', r_app.r_city);
        pkg_soap.add_parameter(req, 'r_street', 'xsd:string', r_app.r_street);
        pkg_soap.add_parameter(req, 'r_emails', 'xsd:string', r_app.r_emails);
        pkg_soap.add_parameter(req, 'r_mob_phone', 'xsd:string', r_app.r_mob_phone);
        pkg_soap.add_parameter(req, 'id_card', 'xsd:string', r_app.id_card);
        pkg_soap.add_parameter(req, 'serial_no', 'xsd:string', r_app.serial_no);
        pkg_soap.add_parameter(req, 'issued_by', 'xsd:string', r_app.issued_by);
        pkg_soap.add_parameter(req, 'card_name','xsd:string', ls_emboss_name);
      end loop;

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'EditCustomerElcardResponse/EditCustomerElcardResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ps_result_code);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        ld_endtime := sysdate;
        pkg_debit_card.ws_log ('EditCustomerElcard',
                                serviceurl,
                                methodname,
                                ld_starttime,
                                ld_endtime,
                                ps_result_code,
                                ls_errorcode,
                               pn_islem_no,
                                1001,
                                result,
                                req.body);
        return 1;
exception
when company_name_notfound then
        return 0;
        raise_application_error(-20100,pkg_hata.getucpointer || '20010' || pkg_hata.getdelimiter  || ps_result_code||' '||ls_errordesc || pkg_hata.getdelimiter || pkg_hata.getucpointer );
when others then
        return 0;
        ps_result_code:= '999';
        pkg_debit_card.ws_log('EditCustomerElcard',serviceurl,methodname,ld_starttime,ld_endtime,'999 '||utl_http.get_detailed_sqlerrm,sqlcode||' '||sqlerrm || ' ' || dbms_utility.format_error_backtrace,pn_islem_no,1203,result,req.body);
end;
/******************************************************************************
   NAME        : FUNCTION processElcardWSQueue
   Prepared By : NurmilaZ
   Date        : 24072020
   Purpose     : process Elcard ListCustomerCards
******************************************************************************/
procedure getdatabyelcard(pn_customer_no in number)
is

    ls_returncode varchar2(3):='0';
    account_no varchar2(300);
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
    pan varchar2(400 byte);
    risklevel varchar2(10 byte);
    stop_cause varchar2(10 byte);
    expiry varchar2(400 byte);
    ld_starttime date;
    ld_endtime date;
    ln_count number;
    ls_name varchar2(250);
    ls_branch varchar2(10 byte);
    pragma autonomous_transaction;
begin
    ld_starttime := sysdate;

    select hesap_no into account_no from cbs_hesap p    -- seval.colak  26072021 elcard performance problem   --from cbs_vw_hesap_izleme p
        where p.musteri_no = pn_customer_no
        and p.doviz_kodu = 'KGS'
        and p.urun_sinif_kod ='ELCARD NON INT.BR-LC'
        and p.durum_kodu='A';

    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);

        namespace := 'http://services.demirbank.kg/';
        methodname := 'getDatabyElcard';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', account_no);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'getDatabyElcardResponse/getDatabyElcardResult');
        --l_n := dbms_xmldom.item(l_nl, 0);

        select count(*) into ln_count from cbs_elcard where customer_no=pn_customer_no;

        if ln_count>0 then
            delete from cbs_elcard where customer_no=pn_customer_no;
        end if;

        for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1
        loop
            l_n := dbms_xmldom.item (l_nl, cur_emp);
            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueof(l_n, 'Result', ls_returncode);
            dbms_xslprocessor.valueof(l_n, 'Pan', pan);
            dbms_xslprocessor.valueof(l_n, 'Expiry', expiry);
            dbms_xslprocessor.valueof(l_n, 'Risklevel', risklevel);
            dbms_xslprocessor.valueof(l_n, 'Stop_Cause', stop_cause);
            dbms_xslprocessor.valueof(l_n, 'Name', ls_name);
            dbms_xslprocessor.valueof(l_n, 'Branch', ls_branch);
            dbms_xslprocessor.valueof(l_n, 'ErrorCode',ls_errorcode);
            dbms_xslprocessor.valueof(l_n, 'ErrorDesc/text()',ls_errordesc);

           pan := pkg_debit_card.get_masked_Cardno(pan);

           insert into cbs_elcard(customer_no, pan, stop_cause, risk_level, expiry, create_date, branch)
                    values(pn_customer_no, pan, stop_cause, risklevel, to_date(expiry,'yyyy-mm-dd'), sysdate, ls_branch);
        end loop;
        ld_endtime := sysdate;
        pkg_debit_card.ws_log ('getDatabyElcard',
                                serviceurl,
                                methodname,
                               ld_starttime,
                                ld_endtime,
                                ls_errorcode,
                                ls_errordesc,
                                null,
                                null,
                                result,
                                req.body);
        commit;
exception
    when others then
        result := sqlerrm;
        pkg_debit_card.ws_log ('CREDIT CARD INFO',
                                serviceurl,
                                methodname,
                                ld_starttime,
                                ld_endtime,
                                '096',
                                sqlcode || ' ' || sqlerrm,
                                null,
                                null,
                                result,
                                req.body);
        log_at('getDatabyElcard',sqlerrm);
        rollback;
end;

end pkg_soa_transaction;
/

