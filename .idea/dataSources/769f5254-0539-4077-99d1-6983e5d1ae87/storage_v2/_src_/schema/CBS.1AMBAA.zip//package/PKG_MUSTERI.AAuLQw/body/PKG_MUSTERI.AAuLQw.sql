create PACKAGE BODY     PKG_MUSTERI IS
    /*************************************************************************************************************************/
    /*   Procedure Sp_Log_Musteri_Guncel_Alan                                                                                */
    /*   Guncelleme Musteri tablosunun degisen degerleri loglanir.Cbs_Trg_Upd_Musteri_Guncellen triggerindan cagrilir.       */
    /*************************************************************************************************************************/
    PROCEDURE Sp_Log_Musteri_Guncel_Alan(ps_table_name                   VARCHAR2,
                                         p_new_musteri_no                CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_NO%TYPE,
                                         p_new_musteri_tipi_kod          CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_TIPI_KOD%TYPE,
                                         p_new_dk_grup_kod               CBS.CBS_MUSTERI_GUNCELLENEN.DK_GRUP_KOD%TYPE,
                                         p_new_isim                      CBS.CBS_MUSTERI_GUNCELLENEN.ISIM%TYPE,
                                         p_new_ikinci_isim               CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM%TYPE,
                                         p_new_soyadi                    CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI%TYPE,
                                         p_new_dogum_tarihi              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_TARIHI%TYPE,
                                         p_new_dogum_yeri                CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_YERI%TYPE,
                                         p_new_dogum_il_kod              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_IL_KOD%TYPE,
                                         p_new_cinsiyet_kod              CBS.CBS_MUSTERI_GUNCELLENEN.CINSIYET_KOD%TYPE,
                                         p_new_baba_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.BABA_ADI%TYPE,
                                         p_new_anne_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_ADI%TYPE,
                                         p_new_anne_kizlik_soyadi        CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_KIZLIK_SOYADI%TYPE,
                                         p_new_meslek_kod                CBS.CBS_MUSTERI_GUNCELLENEN.MESLEK_KOD%TYPE,
                                         p_new_egitim_kod                CBS.CBS_MUSTERI_GUNCELLENEN.EGITIM_KOD%TYPE,
                                         p_new_medeni_hal_kod            CBS.CBS_MUSTERI_GUNCELLENEN.MEDENI_HAL_KOD%TYPE,
                                         p_new_ticari_unvan              CBS.CBS_MUSTERI_GUNCELLENEN.ticari_unvan%TYPE,
                                         p_new_hesap_ucreti_f            CBS.CBS_MUSTERI_GUNCELLENEN.HESAP_UCRETI_F%TYPE,
                                         p_new_cek_karnesi_f             CBS.CBS_MUSTERI_GUNCELLENEN.CEK_KARNESI_F%TYPE,
                                         p_new_personel_sicil_no         CBS.CBS_MUSTERI_GUNCELLENEN.PERSONEL_SICIL_NO%TYPE,
                                         p_new_yerlesim_kod              CBS.CBS_MUSTERI_GUNCELLENEN.YERLESIM_KOD%TYPE,
                                         p_new_ozel_kategori_kod         CBS.CBS_MUSTERI_GUNCELLENEN.OZEL_KATEGORI_KOD%TYPE,
                                         p_new_vergi_muaf_kod            CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_MUAF_KOD%TYPE,
                                         p_new_vergi_dairesi_adi         CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_DAIRESI_ADI%TYPE,
                                         p_new_vergi_no                  CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_NO%TYPE,
                                         p_new_tesvik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.TESVIK_KOD%TYPE,
                                         p_new_uyruk_kod                 CBS.CBS_MUSTERI_GUNCELLENEN.UYRUK_KOD%TYPE,
                                         p_new_kimlik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.KIMLIK_KOD%TYPE,
                                         p_new_tc_kimlik_no              CBS.CBS_MUSTERI_GUNCELLENEN.TC_KIMLIK_NO%TYPE,
                                         p_new_nufus_cuzdani_seri_no     CBS.CBS_MUSTERI_GUNCELLENEN.NUFUS_CUZDANI_SERI_NO%TYPE,
                                         p_new_pasaport_no               CBS.CBS_MUSTERI_GUNCELLENEN.PASAPORT_NO%TYPE,
                                         p_new_ehliyet_belge_no          CBS.CBS_MUSTERI_GUNCELLENEN.EHLIYET_BELGE_NO%TYPE,
                                         p_new_il_kod                    CBS.CBS_MUSTERI_GUNCELLENEN.IL_KOD%TYPE,
                                         p_new_ilce_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.ILCE_KOD%TYPE,
                                         p_new_mahalle_koy               CBS.CBS_MUSTERI_GUNCELLENEN.MAHALLE_KOY%TYPE,
                                         p_new_cilt_no                   CBS.CBS_MUSTERI_GUNCELLENEN.CILT_NO%TYPE,
                                         p_new_aile_sira_no              CBS.CBS_MUSTERI_GUNCELLENEN.AILE_SIRA_NO%TYPE,
                                         p_new_sira_no                   CBS.CBS_MUSTERI_GUNCELLENEN.SIRA_NO%TYPE,
                                         p_new_verildigi_yer             CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_YER%TYPE,
                                         p_new_verildigi_tarih           CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_TARIH%TYPE,
                                         p_new_sektor_kod                CBS.CBS_MUSTERI_GUNCELLENEN.SEKTOR_KOD%TYPE,
                                         p_new_finans_kod                CBS.CBS_MUSTERI_GUNCELLENEN.FINANS_KOD%TYPE,
                                         p_new_ticari_sicil_no           CBS.CBS_MUSTERI_GUNCELLENEN.TICARI_SICIL_NO%TYPE,
                                         p_new_extre_adres_kod           CBS.CBS_MUSTERI_GUNCELLENEN.EXTRE_ADRES_KOD%TYPE,
                                         p_new_serbest_bolge_izin_tar    CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_TARIHI%TYPE,
                                         p_new_serbest_bolge_izin_no     CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_NO%TYPE,
                                         p_new_pazar_sorum_sicil_no_1    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_1%TYPE,
                                         p_new_pazar_sorum_sicil_no_2    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_2%TYPE,
                                         p_new_grup_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.GRUP_KOD%TYPE,
                                         p_new_bic_kod                   CBS.CBS_MUSTERI_GUNCELLENEN.BIC_KOD%TYPE,
                                         p_new_swift_mesaj_kod           CBS.CBS_MUSTERI_GUNCELLENEN.SWIFT_MESAJ_KOD%TYPE,
                                         p_new_reuters_info_page         CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_INFO_PAGE%TYPE,
                                         p_new_reuters_dealing_kod       CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_DEALING_KOD%TYPE,
                                         p_new_sektor_alt1_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt1_kodu%TYPE,
                                         p_new_sektor_alt2_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt2_kodu%TYPE,
                                         p_new_rating_kodu               CBS.CBS_MUSTERI_GUNCELLENEN.rating_kodu%TYPE,
                                         p_new_bolum_kodu                CBS.CBS_MUSTERI_GUNCELLENEN.bolum_kodu%TYPE,
                                         p_new_GECERLILIK_TARIHI         DATE,
                                         p_new_VERGI_DAIRE_KODU          CBS.CBS_MUSTERI_GUNCELLENEN.vergi_daire_kodu%TYPE,
                                         p_new_vat_seri_no               CBS.cbs_musteri_guncellenen.vat_seri_no%TYPE,
                                         p_new_vat_sira_no               CBS.cbs_musteri_guncellenen.vat_sira_no%TYPE,
                                         p_new_okpo_code                 CBS.cbs_musteri_guncellenen.okpo_code%TYPE,
                                         p_new_manager_name              CBS.cbs_musteri_guncellenen.manager_name%TYPE,
                                         p_new_manager_surname           CBS.cbs_musteri_guncellenen.manager_surname%TYPE,
                                         p_new_manager_patronymic_name   CBS.cbs_musteri_guncellenen.manager_patronymic_name%TYPE,
                                         p_new_manager_country_code      CBS.cbs_musteri_guncellenen.manager_country_code%TYPE,
                                         p_new_manager_resident_code     CBS.cbs_musteri_guncellenen.manager_resident_code%TYPE,
                                         p_new_second_manager_name       CBS.cbs_musteri_guncellenen.second_manager_name%TYPE,
                                         p_new_vergi_zorunlumu           CBS.cbs_musteri_guncellenen.vergi_zorunlumu%TYPE,
                                         p_new_sosyal_fon_no             CBS.cbs_musteri_guncellenen.sosyal_fon_no%TYPE,
                                         p_new_ekstre_ucreti_alinsin     CBS.cbs_musteri_guncellenen.ekstre_ucreti_alinsin%TYPE,
                                         p_new_WORKING_BASIS             CBS.cbs_musteri_guncellenen.WORKING_BASIS%TYPE,
                                         P_new_PATENT_NO                 CBS.cbs_musteri_guncellenen.PATENT_NO%TYPE,
                                         P_new_PATENT_EXPIRY_DATE        CBS.cbs_musteri_guncellenen.PATENT_EXPIRY_DATE%TYPE,
                                         P_new_LEGAL_FORM_CODE           CBS.cbs_musteri_guncellenen.LEGAL_FORM_CODE%TYPE,
                                         p_new_isim_eng                  CBS.CBS_MUSTERI_GUNCELLENEN.ISIM_ENG%TYPE,
                                         p_new_ikinci_isim_eng           CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM_ENG%TYPE,
                                         p_new_soyadi_eng                CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI_ENG%TYPE,
                                         p_new_MANAGER_ID_TYPE           CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_ID_TYPE%TYPE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                         p_new_MANAGER_PASSPORT_NUMBER   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_NUMBER%TYPE,
                                         p_new_MANAGER_PASS_ISSUE_D      CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_DATE%TYPE,
                                         p_new_MANAGER_PASS_EXPIRING_D   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_EXPIRING_DATE%TYPE,
                                         p_new_MANAGER_PASS_ISSUE_PLACE  CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_PLACE%TYPE,
                                         p_new_MANAGER_PASSPORT_SERIES   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_SERIES%TYPE, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                                      --BOM CBS-395 AntonPa 271022
                                         P_NEW_MILITARY_CARD              CBS.CBS_MUSTERI_GUNCELLENEN.MILITARY_CARD%TYPE,
                                         P_NEW_RESIDENCE_PERMIT           CBS.CBS_MUSTERI_GUNCELLENEN.RESIDENCE_PERMIT%TYPE,    
                                         P_NEW_ECONOMY_SECTOR_CODE        CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMY_SECTOR_CODE%TYPE,      
                                         P_NEW_BANK_RELATION_CODE         CBS.CBS_MUSTERI_GUNCELLENEN.BANK_RELATION_CODE%TYPE,        
                                         P_NEW_CIVIL_STATUS_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CIVIL_STATUS_CODE%TYPE,  
                                         P_NEW_CAPITAL_PARTICIPATION_CODE CBS.CBS_MUSTERI_GUNCELLENEN.CAPITAL_PARTICIPATION_CODE%TYPE,                
                                         P_NEW_CONTROL_FORM_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CONTROL_FORM_CODE%TYPE,   
                                         P_NEW_ECONOMIC_ACTIVITY_SUB      CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_SUB%TYPE,        
                                         P_NEW_ECONOMIC_ACTIVITY_CODE     CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_CODE%TYPE,            
                                         P_NEW_TAX_INITIAL_REG_DATE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_INITIAL_REG_DATE%TYPE,        
                                         P_NEW_TAX_REG_AUTHORITY          CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_AUTHORITY%TYPE,    
                                         P_NEW_TAX_RE_REG_DATE            CBS.CBS_MUSTERI_GUNCELLENEN.TAX_RE_REG_DATE%TYPE,    
                                         P_NEW_TAX_REG_COUNTRY_CODE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_COUNTRY_CODE%TYPE,       
                                         P_NEW_IS_LICENSED                CBS.CBS_MUSTERI_GUNCELLENEN.IS_LICENSED%TYPE,
                                         P_NEW_MANAGER_GENDER             CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_GENDER%TYPE,
                                         P_NEW_DECLARED_SHARE_CAPITAL     CBS.CBS_MUSTERI_GUNCELLENEN.DECLARED_SHARE_CAPITAL%TYPE, 
                                         P_NEW_SHARE_CAPITAL_CURRENCY     CBS.CBS_MUSTERI_GUNCELLENEN.SHARE_CAPITAL_CURRENCY%TYPE,
                                         P_NEW_PAID_SHARE_CAPITAL         CBS.CBS_MUSTERI_GUNCELLENEN.PAID_SHARE_CAPITAL%TYPE,
                                         P_NEW_PDL_CODE                   CBS.CBS_MUSTERI_GUNCELLENEN.PDL_CODE%TYPE,
                                         P_NEW_BIRTH_CERTIFICATE          CBS.CBS_MUSTERI_GUNCELLENEN.BIRTH_CERTIFICATE%TYPE,
                                         P_NEW_COMPANY_NAME_KYR           CBS.CBS_MUSTERI_GUNCELLENEN.COMPANY_NAME_KYR%TYPE,
                                         P_NEW_OPF_ID_CODE                CBS.CBS_MUSTERI_GUNCELLENEN.OPF_ID_CODE%TYPE,
                                      --EOM CBS-395 AntonPa 271022
                                         p_old_musteri_no                CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_NO%TYPE,
                                         p_old_musteri_tipi_kod          CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_TIPI_KOD%TYPE,
                                         p_old_dk_grup_kod               CBS.CBS_MUSTERI_GUNCELLENEN.DK_GRUP_KOD%TYPE,
                                         p_old_isim                      CBS.CBS_MUSTERI_GUNCELLENEN.ISIM%TYPE,
                                         p_old_ikinci_isim               CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM%TYPE,
                                         p_old_soyadi                    CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI%TYPE,
                                         p_old_dogum_tarihi              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_TARIHI%TYPE,
                                         p_old_dogum_yeri                CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_YERI%TYPE,
                                         p_old_dogum_il_kod              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_IL_KOD%TYPE,
                                         p_old_cinsiyet_kod              CBS.CBS_MUSTERI_GUNCELLENEN.CINSIYET_KOD%TYPE,
                                         p_old_baba_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.BABA_ADI%TYPE,
                                         p_old_anne_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_ADI%TYPE,
                                         p_old_anne_kizlik_soyadi        CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_KIZLIK_SOYADI%TYPE,
                                         p_old_meslek_kod                CBS.CBS_MUSTERI_GUNCELLENEN.MESLEK_KOD%TYPE,
                                         p_old_egitim_kod                CBS.CBS_MUSTERI_GUNCELLENEN.EGITIM_KOD%TYPE,
                                         p_old_medeni_hal_kod            CBS.CBS_MUSTERI_GUNCELLENEN.MEDENI_HAL_KOD%TYPE,
                                         p_old_ticari_unvan              CBS.CBS_MUSTERI_GUNCELLENEN.ticari_unvan%TYPE,
                                         p_old_hesap_ucreti_f            CBS.CBS_MUSTERI_GUNCELLENEN.HESAP_UCRETI_F%TYPE,
                                         p_old_cek_karnesi_f             CBS.CBS_MUSTERI_GUNCELLENEN.CEK_KARNESI_F%TYPE,
                                         p_old_personel_sicil_no         CBS.CBS_MUSTERI_GUNCELLENEN.PERSONEL_SICIL_NO%TYPE,
                                         p_old_yerlesim_kod              CBS.CBS_MUSTERI_GUNCELLENEN.YERLESIM_KOD%TYPE,
                                         p_old_ozel_kategori_kod         CBS.CBS_MUSTERI_GUNCELLENEN.OZEL_KATEGORI_KOD%TYPE,
                                         p_old_vergi_muaf_kod            CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_MUAF_KOD%TYPE,
                                         p_old_vergi_dairesi_adi         CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_DAIRESI_ADI%TYPE,
                                         p_old_vergi_no                  CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_NO%TYPE,
                                         p_old_tesvik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.TESVIK_KOD%TYPE,
                                         p_old_uyruk_kod                 CBS.CBS_MUSTERI_GUNCELLENEN.UYRUK_KOD%TYPE,
                                         p_old_kimlik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.KIMLIK_KOD%TYPE,
                                         p_old_tc_kimlik_no              CBS.CBS_MUSTERI_GUNCELLENEN.TC_KIMLIK_NO%TYPE,
                                         p_old_nufus_cuzdani_seri_no     CBS.CBS_MUSTERI_GUNCELLENEN.NUFUS_CUZDANI_SERI_NO%TYPE,
                                         p_old_pasaport_no               CBS.CBS_MUSTERI_GUNCELLENEN.PASAPORT_NO%TYPE,
                                         p_old_ehliyet_belge_no          CBS.CBS_MUSTERI_GUNCELLENEN.EHLIYET_BELGE_NO%TYPE,
                                         p_old_il_kod                    CBS.CBS_MUSTERI_GUNCELLENEN.IL_KOD%TYPE,
                                         p_old_ilce_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.ILCE_KOD%TYPE,
                                         p_old_mahalle_koy               CBS.CBS_MUSTERI_GUNCELLENEN.MAHALLE_KOY%TYPE,
                                         p_old_cilt_no                   CBS.CBS_MUSTERI_GUNCELLENEN.CILT_NO%TYPE,
                                         p_old_aile_sira_no              CBS.CBS_MUSTERI_GUNCELLENEN.AILE_SIRA_NO%TYPE,
                                         p_old_sira_no                   CBS.CBS_MUSTERI_GUNCELLENEN.SIRA_NO%TYPE,
                                         p_old_verildigi_yer             CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_YER%TYPE,
                                         p_old_verildigi_tarih           CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_TARIH%TYPE,
                                         p_old_sektor_kod                CBS.CBS_MUSTERI_GUNCELLENEN.SEKTOR_KOD%TYPE,
                                         p_old_finans_kod                CBS.CBS_MUSTERI_GUNCELLENEN.FINANS_KOD%TYPE,
                                         p_old_ticari_sicil_no           CBS.CBS_MUSTERI_GUNCELLENEN.TICARI_SICIL_NO%TYPE,
                                         p_old_extre_adres_kod           CBS.CBS_MUSTERI_GUNCELLENEN.EXTRE_ADRES_KOD%TYPE,
                                         p_old_serbest_bolge_izin_tar    CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_TARIHI%TYPE,
                                         p_old_serbest_bolge_izin_no     CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_NO%TYPE,
                                         p_old_pazar_sorum_sicil_no_1    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_1%TYPE,
                                         p_old_pazar_sorum_sicil_no_2    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_2%TYPE,
                                         p_old_grup_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.GRUP_KOD%TYPE,
                                         p_old_bic_kod                   CBS.CBS_MUSTERI_GUNCELLENEN.BIC_KOD%TYPE,
                                         p_old_swift_mesaj_kod           CBS.CBS_MUSTERI_GUNCELLENEN.SWIFT_MESAJ_KOD%TYPE,
                                         p_old_reuters_info_page         CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_INFO_PAGE%TYPE,
                                         p_old_reuters_dealing_kod       CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_DEALING_KOD%TYPE,
                                         p_old_sektor_alt1_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt1_kodu%TYPE,
                                         p_old_sektor_alt2_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt2_kodu%TYPE,
                                         p_old_rating_kodu               CBS.CBS_MUSTERI_GUNCELLENEN.rating_kodu%TYPE,
                                         p_old_bolum_kodu                CBS.CBS_MUSTERI_GUNCELLENEN.bolum_kodu%TYPE,
                                         p_old_GECERLILIK_TARIHI         DATE,
                                         p_old_VERGI_DAIRE_KODU          CBS.CBS_MUSTERI_GUNCELLENEN.vergi_daire_kodu%TYPE,
                                         p_old_vat_seri_no               CBS.cbs_musteri_guncellenen.vat_seri_no%TYPE,
                                         p_old_vat_sira_no               CBS.cbs_musteri_guncellenen.vat_sira_no%TYPE,
                                         p_old_okpo_code                 CBS.cbs_musteri_guncellenen.okpo_code%TYPE,
                                         p_old_manager_name              CBS.cbs_musteri_guncellenen.manager_name%TYPE,
                                         p_old_manager_surname           CBS.cbs_musteri_guncellenen.manager_surname%TYPE,
                                         p_old_manager_patronymic_name   CBS.cbs_musteri_guncellenen.manager_patronymic_name%TYPE,
                                         p_old_manager_country_code      CBS.cbs_musteri_guncellenen.manager_country_code%TYPE,
                                         p_old_manager_resident_code     CBS.cbs_musteri_guncellenen.manager_resident_code%TYPE,
                                         p_old_second_manager_name       CBS.cbs_musteri_guncellenen.second_manager_name%TYPE,
                                         p_old_vergi_zorunlumu           CBS.cbs_musteri_guncellenen.vergi_zorunlumu%TYPE,
                                         p_old_sosyal_fon_no             CBS.cbs_musteri_guncellenen.sosyal_fon_no%TYPE,
                                         p_old_ekstre_ucreti_alinsin     CBS.cbs_musteri_guncellenen.ekstre_ucreti_alinsin%TYPE,
                                         p_old_WORKING_BASIS             CBS.cbs_musteri_guncellenen.WORKING_BASIS%TYPE,
                                         P_old_PATENT_NO                 CBS.cbs_musteri_guncellenen.PATENT_NO%TYPE,
                                         P_old_PATENT_EXPIRY_DATE        CBS.cbs_musteri_guncellenen.PATENT_EXPIRY_DATE%TYPE,
                                         P_old_LEGAL_FORM_CODE           CBS.cbs_musteri_guncellenen.LEGAL_FORM_CODE%TYPE,
                                         p_old_isim_eng                  CBS.CBS_MUSTERI_GUNCELLENEN.ISIM_ENG%TYPE,
                                         p_old_ikinci_isim_eng           CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM_ENG%TYPE,
                                         p_old_soyadi_eng                CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI_ENG%TYPE,
                                         pn_tx_no                        CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE,
                                         p_old_MANAGER_ID_TYPE           CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_ID_TYPE%TYPE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                         p_old_MANAGER_PASSPORT_NUMBER   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_NUMBER%TYPE,
                                         p_old_MANAGER_PASS_ISSUE_D      CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_DATE%TYPE,
                                         p_old_MANAGER_PASS_EXPIRING_D   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_EXPIRING_DATE%TYPE,
                                         p_old_MANAGER_PASS_ISSUE_PLACE  CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_PLACE%TYPE,
                                         p_old_MANAGER_PASSPORT_SERIES   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_SERIES%TYPE, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                                      --BOM AntonPa CBS-395 271022
                                         P_OLD_MILITARY_CARD              CBS.CBS_MUSTERI_GUNCELLENEN.MILITARY_CARD%TYPE,
                                         P_OLD_RESIDENCE_PERMIT           CBS.CBS_MUSTERI_GUNCELLENEN.RESIDENCE_PERMIT%TYPE,    
                                         P_OLD_ECONOMY_SECTOR_CODE        CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMY_SECTOR_CODE%TYPE,      
                                         P_OLD_BANK_RELATION_CODE         CBS.CBS_MUSTERI_GUNCELLENEN.BANK_RELATION_CODE%TYPE,        
                                         P_OLD_CIVIL_STATUS_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CIVIL_STATUS_CODE%TYPE,  
                                         P_OLD_CAPITAL_PARTICIPATION_CODE CBS.CBS_MUSTERI_GUNCELLENEN.CAPITAL_PARTICIPATION_CODE%TYPE,                
                                         P_OLD_CONTROL_FORM_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CONTROL_FORM_CODE%TYPE,   
                                         P_OLD_ECONOMIC_ACTIVITY_SUB      CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_SUB%TYPE,        
                                         P_OLD_ECONOMIC_ACTIVITY_CODE     CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_CODE%TYPE,            
                                         P_OLD_TAX_INITIAL_REG_DATE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_INITIAL_REG_DATE%TYPE,        
                                         P_OLD_TAX_REG_AUTHORITY          CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_AUTHORITY%TYPE,    
                                         P_OLD_TAX_RE_REG_DATE            CBS.CBS_MUSTERI_GUNCELLENEN.TAX_RE_REG_DATE%TYPE,    
                                         P_OLD_TAX_REG_COUNTRY_CODE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_COUNTRY_CODE%TYPE,       
                                         P_OLD_IS_LICENSED                CBS.CBS_MUSTERI_GUNCELLENEN.IS_LICENSED%TYPE,
                                         P_OLD_MANAGER_GENDER             CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_GENDER%TYPE,
                                         P_OLD_DECLARED_SHARE_CAPITAL     CBS.CBS_MUSTERI_GUNCELLENEN.DECLARED_SHARE_CAPITAL%TYPE, 
                                         P_OLD_SHARE_CAPITAL_CURRENCY     CBS.CBS_MUSTERI_GUNCELLENEN.SHARE_CAPITAL_CURRENCY%TYPE,
                                         P_OLD_PAID_SHARE_CAPITAL         CBS.CBS_MUSTERI_GUNCELLENEN.PAID_SHARE_CAPITAL%TYPE,
                                         P_OLD_PDL_CODE                   CBS.CBS_MUSTERI_GUNCELLENEN.PDL_CODE%TYPE,
                                         P_OLD_BIRTH_CERTIFICATE          CBS.CBS_MUSTERI_GUNCELLENEN.BIRTH_CERTIFICATE%TYPE,
                                         P_OLD_COMPANY_NAME_KYR           CBS.CBS_MUSTERI_GUNCELLENEN.COMPANY_NAME_KYR%TYPE,
                                         P_OLD_OPF_ID_CODE                CBS.CBS_MUSTERI_GUNCELLENEN.OPF_ID_CODE%TYPE) IS
                                      --EOM AntonPa CBS-395 271022
        ls_table_name VARCHAR2(100) := ps_table_name;
        ls_parametre  VARCHAR2(100) := pn_tx_no;
    BEGIN
        /* parametre kolonuna unique alanlar birden fazla ise ; ile birlestirilerek gonderilir */
        IF (p_new_MUSTERI_NO <> p_old_MUSTERI_NO) OR (p_new_MUSTERI_NO IS NULL AND p_old_MUSTERI_NO IS NOT NULL ) OR (p_new_MUSTERI_NO IS NOT NULL AND p_old_MUSTERI_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MUSTERI_NO',p_old_MUSTERI_NO,p_new_MUSTERI_NO ,ls_parametre); END IF;
        IF (p_new_MUSTERI_TIPI_KOD <> p_old_MUSTERI_TIPI_KOD) OR (p_new_MUSTERI_TIPI_KOD IS NULL AND p_old_MUSTERI_TIPI_KOD IS NOT NULL ) OR (p_new_MUSTERI_TIPI_KOD IS NOT NULL AND p_old_MUSTERI_TIPI_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MUSTERI_TIPI_KOD',p_old_MUSTERI_TIPI_KOD,p_new_MUSTERI_TIPI_KOD,ls_parametre ); END IF;
        IF (p_new_DK_GRUP_KOD <> p_old_DK_GRUP_KOD) OR (p_new_DK_GRUP_KOD IS NULL AND p_old_DK_GRUP_KOD IS NOT NULL ) OR (p_new_DK_GRUP_KOD IS NOT NULL AND p_old_DK_GRUP_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'DK_GRUP_KOD',p_old_DK_GRUP_KOD,p_new_DK_GRUP_KOD ,ls_parametre); END IF;
        IF (p_new_ISIM <> p_old_ISIM) OR (p_new_ISIM IS NULL AND p_old_ISIM IS NOT NULL ) OR (p_new_ISIM IS NOT NULL AND p_old_ISIM IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ISIM',p_old_ISIM,p_new_ISIM,ls_parametre ); END IF;
        IF (p_new_IKINCI_ISIM <> p_old_IKINCI_ISIM) OR (p_new_IKINCI_ISIM IS NULL AND p_old_IKINCI_ISIM IS NOT NULL ) OR (p_new_IKINCI_ISIM IS NOT NULL AND p_old_IKINCI_ISIM IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'IKINCI_ISIM',p_old_IKINCI_ISIM,p_new_IKINCI_ISIM,ls_parametre ); END IF;
        IF (p_new_SOYADI <> p_old_SOYADI) OR (p_new_SOYADI IS NULL AND p_old_SOYADI IS NOT NULL ) OR (p_new_SOYADI IS NOT NULL AND p_old_SOYADI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SOYADI',p_old_SOYADI,p_new_SOYADI,ls_parametre ); END IF;
        IF (p_new_DOGUM_TARIHI <> p_old_DOGUM_TARIHI) OR (p_new_DOGUM_TARIHI IS NULL AND p_old_DOGUM_TARIHI IS NOT NULL ) OR (p_new_DOGUM_TARIHI IS NOT NULL AND p_old_DOGUM_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'DOGUM_TARIHI',p_old_DOGUM_TARIHI,p_new_DOGUM_TARIHI,ls_parametre ); END IF;
        IF (p_new_DOGUM_YERI <> p_old_DOGUM_YERI) OR (p_new_DOGUM_YERI IS NULL AND p_old_DOGUM_YERI IS NOT NULL ) OR (p_new_DOGUM_YERI IS NOT NULL AND p_old_DOGUM_YERI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'DOGUM_YERI',p_old_DOGUM_YERI,p_new_DOGUM_YERI,ls_parametre ); END IF;
        IF (p_new_DOGUM_IL_KOD <> p_old_DOGUM_IL_KOD) OR (p_new_DOGUM_IL_KOD IS NULL AND p_old_DOGUM_IL_KOD IS NOT NULL ) OR (p_new_DOGUM_IL_KOD IS NOT NULL AND p_old_DOGUM_IL_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'DOGUM_IL_KOD',p_old_DOGUM_IL_KOD,p_new_DOGUM_IL_KOD,ls_parametre ); END IF;
        IF (p_new_CINSIYET_KOD <> p_old_CINSIYET_KOD) OR (p_new_CINSIYET_KOD IS NULL AND p_old_CINSIYET_KOD IS NOT NULL ) OR (p_new_CINSIYET_KOD IS NOT NULL AND p_old_CINSIYET_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'CINSIYET_KOD',p_old_CINSIYET_KOD,p_new_CINSIYET_KOD,ls_parametre ); END IF;
        IF (p_new_BABA_ADI <> p_old_BABA_ADI) OR (p_new_BABA_ADI IS NULL AND p_old_BABA_ADI IS NOT NULL ) OR (p_new_BABA_ADI IS NOT NULL AND p_old_BABA_ADI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'BABA_ADI',p_old_BABA_ADI,p_new_BABA_ADI,ls_parametre ); END IF;
        IF (p_new_ANNE_ADI <> p_old_ANNE_ADI) OR (p_new_ANNE_ADI IS NULL AND p_old_ANNE_ADI IS NOT NULL ) OR (p_new_ANNE_ADI IS NOT NULL AND p_old_ANNE_ADI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ANNE_ADI',p_old_ANNE_ADI,p_new_ANNE_ADI,ls_parametre ); END IF;
        IF (p_new_ANNE_KIZLIK_SOYADI <> p_old_ANNE_KIZLIK_SOYADI) OR (p_new_ANNE_KIZLIK_SOYADI IS NULL AND p_old_ANNE_KIZLIK_SOYADI IS NOT NULL ) OR (p_new_ANNE_KIZLIK_SOYADI IS NOT NULL AND p_old_ANNE_KIZLIK_SOYADI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ANNE_KIZLIK_SOYADI',p_old_ANNE_KIZLIK_SOYADI,p_new_ANNE_KIZLIK_SOYADI,ls_parametre ); END IF;
        IF (p_new_MESLEK_KOD <> p_old_MESLEK_KOD) OR (p_new_MESLEK_KOD IS NULL AND p_old_MESLEK_KOD IS NOT NULL ) OR (p_new_MESLEK_KOD IS NOT NULL AND p_old_MESLEK_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MESLEK_KOD',p_old_MESLEK_KOD,p_new_MESLEK_KOD,ls_parametre ); END IF;
        IF (p_new_EGITIM_KOD <> p_old_EGITIM_KOD) OR (p_new_EGITIM_KOD IS NULL AND p_old_EGITIM_KOD IS NOT NULL ) OR (p_new_EGITIM_KOD IS NOT NULL AND p_old_EGITIM_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'EGITIM_KOD',p_old_EGITIM_KOD,p_new_EGITIM_KOD,ls_parametre ); END IF;
        IF (p_new_MEDENI_HAL_KOD <> p_old_MEDENI_HAL_KOD) OR (p_new_MEDENI_HAL_KOD IS NULL AND p_old_MEDENI_HAL_KOD IS NOT NULL ) OR (p_new_MEDENI_HAL_KOD IS NOT NULL AND p_old_MEDENI_HAL_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MEDENI_HAL_KOD',p_old_MEDENI_HAL_KOD,p_new_MEDENI_HAL_KOD,ls_parametre ); END IF;
        IF (p_new_ticari_unvan <> p_old_ticari_unvan) OR (p_new_ticari_unvan IS NULL AND p_old_ticari_unvan IS NOT NULL ) OR (p_new_ticari_unvan IS NOT NULL AND p_old_ticari_unvan IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'TICARI_UNVAN',p_old_ticari_unvan,p_new_ticari_unvan,ls_parametre ); END IF;
        IF (p_new_HESAP_UCRETI_F <> p_old_HESAP_UCRETI_F) OR (p_new_HESAP_UCRETI_F IS NULL AND p_old_HESAP_UCRETI_F IS NOT NULL ) OR (p_new_HESAP_UCRETI_F IS NOT NULL AND p_old_HESAP_UCRETI_F IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'HESAP_UCRETI_F',p_old_HESAP_UCRETI_F,p_new_HESAP_UCRETI_F,ls_parametre ); END IF;
        IF (p_new_CEK_KARNESI_F <> p_old_CEK_KARNESI_F) OR (p_new_CEK_KARNESI_F IS NULL AND p_old_CEK_KARNESI_F IS NOT NULL ) OR (p_new_CEK_KARNESI_F IS NOT NULL AND p_old_CEK_KARNESI_F IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'CEK_KARNESI_F',p_old_CEK_KARNESI_F,p_new_CEK_KARNESI_F,ls_parametre ); END IF;
        IF (p_new_PERSONEL_SICIL_NO <> p_old_PERSONEL_SICIL_NO) OR (p_new_PERSONEL_SICIL_NO IS NULL AND p_old_PERSONEL_SICIL_NO IS NOT NULL ) OR (p_new_PERSONEL_SICIL_NO IS NOT NULL AND p_old_PERSONEL_SICIL_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'PERSONEL_SICIL_NO',p_old_PERSONEL_SICIL_NO,p_new_PERSONEL_SICIL_NO,ls_parametre ); END IF;
        IF (p_new_YERLESIM_KOD <> p_old_YERLESIM_KOD) OR (p_new_YERLESIM_KOD IS NULL AND p_old_YERLESIM_KOD IS NOT NULL ) OR (p_new_YERLESIM_KOD IS NOT NULL AND p_old_YERLESIM_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'YERLESIM_KOD',p_old_YERLESIM_KOD,p_new_YERLESIM_KOD,ls_parametre ); END IF;
        IF (p_new_OZEL_KATEGORI_KOD <> p_old_OZEL_KATEGORI_KOD) OR (p_new_OZEL_KATEGORI_KOD IS NULL AND p_old_OZEL_KATEGORI_KOD IS NOT NULL ) OR (p_new_OZEL_KATEGORI_KOD IS NOT NULL AND p_old_OZEL_KATEGORI_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'OZEL_KATEGORI_KOD',p_old_OZEL_KATEGORI_KOD,p_new_OZEL_KATEGORI_KOD,ls_parametre ); END IF;
        IF (p_new_VERGI_MUAF_KOD <> p_old_VERGI_MUAF_KOD) OR (p_new_VERGI_MUAF_KOD IS NULL AND p_old_VERGI_MUAF_KOD IS NOT NULL ) OR (p_new_VERGI_MUAF_KOD IS NOT NULL AND p_old_VERGI_MUAF_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VERGI_MUAF_KOD',p_old_VERGI_MUAF_KOD,p_new_VERGI_MUAF_KOD,ls_parametre ); END IF;
        IF (p_new_VERGI_DAIRESI_ADI <> p_old_VERGI_DAIRESI_ADI) OR (p_new_VERGI_DAIRESI_ADI IS NULL AND p_old_VERGI_DAIRESI_ADI IS NOT NULL ) OR (p_new_VERGI_DAIRESI_ADI IS NOT NULL AND p_old_VERGI_DAIRESI_ADI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VERGI_DAIRESI_ADI',p_old_VERGI_DAIRESI_ADI,p_new_VERGI_DAIRESI_ADI,ls_parametre ); END IF;
        IF (p_new_VERGI_NO <> p_old_VERGI_NO) OR (p_new_VERGI_NO IS NULL AND p_old_VERGI_NO IS NOT NULL ) OR (p_new_VERGI_NO IS NOT NULL AND p_old_VERGI_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VERGI_NO',p_old_VERGI_NO,p_new_VERGI_NO,ls_parametre ); END IF;
        IF (p_new_TESVIK_KOD <> p_old_TESVIK_KOD) OR (p_new_TESVIK_KOD IS NULL AND p_old_TESVIK_KOD IS NOT NULL ) OR (p_new_TESVIK_KOD IS NOT NULL AND p_old_TESVIK_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'TESVIK_KOD',p_old_TESVIK_KOD,p_new_TESVIK_KOD,ls_parametre ); END IF;
        IF (p_new_UYRUK_KOD <> p_old_UYRUK_KOD) OR (p_new_UYRUK_KOD IS NULL AND p_old_UYRUK_KOD IS NOT NULL ) OR (p_new_UYRUK_KOD IS NOT NULL AND p_old_UYRUK_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'UYRUK_KOD',p_old_UYRUK_KOD,p_new_UYRUK_KOD,ls_parametre ); END IF;
        IF (p_new_KIMLIK_KOD <> p_old_KIMLIK_KOD) OR (p_new_KIMLIK_KOD IS NULL AND p_old_KIMLIK_KOD IS NOT NULL ) OR (p_new_KIMLIK_KOD IS NOT NULL AND p_old_KIMLIK_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'KIMLIK_KOD',p_old_KIMLIK_KOD,p_new_KIMLIK_KOD,ls_parametre ); END IF;
        IF (p_new_TC_KIMLIK_NO <> p_old_TC_KIMLIK_NO) OR (p_new_TC_KIMLIK_NO IS NULL AND p_old_TC_KIMLIK_NO IS NOT NULL ) OR (p_new_TC_KIMLIK_NO IS NOT NULL AND p_old_TC_KIMLIK_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'TC_KIMLIK_NO',p_old_TC_KIMLIK_NO,p_new_TC_KIMLIK_NO,ls_parametre ); END IF;
        IF (p_new_NUFUS_CUZDANI_SERI_NO <> p_old_NUFUS_CUZDANI_SERI_NO) OR (p_new_NUFUS_CUZDANI_SERI_NO IS NULL AND p_old_NUFUS_CUZDANI_SERI_NO IS NOT NULL ) OR (p_new_NUFUS_CUZDANI_SERI_NO IS NOT NULL AND p_old_NUFUS_CUZDANI_SERI_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'NUFUS_CUZDANI_SERI_NO',p_old_NUFUS_CUZDANI_SERI_NO,p_new_NUFUS_CUZDANI_SERI_NO,ls_parametre ); END IF;
        IF (p_new_PASAPORT_NO <> p_old_PASAPORT_NO) OR (p_new_PASAPORT_NO IS NULL AND p_old_PASAPORT_NO IS NOT NULL ) OR (p_new_PASAPORT_NO IS NOT NULL AND p_old_PASAPORT_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'PASAPORT_NO',p_old_PASAPORT_NO,p_new_PASAPORT_NO,ls_parametre ); END IF;
        IF (p_new_EHLIYET_BELGE_NO <> p_old_EHLIYET_BELGE_NO) OR (p_new_EHLIYET_BELGE_NO IS NULL AND p_old_EHLIYET_BELGE_NO IS NOT NULL ) OR (p_new_EHLIYET_BELGE_NO IS NOT NULL AND p_old_EHLIYET_BELGE_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'EHLIYET_BELGE_NO',p_old_EHLIYET_BELGE_NO,p_new_EHLIYET_BELGE_NO,ls_parametre ); END IF;
        IF (p_new_IL_KOD <> p_old_IL_KOD) OR (p_new_IL_KOD IS NULL AND p_old_IL_KOD IS NOT NULL ) OR (p_new_IL_KOD IS NOT NULL AND p_old_IL_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'IL_KOD',p_old_IL_KOD,p_new_IL_KOD,ls_parametre ); END IF;
        IF (p_new_ILCE_KOD <> p_old_ILCE_KOD) OR (p_new_ILCE_KOD IS NULL AND p_old_ILCE_KOD IS NOT NULL ) OR (p_new_ILCE_KOD IS NOT NULL AND p_old_ILCE_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ILCE_KOD',p_old_ILCE_KOD,p_new_ILCE_KOD,ls_parametre ); END IF;
        IF (p_new_MAHALLE_KOY <> p_old_MAHALLE_KOY) OR (p_new_MAHALLE_KOY IS NULL AND p_old_MAHALLE_KOY IS NOT NULL ) OR (p_new_MAHALLE_KOY IS NOT NULL AND p_old_MAHALLE_KOY IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MAHALLE_KOY',p_old_MAHALLE_KOY,p_new_MAHALLE_KOY,ls_parametre ); END IF;
        IF (p_new_CILT_NO <> p_old_CILT_NO) OR (p_new_CILT_NO IS NULL AND p_old_CILT_NO IS NOT NULL ) OR (p_new_CILT_NO IS NOT NULL AND p_old_CILT_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'CILT_NO',p_old_CILT_NO,p_new_CILT_NO,ls_parametre ); END IF;
        IF (p_new_AILE_SIRA_NO <> p_old_AILE_SIRA_NO) OR (p_new_AILE_SIRA_NO IS NULL AND p_old_AILE_SIRA_NO IS NOT NULL ) OR (p_new_AILE_SIRA_NO IS NOT NULL AND p_old_AILE_SIRA_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'AILE_SIRA_NO',p_old_AILE_SIRA_NO,p_new_AILE_SIRA_NO,ls_parametre ); END IF;
        IF (p_new_SIRA_NO <> p_old_SIRA_NO) OR (p_new_SIRA_NO IS NULL AND p_old_SIRA_NO IS NOT NULL ) OR (p_new_SIRA_NO IS NOT NULL AND p_old_SIRA_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SIRA_NO',p_old_SIRA_NO,p_new_SIRA_NO ,ls_parametre); END IF;
        IF (p_new_VERILDIGI_YER <> p_old_VERILDIGI_YER) OR (p_new_VERILDIGI_YER IS NULL AND p_old_VERILDIGI_YER IS NOT NULL ) OR (p_new_VERILDIGI_YER IS NOT NULL AND p_old_VERILDIGI_YER IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VERILDIGI_YER',p_old_VERILDIGI_YER,p_new_VERILDIGI_YER,ls_parametre ); END IF;
        IF (p_new_VERILDIGI_TARIH <> p_old_VERILDIGI_TARIH) OR (p_new_VERILDIGI_TARIH IS NULL AND p_old_VERILDIGI_TARIH IS NOT NULL ) OR (p_new_VERILDIGI_TARIH IS NOT NULL AND p_old_VERILDIGI_TARIH IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VERILDIGI_TARIH',p_old_VERILDIGI_TARIH,p_new_VERILDIGI_TARIH,ls_parametre ); END IF;
        IF (p_new_SEKTOR_KOD <> p_old_SEKTOR_KOD) OR (p_new_SEKTOR_KOD IS NULL AND p_old_SEKTOR_KOD IS NOT NULL ) OR (p_new_SEKTOR_KOD IS NOT NULL AND p_old_SEKTOR_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SEKTOR_KOD',p_old_SEKTOR_KOD,p_new_SEKTOR_KOD,ls_parametre ); END IF;
        IF (p_new_FINANS_KOD <> p_old_FINANS_KOD) OR (p_new_FINANS_KOD IS NULL AND p_old_FINANS_KOD IS NOT NULL ) OR (p_new_FINANS_KOD IS NOT NULL AND p_old_FINANS_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'FINANS_KOD',p_old_FINANS_KOD,p_new_FINANS_KOD,ls_parametre ); END IF;
        IF (p_new_TICARI_SICIL_NO <> p_old_TICARI_SICIL_NO) OR (p_new_TICARI_SICIL_NO IS NULL AND p_old_TICARI_SICIL_NO IS NOT NULL ) OR (p_new_TICARI_SICIL_NO IS NOT NULL AND p_old_TICARI_SICIL_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'TICARI_SICIL_NO',p_old_TICARI_SICIL_NO,p_new_TICARI_SICIL_NO,ls_parametre ); END IF;
        IF (p_new_EXTRE_ADRES_KOD <> p_old_EXTRE_ADRES_KOD) OR (p_new_EXTRE_ADRES_KOD IS NULL AND p_old_EXTRE_ADRES_KOD IS NOT NULL ) OR (p_new_EXTRE_ADRES_KOD IS NOT NULL AND p_old_EXTRE_ADRES_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'EXTRE_ADRES_KOD',p_old_EXTRE_ADRES_KOD,p_new_EXTRE_ADRES_KOD,ls_parametre ); END IF;
        IF (p_new_SERBEST_BOLGE_IZIN_TAR <> p_old_SERBEST_BOLGE_IZIN_TAR) OR (p_new_SERBEST_BOLGE_IZIN_TAR IS NULL AND p_old_SERBEST_BOLGE_IZIN_TAR IS NOT NULL ) OR (p_new_SERBEST_BOLGE_IZIN_TAR IS NOT NULL AND p_old_SERBEST_BOLGE_IZIN_TAR IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SERBEST_BOLGE_IZIN_TARIHI',p_old_SERBEST_BOLGE_IZIN_TAR,p_new_SERBEST_BOLGE_IZIN_TAR,ls_parametre ); END IF;
        IF (p_new_SERBEST_BOLGE_IZIN_NO <> p_old_SERBEST_BOLGE_IZIN_NO) OR (p_new_SERBEST_BOLGE_IZIN_NO IS NULL AND p_old_SERBEST_BOLGE_IZIN_NO IS NOT NULL ) OR (p_new_SERBEST_BOLGE_IZIN_NO IS NOT NULL AND p_old_SERBEST_BOLGE_IZIN_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SERBEST_BOLGE_IZIN_NO',p_old_SERBEST_BOLGE_IZIN_NO,p_new_SERBEST_BOLGE_IZIN_NO,ls_parametre ); END IF;
        IF (p_new_PAZAR_SORUM_SICIL_NO_1 <> p_old_PAZAR_SORUM_SICIL_NO_1) OR (p_new_PAZAR_SORUM_SICIL_NO_1 IS NULL AND p_old_PAZAR_SORUM_SICIL_NO_1 IS NOT NULL ) OR (p_new_PAZAR_SORUM_SICIL_NO_1 IS NOT NULL AND p_old_PAZAR_SORUM_SICIL_NO_1 IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'PAZARLAMA_SORUMLUSU_SICIL_NO_1',p_old_PAZAR_SORUM_SICIL_NO_1,p_new_PAZAR_SORUM_SICIL_NO_1,ls_parametre ); END IF;
        IF (p_new_PAZAR_SORUM_SICIL_NO_2 <> p_old_PAZAR_SORUM_SICIL_NO_2) OR (p_new_PAZAR_SORUM_SICIL_NO_2 IS NULL AND p_old_PAZAR_SORUM_SICIL_NO_2 IS NOT NULL ) OR (p_new_PAZAR_SORUM_SICIL_NO_2 IS NOT NULL AND p_old_PAZAR_SORUM_SICIL_NO_2 IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'PAZARLAMA_SORUMLUSU_SICIL_NO_2',p_old_PAZAR_SORUM_SICIL_NO_2,p_new_PAZAR_SORUM_SICIL_NO_2,ls_parametre ); END IF;
        IF (p_new_GRUP_KOD <> p_old_GRUP_KOD) OR (p_new_GRUP_KOD IS NULL AND p_old_GRUP_KOD IS NOT NULL ) OR (p_new_GRUP_KOD IS NOT NULL AND p_old_GRUP_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GRUP_KOD',p_old_GRUP_KOD,p_new_GRUP_KOD,ls_parametre ); END IF;
        IF (p_new_BIC_KOD <> p_old_BIC_KOD) OR (p_new_BIC_KOD IS NULL AND p_old_BIC_KOD IS NOT NULL ) OR (p_new_BIC_KOD IS NOT NULL AND p_old_BIC_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'BIC_KOD',p_old_BIC_KOD,p_new_BIC_KOD,ls_parametre ); END IF;
        IF (p_new_SWIFT_MESAJ_KOD <> p_old_SWIFT_MESAJ_KOD) OR (p_new_SWIFT_MESAJ_KOD IS NULL AND p_old_SWIFT_MESAJ_KOD IS NOT NULL ) OR (p_new_SWIFT_MESAJ_KOD IS NOT NULL AND p_old_SWIFT_MESAJ_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SWIFT_MESAJ_KOD',p_old_SWIFT_MESAJ_KOD,p_new_SWIFT_MESAJ_KOD,ls_parametre ); END IF;
        IF (p_new_REUTERS_INFO_PAGE <> p_old_REUTERS_INFO_PAGE) OR (p_new_REUTERS_INFO_PAGE IS NULL AND p_old_REUTERS_INFO_PAGE IS NOT NULL ) OR (p_new_REUTERS_INFO_PAGE IS NOT NULL AND p_old_REUTERS_INFO_PAGE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'REUTERS_INFO_PAGE',p_old_REUTERS_INFO_PAGE,p_new_REUTERS_INFO_PAGE,ls_parametre ); END IF;
        IF (p_new_REUTERS_DEALING_KOD <> p_old_REUTERS_DEALING_KOD) OR (p_new_REUTERS_DEALING_KOD IS NULL AND p_old_REUTERS_DEALING_KOD IS NOT NULL ) OR (p_new_REUTERS_DEALING_KOD IS NOT NULL AND p_old_REUTERS_DEALING_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'REUTERS_DEALING_KOD',p_old_REUTERS_DEALING_KOD,p_new_REUTERS_DEALING_KOD ,ls_parametre); END IF;
        IF (p_new_SEKTOR_ALT1_KODU <> p_old_SEKTOR_ALT1_KODU) OR (p_new_SEKTOR_ALT1_KODU IS NULL AND p_old_SEKTOR_ALT1_KODU IS NOT NULL ) OR (p_new_SEKTOR_ALT1_KODU IS NOT NULL AND p_old_SEKTOR_ALT1_KODU IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SEKTOR_ALT1_KODU',p_old_SEKTOR_ALT1_KODU,p_new_SEKTOR_ALT1_KODU ,ls_parametre); END IF;
        IF (p_new_SEKTOR_ALT2_KODU <> p_old_SEKTOR_ALT2_KODU) OR (p_new_SEKTOR_ALT2_KODU IS NULL AND p_old_SEKTOR_ALT2_KODU IS NOT NULL ) OR (p_new_SEKTOR_ALT2_KODU IS NOT NULL AND p_old_SEKTOR_ALT2_KODU IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SEKTOR_ALT2_KODU',p_old_SEKTOR_ALT2_KODU,p_new_SEKTOR_ALT2_KODU ,ls_parametre); END IF;
        IF (p_new_rating_kodu <> p_old_rating_kodu) OR (p_new_rating_kodu IS NULL AND p_old_rating_kodu IS NOT NULL ) OR (p_new_rating_kodu IS NOT NULL AND p_old_rating_kodu IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'RATING_KODU',p_old_rating_kodu,p_new_rating_kodu ,ls_parametre); END IF;
        IF (p_new_bolum_kodu <> p_old_bolum_kodu) OR (p_new_bolum_kodu IS NULL AND p_old_bolum_kodu IS NOT NULL ) OR (p_new_bolum_kodu IS NOT NULL AND p_old_bolum_kodu IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'BOLUM_KODU',p_old_bolum_kodu,p_new_bolum_kodu ,ls_parametre); END IF;
        IF (p_new_GECERLILIK_TARIHI <> p_old_GECERLILIK_TARIHI) OR (p_new_GECERLILIK_TARIHI IS NULL AND p_old_GECERLILIK_TARIHI IS NOT NULL ) OR (p_new_GECERLILIK_TARIHI IS NOT NULL AND p_old_GECERLILIK_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GECERLILIK_TARIHI',p_old_GECERLILIK_TARIHI,p_new_GECERLILIK_TARIHI ,ls_parametre); END IF;
        IF (p_new_VERGI_DAIRE_KODU <> p_old_VERGI_DAIRE_KODU) OR (p_new_VERGI_DAIRE_KODU IS NULL AND p_old_VERGI_DAIRE_KODU IS NOT NULL ) OR (p_new_VERGI_DAIRE_KODU IS NOT NULL AND p_old_VERGI_DAIRE_KODU IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VERGI_DAIRE_KODU',p_old_VERGI_DAIRE_KODU,p_new_VERGI_DAIRE_KODU ,ls_parametre); END IF;
        IF (p_new_vat_seri_no <> p_old_vat_seri_no) OR (p_new_vat_seri_no IS NULL AND p_old_vat_seri_no IS NOT NULL ) OR (p_new_vat_seri_no IS NOT NULL AND p_old_vat_seri_no IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VAT_SERI_NO',p_old_vat_seri_no,p_new_vat_seri_no ,ls_parametre); END IF;
        IF (p_new_vat_sira_no <> p_old_vat_sira_no) OR (p_new_vat_sira_no IS NULL AND p_old_vat_sira_no IS NOT NULL ) OR (p_new_vat_sira_no IS NOT NULL AND p_old_vat_sira_no IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VAT_SIRA_NO',p_old_vat_sira_no,p_new_vat_sira_no ,ls_parametre); END IF;
        IF (p_new_OKPO_CODE <> p_old_OKPO_CODE) OR (p_new_OKPO_CODE IS NULL AND p_old_OKPO_CODE IS NOT NULL ) OR (p_new_OKPO_CODE IS NOT NULL AND p_old_OKPO_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'OKPO_CODE',p_old_OKPO_CODE,p_new_OKPO_CODE ,ls_parametre); END IF;
        IF (p_new_manager_name <> p_old_manager_name) OR (p_new_manager_name IS NULL AND p_old_manager_name IS NOT NULL ) OR (p_new_manager_name IS NOT NULL AND p_old_manager_name IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MANAGER_NAME',p_old_manager_name,p_new_manager_name ,ls_parametre); END IF;
        IF (p_new_MANAGER_SURNAME <> p_old_MANAGER_SURNAME) OR (p_new_MANAGER_SURNAME IS NULL AND p_old_MANAGER_SURNAME IS NOT NULL ) OR (p_new_MANAGER_SURNAME IS NOT NULL AND p_old_MANAGER_SURNAME IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MANAGER_SURNAME',p_old_MANAGER_SURNAME,p_new_MANAGER_SURNAME ,ls_parametre); END IF;
        IF (p_new_MANAGER_PATRONYMIC_NAME <> p_old_MANAGER_PATRONYMIC_NAME) OR (p_new_MANAGER_PATRONYMIC_NAME IS NULL AND p_old_MANAGER_PATRONYMIC_NAME IS NOT NULL ) OR (p_new_MANAGER_PATRONYMIC_NAME IS NOT NULL AND p_old_MANAGER_PATRONYMIC_NAME IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MANAGER_PATRONYMIC_NAME',p_old_MANAGER_PATRONYMIC_NAME,p_new_MANAGER_PATRONYMIC_NAME ,ls_parametre); END IF;
        IF (p_new_MANAGER_COUNTRY_CODE <> p_old_MANAGER_COUNTRY_CODE) OR (p_new_MANAGER_COUNTRY_CODE IS NULL AND p_old_MANAGER_COUNTRY_CODE IS NOT NULL ) OR (p_new_MANAGER_COUNTRY_CODE IS NOT NULL AND p_old_MANAGER_COUNTRY_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MANAGER_COUNTRY_CODE',p_old_MANAGER_COUNTRY_CODE,p_new_MANAGER_COUNTRY_CODE ,ls_parametre); END IF;
        IF (p_new_MANAGER_RESIDENT_CODE <> p_old_MANAGER_RESIDENT_CODE) OR (p_new_MANAGER_RESIDENT_CODE IS NULL AND p_old_MANAGER_RESIDENT_CODE IS NOT NULL ) OR (p_new_MANAGER_RESIDENT_CODE IS NOT NULL AND p_old_MANAGER_RESIDENT_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'MANAGER_RESIDENT_CODE',p_old_MANAGER_RESIDENT_CODE,p_new_MANAGER_RESIDENT_CODE,ls_parametre ); END IF;
        IF (p_new_SECOND_MANAGER_NAME <> p_old_SECOND_MANAGER_NAME) OR (p_new_SECOND_MANAGER_NAME IS NULL AND p_old_SECOND_MANAGER_NAME IS NOT NULL ) OR (p_new_SECOND_MANAGER_NAME IS NOT NULL AND p_old_SECOND_MANAGER_NAME IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SECOND_MANAGER_NAME',p_old_SECOND_MANAGER_NAME,p_new_SECOND_MANAGER_NAME,ls_parametre ); END IF;
        IF (p_new_VERGI_ZORUNLUMU <> p_old_VERGI_ZORUNLUMU) OR (p_new_VERGI_ZORUNLUMU IS NULL AND p_old_VERGI_ZORUNLUMU IS NOT NULL ) OR (p_new_VERGI_ZORUNLUMU IS NOT NULL AND p_old_VERGI_ZORUNLUMU IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'VERGI_ZORUNLUMU',p_old_VERGI_ZORUNLUMU,p_new_VERGI_ZORUNLUMU,ls_parametre ); END IF;
        IF (p_new_SOSYAL_FON_NO <> p_old_SOSYAL_FON_NO) OR (p_new_SOSYAL_FON_NO IS NULL AND p_old_SOSYAL_FON_NO IS NOT NULL ) OR (p_new_SOSYAL_FON_NO IS NOT NULL AND p_old_SOSYAL_FON_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SOSYAL_FON_NO',p_old_SOSYAL_FON_NO,p_new_SOSYAL_FON_NO,ls_parametre ); END IF;
        IF (p_new_EKSTRE_UCRETI_ALINSIN <> p_old_EKSTRE_UCRETI_ALINSIN) OR (p_new_EKSTRE_UCRETI_ALINSIN IS NULL AND p_old_EKSTRE_UCRETI_ALINSIN IS NOT NULL ) OR (p_new_EKSTRE_UCRETI_ALINSIN IS NOT NULL AND p_old_EKSTRE_UCRETI_ALINSIN IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'EKSTRE_UCRETI_ALINSIN',p_old_EKSTRE_UCRETI_ALINSIN,p_new_EKSTRE_UCRETI_ALINSIN,ls_parametre ); END IF;
        IF (p_new_WORKING_BASIS <> p_old_WORKING_BASIS) OR (p_new_WORKING_BASIS IS NULL AND p_old_WORKING_BASIS IS NOT NULL ) OR (p_new_WORKING_BASIS IS NOT NULL AND p_old_WORKING_BASIS IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'WORKING_BASIS',p_old_WORKING_BASIS,p_new_WORKING_BASIS,ls_parametre ); END IF;
        IF (p_new_PATENT_NO <> p_old_PATENT_NO) OR (p_new_PATENT_NO IS NULL AND p_old_PATENT_NO IS NOT NULL ) OR (p_new_PATENT_NO IS NOT NULL AND p_old_PATENT_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'PATENT_NO',p_old_PATENT_NO,p_new_PATENT_NO,ls_parametre ); END IF;
        IF (p_new_PATENT_EXPIRY_DATE <> p_old_PATENT_EXPIRY_DATE) OR (p_new_PATENT_EXPIRY_DATE IS NULL AND p_old_PATENT_EXPIRY_DATE IS NOT NULL ) OR (p_new_PATENT_EXPIRY_DATE IS NOT NULL AND p_old_PATENT_EXPIRY_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'PATENT_EXPIRY_DATE',p_old_PATENT_EXPIRY_DATE,p_new_PATENT_EXPIRY_DATE,ls_parametre ); END IF;
        IF (p_new_LEGAL_FORM_CODE <> p_old_LEGAL_FORM_CODE) OR (p_new_LEGAL_FORM_CODE IS NULL AND p_old_LEGAL_FORM_CODE IS NOT NULL ) OR (p_new_LEGAL_FORM_CODE IS NOT NULL AND p_old_LEGAL_FORM_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'LEGAL_FORM_CODE',p_old_LEGAL_FORM_CODE,p_new_LEGAL_FORM_CODE,ls_parametre ); END IF;
        --B-O-M Sevalb 1112012 6270_Automatic loading of customer information from CBS to Card system
        IF (p_new_ISIM_ENG <> p_old_ISIM_ENG) OR (p_new_ISIM_ENG IS NULL AND p_old_ISIM_ENG IS NOT NULL ) OR (p_new_ISIM_ENG IS NOT NULL AND p_old_ISIM_ENG IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ISIM_ENG',p_old_ISIM_ENG,p_new_ISIM_ENG,ls_parametre ); END IF;
        IF (p_new_IKINCI_ISIM_ENG <> p_old_IKINCI_ISIM_ENG) OR (p_new_IKINCI_ISIM_ENG IS NULL AND p_old_IKINCI_ISIM_ENG IS NOT NULL ) OR (p_new_IKINCI_ISIM_ENG IS NOT NULL AND p_old_IKINCI_ISIM_ENG IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'IKINCI_ISIM_ENG',p_old_IKINCI_ISIM_ENG,p_new_IKINCI_ISIM_ENG,ls_parametre ); END IF;
        IF (p_new_SOYADI_ENG <> p_old_SOYADI_ENG) OR (p_new_SOYADI_ENG IS NULL AND p_old_SOYADI_ENG IS NOT NULL ) OR (p_new_SOYADI_ENG IS NOT NULL AND p_old_SOYADI_ENG IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri ,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SOYADI_ENG',p_old_SOYADI_ENG,p_new_SOYADI_ENG,ls_parametre ); END IF;
        --E-O-M Sevalb 1112012 6270_Automatic loading of customer information from CBS to Card system
      --BOM CBS-395 AntonPa 271022
        IF (P_NEW_MILITARY_CARD <> P_OLD_MILITARY_CARD) OR (P_NEW_MILITARY_CARD IS NULL AND P_OLD_MILITARY_CARD IS NOT NULL ) OR (P_NEW_MILITARY_CARD IS NOT NULL AND P_OLD_MILITARY_CARD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'MILITARY_CARD',P_OLD_MILITARY_CARD,P_NEW_MILITARY_CARD,LS_PARAMETRE ); END IF;
        IF (P_NEW_RESIDENCE_PERMIT <> P_OLD_RESIDENCE_PERMIT) OR (P_NEW_RESIDENCE_PERMIT IS NULL AND P_OLD_RESIDENCE_PERMIT IS NOT NULL ) OR (P_NEW_RESIDENCE_PERMIT IS NOT NULL AND P_OLD_RESIDENCE_PERMIT IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'RESIDENCE_PERMIT',P_OLD_RESIDENCE_PERMIT,P_NEW_RESIDENCE_PERMIT,LS_PARAMETRE ); END IF;
        IF (P_NEW_ECONOMY_SECTOR_CODE <> P_OLD_ECONOMY_SECTOR_CODE) OR (P_NEW_ECONOMY_SECTOR_CODE IS NULL AND P_OLD_ECONOMY_SECTOR_CODE IS NOT NULL ) OR (P_NEW_ECONOMY_SECTOR_CODE IS NOT NULL AND P_OLD_ECONOMY_SECTOR_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ECONOMY_SECTOR_CODE',P_OLD_ECONOMY_SECTOR_CODE,P_NEW_ECONOMY_SECTOR_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_BANK_RELATION_CODE <> P_OLD_BANK_RELATION_CODE) OR (P_NEW_BANK_RELATION_CODE IS NULL AND P_OLD_BANK_RELATION_CODE IS NOT NULL ) OR (P_NEW_BANK_RELATION_CODE IS NOT NULL AND P_OLD_BANK_RELATION_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'BANK_RELATION_CODE',P_OLD_BANK_RELATION_CODE,P_NEW_BANK_RELATION_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_CIVIL_STATUS_CODE <> P_OLD_CIVIL_STATUS_CODE) OR (P_NEW_CIVIL_STATUS_CODE IS NULL AND P_OLD_CIVIL_STATUS_CODE IS NOT NULL ) OR (P_NEW_CIVIL_STATUS_CODE IS NOT NULL AND P_OLD_CIVIL_STATUS_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CIVIL_STATUS_CODE',P_OLD_CIVIL_STATUS_CODE,P_NEW_CIVIL_STATUS_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_CAPITAL_PARTICIPATION_CODE <> P_OLD_CAPITAL_PARTICIPATION_CODE) OR (P_NEW_CAPITAL_PARTICIPATION_CODE IS NULL AND P_OLD_CAPITAL_PARTICIPATION_CODE IS NOT NULL ) OR (P_NEW_CAPITAL_PARTICIPATION_CODE IS NOT NULL AND P_OLD_CAPITAL_PARTICIPATION_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CAPITAL_PARTICIPATION_CODE',P_OLD_CAPITAL_PARTICIPATION_CODE,P_NEW_CAPITAL_PARTICIPATION_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_CONTROL_FORM_CODE <> P_OLD_CONTROL_FORM_CODE) OR (P_NEW_CONTROL_FORM_CODE IS NULL AND P_OLD_CONTROL_FORM_CODE IS NOT NULL ) OR (P_NEW_CONTROL_FORM_CODE IS NOT NULL AND P_OLD_CONTROL_FORM_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CONTROL_FORM_CODE',P_OLD_CONTROL_FORM_CODE,P_NEW_CONTROL_FORM_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_ECONOMIC_ACTIVITY_SUB <> P_OLD_ECONOMIC_ACTIVITY_SUB) OR (P_NEW_ECONOMIC_ACTIVITY_SUB IS NULL AND P_OLD_ECONOMIC_ACTIVITY_SUB IS NOT NULL ) OR (P_NEW_ECONOMIC_ACTIVITY_SUB IS NOT NULL AND P_OLD_ECONOMIC_ACTIVITY_SUB IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ECONOMIC_ACTIVITY_SUB',P_OLD_ECONOMIC_ACTIVITY_SUB,P_NEW_ECONOMIC_ACTIVITY_SUB,LS_PARAMETRE ); END IF;
        IF (P_NEW_ECONOMIC_ACTIVITY_CODE <> P_OLD_ECONOMIC_ACTIVITY_CODE) OR (P_NEW_ECONOMIC_ACTIVITY_CODE IS NULL AND P_OLD_ECONOMIC_ACTIVITY_CODE IS NOT NULL ) OR (P_NEW_ECONOMIC_ACTIVITY_CODE IS NOT NULL AND P_OLD_ECONOMIC_ACTIVITY_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ECONOMIC_ACTIVITY_CODE',P_OLD_ECONOMIC_ACTIVITY_CODE,P_NEW_ECONOMIC_ACTIVITY_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_TAX_INITIAL_REG_DATE <> P_OLD_TAX_INITIAL_REG_DATE) OR (P_NEW_TAX_INITIAL_REG_DATE IS NULL AND P_OLD_TAX_INITIAL_REG_DATE IS NOT NULL ) OR (P_NEW_TAX_INITIAL_REG_DATE IS NOT NULL AND P_OLD_TAX_INITIAL_REG_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_INITIAL_REG_DATE',P_OLD_TAX_INITIAL_REG_DATE,P_NEW_TAX_INITIAL_REG_DATE,LS_PARAMETRE ); END IF;
        IF (P_NEW_TAX_REG_AUTHORITY <> P_OLD_TAX_REG_AUTHORITY) OR (P_NEW_TAX_REG_AUTHORITY IS NULL AND P_OLD_TAX_REG_AUTHORITY IS NOT NULL ) OR (P_NEW_TAX_REG_AUTHORITY IS NOT NULL AND P_OLD_TAX_REG_AUTHORITY IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_REG_AUTHORITY',P_OLD_TAX_REG_AUTHORITY,P_NEW_TAX_REG_AUTHORITY,LS_PARAMETRE ); END IF;
        IF (P_NEW_TAX_RE_REG_DATE <> P_OLD_TAX_RE_REG_DATE) OR (P_NEW_TAX_RE_REG_DATE IS NULL AND P_OLD_TAX_RE_REG_DATE IS NOT NULL ) OR (P_NEW_TAX_RE_REG_DATE IS NOT NULL AND P_OLD_TAX_RE_REG_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_RE_REG_DATE',P_OLD_TAX_RE_REG_DATE,P_NEW_TAX_RE_REG_DATE,LS_PARAMETRE ); END IF;
        IF (P_NEW_TAX_REG_COUNTRY_CODE <> P_OLD_TAX_REG_COUNTRY_CODE) OR (P_NEW_TAX_REG_COUNTRY_CODE IS NULL AND P_OLD_TAX_REG_COUNTRY_CODE IS NOT NULL ) OR (P_NEW_TAX_REG_COUNTRY_CODE IS NOT NULL AND P_OLD_TAX_REG_COUNTRY_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_REG_COUNTRY_CODE',P_OLD_TAX_REG_COUNTRY_CODE,P_NEW_TAX_REG_COUNTRY_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_IS_LICENSED <> P_OLD_IS_LICENSED) OR (P_NEW_IS_LICENSED IS NULL AND P_OLD_IS_LICENSED IS NOT NULL ) OR (P_NEW_IS_LICENSED IS NOT NULL AND P_OLD_IS_LICENSED IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'IS_LICENSED',P_OLD_IS_LICENSED,P_NEW_IS_LICENSED,LS_PARAMETRE ); END IF;
        IF (P_NEW_MANAGER_GENDER <> P_OLD_MANAGER_GENDER) OR (P_NEW_MANAGER_GENDER IS NULL AND P_OLD_MANAGER_GENDER IS NOT NULL ) OR (P_NEW_MANAGER_GENDER IS NOT NULL AND P_OLD_MANAGER_GENDER IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'MANAGER_GENDER',P_OLD_MANAGER_GENDER,P_NEW_MANAGER_GENDER,LS_PARAMETRE ); END IF;
        IF (P_NEW_DECLARED_SHARE_CAPITAL <> P_OLD_DECLARED_SHARE_CAPITAL) OR (P_NEW_DECLARED_SHARE_CAPITAL IS NULL AND P_OLD_DECLARED_SHARE_CAPITAL IS NOT NULL ) OR (P_NEW_DECLARED_SHARE_CAPITAL IS NOT NULL AND P_OLD_DECLARED_SHARE_CAPITAL IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'DECLARED_SHARE_CAPITAL',P_OLD_DECLARED_SHARE_CAPITAL,P_NEW_DECLARED_SHARE_CAPITAL,LS_PARAMETRE ); END IF;
        IF (P_NEW_SHARE_CAPITAL_CURRENCY <> P_OLD_SHARE_CAPITAL_CURRENCY) OR (P_NEW_SHARE_CAPITAL_CURRENCY IS NULL AND P_OLD_SHARE_CAPITAL_CURRENCY IS NOT NULL ) OR (P_NEW_SHARE_CAPITAL_CURRENCY IS NOT NULL AND P_OLD_SHARE_CAPITAL_CURRENCY IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'SHARE_CAPITAL_CURRENCY',P_OLD_SHARE_CAPITAL_CURRENCY,P_NEW_SHARE_CAPITAL_CURRENCY,LS_PARAMETRE ); END IF;
        IF (P_NEW_PAID_SHARE_CAPITAL <> P_OLD_PAID_SHARE_CAPITAL) OR (P_NEW_PAID_SHARE_CAPITAL IS NULL AND P_OLD_PAID_SHARE_CAPITAL IS NOT NULL ) OR (P_NEW_PAID_SHARE_CAPITAL IS NOT NULL AND P_OLD_PAID_SHARE_CAPITAL IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'PAID_SHARE_CAPITAL',P_OLD_PAID_SHARE_CAPITAL,P_NEW_PAID_SHARE_CAPITAL,LS_PARAMETRE ); END IF;
        IF (P_NEW_PDL_CODE <> P_OLD_PDL_CODE) OR (P_NEW_PDL_CODE IS NULL AND P_OLD_PDL_CODE IS NOT NULL ) OR (P_NEW_PDL_CODE IS NOT NULL AND P_OLD_PDL_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'PDL_CODE',P_OLD_PDL_CODE,P_NEW_PDL_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_BIRTH_CERTIFICATE <> P_OLD_BIRTH_CERTIFICATE) OR (P_NEW_BIRTH_CERTIFICATE IS NULL AND P_OLD_BIRTH_CERTIFICATE IS NOT NULL ) OR (P_NEW_BIRTH_CERTIFICATE IS NOT NULL AND P_OLD_BIRTH_CERTIFICATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'BIRTH_CERTIFICATE',P_OLD_BIRTH_CERTIFICATE,P_NEW_BIRTH_CERTIFICATE,LS_PARAMETRE ); END IF;
        IF (P_NEW_COMPANY_NAME_KYR <> P_OLD_COMPANY_NAME_KYR) OR (P_NEW_COMPANY_NAME_KYR IS NULL AND P_OLD_COMPANY_NAME_KYR IS NOT NULL ) OR (P_NEW_COMPANY_NAME_KYR IS NOT NULL AND P_OLD_COMPANY_NAME_KYR IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'COMPANY_NAME_KYR',P_OLD_COMPANY_NAME_KYR,P_NEW_COMPANY_NAME_KYR,LS_PARAMETRE ); END IF;
        IF (P_NEW_OPF_ID_CODE <> P_OLD_OPF_ID_CODE) OR (P_NEW_OPF_ID_CODE IS NULL AND P_OLD_OPF_ID_CODE IS NOT NULL ) OR (P_NEW_OPF_ID_CODE IS NOT NULL AND P_OLD_OPF_ID_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI ,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'OPF_ID_CODE',P_OLD_OPF_ID_CODE,P_NEW_OPF_ID_CODE,LS_PARAMETRE ); END IF;
      --EOM CBS-395 AntonPa 271022
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '104' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
      END Sp_Log_Musteri_Guncel_Alan;


    /*************************************************************************************************************************/
    /*   Procedure Sp_Log_Musteri_Adres_Guncel                                                                               */
    /*   Guncelleme Adres tablosunun degisen degerleri loglanir.Cbs_Trg_Upd_Musteri_Guncel_Adr triggerindan cagrilir.        */
    /*************************************************************************************************************************/
    PROCEDURE Sp_Log_Musteri_Adres_Guncel(ps_table_name                VARCHAR2,
                                          p_new_adres_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.adres_kod%TYPE,
                                          --p_new_adres                  CBS.CBS_MUSTERI_GUNCEL_ADRES.adres%TYPE,--CBS-395 AntonPa 271022
                                          p_new_semt                   CBS.CBS_MUSTERI_GUNCEL_ADRES.semt%TYPE,
                                          p_new_il_kod                 CBS.CBS_MUSTERI_GUNCEL_ADRES.il_kod%TYPE,
                                          p_new_posta_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.posta_kod%TYPE,
                                          p_new_ulke_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ulke_kod%TYPE,
                                          p_new_email                  CBS.CBS_MUSTERI_GUNCEL_ADRES.email%TYPE,
                                          p_new_tel_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_alan_kod%TYPE,
                                          p_new_tel_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_no%TYPE,
                                          p_new_gsm_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_alan_kod%TYPE,
                                          p_new_gsm_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_no%TYPE,
                                          p_new_fax_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_alan_kod%TYPE,
                                          p_new_fax_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_no%TYPE,
                                          p_new_ilk_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.ilk_gecerlilik_tarihi%TYPE,
                                          p_new_son_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.son_gecerlilik_tarihi%TYPE,
                                          p_new_ilce_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ilce_kod%TYPE,
                                          p_new_isyeri_unvani          CBS.CBS_MUSTERI_GUNCEL_ADRES.ISYERI_UNVANI%TYPE,
                                        --BOM AntonPa CBS-395 271022
                                          P_NEW_REGION_CODE            CBS.CBS_MUSTERI_GUNCEL_ADRES.REGION_CODE%TYPE,
                                          P_NEW_DISTRICT_CODE          CBS.CBS_MUSTERI_GUNCEL_ADRES.DISTRICT_CODE%TYPE,
                                          P_NEW_SETTLEMENT_CODE        CBS.CBS_MUSTERI_GUNCEL_ADRES.SETTLEMENT_CODE%TYPE,
                                          P_NEW_VILLAGE_CODE           CBS.CBS_MUSTERI_GUNCEL_ADRES.VILLAGE_CODE%TYPE,
                                          P_NEW_DIGITAL_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.DIGITAL_ADDRESS%TYPE,
                                          P_NEW_IS_SAME_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.IS_SAME_ADDRESS%TYPE,
                                          P_NEW_ADDRESS_STREET         CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_STREET%TYPE,
                                          P_NEW_ADDRESS_HOUSE_NO       CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_HOUSE_NO%TYPE,
                                          P_NEW_ADDRESS_APARTMENT_NO   CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_APARTMENT_NO%TYPE,
                                          P_NEW_WEBSITE                CBS.CBS_MUSTERI_GUNCEL_ADRES.WEBSITE%TYPE,
                                        --EOM AntonPa CBS-395 271022
                                          p_old_adres_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.adres_kod%TYPE,
                                          --p_old_adres                  CBS.CBS_MUSTERI_GUNCEL_ADRES.adres%TYPE,--CBS-395 AntonPa 271022
                                          p_old_semt                   CBS.CBS_MUSTERI_GUNCEL_ADRES.semt%TYPE,
                                          p_old_il_kod                 CBS.CBS_MUSTERI_GUNCEL_ADRES.il_kod%TYPE,
                                          p_old_posta_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.posta_kod%TYPE,
                                          p_old_ulke_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ulke_kod%TYPE,
                                          p_old_email                  CBS.CBS_MUSTERI_GUNCEL_ADRES.email%TYPE,
                                          p_old_tel_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_alan_kod%TYPE,
                                          p_old_tel_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_no%TYPE,
                                          p_old_gsm_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_alan_kod%TYPE,
                                          p_old_gsm_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_no%TYPE,
                                          p_old_fax_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_alan_kod%TYPE,
                                          p_old_fax_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_no%TYPE,
                                          p_old_ilk_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.ilk_gecerlilik_tarihi%TYPE,
                                          p_old_son_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.son_gecerlilik_tarihi%TYPE,
                                          p_old_ilce_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ilce_kod%TYPE,
                                          p_old_isyeri_unvani          CBS.CBS_MUSTERI_GUNCEL_ADRES.ISYERI_UNVANI%TYPE,
                                        --BOM AntonPa CBS-395 271022
                                          P_OLD_REGION_CODE            CBS.CBS_MUSTERI_GUNCEL_ADRES.REGION_CODE%TYPE,
                                          P_OLD_DISTRICT_CODE          CBS.CBS_MUSTERI_GUNCEL_ADRES.DISTRICT_CODE%TYPE,
                                          P_OLD_SETTLEMENT_CODE        CBS.CBS_MUSTERI_GUNCEL_ADRES.SETTLEMENT_CODE%TYPE,
                                          P_OLD_VILLAGE_CODE           CBS.CBS_MUSTERI_GUNCEL_ADRES.VILLAGE_CODE%TYPE,
                                          P_OLD_DIGITAL_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.DIGITAL_ADDRESS%TYPE,
                                          P_OLD_IS_SAME_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.IS_SAME_ADDRESS%TYPE,
                                          P_OLD_ADDRESS_STREET         CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_STREET%TYPE,
                                          P_OLD_ADDRESS_HOUSE_NO       CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_HOUSE_NO%TYPE,
                                          P_OLD_ADDRESS_APARTMENT_NO   CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_APARTMENT_NO%TYPE,
                                          P_OLD_WEBSITE                CBS.CBS_MUSTERI_GUNCEL_ADRES.WEBSITE%TYPE,
                                        --EOM AntonPa CBS-395 271022
                                          pn_tx_no                     CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE) IS
        ls_table_name VARCHAR2(100) := ps_table_name;
        ls_parametre  VARCHAR2(100) := p_new_adres_kod;
    BEGIN
        IF (p_new_ADRES_KOD <> p_old_ADRES_KOD ) OR (p_new_ADRES_KOD IS NULL AND p_old_ADRES_KOD IS NOT NULL ) OR (p_new_ADRES_KOD IS NOT NULL AND p_old_ADRES_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ADRES_KOD',p_old_ADRES_KOD,p_new_ADRES_KOD,ls_parametre); END IF;
        --IF (p_new_ADRES <> p_old_ADRES ) OR (p_new_ADRES IS NULL AND p_old_ADRES IS NOT NULL ) OR (p_new_ADRES IS NOT NULL AND p_old_ADRES IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ADRES',p_old_ADRES,p_new_ADRES,ls_parametre); END IF;
        IF (p_new_SEMT <> p_old_SEMT ) OR (p_new_SEMT IS NULL AND p_old_SEMT IS NOT NULL ) OR (p_new_SEMT IS NOT NULL AND p_old_SEMT IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SEMT',p_old_SEMT,p_new_SEMT,p_old_ADRES_KOD); END IF;
        IF (p_new_IL_KOD <> p_old_IL_KOD ) OR (p_new_IL_KOD IS NULL AND p_old_IL_KOD IS NOT NULL ) OR (p_new_IL_KOD IS NOT NULL AND p_old_IL_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'IL_KOD',p_old_IL_KOD,p_new_IL_KOD,ls_parametre); END IF;
        IF (p_new_POSTA_KOD <> p_old_POSTA_KOD ) OR (p_new_POSTA_KOD IS NULL AND p_old_POSTA_KOD IS NOT NULL ) OR (p_new_POSTA_KOD IS NOT NULL AND p_old_POSTA_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'POSTA_KOD',p_old_POSTA_KOD,p_new_POSTA_KOD,ls_parametre); END IF;
        IF (p_new_ULKE_KOD <> p_old_ULKE_KOD ) OR (p_new_ULKE_KOD IS NULL AND p_old_ULKE_KOD IS NOT NULL ) OR (p_new_ULKE_KOD IS NOT NULL AND p_old_ULKE_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ULKE_KOD',p_old_ULKE_KOD,p_new_ULKE_KOD,ls_parametre); END IF;
        IF (p_new_EMAIL <> p_old_EMAIL ) OR (p_new_EMAIL IS NULL AND p_old_EMAIL IS NOT NULL ) OR (p_new_EMAIL IS NOT NULL AND p_old_EMAIL IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'EMAIL',p_old_EMAIL,p_new_EMAIL,ls_parametre); END IF;
        IF (p_new_TEL_ALAN_KOD <> p_old_TEL_ALAN_KOD ) OR (p_new_TEL_ALAN_KOD IS NULL AND p_old_TEL_ALAN_KOD IS NOT NULL ) OR (p_new_TEL_ALAN_KOD IS NOT NULL AND p_old_TEL_ALAN_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'TEL_ALAN_KOD',p_old_TEL_ALAN_KOD,p_new_TEL_ALAN_KOD,ls_parametre); END IF;
        IF (p_new_TEL_NO <> p_old_TEL_NO ) OR (p_new_TEL_NO IS NULL AND p_old_TEL_NO IS NOT NULL ) OR (p_new_TEL_NO IS NOT NULL AND p_old_TEL_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'TEL_NO',p_old_TEL_NO,p_new_TEL_NO,ls_parametre); END IF;
        IF (p_new_GSM_ALAN_KOD <> p_old_GSM_ALAN_KOD ) OR (p_new_GSM_ALAN_KOD IS NULL AND p_old_GSM_ALAN_KOD IS NOT NULL ) OR (p_new_GSM_ALAN_KOD IS NOT NULL AND p_old_GSM_ALAN_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GSM_ALAN_KOD',p_old_GSM_ALAN_KOD,p_new_GSM_ALAN_KOD,ls_parametre); END IF;
        IF (p_new_GSM_NO <> p_old_GSM_NO ) OR (p_new_GSM_NO IS NULL AND p_old_GSM_NO IS NOT NULL ) OR (p_new_GSM_NO IS NOT NULL AND p_old_GSM_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GSM_NO',p_old_GSM_NO,p_new_GSM_NO,ls_parametre); END IF;
        IF (p_new_FAX_ALAN_KOD <> p_old_FAX_ALAN_KOD ) OR (p_new_FAX_ALAN_KOD IS NULL AND p_old_FAX_ALAN_KOD IS NOT NULL ) OR (p_new_FAX_ALAN_KOD IS NOT NULL AND p_old_FAX_ALAN_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'FAX_ALAN_KOD',p_old_FAX_ALAN_KOD,p_new_FAX_ALAN_KOD,ls_parametre); END IF;
        IF (p_new_FAX_NO <> p_old_FAX_NO ) OR (p_new_FAX_NO IS NULL AND p_old_FAX_NO IS NOT NULL ) OR (p_new_FAX_NO IS NOT NULL AND p_old_FAX_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'FAX_NO',p_old_FAX_NO,p_new_FAX_NO,ls_parametre); END IF;
        IF (p_new_ILK_GECERLILIK_TARIHI <> p_old_ILK_GECERLILIK_TARIHI ) OR (p_new_ILK_GECERLILIK_TARIHI IS NULL AND p_old_ILK_GECERLILIK_TARIHI IS NOT NULL ) OR (p_new_ILK_GECERLILIK_TARIHI IS NOT NULL AND p_old_ILK_GECERLILIK_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ILK_GECERLILIK_TARIHI',p_old_ILK_GECERLILIK_TARIHI,p_new_ILK_GECERLILIK_TARIHI,ls_parametre); END IF;
        IF (p_new_SON_GECERLILIK_TARIHI <> p_old_SON_GECERLILIK_TARIHI ) OR (p_new_SON_GECERLILIK_TARIHI IS NULL AND p_old_SON_GECERLILIK_TARIHI IS NOT NULL ) OR (p_new_SON_GECERLILIK_TARIHI IS NOT NULL AND p_old_SON_GECERLILIK_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'SON_GECERLILIK_TARIHI',p_old_SON_GECERLILIK_TARIHI,p_new_SON_GECERLILIK_TARIHI,ls_parametre); END IF;
        IF (p_new_ILCE_KOD <> p_old_ILCE_KOD ) OR (p_new_ILCE_KOD IS NULL AND p_old_ILCE_KOD IS NOT NULL ) OR (p_new_ILCE_KOD IS NOT NULL AND p_old_ILCE_KOD IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ILCE_KOD',p_old_ILCE_KOD,p_new_ILCE_KOD,ls_parametre); END IF;
        IF (p_new_ISYERI_UNVANI <> p_old_ISYERI_UNVANI ) OR (p_new_ISYERI_UNVANI IS NULL AND p_old_ISYERI_UNVANI IS NOT NULL ) OR (p_new_ISYERI_UNVANI IS NOT NULL AND p_old_ISYERI_UNVANI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ISYERI_UNVANI',p_old_ISYERI_UNVANI,p_new_ISYERI_UNVANI,ls_parametre); END IF;
      --BOM AntonPa CBS-395 271022
        IF (P_NEW_REGION_CODE <> P_OLD_REGION_CODE ) OR (P_NEW_REGION_CODE IS NULL AND P_OLD_REGION_CODE IS NOT NULL ) OR (P_NEW_REGION_CODE IS NOT NULL AND P_OLD_REGION_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'REGION_CODE',P_OLD_REGION_CODE,P_NEW_REGION_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_DISTRICT_CODE <> P_OLD_DISTRICT_CODE ) OR (P_NEW_DISTRICT_CODE IS NULL AND P_OLD_DISTRICT_CODE IS NOT NULL ) OR (P_NEW_DISTRICT_CODE IS NOT NULL AND P_OLD_DISTRICT_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'DISTRICT_CODE',P_OLD_DISTRICT_CODE,P_NEW_DISTRICT_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_SETTLEMENT_CODE <> P_OLD_SETTLEMENT_CODE ) OR (P_NEW_SETTLEMENT_CODE IS NULL AND P_OLD_SETTLEMENT_CODE IS NOT NULL ) OR (P_NEW_SETTLEMENT_CODE IS NOT NULL AND P_OLD_SETTLEMENT_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'SETTLEMENT_CODE',P_OLD_SETTLEMENT_CODE,P_NEW_SETTLEMENT_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_VILLAGE_CODE <> P_OLD_VILLAGE_CODE ) OR (P_NEW_VILLAGE_CODE IS NULL AND P_OLD_VILLAGE_CODE IS NOT NULL ) OR (P_NEW_VILLAGE_CODE IS NOT NULL AND P_OLD_VILLAGE_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'VILLAGE_CODE',P_OLD_VILLAGE_CODE,P_NEW_VILLAGE_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_DIGITAL_ADDRESS <> P_OLD_DIGITAL_ADDRESS ) OR (P_NEW_DIGITAL_ADDRESS IS NULL AND P_OLD_DIGITAL_ADDRESS IS NOT NULL ) OR (P_NEW_DIGITAL_ADDRESS IS NOT NULL AND P_OLD_DIGITAL_ADDRESS IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'DIGITAL_ADDRESS',P_OLD_DIGITAL_ADDRESS,P_NEW_DIGITAL_ADDRESS,LS_PARAMETRE); END IF;
        IF (P_NEW_IS_SAME_ADDRESS <> P_OLD_IS_SAME_ADDRESS ) OR (P_NEW_IS_SAME_ADDRESS IS NULL AND P_OLD_IS_SAME_ADDRESS IS NOT NULL ) OR (P_NEW_IS_SAME_ADDRESS IS NOT NULL AND P_OLD_IS_SAME_ADDRESS IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'IS_SAME_ADDRESS',P_OLD_IS_SAME_ADDRESS,P_NEW_IS_SAME_ADDRESS,LS_PARAMETRE); END IF;
        IF (P_NEW_ADDRESS_STREET <> P_OLD_ADDRESS_STREET ) OR (P_NEW_ADDRESS_STREET IS NULL AND P_OLD_ADDRESS_STREET IS NOT NULL ) OR (P_NEW_ADDRESS_STREET IS NOT NULL AND P_OLD_ADDRESS_STREET IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ADDRESS_STREET',P_OLD_ADDRESS_STREET,P_NEW_ADDRESS_STREET,LS_PARAMETRE); END IF;
        IF (P_NEW_ADDRESS_HOUSE_NO <> P_OLD_ADDRESS_HOUSE_NO ) OR (P_NEW_ADDRESS_HOUSE_NO IS NULL AND P_OLD_ADDRESS_HOUSE_NO IS NOT NULL ) OR (P_NEW_ADDRESS_HOUSE_NO IS NOT NULL AND P_OLD_ADDRESS_HOUSE_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ADDRESS_HOUSE_NO',P_OLD_ADDRESS_HOUSE_NO,P_NEW_ADDRESS_HOUSE_NO,LS_PARAMETRE); END IF;
        IF (P_NEW_ADDRESS_APARTMENT_NO <> P_OLD_ADDRESS_APARTMENT_NO ) OR (P_NEW_ADDRESS_APARTMENT_NO IS NULL AND P_OLD_ADDRESS_APARTMENT_NO IS NOT NULL ) OR (P_NEW_ADDRESS_APARTMENT_NO IS NOT NULL AND P_OLD_ADDRESS_APARTMENT_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ADDRESS_APARTMENT_NO',P_OLD_ADDRESS_APARTMENT_NO,P_NEW_ADDRESS_APARTMENT_NO,LS_PARAMETRE); END IF;
        IF (P_NEW_WEBSITE <> P_OLD_WEBSITE ) OR (P_NEW_WEBSITE IS NULL AND P_OLD_WEBSITE IS NOT NULL ) OR (P_NEW_WEBSITE IS NOT NULL AND P_OLD_WEBSITE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'WEBSITE',P_OLD_WEBSITE,P_NEW_WEBSITE,LS_PARAMETRE); END IF;
      --EOM AntonPa CBS-395 271022
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '104' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END sp_log_musteri_adres_guncel;

    /*************************************************************************************************************************/
    /*   Procedure Sp_Log_Musteri_Notlar_Guncel                                                                              */
    /*   Guncelleme Notlar tablosunun degisen degerleri loglanir.Cbs_Trg_Upd_Musteri_Guncel_Not triggerindan cagrilir.       */
    /*************************************************************************************************************************/
    PROCEDURE Sp_Log_Musteri_Notlar_Guncel(ps_table_name            VARCHAR2, 
                                           p_new_not_tipi           CBS.CBS_MUSTERI_GUNCEL_NOTLAR.not_tipi%TYPE, 
                                           p_new_ALINAN_NOTLAR      CBS.CBS_MUSTERI_GUNCEL_NOTLAR.ALINAN_NOTLAR%TYPE, 
                                           p_new_GIRIS_TARIHI       CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GIRIS_TARIHI%TYPE, 
                                           p_new_KULLANICI_KODU     CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KULLANICI_KODU%TYPE, 
                                           p_new_GORUSME_BILGILERI  CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_BILGILERI%TYPE, 
                                           p_new_GORUSME_NOTU       CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_NOTU%TYPE, 
                                           p_new_KATILANLAR         CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KATILANLAR%TYPE, 
                                           p_new_GORUSME_TARIHI     CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_TARIHI%TYPE, 
                                           p_new_BASLANGIC_SAATI    CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BASLANGIC_SAATI%TYPE, 
                                           p_new_BITIS_SAATI        CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BITIS_SAATI%TYPE, 
                                           p_old_not_tipi           CBS.CBS_MUSTERI_GUNCEL_NOTLAR.not_tipi%TYPE, 
                                           p_old_ALINAN_NOTLAR      CBS.CBS_MUSTERI_GUNCEL_NOTLAR.ALINAN_NOTLAR%TYPE, 
                                           p_old_GIRIS_TARIHI       CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GIRIS_TARIHI%TYPE, 
                                           p_old_KULLANICI_KODU     CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KULLANICI_KODU%TYPE, 
                                           p_old_GORUSME_BILGILERI  CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_BILGILERI%TYPE, 
                                           p_old_GORUSME_NOTU       CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_NOTU%TYPE, 
                                           p_old_KATILANLAR         CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KATILANLAR%TYPE, 
                                           p_old_GORUSME_TARIHI     CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_TARIHI%TYPE, 
                                           p_old_BASLANGIC_SAATI    CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BASLANGIC_SAATI%TYPE, 
                                           p_old_BITIS_SAATI        CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BITIS_SAATI%TYPE, 
                                           pn_tx_no                 CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE, 
                                           pn_sira_no               CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.sira_no%TYPE) IS
        ls_table_name VARCHAR2(100) := ps_table_name;
        ls_parametre  VARCHAR2(100) := pn_sira_no;
    BEGIN
        --    if (p_new_NOT_TIPI <> p_old_NOT_TIPI ) OR (p_new_NOT_TIPI is null and p_old_NOT_TIPI is not null ) OR (p_new_NOT_TIPI is not null and p_old_ALINAN_NOTLAR is null )  then insert into CBS.cbs_log_guncellenen_alan(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   values (pn_tx_no ,ls_table_name,user,sysdate,'NOT_TIPI',p_old_NOT_TIPI,p_new_NOT_TIPI,ls_parametre); end if;
        IF (p_new_ALINAN_NOTLAR <> p_old_ALINAN_NOTLAR ) OR (p_new_ALINAN_NOTLAR IS NULL AND p_old_ALINAN_NOTLAR IS NOT NULL ) OR (p_new_ALINAN_NOTLAR IS NOT NULL AND p_old_ALINAN_NOTLAR IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ALINAN_NOTLAR',p_old_ALINAN_NOTLAR,p_new_ALINAN_NOTLAR,ls_parametre); END IF;
        IF (p_new_GIRIS_TARIHI <> p_old_GIRIS_TARIHI ) OR (p_new_GIRIS_TARIHI IS NULL AND p_old_GIRIS_TARIHI IS NOT NULL ) OR (p_new_GIRIS_TARIHI IS NOT NULL AND p_old_GIRIS_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GIRIS_TARIHI',p_old_GIRIS_TARIHI,p_new_GIRIS_TARIHI,ls_parametre); END IF;
        IF (p_new_KULLANICI_KODU <> p_old_KULLANICI_KODU ) OR (p_new_KULLANICI_KODU IS NULL AND p_old_KULLANICI_KODU IS NOT NULL ) OR (p_new_KULLANICI_KODU IS NOT NULL AND p_old_KULLANICI_KODU IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'KULLANICI_KODU',p_old_KULLANICI_KODU,p_new_KULLANICI_KODU,ls_parametre); END IF;
        IF (p_new_GORUSME_BILGILERI <> p_old_GORUSME_BILGILERI ) OR (p_new_GORUSME_BILGILERI IS NULL AND p_old_GORUSME_BILGILERI IS NOT NULL ) OR (p_new_GORUSME_BILGILERI IS NOT NULL AND p_old_GORUSME_BILGILERI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GORUSME_BILGILERI',p_old_GORUSME_BILGILERI,p_new_GORUSME_BILGILERI,ls_parametre); END IF;
        IF (p_new_GORUSME_NOTU <> p_old_GORUSME_NOTU ) OR (p_new_GORUSME_NOTU IS NULL AND p_old_GORUSME_NOTU IS NOT NULL ) OR (p_new_GORUSME_NOTU IS NOT NULL AND p_old_GORUSME_NOTU IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GORUSME_NOTU',p_old_GORUSME_NOTU,p_new_GORUSME_NOTU,ls_parametre); END IF;
        IF (p_new_KATILANLAR <> p_old_KATILANLAR ) OR (p_new_KATILANLAR IS NULL AND p_old_KATILANLAR IS NOT NULL ) OR (p_new_KATILANLAR IS NOT NULL AND p_old_KATILANLAR IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'KATILANLAR',p_old_KATILANLAR,p_new_KATILANLAR,ls_parametre); END IF;
        IF (p_new_GORUSME_TARIHI <> p_old_GORUSME_TARIHI ) OR (p_new_GORUSME_TARIHI IS NULL AND p_old_GORUSME_TARIHI IS NOT NULL ) OR (p_new_GORUSME_TARIHI IS NOT NULL AND p_old_GORUSME_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GORUSME_TARIHI',p_old_GORUSME_TARIHI,p_new_GORUSME_TARIHI,ls_parametre); END IF;
        IF (p_new_BASLANGIC_SAATI <> p_old_BASLANGIC_SAATI ) OR (p_new_BASLANGIC_SAATI IS NULL AND p_old_BASLANGIC_SAATI IS NOT NULL ) OR (p_new_BASLANGIC_SAATI IS NOT NULL AND p_old_BASLANGIC_SAATI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'BASLANGIC_SAATI',p_old_BASLANGIC_SAATI,p_new_BASLANGIC_SAATI,ls_parametre); END IF;
        IF (p_new_BITIS_SAATI <> p_old_BITIS_SAATI ) OR (p_new_BITIS_SAATI IS NULL AND p_old_BITIS_SAATI IS NOT NULL ) OR (p_new_BITIS_SAATI IS NOT NULL AND p_old_BITIS_SAATI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'BITIS_SAATI',p_old_BITIS_SAATI,p_new_BITIS_SAATI,ls_parametre); END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '104' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END sp_log_musteri_notlar_guncel;

    /*************************************************************************************************************************/
    /*   Procedure Sp_Log_Musteri_Dokuman_Guncel                                                                             */
    /*   Guncelleme dokuman tablosunun degisen degerleri loglanir.Cbs_Trg_Upd_Musteri_Guncel_Dok triggerindan cagrilir.      */
    /*************************************************************************************************************************/
    PROCEDURE Sp_Log_Musteri_Dokuman_Guncel(ps_table_name           VARCHAR2, 
                                            p_new_DOKUMAN_ADI       CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DOKUMAN_ADI%TYPE, 
                                            p_new_ALINDI_KUTUSU_F   CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.ALINDI_KUTUSU_F%TYPE, 
                                            p_new_DUZENLENME_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DUZENLENME_TARIHI%TYPE, 
                                            p_new_GECERLILIK_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.GECERLILIK_TARIHI%TYPE, 
                                            p_old_DOKUMAN_ADI       CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DOKUMAN_ADI%TYPE, 
                                            p_old_ALINDI_KUTUSU_F   CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.ALINDI_KUTUSU_F%TYPE, 
                                            p_old_DUZENLENME_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DUZENLENME_TARIHI%TYPE, 
                                            p_old_GECERLILIK_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.GECERLILIK_TARIHI%TYPE, 
                                            pn_tx_no                CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE, 
                                            pn_sira_no              CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.sira_no%TYPE) IS
        ls_table_name VARCHAR2(100) := ps_table_name;
        ls_parametre  VARCHAR2(100) := pn_sira_no;
    BEGIN
        IF (p_new_DOKUMAN_ADI <> p_old_DOKUMAN_ADI ) OR (p_new_DOKUMAN_ADI IS NULL AND p_old_DOKUMAN_ADI IS NOT NULL ) OR (p_new_DOKUMAN_ADI IS NOT NULL AND p_old_DOKUMAN_ADI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'DOKUMAN_ADI',p_old_DOKUMAN_ADI,p_new_DOKUMAN_ADI,ls_parametre); END IF;
        IF (p_new_ALINDI_KUTUSU_F <> p_old_ALINDI_KUTUSU_F ) OR (p_new_ALINDI_KUTUSU_F IS NULL AND p_old_ALINDI_KUTUSU_F IS NOT NULL ) OR (p_new_ALINDI_KUTUSU_F IS NOT NULL AND p_old_ALINDI_KUTUSU_F IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'ALINDI_KUTUSU_F',p_old_ALINDI_KUTUSU_F,p_new_ALINDI_KUTUSU_F,ls_parametre); END IF;
        IF (p_new_DUZENLENME_TARIHI <> p_old_DUZENLENME_TARIHI ) OR (p_new_DUZENLENME_TARIHI IS NULL AND p_old_DUZENLENME_TARIHI IS NOT NULL ) OR (p_new_DUZENLENME_TARIHI IS NOT NULL AND p_old_DUZENLENME_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'DUZENLENME_TARIHI',p_old_DUZENLENME_TARIHI,p_new_DUZENLENME_TARIHI,ls_parametre); END IF;
        IF (p_new_GECERLILIK_TARIHI <> p_old_GECERLILIK_TARIHI ) OR (p_new_GECERLILIK_TARIHI IS NULL AND p_old_GECERLILIK_TARIHI IS NOT NULL ) OR (p_new_GECERLILIK_TARIHI IS NOT NULL AND p_old_GECERLILIK_TARIHI IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(tx_no, blok_adi,kullanici_kodu, tarih , alan_adi,eski_degeri, yeni_degeri,parametre)   VALUES (pn_tx_no ,ls_table_name,USER,SYSDATE,'GECERLILIK_TARIHI',p_old_GECERLILIK_TARIHI,p_new_GECERLILIK_TARIHI,ls_parametre); END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '104' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END sp_log_musteri_dokuman_guncel;


    /*************************************************************************************************************************/
    /*   Procedure Sp_Log_Musteri_Ortaklik_Guncel                                                                            */
    /*   Guncelleme Ortaklgk tablosunun deiiien deierleri loglanir.Cbs_Trg_Upd_Musteri_Guncel_Ort triggerindan cagrilir.     */
    /*************************************************************************************************************************/
    PROCEDURE Sp_Log_Musteri_Ortaklik_Guncel(ps_table_name    VARCHAR2,
                                             P_NEW_FIRST_NAME                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.FIRST_NAME%TYPE,
                                             P_NEW_OWNERSHIP                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OWNERSHIP%TYPE,
                                             P_NEW_BIRTH_DATE                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BIRTH_DATE%TYPE,
                                             P_NEW_CITIZEN_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CITIZEN_CODE%TYPE,
                                             P_NEW_BENEFICIARY_TYPE           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_TYPE%TYPE,
                                             P_NEW_CUSTOMER_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_CUSTOMER_NO%TYPE,
                                             P_NEW_COMPANY_INN                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_INN%TYPE,
                                             P_NEW_BENEFICIARY_INN            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_INN%TYPE,
                                             P_NEW_SURNAME                    CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SURNAME%TYPE,
                                             P_NEW_SECOND_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SECOND_NAME%TYPE,
                                             P_NEW_GENDER_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.GENDER_CODE%TYPE,
                                             P_NEW_PASSPORT_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PASSPORT_NO%TYPE,
                                             P_NEW_VALIDITY_DATE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VALIDITY_DATE%TYPE,
                                             P_NEW_ISSUED_BY                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ISSUED_BY%TYPE,
                                             P_NEW_STREET_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.STREET_NAME%TYPE,
                                             P_NEW_HOUSE_NO                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.HOUSE_NO%TYPE,
                                             P_NEW_APARTMENT_NO               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.APARTMENT_NO%TYPE,
                                             P_NEW_REGION_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.REGION_CODE%TYPE,
                                             P_NEW_DISTRICT_CODE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.DISTRICT_CODE%TYPE,
                                             P_NEW_SETTLEMENT_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SETTLEMENT_CODE%TYPE,
                                             P_NEW_VILLAGE_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VILLAGE_CODE%TYPE,
                                             P_NEW_ADDRESS_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ADDRESS_CODE%TYPE,
                                             P_NEW_RISK_LEVEL_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.RISK_LEVEL_CODE%TYPE,
                                             P_NEW_PDL_CODE                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PDL_CODE%TYPE,
                                             P_NEW_COMPANY_NAME_RUS           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_RUS%TYPE,
                                             P_NEW_COMPANY_NAME_ENG           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_ENG%TYPE,
                                             P_NEW_COMPANY_NAME_KYR           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_KYR%TYPE,
                                             P_NEW_TAX_REG_DATE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_DATE%TYPE,
                                             P_NEW_TAX_REG_AUTHORITY          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_AUTHORITY%TYPE,
                                             P_NEW_TAX_REG_COUNTRY_CODE       CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_COUNTRY_CODE%TYPE,
                                             P_NEW_TAX_REG_STATE_NO           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_STATE_NO%TYPE,
                                             P_NEW_LEGAL_FORM_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.LEGAL_FORM_CODE%TYPE,
                                             P_NEW_CIVIL_STATUS_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CIVIL_STATUS_CODE%TYPE,
                                             P_NEW_CAPITAL_PARTICIPATION_CODE CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CAPITAL_PARTICIPATION_CODE%TYPE,
                                             P_NEW_CONTROL_FORM_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CONTROL_FORM_CODE%TYPE,
                                             P_NEW_TAX_RE_REG_DATE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_RE_REG_DATE%TYPE,
                                             P_NEW_OPF_ID_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OPF_ID_CODE%TYPE,              
                                             P_OLD_FIRST_NAME                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.FIRST_NAME%TYPE,
                                             P_OLD_OWNERSHIP                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OWNERSHIP%TYPE,
                                             P_OLD_BIRTH_DATE                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BIRTH_DATE%TYPE,
                                             P_OLD_CITIZEN_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CITIZEN_CODE%TYPE,
                                             P_OLD_BENEFICIARY_TYPE           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_TYPE%TYPE,
                                             P_OLD_CUSTOMER_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_CUSTOMER_NO%TYPE,
                                             P_OLD_COMPANY_INN                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_INN%TYPE,
                                             P_OLD_BENEFICIARY_INN            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_INN%TYPE,
                                             P_OLD_SURNAME                    CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SURNAME%TYPE,
                                             P_OLD_SECOND_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SECOND_NAME%TYPE,
                                             P_OLD_GENDER_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.GENDER_CODE%TYPE,
                                             P_OLD_PASSPORT_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PASSPORT_NO%TYPE,
                                             P_OLD_VALIDITY_DATE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VALIDITY_DATE%TYPE,
                                             P_OLD_ISSUED_BY                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ISSUED_BY%TYPE,
                                             P_OLD_STREET_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.STREET_NAME%TYPE,
                                             P_OLD_HOUSE_NO                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.HOUSE_NO%TYPE,
                                             P_OLD_APARTMENT_NO               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.APARTMENT_NO%TYPE,
                                             P_OLD_REGION_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.REGION_CODE%TYPE,
                                             P_OLD_DISTRICT_CODE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.DISTRICT_CODE%TYPE,
                                             P_OLD_SETTLEMENT_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SETTLEMENT_CODE%TYPE,
                                             P_OLD_VILLAGE_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VILLAGE_CODE%TYPE,
                                             P_OLD_ADDRESS_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ADDRESS_CODE%TYPE,
                                             P_OLD_RISK_LEVEL_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.RISK_LEVEL_CODE%TYPE,
                                             P_OLD_PDL_CODE                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PDL_CODE%TYPE,
                                             P_OLD_COMPANY_NAME_RUS           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_RUS%TYPE,
                                             P_OLD_COMPANY_NAME_ENG           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_ENG%TYPE,
                                             P_OLD_COMPANY_NAME_KYR           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_KYR%TYPE,
                                             P_OLD_TAX_REG_DATE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_DATE%TYPE,
                                             P_OLD_TAX_REG_AUTHORITY          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_AUTHORITY%TYPE,
                                             P_OLD_TAX_REG_COUNTRY_CODE       CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_COUNTRY_CODE%TYPE,
                                             P_OLD_TAX_REG_STATE_NO           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_STATE_NO%TYPE,
                                             P_OLD_LEGAL_FORM_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.LEGAL_FORM_CODE%TYPE,
                                             P_OLD_CIVIL_STATUS_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CIVIL_STATUS_CODE%TYPE,
                                             P_OLD_CAPITAL_PARTICIPATION_CODE CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CAPITAL_PARTICIPATION_CODE%TYPE,
                                             P_OLD_CONTROL_FORM_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CONTROL_FORM_CODE%TYPE,
                                             P_OLD_TAX_RE_REG_DATE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_RE_REG_DATE%TYPE,
                                             P_OLD_OPF_ID_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OPF_ID_CODE%TYPE,
                                             pn_tx_no                         CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE) IS
        ls_table_name VARCHAR2(100) := ps_table_name;
        ls_parametre  VARCHAR2(100) := P_NEW_BENEFICIARY_INN;
    BEGIN
        IF (P_NEW_FIRST_NAME <> P_OLD_FIRST_NAME ) OR (P_NEW_FIRST_NAME IS NULL AND P_OLD_FIRST_NAME IS NOT NULL ) OR (P_NEW_FIRST_NAME IS NOT NULL AND P_OLD_FIRST_NAME IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'FIRST_NAME',P_OLD_FIRST_NAME,P_NEW_FIRST_NAME,LS_PARAMETRE ); END IF;
        IF (P_NEW_OWNERSHIP <> P_OLD_OWNERSHIP ) OR (P_NEW_OWNERSHIP IS NULL AND P_OLD_OWNERSHIP IS NOT NULL ) OR (P_NEW_OWNERSHIP IS NOT NULL AND P_OLD_OWNERSHIP IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'OWNERSHIP',P_OLD_OWNERSHIP,P_NEW_OWNERSHIP,LS_PARAMETRE ); END IF; 
        IF (P_NEW_BIRTH_DATE <> P_OLD_BIRTH_DATE ) OR (P_NEW_BIRTH_DATE IS NULL AND P_OLD_BIRTH_DATE IS NOT NULL ) OR (P_NEW_BIRTH_DATE IS NOT NULL AND P_OLD_BIRTH_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'BIRTH_DATE',P_OLD_BIRTH_DATE,P_NEW_BIRTH_DATE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_CITIZEN_CODE <> P_OLD_CITIZEN_CODE ) OR (P_NEW_CITIZEN_CODE IS NULL AND P_OLD_CITIZEN_CODE IS NOT NULL ) OR (P_NEW_CITIZEN_CODE IS NOT NULL AND P_OLD_CITIZEN_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CITIZEN_CODE',P_OLD_CITIZEN_CODE,P_NEW_CITIZEN_CODE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_BENEFICIARY_TYPE <> P_OLD_BENEFICIARY_TYPE ) OR (P_NEW_BENEFICIARY_TYPE IS NULL AND P_OLD_BENEFICIARY_TYPE IS NOT NULL ) OR (P_NEW_BENEFICIARY_TYPE IS NOT NULL AND P_OLD_BENEFICIARY_TYPE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'BENEFICIARY_TYPE',P_OLD_BENEFICIARY_TYPE,P_NEW_BENEFICIARY_TYPE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_CUSTOMER_NO <> P_OLD_CUSTOMER_NO ) OR (P_NEW_CUSTOMER_NO IS NULL AND P_OLD_CUSTOMER_NO IS NOT NULL ) OR (P_NEW_CUSTOMER_NO IS NOT NULL AND P_OLD_CUSTOMER_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CUSTOMER_NO',P_OLD_CUSTOMER_NO,P_NEW_CUSTOMER_NO,LS_PARAMETRE ); END IF; 
        IF (P_NEW_COMPANY_INN <> P_OLD_COMPANY_INN ) OR (P_NEW_COMPANY_INN IS NULL AND P_OLD_COMPANY_INN IS NOT NULL ) OR (P_NEW_COMPANY_INN IS NOT NULL AND P_OLD_COMPANY_INN IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'COMPANY_INN',P_OLD_COMPANY_INN,P_NEW_COMPANY_INN,LS_PARAMETRE ); END IF; 
        IF (P_NEW_BENEFICIARY_INN <> P_OLD_BENEFICIARY_INN ) OR (P_NEW_BENEFICIARY_INN IS NULL AND P_OLD_BENEFICIARY_INN IS NOT NULL ) OR (P_NEW_BENEFICIARY_INN IS NOT NULL AND P_OLD_BENEFICIARY_INN IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'BENEFICIARY_INN',P_OLD_BENEFICIARY_INN,P_NEW_BENEFICIARY_INN,LS_PARAMETRE ); END IF; 
        IF (P_NEW_SURNAME <> P_OLD_SURNAME ) OR (P_NEW_SURNAME IS NULL AND P_OLD_SURNAME IS NOT NULL ) OR (P_NEW_SURNAME IS NOT NULL AND P_OLD_SURNAME IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'SURNAME',P_OLD_SURNAME,P_NEW_SURNAME,LS_PARAMETRE ); END IF;  
        IF (P_NEW_SECOND_NAME <> P_OLD_SECOND_NAME ) OR (P_NEW_SECOND_NAME IS NULL AND P_OLD_SECOND_NAME IS NOT NULL ) OR (P_NEW_SECOND_NAME IS NOT NULL AND P_OLD_SECOND_NAME IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'SECOND_NAME',P_OLD_SECOND_NAME,P_NEW_SECOND_NAME,LS_PARAMETRE ); END IF;
        IF (P_NEW_GENDER_CODE <> P_OLD_GENDER_CODE ) OR (P_NEW_GENDER_CODE IS NULL AND P_OLD_GENDER_CODE IS NOT NULL ) OR (P_NEW_GENDER_CODE IS NOT NULL AND P_OLD_GENDER_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'GENDER_CODE',P_OLD_GENDER_CODE,P_NEW_GENDER_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_PASSPORT_NO <> P_OLD_PASSPORT_NO ) OR (P_NEW_PASSPORT_NO IS NULL AND P_OLD_PASSPORT_NO IS NOT NULL ) OR (P_NEW_PASSPORT_NO IS NOT NULL AND P_OLD_PASSPORT_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'PASSPORT_NO',P_OLD_PASSPORT_NO,P_NEW_PASSPORT_NO,LS_PARAMETRE ); END IF; 
        IF (P_NEW_VALIDITY_DATE <> P_OLD_VALIDITY_DATE ) OR (P_NEW_VALIDITY_DATE IS NULL AND P_OLD_VALIDITY_DATE IS NOT NULL ) OR (P_NEW_VALIDITY_DATE IS NOT NULL AND P_OLD_VALIDITY_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'VALIDITY_DATE',P_OLD_VALIDITY_DATE,P_NEW_VALIDITY_DATE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_ISSUED_BY <> P_OLD_ISSUED_BY ) OR (P_NEW_ISSUED_BY IS NULL AND P_OLD_ISSUED_BY IS NOT NULL ) OR (P_NEW_ISSUED_BY IS NOT NULL AND P_OLD_ISSUED_BY IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ISSUED_BY',P_OLD_ISSUED_BY,P_NEW_ISSUED_BY,LS_PARAMETRE ); END IF; 
        IF (P_NEW_STREET_NAME <> P_OLD_STREET_NAME ) OR (P_NEW_STREET_NAME IS NULL AND P_OLD_STREET_NAME IS NOT NULL ) OR (P_NEW_STREET_NAME IS NOT NULL AND P_OLD_STREET_NAME IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'STREET_NAME',P_OLD_STREET_NAME,P_NEW_STREET_NAME,LS_PARAMETRE ); END IF; 
        IF (P_NEW_HOUSE_NO <> P_OLD_HOUSE_NO ) OR (P_NEW_HOUSE_NO IS NULL AND P_OLD_HOUSE_NO IS NOT NULL ) OR (P_NEW_HOUSE_NO IS NOT NULL AND P_OLD_HOUSE_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'HOUSE_NO',P_OLD_HOUSE_NO,P_NEW_HOUSE_NO,LS_PARAMETRE ); END IF; 
        IF (P_NEW_APARTMENT_NO <> P_OLD_APARTMENT_NO ) OR (P_NEW_APARTMENT_NO IS NULL AND P_OLD_APARTMENT_NO IS NOT NULL ) OR (P_NEW_APARTMENT_NO IS NOT NULL AND P_OLD_APARTMENT_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'APARTMENT_NO',P_OLD_APARTMENT_NO,P_NEW_APARTMENT_NO,LS_PARAMETRE ); END IF; 
        IF (P_NEW_REGION_CODE <> P_OLD_REGION_CODE ) OR (P_NEW_REGION_CODE IS NULL AND P_OLD_REGION_CODE IS NOT NULL ) OR (P_NEW_REGION_CODE IS NOT NULL AND P_OLD_REGION_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'REGION_CODE',P_OLD_REGION_CODE,P_NEW_REGION_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_DISTRICT_CODE <> P_OLD_DISTRICT_CODE ) OR (P_NEW_DISTRICT_CODE IS NULL AND P_OLD_DISTRICT_CODE IS NOT NULL ) OR (P_NEW_DISTRICT_CODE IS NOT NULL AND P_OLD_DISTRICT_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'DISTRICT_CODE',P_OLD_DISTRICT_CODE,P_NEW_DISTRICT_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_SETTLEMENT_CODE <> P_OLD_SETTLEMENT_CODE ) OR (P_NEW_SETTLEMENT_CODE IS NULL AND P_OLD_SETTLEMENT_CODE IS NOT NULL ) OR (P_NEW_SETTLEMENT_CODE IS NOT NULL AND P_OLD_SETTLEMENT_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'SETTLEMENT_CODE',P_OLD_SETTLEMENT_CODE,P_NEW_SETTLEMENT_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_VILLAGE_CODE <> P_OLD_VILLAGE_CODE ) OR (P_NEW_VILLAGE_CODE IS NULL AND P_OLD_VILLAGE_CODE IS NOT NULL ) OR (P_NEW_VILLAGE_CODE IS NOT NULL AND P_OLD_VILLAGE_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'VILLAGE_CODE',P_OLD_VILLAGE_CODE,P_NEW_VILLAGE_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_ADDRESS_CODE <> P_OLD_ADDRESS_CODE ) OR (P_NEW_ADDRESS_CODE IS NULL AND P_OLD_ADDRESS_CODE IS NOT NULL ) OR (P_NEW_ADDRESS_CODE IS NOT NULL AND P_OLD_ADDRESS_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ADDRESS_CODE',P_OLD_ADDRESS_CODE,P_NEW_ADDRESS_CODE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_RISK_LEVEL_CODE <> P_OLD_RISK_LEVEL_CODE ) OR (P_NEW_RISK_LEVEL_CODE IS NULL AND P_OLD_RISK_LEVEL_CODE IS NOT NULL ) OR (P_NEW_RISK_LEVEL_CODE IS NOT NULL AND P_OLD_RISK_LEVEL_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'RISK_LEVEL_CODE',P_OLD_RISK_LEVEL_CODE,P_NEW_RISK_LEVEL_CODE,LS_PARAMETRE ); END IF;  
        IF (P_NEW_PDL_CODE <> P_OLD_PDL_CODE ) OR (P_NEW_PDL_CODE IS NULL AND P_OLD_PDL_CODE IS NOT NULL ) OR (P_NEW_PDL_CODE IS NOT NULL AND P_OLD_PDL_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'PDL_CODE',P_OLD_PDL_CODE,P_NEW_PDL_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_COMPANY_NAME_RUS <> P_OLD_COMPANY_NAME_RUS ) OR (P_NEW_COMPANY_NAME_RUS IS NULL AND P_OLD_COMPANY_NAME_RUS IS NOT NULL ) OR (P_NEW_COMPANY_NAME_RUS IS NOT NULL AND P_OLD_COMPANY_NAME_RUS IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'COMPANY_NAME_RUS',P_OLD_COMPANY_NAME_RUS,P_NEW_COMPANY_NAME_RUS,LS_PARAMETRE ); END IF;
        IF (P_NEW_COMPANY_NAME_ENG <> P_OLD_COMPANY_NAME_ENG ) OR (P_NEW_COMPANY_NAME_ENG IS NULL AND P_OLD_COMPANY_NAME_ENG IS NOT NULL ) OR (P_NEW_COMPANY_NAME_ENG IS NOT NULL AND P_OLD_COMPANY_NAME_ENG IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'COMPANY_NAME_ENG',P_OLD_COMPANY_NAME_ENG,P_NEW_COMPANY_NAME_ENG,LS_PARAMETRE ); END IF; 
        IF (P_NEW_COMPANY_NAME_KYR <> P_OLD_COMPANY_NAME_KYR ) OR (P_NEW_COMPANY_NAME_KYR IS NULL AND P_OLD_COMPANY_NAME_KYR IS NOT NULL ) OR (P_NEW_COMPANY_NAME_KYR IS NOT NULL AND P_OLD_COMPANY_NAME_KYR IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'COMPANY_NAME_KYR',P_OLD_COMPANY_NAME_KYR,P_NEW_COMPANY_NAME_KYR,LS_PARAMETRE ); END IF; 
        IF (P_NEW_TAX_REG_DATE <> P_OLD_TAX_REG_DATE ) OR (P_NEW_TAX_REG_DATE IS NULL AND P_OLD_TAX_REG_DATE IS NOT NULL ) OR (P_NEW_TAX_REG_DATE IS NOT NULL AND P_OLD_TAX_REG_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_REG_DATE',P_OLD_TAX_REG_DATE,P_NEW_TAX_REG_DATE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_TAX_REG_AUTHORITY <> P_OLD_TAX_REG_AUTHORITY ) OR (P_NEW_TAX_REG_AUTHORITY IS NULL AND P_OLD_TAX_REG_AUTHORITY IS NOT NULL ) OR (P_NEW_TAX_REG_AUTHORITY IS NOT NULL AND P_OLD_TAX_REG_AUTHORITY IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_REG_AUTHORITY',P_OLD_TAX_REG_AUTHORITY,P_NEW_TAX_REG_AUTHORITY,LS_PARAMETRE ); END IF; 
        IF (P_NEW_TAX_REG_COUNTRY_CODE <> P_OLD_TAX_REG_COUNTRY_CODE ) OR (P_NEW_TAX_REG_COUNTRY_CODE IS NULL AND P_OLD_TAX_REG_COUNTRY_CODE IS NOT NULL ) OR (P_NEW_TAX_REG_COUNTRY_CODE IS NOT NULL AND P_OLD_TAX_REG_COUNTRY_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_REG_COUNTRY_CODE',P_OLD_TAX_REG_COUNTRY_CODE,P_NEW_TAX_REG_COUNTRY_CODE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_TAX_REG_STATE_NO <> P_OLD_TAX_REG_STATE_NO ) OR (P_NEW_TAX_REG_STATE_NO IS NULL AND P_OLD_TAX_REG_STATE_NO IS NOT NULL ) OR (P_NEW_TAX_REG_STATE_NO IS NOT NULL AND P_OLD_TAX_REG_STATE_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_REG_STATE_NO',P_OLD_TAX_REG_STATE_NO,P_NEW_TAX_REG_STATE_NO,LS_PARAMETRE ); END IF; 
        IF (P_NEW_LEGAL_FORM_CODE <> P_OLD_LEGAL_FORM_CODE ) OR (P_NEW_LEGAL_FORM_CODE IS NULL AND P_OLD_LEGAL_FORM_CODE IS NOT NULL ) OR (P_NEW_LEGAL_FORM_CODE IS NOT NULL AND P_OLD_LEGAL_FORM_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'LEGAL_FORM_CODE',P_OLD_LEGAL_FORM_CODE,P_NEW_LEGAL_FORM_CODE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_CIVIL_STATUS_CODE <> P_OLD_CIVIL_STATUS_CODE ) OR (P_NEW_CIVIL_STATUS_CODE IS NULL AND P_OLD_CIVIL_STATUS_CODE IS NOT NULL ) OR (P_NEW_CIVIL_STATUS_CODE IS NOT NULL AND P_OLD_CIVIL_STATUS_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CIVIL_STATUS_CODE',P_OLD_CIVIL_STATUS_CODE,P_NEW_CIVIL_STATUS_CODE,LS_PARAMETRE ); END IF;  
        IF (P_NEW_CAPITAL_PARTICIPATION_CODE <> P_OLD_CAPITAL_PARTICIPATION_CODE ) OR (P_NEW_CAPITAL_PARTICIPATION_CODE IS NULL AND P_OLD_CAPITAL_PARTICIPATION_CODE IS NOT NULL ) OR (P_NEW_CAPITAL_PARTICIPATION_CODE IS NOT NULL AND P_OLD_CAPITAL_PARTICIPATION_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CAPITAL_PARTICIPATION_CODE',P_OLD_CAPITAL_PARTICIPATION_CODE,P_NEW_CAPITAL_PARTICIPATION_CODE,LS_PARAMETRE ); END IF; 
        IF (P_NEW_CONTROL_FORM_CODE <> P_OLD_CONTROL_FORM_CODE ) OR (P_NEW_CONTROL_FORM_CODE IS NULL AND P_OLD_CONTROL_FORM_CODE IS NOT NULL ) OR (P_NEW_CONTROL_FORM_CODE IS NOT NULL AND P_OLD_CONTROL_FORM_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'CONTROL_FORM_CODE',P_OLD_CONTROL_FORM_CODE,P_NEW_CONTROL_FORM_CODE,LS_PARAMETRE ); END IF;
        IF (P_NEW_TAX_RE_REG_DATE <> P_OLD_TAX_RE_REG_DATE ) OR (P_NEW_TAX_RE_REG_DATE IS NULL AND P_OLD_TAX_RE_REG_DATE IS NOT NULL ) OR (P_NEW_TAX_RE_REG_DATE IS NOT NULL AND P_OLD_TAX_RE_REG_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'TAX_RE_REG_DATE',P_OLD_TAX_RE_REG_DATE,P_NEW_TAX_RE_REG_DATE,LS_PARAMETRE ); END IF;
        IF (P_NEW_OPF_ID_CODE <> P_OLD_OPF_ID_CODE ) OR (P_NEW_OPF_ID_CODE IS NULL AND P_OLD_OPF_ID_CODE IS NOT NULL ) OR (P_NEW_OPF_ID_CODE IS NOT NULL AND P_OLD_OPF_ID_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO,BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'OPF_ID_CODE',P_OLD_OPF_ID_CODE,P_NEW_OPF_ID_CODE,LS_PARAMETRE ); END IF;
    EXCEPTION
        WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '104' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END sp_log_musteri_ortaklik_guncel;


    /*************************************************************************************************************************/
    /*   Procedure Sp_Musteri_Kaydi_Olustur                                                                                  */
    /*   Baivuru kaydi onaylandiktan sonra bilgileri miiteri tablosuna aktarilir                                             */
    /*************************************************************************************************************************/
    /* Formatted on 10/05/2022 20:03:26 (QP5 v5.256.13226.35510) */
    PROCEDURE Sp_Musteri_Kaydi_Olustur(pn_tx_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE, pn_musteri_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE) IS
        ln_count NUMBER := 0;
    BEGIN
        /* Basvuru musteri bilgilerinin musteri tablosuna aktarilmasi */
        ln_count := 0;

        -- musteri mevcut ise hata mesaji verilecektir.
        SELECT COUNT(*)
          INTO ln_count
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        IF NVL(ln_count, 0) > 0 THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '102' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
        ELSE
            INSERT INTO CBS.CBS_MUSTERI(musteri_no, durum_kodu, musteri_tipi_kod,
                                    dk_grup_kod, isim, ikinci_isim,
                                    soyadi, dogum_tarihi, dogum_yeri,
                                    dogum_il_kod, cinsiyet_kod, baba_adi,
                                    anne_adi, anne_kizlik_soyadi, meslek_kod,
                                    egitim_kod, medeni_hal_kod, ticari_unvan,
                                    hesap_ucreti_f, cek_karnesi_f, personel_sicil_no,
                                    yerlesim_kod, ozel_kategori_kod, vergi_muaf_kod,
                                    vergi_dairesi_adi, vergi_no, tesvik_kod,
                                    uyruk_kod, kimlik_kod, tc_kimlik_no,
                                    nufus_cuzdani_seri_no, pasaport_no, ehliyet_belge_no,
                                    il_kod, ilce_kod, mahalle_koy,
                                    cilt_no, aile_sira_no, sira_no,
                                    verildigi_yer, verildigi_tarih, sektor_kod,
                                    finans_kod, ticari_sicil_no, extre_adres_kod,
                                    serbest_bolge_izin_tarihi, serbest_bolge_izin_no, pazarlama_sorumlusu_sicil_no_1,
                                    pazarlama_sorumlusu_sicil_no_2, grup_kod, bic_kod,
                                    swift_mesaj_kod, reuters_info_page, reuters_dealing_kod,
                                    modul_tur_kod, urun_tur_kod, urun_sinif_kod,
                                    eski_musteri_no, sektor_alt1_kodu, sektor_alt2_kodu,
                                    rating_kodu, bolum_kodu, gecerlilik_tarihi,
                                    vergi_daire_kodu, vat_seri_no, vat_sira_no,
                                    okpo_code, manager_name, manager_surname,
                                    manager_patronymic_name, manager_country_code, manager_resident_code,
                                    second_manager_name, vergi_zorunlumu, sosyal_fon_no,
                                    EKSTRE_UCRETI_ALINSIN, working_basis, patent_no,
                                    patent_expiry_date, legal_form_code, external_acct_no,
                                    lokal_unvan, COMPANY_OF_THE_STAFF, report_customer_type,
                                    fx_convert, risk_level_code, risk_assesment_date,
                                    isim_eng, ikinci_isim_eng, soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                                    MANAGER_ID_TYPE, MANAGER_PASSPORT_NUMBER, MANAGER_PASS_ISSUE_DATE,
                                    MANAGER_PASS_EXPIRING_DATE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                    MANAGER_PASS_ISSUE_PLACE, MANAGER_PASSPORT_SERIES, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                                    UNIVERSITY_CODE, CAMPUS_ID_NO, --CQ5273 MederT 23122015
                                    State_share, --KonstantinJ 08042016 CQ5223 State_Share addition
                                    DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                                    COMPANY_OF_THE_STAFF_2, --CQ4960 ChyngyzO 15082016
                                    COMPANY_OF_THE_STAFF_3, --CQ4960 ChyngyzO 15082016
                                    OPN_BY_THIRD_PERSON, --CQ5516 AisuluuD 29092016
                                    NOTIF_PACK, --CBS113 nurzalata
                                 --BOM CBS-395 AntonPa 271022
                                    MILITARY_CARD, RESIDENCE_PERMIT,
                                    ECONOMY_SECTOR_CODE, BANK_RELATION_CODE,
                                    CIVIL_STATUS_CODE, CAPITAL_PARTICIPATION_CODE,
                                    CONTROL_FORM_CODE, ECONOMIC_ACTIVITY_SUB,
                                    ECONOMIC_ACTIVITY_CODE, TAX_INITIAL_REG_DATE,
                                    TAX_REG_AUTHORITY, TAX_RE_REG_DATE,
                                    TAX_REG_COUNTRY_CODE, IS_LICENSED,
                                    MANAGER_GENDER, DECLARED_SHARE_CAPITAL,
                                    SHARE_CAPITAL_CURRENCY, PAID_SHARE_CAPITAL,
                                    PDL_CODE, BIRTH_CERTIFICATE, COMPANY_NAME_KYR, OPF_ID_CODE
                                 --EOM CBS-395 AntonPa 271022
                                    )
                SELECT musteri_no, 'A', musteri_tipi_kod,
                       dk_grup_kod, isim, ikinci_isim,
                       soyadi, dogum_tarihi, dogum_yeri,
                       dogum_il_kod, cinsiyet_kod, baba_adi,
                       anne_adi, anne_kizlik_soyadi, meslek_kod,
                       egitim_kod, medeni_hal_kod, ticari_unvan,
                       hesap_ucreti_f, cek_karnesi_f, personel_sicil_no,
                       yerlesim_kod, ozel_kategori_kod, vergi_muaf_kod,
                       vergi_dairesi_adi, vergi_no, tesvik_kod,
                       uyruk_kod, kimlik_kod, tc_kimlik_no,
                       nufus_cuzdani_seri_no, pasaport_no, ehliyet_belge_no,
                       il_kod, ilce_kod, mahalle_koy,
                       cilt_no, aile_sira_no, sira_no,
                       verildigi_yer, verildigi_tarih, sektor_kod,
                       finans_kod, ticari_sicil_no, extre_adres_kod,
                       serbest_bolge_izin_tarihi, serbest_bolge_izin_no, pazarlama_sorumlusu_sicil_no_1,
                       pazarlama_sorumlusu_sicil_no_2, grup_kod, bic_kod,
                       swift_mesaj_kod, reuters_info_page, reuters_dealing_kod,
                       modul_tur_kod, urun_tur_kod, urun_sinif_kod,
                       eski_musteri_no, sektor_alt1_kodu, sektor_alt2_kodu,
                       rating_kodu, bolum_kodu, gecerlilik_tarihi,
                       vergi_daire_kodu, vat_seri_no, vat_sira_no,
                       okpo_code, manager_name, manager_surname,
                       manager_patronymic_name, manager_country_code, manager_resident_code,
                       second_manager_name, vergi_zorunlumu, sosyal_fon_no,
                       EKSTRE_UCRETI_ALINSIN, working_basis, patent_no,
                       patent_expiry_date, legal_form_code, external_acct_no,
                       lokal_unvan, COMPANY_OF_THE_STAFF, report_customer_type,
                       fx_convert, risk_level_code, risk_assesment_date,
                       isim_eng, ikinci_isim_eng, soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                       MANAGER_ID_TYPE, MANAGER_PASSPORT_NUMBER, MANAGER_PASS_ISSUE_DATE,
                       MANAGER_PASS_EXPIRING_DATE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                       MANAGER_PASS_ISSUE_PLACE, MANAGER_PASSPORT_SERIES, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                       UNIVERSITY_CODE, CAMPUS_ID_NO, --CQ5273 MederT 23122015,
                       State_share, --KonstantinJ 08042016 CQ5223 State_Share addition
                       DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                       COMPANY_OF_THE_STAFF_2, --CQ4960 ChyngyzO 15082016
                       COMPANY_OF_THE_STAFF_3, --CQ4960 ChyngyzO 15082016
                       OPN_BY_THIRD_PERSON, --CQ5516 AisuluuD 29092016
                       NOTIF_PACK, --CBS113 nurzalata
                     --BOM CBS-395 AntonPa 271022
                       MILITARY_CARD, RESIDENCE_PERMIT,
                       ECONOMY_SECTOR_CODE, BANK_RELATION_CODE,
                       CIVIL_STATUS_CODE, CAPITAL_PARTICIPATION_CODE,
                       CONTROL_FORM_CODE, ECONOMIC_ACTIVITY_SUB,
                       ECONOMIC_ACTIVITY_CODE, TAX_INITIAL_REG_DATE,
                       TAX_REG_AUTHORITY, TAX_RE_REG_DATE,
                       TAX_REG_COUNTRY_CODE, IS_LICENSED,
                       MANAGER_GENDER, DECLARED_SHARE_CAPITAL,
                       SHARE_CAPITAL_CURRENCY, PAID_SHARE_CAPITAL,
                       PDL_CODE, BIRTH_CERTIFICATE, COMPANY_NAME_KYR, OPF_ID_CODE
                     --EOM CBS-395 AntonPa 271022 
                  FROM CBS.CBS_MUSTERI_BASVURU
                 WHERE tx_no = pn_tx_no;

            --bom CBS113 nurzalata packages for each customer
            INSERT INTO CBS.cbs_cust_pack_ops
                SELECT pn_musteri_no, o.*
                  FROM CBS.cbs_notif_pack_ops o
                 WHERE package_id = (SELECT notif_pack FROM CBS.cbs_musteri_basvuru WHERE tx_no = pn_tx_no);
            --eom CBS113 nurzalata packages for each customer

            /* Basvuru adres bilgilerinin musteri adres tablosuna aktarilmasi */
            INSERT INTO CBS.CBS_MUSTERI_ADRES(musteri_no, adres_kod, adres,
                                          semt, il_kod, posta_kod,
                                          ulke_kod, email, tel_alan_kod,
                                          tel_no, gsm_alan_kod, gsm_no,
                                          fax_alan_kod, fax_no, ilk_gecerlilik_tarihi,
                                          son_gecerlilik_tarihi, ilce_kod, extre_adres_kod_f,
                                          ISYERI_UNVANI, ulke_tel_kod, ulke_gsm_kod,
                                          ulke_tel_kod_2, tel_alan_kod_2, tel_no_2,
                                          ulke_tel_kod_3, tel_alan_kod_3, tel_no_3, --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                                          ulke_gsm_kod_2, gsm_alan_kod_2, gsm_no_2,
                                          ulke_gsm_kod_3, gsm_alan_kod_3, gsm_no_3, --e-o-m sevalb 31012011 SDLC14229 additional adres fields
                                          EMAIL_FOR_CCARD_SYSTEM, PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2,
                                          PHONE_EXTENSION_NO_3, FAX_COUNTRY_CODE, FAX_EXTENSION_NO,
                                          EMERGENCY_CALL_PERSON, EMERGENCY_TEL_AREA_CODE, --b-o-m KonstantinJ 10112015 CQ4731 credit card
                                          EMERGENCY_TEL_PHONE_NO,
                                          EMERGENCY_TEL_EXTENSION_NO,
                                        --BOM AntonPa CBS-395 271022
                                          REGION_CODE, DISTRICT_CODE,
                                          SETTLEMENT_CODE, VILLAGE_CODE,
                                          DIGITAL_ADDRESS, IS_SAME_ADDRESS, 
                                          ADDRESS_STREET, ADDRESS_HOUSE_NO, 
                                          ADDRESS_APARTMENT_NO, WEBSITE
                                        --EOM AntonPa CBS-395 271022
                                          )
                (SELECT pn_musteri_no, adres_kod, adres,
                       semt, il_kod, posta_kod,
                       ulke_kod, email, tel_alan_kod,
                       tel_no, gsm_alan_kod, gsm_no,
                       fax_alan_kod, fax_no, ilk_gecerlilik_tarihi,
                       son_gecerlilik_tarihi, ilce_kod, extre_adres_kod_f,
                       ISYERI_UNVANI, ulke_tel_kod, ulke_gsm_kod,
                       ulke_tel_kod_2, tel_alan_kod_2, tel_no_2,
                       ulke_tel_kod_3, tel_alan_kod_3, tel_no_3, --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                       ulke_gsm_kod_2, gsm_alan_kod_2, gsm_no_2,
                       ulke_gsm_kod_3, gsm_alan_kod_3, gsm_no_3,
                       EMAIL_FOR_CCARD_SYSTEM, PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2,
                       PHONE_EXTENSION_NO_3, FAX_COUNTRY_CODE, FAX_EXTENSION_NO,
                       EMERGENCY_CALL_PERSON, EMERGENCY_TEL_AREA_CODE, --b-o-m KonstantinJ 10112015 CQ4731 credit card
                       EMERGENCY_TEL_PHONE_NO,
                       EMERGENCY_TEL_EXTENSION_NO,
                     --BOM AntonPa CBS-395 271022
                       REGION_CODE, DISTRICT_CODE,
                       SETTLEMENT_CODE, VILLAGE_CODE,
                       DIGITAL_ADDRESS, IS_SAME_ADDRESS,
                       ADDRESS_STREET, ADDRESS_HOUSE_NO, 
                       ADDRESS_APARTMENT_NO, WEBSITE
                     --EOM AntonPa CBS-395 271022
                  FROM CBS.CBS_MUSTERI_BASVURU_ADRES
                 WHERE tx_no = pn_tx_no);
                 
          --BOM AntonPa CBS-395 271022
            INSERT INTO CBS.CBS_MUSTERI_ADRES (musteri_no, adres_kod, adres,il_kod,
                                               posta_kod,ulke_kod,ISYERI_UNVANI, REGION_CODE,
                                               DISTRICT_CODE, SETTLEMENT_CODE, VILLAGE_CODE,
                                               DIGITAL_ADDRESS, ADDRESS_STREET,
                                               ADDRESS_HOUSE_NO, ADDRESS_APARTMENT_NO)
            SELECT pn_musteri_no, adres_kod_2, adres_2, il_kod_2, posta_kod_2, ulke_kod_2, 
                   ISYERI_UNVANI_2, REGION_CODE_2, DISTRICT_CODE_2, SETTLEMENT_CODE_2, 
                   VILLAGE_CODE_2, DIGITAL_ADDRESS_2, ADDRESS_STREET_2, 
                   ADDRESS_HOUSE_NO_2, ADDRESS_APARTMENT_NO_2               
            FROM CBS.CBS_MUSTERI_BASVURU_ADRES
            WHERE tx_no = pn_tx_no and IS_SAME_ADDRESS = 'N';
          --EOM AntonPa CBS-395 271022


            /* Basvuru dokuman bilgilerinin musteri dokuman tablosuna aktarilmasi */
            INSERT INTO CBS.CBS_MUSTERI_DOKUMAN(musteri_no, sira_no, dokuman_adi, doc_id, alindi_kutusu_f, timed, duzenlenme_tarihi, gecerlilik_tarihi, doc_no, doc_ver) --MaratM CBS-258
                SELECT pn_musteri_no,
                       sira_no,
                       dokuman_adi,
                       doc_id, --YadgarB CBS-258
                       alindi_kutusu_f,
                       timed, --YadgarB CBS-258
                       duzenlenme_tarihi,
                       gecerlilik_tarihi,
                       doc_no,
                       doc_ver --MaratM CBS-258
                  FROM CBS.CBS_MUSTERI_BASVURU_DOKUMAN
                 WHERE tx_no = pn_tx_no;

            /* Basvuru not bilgilerinin musteri not tablosuna aktarilmasi */

            INSERT INTO CBS.CBS_MUSTERI_NOTLAR(musteri_no, sira_no, alinan_notlar,
                                           giris_tarihi, kullanici_kodu, gorusme_bilgileri,
                                           gorusme_notu, katilanlar, gorusme_tarihi,
                                           baslangic_saati, bitis_saati, not_tipi)
                SELECT pn_musteri_no, sira_no, alinan_notlar,
                       NVL(giris_tarihi, CBS.pkg_muhasebe.banka_tarihi_bul), kullanici_kodu, gorusme_bilgileri,
                       gorusme_notu, katilanlar, gorusme_tarihi,
                       baslangic_saati, bitis_saati, not_tipi
                  FROM CBS.CBS_MUSTERI_BASVURU_NOTLAR
                 WHERE tx_no = pn_tx_no;

            /* Basvuru ortaklik bilgilerinin musteri ortak tablosuna aktarilmasi */
         --BOM AntonPa CBS-395 271022
            /*INSERT INTO CBS.CBS_MUSTERI_ORTAKLIK(musteri_no, sira_no, isim, orani, tutari, doviz_kod, tarih, ulke_kod)
                SELECT pn_musteri_no, sira_no, isim, orani, tutari, doviz_kod, tarih, ulke_kod
                  FROM CBS.CBS_MUSTERI_BASVURU_ORTAKLIK
                 WHERE tx_no = pn_tx_no;*/
            
            INSERT INTO CBS.CBS_CUSTOMER_SHAREHOLDERS(CUSTOMER_NO, FIRST_NAME, OWNERSHIP,
                                     BIRTH_DATE, CITIZEN_CODE, BENEFICIARY_TYPE, BENEFICIARY_CUSTOMER_NO,
                                     COMPANY_INN, BENEFICIARY_INN, SURNAME, SECOND_NAME, GENDER_CODE,
                                     PASSPORT_NO, VALIDITY_DATE, ISSUED_BY, REGION_CODE, DISTRICT_CODE,
                                     SETTLEMENT_CODE, VILLAGE_CODE, STREET_NAME, HOUSE_NO, APARTMENT_NO,
                                     ADDRESS_CODE, RISK_LEVEL_CODE, PDL_CODE, COMPANY_NAME_RUS,
                                     COMPANY_NAME_ENG, COMPANY_NAME_KYR, TAX_REG_DATE, TAX_REG_AUTHORITY,
                                     TAX_REG_COUNTRY_CODE, TAX_REG_STATE_NO, LEGAL_FORM_CODE, CIVIL_STATUS_CODE,
                                     CAPITAL_PARTICIPATION_CODE, CONTROL_FORM_CODE, TAX_RE_REG_DATE, OPF_ID_CODE)
            SELECT PN_MUSTERI_NO, FIRST_NAME, OWNERSHIP,
                   BIRTH_DATE, CITIZEN_CODE, BENEFICIARY_TYPE, BENEFICIARY_CUSTOMER_NO,
                   COMPANY_INN, BENEFICIARY_INN, SURNAME, SECOND_NAME, GENDER_CODE,
                   PASSPORT_NO, VALIDITY_DATE, ISSUED_BY, REGION_CODE, DISTRICT_CODE,
                   SETTLEMENT_CODE, VILLAGE_CODE, STREET_NAME, HOUSE_NO, APARTMENT_NO,
                   ADDRESS_CODE, RISK_LEVEL_CODE, PDL_CODE, COMPANY_NAME_RUS,
                   COMPANY_NAME_ENG, COMPANY_NAME_KYR, TAX_REG_DATE, TAX_REG_AUTHORITY,
                   TAX_REG_COUNTRY_CODE, TAX_REG_STATE_NO, LEGAL_FORM_CODE, CIVIL_STATUS_CODE,
                   CAPITAL_PARTICIPATION_CODE, CONTROL_FORM_CODE, TAX_RE_REG_DATE, OPF_ID_CODE
            FROM CBS.CBS_CUSTOMER_APP_SHAREHOLDERS
            WHERE TX_NO = PN_TX_NO;
         --EOM AntonPa CBS-395 271022

            /* Contact bilgileri Sevalb 06022007 */

            INSERT INTO CBS.cbs_musteri_kontak(musteri_no, sira_no, ad, soyad, email, web_site, tel_alan_kod, tel_no, gsm_alan_kod, gsm_no, fax_alan_kod, fax_no)
                SELECT pn_musteri_no, sira_no, ad, soyad, email, web_site, tel_alan_kod, tel_no, gsm_alan_kod, gsm_no, fax_alan_kod, fax_no
                  FROM CBS.cbs_musteri_basvuru_kontak
                 WHERE tx_no = pn_tx_no;


            /* Document of third persons CQ5516 aisuluud */

            INSERT INTO CBS.CBS_CUSTOMER_BY_THIRD_PERSONS(CUSTOMER_NO, TYPE_OF_DOCUMENT, NO_OF_DOCUMENT, OPENING_DATE, EXPIRY, EXPIRY_DATE,
                                                          cbs_no_of_doc, active, description, opn_mng, firstname, middle_name, surname)
                SELECT pn_musteri_no, a.TYPE_OF_DOCUMENT, a.NO_OF_DOCUMENT, A.OPENING_DATE, a.EXPIRY, a.EXPIRY_DATE,
                       a.cbs_no_of_doc, a.active, a.description, a.opn_mng, p.firstname, p.middle_name, p.surname
                  FROM CBS.CBS_CUST_BY_THIRD_PERS_APPL a LEFT JOIN CBS.cbs_doc_third_persons p ON p.tx_no = a.tx_no AND p.cbs_no_of_doc = A.CBS_NO_OF_DOC
                 WHERE a.tx_no = pn_tx_no;

            --BOM MaratM CBS-258
            INSERT INTO CBS.CBS_MUSTERI_SOURCE(MUSTERI_NO, IS_SALARY, IS_SCHOLARSHIP,
                                               IS_PENSION, IS_P_SURRENDER, IS_DEPENDENCY,
                                               IS_CURRENCY, IS_OTHER, IS_OTHER_TEXT,
                                               IS_AMOUNT_FROM, IS_AMOUNT_TO, POA_SLP, POA_FS, 
                                               POA_CIT, POA_LN, POA_CP, POA_TR, POA_POT, POA_PTI, 
                                               POA_IP, POA_FT, POA_INP, RGP, USA, POP, WITH_POP)
                SELECT pn_musteri_no, S.IS_SALARY, S.IS_SCHOLARSHIP,
                       S.IS_PENSION, S.IS_P_SURRENDER, S.IS_DEPENDENCY,
                       S.IS_CURRENCY, S.IS_OTHER, S.IS_OTHER_TEXT,
                       S.IS_AMOUNT_FROM, S.IS_AMOUNT_TO, S.POA_SLP, S.POA_FS, 
                       S.POA_CIT, S.POA_LN, S.POA_CP, S.POA_TR, S.POA_POT, S.POA_PTI, 
                       S.POA_IP, S.POA_FT, S.POA_INP, S.RGP, S.USA, S.POP, S.WITH_POP
                  FROM CBS.CBS_MUSTERI_BASVURU_SOURCE S
                 WHERE S.TX_NO = pn_tx_no;
            --EOM MaratM CBS-258
            
          --BOM AntonPa CBS-395 271022
            INSERT INTO CBS.CBS_CUSTOMER_LICENSES(CUSTOMER_NO, ACTIVITY_CODE, LICENSE_NO, ISSUE_DATE, ISSUED_BY, VALIDITY_DATE) 
            SELECT PN_MUSTERI_NO, ACTIVITY_CODE, LICENSE_NO, ISSUE_DATE, ISSUED_BY, VALIDITY_DATE 
            FROM CBS.CBS_CUSTOMER_APP_LICENSES
            WHERE TX_NO = PN_TX_NO; 
          --EOM AntonPa CBS-395 271022
            
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '101' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END Sp_Musteri_Kaydi_Olustur;


    /*************************************************************************************************************************/
    /*   Procedure Sp_Musteri_Guncel_Kaydi_Olus                                                                              */
    /*    Musteri guncelleme iilem kaydi oluiturulur.Miiteri tablosundan bilgiler gincelleme tablolarina aktar?lir           */
    /*************************************************************************************************************************/
    PROCEDURE Sp_Musteri_Guncel_Kaydi_Olus(pn_musteri_no     CBS.CBS_MUSTERI_GUNCELLENEN.musteri_no%TYPE,
                                           pn_tx_no      OUT CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE,
                                           ps_durum          VARCHAR2 DEFAULT 'A') IS
        ln_islem_kod        CBS.CBS_ISLEM.islem_kod%TYPE;
        ls_modul_tur_kod    CBS.CBS_ISLEM.modul_tur_kod%TYPE;
        ls_urun_tur_kod     CBS.CBS_ISLEM.urun_tur_kod%TYPE;
        ls_urun_sinif_kod   CBS.CBS_ISLEM.urun_sinif_kod%TYPE;
        ln_tutar            CBS.CBS_ISLEM.tutar%TYPE;
        ls_bolum_kodu       CBS.CBS_BOLUM.kodu%TYPE;
        ls_doviz_kod        CBS.CBS_ISLEM.doviz_kod%TYPE;
        ls_durum_kodu       CBS.CBS_MUSTERI.durum_kodu%TYPE;
        ls_musteri_tipi_kod CBS.CBS_MUSTERI.musteri_tipi_kod%TYPE;
        baglam_yaratilamadi EXCEPTION;
        islem_yaratilamadi  EXCEPTION;
        ln_cnt              NUMBER; --MaratM CBS-258
    BEGIN
        -- Musteri durum kodu guncellenmeden fakli ise islem kaydi olusturulur.

        SELECT durum_kodu, musteri_tipi_kod, modul_tur_kod,
               urun_tur_kod, urun_sinif_kod
          INTO ls_durum_kodu, ls_musteri_tipi_kod, ls_modul_tur_kod,
               ls_urun_tur_kod, ls_urun_sinif_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        --1. musteri durum kodu Guncelleniyor koduna cevrilir.
        /*    if  ls_durum_kodu != '1' then

              update CBS.cbs_musteri
              set    durum_kodu = '1'
              where  musteri_no = pn_musteri_no ;
             end if;
            */
        --2.islem numarasi alinir
        ln_islem_kod := '1001';

        -- CBS.Pkg_Musteri.sp_musteri_urun_sinif_al( pn_musteri_no,ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod);
        /*  ls_modul_tur_kod:='MUSTERI';
          ls_urun_tur_kod:= sf_musteri_tipi_adi(ls_musteri_tipi_kod);
          ls_urun_sinif_kod:=CBS.pkg_musteri.sf_musteri_urun_sinif_al(ls_modul_tur_kod,ls_urun_tur_kod);
          */
        ln_tutar := 0;
        ls_bolum_kodu := CBS.Pkg_Baglam.bolum_kodu;

        IF ls_bolum_kodu IS NULL THEN
            RAISE baglam_yaratilamadi;
        END IF;

        pn_tx_no := CBS.Pkg_Tx.islem_no_al;


        --3.Basvuru musteri bilgilerinin musteri tablosuna aktarilmasi */
        INSERT INTO CBS.CBS_MUSTERI_GUNCELLENEN(tx_no, musteri_no, musteri_tipi_kod,
                                            dk_grup_kod, isim, ikinci_isim,
                                            soyadi, dogum_tarihi, dogum_yeri,
                                            dogum_il_kod, cinsiyet_kod, baba_adi,
                                            anne_adi, anne_kizlik_soyadi, meslek_kod,
                                            egitim_kod, medeni_hal_kod, ticari_unvan,
                                            hesap_ucreti_f, cek_karnesi_f, personel_sicil_no,
                                            yerlesim_kod, ozel_kategori_kod, vergi_muaf_kod,
                                            vergi_dairesi_adi, vergi_no, tesvik_kod,
                                            uyruk_kod, kimlik_kod, tc_kimlik_no,
                                            nufus_cuzdani_seri_no, pasaport_no, ehliyet_belge_no,
                                            il_kod, ilce_kod, mahalle_koy,
                                            cilt_no, aile_sira_no, sira_no,
                                            verildigi_yer, verildigi_tarih, sektor_kod,
                                            finans_kod, ticari_sicil_no, extre_adres_kod,
                                            serbest_bolge_izin_tarihi, serbest_bolge_izin_no, pazarlama_sorumlusu_sicil_no_1,
                                            pazarlama_sorumlusu_sicil_no_2, grup_kod, bic_kod,
                                            swift_mesaj_kod, reuters_info_page, reuters_dealing_kod,
                                            yaratan_kullanici_kodu, yaratildigi_tarih, modul_tur_kod,
                                            urun_tur_kod, urun_sinif_kod, eski_musteri_no,
                                            sektor_alt1_kodu, sektor_alt2_kodu, rating_kodu,
                                            bolum_kodu, gecerlilik_tarihi, vergi_daire_kodu,
                                            durum_kodu, vat_seri_no, vat_sira_no,
                                            okpo_code, manager_name, manager_surname,
                                            manager_patronymic_name, manager_country_code, manager_resident_code,
                                            second_manager_name, vergi_zorunlumu, sosyal_fon_no,
                                            EKSTRE_UCRETI_ALINSIN, working_basis, patent_no,
                                            patent_expiry_date, legal_form_code, external_acct_no,
                                            lokal_unvan, COMPANY_OF_THE_STAFF, report_customer_type,
                                            fx_convert, risk_level_code, risk_assesment_date,
                                            isim_eng, ikinci_isim_eng, soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                                            MANAGER_ID_TYPE, MANAGER_PASSPORT_NUMBER, MANAGER_PASS_ISSUE_DATE,
                                            MANAGER_PASS_EXPIRING_DATE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                            MANAGER_PASS_ISSUE_PLACE, MANAGER_PASSPORT_SERIES, -- end  CQ578 KonstantinJ  03.04.2014 addtitional fields
                                            UNIVERSITY_CODE, CAMPUS_ID_NO, --CQ5273 MederT 23122015
                                            State_share, --KonstantinJ 08042016 CQ5223 State_Share addition
                                            DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                                            COMPANY_OF_THE_STAFF_2, --CQ4960 ChyngyzO 15082016
                                            COMPANY_OF_THE_STAFF_3, --CQ4960 ChyngyzO 15082016
                                            OPN_BY_THIRD_PERSON, --CQ5516 aisuluud 29092016
                                            NOTIF_PACK, --CBS113 nurzalata
                                          --BOM CBS-395 AntonPa 271022
                                            MILITARY_CARD, RESIDENCE_PERMIT,
                                            ECONOMY_SECTOR_CODE, BANK_RELATION_CODE,
                                            CIVIL_STATUS_CODE, CAPITAL_PARTICIPATION_CODE,
                                            CONTROL_FORM_CODE, ECONOMIC_ACTIVITY_SUB,
                                            ECONOMIC_ACTIVITY_CODE, TAX_INITIAL_REG_DATE,
                                            TAX_REG_AUTHORITY, TAX_RE_REG_DATE,
                                            TAX_REG_COUNTRY_CODE, IS_LICENSED,
                                            MANAGER_GENDER, DECLARED_SHARE_CAPITAL,
                                            SHARE_CAPITAL_CURRENCY, PAID_SHARE_CAPITAL,
                                            PDL_CODE, BIRTH_CERTIFICATE, COMPANY_NAME_KYR, OPF_ID_CODE
                                          --EOM CBS-395 AntonPa 271022
                                            )
            SELECT pn_tx_no, musteri_no, musteri_tipi_kod,
                   dk_grup_kod, isim, ikinci_isim,
                   soyadi, dogum_tarihi, dogum_yeri,
                   dogum_il_kod, cinsiyet_kod, baba_adi,
                   anne_adi, anne_kizlik_soyadi, meslek_kod,
                   egitim_kod, medeni_hal_kod, ticari_unvan,
                   hesap_ucreti_f, cek_karnesi_f, personel_sicil_no,
                   yerlesim_kod, ozel_kategori_kod, vergi_muaf_kod,
                   vergi_dairesi_adi, vergi_no, tesvik_kod,
                   uyruk_kod, kimlik_kod, tc_kimlik_no,
                   nufus_cuzdani_seri_no, pasaport_no, ehliyet_belge_no,
                   il_kod, ilce_kod, mahalle_koy,
                   cilt_no, aile_sira_no, sira_no,
                   verildigi_yer, verildigi_tarih, sektor_kod,
                   finans_kod, ticari_sicil_no, extre_adres_kod,
                   serbest_bolge_izin_tarihi, serbest_bolge_izin_no, pazarlama_sorumlusu_sicil_no_1,
                   pazarlama_sorumlusu_sicil_no_2, grup_kod, bic_kod,
                   swift_mesaj_kod, reuters_info_page, reuters_dealing_kod,
                   yaratan_kullanici_kodu, yaratildigi_tarih, modul_tur_kod,
                   urun_tur_kod, urun_sinif_kod, eski_musteri_no,
                   sektor_alt1_kodu, sektor_alt2_kodu, rating_kodu,
                   bolum_kodu, GECERLILIK_TARIHI, VERGI_DAIRE_KODU,
                   NVL(ps_durum, 'A'), vat_seri_no, vat_sira_no,
                   okpo_code, manager_name, manager_surname,
                   manager_patronymic_name, manager_country_code, manager_resident_code,
                   second_manager_name, vergi_zorunlumu, sosyal_fon_no,
                   EKSTRE_UCRETI_ALINSIN, working_basis, patent_no,
                   patent_expiry_date, legal_form_code, external_acct_no,
                   lokal_unvan, company_of_the_staff, report_customer_type,
                   fx_convert, risk_level_code, risk_assesment_date,
                   isim_eng, ikinci_isim_eng, soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                   MANAGER_ID_TYPE, MANAGER_PASSPORT_NUMBER, MANAGER_PASS_ISSUE_DATE,
                   MANAGER_PASS_EXPIRING_DATE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                   MANAGER_PASS_ISSUE_PLACE, MANAGER_PASSPORT_SERIES, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                   UNIVERSITY_CODE, CAMPUS_ID_NO, --CQ5273 MederT 23122015
                   State_share, --KonstantinJ 08042016 CQ5223 State_Share addition
                   DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                   COMPANY_OF_THE_STAFF_2, --CQ4960 ChyngyzO 15082016
                   COMPANY_OF_THE_STAFF_3, --CQ4960 ChyngyzO 15082016
                   OPN_BY_THIRD_PERSON, --CQ5516 aisuluud 29092016
                   NOTIF_PACK, --CBS113 nurzalata
                 --BOM CBS-395 AntonPa 271022
                   MILITARY_CARD, RESIDENCE_PERMIT,
                   ECONOMY_SECTOR_CODE, BANK_RELATION_CODE,
                   CIVIL_STATUS_CODE, CAPITAL_PARTICIPATION_CODE,
                   CONTROL_FORM_CODE, ECONOMIC_ACTIVITY_SUB,
                   ECONOMIC_ACTIVITY_CODE, TAX_INITIAL_REG_DATE,
                   TAX_REG_AUTHORITY, TAX_RE_REG_DATE,
                   TAX_REG_COUNTRY_CODE, IS_LICENSED,
                   MANAGER_GENDER, DECLARED_SHARE_CAPITAL,
                   SHARE_CAPITAL_CURRENCY, PAID_SHARE_CAPITAL,
                   PDL_CODE, BIRTH_CERTIFICATE, COMPANY_NAME_KYR, OPF_ID_CODE
                 --EOM CBS-395 AntonPa 271022
              FROM CBS.CBS_MUSTERI
             WHERE musteri_no = pn_musteri_no;

        /* Basvuru adres bilgilerinin musteri adres tablosuna aktarilmasi */
        INSERT INTO CBS.CBS_MUSTERI_GUNCEL_ADRES(tx_no, adres_kod, adres,
                                             semt, il_kod, posta_kod,
                                             ulke_kod, email, tel_alan_kod,
                                             tel_no, gsm_alan_kod, gsm_no,
                                             fax_alan_kod, fax_no, ilk_gecerlilik_tarihi,
                                             son_gecerlilik_tarihi, ilce_kod, yaratan_kullanici_kodu,
                                             yaratildigi_tarih, extre_adres_kod_f, ISYERI_UNVANI,
                                             ulke_tel_kod, ulke_gsm_kod, ulke_tel_kod_2,
                                             tel_alan_kod_2, tel_no_2, ulke_tel_kod_3,
                                             tel_alan_kod_3, tel_no_3, --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                                             ulke_gsm_kod_2, gsm_alan_kod_2, gsm_no_2, ulke_gsm_kod_3,
                                             gsm_alan_kod_3, gsm_no_3, EMAIL_FOR_CCARD_SYSTEM,
                                             PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2, PHONE_EXTENSION_NO_3,
                                             FAX_COUNTRY_CODE, FAX_EXTENSION_NO, EMERGENCY_CALL_PERSON,
                                             EMERGENCY_TEL_AREA_CODE, --b-o-m KonstantinJ 10112015 CQ4731 credit card
                                             EMERGENCY_TEL_PHONE_NO, EMERGENCY_TEL_EXTENSION_NO,
                                           --BOM AntonPa CBS-395 271022
                                             REGION_CODE, DISTRICT_CODE,
                                             SETTLEMENT_CODE, VILLAGE_CODE,
                                             DIGITAL_ADDRESS, IS_SAME_ADDRESS, 
                                             ADDRESS_STREET, ADDRESS_HOUSE_NO, 
                                             ADDRESS_APARTMENT_NO, WEBSITE)
                                           --EOM AntonPa CBS-395 271022
            --e-o-m KonstantinJ 10112015 CQ4731 credit card
            SELECT pn_tx_no, adres_kod, adres,
                   semt, il_kod, posta_kod,
                   ulke_kod, email, tel_alan_kod,
                   tel_no, gsm_alan_kod, gsm_no,
                   fax_alan_kod, fax_no, ilk_gecerlilik_tarihi,
                   son_gecerlilik_tarihi, ilce_kod, yaratan_kullanici_kodu,
                   yaratildigi_tarih, extre_adres_kod_f, ISYERI_UNVANI,
                   ulke_tel_kod, ulke_gsm_kod, ulke_tel_kod_2,
                   tel_alan_kod_2, tel_no_2, ulke_tel_kod_3,
                   tel_alan_kod_3, tel_no_3, --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                   ulke_gsm_kod_2, gsm_alan_kod_2, gsm_no_2, ulke_gsm_kod_3,
                   gsm_alan_kod_3, gsm_no_3, EMAIL_FOR_CCARD_SYSTEM,
                   PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2, PHONE_EXTENSION_NO_3,
                   FAX_COUNTRY_CODE, FAX_EXTENSION_NO, EMERGENCY_CALL_PERSON,
                   EMERGENCY_TEL_AREA_CODE, --b-o-m KonstantinJ 10112015 CQ4731 credit card
                   EMERGENCY_TEL_PHONE_NO, EMERGENCY_TEL_EXTENSION_NO,
                 --BOM AntonPa CBS-395 271022
                   REGION_CODE, DISTRICT_CODE,
                   SETTLEMENT_CODE, VILLAGE_CODE,
                   DIGITAL_ADDRESS, IS_SAME_ADDRESS,
                   ADDRESS_STREET, ADDRESS_HOUSE_NO, 
                   ADDRESS_APARTMENT_NO, WEBSITE
                 --EOM AntonPa CBS-395 271022
              --e-o-m KonstantinJ 10112015 CQ4731 credit card
              FROM CBS.CBS_MUSTERI_ADRES
             WHERE musteri_no = pn_musteri_no AND 
                   ADRES_KOD IN (DECODE(SF_MUSTERI_TIPI_AL(MUSTERI_NO), '3', '2', '1'), '3')
             ORDER BY ADRES_KOD; --AntonPa CBS-395 271022

        /* Basvuru dokuman bilgilerinin musteri dokuman tablosuna aktarilmasi */
        --BOM YadgarB CBS-258 will filled in forms
        INSERT INTO CBS.CBS_MUSTERI_GUNCEL_DOKUMAN(tx_no, sira_no, doc_id, alindi_kutusu_f, timed, duzenlenme_tarihi, gecerlilik_tarihi,
                                                   yaratan_kullanici_kodu, yaratildigi_tarih, doc_ver, doc_no, dokuman_adi) -- MaratM CBS-258
            SELECT pn_tx_no,
                   sira_no,
                   doc_id, --YadgarB CBS-258
                   alindi_kutusu_f,
                   timed, --YadgarB CBS-258
                   duzenlenme_tarihi,
                   gecerlilik_tarihi,
                   yaratan_kullanici_kodu,
                   yaratildigi_tarih,
                   doc_ver,
                   doc_no,-- MaratM CBS-258
                   dokuman_adi --Bakdoolot added dokuman_adi
            FROM CBS.CBS_MUSTERI_DOKUMAN
            WHERE musteri_no = pn_musteri_no;
--             AND doc_id IS NOT NULL; --YadgarB CBS-258
        --EOM YadgarB CBS-258

        /* Basvuru not bilgilerinin musteri not tablosuna aktarilmasi */
        INSERT INTO CBS.CBS_MUSTERI_GUNCEL_NOTLAR(tx_no, sira_no, alinan_notlar,
                                              giris_tarihi, kullanici_kodu, gorusme_bilgileri,
                                              gorusme_notu, katilanlar, gorusme_tarihi,
                                              baslangic_saati, bitis_saati, yaratan_kullanici_kodu,
                                              yaratildigi_tarih, not_tipi)
            SELECT pn_tx_no, sira_no, alinan_notlar,
                   giris_tarihi, kullanici_kodu, gorusme_bilgileri,
                   gorusme_notu, katilanlar, gorusme_tarihi,
                   baslangic_saati, bitis_saati, yaratan_kullanici_kodu,
                   yaratildigi_tarih, not_tipi
              FROM CBS.CBS_MUSTERI_NOTLAR
             WHERE musteri_no = pn_musteri_no;

        /* Basvuru ortaklik bilgilerinin musteri ortak tablosuna aktarilmasi */
      --BOM AntonPa CBS-395 271022
        /*INSERT INTO CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS(tx_no, sira_no, isim,
                                                orani, tutari, doviz_kod,
                                                tarih, ulke_kod, yaratan_kullanici_kodu,
                                                yaratildigi_tarih)
            SELECT pn_tx_no, sira_no, isim,
                   orani, tutari, doviz_kod,
                   tarih, ulke_kod, yaratan_kullanici_kodu,
                   yaratildigi_tarih
              FROM CBS.CBS_MUSTERI_ORTAKLIK
             WHERE musteri_no = pn_musteri_no;*/
        
        INSERT INTO CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS(TX_NO, FIRST_NAME, OWNERSHIP,
                                 BIRTH_DATE, CITIZEN_CODE, BENEFICIARY_TYPE, BENEFICIARY_CUSTOMER_NO,
                                 COMPANY_INN, BENEFICIARY_INN, SURNAME, SECOND_NAME, GENDER_CODE,
                                 PASSPORT_NO, VALIDITY_DATE, ISSUED_BY, STREET_NAME, HOUSE_NO, APARTMENT_NO,
                                 REGION_CODE, DISTRICT_CODE, SETTLEMENT_CODE, VILLAGE_CODE,
                                 ADDRESS_CODE, RISK_LEVEL_CODE, PDL_CODE, COMPANY_NAME_RUS,
                                 COMPANY_NAME_ENG, COMPANY_NAME_KYR, TAX_REG_DATE, TAX_REG_AUTHORITY,
                                 TAX_REG_COUNTRY_CODE, TAX_REG_STATE_NO, LEGAL_FORM_CODE, CIVIL_STATUS_CODE,
                                 CAPITAL_PARTICIPATION_CODE, CONTROL_FORM_CODE, TAX_RE_REG_DATE, OPF_ID_CODE)
        SELECT PN_TX_NO, FIRST_NAME, OWNERSHIP,
               BIRTH_DATE, CITIZEN_CODE, BENEFICIARY_TYPE, BENEFICIARY_CUSTOMER_NO,
               COMPANY_INN, BENEFICIARY_INN, SURNAME, SECOND_NAME, GENDER_CODE,
               PASSPORT_NO, VALIDITY_DATE, ISSUED_BY, STREET_NAME, HOUSE_NO, APARTMENT_NO,
               REGION_CODE, DISTRICT_CODE, SETTLEMENT_CODE, VILLAGE_CODE,
               ADDRESS_CODE, RISK_LEVEL_CODE, PDL_CODE, COMPANY_NAME_RUS,
               COMPANY_NAME_ENG, COMPANY_NAME_KYR, TAX_REG_DATE, TAX_REG_AUTHORITY,
               TAX_REG_COUNTRY_CODE, TAX_REG_STATE_NO, LEGAL_FORM_CODE, CIVIL_STATUS_CODE,
               CAPITAL_PARTICIPATION_CODE, CONTROL_FORM_CODE, TAX_RE_REG_DATE, OPF_ID_CODE
        FROM CBS.CBS_CUSTOMER_SHAREHOLDERS
        WHERE CUSTOMER_NO = PN_MUSTERI_NO;
      --EOM AntonPa CBS-395 271022

        /* Contact bilgileri Sevalb 06022007 */
        INSERT INTO CBS.cbs_musteri_guncel_kontak(TX_NO, SIRA_NO, AD,
                                              SOYAD, EMAIL, WEB_SITE,
                                              TEL_ALAN_KOD, TEL_NO, GSM_ALAN_KOD,
                                              GSM_NO, FAX_ALAN_KOD, FAX_NO)
            SELECT pn_tx_no, SIRA_NO, AD,
                   SOYAD, EMAIL, WEB_SITE,
                   TEL_ALAN_KOD, TEL_NO, GSM_ALAN_KOD,
                   GSM_NO, FAX_ALAN_KOD, FAX_NO
              FROM CBS.cbs_musteri_kontak
             WHERE musteri_no = pn_musteri_no;

        /* Copy data for additional tab in MUSIZ  UrmatA 20150907 */
        INSERT INTO CBS.CBS_MUSTERI_GUNCEL_UPD_INF(TX_NO, activity, owners, results, update_date, create_user)
            SELECT pn_tx_no, activity, owners, results, update_date, create_user
              FROM CBS.CBS_MUSTERI_UPD_INF
             WHERE musteri_no = pn_musteri_no;

        -- BOM Documents by third persons aisuluud CQ5516 21112016
        INSERT INTO CBS.CBS_CUST_BY_THIRD_PERS_MODIF(TX_NO, TYPE_OF_DOCUMENT, NO_OF_DOCUMENT,
                                                     OPENING_DATE, EXPIRY, EXPIRY_DATE, CBS_NO_OF_DOC, 
                                                     ACTIVE, DESCRIPTION, OPN_MNG)
            SELECT DISTINCT pn_tx_no, TYPE_OF_DOCUMENT, NO_OF_DOCUMENT,
                            OPENING_DATE, EXPIRY, EXPIRY_DATE, CBS_NO_OF_DOC, 
                            ACTIVE, DESCRIPTION, OPN_MNG
              FROM CBS.CBS_CUSTOMER_BY_THIRD_PERSONS
             WHERE customer_no = pn_musteri_no;

        INSERT INTO CBS.cbs_doc_third_persons_modif(TX_NO, CBS_NO_OF_DOC, FIRSTNAME, MIDDLE_NAME, SURNAME)
            SELECT pn_tx_no, CBS_NO_OF_DOC, FIRSTNAME, MIDDLE_NAME, SURNAME
              FROM CBS.CBS_CUSTOMER_BY_THIRD_PERSONS
             WHERE customer_no = pn_musteri_no;

        -- EOM Documents by third persons aisuluud CQ5516 21112016

        --BOM MaratM CBS-258
        SELECT COUNT(*)
          INTO ln_cnt
          FROM CBS.CBS_MUSTERI_SOURCE S
         WHERE S.MUSTERI_NO = pn_musteri_no;

        IF ln_cnt = 0 THEN
            INSERT INTO CBS.CBS_MUSTERI_SOURCE(MUSTERI_NO)
                 VALUES (pn_musteri_no);
        END IF;

        INSERT INTO CBS.CBS_MUSTERI_GUNCEL_SOURCE(tx_no, is_salary, is_scholarship,
                                              is_pension, is_p_surrender, is_dependency,
                                              is_currency, is_other, is_other_text,
                                              is_amount_from, is_amount_to, poa_slp,
                                              poa_fs, poa_cit, poa_ln,
                                              poa_cp, poa_tr, poa_pot,
                                              poa_pti, poa_ip, poa_ft,
                                              poa_inp, rgp, usa,
                                              pop, with_pop)
            SELECT pn_tx_no, s.is_salary, s.is_scholarship,
                   s.is_pension, s.is_p_surrender, s.is_dependency,
                   s.is_currency, s.is_other, s.is_other_text,
                   s.is_amount_from, s.is_amount_to, s.poa_slp,
                   s.poa_fs, s.poa_cit, s.poa_ln,
                   s.poa_cp, s.poa_tr, s.poa_pot,
                   s.poa_pti, s.poa_ip, s.poa_ft,
                   s.poa_inp, s.rgp, s.usa,
                   s.pop, s.with_pop
              FROM CBS.CBS_MUSTERI_SOURCE s
             WHERE s.musteri_no = pn_musteri_no;
        --EOM MaratM CBS-258
        
      --BOM AntonPa CBS-395 271022
        INSERT INTO CBS.CBS_CUSTOMER_UPD_LICENSES(TX_NO, ACTIVITY_CODE, LICENSE_NO, ISSUE_DATE, ISSUED_BY, VALIDITY_DATE) 
        SELECT PN_TX_NO, ACTIVITY_CODE, LICENSE_NO, ISSUE_DATE, ISSUED_BY, VALIDITY_DATE 
        FROM CBS.CBS_CUSTOMER_LICENSES
        WHERE CUSTOMER_NO = PN_MUSTERI_NO; 
      --EOM AntonPa CBS-395 271022
      
    EXCEPTION
        WHEN baglam_yaratilamadi THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '425' || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
        WHEN islem_yaratilamadi THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '426' || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '105' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || SQLERRM || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END Sp_Musteri_Guncel_Kaydi_Olus;

    /*************************************************************************************************************************/ 
    /*   Procedure Sp_Musteriyi_Guncelle                                                                                     */
    /*    Musteri guncellenme islemi onaylandiktan sonra guncelleme tablolalarindan ana musteri tablolarina bilgi aktarilir. */
    /*************************************************************************************************************************/
    PROCEDURE Sp_Musteriyi_Guncelle(pn_tx_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE, pn_musteri_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE) IS
        ln_islem_kod      CBS.CBS_ISLEM.islem_kod%TYPE;
        ls_modul_tur_kod  CBS.CBS_ISLEM.modul_tur_kod%TYPE;
        ls_urun_tur_kod   CBS.CBS_ISLEM.urun_tur_kod%TYPE;
        ls_urun_sinif_kod CBS.CBS_ISLEM.urun_sinif_kod%TYPE;
        ln_tutar          CBS.CBS_ISLEM.tutar%TYPE;
        ls_bolum_kodu     VARCHAR2(200);
        ls_doviz_kod      CBS.CBS_ISLEM.doviz_kod%TYPE;
        ln_kontrol        NUMBER := 0;
        ln_dummy          NUMBER; --nurzalata CBS113 packages for each customer
    BEGIN
        -- Musteri durum kodu G guncellemeden A aktif statusune alinmalidir.
        -- Musteri tablosu Guncelleme tablosundaki bilgilerle guncellenir.
        --bom CBS113 nurzalata packages for each customer
        BEGIN
            SELECT m.musteri_no
              INTO ln_dummy
              FROM CBS.cbs_musteri m, CBS.cbs_musteri_guncellenen g
             WHERE m.musteri_no = g.musteri_no AND m.musteri_no = pn_musteri_no AND g.tx_no = pn_tx_no AND M.NOTIF_PACK <> G.NOTIF_PACK;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                NULL;
        END;

        IF ln_dummy IS NOT NULL THEN
            DELETE FROM CBS.cbs_cust_pack_ops
                  WHERE customer_no = pn_musteri_no;

            INSERT INTO CBS.cbs_cust_pack_ops
                SELECT pn_musteri_no, o.*
                  FROM CBS.cbs_notif_pack_ops o
                 WHERE package_id = (SELECT notif_pack
                                       FROM CBS.cbs_musteri_guncellenen
                                      WHERE tx_no = pn_tx_no);
        END IF;

        SELECT COUNT(*)
          INTO ln_dummy
          FROM CBS.cbs_cust_pack_ops
         WHERE customer_no = pn_musteri_no;

        IF ln_dummy = 0 THEN
            INSERT INTO CBS.cbs_cust_pack_ops
                SELECT pn_musteri_no, o.*
                  FROM CBS.cbs_notif_pack_ops o
                 WHERE package_id = (SELECT notif_pack
                                       FROM CBS.cbs_musteri_guncellenen
                                      WHERE tx_no = pn_tx_no);
        END IF;
        --eom CBS113 nurzalata packages for each customer

        UPDATE CBS.CBS_MUSTERI
           SET (durum_kodu, musteri_tipi_kod, dk_grup_kod, isim, ikinci_isim, soyadi, dogum_tarihi, dogum_yeri, dogum_il_kod,
                cinsiyet_kod, baba_adi, anne_adi, anne_kizlik_soyadi, meslek_kod, egitim_kod, medeni_hal_kod, ticari_unvan, hesap_ucreti_f,
                cek_karnesi_f, personel_sicil_no, yerlesim_kod, ozel_kategori_kod, vergi_muaf_kod, vergi_dairesi_adi, vergi_no, tesvik_kod,
                uyruk_kod, kimlik_kod, tc_kimlik_no, nufus_cuzdani_seri_no, pasaport_no, ehliyet_belge_no, il_kod, ilce_kod, mahalle_koy,
                cilt_no, aile_sira_no, sira_no, verildigi_yer, verildigi_tarih, sektor_kod, finans_kod, ticari_sicil_no, extre_adres_kod,
                serbest_bolge_izin_tarihi, serbest_bolge_izin_no, pazarlama_sorumlusu_sicil_no_1, pazarlama_sorumlusu_sicil_no_2, grup_kod,
                bic_kod, swift_mesaj_kod, reuters_info_page, reuters_dealing_kod, eski_musteri_no, sektor_alt1_kodu, sektor_alt2_kodu,
                rating_kodu, bolum_kodu, gecerlilik_tarihi, vergi_daire_kodu, vat_seri_no, vat_sira_no, okpo_code,
                manager_name, manager_surname, manager_patronymic_name, manager_country_code, manager_resident_code, second_manager_name,
                vergi_zorunlumu, sosyal_fon_no, ekstre_ucreti_alinsin, working_basis, patent_no, patent_expiry_date, legal_form_code,
                external_acct_no, lokal_unvan, company_of_the_staff, report_customer_type, fx_convert, risk_level_code, risk_assesment_date,
                isim_eng, ikinci_isim_eng, soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system)
                MANAGER_ID_TYPE,-- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                MANAGER_PASSPORT_NUMBER, MANAGER_PASS_ISSUE_DATE, MANAGER_PASS_EXPIRING_DATE, MANAGER_PASS_ISSUE_PLACE,
                MANAGER_PASSPORT_SERIES,-- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                UNIVERSITY_CODE, CAMPUS_ID_NO, --CQ5273 MederT 23122015
                State_share, --KonstantinJ 08042016 CQ5223 State_Share addition
                DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                COMPANY_OF_THE_STAFF_2, --CQ4960 ChyngyzO 15082016
                COMPANY_OF_THE_STAFF_3, --CQ4960 ChyngyzO 15082016
                opn_by_third_person, --CQ5516 aisuluud 20092016
                NOTIF_PACK, --CBS113 nurzalata
             --BOM CBS-395 AntonPa 271022
                MILITARY_CARD, RESIDENCE_PERMIT,
                ECONOMY_SECTOR_CODE, BANK_RELATION_CODE,
                CIVIL_STATUS_CODE, CAPITAL_PARTICIPATION_CODE,
                CONTROL_FORM_CODE, ECONOMIC_ACTIVITY_SUB,
                ECONOMIC_ACTIVITY_CODE, TAX_INITIAL_REG_DATE,
                TAX_REG_AUTHORITY, TAX_RE_REG_DATE,
                TAX_REG_COUNTRY_CODE, IS_LICENSED,
                MANAGER_GENDER, DECLARED_SHARE_CAPITAL,
                SHARE_CAPITAL_CURRENCY, PAID_SHARE_CAPITAL, PDL_CODE,
                BIRTH_CERTIFICATE, COMPANY_NAME_KYR, OPF_ID_CODE
             --EOM CBS-395 AntonPa 271022
                ) = (
                SELECT NVL(durum_kodu, 'A'), musteri_tipi_kod, dk_grup_kod, isim, ikinci_isim, soyadi, dogum_tarihi, dogum_yeri, dogum_il_kod,
                       cinsiyet_kod, baba_adi, anne_adi, anne_kizlik_soyadi, meslek_kod, egitim_kod, medeni_hal_kod, ticari_unvan, hesap_ucreti_f,
                       cek_karnesi_f, personel_sicil_no, yerlesim_kod, ozel_kategori_kod, vergi_muaf_kod, vergi_dairesi_adi, vergi_no, tesvik_kod,
                       uyruk_kod, kimlik_kod, tc_kimlik_no, nufus_cuzdani_seri_no, pasaport_no, ehliyet_belge_no, il_kod, ilce_kod, mahalle_koy,
                       cilt_no, aile_sira_no, sira_no, verildigi_yer, verildigi_tarih, sektor_kod, finans_kod, ticari_sicil_no, extre_adres_kod,
                       serbest_bolge_izin_tarihi, serbest_bolge_izin_no, pazarlama_sorumlusu_sicil_no_1, pazarlama_sorumlusu_sicil_no_2, grup_kod,
                       bic_kod, swift_mesaj_kod, reuters_info_page, reuters_dealing_kod, eski_musteri_no, sektor_alt1_kodu, sektor_alt2_kodu,
                       rating_kodu, bolum_kodu, gecerlilik_tarihi, vergi_daire_kodu, vat_seri_no, vat_sira_no, okpo_code,
                       manager_name, manager_surname, manager_patronymic_name, manager_country_code, manager_resident_code, second_manager_name,
                       vergi_zorunlumu, sosyal_fon_no, ekstre_ucreti_alinsin, working_basis, patent_no, patent_expiry_date, legal_form_code,
                       external_acct_no, lokal_unvan, company_of_the_staff, report_customer_type, fx_convert, risk_level_code, risk_assesment_date,
                       isim_eng, ikinci_isim_eng, soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                       MANAGER_ID_TYPE,-- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                       MANAGER_PASSPORT_NUMBER, MANAGER_PASS_ISSUE_DATE, MANAGER_PASS_EXPIRING_DATE, MANAGER_PASS_ISSUE_PLACE,
                       MANAGER_PASSPORT_SERIES,-- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                       UNIVERSITY_CODE,
                       CAMPUS_ID_NO, --CQ5273 MederT 23122015
                       State_share, --KonstantinJ 08042016 CQ5223 State_Share addition
                       DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                       COMPANY_OF_THE_STAFF_2, --CQ4960 ChyngyzO 15082016
                       COMPANY_OF_THE_STAFF_3,  --CQ4960 ChyngyzO 15082016
                       opn_by_third_person, --CQ5516 aisuluud 20092016
                       NOTIF_PACK, --CBS113 nurzalata
                     --BOM CBS-395 AntonPa 271022
                       MILITARY_CARD, RESIDENCE_PERMIT,
                       ECONOMY_SECTOR_CODE, BANK_RELATION_CODE,
                       CIVIL_STATUS_CODE, CAPITAL_PARTICIPATION_CODE,
                       CONTROL_FORM_CODE, ECONOMIC_ACTIVITY_SUB,
                       ECONOMIC_ACTIVITY_CODE, TAX_INITIAL_REG_DATE,
                       TAX_REG_AUTHORITY, TAX_RE_REG_DATE,
                       TAX_REG_COUNTRY_CODE, IS_LICENSED,
                       MANAGER_GENDER, DECLARED_SHARE_CAPITAL,
                       SHARE_CAPITAL_CURRENCY, PAID_SHARE_CAPITAL, PDL_CODE,
                       BIRTH_CERTIFICATE, COMPANY_NAME_KYR, OPF_ID_CODE
                     --EOM CBS-395 AntonPa 271022
                  FROM CBS.CBS_MUSTERI_GUNCELLENEN
                 WHERE musteri_no = pn_musteri_no
                   AND tx_no = pn_tx_no)
        WHERE musteri_no = pn_musteri_no;

        /* Silip atma yontemiyle yeni eklenen kayitlarda ana tabloyak atilmis olacaktir. */
        /* Musteri adres bilgileri guncel adres tablosundakilerle guncellenir. */
        DELETE FROM CBS.CBS_MUSTERI_ADRES
              WHERE musteri_no = pn_musteri_no;

        INSERT INTO CBS.CBS_MUSTERI_ADRES(musteri_no, adres_kod, adres,
                                      semt, il_kod, posta_kod,
                                      ulke_kod, email, tel_alan_kod,
                                      tel_no, gsm_alan_kod, gsm_no,
                                      fax_alan_kod, fax_no, ilk_gecerlilik_tarihi,
                                      son_gecerlilik_tarihi, ilce_kod, yaratan_kullanici_kodu,
                                      yaratildigi_tarih, extre_adres_kod_f, ISYERI_UNVANI,
                                      ulke_tel_kod, ulke_gsm_kod, ulke_tel_kod_2,
                                      tel_alan_kod_2, tel_no_2, ulke_tel_kod_3,
                                      tel_alan_kod_3, tel_no_3, --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                                      ulke_gsm_kod_2, gsm_alan_kod_2, gsm_no_2, ulke_gsm_kod_3,
                                      gsm_alan_kod_3, gsm_no_3, EMAIL_FOR_CCARD_SYSTEM,
                                      PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2, PHONE_EXTENSION_NO_3,
                                      FAX_COUNTRY_CODE, FAX_EXTENSION_NO, EMERGENCY_CALL_PERSON,
                                      EMERGENCY_TEL_AREA_CODE, --b-o-m KonstantinJ 10112015 CQ4731 credit card
                                      EMERGENCY_TEL_PHONE_NO, EMERGENCY_TEL_EXTENSION_NO,
                                    --BOM AntonPa CBS-395 271022
                                      REGION_CODE, DISTRICT_CODE,
                                      SETTLEMENT_CODE, VILLAGE_CODE,
                                      DIGITAL_ADDRESS, IS_SAME_ADDRESS, 
                                      ADDRESS_STREET, ADDRESS_HOUSE_NO, 
                                      ADDRESS_APARTMENT_NO, WEBSITE)
                                    --EOM AntonPa CBS-395 271022
            --e-o-m KonstantinJ 10112015 CQ4731 credit card
            SELECT pn_musteri_no, adres_kod, adres,
                   semt, il_kod, posta_kod,
                   ulke_kod, email, tel_alan_kod,
                   tel_no, gsm_alan_kod, gsm_no,
                   fax_alan_kod, fax_no, ilk_gecerlilik_tarihi,
                   son_gecerlilik_tarihi, ilce_kod, yaratan_kullanici_kodu,
                   yaratildigi_tarih, extre_adres_kod_f, ISYERI_UNVANI,
                   ulke_tel_kod, ulke_gsm_kod, ulke_tel_kod_2,
                   tel_alan_kod_2, tel_no_2, ulke_tel_kod_3,
                   tel_alan_kod_3, tel_no_3, --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                   ulke_gsm_kod_2, gsm_alan_kod_2, gsm_no_2, ulke_gsm_kod_3,
                   gsm_alan_kod_3, gsm_no_3, EMAIL_FOR_CCARD_SYSTEM,
                   PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2, PHONE_EXTENSION_NO_3,
                   FAX_COUNTRY_CODE, FAX_EXTENSION_NO, EMERGENCY_CALL_PERSON,
                   EMERGENCY_TEL_AREA_CODE, --b-o-m KonstantinJ 10112015 CQ4731 credit card
                   EMERGENCY_TEL_PHONE_NO, EMERGENCY_TEL_EXTENSION_NO,
                 --BOM AntonPa CBS-395 271022
                   REGION_CODE, DISTRICT_CODE,
                   SETTLEMENT_CODE, VILLAGE_CODE,
                   DIGITAL_ADDRESS, IS_SAME_ADDRESS,
                   ADDRESS_STREET, ADDRESS_HOUSE_NO, 
                   ADDRESS_APARTMENT_NO, WEBSITE
                 --EOM AntonPa CBS-395 271022
              --e-o-m KonstantinJ 10112015 CQ4731 credit card
              FROM CBS.CBS_MUSTERI_GUNCEL_ADRES
             WHERE tx_no = pn_tx_no;

        /* Musteri dokuman bilgileri guncel dokuman tablosundakilerle guncellenir. */
        DELETE FROM CBS.CBS_MUSTERI_DOKUMAN
              WHERE musteri_no = pn_musteri_no;

        INSERT INTO CBS.CBS_MUSTERI_DOKUMAN(musteri_no, sira_no, doc_id,
                                        alindi_kutusu_f, timed, duzenlenme_tarihi,
                                        gecerlilik_tarihi, yaratan_kullanici_kodu, yaratildigi_tarih,
                                        doc_ver, doc_no, -- MaratM CBS-258
                                        dokuman_adi) --Bakdoolot
            SELECT pn_musteri_no, sira_no, doc_id, --YadgarB CBS.CBS_258
                   alindi_kutusu_f, timed, --YadgarB CBS.CBS_258
                   duzenlenme_tarihi, gecerlilik_tarihi, 
                   yaratan_kullanici_kodu, yaratildigi_tarih,
                   doc_ver, doc_no, --MaratM CBS-258
                   dokuman_adi --Bakdoolot
              FROM CBS.CBS_MUSTERI_GUNCEL_DOKUMAN
             WHERE tx_no = pn_tx_no AND doc_id IS NOT NULL; --YadgarB CBS-258

        /* Musteri not bilgileri guncel not tablosundakilerle guncellenir. */
        DELETE FROM CBS.CBS_MUSTERI_NOTLAR
              WHERE musteri_no = pn_musteri_no;

        INSERT INTO CBS.CBS_MUSTERI_NOTLAR(musteri_no, sira_no, alinan_notlar,
                                       giris_tarihi, kullanici_kodu, gorusme_bilgileri,
                                       gorusme_notu, katilanlar, gorusme_tarihi,
                                       baslangic_saati, bitis_saati, yaratan_kullanici_kodu,
                                       yaratildigi_tarih, not_tipi)
            SELECT pn_musteri_no, sira_no, alinan_notlar,
                   giris_tarihi, kullanici_kodu, gorusme_bilgileri,
                   gorusme_notu, katilanlar, gorusme_tarihi,
                   baslangic_saati, bitis_saati, yaratan_kullanici_kodu,
                   yaratildigi_tarih, not_tipi
              FROM CBS.CBS_MUSTERI_GUNCEL_NOTLAR
             WHERE tx_no = pn_tx_no;

        /* Musteri ortaklik bilgileri guncel ortaklik tablosundakilerle guncellenir. */
        DELETE FROM CBS.CBS_CUSTOMER_SHAREHOLDERS
              WHERE CUSTOMER_NO = pn_musteri_no;
     --BOM AntonPa CBS-395 271022
        /*INSERT INTO CBS.CBS_MUSTERI_ORTAKLIK(musteri_no, sira_no, isim,
                                         orani, tutari, doviz_kod,
                                         tarih, ulke_kod, yaratan_kullanici_kodu,
                                         yaratildigi_tarih)
            SELECT pn_musteri_no, sira_no, isim,
                   orani, tutari, doviz_kod,
                   tarih, ulke_kod, yaratan_kullanici_kodu,
                   yaratildigi_tarih
              FROM CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS
             WHERE tx_no = pn_tx_no;*/
        INSERT INTO CBS.CBS_CUSTOMER_SHAREHOLDERS(CUSTOMER_NO, FIRST_NAME, OWNERSHIP,
                                 BIRTH_DATE, CITIZEN_CODE, BENEFICIARY_TYPE, BENEFICIARY_CUSTOMER_NO,
                                 COMPANY_INN, BENEFICIARY_INN, SURNAME, SECOND_NAME, GENDER_CODE,
                                 PASSPORT_NO, VALIDITY_DATE, ISSUED_BY, STREET_NAME, HOUSE_NO, APARTMENT_NO,
                                 REGION_CODE, DISTRICT_CODE, SETTLEMENT_CODE, VILLAGE_CODE,
                                 ADDRESS_CODE, RISK_LEVEL_CODE, PDL_CODE, COMPANY_NAME_RUS,
                                 COMPANY_NAME_ENG, COMPANY_NAME_KYR, TAX_REG_DATE, TAX_REG_AUTHORITY,
                                 TAX_REG_COUNTRY_CODE, TAX_REG_STATE_NO, LEGAL_FORM_CODE, CIVIL_STATUS_CODE,
                                 CAPITAL_PARTICIPATION_CODE, CONTROL_FORM_CODE, TAX_RE_REG_DATE, OPF_ID_CODE)
        SELECT PN_MUSTERI_NO, FIRST_NAME, OWNERSHIP,
               BIRTH_DATE, CITIZEN_CODE, BENEFICIARY_TYPE, BENEFICIARY_CUSTOMER_NO,
               COMPANY_INN, BENEFICIARY_INN, SURNAME, SECOND_NAME, GENDER_CODE,
               PASSPORT_NO, VALIDITY_DATE, ISSUED_BY, STREET_NAME, HOUSE_NO, APARTMENT_NO,
               REGION_CODE, DISTRICT_CODE, SETTLEMENT_CODE, VILLAGE_CODE,
               ADDRESS_CODE, RISK_LEVEL_CODE, PDL_CODE, COMPANY_NAME_RUS,
               COMPANY_NAME_ENG, COMPANY_NAME_KYR, TAX_REG_DATE, TAX_REG_AUTHORITY,
               TAX_REG_COUNTRY_CODE, TAX_REG_STATE_NO, LEGAL_FORM_CODE, CIVIL_STATUS_CODE,
               CAPITAL_PARTICIPATION_CODE, CONTROL_FORM_CODE, TAX_RE_REG_DATE, OPF_ID_CODE
        FROM CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS
        WHERE TX_NO = PN_TX_NO;
     --EOM AntonPa CBS-395 271022


        /* Contact bilgileri Sevalb 06022007 */
        DELETE FROM CBS.CBS_MUSTERI_KONTAK
              WHERE musteri_no = pn_musteri_no;

        INSERT INTO CBS.cbs_musteri_kontak(musteri_no, sira_no, ad,
                                       soyad, email, web_site,
                                       tel_alan_kod, tel_no, gsm_alan_kod,
                                       gsm_no, fax_alan_kod, fax_no)
            SELECT pn_musteri_no, sira_no, ad,
                   soyad, email, web_site,
                   tel_alan_kod, tel_no, gsm_alan_kod,
                   gsm_no, fax_alan_kod, fax_no
              FROM CBS.cbs_musteri_guncel_kontak
             WHERE tx_no = pn_tx_no;

        /* Copy data for additional tab in MUSIZ  UrmatA 20150907 */
        DELETE FROM CBS.CBS_MUSTERI_UPD_INF
              WHERE musteri_no = pn_musteri_no;

        INSERT INTO CBS.CBS_MUSTERI_UPD_INF(musteri_no, activity, owners,
                                        results, update_date, create_user)
            SELECT pn_musteri_no, activity, owners,
                   results, update_date, USER
              FROM CBS.CBS_MUSTERI_GUNCEL_UPD_INF
             WHERE tx_no = pn_tx_no;

        --BOM aisuluud cq5516
        /* Documents by third persons AisuluuD CQ5516 21112016*/
        DELETE FROM CBS.CBS_CUSTOMER_BY_THIRD_PERSONS
              WHERE customer_no = pn_musteri_no;

        INSERT INTO CBS.CBS_CUSTOMER_BY_THIRD_PERSONS(CUSTOMER_NO, TYPE_OF_DOCUMENT, NO_OF_DOCUMENT, OPENING_DATE, EXPIRY, EXPIRY_DATE,
                                                      cbs_no_of_doc, active, description,opn_mng, firstname, middle_name, surname)
            SELECT pn_musteri_no, a.TYPE_OF_DOCUMENT, a.NO_OF_DOCUMENT, A.OPENING_DATE, a.EXPIRY, a.EXPIRY_DATE,
                   a.cbs_no_of_doc, a.active, a.description, a.opn_mng, p.firstname, p.middle_name, p.surname
              FROM CBS.CBS_CUST_BY_THIRD_PERS_MODIF a LEFT JOIN CBS.cbs_doc_third_persons_modif p ON p.tx_no = a.tx_no AND p.cbs_no_of_doc = A.CBS_NO_OF_DOC
             WHERE a.tx_no = pn_tx_no;
        --EOM aisuluud cq5516

        --BOM MaratM CBS-258
        --DELETE FROM CBS.CBS_MUSTERI_SOURCE S WHERE S.MUSTERI_NO = pn_musteri_no;

        /*INSERT INTO CBS.CBS_MUSTERI_SOURCE (MUSTERI_NO, IS_SALARY, IS_SCHOLARSHIP, IS_PENSION, IS_P_SURRENDER, IS_DEPENDENCY, IS_CURRENCY, IS_OTHER,
                            IS_OTHER_TEXT, IS_AMOUNT_FROM, IS_AMOUNT_TO, POA_SLP, POA_FS, POA_CIT, POA_LN, POA_CP, POA_TR, POA_POT, POA_PTI, POA_IP,
                            POA_FT, POA_INP, RGP, USA, POP, WITH_POP)
                     SELECT pn_musteri_no, S.IS_SALARY, S.IS_SCHOLARSHIP, S.IS_PENSION, S.IS_P_SURRENDER, S.IS_DEPENDENCY, S.IS_CURRENCY, S.IS_OTHER,
                            S.IS_OTHER_TEXT, S.IS_AMOUNT_FROM, S.IS_AMOUNT_TO, S.POA_SLP, S.POA_FS, S.POA_CIT, S.POA_LN, S.POA_CP, S.POA_TR, S.POA_POT, S.POA_PTI, S.POA_IP,
                            S.POA_FT, S.POA_INP, S.RGP, S.USA, S.POP, S.WITH_POP
                       FROM CBS.CBS_MUSTERI_GUNCEL_SOURCE S
                      WHERE S.TX_NO = pn_tx_no;*/

        UPDATE CBS.CBS_MUSTERI_SOURCE
           SET (MUSTERI_NO, IS_SALARY, IS_SCHOLARSHIP, IS_PENSION, IS_P_SURRENDER, IS_DEPENDENCY, IS_CURRENCY, IS_OTHER,
                IS_OTHER_TEXT, IS_AMOUNT_FROM, IS_AMOUNT_TO, POA_SLP, POA_FS, POA_CIT, POA_LN, POA_CP, POA_TR, POA_POT,
                POA_PTI, POA_IP, POA_FT, POA_INP, RGP, USA, POP, WITH_POP
               ) = (
               SELECT pn_musteri_no,
                      S.IS_SALARY,
                      S.IS_SCHOLARSHIP,
                      S.IS_PENSION,
                      S.IS_P_SURRENDER,
                      S.IS_DEPENDENCY,
                      S.IS_CURRENCY,
                      S.IS_OTHER,
                      S.IS_OTHER_TEXT,
                      S.IS_AMOUNT_FROM,
                      S.IS_AMOUNT_TO,
                      S.POA_SLP,
                      S.POA_FS,
                      S.POA_CIT,
                      S.POA_LN,
                      S.POA_CP,
                      S.POA_TR,
                      S.POA_POT,
                      S.POA_PTI,
                      S.POA_IP,
                      S.POA_FT,
                      S.POA_INP,
                      S.RGP,
                      S.USA,
                      S.POP,
                      S.WITH_POP
                 FROM CBS.CBS_MUSTERI_GUNCEL_SOURCE S
                WHERE S.TX_NO = pn_tx_no)
        WHERE musteri_no = pn_musteri_no;
        --EOM MaratM CBS-258
        
      --BOM AntonPa CBS-395 271022 
        DELETE FROM CBS.CBS_CUSTOMER_LICENSES
              WHERE CUSTOMER_NO = PN_MUSTERI_NO;
        
        INSERT INTO CBS.CBS_CUSTOMER_LICENSES(CUSTOMER_NO, ACTIVITY_CODE, LICENSE_NO, ISSUE_DATE, ISSUED_BY, VALIDITY_DATE) 
        SELECT PN_MUSTERI_NO, ACTIVITY_CODE, LICENSE_NO, ISSUE_DATE, ISSUED_BY, VALIDITY_DATE 
        FROM CBS.CBS_CUSTOMER_UPD_LICENSES
        WHERE TX_NO = PN_TX_NO; 
      --EOM AntonPa CBS-395 271022
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '103' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END Sp_Musteriyi_Guncelle;

    /*****************************************************************************************************************/
    /*   Procedure  Sp_Musteri_Adres                                                                                 */
    /*   Miiteriye ait adres bilgisi getirilir.                                                                      */
    /*****************************************************************************************************************/
    PROCEDURE Sp_Musteri_Adres(pn_musteri_no     CBS.CBS_MUSTERI.musteri_no%TYPE,
                               ps_adres      OUT CBS.CBS_MUSTERI_ADRES.adres%TYPE,
                               ps_semt       OUT CBS.CBS_MUSTERI_ADRES.semt%TYPE,
                               ps_il_kod     OUT CBS.CBS_MUSTERI_ADRES.il_kod%TYPE,
                               pn_posta_kod  OUT CBS.CBS_MUSTERI_ADRES.posta_kod%TYPE,
                               ps_ulke_kod   OUT CBS.CBS_MUSTERI_ADRES.ulke_kod%TYPE) IS
        CURSOR cur_ekstre_adres  IS
            SELECT adres, a.semt, a.il_kod,
                   a.posta_kod, a.ulke_kod
              FROM CBS.CBS_MUSTERI_ADRES a, CBS.CBS_MUSTERI b
             WHERE a.musteri_no = b.musteri_no AND adres_kod = b.extre_adres_kod AND a.musteri_no = pn_musteri_no;


        CURSOR cur_musteri  IS
            SELECT adres, a.semt, a.il_kod,
                   a.posta_kod, a.ulke_kod
              FROM CBS.CBS_MUSTERI_ADRES a, CBS.CBS_MUSTERI b
             WHERE a.musteri_no = b.musteri_no AND adres_kod = DECODE(b.musteri_tipi_kod, '1', '1', '2') AND a.musteri_no = pn_musteri_no;

        -- C iletisim adresi
        CURSOR cur_musteri_contact  IS
            SELECT adres, a.semt, a.il_kod,
                   a.posta_kod, a.ulke_kod
              FROM CBS.CBS_MUSTERI_ADRES a, CBS.CBS_MUSTERI b
             WHERE a.musteri_no = b.musteri_no AND adres_kod = '3' AND a.musteri_no = pn_musteri_no;
    BEGIN
        /*ekstre adresi alinir */
        IF cur_ekstre_adres%ISOPEN THEN
            CLOSE cur_ekstre_adres;
        END IF;

        OPEN cur_ekstre_adres;

        LOOP
            FETCH cur_ekstre_adres
                INTO ps_adres, ps_semt, ps_il_kod,
                     pn_posta_kod, ps_ulke_kod;

            EXIT WHEN cur_ekstre_adres%NOTFOUND;
        END LOOP;

        CLOSE cur_ekstre_adres;

        /* ekstre adres tanimli degilse Geriek musteri iiin Ev , diierleri iiin ii adresi alinir */
        IF ps_adres IS NULL THEN
            IF cur_musteri%ISOPEN THEN
                CLOSE cur_musteri;
            END IF;

            OPEN cur_musteri;

            LOOP
                FETCH cur_musteri
                    INTO ps_adres, ps_semt, ps_il_kod,
                         pn_posta_kod, ps_ulke_kod;

                EXIT WHEN cur_musteri%NOTFOUND;
            END LOOP;

            CLOSE cur_musteri;
        END IF;

        /* is veya ev adresi tanimli degilse iletisim adresi alinir */
        IF ps_adres IS NULL THEN
            IF cur_musteri_contact%ISOPEN THEN
                CLOSE cur_musteri_contact;
            END IF;

            OPEN cur_musteri_contact;

            LOOP
                FETCH cur_musteri_contact
                    INTO ps_adres, ps_semt, ps_il_kod,
                         pn_posta_kod, ps_ulke_kod;

                EXIT WHEN cur_musteri_contact%NOTFOUND;
            END LOOP;

            CLOSE cur_musteri_contact;
        END IF;

        IF ps_adres IS NULL THEN
            ps_adres := ' ';
        END IF;

        IF ps_semt IS NULL THEN
            ps_semt := ' ';
        END IF;

        IF ps_il_kod IS NULL THEN
            ps_il_kod := ' ';
        END IF;

        IF pn_posta_kod IS NULL THEN
            pn_posta_kod := 0;
        END IF;

        IF ps_ulke_kod IS NULL THEN
            ps_ulke_kod := ' ';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '147' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Procedure  Sp_Musteri_No_Bul                                                                                */
    /*   Misteri arama kriterleri sonrasi mevcut ise numarasi dondurulur.                                            */
    /*****************************************************************************************************************/
    PROCEDURE Sp_Musteri_No_Bul(ps_full_isim VARCHAR2, ps_unvan VARCHAR2, ps_musteri_tipi VARCHAR2,
                                ps_yerlesim_kod VARCHAR2, ps_baba_adi CBS.CBS_MUSTERI.baba_adi%TYPE, pd_dogum_tarihi CBS.CBS_MUSTERI.dogum_tarihi%TYPE,
                                ps_dogum_yeri CBS.CBS_MUSTERI.dogum_yeri%TYPE, pn_musteri_no OUT CBS.CBS_MUSTERI.musteri_no%TYPE, ps_kimlik_id CBS.CBS_MUSTERI.KIMLIK_KOD%TYPE, 
                                ps_kimlik_no VARCHAR2, ps_vergi_no VARCHAR2, ps_vergi_daire VARCHAR2, ps_full_isim_eng VARCHAR2 DEFAULT NULL) IS
        ln_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE;

        /* cursor for  yurtici bireysel musteriler */
        /* tc kimlik no zorunlu arama kriteridir. */

        CURSOR cur_musteri_bireysel  IS
            SELECT MIN(musteri_no)
              FROM CBS.CBS_MUSTERI
             WHERE ((vergi_no = ps_vergi_no AND ps_vergi_no IS NOT NULL)
                 OR ((arama_isim = CBS.Pkg_Genel.sf_sil_turkce_char(ps_full_isim)
                  AND NVL(CBS.Pkg_Genel.sf_sil_turkce_char(baba_adi), ' ') = NVL(CBS.Pkg_Genel.sf_sil_turkce_char(ps_baba_adi), ' ')
                  AND TRUNC(dogum_tarihi) = TRUNC(pd_dogum_tarihi)
                  AND NVL(CBS.pkg_genel.sf_sil_turkce_char(dogum_yeri), ' ') = NVL(CBS.pkg_genel.sf_sil_turkce_char(ps_dogum_yeri), ' ')
                  AND ((ps_kimlik_id = '1' AND NUFUS_CUZDANI_SERI_NO = ps_kimlik_no)
                    OR (ps_kimlik_id = '2' AND EHLIYET_BELGE_NO = ps_kimlik_no)
                    OR (ps_kimlik_id = '3' AND PASAPORT_NO = ps_kimlik_no))))
                 OR --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                   ((ps_full_isim_eng IS NOT NULL
                 AND CBS.Pkg_Genel.sf_sil_turkce_char(UPPER(TRIM(isim || ikinci_isim || soyadi))) = CBS.Pkg_Genel.sf_sil_turkce_char(ps_full_isim_eng)
                 AND NVL(CBS.Pkg_Genel.sf_sil_turkce_char(baba_adi), ' ') = NVL(CBS.Pkg_Genel.sf_sil_turkce_char(ps_baba_adi), ' ')
                 AND TRUNC(dogum_tarihi) = TRUNC(pd_dogum_tarihi)
                 AND NVL(CBS.pkg_genel.sf_sil_turkce_char(dogum_yeri), ' ') = NVL(CBS.pkg_genel.sf_sil_turkce_char(ps_dogum_yeri), ' ')
                 AND ((ps_kimlik_id = '1' AND NUFUS_CUZDANI_SERI_NO = ps_kimlik_no)
                   OR (ps_kimlik_id = '2' AND EHLIYET_BELGE_NO = ps_kimlik_no)
                   OR (ps_kimlik_id = '3' AND PASAPORT_NO = ps_kimlik_no))))); --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system

        /* cursor for  yurt ici kurumsal ve ticari musteriler */
        CURSOR cur_musteri_yurtici_kurumsal  IS
            SELECT MIN(musteri_no)
              FROM CBS.CBS_MUSTERI
             WHERE (arama_isim = CBS.Pkg_Genel.sf_sil_turkce_char(ps_unvan)) OR (vergi_no = ps_vergi_no AND ps_vergi_no IS NOT NULL);

        /* cursor for  (yurt disi kurumsal ve ticari ) miimusteriler */
        CURSOR cur_musteri_yurtdisi_kurumsal  IS
            SELECT MIN(musteri_no)
              FROM CBS.CBS_MUSTERI
             WHERE (arama_isim = CBS.Pkg_Genel.sf_sil_turkce_char(ps_unvan)) OR (vergi_no = ps_vergi_no AND ps_vergi_no IS NOT NULL);

        /* cursor for ve yurt ici yurt disi tum banka  musteriler */
        CURSOR cur_musteri_banka  IS
            SELECT MIN(musteri_no)
              FROM CBS.CBS_MUSTERI
             WHERE (arama_isim = CBS.Pkg_Genel.sf_sil_turkce_char(ps_unvan)) OR (vergi_no = ps_vergi_no AND ps_vergi_no IS NOT NULL);
    BEGIN
        /* bireysel musteriler */
        IF ps_musteri_tipi IN ('1', '2') THEN --bireysel,Private Enterpreneurs
            /* cursor for  yurt ici bireysel musteriler */
            IF cur_musteri_bireysel%ISOPEN THEN
                CLOSE cur_musteri_bireysel;
            END IF;

            OPEN cur_musteri_bireysel;

            LOOP
                FETCH cur_musteri_bireysel INTO pn_musteri_no;

                EXIT WHEN cur_musteri_bireysel%NOTFOUND;
            END LOOP;

            CLOSE cur_musteri_bireysel;
        END IF;

        /* kurumsal ve ticari  musteriler */
        IF ps_musteri_tipi IN ('3') THEN -- kurumsal ise
            IF ps_yerlesim_kod = '1' THEN --yurtici
                /* cursor for  yurt ici musteriler */
                IF cur_musteri_yurtici_kurumsal%ISOPEN THEN
                    CLOSE cur_musteri_yurtici_kurumsal;
                END IF;

                OPEN cur_musteri_yurtici_kurumsal;

                LOOP
                    FETCH cur_musteri_yurtici_kurumsal INTO pn_musteri_no;

                    EXIT WHEN cur_musteri_yurtici_kurumsal%NOTFOUND;
                END LOOP;

                CLOSE cur_musteri_yurtici_kurumsal;
            ELSE
                /* cursor for  yurt ici musteriler */
                IF cur_musteri_yurtdisi_kurumsal%ISOPEN THEN
                    CLOSE cur_musteri_yurtdisi_kurumsal;
                END IF;

                OPEN cur_musteri_yurtdisi_kurumsal;

                LOOP
                    FETCH cur_musteri_yurtdisi_kurumsal INTO pn_musteri_no;

                    EXIT WHEN cur_musteri_yurtdisi_kurumsal%NOTFOUND;
                END LOOP;

                CLOSE cur_musteri_yurtdisi_kurumsal;
            END IF;
        END IF;

        /* banka musterileri */
        IF ps_musteri_tipi IN ('4') THEN
            IF cur_musteri_banka%ISOPEN THEN
                CLOSE cur_musteri_banka;
            END IF;

            OPEN cur_musteri_banka;

            LOOP
                FETCH cur_musteri_banka INTO pn_musteri_no;

                EXIT WHEN cur_musteri_banka%NOTFOUND;
            END LOOP;

            CLOSE cur_musteri_banka;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '112' || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Personel_Adi                                                                                */
    /*   Personel koduna kariilik gelen aciklama getirilir.                                                          */
    /*****************************************************************************************************************/

    FUNCTION Sf_Personel_Adi(pn_personel_no CBS.CBS_PERSONEL.personel_numara%TYPE)
        RETURN VARCHAR2 IS
        ls_personel_adi VARCHAR2(100) := NULL;
    BEGIN
        SELECT adi || ' ' || soyadi
          INTO ls_personel_adi
          FROM CBS.CBS_PERSONEL
         WHERE personel_numara = pn_personel_no;

        RETURN ls_personel_adi;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '106' || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Musteri_Adi                                                                                 */
    /*   Musteri koduna kariilik gelen aciklama getirilir.                                                           */
    /*****************************************************************************************************************/
    FUNCTION Sf_Musteri_Adi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN VARCHAR2 IS
        ls_musteri_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT --DECODE(musteri_tipi_kod, '1', isim || ' ' || ikinci_isim || ' '||soyadi,
               --             '2', isim || ' ' || ikinci_isim || ' '||soyadi,ticari_unvan) --sevalb 02062007
               DECODE(musteri_tipi_kod,  '1', isim || DECODE(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,  '2', isim || DECODE(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,  ticari_unvan) --mutluo
          INTO ls_musteri_adi
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN UPPER(TRIM(ls_musteri_adi));
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '111' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Dk_Grup_Adi                                                                                 */
    /*   Dk Grup koduna kariilik gelen aciklama getirilir.                                                           */
    /*****************************************************************************************************************/
    FUNCTION Sf_Dk_Grup_Adi(pn_dk_grup_kodu CBS.CBS_MUSTERI.dk_grup_kod%TYPE)
        RETURN VARCHAR2 IS
        ls_dk_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT aciklama
          INTO ls_dk_adi
          FROM CBS.CBS_DK_GRUP_KODLARI
         WHERE dk_grup_kodu = pn_dk_grup_kodu;

        RETURN ls_dk_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    --        RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '113' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Musteri_Tipi_Adi                                                                            */
    /*   Musteri Tipi koduna kariilik gelen aciklama getirilir.                                                      */
    /*****************************************************************************************************************/
    FUNCTION Sf_Musteri_Tipi_Adi(ps_musteri_tipi_kodu CBS.CBS_MUSTERI.musteri_tipi_kod%TYPE)
        RETURN VARCHAR2 IS
        ls_musteri_tipi_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT aciklama
          INTO ls_musteri_tipi_adi
          FROM CBS.CBS_MUSTERI_TIPI_KODLARI
         WHERE musteri_tipi = ps_musteri_tipi_kodu;

        RETURN ls_musteri_tipi_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '114' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Yerlesim_Adi                                                                                */
    /*   Yerlesim koduna kariilik gelen aciklama getirilir.                                                          */
    /*****************************************************************************************************************/
    FUNCTION Sf_Yerlesim_Adi(ps_yerlesim_kodu CBS.CBS_MUSTERI.yerlesim_kod%TYPE)
        RETURN VARCHAR2 IS
        ls_yerlesim_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT aciklama
          INTO ls_yerlesim_adi
          FROM CBS.CBS_YERLESIM_KODLARI
         WHERE yerlesim_kodu = ps_yerlesim_kodu;

        RETURN ls_yerlesim_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '115' || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Meslek_Adi                                                                                  */
    /*   Meslek koduna kariilik gelen aciklama getirilir.                                                            */
    /*****************************************************************************************************************/
    FUNCTION Sf_Meslek_Adi(ps_meslek_kodu CBS.CBS_MUSTERI.meslek_kod%TYPE)
        RETURN VARCHAR2 IS
        ls_meslek_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT aciklama
          INTO ls_meslek_adi
          FROM CBS.CBS_MESLEK_KODLARI
         WHERE meslek_kodu = ps_meslek_kodu;

        RETURN ls_meslek_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL; -- CQ 5186 Defect: AML problems VictorK 05.11.2015
    --RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '122' || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Egitim_Adi                                                                                  */
    /*   Egitim koduna kariilik gelen aciklama getirilir.                                                            */
    /*****************************************************************************************************************/
    FUNCTION Sf_Egitim_Adi(ps_egitim_kodu CBS.CBS_MUSTERI.egitim_kod%TYPE)
        RETURN VARCHAR2 IS
        ls_egitim_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT aciklama
          INTO ls_egitim_adi
          FROM CBS.CBS_EGITIM_KODLARI
         WHERE egitim_kodu = ps_egitim_kodu;

        RETURN ls_egitim_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '123' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Ozel_Kategori_Adi                                                                           */
    /*   Ozel_Kategori koduna kariilik gelen aciklama getirilir.                                                     */
    /*****************************************************************************************************************/
    FUNCTION Sf_Ozel_Kategori_Adi(ps_ozel_kategori_kodu CBS.CBS_MUSTERI.ozel_kategori_kod%TYPE)
        RETURN VARCHAR2 IS
        ls_ozel_kategori_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT aciklama
          INTO ls_ozel_kategori_adi
          FROM CBS.CBS_OZEL_KATEGORI_KODLARI
         WHERE kategori_kodu = ps_ozel_kategori_kodu;

        RETURN ls_ozel_kategori_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '124' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Tesvik_adi                                                                                  */
    /*   Tesvik koduna kariilik gelen aciklama getirilir.                                                            */
    /*****************************************************************************************************************/
    FUNCTION Sf_Tesvik_Adi(ps_tesvik_kodu CBS.CBS_MUSTERI.tesvik_kod%TYPE)
        RETURN VARCHAR2 IS
        ls_tesvik_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT aciklama
          INTO ls_tesvik_adi
          FROM CBS.CBS_TESVIK_KODLARI
         WHERE tesvik_kodu = ps_tesvik_kodu;

        RETURN ls_tesvik_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '125' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Cek_Karnesi_Istiyormu                                                                       */
    /*   Musterinin cek karnesi talebinin olup olmadiii sorgulanir.                                                  */
    /*****************************************************************************************************************/
    FUNCTION Sf_Cek_Karnesi_Istiyormu(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN VARCHAR2 IS
        ls_cek_karne VARCHAR2(1) := NULL;
    BEGIN
        SELECT cek_karnesi_f
          INTO ls_cek_karne
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_cek_karne;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '126' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_PersonelSicilNoAl                                                                           */
    /*   PersonelSicilNoAl koduna kariilik gelen aciklama getirilir.                                                 */
    /*****************************************************************************************************************/
    FUNCTION Sf_PersonelSicilNoAl(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN NUMBER IS
        ln_sicilno NUMBER;
    BEGIN
        SELECT personel_sicil_no
          INTO ln_sicilno
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ln_sicilno;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '201' || CBS.Pkg_Hata.getDELIMITER || pn_musteri_no || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Medeni_Hal_Adi                                                                              */
    /*   Medeni Hal koduna kariilik gelen aciklama getirilir.                                                        */
    /*****************************************************************************************************************/
    FUNCTION Sf_Medeni_Hal_Adi(ps_medeni_hal_kodu CBS.CBS_MEDENI_HAL_KODLARI.medeni_hal_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_medeni_aciklama CBS.CBS_MEDENI_HAL_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_medeni_aciklama
          FROM CBS.CBS_MEDENI_HAL_KODLARI
         WHERE medeni_hal_kodu = ps_medeni_hal_kodu;

        RETURN ls_medeni_aciklama;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '160' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Sektor_Adi                                                                                  */
    /*   Sektor koduna kariilik gelen aciklama getirilir.                                                            */
    /*****************************************************************************************************************/
    /*sektor kodu yerine activity code kullaniliyor.*/
    FUNCTION Sf_Sektor_Adi(pn_sektor_kod CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_sektor_adi CBS.CBS_finans_KODLARI.ACIKLAMA%TYPE;
    BEGIN
        SELECT SUBSTR(ACIKLAMA, 1, 200) --sevalb 22062012 25977-Changing existing activity codes
          INTO ls_sektor_adi
          FROM CBS.CBS_finans_KODLARI
         WHERE finans_kodu = pn_sektor_kod;

        RETURN ls_sektor_adi;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '161' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Kimlik_Adi                                                                                  */
    /*   Kimlik koduna kariilik gelen aciklama getirilir.                                                            */
    /*****************************************************************************************************************/
    FUNCTION Sf_Kimlik_Adi(ps_kimlik_kod CBS.CBS_KIMLIK_KODLARI.kimlik_tipi%TYPE)
        RETURN VARCHAR2 IS
        ls_kimlik_adi CBS.CBS_KIMLIK_KODLARI.aciklama%TYPE;
    BEGIN
        IF ps_kimlik_kod IS NOT NULL THEN
            SELECT aciklama
              INTO ls_kimlik_adi
              FROM CBS.CBS_KIMLIK_KODLARI
             WHERE kimlik_tipi = ps_kimlik_kod;
        END IF;

        RETURN ls_kimlik_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '162' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Adres_Tip_Adi                                                                               */
    /*   Adres_Tip koduna kariilik gelen aciklama getirilir.                                                         */
    /*****************************************************************************************************************/
    FUNCTION Sf_Adres_Tip_Adi(ps_adres_tipi CBS.CBS_ADRES_KODLARI.adres_tipi%TYPE)
        RETURN VARCHAR2 IS
        ls_adres_adi CBS.CBS_KIMLIK_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_adres_adi
          FROM CBS.CBS_ADRES_KODLARI
         WHERE adres_tipi = ps_adres_tipi;

        RETURN ls_adres_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '167' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Vergi_Muaf_Adi                                                                              */
    /*   Vergi Muaf koduna kariilik gelen aciklama getirilir.                                                        */
    /*****************************************************************************************************************/
    FUNCTION Sf_Vergi_Muaf_Adi(pn_vergi_muaf_kodu CBS.CBS_VERGI_MUAF_KODLARI.vergi_muaf_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_vergi_muaf_adi CBS.CBS_VERGI_MUAF_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_vergi_muaf_adi
          FROM CBS.CBS_VERGI_MUAF_KODLARI
         WHERE vergi_muaf_kodu = pn_vergi_muaf_kodu;

        RETURN ls_vergi_muaf_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '168' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Grup_Adi                                                                                    */
    /*   Grup koduna kariilik gelen aciklama getirilir.                                                              */
    /*****************************************************************************************************************/
    FUNCTION Sf_Grup_Adi(ps_grup_kodu CBS.CBS_GRUP_KODLARI.grup_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_grup_adi CBS.CBS_GRUP_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_grup_adi
          FROM CBS.CBS_GRUP_KODLARI
         WHERE grup_kodu = ps_grup_kodu;

        RETURN ls_grup_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '169' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Finans_Adi                                                                                  */
    /*   Finans koduna kariilik gelen aciklama getirilir.                                                            */
    /*****************************************************************************************************************/
    FUNCTION Sf_Finans_Adi(ps_finans_kodu CBS.CBS_FINANS_KODLARI.finans_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_finans_adi CBS.CBS_FINANS_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT SUBSTR(aciklama, 1, 200) --sevalb 22062012 25977-Changing existing activity codes
          INTO ls_finans_adi
          FROM CBS.CBS_FINANS_KODLARI
         WHERE finans_kodu = ps_finans_kodu;

        RETURN ls_finans_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '170' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Reuters_Dealing_Adi                                                                         */
    /*   Reuters Dealing koduna kariilik gelen aciklama getirilir.                                                   */
    /*****************************************************************************************************************/
    FUNCTION Sf_Reuters_Dealing_Adi(pn_reuters_dealing_kodu CBS.CBS_REUTERS_DEALING_KODLARI.kod%TYPE)
        RETURN VARCHAR2 IS
        ls_reuters_dealing_adi CBS.CBS_REUTERS_DEALING_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT kisa_aciklama
          INTO ls_reuters_dealing_adi
          FROM CBS.CBS_REUTERS_DEALING_KODLARI
         WHERE kod = pn_reuters_dealing_kodu;

        RETURN ls_reuters_dealing_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '171' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Cinsiyet_Adi                                                                                */
    /*   Cinsiyet koduna kariilik gelen aciklama getirilir.                                                          */
    /*****************************************************************************************************************/
    FUNCTION Sf_Cinsiyet_Adi(ps_cinsiyet_kodu CBS.CBS_CINSIYET_KODLARI.cinsiyet_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_cinsiyet_adi CBS.CBS_CINSIYET_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_cinsiyet_adi
          FROM CBS.CBS_CINSIYET_KODLARI
         WHERE cinsiyet_kodu = ps_cinsiyet_kodu;

        RETURN ls_cinsiyet_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '172' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Musterinin_Hesabi_Varmi                                                                     */
    /*   Musterinin hesabinin olup olmadigi kontrol edilir.                                                          */
    /*   not: kredi hesaplari hazirlandiginda bu kisma ekleme yapilmalidir.                                          */
    /*****************************************************************************************************************/
    FUNCTION Sf_Musterinin_Hesabi_Varmi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN NUMBER IS
        ln_adet NUMBER := 0;
    BEGIN
        SELECT COUNT(*)
          INTO ln_adet
          FROM CBS.cbs_vw_hesap_izleme
         WHERE musteri_no = pn_musteri_no;

        RETURN NVL(ln_adet, 0);
    END Sf_Musterinin_Hesabi_Varmi;

    /*****************************************************************************************************************/
    /*   Function     Sf_Adresi_Varmi                                                                                */
    /*   Musterinin girilen adres koduna ait kaydinin olup olmadigi kontrol edilir.                                  */
    /*****************************************************************************************************************/
    FUNCTION Sf_Adresi_Varmi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE, ps_adres_kod CBS.CBS_MUSTERI_ADRES.adres_kod%TYPE)
        RETURN NUMBER IS
        ln_adet NUMBER := 0;
    BEGIN
        SELECT COUNT(*)
          INTO ln_adet
          FROM CBS.CBS_MUSTERI_ADRES
         WHERE musteri_no = pn_musteri_no AND adres_kod = ps_adres_kod;

        RETURN NVL(ln_adet, 0);
    END Sf_Adresi_Varmi;

    /*****************************************************************************************************************/
    /*   Function     Sf_Guncel_Girilen_Adresi_Varmi                                                                 */
    /*   Musterinin girilen adres koduna ait guncelleme islem kaydi olup olmadigi kontrol edilir.                    */
    /*****************************************************************************************************************/
    FUNCTION Sf_Guncel_Girilen_Adresi_Varmi(pn_tx_no CBS.CBS_MUSTERI_GUNCEL_ADRES.adres_kod%TYPE, ps_adres_kod CBS.CBS_MUSTERI_ADRES.adres_kod%TYPE)
        RETURN NUMBER IS
        ln_adet NUMBER := 0;
    BEGIN
        SELECT COUNT(*)
          INTO ln_adet
          FROM CBS.CBS_MUSTERI_GUNCEL_ADRES
         WHERE tx_no = pn_tx_no AND adres_kod = ps_adres_kod;

        RETURN NVL(ln_adet, 0);
    END Sf_Guncel_Girilen_Adresi_Varmi;

    /*****************************************************************************************************************/
    /*   Function     Sf_Musteri_Kodu_Al                                                                             */
    /*   Musterinin durum kodunu alir                                                                                */
    /*****************************************************************************************************************/
    FUNCTION Sf_Musteri_Kodu_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.durum_kodu%TYPE IS
        ls_durum_kodu CBS.CBS_MUSTERI.durum_kodu%TYPE;
    BEGIN
        SELECT durum_kodu
          INTO ls_durum_kodu
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_durum_kodu;
    END Sf_Musteri_Kodu_Al;

    /*****************************************************************************************************************/
    /*   Function     Sf_Dk_Grup_Kodu_Karsilik_Yerlesim_Tipi_Al                                                      */
    /*   Musterinin dk grup koduna karsilik yerlesim tipini alir                                                     */
    /*****************************************************************************************************************/
    FUNCTION Sf_DkGrupKodunun_YerlesiTipiAl(ps_dk_grup_kodu CBS.CBS_DK_GRUP_KODLARI.dk_grup_kodu%TYPE)
        RETURN CBS.CBS_DK_GRUP_KODLARI.yerlesim_tipi%TYPE IS
        ls_yerlesim_tipi CBS.CBS_DK_GRUP_KODLARI.yerlesim_tipi%TYPE;
    BEGIN
        SELECT yerlesim_tipi
          INTO ls_yerlesim_tipi
          FROM CBS.CBS_DK_GRUP_KODLARI
         WHERE dk_grup_kodu = ps_dk_grup_kodu;

        RETURN ls_yerlesim_tipi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '244' || CBS.Pkg_Hata.getUCPOINTER);
    END Sf_DkGrupKodunun_YerlesiTipiAl;

    /*****************************************************************************************************************/
    /*   Function     Sf_Personel_mi                                                                                 */
    /*   Musterinin personel olup olmadigi kontrol edilir. E ise Personel ,H ise degildir.                           */
    /*****************************************************************************************************************/
    FUNCTION Sf_Personel_mi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN VARCHAR2 IS
        ls_personel VARCHAR2(1) := 'H';
    BEGIN
        SELECT DECODE(NVL(personel_sicil_no, 0), 0, 'H', 'E')
          INTO ls_personel
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_personel;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '249' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END Sf_Personel_mi;

    /*****************************************************************************************************************/
    /*   Procedure sp_musteri_urun_sinif_al                                                                          */
    /*   Musteri numarasi ginderilip urun sinif bilgisi alinir                                                       */
    /*****************************************************************************************************************/
    PROCEDURE sp_musteri_urun_sinif_al(pn_musteri_no         CBS.CBS_MUSTERI.musteri_no%TYPE, 
                                       ps_modul_tur_kod  OUT CBS.CBS_MUSTERI.modul_tur_kod%TYPE, 
                                       ps_urun_tur_kod   OUT CBS.CBS_MUSTERI.urun_tur_kod%TYPE, 
                                       ps_urun_sinif_kod OUT CBS.CBS_MUSTERI.urun_sinif_kod%TYPE) IS
    BEGIN
        IF NVL(pn_musteri_no, 0) <> 0 THEN
            SELECT modul_tur_kod, urun_tur_kod, urun_sinif_kod
              INTO ps_modul_tur_kod, ps_urun_tur_kod, ps_urun_sinif_kod
              FROM CBS.CBS_MUSTERI
             WHERE musteri_no = pn_musteri_no;
        ELSE
            ps_modul_tur_kod := 'CUSTOMER';
            ps_urun_tur_kod := 'GENERAL';
            ps_urun_sinif_kod := 'GENERAL';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '266' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END sp_musteri_urun_sinif_al;

    /*****************************************************************************************************************/
    /*   Function  sf_musteri_urun_sinif_al                                                                          */
    /*   Musterinin modul , urun bilgisi ve ileride sinif ayriminda kulanilacak bir paramatere degeri                */
    /*   ginderilir,sinif bilgisi getirilir                                                                          */
    /*****************************************************************************************************************/
    FUNCTION sf_musteri_urun_sinif_al(ps_modul_tur_kod    CBS.CBS_MUSTERI.modul_tur_kod%TYPE,
                                      ps_urun_tur_kod     CBS.CBS_MUSTERI.urun_tur_kod%TYPE,
                                      ps_sinif_param_kod  VARCHAR2 DEFAULT NULL)
        RETURN CBS.CBS_MUSTERI.urun_sinif_kod%TYPE IS
        ls_kod CBS.CBS_URUN_SINIF.kod%TYPE;
    BEGIN
        SELECT DISTINCT kod
          INTO ls_kod
          FROM CBS.CBS_URUN_SINIF
         WHERE modul_tur_kod = ps_modul_tur_kod AND urun_tur_kod = ps_urun_tur_kod;

        RETURN ls_kod;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '267' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END sf_musteri_urun_sinif_al;


    /*****************************************************************************************************************/
    /*   Function sf_personel_tanimlimi                                                                              */
    /*   personel tablosunda tanimli mi                                                                              */
    /*****************************************************************************************************************/
    FUNCTION sf_personel_tanimlimi(pn_personel_no CBS.CBS_MUSTERI.personel_sicil_no%TYPE)
        RETURN VARCHAR2 IS
        ls_mevcut VARCHAR2(1) := 'H';
    BEGIN
        SELECT 'E'
          INTO ls_mevcut
          FROM CBS.CBS_PERSONEL
         WHERE personel_numara = pn_personel_no;

        RETURN ls_mevcut;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 'H';
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '268' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END sf_personel_tanimlimi;

    /*****************************************************************************************************************/
    /*   Function sf_kullanicinin_musterino_al                                                                       */
    /*   Kullanici kodu ile personel tablosundan musteri numarasi alinir                                             */
    /*****************************************************************************************************************/
    FUNCTION sf_kullanicinin_musterino_al(ps_kullanici_kodu CBS.CBS_KULLANICI.kodu%TYPE)
        RETURN CBS.CBS_MUSTERI.musteri_no%TYPE IS
        ln_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE;
    BEGIN
        SELECT musteri_no
          INTO ln_musteri_no
          FROM CBS.CBS_PERSONEL a, CBS.CBS_KULLANICI b
         WHERE a.personel_numara = b.personel_numara AND b.kodu = ps_kullanici_kodu;

        RETURN NVL(ln_musteri_no, 0);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '269' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END sf_kullanicinin_musterino_al;

    /*****************************************************************************************************************/
    /*   Function sf_personel_musterino_al                                                                           */
    /*   personel numarasi ile musteri numarasi alinir                                                               */
    /*****************************************************************************************************************/
    FUNCTION sf_personel_musterino_al(ps_personel_numara CBS.CBS_PERSONEL.personel_numara%TYPE)
        RETURN CBS.CBS_MUSTERI.musteri_no%TYPE IS
        ln_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE;
    BEGIN
        SELECT musteri_no
          INTO ln_musteri_no
          FROM CBS.CBS_PERSONEL
         WHERE personel_numara = ps_personel_numara;

        RETURN ln_musteri_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '269' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END sf_personel_musterino_al;

    /*****************************************************************************************************************/
    /*   Procedure sp_personel_musteri_no_guncelle                                                                   */
    /*   Personel musteri onaylandiktan sonra personel tablosunun musteri_no alanin guncellenmesi                    */
    /*   aiamasinda iairilir.                                                                                        */
    /*   guncelleme onaylandiktan sonra da cairilir.                                                                 */
    /*****************************************************************************************************************/
    PROCEDURE sp_personel_musterino_guncelle(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE, pn_sicil_no CBS.CBS_MUSTERI.personel_sicil_no%TYPE DEFAULT NULL) IS
        ln_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE;

        personel_yok  EXCEPTION;
    BEGIN
        UPDATE CBS.CBS_PERSONEL
           SET musteri_no = pn_musteri_no
         WHERE personel_numara = pn_sicil_no;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END sp_personel_musterino_guncelle;

    /*****************************************************************************************************************/
    /*   Function     Sf_VergiNo_Al                                                                                  */
    /*   Musteriye ait vergi numarasi alinir                                                                         */
    /*****************************************************************************************************************/
    FUNCTION Sf_VergiNo_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.vergi_no%TYPE IS
        ls_vergi_no CBS.CBS_MUSTERI.vergi_no%TYPE;
    BEGIN
        SELECT vergi_no
          INTO ls_vergi_no
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_vergi_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '278' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END Sf_VergiNo_Al;

    /*****************************************************************************************************************/
    /*   Function     Sf_UyrukKod_Al                                                                                 */
    /*   Musteriye ait uyruk kodu bilgisi alinir                                                                     */
    /*****************************************************************************************************************/
    FUNCTION Sf_UyrukKod_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.uyruk_kod%TYPE IS
        ls_uyruk_kod CBS.CBS_MUSTERI.uyruk_kod%TYPE;
    BEGIN
        SELECT uyruk_kod
          INTO ls_uyruk_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_uyruk_kod;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '279' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END Sf_UyrukKod_Al;

    /*****************************************************************************************************************/
    /*   Procedure  sp_musteri_sektor_grup_al                                                                        */
    /*   Musteri sektor ve grup bilgisi alinir.                                                                      */
    /*****************************************************************************************************************/
    PROCEDURE sp_musteri_sektor_grup_al(pn_musteri_no     CBS.CBS_MUSTERI.musteri_no%TYPE,
                                        pn_sektor_kod OUT CBS.CBS_MUSTERI.sektor_kod%TYPE,
                                        ps_grup_kod   OUT CBS.CBS_MUSTERI.grup_kod%TYPE) IS
        ls_vergi_no CBS.CBS_MUSTERI.vergi_no%TYPE;
    BEGIN
        /*sektor kod yerine activity code kulaniliyor.*/
        SELECT finans_kod, grup_kod
          INTO pn_sektor_kod, ps_grup_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '289' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END sp_musteri_sektor_grup_al;

    /*****************************************************************************************************************/
    /*   Procedure  sp_musteri_grubu_guncelle                                                                        */
    /*   Musteri grubu guncellemede kullanilir .                                                                     */
    /*****************************************************************************************************************/
    PROCEDURE sp_musteri_grubu_guncelle(pn_musteri_no NUMBER, ps_grup_kodu CBS.CBS_GRUP_KODLARI.grup_kodu%TYPE) IS
    BEGIN
        IF pn_musteri_no <> 0 THEN
            UPDATE CBS.CBS_MUSTERI
               SET grup_kod = ps_grup_kodu
             WHERE musteri_no = pn_musteri_no;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '1729' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || SQLERRM || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /****************************************************************************************************************/
    /*   Procedure  Sp_Musteri_DkGrup_Yerlesim_Al                                                                   */
    /*   Musterinin dk grup kodu ve yerlesim kodu alinir                                                            */
    /****************************************************************************************************************/
    PROCEDURE Sp_Musteri_DkGrup_Yerlesim_Al(pn_musteri_no       CBS.CBS_MUSTERI.musteri_no%TYPE,
                                            ps_dk_grup_kod  OUT CBS.CBS_MUSTERI.dk_grup_kod%TYPE,
                                            ps_yerlesim_kod OUT CBS.CBS_MUSTERI.yerlesim_kod%TYPE) IS
    BEGIN
        SELECT dk_grup_kod, yerlesim_kod
          INTO ps_dk_grup_kod, ps_yerlesim_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '100' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /****************************************************************************************************************/
    /*   Function sf_musteri_dk_grup_kod_al                                                                         */
    /*   Musterinin dk grup kodunu alir                                                                             */
    /****************************************************************************************************************/
    FUNCTION sf_musteri_dk_grup_kod_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.dk_grup_kod%TYPE IS
        ln_dk_grup_kod CBS.CBS_MUSTERI.dk_grup_kod%TYPE;
    BEGIN
        SELECT dk_grup_kod
          INTO ln_dk_grup_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ln_dk_grup_kod;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '504' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END sf_musteri_dk_grup_kod_al;

    /****************************************************************************************************************/

    FUNCTION sf_musteri_tipi_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.musteri_tipi_kod%TYPE IS
        ls_musteri_tipi_kod CBS.CBS_MUSTERI.musteri_tipi_kod%TYPE;
    BEGIN
        SELECT musteri_tipi_kod
          INTO ls_musteri_tipi_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;


        RETURN ls_musteri_tipi_kod;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '2305' || CBS.Pkg_Hata.getUCPOINTER);
    END sf_musteri_tipi_al;

    /*****************************************************************************************************************/
    /*   Function     Sf_Sektor_Alt1_Kod_Adi                                                                         */
    /*   Sektor alt1 koduna kariilik gelen aciklama getirilir.                                                       */
    /*****************************************************************************************************************/
    FUNCTION Sf_Sektor_Alt1_Kod_Adi(pn_sektor_kod CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE, ps_sektor_alt1_kodu CBS.CBS_SEKTOR_ALT1_KODLARI.SEKTOR_ALT1_KODU%TYPE)
        RETURN VARCHAR2 IS
        ls_sektor_adi CBS.CBS_SEKTOR_ALT1_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_sektor_adi
          FROM CBS.CBS_SEKTOR_ALT1_KODLARI
         WHERE sektor_kodu = pn_sektor_kod AND sektor_alt1_kodu = ps_sektor_alt1_kodu;

        RETURN ls_sektor_adi;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '161' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Sektor_Alt1_Kod_Adi                                                                         */
    /*   Sektor alt1 koduna kariilik gelen aciklama getirilir.                                                       */
    /*****************************************************************************************************************/
    FUNCTION Sf_Sektor_Alt2_Kod_Adi(pn_sektor_kod        CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE,
                                    ps_sektor_alt1_kodu  CBS.CBS_SEKTOR_ALT1_KODLARI.SEKTOR_ALT1_KODU%TYPE,
                                    ps_sektor_alt2_kodu  CBS.CBS_SEKTOR_ALT2_KODLARI.SEKTOR_ALT2_KODU%TYPE)
        RETURN VARCHAR2 IS
        ls_sektor_adi CBS.CBS_SEKTOR_ALT2_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_sektor_adi
          FROM CBS.CBS_SEKTOR_ALT2_KODLARI
         WHERE sektor_kodu = pn_sektor_kod AND sektor_alt1_kodu = ps_sektor_alt1_kodu AND sektor_alt2_kodu = ps_sektor_alt2_kodu;

        RETURN ls_sektor_adi;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '161' || CBS.Pkg_Hata.getUCPOINTER);
    END;
    /*****************************************************************************************************************/
    /*   Function     Sf_Sektor_Alt1_Kod_Varmi                                                                       */
    /*   Sektor alt1 koduna kariilik gelen aciklama getirilir.                                                       */
    /*****************************************************************************************************************/
    FUNCTION Sf_Sektor_Alt1_Kod_Varmi(pn_sektor_kod CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_mevcut VARCHAR2(5) := 'H';
    BEGIN
        SELECT DISTINCT 'E'
          INTO ls_mevcut
          FROM CBS.CBS_SEKTOR_ALT1_KODLARI
         WHERE sektor_kodu = pn_sektor_kod;

        RETURN ls_mevcut;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 'H';
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Sektor_Alt2_Kod_Varmi                                                                       */
    /*   Sektor alt1 koduna kariilik gelen aciklama getirilir.                                                       */
    /*****************************************************************************************************************/
    FUNCTION Sf_Sektor_Alt2_Kod_Varmi(pn_sektor_kod        CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE,
                                      ps_sektor_alt1_kodu  CBS.CBS_SEKTOR_ALT1_KODLARI.SEKTOR_ALT1_KODU%TYPE)
        RETURN VARCHAR2 IS
        ls_mevcut VARCHAR2(1) := 'H';
    BEGIN
        SELECT DISTINCT 'E'
          INTO ls_mevcut
          FROM CBS.CBS_SEKTOR_ALT2_KODLARI
         WHERE sektor_kodu = pn_sektor_kod AND sektor_alt1_kodu = ps_sektor_alt1_kodu;

        RETURN ls_mevcut;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 'H';
    END;

    /*****************************************************************************************************************/
    /*   Function     sf_rating_kod_aciklama_al                                                                      */
    /*****************************************************************************************************************/
    FUNCTION sf_rating_kod_aciklama_al(ps_rating_kodu CBS.CBS_MUSTERI.rating_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_aciklama CBS.CBS_RATING_KODLARI.ACIKLAMA%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_aciklama
          FROM CBS.CBS_RATING_KODLARI
         WHERE rating_kodu = ps_rating_kodu;

        RETURN ls_aciklama;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    /*****************************************************************************************************************/
    /*   Function sf_yerlesim_kod_al                                                                                 */
    /*****************************************************************************************************************/
    FUNCTION sf_yerlesim_kod_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.yerlesim_kod%TYPE IS
        ls_kod CBS.CBS_MUSTERI.yerlesim_kod%TYPE;
    BEGIN
        SELECT yerlesim_kod
          INTO ls_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_kod;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    FUNCTION sf_adres_al(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_adres     CBS.CBS_MUSTERI_ADRES.adres%TYPE;
        ls_semt      CBS.CBS_MUSTERI_ADRES.semt%TYPE;
        ls_il_kod    CBS.CBS_MUSTERI_ADRES.il_kod%TYPE;
        ln_posta_kod CBS.CBS_MUSTERI_ADRES.posta_kod%TYPE;
        ls_ulke_kod  CBS.CBS_MUSTERI_ADRES.ulke_kod%TYPE;
        ls_tumadres  VARCHAR2(2000);
        ls_posta_kod VARCHAR2(2000);
    BEGIN
        Sp_Musteri_Adres(pn_musteri_no, ls_adres, ls_semt, ls_il_kod, ln_posta_kod, ls_ulke_kod);

        IF NVL(ls_il_kod, 0) = '0' THEN
            ls_il_kod := '';
        END IF;

        IF NVL(ln_posta_kod, 0) = 0 THEN
            ls_posta_kod := '';
        ELSE
            ls_posta_kod := TRIM(TO_CHAR(ln_posta_kod));
        END IF;

        ls_tumadres := TRIM(TRIM(ls_adres) || ' ' || TRIM(ls_semt) || ' ' || TRIM(ls_il_kod) || ' ' || TRIM(TO_CHAR(ls_posta_kod)) || ' ' || TRIM(ls_ulke_kod));

        RETURN ls_tumadres;
    END;

    -----------------

    FUNCTION Sf_Bagli_Musteri_Grup_Adi(ps_grup_kodu CBS.CBS_BAGLI_MUSTERI_GRUPLARI.grup_kodu%TYPE)
        RETURN VARCHAR2 IS
        ls_grup_adi CBS.CBS_BAGLI_MUSTERI_GRUPLARI.aciklama%TYPE;
    BEGIN
        SELECT aciklama
          INTO ls_grup_adi
          FROM CBS.CBS_BAGLI_MUSTERI_GRUPLARI
         WHERE grup_kodu = ps_grup_kodu;

        RETURN ls_grup_adi;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '169' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    FUNCTION Sf_VergiDairesi_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.VERGI_DAIRESI_ADI%TYPE IS
        ls_VergiDairesi CBS.CBS_MUSTERI.VERGI_DAIRESI_ADI%TYPE;
    BEGIN
        SELECT VERGI_DAIRESI_ADI
          INTO ls_VergiDairesi
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_VergiDairesi;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '278' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END Sf_VergiDairesi_Al;

    FUNCTION resident_kod(pn_residency_code NUMBER)
        RETURN NUMBER IS
    BEGIN
        IF pn_residency_code = 1 THEN
            RETURN 1;
        ELSE
            RETURN 0;
        END IF;
    END;

    --------------------------------------------------------

    FUNCTION TaxNumberControl(ps_taxnumber VARCHAR2)
        RETURN NUMBER IS
        ls_taxnp  VARCHAR2(12);
        ln_total  NUMBER := 0;
        ln_remain NUMBER;
        i         NUMBER := 0;
        c         NUMBER := 0;
        indx      NUMBER := 1;
        carp      NUMBER;
    BEGIN
        ls_taxnp := ps_taxnumber;

        IF LENGTH(ps_taxnumber) = 12 THEN
            LOOP
                i := c;
                indx := 1;
                ln_total := 0;

                LOOP
                    ln_total := ln_total + TO_NUMBER(SUBSTR(ls_taxnp, indx, 1)) * (MOD(i, 10) + 1);
                    i := i + 1;
                    indx := indx + 1;
                    EXIT WHEN indx > 11;
                END LOOP;

                ln_remain := MOD(ln_total, 11);

                EXIT WHEN ln_remain < 10;
                c := c + 1;
            END LOOP;
        ELSE
            RETURN 0;
        END IF;

        IF SUBSTR(ls_taxnp, 12, 1) = TO_CHAR(ln_remain) THEN
            RETURN 1;
        ELSE
            RETURN 0;
        END IF;
    END;

    FUNCTION sf_telefon_al(pn_musteri_no NUMBER)
        RETURN NUMBER IS
        ln_telefon VARCHAR2(200);

        CURSOR cur_ekstre_adres  IS
            SELECT TRIM(ULKE_TEL_KOD) || -- sevalb 31012011 SDLC14229
                                        TEL_ALAN_KOD || TEL_NO
              FROM CBS.CBS_MUSTERI_ADRES a, CBS.CBS_MUSTERI b
             WHERE a.musteri_no = b.musteri_no AND adres_kod = b.extre_adres_kod AND a.musteri_no = pn_musteri_no;

        CURSOR cur_musteri  IS
            SELECT TRIM(ULKE_TEL_KOD) || -- sevalb 31012011 SDLC14229
                                        TEL_ALAN_KOD || TEL_NO
              FROM CBS.CBS_MUSTERI_ADRES a, CBS.CBS_MUSTERI b
             WHERE a.musteri_no = b.musteri_no AND adres_kod = DECODE(b.musteri_tipi_kod, '1', '1', '2') AND a.musteri_no = pn_musteri_no;

        -- C iletisim adresi
        CURSOR cur_musteri_contact  IS
            SELECT TRIM(ULKE_TEL_KOD) || -- sevalb 31012011 SDLC14229
                                        TEL_ALAN_KOD || TEL_NO
              FROM CBS.CBS_MUSTERI_ADRES a, CBS.CBS_MUSTERI b
             WHERE a.musteri_no = b.musteri_no AND adres_kod = '3' AND a.musteri_no = pn_musteri_no;
    BEGIN
        /*ekstre adresi alinir */
        IF cur_ekstre_adres%ISOPEN THEN
            CLOSE cur_ekstre_adres;
        END IF;

        OPEN cur_ekstre_adres;

        LOOP
            FETCH cur_ekstre_adres INTO ln_telefon;

            EXIT WHEN cur_ekstre_adres%NOTFOUND;
        END LOOP;

        CLOSE cur_ekstre_adres;

        /* ekstre adres tanimli degilse */
        IF ln_telefon IS NULL THEN
            IF cur_musteri%ISOPEN THEN
                CLOSE cur_musteri;
            END IF;

            OPEN cur_musteri;

            LOOP
                FETCH cur_musteri INTO ln_telefon;

                EXIT WHEN cur_musteri%NOTFOUND;
            END LOOP;

            CLOSE cur_musteri;
        END IF;

        /* is veya ev adresi tanimli degilse iletisim adresi alinir */
        IF ln_telefon IS NULL THEN
            IF cur_musteri_contact%ISOPEN THEN
                CLOSE cur_musteri_contact;
            END IF;

            OPEN cur_musteri_contact;

            LOOP
                FETCH cur_musteri_contact INTO ln_telefon;

                EXIT WHEN cur_musteri_contact%NOTFOUND;
            END LOOP;

            CLOSE cur_musteri_contact;
        END IF;

        RETURN ln_telefon;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ---------------------------------------------------------------------------------------------

    FUNCTION sf_kimlik_veren_yer(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_kimlik_veren_yer VARCHAR2(200) := NULL;
    BEGIN
        SELECT verildigi_yer
          INTO ls_kimlik_veren_yer
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_kimlik_veren_yer;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------

    FUNCTION sf_kimlik_verildigi_tarih(pn_musteri_no NUMBER)
        RETURN DATE IS
        ld_verildigi_tarih DATE;
    BEGIN
        SELECT verildigi_tarih
          INTO ld_verildigi_tarih
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ld_verildigi_tarih;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------

    FUNCTION sf_bolum_kodu_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN CBS.CBS_MUSTERI.bolum_kodu%TYPE IS
        ls_bolum CBS.CBS_MUSTERI.bolum_kodu%TYPE;
    BEGIN
        SELECT bolum_kodu
          INTO ls_bolum
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_bolum;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
    END;

    --------------------------------------------------
    --CLEARING ICIN KEREKLI :Levent Aysan

    FUNCTION sf_OKPO_al(pn_musteri_no NUMBER)
        RETURN CBS.CBS_MUSTERI.OKPO_CODE%TYPE IS
        ls_OKPO CBS.CBS_MUSTERI.OKPO_CODE%TYPE;
    BEGIN
        SELECT OKPO_CODE
          INTO ls_OKPO
          FROM CBS.CBS_MUSTERI
         WHERE MUSTERI_NO = pn_musteri_no;

        RETURN ls_OKPO;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------
    --CLEARING ICIN KEREKLI :Levent Aysan

    FUNCTION sf_SOSYAL_FON_NO_al(pn_musteri_no NUMBER)
        RETURN CBS.CBS_MUSTERI.SOSYAL_FON_NO%TYPE IS
        ls_SOSYAL_FON_NO CBS.CBS_MUSTERI.SOSYAL_FON_NO%TYPE;
    BEGIN
        SELECT SOSYAL_FON_NO
          INTO ls_SOSYAL_FON_NO
          FROM CBS.CBS_MUSTERI
         WHERE MUSTERI_NO = pn_musteri_no;

        RETURN ls_SOSYAL_FON_NO;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------

    FUNCTION musteri_vergiden_muafmi(pn_musteri NUMBER)
        RETURN VARCHAR2 IS
        ls_ret VARCHAR2(1) := 'H';
        ln_cnt NUMBER;
    BEGIN
        SELECT COUNT(*)
          INTO ln_cnt
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri;

        IF ln_cnt = 1 THEN
            SELECT DECODE(VERGI_ZORUNLUMU, 'H', 'E', 'H')
              INTO ls_ret
              FROM CBS.cbs_musteri
             WHERE musteri_no = pn_musteri;
        END IF;

        RETURN ls_ret;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 'H';
    END;

    ------------------------------------------------

    FUNCTION musteri_kimlik_kodu_al(pn_musteri NUMBER)
        RETURN VARCHAR2 IS
        ln_cnt NUMBER := 0;
        ls_ret VARCHAR2(1);
    BEGIN
        SELECT COUNT(*)
          INTO ln_cnt
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri;

        IF ln_cnt = 1 THEN
            SELECT kimlik_kod
              INTO ls_ret
              FROM CBS.cbs_musteri
             WHERE musteri_no = pn_musteri;
        END IF;

        RETURN ls_ret;
    END;

    ------------------------------------------------

    FUNCTION sf_musteri_urun_tur_al(ps_musteri_tipi_kod VARCHAR2)
        RETURN VARCHAR2 IS
        ls_kod CBS.cbs_urun_tur.KOD%TYPE;
    BEGIN
        SELECT DECODE(ps_musteri_tipi_kod,  '1', 'INDIVIDUAL',  '2', 'PRIV.ENTR.',  '3', 'CORPORATE',  '4', 'BANK',  'GENERAL') INTO ls_kod FROM DUAL;

        RETURN ls_kod;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------

    FUNCTION sf_legal_form_code_Ad_al(pn_legal_Form_code NUMBER)
        RETURN VARCHAR2 IS
        ls_aciklama VARCHAR2(200);
    BEGIN
        SELECT aciklama
          INTO ls_aciklama
          FROM CBS.cbs_legal_form_kodlari
         WHERE legal_form_code = pn_legal_form_code;

        RETURN ls_aciklama;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------

    FUNCTION sf_lokal_ad_al(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_LOKAL_UNVAN VARCHAR2(200);
    BEGIN
        SELECT LOKAL_UNVAN
          INTO ls_LOKAL_UNVAN
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_LOKAL_UNVAN;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------

    FUNCTION branch_of_economy_kod_al(pn_musteri_no NUMBER)
        RETURN NUMBER IS
        ls_musteri_tipi_kod      VARCHAR2(200);
        ln_legal_form_code       NUMBER;
        ln_dk_grup_kod           NUMBER;
        ln_kosul_grup_kod        NUMBER := 0;
        ln_branch_of_economy_kod NUMBER;
    BEGIN
        SELECT musteri_tipi_kod, legal_form_code, dk_grup_kod
          INTO ls_musteri_tipi_kod, ln_legal_form_code, ln_dk_grup_kod
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        IF ls_musteri_tipi_kod = '3' AND ln_dk_grup_kod = 1015 THEN
            IF ln_legal_form_code = 10 THEN
                ln_kosul_grup_kod := 1;
            ELSIF ln_legal_form_code IN (22, 23, 24) THEN
                ln_kosul_grup_kod := 2;
            ELSIF ln_legal_form_code = 27 THEN
                ln_kosul_grup_kod := 3;
            ELSE
                ln_kosul_grup_kod := 0;
            END IF;
        END IF;

        SELECT branch_of_economy_kod
          INTO ln_branch_of_economy_kod
          FROM CBS.cbs_payment_dk_grup_kod
         WHERE dk_grup_kod = ln_dk_grup_kod AND musteri_tipi_kod = ls_musteri_tipi_kod AND kosul_grup_kod = ln_kosul_grup_kod;

        RETURN ln_branch_of_economy_kod;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------

    FUNCTION paymentkod_formatli_al(pn_musteri_no NUMBER, ps_istatistik_kod VARCHAR2)
        RETURN VARCHAR2 IS
        ln_branch_of_economy_kod NUMBER;
        ls_kodformatli           VARCHAR2(30);
    BEGIN
        ln_branch_of_economy_kod := branch_of_economy_kod_al(pn_musteri_no);

        IF ln_branch_of_economy_kod IS NOT NULL THEN
            ls_kodformatli := ps_istatistik_kod || LPAD(ln_branch_of_economy_kod, 2, '0');
        END IF;

        RETURN ls_kodformatli;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------

    FUNCTION old_bic_Account_no(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_external_acct_no VARCHAR2(30);
    BEGIN
        SELECT external_acct_no
          INTO ls_external_acct_no
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_external_acct_no;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------

    FUNCTION Report_Customer_Type(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_ret VARCHAR2(1);
    BEGIN
        SELECT Report_Customer_Type
          INTO ls_ret
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_ret;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Risk_Level_Desc                                                                             */
    /*   RETURN RISK LEVEL EXPLANATION FROM RISK LEVEL CODE                                                          */
    /*****************************************************************************************************************/
    FUNCTION Sf_Risk_Level_Desc(ps_risk_level_code CBS.CBS_MUSTERI.RISK_LEVEL_CODE%TYPE)
        RETURN VARCHAR2 IS
        ls_risk_level_desc VARCHAR2(200) := NULL;
    BEGIN
        SELECT EXPLANATION
          INTO ls_risk_level_desc
          FROM CBS.CBS_RISK_LEVEL_CODES
         WHERE RISK_LEVEL_CODE = ps_risk_level_code;

        RETURN ls_risk_level_desc;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '122' || CBS.Pkg_Hata.getDelimiter || CBS.Pkg_Hata.getUCPOINTER);
    END;

    ------------------------------------------------------------------------------------------------------------------------

    -- B-O-M sevalb 22062012 SDLC25977-Changing existing activity codes
    FUNCTION sf_finans_kod_al(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_finans_kod VARCHAR2(3);
    BEGIN
        SELECT finans_kod
          INTO ls_finans_kod
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_finans_kod;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;
    -- E-O-M sevalb 22062012 SDLC25977-Changing existing activity codes

    --B-O-M sevalb 1112012 6270_Automatic loading of customer information from CBS to Card system
    PROCEDURE sp_lokal_isim_parse_et(pn_musteri_no NUMBER, ps_isim_eng OUT VARCHAR2, ps_ikinci_isim_eng OUT VARCHAR2, ps_soyadi_Eng OUT VARCHAR2) IS
        ls_isim2       CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_isim3       CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_isim4       CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_isim5       CBS.cbs_musteri.lokal_unvan%TYPE;
        ps_delimeter   VARCHAR2(1) := ' ';
        ls_lokal_unvan CBS.cbs_musteri.lokal_unvan%TYPE;
    BEGIN
        SELECT UPPER(TRIM(REPLACE(lokal_unvan, '  ', ' ')))
          INTO ls_lokal_unvan
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        ps_isim_eng := TRIM(CBS.pkg_message.Split(ls_lokal_unvan, ps_delimeter, 0));
        ls_isim2 := TRIM(CBS.pkg_message.Split(ls_lokal_unvan, ps_delimeter, 1));
        ls_isim3 := TRIM(CBS.pkg_message.Split(ls_lokal_unvan, ps_delimeter, 2));
        ls_isim4 := TRIM(CBS.pkg_message.Split(ls_lokal_unvan, ps_delimeter, 3)); --exceptionalcustomers
        ls_isim5 := TRIM(CBS.pkg_message.Split(ls_lokal_unvan, ps_delimeter, 4)); --exceptionalcustomers

        IF ls_isim3 IS NOT NULL THEN
            ps_ikinci_isim_eng := ls_isim2;
            ps_soyadi_eng := TRIM(REPLACE(ls_lokal_unvan, ps_isim_eng || ' ' || ls_isim2));

            IF ps_soyadi_eng IS NOT NULL THEN
                ps_ikinci_isim_eng := ls_isim2;
            ELSE
                ps_ikinci_isim_eng := NULL;
                ps_soyadi_eng := ls_isim2;
            END IF;
        /*  if ls_isim4 is not null then
              ps_soyadi_eng := trim(ls_isim3) || ' '|| ls_isim4;
          else
              ps_soyadi_eng := trim(ls_isim3);
          end if;

         if ls_isim5 is not null then
              ps_soyadi_eng := trim(ps_soyadi_eng) || ' '|| ls_isim5;
          end if;
      */
        ELSE
            ps_ikinci_isim_eng := NULL;
            ps_soyadi_eng := TRIM(ls_isim2);
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            log_At('sp_lokal_isim_parse_et-error', pn_musteri_no, TO_CHAR(SQLCODE) || ' ' || SQLERRM);
    END;

    FUNCTION sf_parse_isim_eng_from_lokal(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_isim_eng        CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_ikinci_isim_eng CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_soyadi_eng      CBS.cbs_musteri.lokal_unvan%TYPE;
    BEGIN
        sp_lokal_isim_parse_et(pn_musteri_no, ls_isim_eng, ls_ikinci_isim_eng, ls_soyadi_eng);

        RETURN ls_isim_eng;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    FUNCTION sf_parse_isim2_eng_from_lokal(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_isim_eng        CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_ikinci_isim_eng CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_soyadi_eng      CBS.cbs_musteri.lokal_unvan%TYPE;
    BEGIN
        sp_lokal_isim_parse_et(pn_musteri_no, ls_isim_eng, ls_ikinci_isim_eng, ls_soyadi_eng);

        RETURN ls_ikinci_isim_eng;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    FUNCTION sf_parse_soyadi_eng_from_lokal(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_isim_eng        CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_ikinci_isim_eng CBS.cbs_musteri.lokal_unvan%TYPE;
        ls_soyadi_eng      CBS.cbs_musteri.lokal_unvan%TYPE;
    BEGIN
        sp_lokal_isim_parse_et(pn_musteri_no, ls_isim_eng, ls_ikinci_isim_eng, ls_soyadi_eng);

        RETURN ls_soyadi_eng;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------------------------------------------------------

    FUNCTION sf_isim_eng_al(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_isim CBS.cbs_musteri.isim_eng%TYPE;
    BEGIN
        SELECT isim_eng
          INTO ls_isim
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_isim;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------------------------------------------------------

    FUNCTION sf_ikinci_isim_eng_al(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_ikinci_isim CBS.cbs_musteri.isim_eng%TYPE;
    BEGIN
        SELECT ikinci_isim_eng
          INTO ls_ikinci_isim
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_ikinci_isim;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------------------------------------------------------

    FUNCTION sf_soyadi_eng_al(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_soyadi CBS.cbs_musteri.soyadi%TYPE;
    BEGIN
        SELECT soyadi_eng
          INTO ls_soyadi
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_soyadi;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;

    ------------------------------------------------------------------------------------------------------------------------

    FUNCTION Sf_Musteri_Eng_Adi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE)
        RETURN VARCHAR2 IS
        ls_musteri_adi VARCHAR2(200) := NULL;
    BEGIN
        SELECT --DECODE(musteri_tipi_kod, '1', isim || ' ' || ikinci_isim || ' '||soyadi,
               --             '2', isim || ' ' || ikinci_isim || ' '||soyadi,ticari_unvan) --sevalb 02062007
               DECODE(musteri_tipi_kod,  '1', isim_eng || DECODE(' ' || ikinci_isim_eng || ' ', '  ', ' ', ' ' || ikinci_isim_eng || ' ') || soyadi_eng,  '2', isim_eng || DECODE(' ' || ikinci_isim_eng || ' ', '  ', ' ', ' ' || ikinci_isim_eng || ' ') || soyadi_eng,  lokal_unvan) --mutluo
          INTO ls_musteri_adi
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_musteri_no;

        RETURN UPPER(TRIM(ls_musteri_adi));
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '111' || CBS.Pkg_Hata.getUCPOINTER);
    END;
    --E-O-M sevalb 1112012 6270_Automatic loading of customer information from CBS to Card system

    --BOM CQ5273 MederT 23122015
    FUNCTION Sf_count_campus_id(pn_musteri_no NUMBER, pn_university_code NUMBER, pn_campus_id_no VARCHAR2)
        RETURN NUMBER IS
        ls_count NUMBER;
    BEGIN
        SELECT COUNT(*)
          INTO ls_count
          FROM CBS.cbs_musteri
         WHERE NVL(pn_musteri_no, 0) != musteri_no AND university_code = pn_university_code AND campus_id_no = pn_campus_id_no;

        RETURN ls_count;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;
    --EOM CQ5273 MederT 23122015

    --BOM aisuluud CQ5516 21112016
    FUNCTION sf_document_type_name(ps_document_type_code VARCHAR2, ps_customer_type VARCHAR2)
        RETURN VARCHAR2 IS
        ls_document_name VARCHAR2(200) := NULL;
    BEGIN
        SELECT name_of_doc
          INTO ls_document_name
          FROM CBS.CBS_DOCUMENT_TYPE
         WHERE code_of_doc = ps_document_type_code AND customer_type = ps_customer_type;

        RETURN ls_document_name;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;
    --EOM aisuluud CQ5516 21112016

    --BOM KonstantinJ CQ5627
    PROCEDURE sp_Get_NameSurname_Separately(pn_customer_no IN NUMBER, ps_name IN OUT VARCHAR2, ps_midname IN OUT VARCHAR2, ps_last_name IN OUT VARCHAR2) IS
    BEGIN
        SELECT DECODE(musteri_tipi_kod, '1', isim), DECODE(musteri_tipi_kod, '1', ikinci_isim), DECODE(musteri_tipi_kod, '1', soyadi)
          INTO ps_name, ps_midname, ps_last_name
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_customer_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '111' || CBS.Pkg_Hata.getUCPOINTER);
    END;
    --EOM KonstantinJ CQ5627

    --BOM KonstantinJ CQ5627
    PROCEDURE sp_Get_EngName_Separately(pn_customer_no IN NUMBER, ps_name IN OUT VARCHAR2, ps_midname IN OUT VARCHAR2, ps_last_name IN OUT VARCHAR2) IS
    BEGIN
        SELECT DECODE(musteri_tipi_kod, '1', isim_eng), DECODE(musteri_tipi_kod, '1', ikinci_isim_eng), DECODE(musteri_tipi_kod, '1', soyadi_eng)
          INTO ps_name, ps_midname, ps_last_name
          FROM CBS.CBS_MUSTERI
         WHERE musteri_no = pn_customer_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '111' || CBS.Pkg_Hata.getUCPOINTER);
    END;
    --EOM KonstantinJ CQ5627

    --BOM KonstantinJ CQ5514
    FUNCTION sf_get_residency_code(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_resident_code CBS.CBS_YERLESIM_KODLARI.aciklama%TYPE;
    BEGIN
        SELECT YERLESIM_KOD
          INTO ls_resident_code
          FROM CBS.cbs_musteri musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_resident_code;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;
    --EOM KonstantinJ CQ5514

    --BOM KonstantinJ CQ5514
    FUNCTION sf_get_citizenship_country(pn_musteri_no NUMBER)
        RETURN VARCHAR2 IS
        ls_citezenship_country CBS.CBS_UYRUK_KODLARI.uyruk_kodu%TYPE;
    BEGIN
        SELECT uyruk_kod
          INTO ls_citezenship_country
          FROM CBS.cbs_musteri
         WHERE musteri_no = pn_musteri_no;

        RETURN ls_citezenship_country;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;
    --EOM KonstantinJ CQ5514

    -- BOM begimai CQ6006
    FUNCTION sf_get_musteri_no(lc_isim VARCHAR2, lc_soyadi VARCHAR2, ld_dogum_tarihi DATE,
                               ln_vergi_no VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER)
        RETURN VARCHAR2 IS
        l_text VARCHAR2(2000) := NULL;
    BEGIN
        FOR cur_rec
            IN (SELECT musteri_no, isim, soyadi,
                       dogum_tarihi
                  FROM CBS.cbs_musteri
                 WHERE musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(isim) = UPPER(lc_isim) AND UPPER(soyadi) = UPPER(lc_soyadi)
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(isim) = UPPER(lc_isim) AND dogum_tarihi = ld_dogum_tarihi
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(soyadi) = UPPER(lc_soyadi) AND dogum_tarihi = ld_dogum_tarihi
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(isim) = UPPER(lc_isim) AND vergi_no = ln_vergi_no
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(soyadi) = UPPER(lc_soyadi) AND vergi_no = ln_vergi_no
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND dogum_tarihi = ld_dogum_tarihi AND vergi_no = ln_vergi_no) 
        LOOP
            l_text := l_text || ', ' || cur_rec.musteri_no || ' ' || cur_rec.isim || ' ' || cur_rec.soyadi || ' ' || cur_rec.dogum_tarihi;
        END LOOP;

        RETURN LTRIM(l_text, ', ');
    END;

    -----------------1--------------------

    FUNCTION sf_get_musteri_no_1(lc_isim VARCHAR2, lc_soyadi VARCHAR2, ld_dogum_tarihi DATE, ln_pasaport_no VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER)
        RETURN VARCHAR2 IS
        l_text VARCHAR2(2000) := NULL;
    BEGIN
        FOR cur_rec
            IN (SELECT musteri_no, isim, soyadi,
                       dogum_tarihi
                  FROM CBS.cbs_musteri
                 WHERE musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(isim) = UPPER(lc_isim) AND UPPER(soyadi) = UPPER(lc_soyadi)
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(isim) = UPPER(lc_isim) AND dogum_tarihi = ld_dogum_tarihi
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(soyadi) = UPPER(lc_soyadi) AND dogum_tarihi = ld_dogum_tarihi
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(isim) = UPPER(lc_isim) AND pasaport_no = ln_pasaport_no
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND UPPER(soyadi) = UPPER(lc_soyadi) AND pasaport_no = ln_pasaport_no
                    OR musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND dogum_tarihi = ld_dogum_tarihi AND pasaport_no = ln_pasaport_no) 
        LOOP
            l_text := l_text || ', ' || cur_rec.musteri_no || ' ' || cur_rec.isim || ' ' || cur_rec.soyadi || ' ' || cur_rec.dogum_tarihi;
        END LOOP;

        RETURN LTRIM(l_text, ', ');
    END;

    -----------------2--------------------

    FUNCTION sf_get_musteri_no_2(ln_okpo_code VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER)
        RETURN VARCHAR2 IS
        l_text VARCHAR2(2000) := NULL;
    BEGIN
        FOR cur_rec IN (SELECT musteri_no, ticari_unvan
                          FROM CBS.cbs_musteri
                         WHERE musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod AND okpo_code = ln_okpo_code) 
        LOOP
            l_text := l_text || ', ' || cur_rec.musteri_no || ' ' || cur_rec.ticari_unvan;
        END LOOP;

        RETURN LTRIM(l_text, ', ');
    END;

    -----------------3--------------------

    FUNCTION sf_get_musteri_no_3(lc_ticari_unvan VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER)
        RETURN VARCHAR2 IS
        l_text VARCHAR2(2000) := NULL;
        diff   NUMBER := 0;
    BEGIN
        FOR cur_rec
            IN (SELECT musteri_no, ticari_unvan
                  FROM CBS.cbs_musteri
                 WHERE musteri_tipi_kod = ln_musteri_tipi_kod
                   AND dk_grup_kod = ln_dk_grup_kod
                   AND UTL_MATCH.edit_distance(ticari_unvan, lc_ticari_unvan) <> -1
                   AND LENGTH(lc_ticari_unvan) - UTL_MATCH.edit_distance(ticari_unvan, lc_ticari_unvan) > (LENGTH(lc_ticari_unvan) * 70) / 100) 
        LOOP
            l_text := l_text || ', ' || cur_rec.musteri_no || ' ' || cur_rec.ticari_unvan;
        END LOOP;

        RETURN LTRIM(l_text, ', ');
    END;

    -----------------4--------------------

    FUNCTION sf_string_matches(lc_ticari_unvan VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER)
        RETURN NUMBER IS
        diff NUMBER := 0;
    BEGIN
        FOR cur_rec IN (SELECT ticari_unvan
                          FROM CBS.cbs_musteri
                         WHERE musteri_tipi_kod = ln_musteri_tipi_kod AND dk_grup_kod = ln_dk_grup_kod) 
        LOOP
            SELECT UTL_MATCH.edit_distance(cur_rec.ticari_unvan, lc_ticari_unvan) INTO diff FROM DUAL;

            IF diff <> -1 AND (LENGTH(lc_ticari_unvan) - diff) > (LENGTH(lc_ticari_unvan) * 70) / 100 THEN
                RETURN 0;
            END IF;
        END LOOP;

        RETURN 1;
    END;
    --EOM begimai CQ6006

    ------------------------------------------------------

    /**
    * Function getTranslit
    * @author Marat Mamatzhanov
    * @version 1.0 (10.04.2021)
    */
    FUNCTION getTranslit(p_text IN VARCHAR2)
        RETURN VARCHAR2 IS
        v_letter VARCHAR2(2);
        v_text   VARCHAR2(2000);
    BEGIN
        FOR i IN 1 .. LENGTH(p_text) LOOP
            BEGIN
                SELECT lat
                  INTO v_letter
                  FROM cbs.cbs_translit
                 WHERE rus = UPPER(SUBSTR(p_text, i, 1));
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    v_letter := SUBSTR(p_text, i, 1);
            END;

            v_text := v_text || UPPER(v_letter);
        END LOOP;

        RETURN v_text;
    END;

    ------------------------------------------------------

    /**
    * Function getCheckTaxId of checking the correct entry of tax number
    * @author Marat Mamatzhanov
    * @version 1.0 (20.04.2021)
    * @param p_customer_type_code Customer Type (1 - Individual, 2 - Private entrepreneur, 3 - Legal entity)
    * @param p_customer_gender Sex Code (M - Male, F - Female)
    * @param p_tax_id Customer tax number we want to check
    * @return Verified tax number
    */
    FUNCTION getCheckTaxId(p_tax_id VARCHAR2, p_customer_type_code VARCHAR2 DEFAULT NULL, p_customer_gender VARCHAR2 DEFAULT NULL)
        RETURN VARCHAR2 IS
        cnt_symbol          NUMBER := LENGTH(p_tax_id);
        tax_id_invalid      EXCEPTION;
        tax_id_type_invalid EXCEPTION;
        errcode             VARCHAR2(5);
    BEGIN
        IF cnt_symbol <> 14 OR TRANSLATE(p_tax_id, '0123465789', '~~~~~~~~~~') != RPAD('~', cnt_symbol, '~') THEN
            RAISE tax_id_invalid;
        END IF;

        IF SUBSTR(p_tax_id, 1, 1) NOT IN ('0', '1', '2', '4', '5', '6') THEN
            errcode := '20113';
            RAISE tax_id_type_invalid;
        END IF;

        IF p_customer_type_code IN ('1', '2') AND SUBSTR(p_tax_id, 1, 1) NOT IN ('1', '2') THEN
            errcode := '20117';
            RAISE tax_id_type_invalid;
        ELSIF p_customer_type_code IN ('3') AND SUBSTR(p_tax_id, 1, 1) NOT IN ('0', '4', '5', '6') THEN
            errcode := '20118';
            RAISE tax_id_type_invalid;
        ELSIF p_customer_type_code IN ('4') AND SUBSTR(p_tax_id, 1, 1) NOT IN ('0', '4') THEN
            errcode := '20138';
            RAISE tax_id_type_invalid;
        END IF;

        IF p_customer_gender IN ('F') AND SUBSTR(p_tax_id, 1, 1) NOT IN ('1') THEN
            errcode := '20119';
            RAISE tax_id_type_invalid;
        ELSIF p_customer_gender IN ('M') AND SUBSTR(p_tax_id, 1, 1) NOT IN ('2') THEN
            errcode := '20120';
            RAISE tax_id_type_invalid;
        END IF;

        RETURN p_tax_id;
    EXCEPTION
        WHEN tax_id_invalid THEN
            raise_application_error(-20112, CBS.PKG_HATA.GETUCPOINTER || '20112' || CBS.PKG_HATA.GETUCPOINTER);
        WHEN tax_id_type_invalid THEN
            IF errcode = '20117' THEN
                raise_application_error(-20117, CBS.PKG_HATA.GETUCPOINTER || '20117' || CBS.PKG_HATA.GETUCPOINTER);
            ELSIF errcode = '20118' THEN
                raise_application_error(-20118, CBS.PKG_HATA.GETUCPOINTER || '20118' || CBS.PKG_HATA.GETUCPOINTER);
            ELSIF errcode = '20113' THEN
                raise_application_error(-20113, CBS.PKG_HATA.GETUCPOINTER || '20113' || CBS.PKG_HATA.GETUCPOINTER);
            ELSIF errcode = '20119' THEN
                raise_application_error(-20119, CBS.PKG_HATA.GETUCPOINTER || '20119' || CBS.PKG_HATA.GETUCPOINTER);
            ELSIF errcode = '20120' THEN
                raise_application_error(-20120, CBS.PKG_HATA.GETUCPOINTER || '20120' || CBS.PKG_HATA.GETUCPOINTER);
            ELSIF errcode = '20138' THEN
                raise_application_error(-20138, CBS.PKG_HATA.GETUCPOINTER || '20138' || CBS.PKG_HATA.GETUCPOINTER);
            END IF;
    END;

    ------------------------------------------------------

    /**
    * Procedure checkDuplicateTaxId for checking duplicate tax number in CBS
    * @author Marat Mamatzhanov
    * @version 1.0 (20.04.2021)
    * @param p_customer_type_code Customer Type (1 - Individual, 2 - Private entrepreneur, 3 - Legal entity)
    * @param p_dk_group_code GL Group Code
    * @param p_tax_id The tax number of the customer we want to check for duplication
    * @throws If an existing customer is found for this tax number, the CBS will throw an exception that such a tax number exists.
    */
    PROCEDURE checkDuplicateTaxId(p_customer_type_code IN VARCHAR2, p_dk_group_code IN NUMBER, p_tax_id IN VARCHAR2, p_yerlesim_kod VARCHAR2) IS --YadgarB CBS-258 added p_yerlesim_kod
        CURSOR c_tax_id  IS
            SELECT vergi_no, musteri_no
              FROM cbs.cbs_musteri
             WHERE musteri_tipi_kod = p_customer_type_code AND yerlesim_kod = p_yerlesim_kod --YadgarB CBS-258
             /*and dk_grup_kod = p_dk_group_code*/ --YadgarB CBS-258 commented group_code filter
               AND vergi_no = p_tax_id;

        res_tax_id     c_tax_id%ROWTYPE;
        tax_id_invalid EXCEPTION;
        ln_customer_no cbs.cbs_musteri.musteri_no%type;
    BEGIN
        OPEN c_tax_id;

        FETCH c_tax_id INTO res_tax_id;

        IF c_tax_id%FOUND THEN
            ln_customer_no := res_tax_id.musteri_no;

            CLOSE c_tax_id;

            RAISE tax_id_invalid;
        END IF;

        CLOSE c_tax_id;
    EXCEPTION
        WHEN tax_id_invalid THEN
            raise_application_error(-20111, CBS.PKG_HATA.GETUCPOINTER || '20111' || CBS.PKG_HATA.GETDELIMITER || ln_customer_no || CBS.PKG_HATA.GETUCPOINTER);
    END;

    ------------------------------------------------------

    /**
    * Procedure checkDuplicateOKPO for checking duplicate OKPO code in CBS
    * @author Marat Mamatzhanov
    * @version 1.0 (20.04.2021)
    * @param p_okpo_code The OKPO code of the customer we want to check for duplication
    * @throws If an existing customer is found for this OKPO code, the CBS will throw an exception that such a code exists.
    */
    PROCEDURE checkDuplicateOKPO(p_okpo_code VARCHAR2, p_musteri_tipi_kod VARCHAR2) IS --YadgarB CBS-258 added p_musteri_tipi_kod
        CURSOR c_okpo  IS
            SELECT musteri_no, okpo_code
              FROM cbs.cbs_musteri
             WHERE okpo_code = p_okpo_code AND musteri_tipi_kod = p_musteri_tipi_kod; --YadgarB CBS-258

        res_okpo              c_okpo%ROWTYPE;
        customer_okpo_invalid EXCEPTION;
    BEGIN
        OPEN c_okpo;

        FETCH c_okpo INTO res_okpo;

        IF c_okpo%FOUND THEN
            CLOSE c_okpo;

            RAISE customer_okpo_invalid;
        END IF;

        CLOSE c_okpo;
    EXCEPTION
        WHEN customer_okpo_invalid THEN
            raise_application_error(-20116, 'A customer ' || res_okpo.musteri_no || ' with this OKPO code ' || res_okpo.okpo_code || ' exists');
    END;

    /**
    * Procedure check_duplicate_corp_nonres
    * @author Marat Mamatzhanov
    * @version 1.0 (15.11.2021)
    */
    PROCEDURE CHECK_DUPLICATE_CORP_NONRES(p_nation_code VARCHAR2, p_company_name VARCHAR2, p_reg_no VARCHAR2 DEFAULT NULL, p_musteri_no NUMBER DEFAULT NULL) IS
        CURSOR c_corp_nonres  IS
              SELECT *
                FROM (SELECT m.musteri_no, m.lokal_unvan name, m.uyruk_kod nation_code,
                             m.vat_seri_no reg_no, UTL_MATCH.jaro_winkler_similarity(m.lokal_unvan, p_company_name) percent
                        FROM cbs.cbs_musteri m
                       WHERE m.musteri_tipi_kod IN (3, 4) AND m.yerlesim_kod = 2 AND m.uyruk_kod = p_nation_code)
               WHERE percent >= 90 OR reg_no = p_reg_no
            ORDER BY percent DESC;

        row_corp_nonres c_corp_nonres%ROWTYPE;
        corp_exists     EXCEPTION;
    BEGIN
        OPEN c_corp_nonres;

        FETCH c_corp_nonres INTO row_corp_nonres;

        IF c_corp_nonres%FOUND THEN
            IF row_corp_nonres.musteri_no <> p_musteri_no OR p_musteri_no IS NULL THEN
                CLOSE c_corp_nonres;

                RAISE corp_exists;
            END IF;
        END IF;

        CLOSE c_corp_nonres;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN corp_exists THEN
            raise_application_error(-20195, 'A customer ' || row_corp_nonres.musteri_no || ' ' || row_corp_nonres.name || ' exists');
    END check_duplicate_corp_nonres;

    ------------------------------------------------------

    /**
    * Function CHECK_DUPLICATE_REG_NO
    * @author Marat Mamatzhanov
    * @version 1.0 (24.01.2022)
    */
    FUNCTION CHECK_DUPLICATE_REG_NO(p_musteri_tipi_kod     VARCHAR2, 
                                    p_vat_seri_no       IN VARCHAR2, 
                                    p_sosyal_fon_no     IN VARCHAR2,
                                    p_old_vat_seri_no      VARCHAR2 DEFAULT NULL, 
                                    p_old_sosyal_fon_no    VARCHAR2 DEFAULT NULL, 
                                    p_yerlesim_kod         VARCHAR2) --YadgarB CBS-258 added p_yerlesim_kod
        RETURN NUMBER IS
        tmpVar NUMBER;
    BEGIN
        SELECT COUNT(*)
          INTO tmpVar
          FROM CBS.CBS_MUSTERI M
         WHERE M.MUSTERI_TIPI_KOD = p_musteri_tipi_kod
           AND (M.SOSYAL_FON_NO IS NOT NULL OR M.VAT_SERI_NO IS NOT NULL)
           --BOM YadgarB CBS-258
           AND M.YERLESIM_KOD = p_yerlesim_kod
           AND ((M.SOSYAL_FON_NO = p_sosyal_fon_no AND (p_sosyal_fon_no <> p_old_sosyal_fon_no OR p_old_sosyal_fon_no IS NULL))
             OR (M.VAT_SERI_NO = p_vat_seri_no AND (p_vat_seri_no <> p_old_vat_seri_no OR p_old_vat_seri_no IS NULL)));

        /*AND (M.SOSYAL_FON_NO = p_sosyal_fon_no OR M.VAT_SERI_NO = p_vat_seri_no)
          AND (M.VAT_SERI_NO <> p_old_vat_seri_no OR M.SOSYAL_FON_NO <> p_old_sosyal_fon_no);
          AND M.VAT_SERI_NO <> p_old_vat_seri_no
          AND M.SOSYAL_FON_NO <> p_old_sosyal_fon_no;*/
        --EOM YadgarB CBS-258
        RETURN tmpVar;
    END CHECK_DUPLICATE_REG_NO;

    ------------------------------------------------------

    FUNCTION getDuplicateCustomer(p_musteri_tipi_kod IN CBS.CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE, 
                                  name               IN CBS.CBS_MUSTERI.isim%TYPE, 
                                  surname            IN CBS.CBS_MUSTERI.soyadi%TYPE, 
                                  birth_day          IN CBS.CBS_MUSTERI.dogum_tarihi%TYPE, 
                                  p_uyruk_kod        IN CBS.CBS_MUSTERI.uyruk_kod%TYPE, 
                                  p_second_name      IN CBS.CBS_MUSTERI.IKINCI_ISIM%TYPE, 
                                  p_sex_code         IN CBS.CBS_MUSTERI.CINSIYET_KOD%TYPE)
        RETURN SYS_REFCURSOR IS
        rf_cur SYS_REFCURSOR;
    BEGIN
        OPEN rf_cur FOR
              SELECT musteri_no customer_id, COUNT(*) cnt
                FROM (SELECT musteri_no
                        FROM cbs.cbs_musteri
                       WHERE isim = UPPER(name) AND durum_kodu = 'A' AND musteri_tipi_kod = p_musteri_tipi_kod
                      UNION ALL
                      SELECT musteri_no
                        FROM cbs.cbs_musteri
                       WHERE soyadi IS NOT NULL AND soyadi = UPPER(surname) AND durum_kodu = 'A' AND musteri_tipi_kod = p_musteri_tipi_kod
                      UNION ALL
                      SELECT musteri_no
                        FROM cbs.cbs_musteri
                       WHERE uyruk_kod IS NOT NULL AND uyruk_kod = p_uyruk_kod AND durum_kodu = 'A' AND musteri_tipi_kod = p_musteri_tipi_kod
                      UNION ALL
                      SELECT musteri_no
                        FROM cbs.cbs_musteri
                       WHERE IKINCI_ISIM IS NOT NULL AND IKINCI_ISIM = p_second_name AND durum_kodu = 'A' AND musteri_tipi_kod = p_musteri_tipi_kod
                      UNION ALL
                      SELECT musteri_no
                        FROM cbs.cbs_musteri
                       WHERE CINSIYET_KOD IS NOT NULL AND CINSIYET_KOD = p_sex_code AND durum_kodu = 'A' AND musteri_tipi_kod = p_musteri_tipi_kod
                      UNION ALL
                      SELECT musteri_no
                        FROM cbs.cbs_musteri
                       WHERE dogum_tarihi = birth_day AND durum_kodu = 'A' AND musteri_tipi_kod = p_musteri_tipi_kod)
            GROUP BY musteri_no
              HAVING COUNT(*) > 1
            ORDER BY cnt DESC;

        RETURN rf_cur;
    END;

    ----------------------------------------------------------------------

    PROCEDURE checkDuplicateCustomer(p_musteri_tipi_kod IN CBS.CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE, 
                                     p_name             IN CBS.CBS_MUSTERI.isim%TYPE, 
                                     surname            IN CBS.CBS_MUSTERI.SOYADI%TYPE, 
                                     birth_day          IN CBS.CBS_MUSTERI.DOGUM_TARIHI%TYPE, 
                                     p_uyruk_kod        IN CBS.CBS_MUSTERI.UYRUK_KOD%TYPE, 
                                     p_second_name      IN CBS.CBS_MUSTERI.IKINCI_ISIM%TYPE DEFAULT NULL, 
                                     p_sex_code         IN CBS.CBS_MUSTERI.CINSIYET_KOD%TYPE DEFAULT NULL, 
                                     p_musteri_no NUMBER DEFAULT NULL) IS
        rf_cur               SYS_REFCURSOR;
        customer_id          cbs.cbs_musteri.musteri_no%TYPE;
        cnt                  NUMBER;
        customer_bul         VARCHAR2(2000);
        customer_duplicate_3 EXCEPTION;
        customer_duplicate_6 EXCEPTION;
        customer_duplicate_2 EXCEPTION;
    BEGIN
        rf_cur := getDuplicateCustomer(p_musteri_tipi_kod, p_name, surname, birth_day, p_uyruk_kod, p_second_name, p_sex_code);

        LOOP
            FETCH rf_cur INTO customer_id, cnt;

            EXIT WHEN rf_cur%NOTFOUND;
            CONTINUE WHEN customer_id = p_musteri_no;

            /*IF cnt = 2 AND p_musteri_no IS NULL THEN
                customer_bul := customer_bul || customer_id || ', ';
            END IF;*/

            IF p_second_name IS NOT NULL THEN
                IF cnt > 2 AND cnt < 6 THEN
                    RAISE customer_duplicate_3;
                ELSIF cnt > 5 THEN
                    RAISE customer_duplicate_6;
                END IF;
            ELSE
                IF cnt > 2 AND cnt < 4 THEN
                    RAISE customer_duplicate_3;
                ELSIF cnt > 4 THEN
                    RAISE customer_duplicate_6;
                END IF;
            END IF;
        END LOOP;

        IF customer_bul IS NOT NULL THEN
            RAISE customer_duplicate_2;
        END IF;
    EXCEPTION
        WHEN customer_duplicate_3 THEN
            RAISE_APPLICATION_ERROR(-20114, 'Please note: the customer with such data is exists under the customer type: ' || p_musteri_tipi_kod || ', Customer no: ' || customer_id || '. ' || cnt || ' mathes');
        WHEN customer_duplicate_6 THEN
            RAISE_APPLICATION_ERROR(-20115, 'Please note: the customer with such data is exists under the customer type: ' || p_musteri_tipi_kod || ', Customer no: ' || customer_id || '. ' || cnt || ' mathes');
        --when customer_duplicate_2 then raise_application_error(-20115, 'Two matches of customer data. (Customer No: ' || customer_bul || ')');
        WHEN customer_duplicate_2 THEN
            NULL;
    END;

    ---------------------------------------------------------------------------------

    /**
    * Function GET_NUMBER_NOT_ZERO_ACCOUNTS - Get the number of non-zero balances of customer accounts
    * @author Marat Mamatzhanov
    * @version 1.0 (01.12.2021)
    * @param p_customer_no
    */
    FUNCTION GET_NUMBER_NOT_ZERO_ACCOUNTS(p_customer_no NUMBER)
        RETURN NUMBER IS
        tmpVar NUMBER;
    BEGIN
        SELECT COUNT(*)
          INTO tmpVar
          FROM CBS.cbs_vw_hesap_izleme
         WHERE musteri_no = p_customer_no AND (bakiye <> 0 OR durum_kodu = 'A');

        RETURN tmpVar;
    END get_number_not_zero_accounts;

    ------------------------------------------

    PROCEDURE issue_date_control(pn_issue_date DATE) IS
        issue_date_error EXCEPTION;
    BEGIN
        IF TRUNC(pn_issue_date) >= TRUNC(SYSDATE) THEN
            RAISE issue_date_error;
        END IF;
    EXCEPTION
        WHEN issue_date_error THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.pkg_hata.getucpointer || '1671' || CBS.pkg_hata.getdelimiter || TO_CHAR(pn_issue_date) || CBS.pkg_hata.getdelimiter || CBS.pkg_hata.getucpointer);
        WHEN OTHERS THEN
            NULL;
    END;

    PROCEDURE validity_date_control(pn_validity_date DATE) IS
        validity_date_error EXCEPTION;
    BEGIN
        IF TRUNC(pn_validity_date) <= TRUNC(SYSDATE) THEN
            RAISE validity_date_error;
        END IF;
    EXCEPTION
        WHEN validity_date_error THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.pkg_hata.getucpointer || '1934' || CBS.pkg_hata.getdelimiter || TO_CHAR(pn_validity_date) || CBS.pkg_hata.getdelimiter || CBS.pkg_hata.getucpointer);
        WHEN OTHERS THEN
            NULL;
    END;

    /*****************************************************************************************************************/
    /*   Function     Sf_Musteri_Adi_FOR_FORMS                                                                       */
    /*  Viktor DBA                                                                                                   */
    /*****************************************************************************************************************/
    FUNCTION SF_MUSTERI_ADI_FOR_FORMS(ps_musteri_tipi_kod CBS.cbs_musteri.musteri_tipi_kod%TYPE, 
                                      ps_isim CBS.cbs_musteri.isim%TYPE, 
                                      ps_ikinci_isim CBS.cbs_musteri.ikinci_isim%TYPE, 
                                      ps_soyadi CBS.cbs_musteri.soyadi%TYPE, 
                                      ps_ticari_unvan VARCHAR2)
        RETURN VARCHAR2 IS
        ls_musteri_adi VARCHAR2(200) := NULL;
        str            VARCHAR(100);
    BEGIN
        ls_musteri_adi := SUBSTR(CASE WHEN ps_musteri_tipi_kod IN ('1', '2') THEN ps_isim || CASE WHEN ' ' || ps_ikinci_isim || ' ' = '  ' THEN ' ' || ps_soyadi ELSE ' ' || ps_ikinci_isim || ' ' || ps_soyadi END ELSE ps_ticari_unvan END, 1, 200);

        RETURN UPPER(TRIM(ls_musteri_adi));
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '111' || CBS.Pkg_Hata.getUCPOINTER);
    END;

    /**
    * Function get_customer_by_taxid - Get customers array by tax id number
    * @author Yadgar Babaev
    * @version 1.0 (20.09.2022)
    * @param p_tax_id
    */
    FUNCTION get_customer_by_taxid(p_tax_id IN CBS.CBS_MUSTERI.VERGI_NO%TYPE) RETURN VARCHAR2 IS
        ls_customers varchar2(2000);
    BEGIN
        select listagg(MUSTERI_NO, ',')
          into ls_customers
          from cbs.cbs_musteri m
         where p_tax_id is not null
           and nvl(m.vergi_no, '') = p_tax_id
        group by vergi_no;

        RETURN ls_customers;
    END;
/*****************************************************************************************************************
    CBS-395 AntonPa 27102022 
    GET NAME OF CIVIL_STATUS, CAPITAL_PARTICIPATION, CONTROL_FORM, ECONOMY SECTOR, PDL BY CODE
*****************************************************************************************************************/
    FUNCTION GET_NAME_BY_CODE(PN_CODE NUMBER, PN_TABLE_NO NUMBER)
    RETURN VARCHAR2 IS
        LS_TABLE_NAME VARCHAR2(30);
        LS_SQL VARCHAR2(200);
        LS_RESULT VARCHAR2(500);
    BEGIN
        LS_TABLE_NAME := CASE PN_TABLE_NO 
            WHEN 1 THEN 'CBS_CIVIL_STATUS_CODES'
            WHEN 2 THEN 'CBS_CAPITAL_PARTICIPATION_CODE'
            WHEN 3 THEN 'CBS_CONTROL_FORM_CODES'
            WHEN 4 THEN 'CBS_PDL_CODES'
            WHEN 5 THEN 'CBS_OPF_ID_CODES'
        END;
        IF LS_TABLE_NAME IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;
        
        LS_SQL := 'SELECT DISTINCT NAME_RUS FROM '|| LS_TABLE_NAME|| ' WHERE CODE = '|| PN_CODE;
        EXECUTE IMMEDIATE LS_SQL INTO LS_RESULT;
        
        RETURN LS_RESULT;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '';
    END;
    
/*****************************************************************************************************************
    CBS-395 AntonPa 27102022 
    GET EXPLANATION AND SUB_EXPLANATION OF ECONOMIC_ACTIVITY BY CODE
*****************************************************************************************************************/
    PROCEDURE GET_ECONOMIC_ACTIVITY_EXPL(PS_CODE VARCHAR2,
                                         PS_EXPL OUT VARCHAR2,
                                         PS_SUB_EXPL OUT VARCHAR2)
    IS
    BEGIN
        SELECT CEAC.EXPLANATION, CEAS.EXPLANATION INTO PS_EXPL, PS_SUB_EXPL
        FROM CBS.CBS_ECONOMIC_ACTIVITY_CODES CEAC
        LEFT JOIN CBS.CBS_ECONOMIC_ACTIVITY_SUBCODES CEAS ON CEAS.SUBCODE = CEAC.SUBCODE
        WHERE CODE = PS_CODE;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            PS_EXPL := '';
            PS_SUB_EXPL := '';
    END;
    
/*****************************************************************************************************************
    CBS-395 AntonPa 27102022 
    PARSE DIGITAL_ADDRESS_CODE
*****************************************************************************************************************/
    PROCEDURE GET_INFO_FROM_DIGITAL_ADDRESS(PS_CODE IN VARCHAR2,
                                            PS_REGION_NAME OUT VARCHAR2,
                                            PS_DISTRICT_NAME OUT VARCHAR2,
                                            PS_SETTLEMENT_NAME OUT VARCHAR2,
                                            PS_VILLAGE_NAME OUT VARCHAR2)
    IS
    BEGIN
        SELECT REGION_NAME,
               DECODE(ADDRESS_TYPE, 'DISTRICT', COALESCE(DISTRICT_NAME, SETTLEMENT_NAME, VILLAGE_NAME), DISTRICT_NAME),
               DECODE(ADDRESS_TYPE, 'SETTLEMENT', NVL(SETTLEMENT_NAME, VILLAGE_NAME), SETTLEMENT_NAME),
               DECODE(ADDRESS_TYPE, 'VILLAGE', VILLAGE_NAME, NULL)
        INTO PS_REGION_NAME, PS_DISTRICT_NAME, PS_SETTLEMENT_NAME, PS_VILLAGE_NAME
        FROM CBS.CBS_DIGITAL_ADDRESS_CODES
        WHERE DIGITAL_CODE = PS_CODE;
    END;


/*****************************************************************************************************************
    CBS-395 AntonPa 27102022 
    GET ACTIVITY_TYPE FROM CODE
*****************************************************************************************************************/
    FUNCTION GET_ACTIVITY_TYPE_BY_CODE(PS_CODE VARCHAR2)
    RETURN VARCHAR2 IS
        LS_RESULT VARCHAR2(500);
    BEGIN 
        SELECT EXPLANATION INTO LS_RESULT 
        FROM CBS_ACTIVITY_TYPES
        WHERE CODE = PS_CODE;
        
        RETURN LS_RESULT;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '';
    END;


/*****************************************************************************************************************
    CBS-395 AntonPa 27102022 
    GET ECONOMY_SECTOR FROM CODE
*****************************************************************************************************************/
    FUNCTION GET_ECONOMY_SECTOR_BY_CODE(PN_GL_GRUP NUMBER, PN_CODE NUMBER)
    RETURN VARCHAR2 IS
        LS_RESULT VARCHAR2(200);
    BEGIN 
        SELECT NAME_RUS INTO LS_RESULT 
        FROM CBS_ECONOMY_SECTORS
        WHERE GL_GROUP_CODE = PN_GL_GRUP AND CODE = PN_CODE;
        
        RETURN LS_RESULT;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '';
    END;

/************************************************************************************************************************
 CBS-395 AntonPa 27102022                                                                             
 LOG OF UPDATED LICENSES 
************************************************************************************************************************/
    PROCEDURE SP_LOG_CUSTOMER_UPD_LICENSES(PS_TABLE_NAME       VARCHAR2, 
                                           P_NEW_ACTIVITY_CODE CBS.CBS_CUSTOMER_LICENSES.ACTIVITY_CODE%TYPE,
                                           P_NEW_LICENSE_NO    CBS.CBS_CUSTOMER_LICENSES.LICENSE_NO%TYPE,
                                           P_NEW_ISSUE_DATE    CBS.CBS_CUSTOMER_LICENSES.ISSUE_DATE%TYPE,
                                           P_NEW_ISSUED_BY     CBS.CBS_CUSTOMER_LICENSES.ISSUED_BY%TYPE,
                                           P_NEW_VALIDITY_DATE CBS.CBS_CUSTOMER_LICENSES.VALIDITY_DATE%TYPE,
                                           P_OLD_ACTIVITY_CODE CBS.CBS_CUSTOMER_LICENSES.ACTIVITY_CODE%TYPE,
                                           P_OLD_LICENSE_NO    CBS.CBS_CUSTOMER_LICENSES.LICENSE_NO%TYPE,
                                           P_OLD_ISSUE_DATE    CBS.CBS_CUSTOMER_LICENSES.ISSUE_DATE%TYPE,
                                           P_OLD_ISSUED_BY     CBS.CBS_CUSTOMER_LICENSES.ISSUED_BY%TYPE,
                                           P_OLD_VALIDITY_DATE CBS.CBS_CUSTOMER_LICENSES.VALIDITY_DATE%TYPE, 
                                           PN_TX_NO            CBS.CBS_MUSTERI_GUNCELLENEN.TX_NO%TYPE) IS
        LS_TABLE_NAME VARCHAR2(100) := PS_TABLE_NAME;
        LS_PARAMETRE  VARCHAR2(100) := P_NEW_LICENSE_NO;
    BEGIN
        IF (P_NEW_ACTIVITY_CODE <> P_OLD_ACTIVITY_CODE ) OR (P_NEW_ACTIVITY_CODE IS NULL AND P_OLD_ACTIVITY_CODE IS NOT NULL ) OR (P_NEW_ACTIVITY_CODE IS NOT NULL AND P_OLD_ACTIVITY_CODE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ACTIVITY_CODE',P_OLD_ACTIVITY_CODE,P_NEW_ACTIVITY_CODE,LS_PARAMETRE); END IF;
        IF (P_NEW_LICENSE_NO <> P_OLD_LICENSE_NO ) OR (P_NEW_LICENSE_NO IS NULL AND P_OLD_LICENSE_NO IS NOT NULL ) OR (P_NEW_LICENSE_NO IS NOT NULL AND P_OLD_LICENSE_NO IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'LICENSE_NO',P_OLD_LICENSE_NO,P_NEW_LICENSE_NO,LS_PARAMETRE); END IF;
        IF (P_NEW_ISSUE_DATE <> P_OLD_ISSUE_DATE ) OR (P_NEW_ISSUE_DATE IS NULL AND P_OLD_ISSUE_DATE IS NOT NULL ) OR (P_NEW_ISSUE_DATE IS NOT NULL AND P_OLD_ISSUE_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ISSUE_DATE',P_OLD_ISSUE_DATE,P_NEW_ISSUE_DATE,LS_PARAMETRE); END IF;
        IF (P_NEW_ISSUED_BY <> P_OLD_ISSUED_BY ) OR (P_NEW_ISSUED_BY IS NULL AND P_OLD_ISSUED_BY IS NOT NULL ) OR (P_NEW_ISSUED_BY IS NOT NULL AND P_OLD_ISSUED_BY IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'ISSUED_BY',P_OLD_ISSUED_BY,P_NEW_ISSUED_BY,LS_PARAMETRE); END IF;
        IF (P_NEW_VALIDITY_DATE <> P_OLD_VALIDITY_DATE ) OR (P_NEW_VALIDITY_DATE IS NULL AND P_OLD_VALIDITY_DATE IS NOT NULL ) OR (P_NEW_VALIDITY_DATE IS NOT NULL AND P_OLD_VALIDITY_DATE IS NULL )  THEN INSERT INTO CBS.CBS_LOG_GUNCELLENEN_ALAN(TX_NO, BLOK_ADI,KULLANICI_KODU, TARIH , ALAN_ADI,ESKI_DEGERI, YENI_DEGERI,PARAMETRE)   VALUES (PN_TX_NO ,LS_TABLE_NAME,USER,SYSDATE,'VALIDITY_DATE',P_OLD_VALIDITY_DATE,P_NEW_VALIDITY_DATE,LS_PARAMETRE); END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,CBS.Pkg_Hata.getUCPOINTER || '104' || CBS.Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || CBS.Pkg_Hata.getDelimiter || SQLERRM || CBS.Pkg_Hata.getUCPOINTER);
    END SP_LOG_CUSTOMER_UPD_LICENSES;

END;
/

