create PACKAGE     Pkg_Tx7041 IS
/******************************************************************************
Name       : Pkg_Tx7041
Created by : Zhypargul Cholponova
Created Date : 16.09.2019
Purpose       : Linking debit cards to credit card ( call BS webservices)
******************************************************************************/
TYPE CursorReferenceType IS REF CURSOR;
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);     -- Islem giris kontrolden gectikten sonra cagrilir

PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);    -- Islem dogrulandiktan sonra cagrilir
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);        -- Islem iptal edildikten sonra cagrilir

PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);        -- Islem onaylandiktan sonra cagrilir
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);    -- Islem reddedildikten sonra cagrilir

PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);        -- Islem tamamlandiktan sonra cagrilir
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);      -- Isleme iliskin formlar basildiktan sonra cagrilir
PROCEDURE Muhasebelesme(pn_islem_no NUMBER);        -- Islemin muhasebelesmesi icin cagrilir

PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);

procedure sp_dbLinkAccountsToCreditCard(pn_islem_no NUMBER) ;

procedure sp_dbUnLinkCreditCardAccounts(pn_islem_no NUMBER ) ;

procedure get_inf(pn_tx_no number,pn_musteri_no number,ps_card_no varchar2,ps_card_id_no varchar2,ps_card_option varchar2,ps_card_type varchar2,pc_ref OUT CursorReferenceType) ;

procedure modify_credit_card_accounts(pn_islem_no number);

END;

/

