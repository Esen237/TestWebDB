create PACKAGE     Pkg_Int_Transfer IS

TYPE CursorReferenceType IS REF CURSOR;

---------------------------------------------------------------------------------------------------------
FUNCTION GetEFTDate(pd_date IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION MakeEFT (
      ps_from_acc                VARCHAR2,
      ps_payee_info              VARCHAR2,
      pd_trandate                VARCHAR2,
      ps_sender_name             VARCHAR2,
      ps_sender_phone            VARCHAR2,
      ps_bank_code               VARCHAR2,
      ps_payee_name              VARCHAR2,
      ps_to_account              VARCHAR2,
      pn_amount                  VARCHAR2,
      ps_description             VARCHAR2,
      ps_save_payee_flag         VARCHAR2,
      ps_payee_nick              VARCHAR2,
      pn_paycode                 VARCHAR2,
      pn_subaccount                 VARCHAR2,
      ps_subname                 VARCHAR2,
      ps_payforservice             VARCHAR2,
      ps_transfer_option            VARCHAR2,
      ps_order_number               VARCHAR2 DEFAULT '',--ernestk 120602014 cqdb864 add order number
      pc_ref               OUT   cursorreferencetype
   )
      RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION EFTInquiry(pn_musterino IN VARCHAR2,
                     pn_sorguno IN VARCHAR2,
                    pd_startdate IN VARCHAR2,
                    pd_enddate     IN VARCHAR2,
                    ps_status     IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION BooktoBookTransfer(pn_fromaccountno IN VARCHAR2,
                             pn_toaccountno IN VARCHAR2,
                            ps_amount IN VARCHAR2,
                            ps_description     IN VARCHAR2,
                            ps_currencycode     IN VARCHAR2,
                            ps_isdekont     IN VARCHAR2,
                            ps_paymentcode     IN       VARCHAR2,
                            ps_order_number IN VARCHAR2 DEFAULT '', --chyngyzo 10122014 cq1264 add order number
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION BooktoBookTransferDecont(pn_txno IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION EFTTimeControl(ps_dummy IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION CheckTime(pd_desc IN VARCHAR2,pd_src IN VARCHAR2) RETURN NUMBER;
---------------------------------------------------------------------------------------------------------
FUNCTION GetEftSaatSinirlari(ps_start OUT VARCHAR2,ps_end OUT VARCHAR2) RETURN NUMBER ;
---------------------------------------------------------------------------------------------------------
--FUNCTION EFTCancel(ps_txno IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION ClearingDekont (pn_txno IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION FxBuyDekont (pn_txno IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION FxSellDekont (pn_txno IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION CheckRNNExternalAccount (pn_bankcode IN VARCHAR2,
                                    pn_externalaccount IN VARCHAR2,
                                 pn_rnn IN VARCHAR2,
                                    pc_ref OUT cursorreferencetype)  RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION MakeUtilityPayment(p_FromAccount IN VARCHAR2,
                             p_SenderName IN VARCHAR2,
                            p_InstitutionCD IN VARCHAR2,
                            p_Description     IN VARCHAR2,
                            p_Amount     IN VARCHAR2,
                            p_AreaCD     IN VARCHAR2,
                            p_PhoneNo     IN       VARCHAR2,
                            p_SubscriptionNo     IN       VARCHAR2,
                            p_InvoiceNo     IN       VARCHAR2,
                            p_KeyNo     IN       VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION CancelClearing(p_TXNO IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------------------
FUNCTION ControlPensionPayment(p_CustomerID IN VARCHAR2,
                                p_strFromAccount IN VARCHAR2,
                                p_strFromRNN IN VARCHAR2,
                               p_str32A_Date IN VARCHAR2,
                               p_str32A_Amount IN VARCHAR2,
                               p_str32A_CAmount IN VARCHAR2,
                               p_strToAccount IN VARCHAR2,
                               p_strToNBAccount IN VARCHAR2,
                               p_strToBranch IN VARCHAR2,
                               p_strToRNN IN VARCHAR2,
                               p_strKNP IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------
FUNCTION TransferToCard(pn_fromaccountno IN VARCHAR2,
                             pn_tocardno IN VARCHAR2,
                            ps_amount IN VARCHAR2,
                            ps_description     IN VARCHAR2,
                            ps_currencycode     IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------

/*******************************************************************************
    Name        : FUNCTION MakeSalaryPayment
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Make Salary Payment
*******************************************************************************/ 
FUNCTION MakeSalaryPayment( ps_todo_txno IN VARCHAR2,
                                                         ps_fromAccNo IN VARCHAR2,
                                                         ps_totalAmount IN VARCHAR2,
                                                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
                                                         
/*******************************************************************************
    Name        : FUNCTION JobMakeSalaryPayment
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Make Salary Payment in Job
*******************************************************************************/    
PROCEDURE JobMakeSalaryPayment(pd_date DATE);                                                        

------------------------------------------------------------------------------------------------------------
FUNCTION SwiftBankInfo ( ps_bankcountry      IN VARCHAR2,
                             ps_bankcity          IN VARCHAR2,
                            ps_bankname          IN VARCHAR2,
                            ps_bankcode              IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
------------------------------------------------------------------------------------------------------------
FUNCTION MAKESwift_old(pd_amount IN VARCHAR2,
                   pd_currency IN VARCHAR2,
                   pd_accountid IN VARCHAR2,
                   ps_ulkekodu IN VARCHAR2,
                   ps_valor_tarihi IN VARCHAR2,
                   ps_aciklama IN VARCHAR2,
                     ps_acilistarihi IN VARCHAR2,
                      ps_swiftbickodu IN VARCHAR2,
                   p_PayeeName IN VARCHAR2,
                   p_PayeeAddress IN VARCHAR2,
                     ps_toAccountNo IN VARCHAR2,
                   ps_muhabirmasraf IN VARCHAR2,
                      ps_bildirimtelno IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2    ;
----------------------------------------------------------------------------------------------------------
FUNCTION GetSwiftDate (pd_startdate VARCHAR2,
                                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------------------
FUNCTION GetSWIFTInquiry(ps_customerid IN VARCHAR2,
                               pd_startdate IN VARCHAR2,
                               pd_enddate IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------------------------
FUNCTION GetBankName(ps_biccode IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------
FUNCTION MakeOrderPayment(pn_from_acc                VARCHAR2,
                            pd_startdate               VARCHAR2,
                            ps_sender_name             VARCHAR2,
                            ps_bank_code               VARCHAR2,
                            ps_payee_name              VARCHAR2,
                            ps_to_account              VARCHAR2,
                            pn_total_amount            VARCHAR2,
                            ps_description             VARCHAR2,
                            ps_senderirsseco           VARCHAR2,
                            pn_rnn                     VARCHAR2,
                            pn_doc_no                  VARCHAR2,
                            pn_income                  VARCHAR2,
                            ps_currency                VARCHAR2,
                            pn_payee_internal_acc      VARCHAR2,
                            pn_payment_code            VARCHAR2,
                            pn_institution_cd          VARCHAR2,
                            pn_area_cd                 VARCHAR2,
                            pn_phone_no                VARCHAR2,
                            ps_tran_type               VARCHAR2,
                            ps_payment_type            VARCHAR2,
                            pn_informing               VARCHAR2,
                            pn_payment_period          VARCHAR2,
                            pn_endofweek               VARCHAR2,
                            pd_end_date                VARCHAR2,
                            pn_payment_no              VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------------------
FUNCTION GetAPSInquiry(ps_customerid IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------------------
FUNCTION GetInstalment(pn_order_id IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------------------
FUNCTION GetAPSInfo(ps_customerid IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------------------
FUNCTION PaymentOrderCancel(ps_txno                    VARCHAR2,
                                pn_orderid                 VARCHAR2,
                              pn_from_acc                VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------------------
FUNCTION GetBranchName(pn_KODU in varchar2) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------------------
FUNCTION GetValueDate(pn_txno in varchar2,
                       pd_trandate in varchar2) RETURN VARCHAR2;
/******************************************************************************
    Name: sendApprovedGrossReport
    Desc: Function to prepare report about the number of approved gross paymetns
          and send to treasury nd payment departments
    Prepared By: Ernest Kuttubaev
    Modify Date: 25.11.2013
*******************************************************************************/
FUNCTION sendApprovedGrossReport(ps_date varchar2) return varchar2;
/******************************************************************************
    Name: notifyBranchAboutGrossFavour
    Desc: Function to prepare email and send to branch directors about customers
           transactoin
    Prepared By: Ernest Kuttubaev
    Modify Date: 25.11.2013
*******************************************************************************/
FUNCTION notifyBranchAboutGrossFavour(
                    ps_customer_id varchar2, 
                    ps_form_acc varchar2, 
                    ps_tran_cd varchar2)
                    return varchar2;
/*******************************************************************************
    Name:   checkIfPaymentIsFavour
    Author: Ernest Kuttubaev
    Modify Date:    26.11.2013
    
    Desc: Check if the customer makes to himself of other bank by payeename and
          if payment is made favour of him send email to branch director
*******************************************************************************/
FUNCTION checkIfPaymentIsFavourMade(    ps_customer_id  IN varchar2,
                                        ps_form_acc     IN varchar2,
                                        ps_tran_cd      IN varchar2,
                                        ps_payeename    IN varchar2) RETURN VARCHAR2;
/*******************************************************************************
    Name        :makeCardDebtPayment
    Prepared By :Ernest Kuttubaev
    Modify Date :24.03.2014
    Pupose      : To make card debt payment
*******************************************************************************/
FUNCTION MakeCardDebtPayment(  ps_personid           VARCHAR2,
                               ps_fromAccount        VARCHAR2,
                               ps_Amount             VARCHAR2,
                               ps_creditCardNo       VARCHAR2,
                               ps_pseudopan         VARCHAR2,
                               pc_ref OUT   cursorreferencetype
                   )
                      RETURN VARCHAR2;
-------------------------------------------------------------------------------
 /******************************************************************************
   NAME        : FUNCTION Make_Swift
   Prepared By : Chyngyz Omurov
   Date        :  02.03.2015, cq509
   Purpose     : Make SWIFT transaction in Corporate IB
******************************************************************************/
FUNCTION Make_Swift(ps_sender_acc_no IN VARCHAR2,
                    ps_country_code IN VARCHAR2,
                    ps_currency IN VARCHAR2,
                    ps_amount IN VARCHAR2,
                    ps_value_date IN VARCHAR2,
                    ps_charge_party IN VARCHAR2, -- who pays charge,  (BEN, OUR, GOUR)
                    ps_stat_code IN VARCHAR2,
                    ps_description IN VARCHAR2,
                    ps_comm_acc_no IN VARCHAR2,
                    ps_charge_amount IN VARCHAR2,
                    ps_ben_acc_no IN VARCHAR2,
                    ps_ben_name IN VARCHAR2,
                    ps_ben_address IN VARCHAR2,
                    ps_ben_swiftcode IN VARCHAR2, --bic code of beneficiary bank
                    ps_ii_bic IN VARCHAR2, --intermediary institution bic code
                    ps_todo_txno VARCHAR2,
                    pc_ref OUT CursorReferenceType,
                    ps_inn_kpp VARCHAR2 DEFAULT NULL --IBC-74 YadgarB
                    ) RETURN VARCHAR2;
 
/******************************************************************************
    Name: sendCibSwiftReport
    Desc: Function to prepare report about the number of swift payments and send to treasury department
    Prepared By:Chyngyz Omurov cq509
    Modify Date: 06.04.2015
******************************************************************************/
FUNCTION sendCibSwiftReport(ps_date in varchar2) RETURN VARCHAR2;                                      
              
/******************************************************************************
    Name: Create_Swift_Transaction
    Desc: Function to create swift transaction. It will be called from CIB, CBS (4005) and EOD
    Prepared By:Chyngyz Omurov cq509
    Modify Date: 06.04.2015
******************************************************************************/
FUNCTION Create_Swift_Transaction(pn_tx_no NUMBER, 
                                                                ps_product_class VARCHAR2, 
                                                                pn_amount NUMBER, 
                                                                ps_branch_no VARCHAR2, 
                                                                ps_currency VARCHAR2, 
                                                                pn_custno NUMBER, 
                                                                pn_accno NUMBER, 
                                                                ps_ben_name VARCHAR2) RETURN VARCHAR2;                              
END;
/

