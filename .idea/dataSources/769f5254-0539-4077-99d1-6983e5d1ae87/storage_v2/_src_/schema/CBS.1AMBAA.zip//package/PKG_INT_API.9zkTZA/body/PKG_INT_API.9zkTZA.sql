create PACKAGE BODY     "PKG_INT_API" IS

/* *********************************************************************************** */
PROCEDURE create_transaction (pn_islem_numara              NUMBER
                            ,pn_islem_kod                 NUMBER
                            ,pc_modul_tur_kod             VARCHAR2
                            ,pc_urun_tur_kod              VARCHAR2
                            ,pc_urun_sinif_kod            VARCHAR2
                            ,pn_tutar                     NUMBER
                            ,pc_amir_bolum_kodu           VARCHAR2   DEFAULT NULL
                            ,pc_bolum_kodu                VARCHAR2   DEFAULT 'INT'
                            ,pc_rol                          VARCHAR2   DEFAULT 7777
                            ,pc_doviz_kod                 VARCHAR2   DEFAULT NULL
                            ,pn_musteri_numara            NUMBER     DEFAULT NULL
                            ,pc_hesap_numara              VARCHAR2   DEFAULT NULL
                            ,pc_kasa_kod                  VARCHAR2   DEFAULT NULL
                            ,pn_KANAL_NUMARA              NUMBER DEFAULT 0
                            ,pc_KAYIT_KULLANICI_KODU      VARCHAR2   DEFAULT 'CINT_CALLER'
                            ) IS
   BEGIN
   log_at('ebilimfortest9.1', pn_islem_numara || pn_islem_kod || pc_modul_tur_kod || pc_urun_tur_kod || pc_urun_sinif_kod || pn_tutar || ' ' || pc_amir_bolum_kodu || ' ' || pc_bolum_kodu || ' ' || pc_rol || pc_doviz_kod || pn_musteri_numara || pc_hesap_numara || pc_kasa_kod || pn_KANAL_NUMARA || pc_KAYIT_KULLANICI_KODU);
     --Pkg_Int_Api.EODControl(NULL);--eod ise islemi yapma
     BEGIN
      -- pkg_baglam.yarat(pc_bolum_kodu,to_number(pc_rol));			 
       INSERT INTO CBS_ISLEM (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                              KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                              KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                              MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                              MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD,KANAL_NUMARA)
                      VALUES (pn_islem_numara,pn_islem_kod,'N',pc_amir_bolum_kodu,
                              pc_KAYIT_KULLANICI_KODU,pc_rol,pc_bolum_kodu,
                              Pkg_Muhasebe.banka_tarihi_bul,SYSDATE,
                              pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod,
                              pn_musteri_numara,pc_hesap_numara,pn_tutar,
                              pc_kasa_kod,pc_doviz_kod,pn_KANAL_NUMARA);

        --gecici islemden geliyorsa gecici islem durumunun set edilmesi gerekli
        --TDL: gecici islem no wait
        log_at('ebilimfortest9.2');
   
        UPDATE CBS_ISLEM_GECICI
           SET durum = 'C'
         WHERE numara=pn_islem_numara;
log_at('ebilimfortest9.3');
--COMMIT;
						  
      EXCEPTION
           WHEN OTHERS THEN
									 
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'60'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
      END;
										
     Pkg_Int_Api.entry_control(pn_islem_numara);
log_at('ebilimfortest9.4');
     --pkg_tx.Harici_Kod_Cagir(pn_islem_numara,'Kontrol_Sonrasi');
END;
/* *********************************************************************************** */
PROCEDURE process_transaction (pn_islem_no IN NUMBER) IS
BEGIN
     /*IF Pkg_Tx.Dogrula_Kontrol(pn_islem_no) THEN
         NULL;
     ELSIF Pkg_Tx.Onay_Kontrol(pn_islem_no) THEN
         NULL;
     ELSE
          Pkg_Tx.Muhasebelestir(pn_islem_no);
     END IF;*/
															
     IF Pkg_Tx.Dogrula_Kontrol(pn_islem_no) THEN         -- dogrulama gerekiyor
								   
	log_at('2401',1,'Dogrula_Kontrol'||' '||pn_islem_no);																 
			 
        BEGIN
	log_at('2401',2);        													 
	   
         Pkg_Tx.dogrula(pn_islem_no,TRUE);
    log_at('2401',3,' Pkg_Tx.dogrula'||' '||pn_islem_no);     
                            -- dogrula
         IF Pkg_Tx.Onay_Kontrol(pn_islem_no) THEN
	log_at('2401',4,'Pkg_Tx.Onay_Kontrol'||' '||pn_islem_no);    																						
											
           Pkg_Tx.onay(pn_islem_no, TRUE );                  --onay gerekiyor o zaman onaylamaya ?al??.
	log_at('2401',5,'Pkg_Tx.Onay'||' '||pn_islem_no);    																			 
         END IF;
																  
         Pkg_Tx.muhasebelestir(pn_islem_no);
	log_at('2401',6,'Pkg_Tx.muhasebelestir'||' '||pn_islem_no);    														  
        END;
     ELSIF Pkg_Tx.Onay_Kontrol(pn_islem_no) THEN     --dogrulama gerekmiyor ama onay gerekiyor
	log_at('2401',6.1);      													  
        BEGIN
																								 
        --log_at('A1->',pn_islem_no);
         Pkg_Tx.onay(pn_islem_no, TRUE );                 --onaylamaya calis
	log_at('2401',7,'Pkg_Tx.onay'||' '||pn_islem_no);     																 
        -- log_at('A2->',pn_islem_no);
           Pkg_Tx.muhasebelestir(pn_islem_no);
     log_at('2401',8,'Pkg_Tx.muhasebelestir'||' '||pn_islem_no);    														  
         --log_at('A3->');
        END;
     ELSE                                                  --ne dogrulama ne onay gerekiyor. sadece muhasebele?tir..
        BEGIN
										  
         Pkg_Tx.muhasebelestir(pn_islem_no);
	log_at('2401',9,'Pkg_Tx.muhasebelestir'||' '||pn_islem_no);     								 
																	
        END;
																   
     END IF;
END;
/***************************************************************************************/
PROCEDURE entry_control(pn_islem_no NUMBER) IS
   lc_dogrulama                VARCHAR2(1);
   lc_onay                     VARCHAR2(1);
   lc_iptal_onay            VARCHAR2(1);
   lc_dogrula_guncelle  VARCHAR2(1);
   lc_onay_guncelle     VARCHAR2(1);
   
   CURSOR c1 IS
    SELECT rui.dogrulama,rui.onay,rui.dogrula_guncelle,rui.onayla_guncelle,rui.iptal_onay
      FROM CBS_ROL_URUN_ISLEM rui,CBS_ISLEM,CBS_ZAMAN,CBS_LIMIT
     WHERE CBS_ISLEM.numara = pn_islem_no
       AND CBS_ISLEM.durum IN ('N')
       AND CBS_ISLEM.islem_kod      = rui.islem_tanim_kod
       AND CBS_ISLEM.modul_tur_kod  = rui.modul_tur_kod
       AND CBS_ISLEM.urun_tur_kod   = rui.urun_tur_kod
       AND CBS_ISLEM.urun_sinif_kod = rui.urun_sinif_kod
       AND rui.rol_numara       = 7777 --pkg_baglam.rol_numara
       AND rui.zaman_numara     = CBS_ZAMAN.numara
           AND TO_NUMBER(TO_CHAR(SYSDATE,'HH24')) BETWEEN baslangic AND bitis
           AND rui.limit_numara = CBS_LIMIT.numara
       AND ( ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'S' AND NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN alt AND ust)  OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'F' AND NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'L' AND NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'F'
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'L'
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.karsilik = 'N' )
             );

   BEGIN
        BEGIN
       OPEN c1;
       LOOP
          FETCH c1 INTO lc_dogrulama,lc_onay,lc_dogrula_guncelle,lc_onay_guncelle,lc_iptal_onay;
          EXIT WHEN c1%NOTFOUND;
          --Kilit_Test(pn_islem_no);
          UPDATE CBS_ISLEM
            SET durum           = 'C' ,
                dogrulanmali_mi = lc_dogrulama,
                onaylanmali_mi  = lc_onay,
                iptal_onaylanmali_mi=lc_iptal_onay,
                dogrula_guncelle = lc_dogrula_guncelle,
                onay_guncelle = lc_onay_guncelle
          WHERE numara=pn_islem_no;
        RETURN;
       END LOOP;
       CLOSE c1;
     EXCEPTION
          WHEN OTHERS THEN
																																								  
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'62'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
     END;
																												  
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'61'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
   END;

/* *********************************************************************************** */
 FUNCTION GetErrorCode(ps_errortext IN VARCHAR2) RETURN VARCHAR2 IS
     ls_errorstr               VARCHAR2(1000);
    ln_errorstart            NUMBER;
    ln_errorend               NUMBER;
    ls_code                   VARCHAR2(10);
    ls_returncode           VARCHAR2(3);
 BEGIN
    ls_errorstr:=ps_errortext; --mutluo SQLERRM;
    ln_errorstart:=INSTR(ls_errorstr,'***');
    ln_errorend:=INSTR(ls_errorstr,'###');
    
    if ln_errorend = 0 then
        ln_errorend :=INSTR(SUBSTR(ls_errorstr,ln_errorstart+3),'***'); 
        ln_errorend := ln_errorend + ln_errorstart + 2;
    end if;
    
    ls_code := SUBSTR(ls_errorstr, ln_errorstart + 3,ln_errorend-ln_errorstart-3);
    
    IF ls_code='1126' THEN
        ls_returncode:='502';
    ELSIF ls_code='441' THEN
        ls_returncode:='502'; -- bakiye yetersiz hatas?
    ELSIF ls_code='1156' THEN -- hesap bulunamad? hatas?
        ls_returncode:='202';
    ELSIF ls_code='1704' THEN -- hesap bulunamad? hatas?
        ls_returncode:='255';
    ELSIF ls_code='1165' THEN -- bloke var hatas?
        ls_returncode:='257';
    ELSIF ls_code='1103' THEN -- onay bekleyen i?lem hatas?
        ls_returncode:='258';
    ELSIF ls_code='1168' THEN -- teminat kay?tl? hatas?
        ls_returncode:='259';
    ELSIF ls_code='1262' THEN -- bakiye bulunamad? hatas?
        ls_returncode:='260';
    ELSIF ls_code='555' THEN -- bakiye bulunamad? hatas?
        ls_returncode:='724'; -- eod hatas?
    ELSIF ls_code='425' THEN -- bakiye bulunamad? hatas?
        ls_returncode:='673'; -- m??teri g?ncellem yap?lamaz.					
    ELSIF TO_NUMBER(NVL(ls_code, 0)) BETWEEN 350 AND 400 THEN --chyngyzo cq5220 Dealer Payments 09.12.2015
        ls_returncode := TO_NUMBER(ls_code) + 450;
    ELSIF ls_code='6670' THEN -- diplicate payment error Nurs Kazbekov ib-169
        ls_returncode:='899';
    ELSIF ls_code='9900' THEN -- EOD Accounting is running, this trx is not allowed.
        ls_returncode:='470';
    ELSE
        ls_returncode:='999';
    END IF;
    RETURN ls_returncode;
 END;
/* *********************************************************************************** */
PROCEDURE draft_entry_control(pn_islem_no NUMBER) IS
   lc_dogrulama                VARCHAR2(1);
   lc_onay                     VARCHAR2(1);
   lc_iptal_onay            VARCHAR2(1);
   lc_dogrula_guncelle  VARCHAR2(1);
   lc_onay_guncelle     VARCHAR2(1);
   CURSOR c1 IS
    SELECT rui.dogrulama,rui.onay,rui.dogrula_guncelle,rui.onayla_guncelle,rui.iptal_onay
      FROM CBS_ROL_URUN_ISLEM rui,CBS_ISLEM_GECICI,CBS_ZAMAN,CBS_LIMIT
     WHERE CBS_ISLEM_GECICI.numara = pn_islem_no
       AND CBS_ISLEM_GECICI.durum IN ('G')
       AND CBS_ISLEM_GECICI.islem_kod      = rui.islem_tanim_kod
       AND CBS_ISLEM_GECICI.modul_tur_kod  = rui.modul_tur_kod
       AND CBS_ISLEM_GECICI.urun_tur_kod   = rui.urun_tur_kod
       AND CBS_ISLEM_GECICI.urun_sinif_kod = rui.urun_sinif_kod
       AND rui.rol_numara       = 7777--pkg_baglam.rol_numara
       AND rui.zaman_numara     = CBS_ZAMAN.numara
           AND TO_NUMBER(TO_CHAR(SYSDATE,'HH24')) BETWEEN baslangic AND bitis
           AND rui.limit_numara = CBS_LIMIT.numara
       AND ( ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'S' AND NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN alt AND ust)  OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'F' AND NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'L' AND NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'F'
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'L'
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.karsilik = 'N' )
             );

   BEGIN
        BEGIN
       OPEN c1;
       LOOP
          FETCH c1 INTO lc_dogrulama,lc_onay,lc_dogrula_guncelle,lc_onay_guncelle,lc_iptal_onay;
          EXIT WHEN c1%NOTFOUND;

          --Kilit_Test(pn_islem_no);

          UPDATE CBS_ISLEM_GECICI
            SET dogrulanmali_mi = lc_dogrulama,
                onaylanmali_mi  = lc_onay,
                iptal_onaylanmali_mi=lc_iptal_onay,
                dogrula_guncelle = lc_dogrula_guncelle,
                onay_guncelle = lc_onay_guncelle
          WHERE numara=pn_islem_no;

        RETURN;
       END LOOP;
       CLOSE c1;
     EXCEPTION
          WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'62'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
     END;
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'61'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
   END;
-----------------------------------------------------------------------------------------
PROCEDURE create_draft_transaction (pn_islem_numara              NUMBER
                            ,pn_islem_kod                 NUMBER
                            ,pc_modul_tur_kod             VARCHAR2
                            ,pc_urun_tur_kod              VARCHAR2
                            ,pc_urun_sinif_kod            VARCHAR2
                            ,pn_tutar                     NUMBER
                            ,pc_amir_bolum_kodu           VARCHAR2   DEFAULT NULL
                            ,pc_bolum_kodu                VARCHAR2   DEFAULT 'INT'
                            ,pc_rol                          VARCHAR2   DEFAULT 2
                            ,pc_doviz_kod                 VARCHAR2   DEFAULT NULL
                            ,pn_musteri_numara            NUMBER     DEFAULT NULL
                            ,pc_hesap_numara              VARCHAR2   DEFAULT NULL
                            ,pc_kasa_kod                  VARCHAR2   DEFAULT NULL
                            ,pn_KANAL_NUMARA              NUMBER DEFAULT 0
                            ) IS
   BEGIN

   Pkg_Int_Api.EODControl(NULL);--eod ise i?lemi yapma

     BEGIN
       INSERT INTO CBS_ISLEM_GECICI (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                              KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                              KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                              MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                              MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD,KANAL_NUMARA)
                      VALUES (pn_islem_numara,pn_islem_kod,'G',pc_amir_bolum_kodu,
                              'CINT_CALLER',pc_rol,pc_bolum_kodu,
                              Pkg_Muhasebe.banka_tarihi_bul,SYSDATE,
                              pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod,
                              pn_musteri_numara,pc_hesap_numara,pn_tutar,pc_kasa_kod,pc_doviz_kod,pn_KANAL_NUMARA);

      EXCEPTION
           WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'60'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
      END;

     draft_entry_control(pn_islem_numara);

END;
-----------------------------------------------------------------------------------------
 PROCEDURE EODControl(dummy IN VARCHAR2) IS
  ls_returncode VARCHAR2(3):='000';
  is_EOD VARCHAR2(1):='H';
  is_SOD VARCHAR2(1):='H';
  is_EOD_ACC VARCHAR2(1):='H';

  -- sistemin eod veya sod olup olmad???n? belirler...
  -- e?er ??le ise hata verir

 BEGIN
    SELECT S.EOD, S.SOD, S.EOD_MUHASEBE
    INTO  is_EOD, is_SOD, is_EOD_ACC
    FROM CBS_SYSTEM S;
    --07.06.2012 Roman Shakirov SDLC00025624   Time deposit closing through IB   
    --WHERE ADI='CBS-PROD';

    IF ((is_EOD='E') OR (is_SOD='E') OR (is_EOD_ACC='E')) THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'555'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
    END IF;

 END;

END;
/

