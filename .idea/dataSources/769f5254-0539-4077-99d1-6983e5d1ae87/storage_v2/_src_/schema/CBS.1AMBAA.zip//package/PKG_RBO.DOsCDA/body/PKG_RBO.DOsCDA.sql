create package body     pkg_rbo
is
    function rbo_4 (p_section in number, 
                    p_subsection number, 
                    pd_date_in in date, 
                    ps_curr in varchar2) 
    return cbs.rbo4_ntt
    is 
        l_ret rbo4_ntt := rbo4_ntt();
        l_condition_nt rbo4_ntt := rbo4_ntt();

        l_condition_sum number;
        l_reverse_condition varchar2(1000);

        procedure free_memory is 
        begin
            l_condition_nt.delete;
            dbms_session.free_unused_user_memory;
        end free_memory;
    begin
        --------------------------------------------------------------Conditions
        for rec in (select *
                      from CBS_RBO4_TABLE_condition
                     where section = p_section 
                       and subsection = p_subsection)
        loop 
            with e_cte as (
                select 
                       trim(regexp_substr(rec.condition, '[^+-]+', 1, level)) gl,
                       case
                         when level > 1 then 
                             decode (regexp_substr(rec.condition, '[+-]+', 1, 
                                     case 
                                       when substr(trim(rec.condition), 1, 1) in ('+', '-') then level
                                       else level - 1 
                                     end ), '-', -1, 1)
                         else 
                           case 
                             when substr(trim(rec.condition), 1, 1) in ('-') then -1
                             else 1 
                           end
                       end sign
                  from dual
               connect by trim(regexp_substr(rec.condition, '[^+-]+', 1, level)) is not null
            )             
            select nvl(sum(d.sign * e.bakiye_lc),0) balance_lc,
                   max(k.rev)
              into l_condition_sum, l_reverse_condition
              from e_cte d, cbs_dkhesap_gunluk_bakiye e, (select listagg( (case when sign=-1 then '+' when sign = 1 then '-' else null end) || gl) within group (order by null) rev from e_cte) k
             where e.numara like nvl(d.gl, 'AAA') || '%'
               and e.yil = to_char(pd_date_in, 'yyyy')
               and e.ay  = to_char(pd_date_in, 'mm')
               and e.gun = to_char(pd_date_in, 'dd') 
               and e.doviz_kod = ps_curr;
            
            if rec.p_option = 'POS' and l_condition_sum < 0 or rec.p_option = 'NEG' and l_condition_sum > 0 --if condition is false
            then 
                l_condition_nt.extend;
                l_condition_nt(l_condition_nt.last) := rbo4_row_ot(rec.id, l_reverse_condition, null, null, null);
            end if;

        end loop;



        --------------------------------------------------calculate sum
        with rbo4_cte as (
            select t.id, 
                   t.name, 
                   t.ref_str || k.reverse_condition ref_str --get reverse_condition if condition is false
              from CBS_RBO4_TABLE t
              left join 
                   (select id,
                           listagg(name) within group (order by null) reverse_condition
                      from table(l_condition_nt) 
                     group by id) k on t.id = k.id 
             where section = p_section 
               and subsection = p_subsection
        )
        , a_cte as (
            select level n
              from dual
           connect by level <= 1000 
        )
        , b_cte as (
            select b.id,
                   b.name, 
                   trim(regexp_substr(b.ref_str, '[^+-]+', 1, n)) gl,
                   case
                     when n > 1 then 
                     regexp_substr(b.ref_str, '[+-]+', 1, 
                                   case 
                                     when substr(trim(b.ref_str), 1, 1) in ('+', '-') then n 
                                     else n - 1 
                                   end ) 
                     else 
                     case 
                       when substr(trim(b.ref_str), 1, 1) in ('-') then '-' 
                       else '+' 
                     end
                   end sign
              from a_cte a, rbo4_cte b
             where trim(regexp_substr(b.ref_str, '[^+-]+', 1, n)) is not null
        )
        , c_cte as (
            select id,
                   name,
                   rtrim(gl,'d') gl,
                   case 
                     when lower(gl) like '%d' then 'ID' 
                     else 'GL'
                   end ref_type,
                   sign
              from b_cte
        )
        , d_cte as (
            select c.*, 
                   connect_by_root(gl) gl_2, 
                   sys_connect_by_path(sign,',') sign_path
              from c_cte c 
           connect by prior to_char(id) = gl and ref_type = 'ID'
             start with ref_type = 'GL'
        )
        , e_cte as (
            select id,
                   name, 
                   gl_2 gl,
                   case 
                       when mod( length(sign_path) - length(replace(sign_path, '-', '')), 2) = 1 then -1
                       else 1
                   end sign
              from d_cte
        )
        select rbo4_row_ot(g.id, g.name, balance_lc, balance_fc,currency)
          bulk collect into l_ret
          from rbo4_cte g
          left join (
             select d.id, 
                    d.name,
                    nvl(sum(d.sign * e.bakiye_lc),0) balance_lc, 
                    nvl(sum(d.sign * e.bakiye),0)    balance_fc ,
                    e.doviz_kod currency
               from e_cte d, cbs_dkhesap_gunluk_bakiye e
              where e.numara like nvl(d.gl, 'AAA') || '%'
                and e.yil = to_char(pd_date_in, 'yyyy')
                and e.ay  = to_char(pd_date_in, 'mm')
                and e.gun = to_char(pd_date_in, 'dd') 
                and e.doviz_kod = ps_curr
              group by d.id, d.name, e.doviz_kod
              order by id, name, currency) h on g.id = h.id and g.name = h.name 
         order by g.id, g.name;

        free_memory;
        return l_ret;
    exception   
        when others then 
            l_ret.delete;
            free_memory;
            raise_application_error(-20100, sqlerrm || '***' || dbms_utility.format_error_backtrace);
    end rbo_4;
  /*  function get_daily_sum (str in varchar, ddate date)
    return number
    is
    sum number;
    begin

    select sum(BAKIYE_LC) into sum from CBS_DKHESAP_GUNLUK_BAKIYE where to_date(yil||ay||gun,'yyyymmdd')=ddate
    and regexp_like(numara,(select to_number(COLUMN_VALUE)
    from table (select apex_string.split(str,',') res
    from dual)));
    return sum;
    end get_daily_sum;*/
    function get_time_deposit_type (pd_vade_date date,pd_bank_date date ) 
    return number
    is 
    res number;
    begin
    if pd_vade_date - pd_bank_date < 365 then  res:=4;
    elsif pd_vade_date - pd_bank_date between 365 and 1094 then res:=5;
    else res:=6;
    end if;
    return res;
    end get_time_deposit_type;
end pkg_rbo;
/

