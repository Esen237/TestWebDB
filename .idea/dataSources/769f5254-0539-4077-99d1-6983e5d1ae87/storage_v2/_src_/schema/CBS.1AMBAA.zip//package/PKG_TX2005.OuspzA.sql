create PACKAGE     "PKG_TX2005" IS

  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54
  -- Purpose : Vadeli Hesap G?ncelleme kullan?lacakt?r.

  PROCEDURE Yaratma_Oncesi(pn_islem_no NUMBER); 		-- Islem giris kontrolden once cagrilir
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		-- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			-- Islem iptal edildikten sonra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);				-- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		-- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			-- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		-- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			-- Islemin muhasebelesmesi icin cagrilir

   PROCEDURE Guncelleme_Kontrolu(pn_islem_no NUMBER,
  								ps_block	VARCHAR2,
								ps_rowid   VARCHAR2,
		  				   		ps_column  	VARCHAR2,
  		   				   		pd_column   VARCHAR2,
								ps_oldvalue IN OUT VARCHAR2); --G?ncellenen alanlar? bulmak i?in

Function renewal_uygun(pn_hesap number,ps_tran_type varchar2) return varchar2;
END Pkg_Tx2005;
/

