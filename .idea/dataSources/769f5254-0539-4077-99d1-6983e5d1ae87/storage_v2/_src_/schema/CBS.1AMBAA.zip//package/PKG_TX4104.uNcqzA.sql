create PACKAGE PKG_TX4104 IS

  /******************************************************************************
   Name       : PKG_TX4103
   Created By : Bilal GUL
   Date	   	  : 28/12/2003
   Purpose	  : TM MUHABIR KOMISYONU ALIS
  ******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Procedure TM_HG_Acilis_Bilgisi_Al(ps_referans CBS_TM_HG_ACILIS.REFERANS%type,
  								    ps_lehdar_musteri_no out CBS_TM_HG_ACILIS.lehdar_musteri_no%type,
								    ps_doviz_kodu out CBS_TM_HG_ACILIS.doviz_kodu%type,
								    ps_mektup_tutari out CBS_TM_HG_ACILIS.tutar%type,
								    ps_278_bakiye out CBS_TM_HG_ACILIS.bakiye%type
								    );
  Procedure Masraf_BilgiAktar(pn_txno number,ps_refno varchar2);

  FUNCTION TxGonderReferansAl(pn_tx_no number) return varchar2;

END;


/

