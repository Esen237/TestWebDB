create PACKAGE     "PKG_KREDI" IS

/******************************************************************************
   Name       : PKG_KREDI
   Created By : Seval Balci
   Date          : 02.10.03
   Purpose      : Genel olarak Kurumsal Kredi islemleri ve bireysel krediler ile ilgili ortak
    procedure ve fonksiyonlar
******************************************************************************/
/*** kredi teklif ile ilgili fonksiyon ve procedurler ***/
 FUNCTION  Sf_Kredi_Teklif_ReferansNo_Al RETURN VARCHAR2 ;
 FUNCTION  Sf_Kredi_Kullandir_Acikla( ps_kullandirim_kodu CBS_KREDI_KULLANDIRIM_KODLARI.kullandirim_kodu%TYPE ) RETURN CBS_BLOKE_NEDEN_KODLARI.aciklama%TYPE;
 FUNCTION  Sf_Kredi_Urun_Doviz_Kodu_LC_mi(pn_kredi_turu_numara CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2;
 FUNCTION  Sf_MusteriTipi_Teklife_Uygun( ps_musteri_tipi CBS_MUSTERI.musteri_tipi_kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION  Sf_kredi_urun_gayri_nakdimi(pn_kredi_turu_numara CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2;
 FUNCTION  Sf_Bitmemis_TeklifIslem_Var_Mi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                             pn_islem_no   CBS_ISLEM.numara%TYPE ,
                                         pn_islem_tanim_kod CBS_ISLEM.islem_kod%TYPE DEFAULT NULL) RETURN NUMBER;
 FUNCTION  Sf_Onayli_Teklifi_VarMi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN NUMBER;
 FUNCTION  Sf_Bekleyen_Kredi_Teklif_No_Al(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE ) RETURN CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE;
 FUNCTION  Sf_Varolan_Teklifden_Uretilmis(pn_teklif_no CBS_KREDI_TEKLIF.teklif_no%TYPE) RETURN NUMBER;
 PROCEDURE Sp_KrediTeklifi_AnaTabloya_At(pn_tx_no CBS_ISLEM.numara%TYPE);
 PROCEDURE Sp_Teklifi_IslemTablosuna_At(pn_islem_tanim_kod NUMBER,pn_eski_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE,
                                            pn_yeni_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE,
                                        ps_yeni_teklif_referans CBS_KREDI_TEKLIF_ISLEM.teklif_referans%TYPE,
                                            pn_yeni_tx_no CBS_ISLEM.numara%TYPE,
                                        pd_yeni_teklif_tarihi CBS_KREDI_TEKLIF_ISLEM.teklif_tarihi%TYPE,
                                        ps_durum_kodu  CBS_KREDI_TEKLIF.durum_kodu%TYPE);

 FUNCTION  Sf_Kredi_Teminat_SiraNo_Al(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE ) RETURN CBS_KREDI_TEMINAT_TANIM.TEMINAT_SIRA_NO%TYPE;
 FUNCTION  Sf_Onceki_Kredi_Teklif_No_Al(pn_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE ) RETURN CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE ;
 FUNCTION  Sf_Islemden_Kredi_Teklif_No_Al(pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE ) RETURN CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE ;
 PROCEDURE Sp_Onceki_Kredi_Teklifi_Kapat(pn_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE) ;
 FUNCTION  Sf_Kredi_Turu_Aciklamasi_Al( pn_kredi_turu_no CBS_URUN_GRUBU.numara%TYPE) RETURN CBS_URUN_GRUBU.tanim%TYPE;
 FUNCTION  Sf_Teminat_Alt_Kod_Aciklamasi(ps_teminat_kodu CBS_TEMINAT_ALT_KODLARI.teminat_kodu%TYPE, ps_teminat_alt_kodu CBS_TEMINAT_ALT_KODLARI.teminat_alt_kodu%TYPE) RETURN CBS_TEMINAT_ALT_KODLARI.aciklama%TYPE;
 PROCEDURE Sp_Aktif_Kredi_Guncel_Getir(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                           ps_teklif_referans IN OUT CBS_KREDI_TEKLIF_ISLEM.TEKLIF_REFERANS%TYPE,
                                       pn_teklif_no     OUT  CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE,
                                       pd_teklif_tarihi OUT  CBS_KREDI_TEKLIF_ISLEM.teklif_tarihi%TYPE);
 FUNCTION sf_kredi_referans_musterino_al(ps_teklif_referans CBS_KREDI_TEKLIF_ISLEM.teklif_referans%TYPE) RETURN CBS_MUSTERI.musteri_no%TYPE;
 PROCEDURE sp_kredi_teklif_guncelle(pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE);
 PROCEDURE sp_teklif_durum_guncelle(pn_teklif_no CBS_KREDI_TEKLIF.teklif_no%TYPE ,ps_yeni_durum_kodu CBS_KREDI_TEKLIF.durum_kodu%TYPE);
 PROCEDURE sp_teklif_gayrinakdilimit_var( pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE,
                                              ps_nakdi_varmi  OUT VARCHAR2,
                                          ps_gayrinakdi_varmi OUT VARCHAR2);
 FUNCTION sf_teklif_durumu_al(pn_kredi_teklif_no CBS_KREDI_TEKLIF.TEKLIF_no%TYPE ) RETURN  VARCHAR2;
 PROCEDURE sp_krediteklif_bilgisi_al(pn_kredi_teklif_no CBS_KREDI_TEKLIF.teklif_no%TYPE ,
                                     ps_modul_tur_kod    OUT CBS_KREDI_TEKLIF.modul_tur_kod%TYPE,
                                    ps_urun_tur_kod        OUT CBS_KREDI_TEKLIF.urun_tur_kod%TYPE,
                                    ps_urun_sinif_kod    OUT CBS_KREDI_TEKLIF.urun_sinif_kod%TYPE,
                                    pn_musteri_no        OUT CBS_KREDI_TEKLIF.musteri_no%TYPE,
                                        ps_teklif_referans    OUT CBS_KREDI_TEKLIF.teklif_referans%TYPE,
                                    pd_teklif_tarihi    OUT CBS_KREDI_TEKLIF.teklif_tarihi%TYPE,
                                    ps_teklif_turu        OUT CBS_KREDI_TEKLIF.teklif_turu%TYPE,
                                    ps_teklif_durumu    OUT CBS_KREDI_TEKLIF.durum_kodu%TYPE);

 FUNCTION sf_islemden_teklifmusteri_al(    pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE) RETURN CBS_MUSTERI.musteri_no%TYPE;
 FUNCTION sf_satirnodan_teklifnoal(pn_teklif_satir_no NUMBER) RETURN NUMBER;
 FUNCTION sf_teklifsatir_bakiyetl( pn_teklif_satir_no NUMBER ) RETURN NUMBER;
 FUNCTION sf_teklifsatir_bakiyeyp(pn_teklif_satir_no NUMBER ) RETURN NUMBER;
 FUNCTION sf_teklifsatir_riskyp(pn_teklif_satir_no NUMBER ) RETURN NUMBER;
 FUNCTION sf_teklifsatir_risktl( pn_teklif_satir_no NUMBER ) RETURN NUMBER;
 /*** Kredi Hesap A??l?? ile ilgili fonksiyon ve procedurler ***/
  PROCEDURE kredi_hesap_ac(  ps_modul_tur VARCHAR2, ps_urun_tur VARCHAR2, ps_urun_sinif VARCHAR2,
                            pn_musteri_no NUMBER, ps_doviz VARCHAR2, ps_sube VARCHAR2, pd_vade DATE,
                            ps_referans VARCHAR2, pn_hesap_no OUT NUMBER ,
                            p_musteri_dk_no        CBS_HESAP_KREDI.MUSTERI_DK_NO%TYPE DEFAULT NULL,
                            p_tutar    CBS_HESAP_KREDI.tutar%TYPE DEFAULT 0,
                            p_extre_masrafi    CBS_HESAP_KREDI.extre_masrafi%TYPE DEFAULT 'H',
                            p_iliskili_hesap_no    CBS_HESAP_KREDI.iliskili_hesap_no%TYPE DEFAULT NULL,
                            p_kredi_teklif_satir_numara    CBS_HESAP_KREDI.kredi_teklif_satir_numara%TYPE DEFAULT NULL,
                            p_kredi_kullandirim_kodu    CBS_HESAP_KREDI.kredi_kullandirim_kodu%TYPE DEFAULT NULL,
                            p_endeks_doviz_kodu    CBS_HESAP_KREDI.endeks_doviz_kodu%TYPE DEFAULT NULL,
                            p_kullandirim_doviz_kodu    CBS_HESAP_KREDI.kullandirim_doviz_kodu%TYPE DEFAULT NULL,
                            p_son_gun_faizi    CBS_HESAP_KREDI.son_gun_faizi%TYPE DEFAULT NULL,
                            p_acilis_kuru    CBS_HESAP_KREDI.acilis_kuru%TYPE DEFAULT NULL,
                            p_faiz_orani    CBS_HESAP_KREDI.faiz_orani%TYPE DEFAULT NULL,
                            p_faiz_siklik    CBS_HESAP_KREDI.faiz_siklik%TYPE DEFAULT NULL,
                            p_faiz_siklik_tipi    CBS_HESAP_KREDI.faiz_siklik_tipi%TYPE DEFAULT NULL,
                            p_faiz_tahakkuk_tarihi    CBS_HESAP_KREDI.faiz_tahakkuk_tarihi%TYPE DEFAULT NULL,
                            p_komisyon_orani    CBS_HESAP_KREDI.komisyon_orani%TYPE DEFAULT NULL,
                            p_komisyon_tutari    CBS_HESAP_KREDI.komisyon_tutari%TYPE DEFAULT NULL,
                            p_komisyon_tahsilat_donemi    CBS_HESAP_KREDI.komisyon_tahsilat_donemi%TYPE DEFAULT NULL,
                            p_fon_orani    CBS_HESAP_KREDI.fon_orani%TYPE DEFAULT NULL,
                            p_bsmv_orani    CBS_HESAP_KREDI.bsmv_orani%TYPE DEFAULT NULL,
                            p_alacak_hesap_no    CBS_HESAP_KREDI.alacak_hesap_no%TYPE DEFAULT NULL,
                            p_kur_farki    CBS_HESAP_KREDI.kur_farki%TYPE DEFAULT NULL,
                            p_sinirlama_kodu    CBS_HESAP_KREDI.sinirlama_kodu%TYPE DEFAULT NULL,
                            p_kaynak_kodu    CBS_HESAP_KREDI.kaynak_kodu%TYPE DEFAULT NULL,
                            p_istatistik_kodu    CBS_HESAP_KREDI.istatistik_kodu%TYPE DEFAULT NULL,
                            p_urun_grup_no    CBS_HESAP_KREDI.urun_grup_no%TYPE DEFAULT NULL,
--                            p_kredi_teklif_no    cbs__kredi.kredi_teklif_no%type default null,
                            p_faiz_tahakkuk_hesap_no    CBS_HESAP_KREDI.faiz_tahakkuk_hesap_no%TYPE DEFAULT NULL,
                            p_vergi_tahakkuk_hesap_no    CBS_HESAP_KREDI.vergi_tahakkuk_hesap_no%TYPE DEFAULT NULL,
                            p_birikmis_faiz_tutari    CBS_HESAP_KREDI.birikmis_faiz_tutari%TYPE DEFAULT 0,
                            p_birikmis_komisyon_tutari    CBS_HESAP_KREDI.birikmis_komisyon_tutari%TYPE DEFAULT 0 ,
                            p_esas_gun_sayisi             CBS_HESAP_KREDI.ESAS_GUN_SAYISI%TYPE DEFAULT 360,
                            p_acilis_tarihi    CBS_HESAP_KREDI.acilis_tarihi%TYPE DEFAULT Pkg_Muhasebe.Banka_Tarihi_Bul,
                            p_endeks_doviz_tutari NUMBER DEFAULT 0,
                            p_sch_faiz_orani NUMBER DEFAULT 0,
                            p_eski_hesap_no NUMBER DEFAULT 0,
                            p_eski_hesap_ekno NUMBER DEFAULT 0,
                            p_eski_faiz_ekno NUMBER DEFAULT 0,
                            p_eski_kom_ekno NUMBER DEFAULT 0,
                            p_odeme_turu        VARCHAR2 DEFAULT NULL,
                            p_taksit_sayisi        NUMBER DEFAULT NULL,
                            p_taksit_once_sonra    VARCHAR2 DEFAULT NULL,
                            p_artis_siklik        NUMBER DEFAULT NULL,
                            p_artis_oran        NUMBER DEFAULT NULL,
                            p_ara_odeme_siklik    NUMBER DEFAULT NULL,
                            p_ara_odeme_tutar        NUMBER DEFAULT NULL,
                            p_donem_siklik        NUMBER DEFAULT NULL,
                            p_kredi_turu        NUMBER DEFAULT NULL,
                            p_sch_faiz_tur VARCHAR2 DEFAULT NULL,
                            p_tahakkuk_sch_faiz_tutari NUMBER DEFAULT 0    ,
                            p_temdit_tarihi               DATE DEFAULT NULL,
                            p_repayment_type                     CBS_HESAP_KREDI.repayment_type%TYPE DEFAULT NULL,
                            p_prefix_istatistik_kodu           CBS_HESAP_KREDI.prefix_istatistik_kodu%TYPE DEFAULT NULL,
                            p_prefix_istatistik_kodu_faiz       CBS_HESAP_KREDI.prefix_istatistik_kodu_faiz%TYPE DEFAULT NULL,
                            p_istatistik_kodu_faiz                CBS_HESAP_KREDI.istatistik_kodu_faiz%TYPE DEFAULT NULL,
                            p_prefix_istatistik_kodu_kapa       CBS_HESAP_KREDI.prefix_istatistik_kodu_kapama%TYPE DEFAULT NULL,
                            p_istatistik_kodu_kapama          CBS_HESAP_KREDI.istatistik_kodu_kapama%TYPE DEFAULT NULL,
                            p_ana_kredi_hesap_no          cbs_hesap_kredi.ana_kredi_hesap_no%type default null,
                            p_pastdue_faiz_anapara_sec          cbs_hesap_kredi.pastdue_faiz_anapara_sec%type default null,
                            p_pastdue_faiz_orani number default null    ,
                            p_yearly_int_rate    number default null,
                            p_alacak_secimi         cbs_hesap_kredi.alacak_secimi%type default null,
                            p_alacak_dk_no         cbs_hesap_kredi.alacak_dk_no%type default null,
                            p_contract_status    cbs_hesap_kredi.contract_status%type default 1,
                            p_gecmis_aylarin_faizi  number default null ,
                            p_gecmis_aylarin_komisyonu number default null,
                            p_taksit_baslangic_tarihi     date default null,
                            p_ek_taksit_faiz             number default null,
                            p_report_cust_type             varchar2 default null,
                            pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE default null,  --chyngyzo 28102014 cqdb614  add app_no
                            p_loan_numara CBS_HESAP_KREDI.LOAN_NUMARA%TYPE default null,--VictorK 17062015
                            p_agreement_date  CBS_HESAP_KREDI.agreement_date%TYPE default null, -- CQ5318 additinal fields KonstantinJ 26052016
                            p_agreement_no  CBS_HESAP_KREDI.agreement_no%TYPE default null, -- CQ5318 additinal fields KonstantinJ 26052016
                            p_transaction_type  CBS_HESAP_KREDI.transaction_type%TYPE default null, -- CQ5935 ViktorT 22032018
                            p_yearly_effective_int_rate  CBS_HESAP_KREDI.yearly_effective_int_rate%TYPE default null, -- CQ5935 ViktorT 22032018
                           -- B-O-M seval.colak 09052021 
                            p_odeme_plan_no             cbs_hesap_kredi.odeme_plan_no%type  default null ,
                            p_odeme_gunu                cbs_hesap_kredi.odeme_gunu%type  default null ,
                            p_taksit_siklik             cbs_hesap_kredi.taksit_siklik%type  default null ,
                            p_odemesiz_ay_sayisi        cbs_hesap_kredi.odemesiz_ay_sayisi%type  default null ,
                            p_faiz_yontemi_methodu      cbs_hesap_kredi.faiz_yontemi_methodu%type  default null ,
                            p_faiz_hesaplama_tipi       cbs_hesap_kredi.faiz_hesaplama_tipi%type  default null ,
                            p_penalty_rate              cbs_hesap_kredi.penalty_rate%type  default null ,
                            -- E-O-M seval.colak 09052021 
                            -- B-O-M seval.colak 29032022
                            p_faiz_orani_tipi            cbs_hesap_kredi.faiz_orani_tipi%type  default null ,
                            p_monthly_int_Rate           cbs_hesap_kredi.monthly_int_Rate%type  default null 
                            -- E-O-M seval.colak 29032022
                            );
 FUNCTION Sf_Alacak_Hesap_Uygunmu(pn_hesap_no CBS_BLOKE_ISLEM.hesap_no%TYPE ) RETURN VARCHAR2;
 FUNCTION Sf_Sinirlandirma_Kodu_Acikla( ps_sinirlama_kodu CBS_SINIRLAMA_KODLARI.sinirlama_kodu%TYPE ) RETURN CBS_SINIRLAMA_KODLARI.aciklama%TYPE;
 FUNCTION Sf_Kaynak_Kodu_Acikla( ps_kaynak_kodu CBS_KAYNAK_KODLARI.kaynak_kodu%TYPE ) RETURN CBS_KAYNAK_KODLARI.aciklama%TYPE;
 FUNCTION sf_faiz_siklik_suresi_tanimla( ps_siklik_kodu CBS_FAIZ_SIKLIK_KODLARI.siklik_kodu%TYPE) RETURN CBS_FAIZ_SIKLIK_KODLARI.aciklama%TYPE;
 FUNCTION sf_kredi_istatistikkod_uygunmu(ps_doviz_kodu CBS_DOVIZ_KODLARI.doviz_kodu%TYPE, ps_istatistik_kodu CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2;
 FUNCTION sf_kredi_dk_bul( pn_musteri_no CBS_MUSTERI.musteri_no%TYPE ,ps_modul_tur_kod  VARCHAR2,ps_urun_tur_kod  VARCHAR2 ,ps_urun_sinif_kod VARCHAR2,pn_gl_index NUMBER default 1) RETURN VARCHAR2;
 PROCEDURE sp_vade_tarihi_uygunmu( pn_teklif_satir_no CBS_KREDI_TEKLIF_SATIR.teklif_satir_no%TYPE, pd_vade_tarihi CBS_HESAP_KREDI.kredi_vade%TYPE) ;
 FUNCTION subemi_genel_mudurluk_mu(ps_bolum_kodu CBS_BOLUM.kodu%TYPE) RETURN VARCHAR2;
 FUNCTION sf_faiz_tahakkuk_tarihi_bul(ps_faiz_siklik_tipi CBS_HESAP_KREDI.FAIZ_SIKLIK_TIPI%TYPE ,
                                         ps_faiz_siklik CBS_HESAP_KREDI.FAIZ_SIKLIK%TYPE ,
                                         pd_faiz_tarihi DATE DEFAULT Pkg_Muhasebe.banka_tarihi_bul,
                                      ps_vade_tarihi DATE DEFAULT Pkg_Muhasebe.banka_tarihi_bul
                                       ) RETURN CBS_HESAP_KREDI.FAIZ_TAHAKKUK_TARIHI%TYPE;
 FUNCTION modul_tur_kod RETURN VARCHAR2;
 PROCEDURE sp_islemden_kredi_hesap_acilis(pn_islem_no NUMBER,pn_hesap_no OUT CBS_HESAP_KREDI.hesap_no%TYPE ,ps_doviz_kodu OUT CBS_HESAP_KREDI.doviz_kodu%TYPE);
 FUNCTION Sf_Bitmemis_HesapIslem_Var_Mi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                           pn_islem_no CBS_ISLEM.numara%TYPE,
                                        pn_teklif_satir_no  CBS_HESAP_KREDI.KREDI_TEKLIF_SATIR_NUMARA%TYPE) RETURN NUMBER;

 FUNCTION sf_dovize_endeksli_kredimi(ps_modul_tur_kod CBS_URUN_SINIF.modul_tur_kod%TYPE,
                                     ps_urun_tur_kod CBS_URUN_SINIF.urun_tur_kod%TYPE,
                                  ps_urun_sinif_kod   CBS_URUN_SINIF.kod%TYPE) RETURN VARCHAR2;
 PROCEDURE sp_kredi_teklif_satir_bakiyeal( pn_teklif_no      NUMBER,
                                               pn_teklif_satir_no NUMBER ,
                                               pn_bakiye_tl OUT NUMBER,
                                           pn_bakiye_yp OUT NUMBER,
                                           ps_doviz_kodu OUT CBS_DOVIZ_KODLARI.doviz_kodu%TYPE,
                                              pn_risk_tl     OUT NUMBER,
                                           pn_risk_yp OUT NUMBER );
 PROCEDURE sp_bakiye_kontrol(
--                                pn_teklif_no      number,
                                pn_teklif_satir_no NUMBER ,
                               pn_tutar NUMBER,
                               ps_doviz_kodu CBS_DOVIZ_KODLARI.doviz_kodu%TYPE,
                            pn_risk_tl OUT NUMBER,
                            pn_risk_yp OUT NUMBER );
--  Procedure sp_teklif_satir_risk_guncelle( pn_islem_no number,ps_islem varchar2 );
/* mevcut kredi teklif satir risk guncellemesi
teklifden yeni giris yapilana kadar korunmasi istendiginden ,guncellenmesi kaldirildi .*/

  PROCEDURE sp_faizvergi_tahakkukhesap_ac (pn_islem_no NUMBER) ;
 /*** Kredi Hesap Guncelleme ile ilgili fonksiyon ve procedurler ***/
  PROCEDURE sp_kredihesap_isleme_at (pn_hesap_no          CBS_HESAP_KREDI.hesap_no%TYPE,
                                     pn_tx_no               CBS_HESAP_KREDI_ISLEM.tx_no%TYPE,
                                     pn_islem_tanim_kod CBS_HESAP_KREDI_ISLEM.islem_tanim_kod%TYPE DEFAULT 1303,
                                     pn_tutar            CBS_HESAP_KREDI_ISLEM.tutar%TYPE DEFAULT NULL,
                                     ps_durum_kodu          CBS_HESAP_KREDI_ISLEM.durum_kodu%TYPE DEFAULT NULL,
                                     ps_GERIODEME_KAPAMA_SECIMI    VARCHAR2 DEFAULT NULL,
                                     ps_plan_degisiklik_secimi    VARCHAR2 DEFAULT NULL,
                                     ps_faiz_indirimi             VARCHAR2 DEFAULT NULL); --seval.colak 25052022
  PROCEDURE sp_kredihesap_bilgisi_al(
                    pn_hesap_no                 CBS_HESAP_KREDI.hesap_no%TYPE,
                    p_musteri_no                 OUT CBS_HESAP_KREDI.musteri_no%TYPE,
                    p_doviz_kodu                 OUT CBS_HESAP_KREDI.doviz_kodu%TYPE,
                    p_tutar                     OUT CBS_HESAP_KREDI.tutar%TYPE,
                    p_durum_kodu                 OUT CBS_HESAP_KREDI.durum_kodu%TYPE,
                    p_sube_kodu                 OUT CBS_HESAP_KREDI.sube_kodu%TYPE,
                    p_musteri_dk_no             OUT CBS_HESAP_KREDI.musteri_dk_no%TYPE,
                    p_urun_tur_kod                 OUT CBS_HESAP_KREDI.urun_tur_kod%TYPE,
                    p_urun_sinif_kod             OUT CBS_HESAP_KREDI.urun_sinif_kod%TYPE,
                    p_modul_tur_kod                OUT CBS_HESAP_KREDI.modul_tur_kod%TYPE,
                    p_kredi_vade                OUT CBS_HESAP_KREDI.kredi_vade%TYPE,
                    p_endeks_doviz_kodu         OUT CBS_HESAP_KREDI.endeks_doviz_kodu%TYPE,
                    p_son_gun_faizi                OUT CBS_HESAP_KREDI.son_gun_faizi%TYPE,
                    p_faiz_orani                 OUT CBS_HESAP_KREDI.faiz_orani%TYPE,
                    p_faiz_siklik                 OUT CBS_HESAP_KREDI.faiz_siklik%TYPE,
                    p_faiz_siklik_tipi             OUT CBS_HESAP_KREDI.faiz_siklik_tipi%TYPE,
                    p_faiz_tahakkuk_tarihi         OUT CBS_HESAP_KREDI.faiz_tahakkuk_tarihi%TYPE,
                    p_komisyon_orani             OUT CBS_HESAP_KREDI.komisyon_orani%TYPE,
                    p_komisyon_tutari             OUT CBS_HESAP_KREDI.komisyon_tutari%TYPE,
                    p_alacak_hesap_no             OUT CBS_HESAP_KREDI.alacak_hesap_no%TYPE,
                    p_iliskili_hesap_no         OUT CBS_HESAP_KREDI.iliskili_hesap_no%TYPE,
                    p_extre_masrafi             OUT CBS_HESAP_KREDI.extre_masrafi%TYPE,
                    p_sinirlama_kodu             OUT CBS_HESAP_KREDI.sinirlama_kodu%TYPE,
                    p_kaynak_kodu                 OUT CBS_HESAP_KREDI.kaynak_kodu%TYPE,
                    p_birikmis_faiz_tutari         OUT CBS_HESAP_KREDI.birikmis_faiz_tutari%TYPE,
                    p_birikmis_komisyon_tutari    OUT CBS_HESAP_KREDI.birikmis_komisyon_tutari%TYPE,
                    p_faiz_tahakkuk_hesap_no     OUT CBS_HESAP_KREDI.faiz_tahakkuk_hesap_no%TYPE,
                    p_vergi_tahakkuk_hesap_no    OUT CBS_HESAP_KREDI.vergi_tahakkuk_hesap_no%TYPE,
                    p_FON_ORANI                    OUT CBS_HESAP_KREDI.FON_ORANI%TYPE,
                    p_BSMV_ORANI                OUT    CBS_HESAP_KREDI.BSMV_ORANI%TYPE,
                    p_ACILIS_KURU                OUT CBS_HESAP_KREDI.ACILIS_KURU%TYPE,
                    p_KUR_FARKI                    OUT CBS_HESAP_KREDI.KUR_FARKI%TYPE,
                    p_ISTATISTIK_KODU            OUT CBS_HESAP_KREDI.ISTATISTIK_KODU%TYPE,
                    p_KREDI_TEKLIF_NO            OUT CBS_KREDI_TEKLIF.TEKLIF_NO%TYPE,
                    p_KOMISYON_TAHSILAT_DONEMI    OUT CBS_HESAP_KREDI.KOMISYON_TAHSILAT_DONEMI%TYPE,
                    p_KREDI_KULLANDIRIM_KODU    OUT CBS_HESAP_KREDI.KREDI_KULLANDIRIM_KODU%TYPE,
                    p_KULLANDIRIM_DOVIZ_KODU    OUT CBS_HESAP_KREDI.KULLANDIRIM_DOVIZ_KODU%TYPE,
                    p_KREDI_TEKLIF_SATIR_NO        OUT CBS_HESAP_KREDI.KREDI_TEKLIF_SATIR_NUMARA%TYPE
                    ) ;
 PROCEDURE sp_kredihesap_bilgisi_guncelle(pn_islem_no NUMBER) ;

 PROCEDURE sf_tahakkuk_dk_tanimlimi(ps_sube_kodu  CBS_HESAP_KREDI.sube_kodu%TYPE,
                                        ps_doviz_kodu  CBS_HESAP_KREDI.doviz_kodu%TYPE,
                                    ps_faiz_dk_numara  OUT CBS_DKHESAP.numara%TYPE,
                                    ps_vergi_dk_numara OUT CBS_DKHESAP.numara%TYPE) ;
 PROCEDURE sp_kredi_hesap_durum_guncelle( pn_hesap_no CBS_HESAP.hesap_no%TYPE,ps_durum_kodu VARCHAR2);

/* procedure sp_hesap_krediteklifno_guncel( pn_eski_teklif_no         cbs_hesap_kredi.kredi_teklif_no%type,
                                              pn_yeni_teklif_no         cbs_hesap_kredi.kredi_teklif_no%type);
 */
 PROCEDURE sp_kredteklifdurumu_uygunmu(pn_islem_no NUMBER );

 FUNCTION Sf_Bitmemis_HesapIslm_VarMi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                           pn_islem_no CBS_ISLEM.numara%TYPE,
                                        pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) RETURN NUMBER;
 FUNCTION Sf_KrediHesap_UrunUygunmu( ps_urun_tur_kod CBS_HESAP_KREDI.urun_tur_kod%TYPE ) RETURN VARCHAR2;
 PROCEDURE Sp_Kredi_Kapama_FaizKomis_Bul( pn_HESAP_no CBS_HESAP_KREDI_ISLEM.hesap_no%TYPE ,
                                              pn_faiz_tutari OUT NUMBER ,
                                          pn_komisyon_tutari OUT NUMBER,
                                          pd_faiz_tarihi DATE  );
 PROCEDURE sp_kkdf_faiz_tutar_hesapla(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
                                             pn_tutar NUMBER,
                                       pn_kur NUMBER DEFAULT 0 ,
                                      pn_kkdf_kredidoviz_tutar OUT NUMBER,
                                      pn_kkdf_tl_tutar OUT NUMBER,
                                      pn_faiz_tl_tutar OUT NUMBER );

 FUNCTION sf_kkdf_hesapla(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,pn_tutar NUMBER, pn_kur NUMBER DEFAULT 0,ps_kredidoviz_tutarli VARCHAR2 DEFAULT NULL) RETURN NUMBER;
 PROCEDURE sp_bsmv_faiz_tutar_hesapla(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
                                             pn_tutar NUMBER,
                                        pn_kur NUMBER DEFAULT 0,
                                      pn_bsmv_kredidoviz_tutar OUT NUMBER,
                                      pn_bsmv_tl_tutar OUT NUMBER,
                                      pn_faiz_tl_tutar OUT NUMBER );
 FUNCTION sf_bsmv_hesapla(pn_hesap_no NUMBER,pn_tutar NUMBER , pn_kur NUMBER DEFAULT 0,ps_kredidoviz_tutarli VARCHAR2 DEFAULT NULL) RETURN NUMBER;
 FUNCTION sf_kkdfbsmv_hesapla(
                               ps_secim VARCHAR2 DEFAULT 'KKDF',
                          ps_doviz_kodu VARCHAR2,
                          pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
                              pn_tutar NUMBER,
                          pn_kur NUMBER ,
                          ps_bol VARCHAR2 DEFAULT 'E',
                          ps_kkdf_alinsin VARCHAR2 DEFAULT 'E',
                          ps_bsmv_alinsin VARCHAR2 DEFAULT 'E'
                           ) RETURN NUMBER;
 FUNCTION Sf_TahsilHesap_UrunUygunmu(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE ) RETURN VARCHAR2;
 FUNCTION sf_Bakiye_Al(pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE ) RETURN CBS_HESAP_BAKIYE.bakiye%TYPE;
 FUNCTION sf_krediteklifno_musterinoal(pn_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE) RETURN CBS_MUSTERI.musteri_no%TYPE;
 FUNCTION sf_kredi_musterinoal(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE) RETURN CBS_HESAP_KREDI.musteri_no%TYPE;

/* toplu teminat giris sorgu asamas?nda kullanilir */
 FUNCTION sf_islemhesapno_al(pn_tx_no NUMBER) RETURN CBS_HESAP.hesap_no%TYPE;
 PROCEDURE sp_hesapbilgi_al(pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE,
                                ps_modul_tur_kod  OUT CBS_HESAP_KREDI.modul_tur_kod%TYPE,
                                ps_urun_tur_kod   OUT CBS_HESAP_KREDI.urun_tur_kod%TYPE,
                                ps_urun_sinif_kod OUT CBS_HESAP_KREDI.urun_sinif_kod%TYPE,
                                pn_musteri_no       OUT CBS_HESAP_KREDI.musteri_no%TYPE,
                            ps_hesap_sube       OUT CBS_HESAP_KREDI.sube_kodu%TYPE,
                            ps_hesap_doviz       OUT CBS_HESAP_KREDI.doviz_kodu%TYPE,
                            pn_kredi_teklif_satir_no OUT CBS_HESAP_KREDI.kredi_teklif_satir_numara%TYPE,
                            pn_kredi_teklif_no     OUT CBS_KREDI_TEKLIF.teklif_no%TYPE        );

 FUNCTION sf_musteriden_teklifnoal(pn_musteri_no NUMBER) RETURN NUMBER;
 FUNCTION sf_tutarkuryuvarla(pn_tutar NUMBER, ps_doviz VARCHAR2) RETURN NUMBER ;
 PROCEDURE sp_faizkom_dk_tanimlimi(pn_islem_no NUMBER) ;
 FUNCTION sf_endeks_doviz_kodu_al(pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE) RETURN VARCHAR2;
 FUNCTION sf_endeks_doviz_bakiye_al(pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE) RETURN NUMBER;
 FUNCTION sf_kredi_hesap_durumu_al(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE ) RETURN  VARCHAR2;
 FUNCTION sf_kredi_faiztahak_tarih(ps_modul_tur_kod VARCHAR2, ps_urun_tur_kod VARCHAR2,ps_urun_sinif_kod VARCHAR2) RETURN VARCHAR2;
 FUNCTION sf_kredikapamaistatkod_uygunmu(ps_doviz_kodu CBS_DOVIZ_KODLARI.doviz_kodu%TYPE, ps_istatistik_kodu CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2;

 /* kazakistan ilave*/
 FUNCTION sf_vade_tarih_al(pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) RETURN DATE;
 PROCEDURE sp_vade_tarihi_guncelle(pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE ,pd_kredi_vade  CBS_HESAP_KREDI.kredi_vade%TYPE );
 FUNCTION sf_hesap_taksit_maxno_al(pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) RETURN NUMBER;
 PROCEDURE sp_taksit_sira_guncelle(pn_islem_no NUMBER);
 PROCEDURE sp_taksit_vade_tutar_kontrol(pn_islem_no NUMBER ,pn_tutar  NUMBER DEFAULT NULL);
 PROCEDURE sp_onayonce_taksit_sakla(    pn_tx_no               CBS_HESAP_KREDI_ISLEM.tx_no%TYPE,
                                           pn_hesap_no          CBS_HESAP_KREDI.hesap_no%TYPE);
 FUNCTION sf_islemvarsa_uyar(pn_islem_no NUMBER,
                                 pn_hesap_no NUMBER ,
                              pn_islem_kod NUMBER DEFAULT NULL) RETURN NUMBER;

 PROCEDURE  sp_hesap_kapanabilir_mi( pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) ;
 FUNCTION sf_islem_taksit_maxno_al(pn_islem_no NUMBER ) RETURN NUMBER;
 Procedure sf_pastdue_kredi_hesap_ac(pn_kredi_hesap_no number,
                                         pn_iliskili_hesap_no number,
                                     pn_yaratan_islem_no    number,
                                     pn_yeni_islem_no    number ,
                                        pn_tutar number,
                                     ps_faiz_anapara varchar2 default 'FAIZ',
                                     pn_pastdue_hesap_no out number,
                                     pn_fis_no out number,
                                     ps_fis_kesilsin varchar2 default 'E')     ;

 PROCEDURE sp_pastdue_dk_tanimlimi(pn_islem_no NUMBER) ;
 FUNCTION sf_acilis_vade_tarih_al(pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) RETURN DATE;
 procedure sp_taksit_geriodeme_tutarayni(pn_islem_no number ,pn_tutar number);
 FUNCTION  sf_dk_uygunmu(ps_dkno VARCHAR2) RETURN VARCHAR2;
 FUNCTION sf_tarih_arasi_kredtak_varmi(pn_hesap_no number, pd_tarih1 date, pd_tarih2 date) return varchar;
 FUNCTION sf_teklif_bolum_kodu_al(pn_musteri_no NUMBER) RETURN varchar2;
 FUNCTION sf_accrued_interest_tax_amt(pn_hesap_no NUMBER) RETURN number;
 FUNCTION sf_accrued_commision_tax_amt(pn_hesap_no NUMBER) RETURN number;
 FUNCTION sf_get_Customer_AppNo(pn_musteri_no NUMBER, pn_kredi_teklif_satir_no NUMBER) RETURN NUMBER; --cq614 ErkinZu 25042017   
 PROCEDURE sp_Principal_Pastdue_Closing( pn_pd_account_no number,
                                        pd_value_date date,
                                        ps_collection_currency varchar2,
                                        pn_rate number,
                                        pn_related_account number,
                                        pn_collection_account number,
                                        pn_tahsedil_gecenyilfaiztutar number,
                                        pn_tahsedil_gecmis_aylar_faiz number,
                                        pn_tahsedil_birikmisfaiztutar number,
                                        pn_anapara_tahsilat_tutar number,
                                        ps_aciklama varchar2,
                                        ps_choice varchar2,
                                        ps_durum_kodu varchar2,
                                        ps_pd_branch_cd varchar2,
                                        ps_modul_tur_kod varchar2, 
                                        ps_urun_tur_kod varchar2,
                                        ps_urun_sinif_kod varchar2,
                                        ps_past_due_currency varchar2,
                                        pn_musteri_no number); --aisuluud cq4883 past due closing cbs-119
 PROCEDURE sp_penalty_Pastdue_Closing( ps_cash_account varchar2,
                                        ps_currency_code varchar2,
                                        pn_customer_no number,
                                        ps_residency_code varchar2,
                                        ps_citizen_code varchar2,
                                        ps_customer_type varchar2, 
                                        ps_income_type varchar2, 
                                        pn_related_account number,
                                        pn_amount number,
                                        ps_vat varchar2,
                                        ps_service_tax varchar2,
                                        pn_service_tax_rate number,
                                        ps_tax_coll_type varchar2,
                                        pn_paid_tax_amount number,
                                        pn_total_collection_amount number,
                                        ps_collection_currency varchar2,
                                        pn_rate number,
                                        pn_collection_account number,
                                        ps_income_gl varchar2,
                                        ps_explanation varchar2,
                                        ps_pd_branch_cd varchar2,
                                        ps_modul_tur_kod varchar2,
                                        ps_urun_tur_kod varchar2,
                                        ps_urun_sinif_kod varchar2,
                                        pn_current_account number); --aisuluud cq4883 - CBS-119 past due closing                                        
 PROCEDURE sp_convert_for_pd_closing_arb(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number, pn_alis_tutari out number);--aisuluud cq4883 - CBS-119 past due closing
 PROCEDURE sp_transfer_for_pd_closing(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number, pn_alis_tutari out number);--aisuluud cq4883 - CBS-119 past due closing
 FUNCTION arbitraj_kur( ps_account_currency varchar2, 
                            ps_past_due_currency varchar2, 
                            pn_available_amount number, 
                            ps_account_branch varchar2, 
                            pb_buy_loan_currency boolean default false,
                            pb_bought_amount boolean default false) return number; --aisuluud cq4883 - CBS-119 past due closing-
 PROCEDURE Giris_Kontrol(pn_islem_no number);
 FUNCTION what_month(pd_date date) RETURN varchar2; -- CBS-119 past due closing
 function sf_dk_grup_kod_al ( pn_musteri_no cbs_musteri.musteri_no%type ) return cbs_musteri.dk_grup_kod%type; -- seval.colak 09052021
 FUNCTION SF_FAIZ_TAHAKKUK_HESAP_NO_AL(pn_hesap_no  NUMBER) RETURN NUMBER;
 FUNCTION SF_VERGI_TAHAKKUK_HESAP_NO_AL(pn_hesap_no  NUMBER) RETURN NUMBER; 
 --B-o-m seval.colak 05102022
  procedure sp_hesap_iptaloncetaksitkntr(pn_islem_no number);  
  Function sf_iptal_edilebilirmi(pn_islem_no number ,pn_hesap_no number) return number;
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);
 --E-o-m seval.colak 05102022
 END;
/

