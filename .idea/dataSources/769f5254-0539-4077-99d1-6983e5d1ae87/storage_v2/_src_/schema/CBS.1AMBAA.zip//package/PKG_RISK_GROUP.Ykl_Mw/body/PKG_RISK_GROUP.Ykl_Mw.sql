create PACKAGE BODY     PKG_RISK_GROUP IS

FUNCTION  Sf_risk_group_name( ps_grup_kodu CBS_RISK_GROUP_CODES.grup_kodu%TYPE) RETURN VARCHAR2
  IS
    ls_grup_adi      CBS_RISK_GROUP_CODES.aciklama%TYPE;
  BEGIN
      SELECT aciklama
    INTO   ls_grup_adi
    FROM   CBS_RISK_GROUP_CODES
    WHERE  grup_kodu =ps_grup_kodu  ;

    RETURN ls_grup_adi ;

  EXCEPTION
      WHEN OTHERS THEN
        --RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '169' || Pkg_Hata.getUCPOINTER);
        return null;
  END;

FUNCTION SF_SECTOR_CODE_EXPLANATION(PN_SECTOR_CODE CBS_FINANS_KODLARI.FINANS_KODU%TYPE) RETURN CBS_FINANS_KODLARI.ACIKLAMA%TYPE IS

    ls_explanation cbs_finans_kodlari.aciklama%type;
    
BEGIN
    select aciklama
    into ls_explanation
    from CBS_FINANS_KODLARI
    where FINANS_KODU = PN_SECTOR_CODE;
    
    return ls_explanation;
    
    EXCEPTION 
    WHEN OTHERS THEN
    RETURN NULL;
    
END;

FUNCTION  sf_GROUP_CODE_EXISTS(ps_group_code VARCHAR2) RETURN VARCHAR2 IS
 ln_count NUMBER;
BEGIN

   SELECT COUNT(*)
   INTO   ln_count
   FROM   CBS_RISK_GROUP_CODES
   WHERE  GRUP_KODU = ps_group_code;

log_at('pkg_tx6106_sf_GROUP_CODE_EXISTS_ps_group_code',ps_group_code);
   IF ln_count = 0  THEN 
         RETURN 'H' ;
   ELSE
      RETURN 'E'; --there is already a group with the same code
   END IF;

   EXCEPTION
          WHEN NO_DATA_FOUND THEN
         RETURN 'H';
       WHEN OTHERS THEN
       log_at('pkg_tx6106_sf_GROUP_CODE_EXISTS', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RETURN 'H';
END;  

Procedure Get_Related_Parties(pn_app_no number, pn_tx_no number )  IS

ln_appl_cust_no number;
ln_guarant_retail number;
ln_guarant_company number;

ln_app_no number;
ln_cust_no number;
ls_name varchar2(100);
ls_type varchar2(100);

ln_count number;
ls_app_cust_type varchar2(100);
ls_guarant_retail_type varchar2(100);
ls_guarant_company_type varchar2(100);

ls_appl_cust_name varchar2(100);
ls_guarant_retail_name varchar2(100);
ls_guarant_company_name varchar2(100);
          
   cursor c_app_cust is
             
    select app_no,cust_no, pkg_musteri.Sf_Musteri_Adi(CUST_NO) title,c_type from 
        (select ap.app_no app_no, ap.cust_no cust_no, 'Customer' c_type 
            from cbs_cib_loan_application ap 
            where cust_no in
                (select cust_no from cbs_cib_loan_application where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                union all
                select cust_no from cbs_cib_guarantors_ul where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                union all
                select cust_no from cbs_cib_guarantors where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                )
        union all
        select gu.app_no, gu.cust_no,  'Loan participants - companies' c_type 
            from cbs_cib_guarantors_ul gu 
            where cust_no in
                (select cust_no from cbs_cib_loan_application where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                union all
                select cust_no from cbs_cib_guarantors_ul where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                union all
                select cust_no from cbs_cib_guarantors where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                )
        union all
        select g.app_no, g.cust_no,  
            (select decode(tt.code, '001', '001-Owner of company',
                                '002', '002-Executive of company BOD',
                                '003', '003-Shareholder of company',
                                '004', '004-Guarantor',
                                '007', '007-Founder of company',
                                '010', '010-Manager GM',
                                '012', '012-Pledge giver',
                                '013', '013-Spouse',
                                tt.code
                                || '-'
                                || tt.description) type
            from cbs_cib_dir_guarant_status tt
            where  tt.code = g.status) c_type 
            from cbs_cib_guarantors g 
            where cust_no in
                (select cust_no from cbs_cib_loan_application where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                union all
                select cust_no from cbs_cib_guarantors_ul where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                union all
                select cust_no from cbs_cib_guarantors where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no= pn_app_no))
                ));
    
    r_app_cust            c_app_cust%ROWTYPE; 


begin

delete from cbs_app_rel_parties_tx where tx_no=pn_tx_no;


    OPEN c_app_cust;
    LOOP 
    FETCH c_app_cust INTO r_app_cust;
    EXIT WHEN c_app_cust%NOTFOUND;

        insert into cbs_app_rel_parties_tx (tx_no,main_app_no, app_no, customer_no, c_name, c_type)
        values (pn_tx_no,pn_app_no, r_app_cust.app_no, r_app_cust.cust_no,r_app_cust.title,r_app_cust.c_type  );

    END LOOP;
    CLOSE c_app_cust;   

      
    EXCEPTION
    WHEN OTHERS THEN
      log_at('pkg_risk_groups_Get_Related_Parties', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6914' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);

end;


Procedure Get_Related_Parties_cn(pn_cust_no number, pn_tx_no number )  IS

ln_appl_cust_no number;
ln_guarant_retail number;
ln_guarant_company number;

ln_app_no number;
ln_cust_no number;
ls_name varchar2(100);
ls_type varchar2(100);

ln_count number;
ls_app_cust_type varchar2(100);
ls_guarant_retail_type varchar2(100);
ls_guarant_company_type varchar2(100);

ls_appl_cust_name varchar2(100);
ls_guarant_retail_name varchar2(100);
ls_guarant_company_name varchar2(100);


CURSOR c_app_no IS
    
    select a.app_no app_no from 
        (select a.app_no app_no,a.cust_no cust_no, nvl(a.company_name, a.p_firstname || ' ' || a.p_lastname)  name   
        from CBS_CIB_LOAN_APPLICATION a
        union all
        select g.app_no app_no, G.CUST_NO cust_no, G.FIRSTNAME || ' ' || G.LASTNAME name from CBS_CIB_GUARANTORS g, CBS_CIB_LOAN_APPLICATION ap
        where AP.APP_NO=G.APP_NO 
        union all
        select UL.APP_NO app_no, UL.CUST_NO cust_no, UL.NAME name from CBS_CIB_GUARANTORS_UL ul, CBS_CIB_LOAN_APPLICATION ap
        where AP.APP_NO=UL.APP_NO) a where a.cust_no=pn_cust_no;
        
        r_c_app_no                  c_app_no%ROWTYPE;


CURSOR c0 IS
        
        SELECT app_no,
       app_cust,
       pkg_musteri.Sf_musteri_adi(app_cust) name,
       TYPE
FROM   (SELECT DISTINCT b.app_no,
                        b.app_cust,
                        'Customer' TYPE
        FROM   (SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT s.description
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_appl_cust_no
                          OR G.cust_no = ln_appl_cust_no
                          OR U.cust_no = ln_appl_cust_no )
                       AND a.app_no != r_c_app_no.app_no
                UNION ALL
                SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT s.description
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_guarant_retail
                          OR G.cust_no = ln_guarant_retail
                          OR U.cust_no = ln_guarant_retail )
                       AND a.app_no != r_c_app_no.app_no
                UNION ALL
                SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT s.description
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_guarant_company
                          OR G.cust_no = ln_guarant_company
                          OR U.cust_no = ln_guarant_company )
                       AND a.app_no != r_c_app_no.app_no
                ORDER  BY 1) b
        WHERE  b.app_cust NOT IN ( ln_appl_cust_no, ln_guarant_retail,
                                   ln_guarant_company )
        UNION ALL
        SELECT DISTINCT b.app_no,
                        b.guarantor_rt,
                        (SELECT
        Decode(tt.code, '001', '001-Owner of company',
                        '002', '002-Executive of company BOD',
                        '003', '003-Shareholder of company',
                        '004', '004-Guarantor',
                        '007', '007-Founder of company',
                        '010', '010-Manager GM',
                        '012', '012-Pledge giver',
                        '013', '013-Spouse',
                        tt.code
                        || '-'
                        || tt.description) TYPE
                         FROM   cbs_cib_dir_guarant_status tt
                         WHERE  tt.code = b.status) TYPE
        FROM   (SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT Decode(s.code, '001', '001-Owner of company',
                                              '002',
                               '002-Executive of company BOD',
                                              '003',
                               '003-Shareholder of company',
                                              '004', '004-Guarantor',
                                              '007', '007-Founder of company',
                                              '010', '010-Manager GM',
                                              '012', '012-Pledge giver',
                                              '013', '013-Spouse',
                                              s.code
                                              || '-'
                                              || s.description) TYPE
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_appl_cust_no
                          OR G.cust_no = ln_appl_cust_no
                          OR U.cust_no = ln_appl_cust_no )
                       AND a.app_no != r_c_app_no.app_no
                UNION ALL
                SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT Decode(s.code, '001', '001-Owner of company',
                                              '002',
                               '002-Executive of company BOD',
                                              '003',
                               '003-Shareholder of company',
                                              '004', '004-Guarantor',
                                              '007', '007-Founder of company',
                                              '010', '010-Manager GM',
                                              '012', '012-Pledge giver',
                                              '013', '013-Spouse',
                                              s.code
                                              || '-'
                                              || s.description) TYPE
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_guarant_retail
                          OR G.cust_no = ln_guarant_retail
                          OR U.cust_no = ln_guarant_retail )
                       AND a.app_no != r_c_app_no.app_no
                UNION ALL
                SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT Decode(s.code, '001', '001-Owner of company',
                                              '002',
                               '002-Executive of company BOD',
                                              '003',
                               '003-Shareholder of company',
                                              '004', '004-Guarantor',
                                              '007', '007-Founder of company',
                                              '010', '010-Manager GM',
                                              '012', '012-Pledge giver',
                                              '013', '013-Spouse',
                                              s.code
                                              || '-'
                                              || s.description) TYPE
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_guarant_company
                          OR G.cust_no = ln_guarant_company
                          OR U.cust_no = ln_guarant_company )
                       AND a.app_no != r_c_app_no.app_no
                ORDER  BY 1) b
        WHERE  b.guarantor_rt NOT IN ( ln_appl_cust_no, ln_guarant_retail,
                                       ln_guarant_company )
        UNION ALL
        SELECT DISTINCT b.app_no,
                        b.cmp,
                        'Loan participants - companies' TYPE
        FROM   (SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT s.description
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_appl_cust_no
                          OR G.cust_no = ln_appl_cust_no
                          OR U.cust_no = ln_appl_cust_no )
                       AND a.app_no != r_c_app_no.app_no
                UNION ALL
                SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT s.description
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_guarant_retail
                          OR G.cust_no = ln_guarant_retail
                          OR U.cust_no = ln_guarant_retail )
                       AND a.app_no != r_c_app_no.app_no
                UNION ALL
                SELECT A.app_no,
                       a.cust_no                  app_cust,
                       A.cust_type,
                       G.cust_no                  guarantor_rt,
                       G.status,
                       (SELECT s.description
                        FROM   cbs_cib_dir_guarant_status s
                        WHERE  S.code = G.status) status_desc,
                       U.cust_no                  cmp
                FROM   cbs_cib_loan_application a
                       left join cbs_cib_guarantors g
                              ON A.app_no = G.app_no
                       left join cbs_cib_guarantors_ul u
                              ON A.app_no = U.app_no
                WHERE  ( a.cust_no = ln_guarant_company
                          OR G.cust_no = ln_guarant_company
                          OR U.cust_no = ln_guarant_company )
                       AND a.app_no != r_c_app_no.app_no
                       ) b
        WHERE  b.cmp NOT IN ( ln_appl_cust_no, ln_guarant_retail,
                              ln_guarant_company ))
ORDER  BY 1; 
    r_c0                  c0%ROWTYPE;
    
    CURSOR c1 IS

    select  a.cust_no ln_appl_cust_no, pkg_musteri.Sf_Musteri_Adi(a.cust_no) ls_appl_cust_name 
    from CBS_CIB_LOAN_APPLICATION a   
    where  a.app_no = r_c_app_no.app_no;
    
    r_c1                  c1%ROWTYPE;
    
    CURSOR c2 IS
    
    select G.CUST_NO ln_guarant_retail, pkg_musteri.Sf_Musteri_Adi(G.CUST_NO) ls_guarant_retail_name,(select decode(s.code, '001' ,'001-Owner of company','002','002-Executive of company BOD','003','003-Shareholder of company',
    '004','004-Guarantor','007','007-Founder of company','010','010-Manager GM','012','012-Pledge giver','013','013-Spouse',
    s.code || '-' || s.description) type from CBS_CIB_DIR_GUARANT_STATUS s where S.CODE=G.STATUS  ) ls_guarant_retail_type 
    from CBS_CIB_GUARANTORS g 
    where  g.app_no = r_c_app_no.app_no;
    
    r_c2                  c2%ROWTYPE;
    
    CURSOR c3 IS
    
    select U.CUST_NO ln_guarant_company, pkg_musteri.Sf_Musteri_Adi(U.CUST_NO) ls_guarant_company_name 
    from CBS_CIB_GUARANTORS_UL u
    where u.app_no = r_c_app_no.app_no;
    
    r_c3                  c3%ROWTYPE;
    
    cursor c_app_cust is
             
    select app_no,cust_no, pkg_musteri.Sf_Musteri_Adi(CUST_NO) title,c_type from 
        (select ap.app_no app_no, ap.cust_no cust_no, 'Customer' c_type 
            from cbs_cib_loan_application ap 
            where cust_no in
                (select cust_no from cbs_cib_loan_application where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                union all
                select cust_no from cbs_cib_guarantors_ul where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                union all
                select cust_no from cbs_cib_guarantors where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                )
        union all
        select gu.app_no, gu.cust_no,  'Loan participants - companies' c_type 
            from cbs_cib_guarantors_ul gu 
            where cust_no in
                (select cust_no from cbs_cib_loan_application where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                union all
                select cust_no from cbs_cib_guarantors_ul where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                union all
                select cust_no from cbs_cib_guarantors where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                )
        union all
        select g.app_no, g.cust_no,  
            (select decode(tt.code, '001', '001-Owner of company',
                                '002', '002-Executive of company BOD',
                                '003', '003-Shareholder of company',
                                '004', '004-Guarantor',
                                '007', '007-Founder of company',
                                '010', '010-Manager GM',
                                '012', '012-Pledge giver',
                                '013', '013-Spouse',
                                tt.code
                                || '-'
                                || tt.description) type
            from cbs_cib_dir_guarant_status tt
            where  tt.code = g.status) c_type 
            from cbs_cib_guarantors g 
            where cust_no in
                (select cust_no from cbs_cib_loan_application where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                union all
                select cust_no from cbs_cib_guarantors_ul where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                union all
                select cust_no from cbs_cib_guarantors where app_no in (select distinct app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where cust_no in (select distinct cust_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors) where app_no in (select app_no from (select app_no, cust_no from cbs_cib_loan_application union all select app_no,cust_no from cbs_cib_guarantors_ul union all select app_no,cust_no from cbs_cib_guarantors)where cust_no=pn_cust_no)))
                ));
    
    r_app_cust            c_app_cust%ROWTYPE;

begin

delete from cbs_app_rel_parties_tx where tx_no=pn_tx_no;

open c_app_cust;--get other applications of customer
loop 
fetch c_app_cust into r_app_cust;
exit when c_app_cust%notfound;

--    OPEN C1;--get information of related customers of one application
--    LOOP 
--    FETCH C1 INTO R_C1;
--    EXIT WHEN c1%NOTFOUND;
--
--
--        if R_C1.ln_appl_cust_no is not null then

--            ls_app_cust_type := 'Customer';
            insert into cbs_app_rel_parties_tx (tx_no,main_app_no, app_no, customer_no, c_name, c_type)
            values (pn_tx_no,r_app_cust.app_no, r_app_cust.app_no, r_app_cust.cust_no,r_app_cust.title,r_app_cust.c_type );
--        end if;    


--    END LOOP;
--    CLOSE c1;   
            
            
--    OPEN C2;--get information of related customers of one application
--    LOOP 
--    FETCH C2 INTO R_C2;
--    EXIT WHEN c2%NOTFOUND;
--
--
--        if R_C2.ln_guarant_retail is not null then
--            insert into cbs_app_rel_parties_tx (tx_no,main_app_no, app_no, customer_no, c_name, c_type)
--            values (pn_tx_no,r_c_app_no.app_no, r_c_app_no.app_no, R_C2.ln_guarant_retail,R_C2.ls_guarant_retail_name,R_C2.ls_guarant_retail_type );
--        end if;   
--                
--        /*OPEN C0;
--        LOOP 
--        FETCH C0 INTO R_C0;
--        EXIT WHEN c0%NOTFOUND;
--
--        insert into cbs_app_rel_parties_tx (tx_no,main_app_no, app_no, customer_no, c_name, c_type)
--        values (pn_tx_no,r_c_app_no.app_no, r_c0.app_no, r_c0.app_cust,r_c0.name,r_c0.type );
--
--
--        END LOOP;
--        CLOSE c0;*/
--
--    END LOOP;
--    CLOSE c2;
--            
--    OPEN C3;--get information of related customers of one application
--    LOOP 
--    FETCH C3 INTO R_C3;
--    EXIT WHEN c3%NOTFOUND;
--
--
--        if R_C3.ln_guarant_company is not null then
--
--            ls_guarant_company_type := 'Loan participants - companies';
--            insert into cbs_app_rel_parties_tx (tx_no,main_app_no, app_no, customer_no, c_name, c_type)
--            values (pn_tx_no,r_c_app_no.app_no, r_c_app_no.app_no, R_C3.ln_guarant_company,R_C3.ls_guarant_company_name,ls_guarant_company_type );
--            end if; 
--                
--        /*OPEN C0;
--        LOOP 
--        FETCH C0 INTO R_C0;
--        EXIT WHEN c0%NOTFOUND;
--
--        insert into cbs_app_rel_parties_tx (tx_no,main_app_no, app_no, customer_no, c_name, c_type)
--        values (pn_tx_no,r_c_app_no.app_no, r_c0.app_no, r_c0.app_cust,r_c0.name,r_c0.type );
--
--
--        END LOOP;
--        CLOSE c0;*/
--
--    END LOOP;
--    CLOSE c3;
    
end loop;
close c_app_cust;        
      
    EXCEPTION
    WHEN OTHERS THEN
      log_at('pkg_risk_groups_Get_Related_Parties_cn', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6914' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);

end;

end;
/

