create PACKAGE     PKG_INT_QR_INQ IS
/******************************************************************************
    Name       : PKG_INT_QR_INQ
    Created By : Yadgar Babaev
    Date       : 15/11/2022
    Purpose    : CBS-793: QR STANDARDIZATION / IPC Integration
******************************************************************************/
    TYPE CursorReferenceType IS REF CURSOR;

    FUNCTION CheckQrAccount(ps_customer_id varchar2, ps_source_iban varchar2, ps_currency varchar2, pn_amount number) RETURN varchar2;
    FUNCTION GetQrCustomerType(ps_customer_id varchar2, ps_source_iban varchar2) RETURN varchar2;
    FUNCTION CheckQRBeneficiary(ps_target_iban varchar2, ps_our_qr varchar2) RETURN varchar2;
    FUNCTION GetQRBeneficiary(ps_target_iban varchar2, ps_our_qr varchar2, pc_ref OUT CursorReferenceType) RETURN varchar2;
    FUNCTION GetQrStatus(ps_ipc_transaction_id varchar2 DEFAULT NULL,
                         ps_status varchar2 DEFAULT NULL,
                         ps_direction varchar2 DEFAULT NULL,
                         ps_from_date varchar2 DEFAULT NULL,
                         ps_to_date varchar2 DEFAULT NULL,
                         pc_ref OUT CursorReferenceType) RETURN varchar2;
    FUNCTION MaskQRName(ps_name varchar2) RETURN varchar2;
END;
/

