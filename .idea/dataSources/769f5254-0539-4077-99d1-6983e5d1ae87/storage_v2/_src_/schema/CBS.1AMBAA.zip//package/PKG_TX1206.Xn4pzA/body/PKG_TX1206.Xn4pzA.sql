create PACKAGE BODY PKG_TX1206 IS
	pn_1206_banka_aciklama        number;
	pn_1206_hesap_doviz        number;
	pn_1206_istatistik_kodu        number;
	pn_1206_musteri_aciklama        number;
	pn_1206_hesap_sube        number;
	pn_1206_referans        number;
	pn_1206_hesap_no        number;
	pn_1206_fc_tutar        number;
	pn_1206_kur        number;
	pn_1206_lc_tutar        number;
	pn_1206_valor_tarihi        number;
	pn_1206_fc_TOPLAM        number;
	pn_1206_lc_TOPLAM        number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
     ls_hata varchar2(1);
     hatali_kayit_var exception;
   Begin
     ls_hata := PKG_dosya_islemleri.MAAS_dosya_hatalimi(pn_islem_no);
 	 if ls_hata <> 'H' then
	    raise hatali_kayit_var;
	  end if;
  Exception
    When hatali_kayit_var Then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '992' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
    When others Then
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '995' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
   End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	   null;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
  	   null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
   NULL;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;


 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;
	ls_islem_kod			   cbs_islem.islem_kod%type := '1206';
	ln_fis_no				   cbs_fis.numara%type ;
    ls_aciklama                varchar2(2000);
	ls_musteri_aciklama        varchar2(2000);
	ls_banka_aciklama          varchar2(2000);
	ls_fis_aciklama            varchar2(2000);
	ls_doviz 				   cbs_hesap.doviz_kodu%type;
	ls_sube  				   cbs_hesap.sube_kodu%type;
	ln_internal_no			   number := 0;
	cursor cur_sube is
	  select
		pkg_hesap.hesapsubeal(hesap_no)  sube_kodu,
		pkg_hesap.hesaptandovizkodual(hesap_no) doviz_kodu ,
		sum(abs(nvl(tutar,0))) toplam
	  from cbs_maas_odeme_dosya_detay_isl a
	  where tx_no = pn_islem_no
	  group by pkg_hesap.hesapsubeal(hesap_no) ,
	  		   pkg_hesap.hesaptandovizkodual(hesap_no);

  	cursor cur_hesap is
	  select
	    hesap_no,
		pkg_hesap.hesapsubeal(hesap_no)  sube_kodu,
		pkg_hesap.hesaptandovizkodual(hesap_no) doviz_kodu,
	  	abs(nvl(tutar,0)) tutar
	  from cbs_maas_odeme_dosya_detay_isl a
	  where tx_no = pn_islem_no and
	  		 pkg_hesap.hesapsubeal(hesap_no) = ls_sube and
			 pkg_hesap.hesaptandovizkodual(hesap_no) = ls_doviz	 ;

  Begin

	varchar_list(pn_1206_banka_aciklama) := NULL;
	varchar_list(pn_1206_hesap_doviz) := NULL;
	varchar_list(pn_1206_hesap_no) := NULL;
	varchar_list(pn_1206_hesap_sube) := NULL;
	varchar_list(pn_1206_istatistik_kodu) := NULL;
	varchar_list(pn_1206_musteri_aciklama) := NULL;
	varchar_list(pn_1206_referans) := NULL;
	number_list(pn_1206_fc_toplam):= 0;
	number_list(pn_1206_fc_tutar):= 0;
	number_list(pn_1206_kur):= 0;
	number_list(pn_1206_lc_toplam):= 0;
	number_list(pn_1206_lc_tutar):= 0;
	date_list(pn_1206_valor_tarihi) := PKG_MUHASEBE.BANKA_TARIHI_BUL;

/* islem bilgisi detaylari alinir */

/*********** Liste Deger Atama K?sm? ***********/
  ls_aciklama :=   pkg_genel.ISLEM_ADI_AL(1206) ;
  varchar_list(pn_1206_banka_aciklama) := ls_aciklama ;
  varchar_list(pn_1206_musteri_aciklama) := ls_aciklama;

  for c_sube in cur_sube loop
  	  ls_sube := c_sube.sube_kodu;
	  ls_doviz := c_sube.doviz_kodu;
      number_list(pn_1206_kur) := pkg_kur.doviz_doviz_karsilik( ls_doviz,pkg_genel.lc_al,null,1,1,null,null,'O','A');
      varchar_list(pn_1206_hesap_sube) := ls_sube;
	  varchar_list(pn_1206_hesap_DOVIZ) := ls_doviz;

	  number_list(pn_1206_fc_TOPLAM) :=  C_SUBE.TOPLAM;
	  number_list(pn_1206_Lc_TOPLAM) :=  pkg_kur.doviz_doviz_karsilik( ls_doviz,pkg_genel.lc_al,null,C_SUBE.TOPLAM,1,null,null,'O','A');
	  varchar_list(pn_1206_hesap_doviz) := ls_doviz;
	  ln_fis_no := 0;
	  ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							1,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							ln_fis_no,
							ls_fis_aciklama);
   	  for c_hesap in cur_hesap loop
 	      varchar_list(pn_1206_referans) := TO_CHAR(C_HESAP.HESAP_NO);
	      varchar_list(pn_1206_hesap_no) := C_HESAP.HESAP_NO;
	  	  number_list(pn_1206_fc_tutar) :=  C_hesap.tutar;
	  	  number_list(pn_1206_Lc_tutar) :=  pkg_kur.doviz_doviz_karsilik( ls_doviz,pkg_genel.lc_al,null,C_hesap.tutar,1,null,null,'O','A');

	   	  ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							2,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							ln_fis_no,
							ls_fis_aciklama);

	  end loop;
	  	pkg_muhasebe.muhasebelestir(ln_fis_no);

  end loop;
  ln_internal_no :=pkg_genel.genel_kod_al('MAAS_DOSYA_INTNO');

  insert into cbs_maas_odeme_dosya(internal_no, yaratan_tx_no, banka_tarihi, islem_tanim_kod, durum_kodu, dosya_adi, modul_tur_kod, urun_tur_kod, urun_sinif_kod)
  select ln_internal_no, tx_no, banka_tarihi, islem_tanim_kod,'K', dosya_adi, modul_tur_kod, urun_tur_kod, urun_sinif_kod
  from cbs_maas_odeme_dosya_islem
  where tx_no = pn_islem_no;

  insert into   cbs_maas_odeme_dosya_detay(  internal_no, yaratan_tx_no, dosya_adi, sira_no, banka_tarihi, durum_kodu, hesap_no, doviz_kodu, ad_soyad, tutar, aciklama)
  select ln_internal_no,tx_no, dosya_adi, sira_no, banka_tarihi, durum_kodu, hesap_no, doviz_kodu, ad_soyad, tutar, aciklama
  FROM  cbs_maas_odeme_dosya_detay_isl
  where tx_no = pn_islem_no;

 Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1126' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

 End;

BEGIN
	pn_1206_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1206_BANKA_ACIKLAMA');
	pn_1206_hesap_doviz :=pkg_muhasebe.parametre_index_bul('1206_HESAP_DOVIZ');
	pn_1206_fc_tutar :=pkg_muhasebe.parametre_index_bul('1206_FC_TUTAR');
	pn_1206_fc_TOPLAM :=pkg_muhasebe.parametre_index_bul('1206_FC_TOPLAM');
	pn_1206_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1206_ISTATISTIK_KODU');
	pn_1206_kur :=pkg_muhasebe.parametre_index_bul('1206_KUR');
	pn_1206_lc_tutar :=pkg_muhasebe.parametre_index_bul('1206_LC_TUTAR');
	pn_1206_lc_toplam :=pkg_muhasebe.parametre_index_bul('1206_LC_TOPLAM');
	pn_1206_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1206_MUSTERI_ACIKLAMA');
	pn_1206_hesap_no :=pkg_muhasebe.parametre_index_bul('1206_HESAP_NO');
	pn_1206_hesap_sube :=pkg_muhasebe.parametre_index_bul('1206_HESAP_SUBE');
	pn_1206_referans :=pkg_muhasebe.parametre_index_bul('1206_REFERANS');
	pn_1206_valor_tarihi :=pkg_muhasebe.parametre_index_bul('1206_VALOR_TARIHI');

END ;
/

