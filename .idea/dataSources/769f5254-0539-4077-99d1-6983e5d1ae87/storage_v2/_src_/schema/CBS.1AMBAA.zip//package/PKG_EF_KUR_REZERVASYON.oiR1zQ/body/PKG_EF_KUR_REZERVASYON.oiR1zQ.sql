create PACKAGE BODY     PKG_EF_KUR_REZERVASYON IS

g_uc_delimiter constant varchar2(3):=pkg_hata.getUCPOINTER;
g_ara_delimiter constant varchar2(3):=pkg_hata.getDELIMITER;

Function Rezerve_Kur_Tutar_Uygunmu(pn_rezervasyon_no cbs_ef_kur_rezervasyon.REZERVASYON_NO%type,
 		  							pn_tutar number,
									pn_Alis_Satis varchar,
									pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return boolean is
	ln_rezerve_tutar number;
	ln_kullanilan_tutar number;
	ln_max_tutar number;
	ln_marj number;
	ln_kullanilabilir_tutar number;
	ls_doviz_kodu varchar2(3);
	ln_count    number;
	ls_islem_sekli varchar2(10);
	ln_bought_amount    number;
	ln_sold_amount    number;
begin
	select islem_sekli,nvl(BOUGHT_AMOUNT,0),nvl(SOLD_AMOUNT,0)
	into ls_islem_sekli,ln_bought_amount,ln_sold_amount
	from cbs_ef_kur_rezervasyon
	where  TARIH=pd_TARIH
	and SUBE_KODU=ps_SUBE_KODU
	and rezervasyon_no=pn_rezervasyon_no;

	if ls_islem_sekli <> 'ARBITRAJ'
	then
		select nvl(tutar,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		select doviz_kodu
		into ls_doviz_kodu
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		select count(*)
		into ln_count
		from cbs_ef_kur_rezervasyon_MARJ
		where doviz_kodu=ls_doviz_kodu;

		if ln_count>0
		then
			select nvl(marj,0)
			into ln_marj
			from cbs_ef_kur_rezervasyon_MARJ
			where doviz_kodu=ls_doviz_kodu;
		else
			ln_marj:=0;
		end if;

		ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
		ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;
	else
		select nvl(BOUGHT_AMOUNT,0)+nvl(SOLD_AMOUNT,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		if ln_bought_amount > 0
		then
			select bought_cy
			into ls_doviz_kodu
			from cbs_ef_kur_rezervasyon
			where  TARIH=pd_TARIH
			   and SUBE_KODU=ps_SUBE_KODU
			   and rezervasyon_no=pn_rezervasyon_no;
		end if;
		if ln_sold_amount > 0
		then
			select sold_cy
			into ls_doviz_kodu
			from cbs_ef_kur_rezervasyon
			where  TARIH=pd_TARIH
			   and SUBE_KODU=ps_SUBE_KODU
			   and rezervasyon_no=pn_rezervasyon_no;
		end if;

		select count(*)
		into ln_count
		from cbs_ef_kur_rezervasyon_MARJ
		where doviz_kodu=ls_doviz_kodu;

		if ln_count>0
		then
			select nvl(marj,0)
			into ln_marj
			from cbs_ef_kur_rezervasyon_MARJ
			where doviz_kodu=ls_doviz_kodu;
		else
			ln_marj:=0;
		end if;

		ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
		ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;
	end if;
	if pn_tutar<=ln_kullanilabilir_tutar
	then
		return true;
	else
		return false;
	end if;
end;
-------------------------------------------------------------------------------------
Function Rezervasyon_Kullanim_Orani(pd_tarih cbs_ef_kur_rezervasyon.tarih%type,
 		  							 ps_sube_kodu cbs_ef_kur_rezervasyon.sube_kodu%type,
 		  							 pn_rezervasyon_no cbs_ef_kur_rezervasyon.REZERVASYON_NO%type
 		  					         ) return number is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_max_tutar number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
 ls_Alis_Satis varchar2(10);
 ln_tutar number;
 ln_kullanim_orani number;
 ln_count number;
 ls_islem_sekli  varchar2(10);
begin
	select islem_sekli
	into ls_islem_sekli
	from cbs_ef_kur_rezervasyon
	where  TARIH=pd_TARIH
	and SUBE_KODU=ps_SUBE_KODU
	and rezervasyon_no=pn_rezervasyon_no;

	if ls_islem_sekli <> 'ARBITRAJ'
	then
		select nvl(tutar,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		ln_kullanim_orani:=ROUND(ln_kullanilan_tutar/ln_rezerve_tutar*100,2);

	else -- ARBITRAJ ISE
		select nvl(BOUGHT_AMOUNT,0)+nvl(SOLD_AMOUNT,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		ln_kullanim_orani:=ROUND(ln_kullanilan_tutar/ln_rezerve_tutar*100,2);
	end if;
	return ln_kullanim_orani;
end;

-----------------------------------------------------------------------------------------
 Function Rezervasyon_Bakiye( pn_rezervasyon_no cbs_ef_kur_rezervasyon.REZERVASYON_NO%type,
 		  					  pn_islem_numara cbs_islem.NUMARA%type,
 		  					  pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
							  ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
							 ) return number is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_max_tutar number;
 ln_marj number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
 ls_Alis_Satis varchar2(10);
 ln_tutar number;
 ln_count number;
 ln_kullanim_count    number;
 ls_islem_sekli  varchar2(10);
 ln_bought_amount    number;
 ln_sold_amount    number;
begin
	select islem_sekli,nvl(BOUGHT_AMOUNT,0),nvl(SOLD_AMOUNT,0)
	into ls_islem_sekli,ln_bought_amount,ln_sold_amount
	from cbs_ef_kur_rezervasyon
	where  TARIH=pd_TARIH
	and SUBE_KODU=ps_SUBE_KODU
	and rezervasyon_no=pn_rezervasyon_no;

	if ls_islem_sekli <> 'ARBITRAJ'
	then
		select nvl(tutar,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		select islem_sekli,doviz_kodu,tutar
		into ls_Alis_Satis,ls_doviz_kodu,ln_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		and SUBE_KODU=ps_SUBE_KODU
		and rezervasyon_no=pn_rezervasyon_no;

		select count(*)
		into ln_count
		from cbs_ef_kur_rezervasyon_MARJ
		where doviz_kodu=ls_doviz_kodu;

		if ln_count>0 then
			select nvl(marj,0)
			into ln_marj
			from cbs_ef_kur_rezervasyon_MARJ
			where doviz_kodu=ls_doviz_kodu;
		else
			ln_marj:=0;
		end if;

		ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
		ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;
		ln_kullanim_count:=0;
		ln_kullanilan_tutar:=0;

		select count(*)
		into ln_kullanim_count
		from CBS_EF_KUR_REZERV_KULLANIM
		where TARIH=pd_TARIH
		  and SUBE_KODU=ps_SUBE_KODU
		  and rezervasyon_no=pn_rezervasyon_no
		  and islem_no=pn_islem_numara;

		if ln_kullanim_count>0 then
			select nvl(sum(tutar),0)
			into ln_kullanilan_tutar
			from CBS_EF_KUR_REZERV_KULLANIM
			where TARIH=pd_TARIH
			  and SUBE_KODU=ps_SUBE_KODU
		 	  and rezervasyon_no=pn_rezervasyon_no
			  and islem_no=pn_islem_numara;

			ln_kullanilabilir_tutar:=ln_kullanilabilir_tutar+ln_kullanilan_tutar;
		end if;
	else
		select nvl(BOUGHT_AMOUNT,0)+nvl(SOLD_AMOUNT,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		if ln_bought_amount > 0
		then
			select bought_cy
			into ls_doviz_kodu
			from cbs_ef_kur_rezervasyon
			where  TARIH=pd_TARIH
			   and SUBE_KODU=ps_SUBE_KODU
			   and rezervasyon_no=pn_rezervasyon_no;
		end if;
		if ln_sold_amount > 0
		then
			select sold_cy
			into ls_doviz_kodu
			from cbs_ef_kur_rezervasyon
			where  TARIH=pd_TARIH
			   and SUBE_KODU=ps_SUBE_KODU
			   and rezervasyon_no=pn_rezervasyon_no;
		end if;

		select count(*)
		into ln_count
		from cbs_ef_kur_rezervasyon_MARJ
		where doviz_kodu=ls_doviz_kodu;

		if ln_count>0
		then
			select nvl(marj,0)
			into ln_marj
			from cbs_ef_kur_rezervasyon_MARJ
			where doviz_kodu=ls_doviz_kodu;
		else
			ln_marj:=0;
		end if;

		ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
		ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;
		ln_kullanim_count:=0;
		ln_kullanilan_tutar:=0;

		select count(*)
		into ln_kullanim_count
		from CBS_EF_KUR_REZERV_KULLANIM
		where TARIH=pd_TARIH
		  and SUBE_KODU=ps_SUBE_KODU
		  and rezervasyon_no=pn_rezervasyon_no
		  and islem_no=pn_islem_numara;

		if ln_kullanim_count>0 then
			select nvl(sum(tutar),0)
			into ln_kullanilan_tutar
			from CBS_EF_KUR_REZERV_KULLANIM
			where TARIH=pd_TARIH
			  and SUBE_KODU=ps_SUBE_KODU
		 	  and rezervasyon_no=pn_rezervasyon_no
			  and islem_no=pn_islem_numara;

			ln_kullanilabilir_tutar:=ln_kullanilabilir_tutar+ln_kullanilan_tutar;
		end if;
	end if;

	return ln_kullanilabilir_tutar;
	exception
		when others then
			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '4542' || pkg_hata.getUCPOINTER);
end;
-------------------------------------------------------------------------------------

 Function Rezervasyon_Gercek_Bakiye( pn_rezervasyon_no cbs_ef_kur_rezervasyon.REZERVASYON_NO%type,
                                     ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
 		  					         ) return number is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
 ls_Alis_Satis varchar2(10);
 ls_islem_sekli varchar2(10);
 ln_tutar number;
 pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;

begin
	select islem_sekli
	into ls_islem_sekli
	from cbs_ef_kur_rezervasyon
	where  TARIH=pd_TARIH
	   and SUBE_KODU=ps_SUBE_KODU
	   and rezervasyon_no=pn_rezervasyon_no;

	if ls_islem_sekli <> 'ARBITRAJ'
	then
		select nvl(tutar,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		ln_kullanilabilir_tutar:=nvl(ln_rezerve_tutar,0)-nvl(ln_kullanilan_tutar,0);
	else
		select nvl(BOUGHT_AMOUNT,0)+nvl(SOLD_AMOUNT,0)
		into ln_rezerve_tutar
		from cbs_ef_kur_rezervasyon
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		select nvl(sum(tutar),0)
		into ln_kullanilan_tutar
		from CBS_EF_KUR_REZERV_KULLANIM
		where  TARIH=pd_TARIH
		   and SUBE_KODU=ps_SUBE_KODU
		   and rezervasyon_no=pn_rezervasyon_no;

		ln_kullanilabilir_tutar:=nvl(ln_rezerve_tutar,0)-nvl(ln_kullanilan_tutar,0);
	end if;

   return nvl(ln_kullanilabilir_tutar,0);
end;
--------------------------------------------------------------------------------------
Function Rezervasyon_Efektif_Kur_Al(pn_rezervasyon_no cbs_ef_kur_rezervasyon.REZERVASYON_NO%type,
									pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return number is

 ln_musteri_kuru number;
begin
	select musteri_kuru
	into ln_musteri_kuru
	from cbs_ef_kur_rezervasyon
	where  TARIH=pd_TARIH
	   and SUBE_KODU=ps_SUBE_KODU
	   and rezervasyon_no=pn_rezervasyon_no;

	return ln_musteri_kuru;
end;
--------------------------------------------------------------------------------------
Function Kur_Rezervasyon_Kullanilmismi( pn_rezervasyon_no cbs_ef_kur_rezervasyon.REZERVASYON_NO%type,
                                        pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									    ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return boolean is
	ln_count number;
begin
	select count(*)
	into ln_count
	from CBS_EF_KUR_REZERV_KULLANIM
	where  TARIH=pd_TARIH
  	   and SUBE_KODU=ps_SUBE_KODU
	   and rezervasyon_no=pn_rezervasyon_no;

	if ln_count=0
	then
		return False;
	else
		return True;
	end if;
end;
-----------------------------------------------------------------------------------
 Procedure Rezervasyon_Bilgisi_Al(pn_rezervasyon_no in cbs_ef_kur_rezervasyon.REZERVASYON_NO%type,
                                  pn_musteri_kuru out cbs_ef_kur_rezervasyon.MUSTERI_KURU%type,
								  pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
								  ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
								  ) is

begin
	select musteri_kuru
	into pn_musteri_kuru
	from cbs_ef_kur_rezervasyon
	where  TARIH=pd_TARIH
	   and SUBE_KODU=ps_SUBE_KODU
	   and rezervasyon_no=pn_rezervasyon_no;
 exception
    when others then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2037' ||g_uc_delimiter);

 end;
------------------------------------------------------------------------------------------
 Procedure Rezervasyon_Kullanim_Kaydet(pn_REZERVASYON_NO in number,
                                       pn_islem_numara in number,
									   pn_TUTAR in number,
									   pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									   ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) is
 ln_count number;
begin
	ln_count:=0;

	select count(*)
	into ln_count
	from  CBS_EF_KUR_REZERV_KULLANIM
	where tarih = pd_TARIH
	   and sube_kodu = ps_SUBE_KODU
	   and islem_no=pn_islem_numara;

	if nvl(ln_count,0)>0
	then
		delete from CBS_EF_KUR_REZERV_KULLANIM
		where tarih = pd_TARIH
		and sube_kodu = ps_SUBE_KODU
		and islem_no=pn_islem_numara;
	end if;

	INSERT INTO CBS_EF_KUR_REZERV_KULLANIM(TARIH,SUBE_KODU,REZERVASYON_NO,ISLEM_NO,TUTAR)
	VALUES(pd_TARIH, ps_SUBE_KODU, pn_REZERVASYON_NO, pn_islem_numara, pn_TUTAR);

 exception
    when others then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '4722' ||g_uc_delimiter);
end;
--------------------------------------------------------------------------------------
Procedure Rezervasyon_Kullanim_Iptal(pn_islem_numara in number) is
begin
	delete from CBS_EF_KUR_REZERV_KULLANIM
	where islem_no=pn_islem_numara;

	exception
	when others then
		null;
end;
 -------------------------------------------------------------------------------------
 Function Kur_Marj_Al( ps_doviz_kodu cbs_doviz_kodlari.doviz_kodu%type,ps_Alis_Satis varchar) return number is
 ln_count number;
 ln_kur_marj number;
 begin

   select count(*)
   into ln_count
   from cbs_ef_kur_rezervasyon_MARJ
   where doviz_kodu=ps_doviz_kodu;

   if ln_count>0 then

    select nvl(kur_marj,0)
     into ln_kur_marj
     from cbs_ef_kur_rezervasyon_MARJ
     where doviz_kodu=ps_doviz_kodu;
   else
     ln_kur_marj:=0;
   end if;

    return ln_kur_marj;

 end;
-------------------------------------------------------------------------------
Procedure Kontrol_Sonrasi(pn_tx_no number, ps_Rezervasyon_No number, pn_tutar number) is
ln_bakiye number;
begin

	if ps_Rezervasyon_No is not null then

	   ln_bakiye:=PKG_EF_KUR_Rezervasyon.Rezervasyon_Bakiye( ps_Rezervasyon_No,pn_tx_no);

	   IF pn_tutar >ln_bakiye THEN --Bakiye Yetersiz..
	      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
	   else
	      Pkg_Ef_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(ps_Rezervasyon_No,
	 		    										     pn_tx_no,
	     												     pn_tutar);
	   END IF;

	end if;

end;
-------------------------------------------------------------------
Function Rezervasyon_Tutar_Turu_Al( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
 		  					         pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									 ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
									) return varchar is
 ln_alis_tutar number;
 ln_satis_tutar number;
 ln_tutar		number;
 ls_tutar_tur varchar2(10);
 ls_ISLEM_SEKLI   varchar2(10);
begin
	select TUTAR, BOUGHT_AMOUNT, SOLD_AMOUNT,ISLEM_SEKLI
	into ln_tutar,ln_alis_tutar,ln_satis_tutar,ls_ISLEM_SEKLI
	from CBS_EF_KUR_REZERVASYON
	where  TARIH=pd_TARIH
	   and SUBE_KODU=ps_SUBE_KODU
	   and rezervasyon_no=pn_rezervasyon_no;

	if ls_ISLEM_SEKLI = 'ALIS'
	then
		ls_tutar_tur:='ALIS';
	end if;
	if ls_ISLEM_SEKLI = 'SATIS'
	then
		ls_tutar_tur:='SATIS';
	end if;

	if ls_ISLEM_SEKLI = 'ARBITRAJ'
	then
		if nvl(ln_alis_tutar,0)<>0
		then
			ls_tutar_tur:='ALIS';
		end if;
		if nvl(ln_satis_tutar,0)<>0
		then
			ls_tutar_tur:='SATIS';
		end if;
	end if;

	return ls_tutar_tur;
end;
-----------------------------------------------------------------------------------------
END;
/

