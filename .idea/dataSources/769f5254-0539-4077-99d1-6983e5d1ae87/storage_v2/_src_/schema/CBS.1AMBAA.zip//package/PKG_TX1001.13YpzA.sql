create PACKAGE     PKG_TX1001 IS

/******************************************************************************
   Name       : PKG_TX1001
   Created By : Seval Balci
   Date       : 04.06.03
   Purpose    : M??teri G?ncelleme Islemleri
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);         -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number);  -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);             -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);             -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);             -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);             -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );       -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );   -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );

  Function sf_kontrol_ekstre_adres(pn_islem_no number) return number;
  Function sf_ekstre_adres_kodu_al(pn_islem_no number) return cbs_musteri_guncellenen.extre_adres_kod%type;
  Function sf_ortaklik_kontrol(pn_islem_no number) return number;
  Function Sf_Onay_Bekleyen_Varmi(pn_tx_no cbs_islem.numara%type, pn_musteri_no cbs_musteri.musteri_no%type, pn_islem_tanim_kod cbs_islem.islem_kod%type default 1001) return cbs_cek_islem.tx_no%type;
  Procedure Guncelleme_Kontrolu(pn_islem_no number, ps_block varchar2, ps_rowid varchar2, ps_column varchar2, pd_column varchar2, ps_oldvalue in out varchar2);
  Function dokuman_kontrol(ps_musteri_tipi_kod cbs_musteri.musteri_tipi_kod%type, pn_islem_no number) return number;
  Function badlist_kontrol(pn_musteri_no number) return varchar2;
  Function sf_Musteri_Kapatilabilir(pn_musteri_no number) return varchar;
  Procedure dokuman_sil(pn_tx_no number);
  Function Sme_Adi(ps_tip varchar2) return varchar2;
  Function Report_Customer_Type(pn_musteri_no number) return varchar2;
END;
/

