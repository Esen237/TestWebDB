create PACKAGE BODY     "PKG_CREDIT_CARD" IS
   /******************************************************************************
    Name       : GetPrimaryCrebitCard
    Created By : Konstantin Zhukov 05.01.2015
    Purpose      : Get primary credit card by customer No
   ******************************************************************************/
   FUNCTION GETPRIMARYCREBITCARD(PS_CUSTOMER_ID IN VARCHAR2) RETURN VARCHAR2 IS
   LC_PRIMARY_CARD VARCHAR2 (18);
   BEGIN
      SELECT CARD_ID_NO                                              --CARD_NO
        INTO LC_PRIMARY_CARD
        FROM CBS_CREDIT_CARD
       WHERE PRIMARY_CARD_FLAG = 'Y' AND CUSTOMER_NO = PS_CUSTOMER_ID;

      RETURN LC_PRIMARY_CARD;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN LC_PRIMARY_CARD;
   END;

   /******************************************************************************
    Name       : sp_ins_Credit_Card_app_Tx
    Created By : Konstantin Zhukov 05.01.2015
    Purpose      : Procedure for creating Credit  card
   ******************************************************************************/
   PROCEDURE sp_ins_Credit_Card_app_Tx(
      pn_app_id                       NUMBER,
      pn_tx_no                        NUMBER DEFAULT NULL,
      pn_musteri_no                   NUMBER,
      l_customer_number               VARCHAR2 DEFAULT NULL,
      l_app_id                        VARCHAR2 DEFAULT NULL,
      l_name                          VARCHAR2 DEFAULT NULL,
      l_middleName                    VARCHAR2 DEFAULT NULL,
      l_surname                       VARCHAR2 DEFAULT NULL,
      l_embossName                    VARCHAR2 DEFAULT NULL,
      l_dateOfBirth                   VARCHAR2 DEFAULT NULL,
      l_gender                        VARCHAR2 DEFAULT NULL,
      l_MOTHER_MAIDEN_NAME            VARCHAR2 DEFAULT NULL,
      l_birth_place                   VARCHAR2 DEFAULT NULL,
      l_nationalityCode               VARCHAR2 DEFAULT NULL,
      l_maritialStatus                VARCHAR2 DEFAULT NULL,
      l_PREVIOUS_SURNAME              VARCHAR2 DEFAULT NULL,
      l_fatherName                    VARCHAR2 DEFAULT NULL,
      l_photo_request                 VARCHAR2 DEFAULT NULL,
      l_EMERGENCY_CALL_PERSON         VARCHAR2 DEFAULT NULL,
      l_EMERGENCY_TEL_AREACODE        VARCHAR2 DEFAULT NULL,
      l_EMERGENCY_TEL_PHONENO         VARCHAR2 DEFAULT NULL,
      l_EMERGENCY_TEL_EXTENSIONNO     VARCHAR2 DEFAULT NULL,
      l_WORK_COMPANYNAME              VARCHAR2 DEFAULT NULL,
      L_COMPANY_FLAG                  VARCHAR2 DEFAULT NULL,
      L_COMPANY_NAME                  VARCHAR2 DEFAULT NULL,
      L_COMPANY_EMBOSSNAME            VARCHAR2 DEFAULT NULL,
      l_CARDSENDINGTYPE               VARCHAR2 DEFAULT NULL,
      l_CARDSENDINGPLACE              VARCHAR2 DEFAULT NULL,
      l_CARD_PINSENDINGBRANCH         VARCHAR2 DEFAULT NULL,
      l_STATEMENTSENDADRESS           VARCHAR2 DEFAULT NULL,
      l_PINSENDINGTYPE                VARCHAR2 DEFAULT NULL,
      l_PINSENDINGPLACE               VARCHAR2 DEFAULT NULL,
      l_branch_code                   VARCHAR2 DEFAULT NULL,
      l_limit                         NUMBER   DEFAULT NULL,
      l_AUTOMATIC_PAYMENT             VARCHAR2 DEFAULT NULL,
      l_PAYMENT_COLL_ACCOUNT_NO       VARCHAR2 DEFAULT NULL,
      l_CUSTOMER_GROUP                VARCHAR2 DEFAULT NULL,
      l_PRODUCT_CODE                  VARCHAR2 DEFAULT NULL,
      l_PRICING_GROUP                 VARCHAR2 DEFAULT NULL,
      l_RISK_GROUP                    VARCHAR2 DEFAULT NULL,
      l_STATEMENTCODE                 VARCHAR2 DEFAULT NULL,
      l_RESIDENTFLAG                  VARCHAR2 DEFAULT NULL,
      l_ACCOUNTTYPE                   VARCHAR2 DEFAULT NULL,
      l_CARDTYPE                      VARCHAR2 DEFAULT NULL,
      l_PRIMARYCARD_NO                VARCHAR2 DEFAULT NULL,
      l_SUPP_CARDLIMIT_MULTIPLIER     NUMBER   DEFAULT NULL,
      l_SUPP_CARDINSTLIMIT_MULT       NUMBER   DEFAULT NULL,
      l_SUPP_CARD_CASHLIMIT_MULT      NUMBER   DEFAULT NULL,
      l_ENTERING_USER                 VARCHAR2 DEFAULT NULL,
      l_ID_TYPE                       VARCHAR2 DEFAULT NULL,
      l_SERIES                        VARCHAR2 DEFAULT NULL,
      l_SERIAL_NUMBER                 VARCHAR2 DEFAULT NULL,
      l_HOME_POSTALCODE               VARCHAR2 DEFAULT NULL,
      l_HOME_COUNTRYCODE              VARCHAR2 DEFAULT NULL,
      l_HOME_REGIONNAME               VARCHAR2 DEFAULT NULL,
      l_HOME_CITYCODE                 VARCHAR2 DEFAULT NULL,
      l_HOME_CITYNAME                 VARCHAR2 DEFAULT NULL,
      l_HOME_ADDRESSLINE1             VARCHAR2 DEFAULT NULL,
      l_HOME_ADDRESSLINE2             VARCHAR2 DEFAULT NULL,
      l_HOME_ADDRESSLINE3             VARCHAR2 DEFAULT NULL,
      l_WORK_POSTALCODE               VARCHAR2 DEFAULT NULL,
      l_WORK_COUNTRYCODE              VARCHAR2 DEFAULT NULL,
      l_WORK_REGIONNAME               VARCHAR2 DEFAULT NULL,
      l_WORK_CITYCODE                 VARCHAR2 DEFAULT NULL,
      l_WORK_CITYNAME                 VARCHAR2 DEFAULT NULL,
      l_WORK_ADDRESSLINE1             VARCHAR2 DEFAULT NULL,
      l_WORK_ADDRESSLINE2             VARCHAR2 DEFAULT NULL,
      l_WORK_ADDRESSLINE3             VARCHAR2 DEFAULT NULL,
      l_REGIS_POSTALCODE              VARCHAR2 DEFAULT NULL,
      l_REGIS_COUNTRYCODE             VARCHAR2 DEFAULT NULL,
      l_REGIS_REGIONNAME              VARCHAR2 DEFAULT NULL,
      l_REGIS_CITYCODE                VARCHAR2 DEFAULT NULL,
      l_REGIS_CITYNAME                VARCHAR2 DEFAULT NULL,
      l_REGIS_ADDRESSLINE1            VARCHAR2 DEFAULT NULL,
      l_REGIS_ADDRESSLINE2            VARCHAR2 DEFAULT NULL,
      l_REGIS_ADDRESSLINE3            VARCHAR2 DEFAULT NULL,
      l_HOME_TEL_COUNTRYAREACODE      VARCHAR2 DEFAULT NULL,
      l_HOME_TEL_AREACODE             VARCHAR2 DEFAULT NULL,
      l_HOME_TEL_PHONENO              VARCHAR2 DEFAULT NULL,
      l_HOME_TEL_EXTENSIONNO          VARCHAR2 DEFAULT NULL,
      l_WORK_TEL_COUNTRYAREACODE      VARCHAR2 DEFAULT NULL,
      l_WORK_TEL_AREACODE             VARCHAR2 DEFAULT NULL,
      l_WORK_TEL_PHONENO              VARCHAR2 DEFAULT NULL,
      l_WORK_TEL_EXTENSIONNO          VARCHAR2 DEFAULT NULL,
      l_MOB_TEL_COUNTRYAREACODE       VARCHAR2 DEFAULT NULL,
      l_MOB_TEL_AREACODE              VARCHAR2 DEFAULT NULL,
      l_MOB_TEL_PHONENO               VARCHAR2 DEFAULT NULL,
      l_MOB_TEL_COUNTRYAREACODE2      VARCHAR2 DEFAULT NULL,
      l_MOB_TEL_AREACODE2             VARCHAR2 DEFAULT NULL,
      l_MOB_TEL_PHONENO2              VARCHAR2 DEFAULT NULL,
      l_FAX_COUNTRYAREACODE           VARCHAR2 DEFAULT NULL,
      l_FAX_AREACODE                  VARCHAR2 DEFAULT NULL,
      l_FAX_PHONENO                   VARCHAR2 DEFAULT NULL,
      l_FAX_EXTENSIONNO               VARCHAR2 DEFAULT NULL,
      l_HOME_MAILADDRESS              VARCHAR2 DEFAULT NULL,
      l_WORK_MAILADDRESS              VARCHAR2 DEFAULT NULL,
      l_EMAIL_ONLYFLAG                VARCHAR2 DEFAULT NULL,
      l_CARD_HOLDER_NO                VARCHAR2 DEFAULT NULL,
      l_RESTORE_SUPPCARD_LIMITFLAG    VARCHAR2,
      SELECT_MOB_TEL                  VARCHAR2,
      DEALER_CODE                     VARCHAR2,
      L_pin_emboss_flag               VARCHAR2,    --NURZALATA 04052018 CQ6038
      L_emboss_string_option          VARCHAR2)    --NURZALATA 04052018 CQ6038
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      INSERT INTO CBS_CREDIT_CARD_APP_TX (app_id,
                                          tx_no,
                                          Customer_No,
                                          Customer_number,
                                          APPID,
                                          name,
                                          middleName,
                                          surname,
                                          embossName,
                                          Birth_Date,
                                          gender,
                                          MOTHER_MAIDEN_NAME,
                                          birth_place,
                                          NATIONALITY,
                                          MARIAL_STATUS,
                                          PREVIOUS_SURNAME,
                                          father_Name,
                                          photo_request,
                                          EMERGENCY_CALL_PERSON,
                                          EMERGENCY_TEL_AREACODE,
                                          EMERGENCY_TEL_PHONENO,
                                          EMERGENCY_TEL_EXTENSION_NO,
                                          WORK_COMPANY_NAME,
                                          COMPANY_FLAG,
                                          COMPANY_NAME,
                                          COMPANY_EMBOSSNAME,
                                          CARD_SENDING_TYPE,
                                          CARD_SENDING_PLACE,
                                          CARD_PIN_SENDINGBRANCH,
                                          STATEMENT_SEND_ADRESS,
                                          PIN_SENDING_TYPE,
                                          PIN_SENDING_PLACE,
                                          branch_code,
                                          LIMIT,
                                          AUTOMATIC_PAYMENT,
                                          PAYMENT_COLLECTION_ACCOUNT_NO,
                                          CUSTOMER_GROUP,
                                          PRODUCT_CODE,
                                          PRICING_GROUP,
                                          RISK_GROUP,
                                          STATEMENT_CODE,
                                          RESIDENT_FLAG,
                                          ACCOUNT_TYPE,
                                          CARD_TYPE,
                                          PRIMARY_CARD_NO,
                                          SUPP_CARDLIMIT_MULTIPLIER,
                                          SUPP_CARD_CASHLIMIT_MULTIPLIER,
                                          SUPP_CARDINSTLIMIT_MULTIPLIER,
                                          ENTERING_USER,
                                          ID_TYPE,
                                          SERIES,
                                          SERIAL_NUMBER,
                                          HOME_POSTALCODE,
                                          HOME_COUNTRYCODE,
                                          HOME_REGION_NAME,
                                          HOME_CITYCODE,
                                          HOME_CITYNAME,
                                          HOME_ADDRESSLINE1,
                                          HOME_ADDRESSLINE2,
                                          HOME_ADDRESSLINE3,
                                          WORK_POSTALCODE,
                                          WORK_COUNTRYCODE,
                                          WORK_REGIONNAME,
                                          WORK_CITYCODE,
                                          WORK_CITYNAME,
                                          WORK_ADDRESSLINE1,
                                          WORK_ADDRESSLINE2,
                                          WORK_ADDRESSLINE3,
                                          REGIS_POSTALCODE,
                                          REGIS_COUNTRYCODE,
                                          REGIS_REGIONNAME,
                                          REGIS_CITYCODE,
                                          REGIS_CITYNAME,
                                          REGIS_ADDRESSLINE1,
                                          REGIS_ADDRESSLINE2,
                                          REGIS_ADDRESSLINE3,
                                          HOME_TEL_COUNTRYAREACODE,
                                          HOME_TEL_AREACODE,
                                          HOME_TEL_PHONENO,
                                          HOME_TEL_EXTENSIONNO,
                                          WORK_TEL_COUNTRYAREACODE,
                                          WORK_TEL_AREACODE,
                                          WORK_TEL_PHONENO,
                                          WORK_TEL_EXTENSIONNO,
                                          MOB_TEL_COUNTRYAREACODE,
                                          MOB_TEL_AREACODE,
                                          MOB_TEL_PHONENO,
                                          MOB_TEL_COUNTRYAREACODE2,
                                          MOB_TEL_AREACODE2,
                                          MOB_TEL_PHONENO2,
                                          FAX_COUNTRYAREACODE,
                                          FAX_AREACODE,
                                          FAX_PHONENO,
                                          FAX_EXTENSIONNO,
                                          HOME_MAILADDRESS,
                                          WORK_MAILADDRESS,
                                          EMAIL_ONLYFLAG,
                                          CARD_HOLDER_NO,
                                          RESTORE_SUPPCARD_LIMITFLAG,
                                          SELECT_MOB_TEL,
                                          DEALER_CODE,
                                          pin_emboss_flag,      --NURZALATA 04052018 CQ6038
                                          emboss_string_option) --NURZALATA 04052018 CQ6038
           VALUES (pn_app_id,
                   pn_tx_no,
                   pn_musteri_no,
                   l_customer_number,
                   l_APP_ID,
                   l_name,
                   l_middleName,
                   l_surname,
                   l_embossName,
                   l_dateOfBirth,
                   l_gender,
                   l_MOTHER_MAIDEN_NAME,
                   l_birth_place,
                   l_nationalityCode,
                   l_maritialStatus,
                   l_PREVIOUS_SURNAME,
                   l_fatherName,
                   l_photo_request,
                   l_EMERGENCY_CALL_PERSON,
                   l_EMERGENCY_TEL_AREACODE,
                   l_EMERGENCY_TEL_PHONENO,
                   l_EMERGENCY_TEL_EXTENSIONNO,
                   l_WORK_COMPANYNAME,
                   L_COMPANY_FLAG,
                   L_COMPANY_NAME,
                   L_COMPANY_EMBOSSNAME,
                   l_CARDSENDINGTYPE,
                   l_CARDSENDINGPLACE,
                   l_CARD_PINSENDINGBRANCH,
                   l_STATEMENTSENDADRESS,
                   l_PINSENDINGTYPE,
                   l_PINSENDINGPLACE,
                   l_branch_code,
                   l_limit,
                   l_AUTOMATIC_PAYMENT,
                   l_PAYMENT_COLL_ACCOUNT_NO,
                   l_CUSTOMER_GROUP,
                   l_PRODUCT_CODE,
                   l_PRICING_GROUP,
                   l_RISK_GROUP,
                   l_STATEMENTCODE,
                   l_RESIDENTFLAG,
                   l_ACCOUNTTYPE,
                   l_CARDTYPE,
                   l_PRIMARYCARD_NO,
                   l_SUPP_CARDLIMIT_MULTIPLIER,
                   l_SUPP_CARD_CASHLIMIT_MULT,
                   l_SUPP_CARDINSTLIMIT_MULT,
                   l_ENTERING_USER,
                   l_ID_TYPE,
                   l_SERIES,
                   l_SERIAL_NUMBER,
                   l_HOME_POSTALCODE,
                   l_HOME_COUNTRYCODE,
                   l_HOME_REGIONNAME,
                   l_HOME_CITYCODE,
                   l_HOME_CITYNAME,
                   l_HOME_ADDRESSLINE1,
                   l_HOME_ADDRESSLINE2,
                   l_HOME_ADDRESSLINE3,
                   l_WORK_POSTALCODE,
                   l_WORK_COUNTRYCODE,
                   l_WORK_REGIONNAME,
                   l_WORK_CITYCODE,
                   l_WORK_CITYNAME,
                   l_WORK_ADDRESSLINE1,
                   l_WORK_ADDRESSLINE2,
                   l_WORK_ADDRESSLINE3,
                   l_REGIS_POSTALCODE,
                   l_REGIS_COUNTRYCODE,
                   l_REGIS_REGIONNAME,
                   l_REGIS_CITYCODE,
                   l_REGIS_CITYNAME,
                   l_REGIS_ADDRESSLINE1,
                   l_REGIS_ADDRESSLINE2,
                   l_REGIS_ADDRESSLINE3,
                   l_HOME_TEL_COUNTRYAREACODE,
                   l_HOME_TEL_AREACODE,
                   l_HOME_TEL_PHONENO,
                   l_HOME_TEL_EXTENSIONNO,
                   l_WORK_TEL_COUNTRYAREACODE,
                   l_WORK_TEL_AREACODE,
                   l_WORK_TEL_PHONENO,
                   l_WORK_TEL_EXTENSIONNO,
                   l_MOB_TEL_COUNTRYAREACODE,
                   l_MOB_TEL_AREACODE,
                   l_MOB_TEL_PHONENO,
                   l_MOB_TEL_COUNTRYAREACODE2,
                   l_MOB_TEL_AREACODE2,
                   l_MOB_TEL_PHONENO2,
                   l_FAX_COUNTRYAREACODE,
                   l_FAX_AREACODE,
                   l_FAX_PHONENO,
                   l_FAX_EXTENSIONNO,
                   l_HOME_MAILADDRESS,
                   l_WORK_MAILADDRESS,
                   l_EMAIL_ONLYFLAG,
                   l_CARD_HOLDER_NO,
                   l_RESTORE_SUPPCARD_LIMITFLAG,
                   SELECT_MOB_TEL,
                   DEALER_CODE,
                   L_pin_emboss_flag,              --NURZALATA 04052018 CQ6038
                   L_emboss_string_option);        --NURZALATA 04052018 CQ6038
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         ROLLBACK;
         log_at('SP_INS_CREDIT_CARD_APP_TX-ERROR', pn_app_id, SQLCODE || ' ' || SQLERRM);
         raise_application_error(-20100, pkg_hata.getucpointer || '6702' || pkg_hata.getdelimiter || TO_CHAR (SQLCODE) || ' ' || SQLERRM || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   END;

   /******************************************************************************
    Name       : sp_ins_Credit_Card_UPD_app_Tx
    Created By : Konstantin Zhukov 05.01.2015
    Purpose      : Procedure for Updating Credit  card
   ******************************************************************************/
   PROCEDURE sp_ins_Credit_Card_UPD_app_Tx(
      pn_app_id                      NUMBER,
      pn_tx_no                       NUMBER DEFAULT NULL,
      pn_musteri_no                  NUMBER,
      l_customer_number              VARCHAR2 DEFAULT NULL,
      l_app_id                       VARCHAR2 DEFAULT NULL,
      L_NAME                         VARCHAR2 DEFAULT NULL,
      L_SURNAME                      VARCHAR2 DEFAULT NULL,
      L_MIDDLE_NAME                  VARCHAR2 DEFAULT NULL,
      L_EMBOSSNAME                   VARCHAR2 DEFAULT NULL,
      L_BIRTH_DATE                   VARCHAR2 DEFAULT NULL,
      L_GENDER                       VARCHAR2 DEFAULT NULL,
      L_MOTHER_MAIDEN_NAME           VARCHAR2 DEFAULT NULL,
      L_BIRTH_PLACETEXT              VARCHAR2 DEFAULT NULL,
      L_NATIONALITY                  VARCHAR2 DEFAULT NULL,
      L_MARIAL_STATUS                VARCHAR2 DEFAULT NULL,
      L_FATHER_NAME                  VARCHAR2 DEFAULT NULL,
      L_EMERGENCYCALLPERSON          VARCHAR2 DEFAULT NULL,
      L_EMERGENCY_TEL_AREACODE       VARCHAR2 DEFAULT NULL,
      L_EMERGENCY_TEL_PHONENO        VARCHAR2 DEFAULT NULL,
      L_EMERGENCY_TEL_EXTENSIONNO    VARCHAR2 DEFAULT NULL,
      L_WORK_COMPANYNAME             VARCHAR2 DEFAULT NULL,
      L_CARDSENDINGTYPE              VARCHAR2 DEFAULT NULL,
      L_CARDSENDINGPLACE             VARCHAR2 DEFAULT NULL,
      L_CARD_PINSENDINGBRANCH        VARCHAR2 DEFAULT NULL,
      L_STATEMENTSENDADRESS          VARCHAR2 DEFAULT NULL,
      L_PINSENDINGTYPE               VARCHAR2 DEFAULT NULL,
      L_PINSENDINGPLACE              VARCHAR2 DEFAULT NULL,
      L_RESIDENTFLAG                 VARCHAR2 DEFAULT NULL,
      L_IDTYPE                       VARCHAR2 DEFAULT NULL,
      L_IDSERIES                     VARCHAR2 DEFAULT NULL,
      L_IDSERIALNUMBER               VARCHAR2 DEFAULT NULL,
      L_HADR1                        VARCHAR2 DEFAULT NULL,
      L_HADR2                        VARCHAR2 DEFAULT NULL,
      L_HADR3                        VARCHAR2 DEFAULT NULL,
      L_HDISTRICT                    VARCHAR2 DEFAULT NULL,
      L_HCITYCODE                    VARCHAR2 DEFAULT NULL,
      L_HCITYNAME                    VARCHAR2 DEFAULT NULL,
      L_HCOUNTRYCODE                 VARCHAR2 DEFAULT NULL,
      L_HCOUNTRYNAME                 VARCHAR2 DEFAULT NULL,
      L_HZIPCODE                     VARCHAR2 DEFAULT NULL,
      L_WADR1                        VARCHAR2 DEFAULT NULL,
      L_WADR2                        VARCHAR2 DEFAULT NULL,
      L_WADR3                        VARCHAR2 DEFAULT NULL,
      L_WDISTRICT                    VARCHAR2 DEFAULT NULL,
      L_WCITYCODE                    VARCHAR2 DEFAULT NULL,
      L_WCITYNAME                    VARCHAR2 DEFAULT NULL,
      L_WCOUNTRYCODE                 VARCHAR2 DEFAULT NULL,
      L_WCOUNTRYNAME                 VARCHAR2 DEFAULT NULL,
      L_WZIPCODE                     VARCHAR2 DEFAULT NULL,
      L_TADRACTIVE                   VARCHAR2 DEFAULT NULL,
      L_TADR1                        VARCHAR2 DEFAULT NULL,
      L_TADR2                        VARCHAR2 DEFAULT NULL,
      L_TADR3                        VARCHAR2 DEFAULT NULL,
      L_TDISTRICT                    VARCHAR2 DEFAULT NULL,
      L_TCITYCODE                    VARCHAR2 DEFAULT NULL,
      L_TCITYNAME                    VARCHAR2 DEFAULT NULL,
      L_TCOUNTRYCODE                 VARCHAR2 DEFAULT NULL,
      L_TCOUNTRYNAME                 VARCHAR2 DEFAULT NULL,
      L_TZIPCODE                     VARCHAR2 DEFAULT NULL,
      L_TADRSTARTDAY                 VARCHAR2 DEFAULT NULL,
      L_TADRSTARTMONTH               VARCHAR2 DEFAULT NULL,
      L_TADRSTARTYEAR                VARCHAR2 DEFAULT NULL,
      L_TADRENDDAY                   VARCHAR2 DEFAULT NULL,
      L_TADRENDMONTH                 VARCHAR2 DEFAULT NULL,
      L_TADRENDYEAR                  VARCHAR2 DEFAULT NULL,
      L_TADRTYPE                     VARCHAR2 DEFAULT NULL,
      L_HTELCOUNTRY                  VARCHAR2 DEFAULT NULL,
      L_HTELAREA                     VARCHAR2 DEFAULT NULL,
      L_HTEL                         VARCHAR2 DEFAULT NULL,
      L_HTELEXT                      VARCHAR2 DEFAULT NULL,
      L_HFAXCOUNTRY                  VARCHAR2 DEFAULT NULL,
      L_HFAXAREA                     VARCHAR2 DEFAULT NULL,
      L_HFAX                         VARCHAR2 DEFAULT NULL,
      L_HEMAIL                       VARCHAR2 DEFAULT NULL,
      L_WTELCOUNTRY                  VARCHAR2 DEFAULT NULL,
      L_WTELAREA                     VARCHAR2 DEFAULT NULL,
      L_WTEL                         VARCHAR2 DEFAULT NULL,
      L_WTELEXT                      VARCHAR2 DEFAULT NULL,
      L_WFAXCOUNTRY                  VARCHAR2 DEFAULT NULL,
      L_WFAXAREA                     VARCHAR2 DEFAULT NULL,
      L_WFAX                         VARCHAR2 DEFAULT NULL,
      L_WEMAIL                       VARCHAR2 DEFAULT NULL,
      L_TTELCOUNTRY                  VARCHAR2 DEFAULT NULL,
      L_TTELAREA                     VARCHAR2 DEFAULT NULL,
      L_TTEL                         VARCHAR2 DEFAULT NULL,
      L_TTELEXT                      VARCHAR2 DEFAULT NULL,
      L_TFAXCOUNTRY                  VARCHAR2 DEFAULT NULL,
      L_TFAXAREA                     VARCHAR2 DEFAULT NULL,
      L_TFAX                         VARCHAR2 DEFAULT NULL,
      L_TEMAIL                       VARCHAR2 DEFAULT NULL,
      L_MTELCOUNTRY                  VARCHAR2 DEFAULT NULL,
      L_MTELAREA                     VARCHAR2 DEFAULT NULL,
      L_MTEL                         VARCHAR2 DEFAULT NULL,
      L_MTELCOUNTRY2                 VARCHAR2 DEFAULT NULL,
      L_MTELAREA2                    VARCHAR2 DEFAULT NULL,
      L_MTEL2                        VARCHAR2 DEFAULT NULL,
      L_UserID                       VARCHAR2 DEFAULT NULL,
      L_SELECT_MOB_TEL               VARCHAR2,
      pn_card_no                     VARCHAR2 DEFAULT NULL,
      pn_card_id_no                  VARCHAR2 DEFAULT NULL)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      INSERT INTO CBS_CREDIT_CARD_UPD_APP_TX (app_id,
                                              tx_no,
                                              Customer_No,
                                              Customer_number,
                                              APPID,
                                              NAME,
                                              SURNAME,
                                              MIDDLE_NAME,
                                              EMBOSSNAME,
                                              BIRTH_DATE,
                                              GENDER,
                                              MOTHER_MAIDEN_NAME,
                                              BIRTH_PLACETEXT,
                                              NATIONALITY,
                                              MARIAL_STATUS,
                                              FATHER_NAME,
                                              EMERGENCYCALLPERSON,
                                              EMERGENCY_TEL_AREACODE,
                                              EMERGENCY_TEL_PHONENO,
                                              EMERGENCY_TEL_EXTENSIONNO,
                                              WORK_COMPANYNAME,
                                              CARDSENDINGTYPE,
                                              CARDSENDINGPLACE,
                                              CARD_PINSENDINGBRANCH,
                                              STATEMENTSENDADRESS,
                                              PINSENDINGTYPE,
                                              PINSENDINGPLACE,
                                              RESIDENTFLAG,
                                              IDTYPE,
                                              IDSERIES,
                                              IDSERIALNUMBER,
                                              HADR1,
                                              HADR2,
                                              HADR3,
                                              HDISTRICT,
                                              HCITYCODE,
                                              HCITYNAME,
                                              HCOUNTRYCODE,
                                              HCOUNTRYNAME,
                                              HZIPCODE,
                                              WADR1,
                                              WADR2,
                                              WADR3,
                                              WDISTRICT,
                                              WCITYCODE,
                                              WCITYNAME,
                                              WCOUNTRYCODE,
                                              WCOUNTRYNAME,
                                              WZIPCODE,
                                              TADRACTIVE,
                                              TADR1,
                                              TADR2,
                                              TADR3,
                                              TDISTRICT,
                                              TCITYCODE,
                                              TCITYNAME,
                                              TCOUNTRYCODE,
                                              TCOUNTRYNAME,
                                              TZIPCODE,
                                              TADRSTARTDAY,
                                              TADRSTARTMONTH,
                                              TADRSTARTYEAR,
                                              TADRENDDAY,
                                              TADRENDMONTH,
                                              TADRENDYEAR,
                                              TADRTYPE,
                                              HTELCOUNTRY,
                                              HTELAREA,
                                              HTEL,
                                              HTELEXT,
                                              HFAXCOUNTRY,
                                              HFAXAREA,
                                              HFAX,
                                              HEMAIL,
                                              WTELCOUNTRY,
                                              WTELAREA,
                                              WTEL,
                                              WTELEXT,
                                              WFAXCOUNTRY,
                                              WFAXAREA,
                                              WFAX,
                                              WEMAIL,
                                              TTELCOUNTRY,
                                              TTELAREA,
                                              TTEL,
                                              TTELEXT,
                                              TFAXCOUNTRY,
                                              TFAXAREA,
                                              TFAX,
                                              TEMAIL,
                                              MTELCOUNTRY,
                                              MTELAREA,
                                              MTEL,
                                              MTELCOUNTRY2,
                                              MTELAREA2,
                                              MTEL2,
                                              UserID,
                                              CARD_NO,
                                              CARD_ID_NO,
                                              SELECT_MOB_TEL)
           VALUES (pn_app_id,
                   pn_tx_no,
                   pn_musteri_no,
                   l_customer_number,
                   l_app_id,
                   L_NAME,
                   L_SURNAME,
                   L_MIDDLE_NAME,
                   L_EMBOSSNAME,
                   L_BIRTH_DATE,
                   L_GENDER,
                   L_MOTHER_MAIDEN_NAME,
                   L_BIRTH_PLACETEXT,
                   L_NATIONALITY,
                   L_MARIAL_STATUS,
                   L_FATHER_NAME,
                   L_EMERGENCYCALLPERSON,
                   L_EMERGENCY_TEL_AREACODE,
                   L_EMERGENCY_TEL_PHONENO,
                   L_EMERGENCY_TEL_EXTENSIONNO,
                   L_WORK_COMPANYNAME,
                   L_CARDSENDINGTYPE,
                   L_CARDSENDINGPLACE,
                   L_CARD_PINSENDINGBRANCH,
                   L_STATEMENTSENDADRESS,
                   L_PINSENDINGTYPE,
                   L_PINSENDINGPLACE,
                   L_RESIDENTFLAG,
                   L_IDTYPE,
                   L_IDSERIES,
                   L_IDSERIALNUMBER,
                   L_HADR1,
                   L_HADR2,
                   L_HADR3,
                   L_HDISTRICT,
                   L_HCITYCODE,
                   L_HCITYNAME,
                   L_HCOUNTRYCODE,
                   L_HCOUNTRYNAME,
                   L_HZIPCODE,
                   L_WADR1,
                   L_WADR2,
                   L_WADR3,
                   L_WDISTRICT,
                   L_WCITYCODE,
                   L_WCITYNAME,
                   L_WCOUNTRYCODE,
                   L_WCOUNTRYNAME,
                   L_WZIPCODE,
                   L_TADRACTIVE,
                   L_TADR1,
                   L_TADR2,
                   L_TADR3,
                   L_TDISTRICT,
                   L_TCITYCODE,
                   L_TCITYNAME,
                   L_TCOUNTRYCODE,
                   L_TCOUNTRYNAME,
                   L_TZIPCODE,
                   L_TADRSTARTDAY,
                   L_TADRSTARTMONTH,
                   L_TADRSTARTYEAR,
                   L_TADRENDDAY,
                   L_TADRENDMONTH,
                   L_TADRENDYEAR,
                   L_TADRTYPE,
                   L_HTELCOUNTRY,
                   L_HTELAREA,
                   L_HTEL,
                   L_HTELEXT,
                   L_HFAXCOUNTRY,
                   L_HFAXAREA,
                   L_HFAX,
                   L_HEMAIL,
                   L_WTELCOUNTRY,
                   L_WTELAREA,
                   L_WTEL,
                   L_WTELEXT,
                   L_WFAXCOUNTRY,
                   L_WFAXAREA,
                   L_WFAX,
                   L_WEMAIL,
                   L_TTELCOUNTRY,
                   L_TTELAREA,
                   L_TTEL,
                   L_TTELEXT,
                   L_TFAXCOUNTRY,
                   L_TFAXAREA,
                   L_TFAX,
                   L_TEMAIL,
                   L_MTELCOUNTRY,
                   L_MTELAREA,
                   L_MTEL,
                   L_MTELCOUNTRY2,
                   L_MTELAREA2,
                   L_MTEL2,
                   L_UserID,
                   pn_card_no,
                   pn_card_id_no,
                   L_SELECT_MOB_TEL);
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         ROLLBACK;
         log_at('SP_INS_CREDIT_CARD_APP_TX-ERROR', pn_app_id, SQLCODE || ' ' || SQLERRM);
         raise_application_error(-20100, pkg_hata.getucpointer || '6702' || pkg_hata.getdelimiter || TO_CHAR (SQLCODE) || ' ' || SQLERRM || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   END;

   /******************************************************************************
      NAME : FUNCTION SP_WS_GenerateEmbossRequest
      Prepared By : Konstantin Zhukov
      Date : 09.12.2015
      Purpose : Function Calls web service and Generate Emboss and PIN request for Credit card
    *****************************************************************************/
   FUNCTION SP_WS_GenerateEmbossRequest(pc_CARDNO                  IN     VARCHAR2,
                                        pn_tx_no                          NUMBER,
                                        pc_EXTEND_EXP_DATE         IN     VARCHAR2,
                                        pc_CARD_EMBOSS_REQ         IN     VARCHAR2,
                                        pc_PIN_PRINT_REQ           IN     VARCHAR2,
                                        pc_PINSENDINGBRANCH        IN     VARCHAR2,
                                        pc_USERID                  IN     VARCHAR2,
                                        ps_RCODE                   IN OUT VARCHAR2,
                                        ps_RDESC                   IN OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      ls_returncode      VARCHAR2 (3) := '60';
      --ws variables
      serviceUrl         VARCHAR2 (300);
      soapAction         VARCHAR2 (100);
      namespace          VARCHAR2 (100);
      methodName         VARCHAR2 (100);
      req                pkg_soap.request;
      resp               pkg_soap.response;
      result             CLOB;

      l_parser           DBMS_XMLPARSER.Parser;
      l_doc              DBMS_XMLDOM.DOMDocument;
      l_nl               DBMS_XMLDOM.DOMNodeList;
      l_n                DBMS_XMLDOM.DOMNode;

      ls_CARDNO          VARCHAR2 (100);
      ls_STATUS_CODE     VARCHAR2 (100);
      ls_CUSTNO          VARCHAR2 (100);
      ls_EMBOSS_NAME     VARCHAR2 (100);

      ld_starttime       DATE;
      ld_endtime         DATE;

      url_web            VARCHAR2 (200 CHAR);
   BEGIN
      pkg_parametre.deger('BS_CWS_SERVICE_URL', url_web);
      serviceUrl := url_web;
      ld_starttime := SYSDATE;

      BEGIN
         namespace := 'http://www.banksoft.com.tr';
         methodName := 'GenerateEmbossRequest';
         soapAction := namespace || '/KirgizDemirWS/' || methodName;
         namespace := 'xmlns="' || namespace || '"';

         --create new request
         req := Pkg_Soap.new_request(methodName, namespace);
         log_at ('EMB0000');
         
         Pkg_Soap.ADD_PARAMETER(req, 'ERT', NULL,
               '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GenerateEmbossRequestType"><![CDATA[' || pc_CARDNO || ']]></PSEUDOPAN> '
            || '<EXTEND_EXP_DATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GenerateEmbossRequestType"><![CDATA[' || pc_EXTEND_EXP_DATE || ']]></EXTEND_EXP_DATE> '
            || '<CARD_EMBOSS_REQ xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GenerateEmbossRequestType"><![CDATA[' || pc_CARD_EMBOSS_REQ || ']]></CARD_EMBOSS_REQ> '
            || '<PIN_PRINT_REQ xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GenerateEmbossRequestType"><![CDATA[' || pc_PIN_PRINT_REQ || ']]></PIN_PRINT_REQ> '
            || '<USERID xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GenerateEmbossRequestType"><![CDATA[' || SUBSTR (pc_USERID, 1, 8) || ']]></USERID> '      -- CQ5794 KonstantinJ 11052017
            || '<CARD_PINSENDINGBRANCH xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GenerateEmbossRequestType"><![CDATA['  || LPAD(pc_PINSENDINGBRANCH, 4, '0') || ']]></CARD_PINSENDINGBRANCH> '); -- CQ5813 IadgarB 10092018

         --call web service, and get response
         log_at('EMB1111');
         resp := Pkg_Soap.invoke_utf8_v11 (req, serviceUrl, soapAction);
         log_at('EMB2222');
         result := resp.doc.getstringval ();
         log_at('EMB3333');
         result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"', '');
         result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr"', '');

         l_parser := DBMS_XMLPARSER.newParser;
         DBMS_XMLPARSER.parseclob(l_parser, result);
         l_doc := DBMS_XMLPARSER.getDocument(l_parser);
         l_nl := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode(l_doc), 'GenerateEmbossRequestResponse/GenerateEmbossRequestResult');
         l_n := DBMS_XMLDOM.item(l_nl, 0);
         log_at('EMB4444');


         -- Use XPATH syntax to assign values to he elements of the collection.
         DBMS_XSLPROCESSOR.valueOf(l_n, 'RCODE', ps_RCODE);
         DBMS_XSLPROCESSOR.valueOf(l_n, 'RDESC', ps_RDESC);
         log_at('EMB5555');

         ld_endtime := SYSDATE;

         Pkg_debit_Card.WS_LOG('CREDIT_CARD_EMBOSS', serviceUrl, methodName, ld_starttime, ld_endtime, ps_RCODE, NULL, pn_tx_no, NULL, result, REQ.BODY);
         log_at('EMB6666');
      EXCEPTION
         WHEN OTHERS THEN
            Pkg_debit_Card.WS_LOG('CREDIT_CARD_EMBOSS', serviceUrl, methodName, ld_starttime, ld_endtime, '999', SQLCODE || ' ' || SQLERRM, pn_tx_no, NULL, result, REQ.BODY);
      END;
      RETURN ls_returncode;
   END;

   ----------------------------------------------------------------------------------------------------------------------
   PROCEDURE SP_WS_CCardAppReq(pn_app_id              NUMBER,
                               ps_response_code   OUT VARCHAR2,
                               ps_response_desc   OUT VARCHAR2,
                               ps_newcardno       OUT VARCHAR2,
                               ps_card_id         OUT VARCHAR2,
                               ps_banksoft_no     OUT VARCHAR2)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;

      CURSOR cur_app IS
         SELECT *
           FROM CBS_CREDIT_CARD_APP_TX
          WHERE app_id = pn_app_id;

      r_app                  cur_App%ROWTYPE;
      serviceUrl             VARCHAR2 (2000);
      soapAction             VARCHAR2 (2000);
      namespace              VARCHAR2 (2000);
      methodName             VARCHAR2 (2000);
      req                    Pkg_Soap.request;
      resp                   Pkg_Soap.response;
      result                 CLOB;                         --NVARCHAR2(32767);
      referenceId            INTEGER;

      l_parser               DBMS_XMLPARSER.Parser;
      l_doc                  DBMS_XMLDOM.DOMDocument;
      l_nl                   DBMS_XMLDOM.DOMNodeList;
      l_n                    DBMS_XMLDOM.DOMNode;

      ld_starttime           DATE;
      ld_endtime             DATE;

      ls_new_bs_flag         VARCHAR2 (1) := 'N';

      ls_BS_WS_SERVICE_URL   VARCHAR2 (200);
      
      ln_credit_card_count   NUMBER := 0;
   BEGIN
      pkg_parametre.deger('BS_CWS_SERVICE_URL', ls_BS_WS_SERVICE_URL);

      FOR c_app IN cur_app
      LOOP
         r_app := c_app;
      END LOOP;

      ld_starttime := SYSDATE;

      serviceUrl := ls_BS_WS_SERVICE_URL;
      namespace := 'http://www.banksoft.com.tr';
      methodName := 'CCardAppReq';
      soapAction := namespace || '/KirgizDemirWS/' || methodName;
      namespace := 'xmlns="' || namespace || '"';

      IF r_app.CUSTOMER_NUMBER IS NOT NULL THEN
         SELECT COUNT(*) i
           INTO ln_credit_card_count
           FROM cbs_credit_card
          WHERE customer_no = r_app.CUSTOMER_NUMBER
            AND primary_card_flag = 'A';
           -- AND status = 'A';--GulkaiyrK cbs251
      END IF;

      IF pkg_musteri.sf_musteri_tipi_al(r_app.CUSTOMER_NUMBER) IN ('3','4') THEN
         IF r_app.Card_type = 'A' THEN
            ls_new_bs_flag := 'Y';
         ELSE
            ls_new_bs_flag := 'N';
         END IF;
      ELSE
         IF ln_credit_card_count = 0 AND r_app.Card_type = 'A' THEN
            ls_new_bs_flag := 'Y';
         ELSE
            ls_new_bs_flag := 'N';
         END IF;
      END IF;

      req := Pkg_Soap.new_request(methodName, namespace);

      Pkg_Soap.ADD_PARAMETER(
            req,
            'CAReq',
            NULL,
               '<CUSTOMERNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.CUSTOMER_NUMBER || ']]></CUSTOMERNO>'
            || '<APPLICATION_NO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.APP_ID || ']]></APPLICATION_NO>'
            || '<NAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.NAME || ']]></NAME>'
            || '<MIDDLE_NAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MIDDLENAME || ']]></MIDDLE_NAME>'
            || '<SURNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.SURNAME || ']]></SURNAME>'
            || '<EMBOSSNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.EMBOSSNAME || ']]></EMBOSSNAME>'
            || '<BIRTH_DATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.BIRTH_DATE || ']]></BIRTH_DATE>'
            || '<GENDER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.gender || ']]></GENDER>'
            || '<MOTHER_MAIDEN_NAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MOTHER_MAIDEN_NAME || ']]></MOTHER_MAIDEN_NAME>'
            || '<BIRTH_PLACETEXT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.BIRTH_PLACE || ']]></BIRTH_PLACETEXT>'
            || '<NATIONALITY xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.NATIONALITY || ']]></NATIONALITY>'
            || '<MARIAL_STATUS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MARIAL_STATUS || ']]></MARIAL_STATUS>'
            || '<PREVIOUS_SURNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.PREVIOUS_SURNAME || ']]></PREVIOUS_SURNAME>'
            || '<FATHER_NAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.FATHER_NAME || ']]></FATHER_NAME>'
            || '<PHOTO_REQUEST xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.PHOTO_REQUEST || ']]></PHOTO_REQUEST>'
            || '<EMERGENCY_CALL_PERSON xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.EMERGENCY_CALL_PERSON || ']]></EMERGENCY_CALL_PERSON>'
            || '<EMERGENCY_TEL_AREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.EMERGENCY_TEL_AREACODE || ']]></EMERGENCY_TEL_AREACODE>'
            || '<EMERGENCY_TEL_PHONENO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.EMERGENCY_TEL_PHONENO || ']]></EMERGENCY_TEL_PHONENO>'
            || '<EMERGENCY_TEL_EXTENSIONNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.EMERGENCY_TEL_EXTENSION_NO || ']]></EMERGENCY_TEL_EXTENSIONNO>'
            || '<WORK_COMPANYNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_COMPANY_NAME || ']]></WORK_COMPANYNAME>'
            || '<COMPANY_FLAG xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.COMPANY_FLAG || ']]></COMPANY_FLAG>'
            || '<COMPANY_NAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.COMPANY_NAME || ']]></COMPANY_NAME>'
            || '<COMPANY_EMBOSSNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.COMPANY_EMBOSSNAME || ']]></COMPANY_EMBOSSNAME>'
            || '<CARDSENDINGTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.CARD_SENDING_TYPE || ']]></CARDSENDINGTYPE>'   --TEST r_app.CARD_SENDING_TYPE
            || '<CARDSENDINGPLACE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.CARD_SENDING_PLACE || ']]></CARDSENDINGPLACE>'  -- E TEST r_app.CARD_SENDING_PLACE
            || '<CARD_PINSENDINGBRANCH xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || LPAD (r_app.CARD_PIN_SENDINGBRANCH, 4, '0') || ']]></CARD_PINSENDINGBRANCH>' --TEST r_app.CARD_PIN_SENDINGBRANCH
            || '<STATEMENTSENDADRESS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.STATEMENT_SEND_ADRESS || ']]></STATEMENTSENDADRESS>'
            || '<PINSENDINGTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.PIN_SENDING_TYPE || ']]></PINSENDINGTYPE>'
            || '<PINSENDINGPLACE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.PIN_SENDING_PLACE || ']]></PINSENDINGPLACE>'
            || '<BRANCHCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || LPAD (r_app.BRANCH_CODE, 4, '0') || ']]></BRANCHCODE>'   --TEST  r_app.BRANCH_CODE
            || '<LIMIT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.LIMIT || ']]></LIMIT>'
            || '<AUTOMATIC_PAYMENT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.AUTOMATIC_PAYMENT || ']]></AUTOMATIC_PAYMENT>'
            || '<PAYMENT_COLLECTION_ACCOUNT_NO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || LPAD (r_app.PAYMENT_COLLECTION_ACCOUNT_NO, 18, '0') || ']]></PAYMENT_COLLECTION_ACCOUNT_NO>'
            || '<CUSTOMER_GROUP xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.CUSTOMER_GROUP || ']]></CUSTOMER_GROUP>'  -- 'VGO'  TEST r_app.CUSTOMER_GROUP
            || '<PRODUCT_CODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.PRODUCT_CODE || ']]></PRODUCT_CODE>'  -- 'VGC' TEST r_app.PRODUCT_CODE
            || '<PRICING_GROUP xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.PRICING_GROUP || ']]></PRICING_GROUP>' --'VG'    TEST r_app.PRICING_GROUP
            || '<RISK_GROUP xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.RISK_GROUP || ']]></RISK_GROUP>'    --'R01'   TEST  r_app.RISK_GROUP
            || '<STATEMENTCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.STATEMENT_CODE || ']]></STATEMENTCODE>' --'VC'  TEST r_app.STATEMENT_CODE
            || '<RESIDENTFLAG xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.RESIDENT_FLAG || ']]></RESIDENTFLAG>'
            || '<ACCOUNTTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.ACCOUNT_TYPE || ']]></ACCOUNTTYPE>'  --TEST
            || '<CARDTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.Card_type || ']]></CARDTYPE>'     --TEST
            || '<PRIMARYPSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.primary_card_no || ']]></PRIMARYPSEUDOPAN>'  --PSEUDOPAN CODE
            || '<SUPPCARDLIMITMULTIPLIER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.SUPP_CARDLIMIT_MULTIPLIER || ']]></SUPPCARDLIMITMULTIPLIER>'
            || '<SUPPCARDCASHLIMITMULTIPLIER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.SUPP_CARD_CASHLIMIT_MULTIPLIER || ']]></SUPPCARDCASHLIMITMULTIPLIER>'
            || '<SUPPCARDINSTLIMITMULTIPLIER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.SUPP_CARDINSTLIMIT_MULTIPLIER || ']]></SUPPCARDINSTLIMITMULTIPLIER>'
            || '<ENTERINGUSER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.ENTERING_USER || ']]></ENTERINGUSER>'
            || '<IDTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.ID_TYPE || ']]></IDTYPE>'
            || '<SERIES xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.SERIES || ']]></SERIES>' --TEST r_app.SERIES
            || '<SERIALNUMBER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.SERIAL_NUMBER || ']]></SERIALNUMBER>'  --rTEST _app.SERIAL_NUMBER
            || '<HOME_POSTALCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_POSTALCODE || ']]></HOME_POSTALCODE>'
            || '<HOME_COUNTRYCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_COUNTRYCODE || ']]></HOME_COUNTRYCODE>'
            || '<HOME_REGIONNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_REGION_NAME || ']]></HOME_REGIONNAME>'
            || '<HOME_CITYCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_CITYCODE || ']]></HOME_CITYCODE>'
            || '<HOME_CITYNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_CITYNAME || ']]></HOME_CITYNAME>'
            || '<HOME_ADDRESSLINE1 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_ADDRESSLINE1 || ']]></HOME_ADDRESSLINE1>'
            || '<HOME_ADDRESSLINE2 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_ADDRESSLINE2 || ']]></HOME_ADDRESSLINE2>'
            || '<HOME_ADDRESSLINE3 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_ADDRESSLINE3 || ']]></HOME_ADDRESSLINE3>'
            || '<WORK_POSTALCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_POSTALCODE || ']]></WORK_POSTALCODE>'
            || '<WORK_COUNTRYCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_COUNTRYCODE || ']]></WORK_COUNTRYCODE>'
            || '<WORK_REGIONNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_REGIONNAME || ']]></WORK_REGIONNAME>'
            || '<WORK_CITYCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_CITYCODE || ']]></WORK_CITYCODE>'
            || '<WORK_CITYNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_CITYNAME || ']]></WORK_CITYNAME>'
            || '<WORK_ADDRESSLINE1 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_ADDRESSLINE1 || ']]></WORK_ADDRESSLINE1>'
            || '<WORK_ADDRESSLINE2 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_ADDRESSLINE2 || ']]></WORK_ADDRESSLINE2>'
            || '<WORK_ADDRESSLINE3 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_ADDRESSLINE3 || ']]></WORK_ADDRESSLINE3>'
            || '<REGIS_POSTALCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_POSTALCODE || ']]></REGIS_POSTALCODE>'
            || '<REGIS_COUNTRYCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_COUNTRYCODE || ']]></REGIS_COUNTRYCODE>'
            || '<REGIS_REGIONNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_REGIONNAME || ']]></REGIS_REGIONNAME>'
            || '<REGIS_CITYCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_CITYCODE || ']]></REGIS_CITYCODE>'
            || '<REGIS_CITYNAME xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_CITYNAME || ']]></REGIS_CITYNAME>'
            || '<REGIS_ADDRESSLINE1 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_ADDRESSLINE1 || ']]></REGIS_ADDRESSLINE1>'
            || '<REGIS_ADDRESSLINE2 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_ADDRESSLINE2 || ']]></REGIS_ADDRESSLINE2>'
            || '<REGIS_ADDRESSLINE3 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.REGIS_ADDRESSLINE3 || ']]></REGIS_ADDRESSLINE3>'
            || '<HOME_TEL_COUNTRYAREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_TEL_COUNTRYAREACODE || ']]></HOME_TEL_COUNTRYAREACODE>'
            || '<HOME_TEL_AREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_TEL_AREACODE || ']]></HOME_TEL_AREACODE>'
            || '<HOME_TEL_PHONENO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_TEL_PHONENO || ']]></HOME_TEL_PHONENO>'
            || '<HOME_TEL_EXTENSIONNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_TEL_EXTENSIONNO || ']]></HOME_TEL_EXTENSIONNO>'
            || '<WORK_TEL_COUNTRYAREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_TEL_COUNTRYAREACODE || ']]></WORK_TEL_COUNTRYAREACODE>'
            || '<WORK_TEL_AREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_TEL_AREACODE || ']]></WORK_TEL_AREACODE>'
            || '<WORK_TEL_PHONENO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_TEL_PHONENO || ']]></WORK_TEL_PHONENO>'
            || '<WORK_TEL_EXTENSIONNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_TEL_EXTENSIONNO || ']]></WORK_TEL_EXTENSIONNO>'
            || '<MOB_TEL_COUNTRYAREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MOB_TEL_COUNTRYAREACODE || ']]></MOB_TEL_COUNTRYAREACODE>'
            || '<MOB_TEL_AREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MOB_TEL_AREACODE || ']]></MOB_TEL_AREACODE>'
            || '<MOB_TEL_PHONENO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MOB_TEL_PHONENO || ']]></MOB_TEL_PHONENO>'
            || '<MOB_TEL_COUNTRYAREACODE2 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MOB_TEL_COUNTRYAREACODE2 || ']]></MOB_TEL_COUNTRYAREACODE2>' -- r_app.MOB_TEL_COUNTRYAREACODE2
            || '<MOB_TEL_AREACODE2 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MOB_TEL_AREACODE2 || ']]></MOB_TEL_AREACODE2>'
            || '<MOB_TEL_PHONENO2 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.MOB_TEL_PHONENO2 || ']]></MOB_TEL_PHONENO2>'
            || '<FAX_COUNTRYAREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.FAX_COUNTRYAREACODE || ']]></FAX_COUNTRYAREACODE>'           -- r_app.FAX_COUNTRYAREACODE
            || '<FAX_AREACODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.FAX_AREACODE || ']]></FAX_AREACODE>'
            || '<FAX_PHONENO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.FAX_PHONENO || ']]></FAX_PHONENO>'
            || '<FAX_EXTENSIONNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.FAX_EXTENSIONNO || ']]></FAX_EXTENSIONNO>'
            || '<HOME_MAILADDRESS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.HOME_MAILADDRESS || ']]></HOME_MAILADDRESS>'
            || '<WORK_MAILADDRESS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.WORK_MAILADDRESS || ']]></WORK_MAILADDRESS>'
            || '<EMAIL_ONLYFLAG xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.EMAIL_ONLYFLAG || ']]></EMAIL_ONLYFLAG>'
            || '<RESTORE_SUPPCARD_LIMITFLAG xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.RESTORE_SUPPCARD_LIMITFLAG || ']]></RESTORE_SUPPCARD_LIMITFLAG>'
            || '<SELECT_MOB_TEL  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.SELECT_MOB_TEL || ']]></SELECT_MOB_TEL>'
            || '<CREATE_NEW_BSCUSTOMER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || ls_new_bs_flag || ']]></CREATE_NEW_BSCUSTOMER>'
            || '<BANK_CODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || '01' || ']]></BANK_CODE>'
            || '<DEALER_CODE  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.DEALER_CODE || ']]></DEALER_CODE >'
            || '<EMBOSS_STR_OPT  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.EMBOSS_STRING_OPTION || ']]></EMBOSS_STR_OPT>'
            || '<PINEMBOSSFLAG  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppRequestType"><![CDATA[' || r_app.PIN_EMBOSS_FLAG || ']]></PINEMBOSSFLAG>');

      log_at ('0410 7057 -1');
      resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
      log_at ('0410 7057 -2');
      result := resp.doc.getstringval();
      log_at ('0410 7057 -3');

      result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/CCardAppResponseType"', '');
      result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr"', '');

      l_parser := DBMS_XMLPARSER.newParser;

      DBMS_XMLPARSER.parseclob(l_parser, result);
      l_doc := DBMS_XMLPARSER.getDocument(l_parser);
      l_nl := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode (l_doc), 'CCardAppReqResponse/CCardAppReqResult');

      FOR cur_emp IN 0 .. DBMS_XMLDOM.getLength (l_nl) - 1
      LOOP
         l_n := DBMS_XMLDOM.item (l_nl, cur_emp);
         -- Use XPATH syntax to assign values to he elements of the collection.
         DBMS_XSLPROCESSOR.valueOf(l_n, 'CARDNO', ps_newCardNo);
         DBMS_XSLPROCESSOR.valueOf(l_n, 'RESPONSE_CODE', ps_response_Code);
         DBMS_XSLPROCESSOR.valueOf(l_n, 'RESPONSE_DESC', ps_response_Desc);
         DBMS_XSLPROCESSOR.valueOf(l_n, 'PSEUDOCODE', ps_card_id);
         DBMS_XSLPROCESSOR.valueOf(l_n, 'BANSOFT_CUSTOMER_NO', ps_banksoft_no);
      --  DBMS_XSLPROCESSOR.valueOf(l_n, 'CRMNO ', ps_newpanno);
      END LOOP;
      Log_at ('cbs.pkg_credit_card', ps_newCardNo);

      ld_endtime := SYSDATE;
      Pkg_debit_Card.WS_LOG ('CREDIT_CARD_CREATE',
                             serviceUrl,
                             methodName,
                             ld_starttime,
                             ld_endtime,
                             ps_response_Code,
                             ps_response_Desc,
                             r_app.tx_no,
                             pn_app_id,
                             result,
                             REQ.BODY);
   EXCEPTION
      WHEN OTHERS THEN
         ROLLBACK;
         ps_response_Code := '999';
         ps_response_Desc := SQLCODE || ' ' || SQLERRM;
         Pkg_debit_Card.WS_LOG ('CREDIT_CARD_CREATE',
                                serviceUrl,
                                methodName,
                                ld_starttime,
                                ld_endtime,
                                '999',
                                SQLCODE || ' ' || SQLERRM,
                                r_app.tx_no,
                                pn_app_id,
                                result,
                                REQ.BODY);
   END;

   -------------------------CALL WS FOR UPDATE-------------------------------------------------------------------------------------------
   PROCEDURE SP_WS_PersonalInfoUpdate (pn_app_id                 NUMBER,
                                       pn_banksoft_no        IN  VARCHAR2,
                                       ps_response_code      OUT VARCHAR2,
                                       ps_response_desc      OUT VARCHAR2,
                                       ps_newcardno          OUT VARCHAR2,
                                       ps_newpanno           OUT VARCHAR2)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;

      CURSOR cur_app
      IS
         SELECT *
           FROM CBS_CREDIT_CARD_UPD_APP_TX
          WHERE app_id = pn_app_id;

      r_app                  cur_App%ROWTYPE;

      serviceUrl             VARCHAR2 (2000);
      soapAction             VARCHAR2 (2000);
      namespace              VARCHAR2 (2000);
      methodName             VARCHAR2 (2000);
      req                    Pkg_Soap.request;
      resp                   Pkg_Soap.response;
      result                 CLOB;                         --NVARCHAR2(32767);
      referenceId            INTEGER;

      l_parser               DBMS_XMLPARSER.Parser;
      l_doc                  DBMS_XMLDOM.DOMDocument;
      l_nl                   DBMS_XMLDOM.DOMNodeList;
      l_n                    DBMS_XMLDOM.DOMNode;

      ld_starttime           DATE;
      ld_endtime             DATE;

      ls_BS_WS_SERVICE_URL   VARCHAR2 (200);

   BEGIN
      pkg_parametre.deger ('BS_CWS_SERVICE_URL', ls_BS_WS_SERVICE_URL);

      FOR c_app IN cur_app
      LOOP
         r_app := c_app;
      END LOOP;

      ld_starttime := SYSDATE;

      serviceUrl := ls_BS_WS_SERVICE_URL;
      namespace := 'http://www.banksoft.com.tr';
      methodName := 'PersonalInfoUpdate';
      soapAction := namespace || '/KirgizDemirWS/' || methodName;
      namespace := 'xmlns="' || namespace || '"';

      req := Pkg_Soap.new_request(methodName, namespace);

      Pkg_Soap.ADD_PARAMETER (
         req,
         'PIT',
         NULL,
            '<CBSNO                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.CUSTOMER_NUMBER           || ']]></CBSNO>'
         || '<BSCUSTOMERNO              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || pn_banksoft_no                  || ']]></BSCUSTOMERNO>'                                   --BS Number
         || '<NAME                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.NAME                      || ']]></NAME>'
         || '<SURNAME                   xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.SURNAME                   || ']]></SURNAME>'
         || '<MIDDLE_NAME               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MIDDLE_NAME               || ']]></MIDDLE_NAME>'
         || '<EMBOSSNAME                xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.EMBOSSNAME                || ']]></EMBOSSNAME>'
         || '<BIRTH_DATE                xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.BIRTH_DATE                || ']]></BIRTH_DATE>'
         || '<GENDER                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.GENDER                    || ']]></GENDER>'
         || '<MOTHER_MAIDEN_NAME        xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MOTHER_MAIDEN_NAME        || ']]></MOTHER_MAIDEN_NAME>'
         || '<BIRTH_PLACETEXT           xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.BIRTH_PLACETEXT           || ']]></BIRTH_PLACETEXT>'
         || '<NATIONALITY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.NATIONALITY               || ']]></NATIONALITY>'
         || '<MARIAL_STATUS             xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MARIAL_STATUS             || ']]></MARIAL_STATUS>'
         || '<FATHER_NAME               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.FATHER_NAME               || ']]></FATHER_NAME>'
         || '<EMERGENCY_CALL_PERSON     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.EMERGENCYCALLPERSON       || ']]></EMERGENCY_CALL_PERSON>'
         || '<EMERGENCY_TEL_AREACODE    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.EMERGENCY_TEL_AREACODE    || ']]></EMERGENCY_TEL_AREACODE>'
         || '<EMERGENCY_TEL_PHONENO     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.EMERGENCY_TEL_PHONENO     || ']]></EMERGENCY_TEL_PHONENO>'
         || '<EMERGENCY_TEL_EXTENSIONNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.EMERGENCY_TEL_EXTENSIONNO || ']]></EMERGENCY_TEL_EXTENSIONNO>'
         || '<WORK_COMPANYNAME          xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WORK_COMPANYNAME          || ']]></WORK_COMPANYNAME>'
         || '<CARDSENDINGTYPE           xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.CARDSENDINGTYPE           || ']]></CARDSENDINGTYPE>'
         || '<CARDSENDINGPLACE          xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.CARDSENDINGPLACE          || ']]></CARDSENDINGPLACE>'
         || '<CARD_PINSENDINGBRANCH     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.CARD_PINSENDINGBRANCH     || ']]></CARD_PINSENDINGBRANCH>'
         || '<STATEMENTSENDADRESS       xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.STATEMENTSENDADRESS       || ']]></STATEMENTSENDADRESS>'
         || '<PINSENDINGTYPE            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.PINSENDINGTYPE            || ']]></PINSENDINGTYPE>'
         || '<PINSENDINGPLACE           xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.PINSENDINGPLACE           || ']]></PINSENDINGPLACE>'
         || '<RESIDENTFLAG              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.RESIDENTFLAG              || ']]></RESIDENTFLAG>'
         || '<IDTYPE                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.IDTYPE                    || ']]></IDTYPE>'
         || '<IDSERIES                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.IDSERIES                  || ']]></IDSERIES>'
         || '<IDSERIALNUMBER            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.IDSERIALNUMBER            || ']]></IDSERIALNUMBER>'
         || '<HADR1                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HADR1                     || ']]></HADR1>'
         || '<HADR2                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HADR2                     || ']]></HADR2>'
         || '<HADR3                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HADR3                     || ']]></HADR3>'
         || '<HDISTRICT                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HDISTRICT                 || ']]></HDISTRICT>'
         || '<HCITYCODE                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HCITYCODE                 || ']]></HCITYCODE>'
         || '<HCITYNAME                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HCITYNAME                 || ']]></HCITYNAME>'
         || '<HCOUNTRYCODE              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HCOUNTRYCODE              || ']]></HCOUNTRYCODE>'
         || '<HCOUNTRYNAME              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HCOUNTRYNAME              || ']]></HCOUNTRYNAME>'
         || '<HZIPCODE                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HZIPCODE                  || ']]></HZIPCODE>'
         || '<WADR1                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WADR1                     || ']]></WADR1>'
         || '<WADR2                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WADR2                     || ']]></WADR2>'
         || '<WADR3                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WADR3                     || ']]></WADR3>'
         || '<WDISTRICT                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WDISTRICT                 || ']]></WDISTRICT>'
         || '<WCITYCODE                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WCITYCODE                 || ']]></WCITYCODE>'
         || '<WCITYNAME                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WCITYNAME                 || ']]></WCITYNAME>'
         || '<WCOUNTRYCODE              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WCOUNTRYCODE              || ']]></WCOUNTRYCODE>'
         || '<WCOUNTRYNAME              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WCOUNTRYNAME              || ']]></WCOUNTRYNAME>'
         || '<WZIPCODE                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WZIPCODE                  || ']]></WZIPCODE>'
         || '<TADRACTIVE                xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRACTIVE                || ']]></TADRACTIVE>'
         || '<TADR1                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADR1                     || ']]></TADR1>'
         || '<TADR2                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADR2                     || ']]></TADR2>'
         || '<TADR3                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADR3                     || ']]></TADR3>'
         || '<TDISTRICT                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TDISTRICT                 || ']]></TDISTRICT>'
         || '<TCITYCODE                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TCITYCODE                 || ']]></TCITYCODE>'
         || '<TCITYNAME                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TCITYNAME                 || ']]></TCITYNAME>'
         || '<TCOUNTRYCODE              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TCOUNTRYCODE              || ']]></TCOUNTRYCODE>'
         || '<TCOUNTRYNAME              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TCOUNTRYNAME              || ']]></TCOUNTRYNAME>'
         || '<TZIPCODE                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TZIPCODE                  || ']]></TZIPCODE>'
         || '<TADRSTARTDAY              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRSTARTDAY              || ']]></TADRSTARTDAY>'
         || '<TADRSTARTMONTH            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRSTARTMONTH            || ']]></TADRSTARTMONTH>'
         || '<TADRSTARTYEAR             xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRSTARTYEAR             || ']]></TADRSTARTYEAR>'
         || '<TADRENDDAY                xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRENDDAY                || ']]></TADRENDDAY>'
         || '<TADRENDMONTH              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRENDMONTH              || ']]></TADRENDMONTH>'
         || '<TADRENDYEAR               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRENDYEAR               || ']]></TADRENDYEAR>'
         || '<TADRTYPE                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TADRTYPE                  || ']]></TADRTYPE>'
         || '<HTELCOUNTRY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HTELCOUNTRY               || ']]></HTELCOUNTRY>'
         || '<HTELAREA                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HTELAREA                  || ']]></HTELAREA>'
         || '<HTEL                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HTEL                      || ']]></HTEL>'
         || '<HTELEXT                   xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HTELEXT                   || ']]></HTELEXT>'
         || '<HFAXCOUNTRY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HFAXCOUNTRY               || ']]></HFAXCOUNTRY>'
         || '<HFAXAREA                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HFAXAREA                  || ']]></HFAXAREA>'
         || '<HFAX                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HFAX                      || ']]></HFAX>'
         || '<HEMAIL                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.HEMAIL                    || ']]></HEMAIL>'
         || '<WTELCOUNTRY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WTELCOUNTRY               || ']]></WTELCOUNTRY>'
         || '<WTELAREA                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WTELAREA                  || ']]></WTELAREA>'
         || '<WTEL                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WTEL                      || ']]></WTEL>'
         || '<WTELEXT                   xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WTELEXT                   || ']]></WTELEXT>'
         || '<WFAXCOUNTRY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WFAXCOUNTRY               || ']]></WFAXCOUNTRY>'
         || '<WFAXAREA                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WFAXAREA                  || ']]></WFAXAREA>'
         || '<WFAX                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WFAX                      || ']]></WFAX>'
         || '<WEMAIL                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.WEMAIL                    || ']]></WEMAIL>'
         || '<TTELCOUNTRY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TTELCOUNTRY               || ']]></TTELCOUNTRY>'
         || '<TTELAREA                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TTELAREA                  || ']]></TTELAREA>'
         || '<TTEL                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TTEL                      || ']]></TTEL>'
         || '<TTELEXT                   xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TTELEXT                   || ']]></TTELEXT>'
         || '<TFAXCOUNTRY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TFAXCOUNTRY               || ']]></TFAXCOUNTRY>'
         || '<TFAXAREA                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TFAXAREA                  || ']]></TFAXAREA>'
         || '<TFAX                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TFAX                      || ']]></TFAX>'
         || '<TEMAIL                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.TEMAIL                    || ']]></TEMAIL>'
         || '<MTELCOUNTRY               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MTELCOUNTRY               || ']]></MTELCOUNTRY>'
         || '<MTELAREA                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MTELAREA                  || ']]></MTELAREA>'
         || '<MTEL                      xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MTEL                      || ']]></MTEL>'
         || '<MTELCOUNTRY2              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MTELCOUNTRY2              || ']]></MTELCOUNTRY2>'
         || '<MTELAREA2                 xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MTELAREA2                 || ']]></MTELAREA2>'
         || '<MTEL2                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.MTEL2                     || ']]></MTEL2>'
         || '<USERID                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.USERID                    || ']]></USERID>' 
         || '<SELECT_MOB_TEL            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.SELECT_MOB_TEL            || ']]></SELECT_MOB_TEL>'
         || '<DEALER_CODE               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || r_app.USERID                    || ']]></DEALER_CODE>');

      resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
      result := resp.doc.getstringval();
      
      result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"', '');
      result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr"', '');

      l_parser := DBMS_XMLPARSER.newParser;

      DBMS_XMLPARSER.parseclob(l_parser, result);
      l_doc := DBMS_XMLPARSER.getDocument(l_parser);
      l_nl := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode(l_doc), 'PersonalInfoUpdateResponse/PersonalInfoUpdateResult');

      FOR cur_emp IN 0 .. DBMS_XMLDOM.getLength(l_nl) - 1
      LOOP
         l_n := DBMS_XMLDOM.item(l_nl, cur_emp);
         -- Use XPATH syntax to assign values to he elements of the collection.

         DBMS_XSLPROCESSOR.valueOf(l_n, 'RCODE', ps_response_Code);
         DBMS_XSLPROCESSOR.valueOf(l_n, 'RDESC', ps_response_Desc);
      END LOOP;

      ld_endtime := SYSDATE;

      Pkg_debit_Card.WS_LOG('CREDIT_CARD_UPDATE', serviceUrl, methodName, ld_starttime, ld_endtime, ps_response_Code, ps_response_Desc, r_app.tx_no, pn_app_id, result, REQ.BODY);
   EXCEPTION
      WHEN OTHERS THEN
         ROLLBACK;
         ps_response_Code := '999';
         ps_response_Desc := SQLCODE || ' ' || SQLERRM;
         Pkg_debit_Card.WS_LOG('CREDIT_CARD_UPD', serviceUrl, methodName, ld_starttime, ld_endtime, '999', SQLCODE || ' ' || SQLERRM, r_app.tx_no, pn_app_id, result, REQ.BODY);
   END;

   -----------------CARD CREATION PROCEDURE----------------------------------------------------------------------------------------------------

   PROCEDURE SP_CCARD_CREATE_APP_CALL_WS(pn_tx_no                  NUMBER,
                                         pn_musteri_no         IN  NUMBER,
                                         pn_card_holder_no     IN  NUMBER,
                                         pn_card_id_no         OUT VARCHAR2,
                                         pn_new_card_no        OUT VARCHAR2,
                                         ps_response_code      OUT VARCHAR2,
                                         ps_response_desc      OUT VARCHAR2,
                                         ps_banksoft_no        OUT VARCHAR2)
   IS
      l_CustomerNumber               VARCHAR2 (18);
      l_name                         VARCHAR2 (20);
      l_middleName                   VARCHAR2 (20);
      l_surname                      VARCHAR2 (20);
      l_embossName                   VARCHAR2 (26);
      l_dateOfBirth                  VARCHAR2 (8);
      l_gender                       VARCHAR2 (1);
      l_MOTHER_MAIDEN_NAME           VARCHAR2 (20);
      l_birth_place                  VARCHAR2 (25);
      l_nationalityCode              VARCHAR2 (2);
      l_maritialStatus               VARCHAR2 (2);
      l_PREVIOUS_SURNAME             VARCHAR2 (5);
      l_fatherName                   VARCHAR2 (20);
      l_photo_request                VARCHAR2 (1);
      l_EMERGENCY_CALL_PERSON        VARCHAR2 (36);
      l_EMERGENCY_TEL_AREACODE       VARCHAR2 (4);
      l_EMERGENCY_TEL_PHONENO        VARCHAR2 (9);
      l_EMERGENCY_TEL_EXTENSIONNO    VARCHAR2 (5);
      l_WORK_COMPANYNAME             VARCHAR2 (40);
      L_COMPANY_FLAG                 VARCHAR2 (1);
      L_COMPANY_NAME                 VARCHAR2 (40);
      L_COMPANY_EMBOSSNAME           VARCHAR2 (26);
      l_CARDSENDINGTYPE              VARCHAR2 (1);
      l_CARDSENDINGPLACE             VARCHAR2 (1);
      l_CARD_PINSENDINGBRANCH        VARCHAR2 (5);
      l_STATEMENTSENDADRESS          VARCHAR2 (1);
      l_PINSENDINGTYPE               VARCHAR2 (1);
      l_PINSENDINGPLACE              VARCHAR2 (1);
      l_branch_code                  VARCHAR2 (5);
      l_limit                        NUMBER;
      l_AUTOMATIC_PAYMENT            VARCHAR2 (1);
      l_PAYMENT_COLL_ACCOUNT_NO      VARCHAR2 (25);
      l_CUSTOMER_GROUP               VARCHAR2 (3);
      l_PRODUCT_CODE                 VARCHAR2 (10);
      l_PRICING_GROUP                VARCHAR2 (3);
      l_RISK_GROUP                   VARCHAR2 (3);
      l_STATEMENTCODE                VARCHAR2 (2);
      l_RESIDENTFLAG                 VARCHAR2 (1);
      l_ACCOUNTTYPE                  VARCHAR2 (1);
      l_CARDTYPE                     VARCHAR2 (1);
      l_PRIMARYCARD_NO               VARCHAR2 (16);
      l_SUPP_CARDLIMIT_MULTIPLIER    NUMBER;
      l_ENTERING_USER                VARCHAR2 (8);
      l_ID_TYPE                      VARCHAR2 (2);
      l_SERIES                       VARCHAR2 (15);

      l_SERIAL_NUMBER                VARCHAR2 (25);
      l_HOME_POSTALCODE              VARCHAR2 (7);
      l_HOME_COUNTRYCODE             VARCHAR2 (2);
      l_HOME_REGIONNAME              VARCHAR2 (25);
      l_HOME_CITYCODE                VARCHAR2 (3);
      l_HOME_CITYNAME                VARCHAR2 (25);
      l_HOME_ADDRESSLINE1            VARCHAR2 (40);
      l_HOME_ADDRESSLINE2            VARCHAR2 (40);
      l_HOME_ADDRESSLINE3            VARCHAR2 (40);
      l_WORK_POSTALCODE              VARCHAR2 (7);
      l_WORK_COUNTRYCODE             VARCHAR2 (2);
      l_WORK_REGIONNAME              VARCHAR2 (25);
      l_WORK_CITYCODE                VARCHAR2 (3);
      l_WORK_CITYNAME                VARCHAR2 (25);

      l_WORK_ADDRESSLINE1            VARCHAR2 (40);
      l_WORK_ADDRESSLINE2            VARCHAR2 (40);
      l_WORK_ADDRESSLINE3            VARCHAR2 (40);

      l_REGIS_POSTALCODE             VARCHAR2 (7);
      l_REGIS_COUNTRYCODE            VARCHAR2 (2);
      l_REGIS_REGIONNAME             VARCHAR2 (25);
      l_REGIS_CITYCODE               VARCHAR2 (3);
      l_REGIS_CITYNAME               VARCHAR2 (25);

      l_REGIS_ADDRESSLINE1           VARCHAR2 (40);
      l_REGIS_ADDRESSLINE2           VARCHAR2 (40);
      l_REGIS_ADDRESSLINE3           VARCHAR2 (40);

      l_HOME_TEL_COUNTRYAREACODE     VARCHAR2 (3);
      l_HOME_TEL_AREACODE            VARCHAR2 (4);
      l_HOME_TEL_PHONENO             VARCHAR2 (9);
      l_HOME_TEL_EXTENSIONNO         VARCHAR2 (5);
      l_WORK_TEL_COUNTRYAREACODE     VARCHAR2 (3);
      l_WORK_TEL_AREACODE            VARCHAR2 (4);
      l_WORK_TEL_PHONENO             VARCHAR2 (9);
      l_WORK_TEL_EXTENSIONNO         VARCHAR2 (5);
      l_MOB_TEL_COUNTRYAREACODE      VARCHAR2 (3);
      l_MOB_TEL_AREACODE             VARCHAR2 (4);
      l_MOB_TEL_PHONENO              VARCHAR2 (9);
      l_MOB_TEL_COUNTRYAREACODE2     VARCHAR2 (3);
      l_MOB_TEL_AREACODE2            VARCHAR2 (4);
      l_MOB_TEL_PHONENO2             VARCHAR2 (9);
      l_FAX_COUNTRYAREACODE          VARCHAR2 (3);
      l_FAX_AREACODE                 VARCHAR2 (4);
      l_FAX_PHONENO                  VARCHAR2 (9);
      l_FAX_EXTENSIONNO              VARCHAR2 (5);
      l_HOME_MAILADDRESS             VARCHAR2 (60);
      l_WORK_MAILADDRESS             VARCHAR2 (60);
      l_EMAIL_ONLYFLAG               VARCHAR2 (60);
      l_SELECT_MOB_TEL               VARCHAR2 (3);
      l_DEALER_CODE                  VARCHAR2 (50);

      pn_app_id                      NUMBER;
      l_SUPP_CARDINSTLIMIT_MULTIP    NUMBER;
      l_SUPP_CARD_CASHLIMIT_MULTIP   NUMBER;
      L_RESTORE_SUPPCARD_LIMITFLAG   VARCHAR2 (2);

      L_EMBOSS_STRING_OPTION         VARCHAR2 (1); --NURZALATA 04052018 CQ6038
      L_PIN_EMBOSS_FLAG              VARCHAR2 (1); --NURZALATA 04052018 CQ6038
   ---- pn_app_id
   BEGIN
      pn_app_id := pkg_genel.genel_kod_al('CBS_CARD_CREDIT_APP');

      BEGIN
         SELECT NVL((CARD_SEND_BRANCH_CODE), ' ') CARD_PINSENDINGBRANCH,
                NVL((BRANCH), ' ') branch_code,
                NVL((CREDIT_CARD_LIMIT), 0) CARD_LIMIT,
                NVL((AUTOMATIC_PAYMENT), 'Y') AUTOMATIC_PAYMENT,
                NVL((PAYMENT_COLLECTION_ACC_NO), ' ') PAYMENT_COLL_ACCOUNT_NO,
                NVL((CC_CUSTOMER_GROUP), ' ') CUSTOMER_GROUP,
                NVL((PRODUCT_CODE), ' ') PRODUCT_CODE,
                NVL((PRICING_GROUP), ' ') PRICING_GROUP,
                NVL((RISK_GROUP_CODE), ' ') RISK_GROUP,
                NVL((STATEMENT_CODE), ' ') STATEMENTCODE,
                NVL((ACCOUNT_TYPE), ' ') ACCOUNT_TYPE,
                NVL((CARD_TYPE), ' ') CARD_TYPE,
                NVL((PRIMARY_CARD_NO), ' ') PRIMARY_CARD_NO,
                NVL((SUPPL_CARD_LIMIT_MULTIPLIER), 0) SUPPL_CARD_LIMIT_MULTIPLIER,
                NVL((SUPP_CARD_CASHLIMIT_MULTIPLIER), 0) SUPP_CARD_CASHLIMIT_MULTIPLIER,
                NVL((SUPP_CARDINSTLIMIT_MULTIPLIER), 0) SUPP_CARDINSTLIMIT_MULTIPLIER,
                CARD_SENDING_TYPE CARD_SENDINGTYPE,
                CARD_SENDING_ADDRESS CARD_SENDINGPLACE,
                STATEMENT_ADRESS STATEMENT_SENDADRESS,
                PIN_SENDING_TYPE,
                PIN_SENDING_PLACE,
                RESTORE_SUPPCARD_LIMITFLAG,
                EMBOSS_NAME,
                Dealer_code,
                COMPANY_FLAG,                      --NURZALATA 04052018 CQ6038
                COMPANY_EMBOSS_NAME,               --NURZALATA 04052018 CQ6038
                EMBOSS_STRING_OPTION,              --NURZALATA 04052018 CQ6038
                PIN_EMBOSS_FLAG                   -- NURZALATA 04052018 CQ6038
           INTO l_CARD_PINSENDINGBRANCH,
                l_branch_code,
                l_LIMIT,
                l_AUTOMATIC_PAYMENT,
                l_PAYMENT_COLL_ACCOUNT_NO,
                l_CUSTOMER_GROUP,
                l_PRODUCT_CODE,
                l_PRICING_GROUP,
                l_RISK_GROUP,
                l_STATEMENTCODE,
                L_ACCOUNTTYPE,
                L_CARDTYPE,
                L_PRIMARYCARD_NO,
                L_SUPP_CARDLIMIT_MULTIPLIER,
                l_SUPP_CARD_CASHLIMIT_MULTIP,
                l_SUPP_CARDINSTLIMIT_MULTIP,
                l_CARDSENDINGTYPE,
                l_CARDSENDINGPLACE,
                L_STATEMENTSENDADRESS,
                L_PINSENDINGTYPE,
                L_PINSENDINGPLACE,
                L_RESTORE_SUPPCARD_LIMITFLAG,
                l_embossName,
                l_DEALER_CODE,
                L_COMPANY_FLAG,                    --NURZALATA 04052018 CQ6038
                L_COMPANY_EMBOSSNAME,              --NURZALATA 04052018 CQ6038
                L_EMBOSS_STRING_OPTION,            --NURZALATA 04052018 CQ6038
                L_PIN_EMBOSS_FLAG                  --NURZALATA 04052018 CQ6038
           FROM CBS_CREDIT_CARD_DEF
          WHERE tx_no = pn_tx_no;
      EXCEPTION
         WHEN OTHERS THEN
            log_at('CBS_CREDIT_CARD_DEF SELECT', SQLCODE, SQLERRM);
      END;

      ------------------------
      BEGIN
         SELECT LPAD(SUBSTR(musteri_no, 1, 13), 13, '0') customernumber,
                pkg_Debit_card.CYR2LAT(UPPER(SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, isim_eng, NULL), ' '), 1, 20))) custname,
                pkg_Debit_card.CYR2LAT(UPPER(SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, ikinci_isim_eng, NULL), ' '), 1, 20))) custmiddlename,
                pkg_Debit_card.CYR2LAT(UPPER(SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, soyadi_eng, NULL), ' '), 1, 20))) custsurname,
                /*     UPPER (pkg_Debit_card.CYR2LAT (    SUBSTR (    NVL (    DECODE (
                                        musteri_tipi_kod,
                                        1, (   CBS_MUSTERI.ISIM_ENG
                                            || ' '
                                            || CBS_MUSTERI.SOYADI_ENG),
                                        (SELECT EMBOSS_NAME
                                           FROM CBS_BUS_CREDIT_CARD_HOLDERS
                                          WHERE     customer_no = pn_musteri_no
                                                AND business_card_holder_no =
                                                       pn_card_holder_no)),   ' '),  1,  26)))                   embossname,*/
                SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, TO_CHAR(dogum_tarihi, 'YYYYMMDD'), NULL), ' '), 1, 8) dateofbirth,
                NVL(DECODE(DECODE(musteri_tipi_kod, 1, cinsiyet_kod, NULL), 'M', 'E', 'F', 'K', ' '), NULL) gender,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, anne_kizlik_soyadi, NULL))), 'XXX'), 1, 20)) mothermaidenname,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, dogum_yeri, NULL))), 'KR'), 1, 25)) placeofbirth,
                NVL(uyruk_kod, 'KG') nationalitycode,
                NVL(DECODE(musteri_tipi_kod, 1, DECODE(medeni_hal_kod, '1', 'BE', '2', 'EV', '3', 'BO', 'BE'), NULL), 'BE') marial_stat,
                ' ' PREVIOUS_SURNAME,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, baba_adi, NULL))), 'XXX'), 1, 20)) fathername,
                'N' photo_request,
                UPPER(SUBSTR(NVL(pkg_Debit_card.CYR2LAT(pkg_musteri.sf_musteri_adi(company_of_the_staff)), ' '), 1, 40)) WORKCOMPANY,
                --'N' Company_flag, --NURZALATA 04052018 CQ6038 removed company_flag as it is on first select is being setted
                ' ' Company_name,
                NVL(DECODE(cbs_musteri.yerlesim_kod, '1', 'Y', '2', 'N', ' '), ' ') Resident_flag,
                NVL(DECODE(musteri_tipi_kod, 1, DECODE(CBS_MUSTERI.kimlik_kod, '1', 'Y', '2', 'E', '3', 'P', ' '), NULL), ' ') IDTYPE,
                NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, NVL(CBS_MUSTERI.PASAPORT_NO, CBS_MUSTERI.EHLIYET_BELGE_NO), NULL))), ' ') biserial,
                NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, NUFUS_CUZDANI_SERI_NO, NULL))), ' ') binumber,
                DECODE(L_COMPANY_FLAG, 'N', ' ', L_COMPANY_EMBOSSNAME) COMPANY_EMBOSSNAME, --NURZALATA 04052018 CQ6038 COMPANY_EMBOSSNAME is setted when company_flag is Y, else COMPANY_EMBOSSNAME is blank
                NVL(DECODE(L_COMPANY_FLAG, 'N', ' ', L_EMBOSS_STRING_OPTION), ' ') EMBOSS_STRING_OPTION --NURZALATA 04052018 CQ6038 EMBOSS_STRING_OPTION is setted when company_flag is Y, else EMBOSS_STRING_OPTION is blank
           INTO l_CustomerNumber,
                l_name,
                l_middleName,
                l_surname,
                l_dateOfBirth,
                l_gender,
                l_MOTHER_MAIDEN_NAME,
                l_birth_place,
                l_nationalityCode,
                l_maritialStatus,
                l_PREVIOUS_SURNAME,
                l_fatherName,
                l_photo_request,
                l_WORK_COMPANYNAME,
                --L_COMPANY_FLAG --NURZALATA 04052018 CQ6038 removed company_flag as it is on first select is being setted
                L_COMPANY_NAME,
                l_RESIDENTFLAG,
                l_ID_TYPE,
                l_SERIES,
                l_SERIAL_NUMBER,
                L_COMPANY_EMBOSSNAME,
                L_EMBOSS_STRING_OPTION --NURZALATA 04052018 CQ6038 added emboss_string_option
           FROM cbs_musteri
          WHERE musteri_no = pn_musteri_no;
      END;

      ------------------------
      BEGIN
         SELECT SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(posta_kod)), ' '), 1, 7) HOME_POSTALCODE,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(ulke_kod)), ' '), 1, 2)) HOME_COUNTRYCODE,
                (SELECT UPPER(pkg_Debit_card.CYR2LAT(IL_ADI))
                   FROM CBS_IL_KODLARI
                  WHERE CBS_IL_KODLARI.IL_KODU = CBS_MUSTERI_ADRES.IL_KOD) HOME_REGIONNAME,
                UPPER(SUBSTR(NVL(TRIM(pkg_debit_Card.sf_bs_city_code (il_kod)), ' '), 1, 3)) HOME_CITYCODE,                               --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT( pkg_genel.sehir_adi_al_hatasiz (il_kod))), ' '), 1, 25)) HOME_CITYNAME,    --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 1, 40)) homeaddress1,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 41, 40)) homeaddress2,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 81, 40)) homeaddress3,
                SUBSTR(pkg_debit_Card.sf_country_code_formatted(ulke_tel_kod), 1, 3) HOME_TEL_COUNTRYAREACODE,
                SUBSTR(pkg_debit_Card.sf_tel_alan_kod_formatli(tel_alan_kod), 1, 4) HOME_TEL_AREACODE,
                SUBSTR(pkg_debit_Card.sf_phone_number_formatted(tel_no), 1, 9) HOME_TEL_PHONENO,
                SUBSTR(NVL(PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2), 1, 5) HOME_TEL_EXTENSIONNO,
                SUBSTR(NVL(FAX_EXTENSION_NO, ' '), 1, 5) FAX_EXTENSIONNO,
                SUBSTR(NVL(FAX_COUNTRY_CODE, ' '), 1, 2) FAX_COUNTRYAREACODE,
                NVL(SUBSTR(pkg_debit_Card.sf_tel_alan_kod_formatli (fax_alan_kod), 1, 4), ' ') FAX_AREACODE,
                NVL(SUBSTR(pkg_debit_Card.sf_phone_number_formatted (fax_no), 1, 9), ' ') FAX_PHONENO,
                SUBSTR(NVL(TRIM(EMERGENCY_CALL_PERSON), ' '), 1, 36),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_AREA_CODE), ' '), 1, 4),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_PHONE_NO), ' '), 1, 9),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_EXTENSION_NO), ' '), 1, 5),
                NVL(SUBSTR(pkg_debit_Card.sf_country_code_formatted(ulke_gsm_kod), 1, 3), ' ') mobilePhoneCountryCode,
                NVL(SUBSTR(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod), 1, 4), ' ') mobilePhoneRegionCode,
                NVL(SUBSTR(pkg_debit_Card.sf_phone_number_formatted(gsm_no), 1, 9), ' ') mobilePhone,
                NVL(SUBSTR(pkg_debit_card.sf_country_code_formatted(ulke_gsm_kod_2), 1, 3), ' ') foreignMobileCountryCode,
                NVL(SUBSTR(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod_2), 1, 4), ' ') foreignMobileRegionCode,
                NVL(SUBSTR(pkg_debit_Card.sf_phone_number_formatted(gsm_no_2), 1, 9), ' ') foreignMobilePhone,
                'N' EMAIL_ONLYFLAG,
                NVL(SUBSTR(NVL(EMAIL_FOR_CCARD_SYSTEM, EMAIL), 1, 60), ' ') HOME_MAILADDRESS
           INTO l_HOME_POSTALCODE,
                l_HOME_COUNTRYCODE,
                l_HOME_REGIONNAME,
                l_HOME_CITYCODE,
                L_HOME_CITYNAME,
                L_HOME_ADDRESSLINE1,
                L_HOME_ADDRESSLINE2,
                L_HOME_ADDRESSLINE3,
                l_HOME_TEL_COUNTRYAREACODE,
                l_HOME_TEL_AREACODE,
                l_HOME_TEL_PHONENO,
                L_HOME_TEL_EXTENSIONNO,
                L_FAX_EXTENSIONNO,
                L_FAX_COUNTRYAREACODE,
                L_FAX_AREACODE,
                L_FAX_PHONENO,
                l_EMERGENCY_CALL_PERSON,
                l_EMERGENCY_TEL_AREACODE,
                l_EMERGENCY_TEL_PHONENO,
                l_EMERGENCY_TEL_EXTENSIONNO,
                L_MOB_TEL_COUNTRYAREACODE,
                L_MOB_TEL_AREACODE,
                L_MOB_TEL_PHONENO,
                L_MOB_TEL_COUNTRYAREACODE2,
                L_MOB_TEL_AREACODE2,
                L_MOB_TEL_PHONENO2,
                L_EMAIL_ONLYFLAG,
                L_HOME_MAILADDRESS
           FROM CBS_MUSTERI_ADRES
          WHERE musteri_no = pn_musteri_no AND adres_kod = '1';
      EXCEPTION
         WHEN OTHERS THEN
            log_at ('CBS_MUSTERI_ADRES_HOME', SQLCODE, SQLERRM);
      END;

      BEGIN
         SELECT SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT (posta_kod)), ' '), 1, 7) workpostalcode,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT (ulke_kod)), ' '), 1, 2)) workcountry,
                (SELECT UPPER(pkg_Debit_card.CYR2LAT (IL_ADI))
                   FROM CBS_IL_KODLARI
                  WHERE CBS_IL_KODLARI.IL_KODU = CBS_MUSTERI_ADRES.IL_KOD) work_REGIONNAME,
                UPPER(SUBSTR(NVL(TRIM(pkg_debit_Card.sf_bs_city_code (il_kod)),' '), 1, 3)) workcitycode,                                --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz (il_kod))), ' '), 1, 25)) workcity,         --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 1, 40)) workaddress1,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 41, 40)) workaddress2,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 81, 40)) workaddress3,
                SUBSTR(NVL(PHONE_EXTENSION_NO_1, PHONE_EXTENSION_NO_2), 1, 5) WORK_TEL_EXTENSIONNO,
                /*      SUBSTR(NVL (FAX_EXTENSION_NO, ' '),1,5)                                                        FAX_EXTENSIONNO,
                        SUBSTR(NVL (FAX_COUNTRY_CODE, ' ') ,1,2)        FAX_COUNTRYAREACODE,
                             NVL (  SUBSTR ( pkg_debit_Card.sf_tel_alan_kod_formatli (fax_alan_kod),   1,  4),  ' ')            homefaxregioncode,
                      NVL (   SUBSTR (pkg_debit_Card.sf_phone_number_formatted (fax_no),  1,   9),   ' ')                   homefax,
                /*        SUBSTR( NVL (TRIM (EMERGENCY_CALL_PERSON), ' '),1,36),
                     SUBSTR(  NVL (TRIM (EMERGENCY_TEL_AREA_CODE), ' '),1,4),
                     SUBSTR(  NVL (TRIM (EMERGENCY_TEL_PHONE_NO), ' '),1,9),
                     SUBSTR(  NVL (TRIM (EMERGENCY_TEL_EXTENSION_NO), ' '),1,5),*/
                /*  NVL (       SUBSTR (       pkg_debit_Card.sf_country_code_formatted (ulke_gsm_kod), 1, 3), ' ')                  mobilePhoneCountryCode,
                         NVL (      SUBSTR (        pkg_debit_Card.sf_tel_alan_kod_formatli (gsm_alan_kod), 1, 4), ' ')                   mobilePhoneRegionCode,
                         NVL (      SUBSTR (pkg_debit_Card.sf_phone_number_formatted (gsm_no), 1, 9), ' ')                   mobilePhone,
                         NVL (    SUBSTR (     pkg_debit_card.sf_country_code_formatted (ulke_gsm_kod_2),    1,    3),           ' ')                   foreignMobileCountryCode,
                         NVL (    SUBSTR (       pkg_debit_Card.sf_tel_alan_kod_formatli ( gsm_alan_kod_2),   1,     4),           ' ')                   foreignMobileRegionCode,
                         NVL (        SUBSTR (        pkg_debit_Card.sf_phone_number_formatted (gsm_no_2),   1,    9),          ' ')                   foreignMobilePhone,*/
                'N' EMAIL_ONLYFLAG,
                NVL(SUBSTR(NVL(EMAIL_FOR_CCARD_SYSTEM, EMAIL), 1, 60), ' ') WORK_MAILADDRESS,
                SUBSTR(pkg_debit_Card.sf_country_code_formatted (ulke_tel_kod), 1, 3) homephonecountrycode,
                SUBSTR(pkg_debit_Card.sf_tel_alan_kod_formatli (tel_alan_kod), 1, 4) homephoneregioncode,
                SUBSTR(pkg_debit_Card.sf_tel_alan_no_formatli (tel_no), 1, 9) homephone
           INTO l_WORK_POSTALCODE,
                l_WORK_COUNTRYCODE,
                l_WORK_REGIONNAME,
                l_WORK_CITYCODE,
                l_WORK_CITYNAME,
                l_WORK_ADDRESSLINE1,
                l_WORK_ADDRESSLINE2,
                l_WORK_ADDRESSLINE3,
                L_WORK_TEL_EXTENSIONNO,
                /*  L_FAX_EXTENSIONNO,
                    L_FAX_COUNTRYAREACODE,
                    L_FAX_AREACODE,
                    L_FAX_PHONENO,*/
                /*  l_EMERGENCY_CALL_PERSON,
                    l_EMERGENCY_TEL_AREACODE,
                    l_EMERGENCY_TEL_PHONENO,
                    l_EMERGENCY_TEL_EXTENSIONNO,*/
                /*  L_MOB_TEL_COUNTRYAREACODE,
                    L_MOB_TEL_AREACODE,
                    L_MOB_TEL_PHONENO,
                    L_MOB_TEL_COUNTRYAREACODE2,
                    L_MOB_TEL_AREACODE2,
                    L_MOB_TEL_PHONENO2,*/
                L_EMAIL_ONLYFLAG,
                L_WORK_MAILADDRESS,
                l_WORK_TEL_COUNTRYAREACODE,
                l_WORK_TEL_AREACODE,
                l_WORK_TEL_PHONENO
           FROM CBS_MUSTERI_ADRES
          WHERE musteri_no = pn_musteri_no AND adres_kod = '2';
      EXCEPTION
         WHEN OTHERS THEN
            log_at ('CBS_MUSTERI_ADRES_WORK', SQLCODE, SQLERRM);
      END;

      BEGIN
         SELECT SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(posta_kod)), ' '), 1, 7) regispostalcode,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(ulke_kod)), ' '), 1, 2)) regiscountry,
                (SELECT UPPER(pkg_Debit_card.CYR2LAT(IL_ADI))
                   FROM CBS_IL_KODLARI
                  WHERE CBS_IL_KODLARI.IL_KODU = CBS_MUSTERI_ADRES.IL_KOD) regisREGIONNAME,
                UPPER(SUBSTR(NVL(TRIM(pkg_debit_Card.sf_bs_city_code(il_kod)), ' '), 1, 3)) regiscitycode,                               --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz (il_kod))), ' '), 1, 25)) regiscity,         --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 1, 40)) regisaddress1,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 41, 40)) regisaddress2,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ' '), 81, 40)) regisaddress3
           /*    NVL (TRIM (EMERGENCY_CALL_PERSON), ' '),
                NVL (TRIM (EMERGENCY_TEL_AREA_CODE), ' '),
                NVL (TRIM (EMERGENCY_TEL_PHONE_NO), ' '),
                NVL (TRIM (EMERGENCY_TEL_EXTENSION_NO), ' '),
                NVL (       SUBSTR (       pkg_debit_Card.sf_country_code_formatted (ulke_gsm_kod),      1,       3),   ' ')                  mobilePhoneCountryCode,
                NVL (      SUBSTR (        pkg_debit_Card.sf_tel_alan_kod_formatli (gsm_alan_kod),        1,        3),    ' ')                   mobilePhoneRegionCode,
                NVL (      SUBSTR (pkg_debit_Card.sf_tel_alan_no_formatli (gsm_no),                    1,          6),         ' ')                   mobilePhone,
                NVL (    SUBSTR (     pkg_debit_card.sf_country_code_formatted (ulke_gsm_kod_2),    1,    3),           ' ')                   foreignMobileCountryCode,
                NVL (    SUBSTR (       pkg_debit_Card.sf_tel_alan_kod_formatli ( gsm_alan_kod_2),   1,     3),           ' ')                   foreignMobileRegionCode,
                NVL (        SUBSTR (        pkg_debit_Card.sf_phone_number_formatted (gsm_no_2),   1,    6),          ' ')                   foreignMobilePhone,*/
           --     'N' EMAIL_ONLYFLAG,
           --  NVL (    SUBSTR ( nvl( EMAIL_FOR_CCARD_SYSTEM,EMAIL),  1, 60),  ' ')           WORK_MAILADDRESS
           INTO l_REGIS_POSTALCODE,
                l_REGIS_COUNTRYCODE,
                l_REGIS_REGIONNAME,
                l_REGIS_CITYCODE,
                l_REGIS_CITYNAME,
                l_REGIS_ADDRESSLINE1,
                l_REGIS_ADDRESSLINE2,
                l_REGIS_ADDRESSLINE3
           /*  l_EMERGENCY_CALL_PERSON,
               l_EMERGENCY_TEL_AREACODE,
               l_EMERGENCY_TEL_PHONENO,
               l_EMERGENCY_TEL_EXTENSIONNO,
               L_MOB_TEL_COUNTRYAREACODE,
               L_MOB_TEL_AREACODE,
               L_MOB_TEL_PHONENO,
               L_MOB_TEL_COUNTRYAREACODE2,
               L_MOB_TEL_AREACODE2,
               L_EMAIL_ONLYFLAG,*/
           --  L_MOB_TEL_PHONENO2,
           --  L_HOME_MAILADDRESS
           FROM CBS_MUSTERI_ADRES
          WHERE musteri_no = pn_musteri_no AND adres_kod = '3';
      EXCEPTION
         WHEN OTHERS THEN
            log_at ('CBS_MUSTERI_ADRES_REGIS', SQLCODE, SQLERRM);
      END;

      --  GET INFO FROM BUSINESS CARD HOLDERS TABLE --
      /*  If pn_card_holder_no is not null then
        BEGIN
        SELECT NVL (TRIM (EMERGENCY_CALL_PERSON), ' '),
                  NVL (TRIM (EMERGENCY_TEL_AREACODE), ' '),
                  NVL (TRIM (EMERGENCY_TEL_PHONENO), ' '),
                  NVL (TRIM (EMERGENCY_TEL_EXTENSIONNO), ' '),
                  NVL (HOME_TEL_EXTENSIONNO, ' ') PHONE_EXTENSION_NO_1,
                  '' PHONE_EXTENSION_NO_2,
                  NVL (FAX_EXTENSIONNO, ' ') PHONE_EXTENSION_NO_3,
                  NVL (MOB_TEL_COUNTRYAREACODE,   ' ')                  mobilePhoneCountryCode,
                  NVL (     MOB_TEL_AREACODE,    ' ')                   mobilePhoneRegionCode,
                  NVL (     MOB_TEL_PHONENO,         ' ')                   mobilePhone,
                  NVL (   MOB_TEL_COUNTRYAREACODE2,           ' ')                   foreignMobileCountryCode,
                  NVL ( MOB_TEL_AREACODE2,           ' ')                   foreignMobileRegionCode,
                  NVL (  MOB_TEL_PHONENO2,          ' ')                   foreignMobilePhone,
                  NVL (FAX_COUNTRYAREACODE, ' ')         FAX_COUNTRY_CODE,
                  NVL (  FAX_AREACODE,  ' ')            homefaxregioncode,
                  NVL (   FAX_PHONENO,   ' ')                   homefax,
                  ' '         HOME_MAILADDRESS,
                  NVL (    SUBSTR (  WORK_MAILADDRESS,  1, 60),  ' ')           WORK_MAILADDRESS,
                  'N' EMAIL_ONLYFLAG,
                        NVL (    HOME_POSTALCODE, ' ')  ,
                         NVL ( HOME_COUNTRYCODE, ' ')  ,
                         NVL ( HOME_REGIONNAME, ' ') ,
                         NVL (  HOME_CITYCODE, ' ')    ,
                         NVL (  HOME_CITYNAME, ' ')    ,
                         NVL (  HOME_ADDRESSLINE1, ' ')    ,
                         NVL (   HOME_ADDRESSLINE2 ,' ')    ,
                         SUBSTR (  pkg_debit_Card.sf_country_code_formatted (HOME_TEL_COUNTRYAREACODE), 1,   3)                HOME_TEL_COUNTRYAREACODE,
                         SUBSTR ( pkg_debit_Card.sf_tel_alan_kod_formatli (HOME_TEL_AREACODE),  1,     4)                 HOME_TEL_AREACODE,
                         SUBSTR (pkg_debit_Card.sf_phone_number_formatted (HOME_TEL_PHONENO),  1,   9)                       HOME_TEL_PHONENO

             INTO
                  l_EMERGENCY_CALL_PERSON,
                  l_EMERGENCY_TEL_AREACODE,
                  l_EMERGENCY_TEL_PHONENO,
                  l_EMERGENCY_TEL_EXTENSIONNO,
                  L_HOME_TEL_EXTENSIONNO,
                  L_WORK_TEL_EXTENSIONNO,
                  L_FAX_EXTENSIONNO,
                  L_MOB_TEL_COUNTRYAREACODE,
                  L_MOB_TEL_AREACODE,
                  L_MOB_TEL_PHONENO,
                  L_MOB_TEL_COUNTRYAREACODE2,
                  L_MOB_TEL_AREACODE2,
                  L_MOB_TEL_PHONENO2,
                  L_FAX_COUNTRYAREACODE,
                  L_FAX_AREACODE,
                  L_FAX_PHONENO,
                  L_HOME_MAILADDRESS,
                  L_WORK_MAILADDRESS,
                  L_EMAIL_ONLYFLAG,
                   l_HOME_POSTALCODE,
                  l_HOME_COUNTRYCODE,
                  l_HOME_REGIONNAME,
                  l_HOME_CITYCODE,
                  L_HOME_CITYNAME,
                  L_HOME_ADDRESSLINE1,
                  L_HOME_ADDRESSLINE2,
                  l_HOME_TEL_COUNTRYAREACODE,
                  l_HOME_TEL_AREACODE,
                  l_HOME_TEL_PHONENO

               FROM CBS_BUS_CREDIT_CARD_HOLDERS
            WHERE BUSINESS_CARD_HOLDER_NO = pn_card_holder_no;
        EXCEPTION
           WHEN OTHERS
           THEN
                  log_at('CBS_BUS_CREDIT_CARD_HOLDERS',sqlcode,sqlerrm);
        END;
        end if;*/

      BEGIN
         SELECT DEFAULT_MOBILE_PHONE
           INTO l_SELECT_MOB_TEL
           FROM CBS_MUSTERI_BASVURU
          WHERE musteri_no = pn_musteri_no;
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
      END;

      sp_ins_Credit_Card_app_Tx(pn_app_id,
                                pn_tx_no,
                                pn_musteri_no,
                                l_CustomerNumber,
                                LPAD(SUBSTR(pn_app_id, 1, 14), 14, '0'),
                                L_name,
                                L_middleName,
                                L_surname,
                                L_embossName,
                                NVL(l_dateOfBirth, '19000101'),
                                NVL(L_gender, 'E'),
                                NVL(L_MOTHER_MAIDEN_NAME, 'XXX'),
                                NVL(L_birth_place, 'KR'),
                                NVL(l_nationalityCode, 'KG'),
                                NVL(l_maritialStatus, 'BE'),
                                L_PREVIOUS_SURNAME,
                                NVL(l_fatherName, 'XXX'),
                                NVL(L_photo_request, 'N'),
                                L_EMERGENCY_CALL_PERSON,
                                NVL(L_EMERGENCY_TEL_AREACODE, ' '),
                                NVL(L_EMERGENCY_TEL_PHONENO, ' '),
                                NVL(L_EMERGENCY_TEL_EXTENSIONNO, ' '),
                                L_WORK_COMPANYNAME,
                                NVL(L_COMPANY_FLAG, 'N'),
                                L_COMPANY_NAME,
                                L_COMPANY_EMBOSSNAME,
                                l_CARDSENDINGTYPE,
                                L_CARDSENDINGPLACE,
                                NVL(L_CARD_PINSENDINGBRANCH, ' '),
                                NVL(L_STATEMENTSENDADRESS, ' '),
                                NVL(L_PINSENDINGTYPE, ' '),
                                NVL(L_PINSENDINGPLACE, ' '),
                                NVL(L_branch_code, ' '),
                                NVL(L_Limit, 0),
                                NVL(L_AUTOMATIC_PAYMENT, 'Y'),
                                NVL(l_PAYMENT_COLL_ACCOUNT_NO, ' '),
                                NVL(L_CUSTOMER_GROUP, ' '),
                                NVL(L_PRODUCT_CODE, ' '),
                                NVL(L_PRICING_GROUP, ' '),
                                NVL(L_RISK_GROUP, ' '),
                                NVL(L_STATEMENTCODE, ' '),
                                NVL(L_RESIDENTFLAG, ' '),
                                NVL(L_ACCOUNTTYPE, ' '),
                                NVL(L_CARDTYPE, ' '),
                                NVL(L_PRIMARYCARD_NO, NULL),
                                NVL(L_SUPP_CARDLIMIT_MULTIPLIER, 0),
                                NVL(l_SUPP_CARDINSTLIMIT_MULTIP, 0),
                                NVL(l_SUPP_CARD_CASHLIMIT_MULTIP, 0),
                                SUBSTR(USER, 1, 8), --CQ5794 KonstantinJ 11052017
                                L_ID_TYPE,
                                LPAD(NVL(L_SERIES, ''), 10, '0'),
                                LPAD(NVL(L_SERIAL_NUMBER, ''), 10, '0'),
                                NVL(L_HOME_POSTALCODE, ' '),
                                NVL(L_HOME_COUNTRYCODE, ' '),
                                NVL(L_HOME_REGIONNAME, ' '),
                                NVL(L_HOME_CITYCODE, ' '),
                                NVL(L_HOME_CITYNAME, ' '),
                                NVL(L_HOME_ADDRESSLINE1, ' '),
                                NVL(L_HOME_ADDRESSLINE2, ' '),
                                NVL(L_HOME_ADDRESSLINE3, ' '),
                                NVL(L_WORK_POSTALCODE, ' '),
                                NVL(L_WORK_COUNTRYCODE, ' '),
                                NVL(L_WORK_REGIONNAME, ' '),
                                NVL(L_WORK_CITYCODE, ' '),
                                NVL(L_WORK_CITYNAME, ' '),
                                NVL(L_WORK_ADDRESSLINE1, ' '),
                                NVL(L_WORK_ADDRESSLINE2, ' '),
                                NVL(L_WORK_ADDRESSLINE3, ' '),
                                NVL(L_REGIS_POSTALCODE, ' '),
                                NVL(L_REGIS_COUNTRYCODE, ' '),
                                NVL(L_REGIS_REGIONNAME, ' '),
                                NVL(L_REGIS_CITYCODE, ' '),
                                NVL(L_REGIS_CITYNAME, ' '),
                                NVL(L_REGIS_ADDRESSLINE1, ' '),
                                NVL(L_REGIS_ADDRESSLINE2, ' '),
                                NVL(L_REGIS_ADDRESSLINE3, ' '),
                                NVL(L_HOME_TEL_COUNTRYAREACODE, ' '),
                                NVL(L_HOME_TEL_AREACODE, ' '),
                                NVL(L_HOME_TEL_PHONENO, ' '),
                                NVL(L_HOME_TEL_EXTENSIONNO, ' '),
                                NVL(L_WORK_TEL_COUNTRYAREACODE, ' '),
                                NVL(L_WORK_TEL_AREACODE, ' '),
                                NVL(L_WORK_TEL_PHONENO, ' '),
                                NVL(L_WORK_TEL_EXTENSIONNO, ' '),
                                NVL(L_MOB_TEL_COUNTRYAREACODE, ' '),
                                NVL(L_MOB_TEL_AREACODE, ' '),
                                NVL(L_MOB_TEL_PHONENO, ' '),
                                NVL(L_MOB_TEL_COUNTRYAREACODE2, ' '),
                                NVL(L_MOB_TEL_AREACODE2, ' '),
                                NVL(L_MOB_TEL_PHONENO2, ' '),
                                NVL(L_FAX_COUNTRYAREACODE, ' '),
                                NVL(L_FAX_AREACODE, ' '),
                                NVL(L_FAX_PHONENO, ' '),
                                NVL(L_FAX_EXTENSIONNO, ' '),
                                NVL(L_HOME_MAILADDRESS, ' '),
                                NVL(L_WORK_MAILADDRESS, ' '),
                                NVL(L_EMAIL_ONLYFLAG, 'N'),
                                NVL(pn_card_holder_no, ''),
                                L_RESTORE_SUPPCARD_LIMITFLAG,
                                l_SELECT_MOB_TEL,
                                l_DEALER_CODE,
                                L_pin_emboss_flag,       --NURZALATA 04052018 CQ6038
                                L_emboss_string_option); --NURZALATA 04052018 CQ6038

      pkg_credit_card.SP_WS_CCardAppReq(pn_app_id,
                                        ps_response_code,
                                        ps_response_desc,
                                        pn_new_card_no,
                                        pn_card_id_no,
                                        ps_banksoft_no);

      sp_upd_credit_Card_app_islem('CREATE',
                                   pn_app_id,
                                   pn_card_holder_no,
                                   ps_response_code,
                                   ps_response_desc,
                                   pn_new_card_no,
                                   pn_card_id_no,
                                   ps_banksoft_no);
   EXCEPTION
      WHEN OTHERS THEN
         log_at('SP_CCARD_CREATE_APP_CALL_WS ERROR', SQLCODE, SQLERRM);
         raise_application_error(-20100, pkg_hata.getucpointer || '6697' || pkg_hata.getdelimiter || 'Customer No:' || pn_musteri_no || TO_CHAR (SQLCODE) || ' ' || SQLERRM  || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   END;

   PROCEDURE sp_upd_credit_card_app_islem(ps_option_type       VARCHAR2,
                                          pn_app_id            NUMBER,
                                          pn_card_holder_no    NUMBER,
                                          ps_response_code     VARCHAR2,
                                          ps_response_desc     VARCHAR2,
                                          ps_newcardno         VARCHAR2 DEFAULT NULL,
                                          ps_newpanno          VARCHAR2 DEFAULT NULL,
                                          ps_banksoft_no       VARCHAR2 DEFAULT NULL)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      IF ps_option_type IN ('CREATE') THEN
         UPDATE CBS_CREDIT_CARD_APP_TX
            SET response_code = ps_response_code,
                response_desc = ps_response_desc,
                response_date = SYSDATE,
                card_No = TRIM(ps_newcardno),
                card_id_no = TRIM(ps_newpanno),
                BANKSOFT_NO = TRIM(ps_banksoft_no)
          WHERE app_id = pn_app_id;
      /*update CBS_BUS_CREDIT_CARD_HOLDERS
         set  BANKSOFT_CUSTOMER_NO = trim(ps_banksoft_no)
                where BUSINESS_CARD_HOLDER_NO = pn_card_holder_no;*/
      ELSE
         UPDATE CBS_CREDIT_CARD_UPD_APP_TX
            SET response_code = ps_response_code,
                response_desc = ps_response_desc,
                response_date = SYSDATE
          WHERE app_id = pn_app_id;
      END IF;

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         ROLLBACK;
         log_at('sp_upd_credit_card_app_islem-ERROR', pn_app_id, SQLCODE || ' ' || SQLERRM);
   END;

   -------------- --- UPDATE CREDIT CARD PRUCEDURE ---------- -------------------------------------

   PROCEDURE SP_CCARD_UPDATE_APP_CALL_WS(pn_tx_no                  NUMBER,
                                         pn_musteri_no         IN  NUMBER,
                                         pn_card_holder_no         NUMBER,
                                         pn_banksoft_no        IN  VARCHAR2,
                                         ps_response_code      OUT VARCHAR2,
                                         ps_response_desc      OUT VARCHAR2)
   IS
      L_CBSNO                       VARCHAR2 (20 BYTE);
      L_NAME                        VARCHAR2 (20 BYTE);
      L_SURNAME                     VARCHAR2 (20 BYTE);
      L_MIDDLE_NAME                 VARCHAR2 (20 BYTE);
      L_EMBOSSNAME                  VARCHAR2 (26 BYTE);
      L_BIRTH_DATE                  VARCHAR2 (8 BYTE);
      L_GENDER                      VARCHAR2 (2 BYTE);
      L_MOTHER_MAIDEN_NAME          VARCHAR2 (20 BYTE);
      L_BIRTH_PLACETEXT             VARCHAR2 (25 BYTE);
      L_NATIONALITY                 VARCHAR2 (2 BYTE);
      L_MARIAL_STATUS               VARCHAR2 (2 BYTE);
      L_FATHER_NAME                 VARCHAR2 (20 BYTE);
      L_EMERGENCYCALLPERSON         VARCHAR2 (36 BYTE);
      L_EMERGENCY_TEL_AREACODE      VARCHAR2 (4 BYTE);
      L_EMERGENCY_TEL_PHONENO       VARCHAR2 (9 BYTE);
      L_EMERGENCY_TEL_EXTENSIONNO   VARCHAR2 (5 BYTE);
      L_WORK_COMPANYNAME            VARCHAR2 (40 BYTE);
      L_CARDSENDINGTYPE             VARCHAR2 (1 BYTE);
      L_CARDSENDINGPLACE            VARCHAR2 (1 BYTE);
      L_CARD_PINSENDINGBRANCH       VARCHAR2 (5 BYTE);
      L_STATEMENTSENDADRESS         VARCHAR2 (1 BYTE);
      L_PINSENDINGTYPE              VARCHAR2 (1 BYTE);
      L_PINSENDINGPLACE             VARCHAR2 (1 BYTE);
      L_RESIDENTFLAG                VARCHAR2 (1 BYTE);
      L_IDTYPE                      VARCHAR2 (2 BYTE);
      L_IDSERIES                    VARCHAR2 (15 BYTE);
      L_IDSERIALNUMBER              VARCHAR2 (25 BYTE);
      L_HADR1                       VARCHAR2 (40 BYTE);
      L_HADR2                       VARCHAR2 (40 BYTE);
      L_HADR3                       VARCHAR2 (40 BYTE);
      L_HDISTRICT                   VARCHAR2 (25 BYTE);
      L_HCITYCODE                   VARCHAR2 (3 BYTE);
      L_HCITYNAME                   VARCHAR2 (25 BYTE);
      L_HCOUNTRYCODE                VARCHAR2 (3 BYTE);
      L_HCOUNTRYNAME                VARCHAR2 (25 BYTE);
      L_HZIPCODE                    VARCHAR2 (8 BYTE);
      L_WADR1                       VARCHAR2 (40 BYTE);
      L_WADR2                       VARCHAR2 (40 BYTE);
      L_WADR3                       VARCHAR2 (40 BYTE);
      L_WDISTRICT                   VARCHAR2 (25 BYTE);
      L_WCITYCODE                   VARCHAR2 (3 BYTE);
      L_WCITYNAME                   VARCHAR2 (25 BYTE);
      L_WCOUNTRYCODE                VARCHAR2 (3 BYTE);
      L_WCOUNTRYNAME                VARCHAR2 (25 BYTE);
      L_WZIPCODE                    VARCHAR2 (8 BYTE);
      L_TADRACTIVE                  VARCHAR2 (1 BYTE);
      L_TADR1                       VARCHAR2 (40 BYTE);
      L_TADR2                       VARCHAR2 (40 BYTE);
      L_TADR3                       VARCHAR2 (40 BYTE);
      L_TDISTRICT                   VARCHAR2 (25 BYTE);
      L_TCITYCODE                   VARCHAR2 (3 BYTE);
      L_TCITYNAME                   VARCHAR2 (25 BYTE);
      L_TCOUNTRYCODE                VARCHAR2 (3 BYTE);
      L_TCOUNTRYNAME                VARCHAR2 (25 BYTE);
      L_TZIPCODE                    VARCHAR2 (8 BYTE);
      L_TADRSTARTDAY                VARCHAR2 (2 BYTE);
      L_TADRSTARTMONTH              VARCHAR2 (2 BYTE);
      L_TADRSTARTYEAR               VARCHAR2 (2 BYTE);
      L_TADRENDDAY                  VARCHAR2 (2 BYTE);
      L_TADRENDMONTH                VARCHAR2 (2 BYTE);
      L_TADRENDYEAR                 VARCHAR2 (2 BYTE);
      L_TADRTYPE                    VARCHAR2 (2 BYTE);
      L_HTELCOUNTRY                 VARCHAR2 (3 BYTE);
      L_HTELAREA                    VARCHAR2 (4 BYTE);
      L_HTEL                        VARCHAR2 (20 BYTE);
      L_HTELEXT                     VARCHAR2 (6 BYTE);
      L_HFAXCOUNTRY                 VARCHAR2 (3 BYTE);
      L_HFAXAREA                    VARCHAR2 (4 BYTE);
      L_HFAX                        VARCHAR2 (20 BYTE);
      L_HEMAIL                      VARCHAR2 (40 BYTE);
      L_WTELCOUNTRY                 VARCHAR2 (3 BYTE);
      L_WTELAREA                    VARCHAR2 (4 BYTE);
      L_WTEL                        VARCHAR2 (20 BYTE);
      L_WTELEXT                     VARCHAR2 (6 BYTE);
      L_WFAXCOUNTRY                 VARCHAR2 (3 BYTE);
      L_WFAXAREA                    VARCHAR2 (4 BYTE);
      L_WFAX                        VARCHAR2 (20 BYTE);
      L_WEMAIL                      VARCHAR2 (40 BYTE);
      L_TTELCOUNTRY                 VARCHAR2 (3 BYTE);
      L_TTELAREA                    VARCHAR2 (4 BYTE);
      L_TTEL                        VARCHAR2 (20 BYTE);
      L_TTELEXT                     VARCHAR2 (6 BYTE);
      L_TFAXCOUNTRY                 VARCHAR2 (3 BYTE);
      L_TFAXAREA                    VARCHAR2 (4 BYTE);
      L_TFAX                        VARCHAR2 (20 BYTE);
      L_TEMAIL                      VARCHAR2 (40 BYTE);
      L_MTELCOUNTRY                 VARCHAR2 (3 BYTE);
      L_MTELAREA                    VARCHAR2 (4 BYTE);
      L_MTEL                        VARCHAR2 (20 BYTE);
      L_MTELCOUNTRY2                VARCHAR2 (3 BYTE);
      L_MTELAREA2                   VARCHAR2 (4 BYTE);
      L_MTEL2                       VARCHAR2 (20 BYTE);
      L_UserID                      VARCHAR2 (8 BYTE);
      ps_newcardno                  VARCHAR2 (2000);
      ps_newpanno                   VARCHAR2 (2000);

      pn_app_id                     NUMBER;
      l_CustomerNumber              VARCHAR2 (18);
      l_SELECT_MOB_TEL              VARCHAR2 (50);

   ----
   BEGIN
      pn_app_id := pkg_genel.genel_kod_al ('CBS_CARD_CREDIT_APP');

      BEGIN
         SELECT LPAD(SUBSTR(musteri_no, 1, 13), 13, '0') customernumber,
                pkg_Debit_card.CYR2LAT(UPPER(SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, isim_eng, NULL), ''), 1, 20))) custname,
                pkg_Debit_card.CYR2LAT(UPPER(SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, ikinci_isim_eng, NULL), ''), 1, 20))) custmiddlename,
                pkg_Debit_card.CYR2LAT(UPPER(SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, soyadi_eng, NULL), ''), 1, 20))) custsurname,
                UPPER(pkg_Debit_card.CYR2LAT(SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, (CBS_MUSTERI.ISIM_ENG || ' ' || CBS_MUSTERI.SOYADI_ENG), NULL), ''), 1, 26))) embossname,
                SUBSTR(NVL(DECODE(musteri_tipi_kod, 1, TO_CHAR(dogum_tarihi, 'YYYYMMDD'), NULL), ''), 1, 8) dateofbirth,
                NVL(DECODE(DECODE(musteri_tipi_kod, 1, cinsiyet_kod, NULL), 'M', 'E', 'F', 'K', ' '), '') gender,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, anne_kizlik_soyadi, NULL))), ''), 1, 20)) mothermaidenname,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, dogum_yeri, NULL))), ''), 1, 25)) placeofbirth,
                NVL(uyruk_kod, '') nationalitycode,
                NVL(DECODE(musteri_tipi_kod, 1, DECODE(medeni_hal_kod,
                                 '1', 'BE',
                                 '2', 'EV',
                                 '3', 'BO',
                                 'BE'), NULL), 'BE') maritialstatus,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, baba_adi, NULL))), ''), 1, 20)) fathername,
                UPPER(SUBSTR(NVL(pkg_report4.cyr2lat_rub(pkg_musteri.sf_musteri_adi(cbs_musteri.company_of_the_staff)), ''), 1, 40)) workplace,
                '' CARD_SENDINGTYPE,
                '' CARD_SENDINGPLACE,
                '' STATEMENT_SEND_ADRESS,
                '' PINSENDINGTYPE,
                '' PINSENDINGPLACE,
                NVL(DECODE(cbs_musteri.yerlesim_kod, '1', 'Y', '2', 'N', ' '), '') Resident_flag,
                NVL(DECODE(musteri_tipi_kod, 1, DECODE(CBS_MUSTERI.kimlik_kod,
                                 '1', 'Y',
                                 '2', 'E',
                                 '3', 'P', 
                                 ' '), NULL), '') idtypeemployee,
                SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, NVL(CBS_MUSTERI.PASAPORT_NO, CBS_MUSTERI.EHLIYET_BELGE_NO), NULL))), ''), 1, 15) biserial,
                SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(DECODE(musteri_tipi_kod, 1, NUFUS_CUZDANI_SERI_NO, NULL))), ''), 1, 25) binumber,
                SUBSTR(USER, 1, 8)             -- CQ5794 KonstantinJ 11052017
           INTO l_CustomerNumber,
                L_NAME,
                L_MIDDLE_NAME,
                L_SURNAME,
                l_embossName,
                l_birth_date,
                l_gender,
                l_MOTHER_MAIDEN_NAME,
                L_BIRTH_PLACETEXT,
                l_NATIONALITY,
                l_MARIAL_STATUS,
                l_father_Name,
                l_WORK_COMPANYNAME,
                l_CARDSENDINGTYPE,
                l_CARDSENDINGPLACE,
                L_STATEMENTSENDADRESS,
                L_PINSENDINGTYPE,
                L_PINSENDINGPLACE,
                l_RESIDENTFLAG,
                l_IDTYPE,
                l_IDSERIES,
                l_IDSERIALNUMBER,
                L_UserID
           FROM cbs_musteri
          WHERE musteri_no = pn_musteri_no;
      END;

      BEGIN
         SELECT (SELECT ULKE_ADI
                   FROM CBS_ULKE_KODLARI
                  WHERE CBS_ULKE_KODLARI.ULKE_KODU = Ulke_kod) ulke,
                SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(posta_kod)), ''), 1, 8) homepostalcode,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(ulke_kod)), ''), 1, 2)) homecountry,
                (SELECT UPPER (pkg_Debit_card.CYR2LAT (IL_ADI))
                   FROM CBS_IL_KODLARI
                  WHERE CBS_IL_KODLARI.IL_KODU = CBS_MUSTERI_ADRES.IL_KOD) homeREGIONNAME,
                UPPER(SUBSTR(NVL(TRIM(pkg_debit_Card.sf_bs_city_code(il_kod)), ''), 1, 3)) homecitycode,                                --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz (il_kod))), ''), 1, 25)) homecity,          --map edilecek
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ''), 1, 40)) homeaddress1,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ''), 41, 40)) homeaddress2,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ''), 81, 40)) homeaddress3,
                SUBSTR((ulke_tel_kod), 1, 3) homephonecountrycode,
                SUBSTR((tel_alan_kod), 1, 4) homephoneregioncode,
                SUBSTR((tel_no), 1, 9) homephone,
                SUBSTR(PHONE_EXTENSION_NO_1, 1, 6) HTELEXT,
                SUBSTR(FAX_ALAN_KOD, 1, 3) HFAXAREA,
                SUBSTR(NVL(EMAIL_FOR_CCARD_SYSTEM, EMAIL), 1, 60) HOME_MAILADDRESS,
                SUBSTR(NVL(TRIM(EMERGENCY_CALL_PERSON), ' '), 1, 36),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_AREA_CODE), ' '), 1, 4),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_PHONE_NO), ' '), 1, 9),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_EXTENSION_NO), ' '), 1, 5),
                SUBSTR(FAX_NO, 1, 20),
                SUBSTR(FAX_COUNTRY_CODE, 1, 3) HFAXCOUNTRY,
                NVL(SUBSTR(pkg_debit_Card.sf_country_code_formatted(ulke_gsm_kod), 1, 3), ' ') mobilePhoneCountryCode,
                NVL(SUBSTR(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod), 1, 4), ' ') mobilePhoneRegionCode,
                NVL(SUBSTR(pkg_debit_Card.sf_phone_number_formatted(gsm_no), 1, 20), ' ') mobilePhone,
                NVL(SUBSTR(pkg_debit_card.sf_country_code_formatted(ulke_gsm_kod_2), 1, 3), ' ') foreignMobileCountryCode,
                NVL(SUBSTR(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod_2), 1, 4), ' ') foreignMobileRegionCode,
                NVL(SUBSTR(pkg_debit_Card.sf_phone_number_formatted(gsm_no_2), 1, 20), ' ') foreignMobilePhone,
                '' tmp
           INTO L_HCOUNTRYNAME,
                l_HZIPCODE,
                l_HCOUNTRYCODE,
                L_HDISTRICT,
                L_HCITYCODE,
                L_HCITYNAME,
                L_HADR1,
                L_HADR2,
                L_HADR3,
                L_HTELCOUNTRY,
                L_HTELAREA,
                L_HTEL,
                L_HTELEXT,
                L_HFAXAREA,
                L_HEMAIL,
                L_EMERGENCYCALLPERSON,
                l_EMERGENCY_TEL_AREACODE,
                l_EMERGENCY_TEL_PHONENO,
                l_EMERGENCY_TEL_EXTENSIONNO,
                L_HFAX,
                L_HFAXCOUNTRY,
                L_MTELCOUNTRY,
                L_MTELAREA,
                L_MTEL,
                L_MTELCOUNTRY2,
                L_MTELAREA2,
                L_MTEL2,
                L_TADRACTIVE
           FROM CBS_MUSTERI_ADRES
          WHERE musteri_no = pn_musteri_no AND adres_kod = '1';
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
      END;

      BEGIN
         SELECT (SELECT ULKE_ADI
                   FROM CBS_ULKE_KODLARI
                  WHERE CBS_ULKE_KODLARI.ULKE_KODU = Ulke_kod) WCOUNTRYNAME,
                SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(posta_kod)), ''), 1, 8) WZIPCODE,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(ulke_kod)), ''), 1, 3)) WCOUNTRYCODE,
                (SELECT UPPER(pkg_Debit_card.CYR2LAT(IL_ADI))
                   FROM CBS_IL_KODLARI
                  WHERE CBS_IL_KODLARI.IL_KODU = CBS_MUSTERI_ADRES.IL_KOD) WDISTRICT,
                UPPER(SUBSTR(NVL(TRIM(pkg_debit_Card.sf_bs_city_code(il_kod)), ''), 1, 3)) WCITYCODE,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz (il_kod))), ''), 1, 25)) WCITYNAME,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ''), 1, 40)) workaddress1,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ''), 41, 40)) workaddress2,
                UPPER(SUBSTR(NVL(TRIM(pkg_Debit_card.CYR2LAT(adres)), ''), 81, 40)) workaddress3,
                SUBSTR((ulke_tel_kod), 1, 3) WTELCOUNTRY,
                SUBSTR((tel_alan_kod), 1, 4) WTELAREA,
                SUBSTR((tel_no), 1, 9) WTEL,
                SUBSTR(PHONE_EXTENSION_NO_1, 1, 6) WTELEX,
                SUBSTR(FAX_COUNTRY_CODE, 1, 3) WFAXCOUNTRY,
                SUBSTR(FAX_ALAN_KOD, 1, 3) WFAXAREA,
                SUBSTR(NVL(EMAIL_FOR_CCARD_SYSTEM, EMAIL), 1, 60) WORK_MAILADDRESS,
                SUBSTR(NVL(TRIM(EMERGENCY_CALL_PERSON), ' '), 1, 36),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_AREA_CODE), ' '), 1, 4),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_PHONE_NO), ' '), 1, 9),
                SUBSTR(NVL(TRIM(EMERGENCY_TEL_EXTENSION_NO), ' '), 1, 5),
                '' tmp,
                SUBSTR(FAX_NO, 1, 20) WFAX
           /*      NVL (       SUBSTR (       pkg_debit_Card.sf_country_code_formatted (ulke_gsm_kod),      1,       3),   ' ')                  mobilePhoneCountryCode,
                   NVL (      SUBSTR (        pkg_debit_Card.sf_tel_alan_kod_formatli (gsm_alan_kod),        1,        4),    ' ')                   mobilePhoneRegionCode,
                   NVL (      SUBSTR (pkg_debit_Card.sf_phone_number_formatted (gsm_no),                    1,          20),         ' ')                   mobilePhone,
                   NVL (    SUBSTR (     pkg_debit_card.sf_country_code_formatted (ulke_gsm_kod_2),    1,    3),           ' ')                   foreignMobileCountryCode,
                   NVL (    SUBSTR (       pkg_debit_Card.sf_tel_alan_kod_formatli ( gsm_alan_kod_2),   1,     4),           ' ')                   foreignMobileRegionCode,
                   NVL (        SUBSTR (        pkg_debit_Card.sf_phone_number_formatted (gsm_no_2),   1,    20),          ' ')                   foreignMobilePhone*/
           INTO L_WCOUNTRYNAME,
                L_WZIPCODE,
                L_WCOUNTRYCODE,
                L_WDISTRICT,
                L_WCITYCODE,
                L_WCITYNAME,
                L_WADR1,
                L_WADR2,
                L_WADR3,
                L_WTELCOUNTRY,
                L_WTELAREA,
                L_WTEL,
                L_WTELEXT,
                L_WFAXCOUNTRY,
                L_WFAXAREA,
                L_WEMAIL,
                L_EMERGENCYCALLPERSON,
                l_EMERGENCY_TEL_AREACODE,
                l_EMERGENCY_TEL_PHONENO,
                l_EMERGENCY_TEL_EXTENSIONNO,
                L_TADRACTIVE,
                L_WFAX
            /*  L_MTELCOUNTRY,
                L_MTELAREA ,
                L_MTEL,
                L_MTELCOUNTRY2,
                L_MTELAREA2,
                L_MTEL2    */
           FROM CBS_MUSTERI_ADRES
          WHERE musteri_no = pn_musteri_no AND adres_kod = '2';
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
      END;

      /*BEGIN
        SELECT
                SUBSTR (TEMP_TEL_EXT, 1, 6) TTELEXT,
                SUBSTR (TEMP_TEL_COUNTRY, 1, 3) tempcountry,
                UPPER (        SUBSTR (NVL (TRIM (pkg_Debit_card.CYR2LAT (adres)), ''),      1,         40))                address1,
                UPPER (      SUBSTR (NVL (TRIM (pkg_Debit_card.CYR2LAT (adres)), ''),   41,         40))                   address2,
                UPPER (  SUBSTR (NVL (TRIM (pkg_Debit_card.CYR2LAT (adres)), ''),     81,             40))                   address3,
                (SELECT UPPER (pkg_Debit_card.CYR2LAT (IL_ADI))
                   FROM CBS_IL_KODLARI
                  WHERE CBS_IL_KODLARI.IL_KODU = CBS_MUSTERI_ADRES.IL_KOD)                   work_REGIONNAME,
                UPPER (        SUBSTR (
                      NVL (TRIM (pkg_debit_Card.sf_bs_city_code (il_kod)),
                           ''),                      1,                      3))                   workcitycode,                                --map edilecek
                UPPER (       SUBSTR (       NVL (
                         TRIM (
                            pkg_Debit_card.CYR2LAT (
                               pkg_genel.sehir_adi_al_hatasiz (il_kod))),         ''),     1,        25))                   workcity,                                    --map edilecek
                UPPER (                   SUBSTR (
                      NVL (TRIM (pkg_Debit_card.CYR2LAT (ulke_kod)), ''),      1,       3      ))                   regiscountry,
                (SELECT UPPER (pkg_Debit_card.CYR2LAT (IL_ADI))
                   FROM CBS_IL_KODLARI
                  WHERE CBS_IL_KODLARI.IL_KODU = CBS_MUSTERI_ADRES.IL_KOD)                   regisREGIONNAME,
                SUBSTR (NVL (TRIM (pkg_Debit_card.CYR2LAT (posta_kod)), ''),
                        1,
                        8)
                   workpostalcode,
                SUBSTR (
                   NVL (TRIM (pkg_Debit_card.CYR2LAT (TEMP_ADR_START_DAY)),
                        ''),
                   1,
                   2),
                SUBSTR (
                   NVL (TRIM (pkg_Debit_card.CYR2LAT (TEMP_ADR_START_MONTH)),
                        ''),
                   1,
                   2),
                SUBSTR (
                   NVL (TRIM (pkg_Debit_card.CYR2LAT (TEMP_ADR_START_YEAR)),
                        ''),
                   1,
                   2),
                SUBSTR (
                   NVL (TRIM (pkg_Debit_card.CYR2LAT (TEMP_ADR_END_DAY)),
                        ''),
                   1,
                   2),
                SUBSTR (
                   NVL (TRIM (pkg_Debit_card.CYR2LAT (TEMP_ADR_END_MONTH)),
                        ''),
                   1,
                   2),
                SUBSTR (
                   NVL (TRIM (pkg_Debit_card.CYR2LAT (TEMP_ADR_END_YEAR)),
                        ''),
                   1,
                   2),
                SUBSTR (TEMP_TYPE, 1, 2),
                SUBSTR (                   pkg_debit_Card.sf_country_code_formatted (ulke_tel_kod),                 1,                 3)                   TTELCOUNTRY,
                SUBSTR (      pkg_debit_Card.sf_tel_alan_kod_formatli (tel_alan_kod),                   1,                   4)                   TTELAREA,
                SUBSTR (pkg_debit_Card.sf_phone_number_formatted (tel_no),                        1,                        20)                   TTEL,
                SUBSTR (                   pkg_debit_Card.sf_tel_alan_kod_formatli (fax_alan_kod),                   1,                   4)                   TFAXAREA,
                SUBSTR (pkg_debit_Card.sf_phone_number_formatted (fax_no),                        1,                        20)                     TFAX,
                SUBSTR ( nvl(EMAIL_FOR_CCARD_SYSTEM,EMAIL), 1, 40) tempmail,
            /*       TRIM (EMERGENCY_CALL_PERSON),
                TRIM (EMERGENCY_TEL_AREA_CODE),
                TRIM (EMERGENCY_TEL_PHONE_NO),
                TRIM (EMERGENCY_TEL_EXTENSION_NO),*/
      /*           nvl(TEMPORARY_ADDRESS_ACTIVE,'')
         INTO
          L_TTELEXT,
          L_TFAXCOUNTRY,
          L_TADR1,
           L_TADR2,
           L_TADR3,
                  L_TDISTRICT,
                  L_TCITYCODE,
                   L_TCITYNAME,
                  L_TCOUNTRYCODE,
                  L_TCOUNTRYNAME,
                   L_TZIPCODE,
                    L_TADRSTARTDAY,
                   L_TADRSTARTMONTH,
                    L_TADRSTARTYEAR,
                    L_TADRENDDAY,
                    L_TADRENDMONTH,
                     L_TADRENDYEAR,
                        L_TADRTYPE,
                         L_TTELCOUNTRY,
                       L_TTELAREA,
                         L_TTEL,
                     L_TFAXAREA,
                     L_TFAX,
                L_TEMAIL,
   /*     L_EMERGENCYCALLPERSON,
        l_EMERGENCY_TEL_AREACODE,
        l_EMERGENCY_TEL_PHONENO,
        l_EMERGENCY_TEL_EXTENSIONNO ,*/
      /*   L_TADRACTIVE
          FROM CBS_MUSTERI_ADRES
         WHERE musteri_no = pn_musteri_no AND adres_kod = '3';
     EXCEPTION
        WHEN OTHERS
        THEN
           NULL;
    END;*/

      -- GET INFO FROM BUSINESS CARD HOLDERS TABLE
      /* If pn_card_holder_no is not null then
       BEGIN
       SELECT
                SUBSTR( NVL (TRIM (EMERGENCY_CALL_PERSON), ' '),1,36),
                SUBSTR(  NVL (TRIM (EMERGENCY_TEL_AREACODE), ' '),1,4),
                SUBSTR(  NVL (TRIM (EMERGENCY_TEL_PHONENO), ' '),1,9),
                SUBSTR(  NVL (TRIM (EMERGENCY_TEL_EXTENSIONNO), ' '),1,4),
                 NVL (HOME_TEL_EXTENSIONNO, '') PHONE_EXTENSION_NO_1,
                 '' PHONE_EXTENSION_NO_2,
                  NVL (MOB_TEL_COUNTRYAREACODE,   '')                  mobilePhoneCountryCode,
                 NVL (     MOB_TEL_AREACODE,    '')                   mobilePhoneRegionCode,
                 NVL (     MOB_TEL_PHONENO,         '')                   mobilePhone,
                 NVL (   MOB_TEL_COUNTRYAREACODE2,           '')                   foreignMobileCountryCode,
                 NVL ( MOB_TEL_AREACODE2,           '')                   foreignMobileRegionCode,
                 NVL (  MOB_TEL_PHONENO2,          '')                   foreignMobilePhone,
                 NVL (FAX_COUNTRYAREACODE, '')         FAX_COUNTRY_CODE,
                 NVL (  FAX_AREACODE,  '')            homefaxregioncode,
                 NVL (   FAX_PHONENO,   '')                   homefax,
                 ''         HOME_MAILADDRESS,
                 NVL (    SUBSTR ( pkg_debit_Card.sf_tel_alan_no_formatli (WORK_MAILADDRESS),  1, 60),  '')           WORK_MAILADDRESS,
                --                  NVL (    HOME_POSTALCODE, ' ')  ,
                       NVL ( HOME_COUNTRYCODE, '')  ,
                       NVL ( HOME_REGIONNAME, '') ,
                      NVL (  HOME_CITYCODE, '')    ,
                      NVL (  HOME_CITYNAME, '')    ,
                      NVL (  HOME_ADDRESSLINE1, '')    ,
                     NVL (   HOME_ADDRESSLINE2 ,'')
       INTO
                 L_EMERGENCYCALLPERSON,
                 l_EMERGENCY_TEL_AREACODE,
                 l_EMERGENCY_TEL_PHONENO,
                 l_EMERGENCY_TEL_EXTENSIONNO,
                 L_HTELEXT  ,
                 L_WTELEXT  ,
                 l_MTELCOUNTRY,
                 L_MTELAREA,
                 L_MTEL,
                 L_MTELCOUNTRY2,
                 L_MTELAREA2,
                 L_MTEL2,
                 l_HFAXCOUNTRY,
                 l_HFAXAREA,
                 l_HFAX,
                 L_HEMAIL,
                 L_WEMAIL,
        --          l_HOME_POSTALCODE,
                 l_HCOUNTRYCODE   ,
                 l_HDISTRICT   ,
                 l_HCITYCODE,
                 L_HCITYNAME,
                 L_HADR1,
                 L_HADR2

            FROM CBS_BUS_CREDIT_CARD_HOLDERS
           WHERE BUSINESS_CARD_HOLDER_NO = pn_card_holder_no;
       EXCEPTION
          WHEN OTHERS
          THEN
             NULL;
       END;

       end if;*/

      BEGIN
         SELECT DEFAULT_MOBILE_PHONE
           INTO l_SELECT_MOB_TEL
           FROM cbs_musteri
          WHERE musteri_no = pn_musteri_no;
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
      END;

      --INSERT INTO TABLE FOR UPDATE
      sp_ins_Credit_Card_UPD_app_Tx(pn_app_id,
                                    pn_tx_no,
                                    pn_musteri_no,
                                    l_CustomerNumber,
                                    LPAD(SUBSTR(pn_app_id, 1, 14), 14, '0'),
                                    L_name,
                                    L_SURNAME,
                                    L_MIDDLE_NAME,
                                    L_EMBOSSNAME,
                                    L_BIRTH_DATE,
                                    L_GENDER,
                                    NVL(L_MOTHER_MAIDEN_NAME, ''),
                                    NVL(L_BIRTH_PLACETEXT, ''),
                                    NVL(L_NATIONALITY, ''),
                                    NVL(L_MARIAL_STATUS, ''),
                                    NVL(L_FATHER_NAME, ''),
                                    NVL(L_EMERGENCYCALLPERSON, ''),
                                    NVL(L_EMERGENCY_TEL_AREACODE, ''),
                                    NVL(L_EMERGENCY_TEL_PHONENO, ''),
                                    NVL(L_EMERGENCY_TEL_EXTENSIONNO, ''),
                                    NVL(L_WORK_COMPANYNAME, ''),
                                    NVL(L_CARDSENDINGTYPE, ''),
                                    NVL(L_CARDSENDINGPLACE, ''),
                                    NVL(L_CARD_PINSENDINGBRANCH, ''),
                                    NVL(L_STATEMENTSENDADRESS, ''),
                                    NVL(L_PINSENDINGTYPE, ''),
                                    NVL(L_PINSENDINGPLACE, ''),
                                    NVL(L_RESIDENTFLAG, ''),
                                    NVL(L_IDTYPE, ''),
                                    NVL(L_IDSERIES, ''),
                                    NVL(L_IDSERIALNUMBER, ''),
                                    NVL(L_HADR1, ''),
                                    NVL(L_HADR2, ''),
                                    NVL(L_HADR3, ''),
                                    NVL(L_HDISTRICT, ''),
                                    NVL(L_HCITYCODE, ''),
                                    NVL(L_HCITYNAME, ''),
                                    NVL(L_HCOUNTRYCODE, ''),
                                    NVL(L_HCOUNTRYNAME, ''),
                                    NVL(L_HZIPCODE, ''),
                                    NVL(L_WADR1, ''),
                                    NVL(L_WADR2, ''),
                                    NVL(L_WADR3, ''),
                                    NVL(L_WDISTRICT, ''),
                                    NVL(L_WCITYCODE, ''),
                                    NVL(L_WCITYNAME, ''),
                                    NVL(L_WCOUNTRYCODE, ''),
                                    NVL(L_WCOUNTRYNAME, ''),
                                    NVL(L_WZIPCODE, ''),
                                    NVL(L_TADRACTIVE, ''),
                                    NVL(L_TADR1, ''),
                                    NVL(L_TADR2, ''),
                                    NVL(L_TADR3, ''),
                                    NVL(L_TDISTRICT, ''),
                                    NVL(L_TCITYCODE, ''),
                                    NVL(L_TCITYNAME, ''),
                                    NVL(L_TCOUNTRYCODE, ''),
                                    NVL(L_TCOUNTRYNAME, ''),
                                    NVL(L_TZIPCODE, ''),
                                    NVL(L_TADRSTARTDAY, ''),
                                    NVL(L_TADRSTARTMONTH, ''),
                                    NVL(L_TADRSTARTYEAR, ''),
                                    NVL(L_TADRENDDAY, ''),
                                    NVL(L_TADRENDMONTH, ''),
                                    NVL(L_TADRENDYEAR, ''),
                                    NVL(L_TADRTYPE, ''),
                                    NVL(L_HTELCOUNTRY, ''),
                                    NVL(L_HTELAREA, ''),
                                    NVL(L_HTEL, ''),
                                    NVL(L_HTELEXT, ''),
                                    NVL(L_HFAXCOUNTRY, ''),
                                    NVL(L_HFAXAREA, ''),
                                    NVL(L_HFAX, ''),
                                    NVL(L_HEMAIL, ''),
                                    NVL(L_WTELCOUNTRY, ''),
                                    NVL(L_WTELAREA, ''),
                                    NVL(L_WTEL, ''),
                                    NVL(L_WTELEXT, ''),
                                    NVL(L_WFAXCOUNTRY, ''),
                                    NVL(L_WFAXAREA, ''),
                                    NVL(L_WFAX, ''),
                                    NVL(L_WEMAIL, ''),
                                    NVL(L_TTELCOUNTRY, ''),
                                    NVL(L_TTELAREA, ''),
                                    NVL(L_TTEL, ''),
                                    NVL(L_TTELEXT, ''),
                                    NVL(L_TFAXCOUNTRY, ''),
                                    NVL(L_TFAXAREA, ''),
                                    NVL(L_TFAX, ''),
                                    NVL(L_TEMAIL, ''),
                                    NVL(L_MTELCOUNTRY, ''),
                                    NVL(L_MTELAREA, ''),
                                    NVL(L_MTEL, ''),
                                    NVL(L_MTELCOUNTRY2, ''),
                                    NVL(L_MTELAREA2, ''),
                                    NVL(L_MTEL2, ''),
                                    L_UserID,
                                    l_SELECT_MOB_TEL);

      --CALL WS FOR UPDATE
      pkg_credit_card.SP_WS_PersonalInfoUpdate(pn_app_id,
                                               pn_banksoft_no,
                                               ps_response_code,
                                               ps_response_desc,
                                               ps_newcardno,
                                               ps_newpanno);
      --UPDATE MAIN TABLE
      sp_upd_credit_Card_app_islem('UPD',
                                   pn_app_id,
                                   pn_banksoft_no,
                                   ps_response_code,
                                   ps_response_desc,
                                   NULL,
                                   NULL,
                                   NULL);
   END;

   ------------------------------------------------------------------------------------------------------
   PROCEDURE Customer_limit_used(pn_musteri IN NUMBER, pn_limit OUT NUMBER) IS
   ln_cnt   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO ln_cnt
        FROM CBS_CREDIT_CARD_DEF
       WHERE customer_no = pn_musteri;

      IF NVL(ln_cnt, 0) > 0
      THEN
         SELECT SUM(credit_card_limit)
           INTO pn_limit
           FROM CBS_CREDIT_CARD_DEF
          WHERE customer_no = pn_musteri;
      END IF;
   END;

   FUNCTION Sf_emboss_full_name(ps_customer_no VARCHAR2, ps_bussines_no VARCHAR2 DEFAULT NULL) RETURN VARCHAR2 IS
      ls_musteri_adi          VARCHAR2 (200) := NULL;
      ps_emboss_name          VARCHAR2 (200) := NULL;
      ps_surname              VARCHAR2 (200) := NULL;
      ps_emboss_second_name   VARCHAR2 (200) := NULL;
   BEGIN
      IF ps_bussines_no IS NOT NULL THEN
         NULL;
      /*Select  First_name,Middle_name,Last_name
            into
             ps_emboss_name,ps_emboss_second_name,ps_surname
           from   CBS_BUS_CREDIT_CARD_HOLDERS
      where customer_no  =  ps_customer_no and BUSINESS_CARD_HOLDER_NO =  ps_bussines_no;*/

      ELSE
         SELECT ISIM_ENG, IKINCI_ISIM_ENG, SOYADI_ENG
           INTO ps_emboss_name, ps_emboss_second_name, ps_surname
           FROM CBS_MUSTERI
          WHERE musteri_no = ps_customer_no;
      END IF;

      IF TRIM(ps_emboss_second_name) IS NULL THEN
         ls_musteri_adi := TRIM(TRIM(ps_emboss_name) || ' ' || TRIM(ps_surname));
      ELSE
         ls_musteri_adi := TRIM(TRIM(ps_emboss_name) || ' ' || TRIM(ps_emboss_second_name) || ' ' || TRIM(ps_surname));
      END IF;

      RETURN UPPER (TRIM (ls_musteri_adi));
   EXCEPTION
      WHEN OTHERS THEN
         RETURN NULL;
   END;

   ----------------------------------------------------------------------------------------------------------------------------------------------
   FUNCTION SF_Truncate_emboss_name(Customer_no VARCHAR2) RETURN VARCHAR2 IS
   ls_emboss_name_eng          VARCHAR2 (100);
   ls_emboss_second_name_eng   VARCHAR2 (100);
   ls_emboss_surname_eng       VARCHAR2 (100);
   ls_emboss_full_name         VARCHAR2 (100);
   
   BEGIN
      BEGIN
         SELECT DECODE(musteri_tipi_kod, 3, TRIM(manager_name), TRIM(isim_eng)),
                DECODE(musteri_tipi_kod, 3, TRIM(manager_patronymic_name), TRIM(ikinci_isim_eng)),
                DECODE(musteri_tipi_kod, 3, TRIM(manager_surname), TRIM(soyadi_eng))
           INTO ls_emboss_name_eng,
                ls_emboss_second_name_eng,
                ls_emboss_surname_eng
           FROM cbs_musteri
          WHERE musteri_no = Customer_no;
      END;

      ls_emboss_full_name := pkg_Debit_Card.Sf_emboss_full_name(ls_emboss_name_eng,
                                                                ls_emboss_second_name_eng,
                                                                ls_emboss_surname_eng);
                                                                 
      IF LENGTH(ls_emboss_full_name) > 26
         AND TRIM(ls_emboss_Second_name_eng) IS NOT NULL THEN
         IF UPPER(SUBSTR(TRIM (ls_emboss_second_name_eng), 1, 3)) = 'DZH' THEN
            ls_emboss_second_name_eng := SUBSTR(TRIM(ls_emboss_second_name_eng), 1, 3) || '.';
         ELSIF UPPER(SUBSTR(TRIM (ls_emboss_name_eng), 1, 2)) IN ('CH', 'ZH', 'SH', 'PH', 'TS', 'KH') THEN
            ls_emboss_second_name_eng := SUBSTR(TRIM(ls_emboss_second_name_eng), 1, 2) || '.';
         ELSE
            ls_emboss_second_name_eng := SUBSTR(TRIM(ls_emboss_second_name_eng), 1, 1) || '.';
         END IF;

         ls_emboss_full_name := pkg_Debit_Card.Sf_emboss_full_name(ls_emboss_name_eng,
                                                                   ls_emboss_second_name_eng,
                                                                   ls_emboss_surname_eng);

         IF LENGTH(ls_emboss_full_name) > 26
         THEN
            IF UPPER(SUBSTR(TRIM(ls_emboss_name_eng), 1, 3)) = 'DZH' THEN
               ls_emboss_name_eng := SUBSTR(TRIM(ls_emboss_name_eng), 1, 3) || '.';
            ELSIF UPPER(SUBSTR(TRIM(ls_emboss_name_eng), 1, 2)) IN ('CH', 'ZH', 'SH', 'PH', 'TS', 'KH') THEN
               ls_emboss_name_eng := SUBSTR(TRIM(ls_emboss_name_eng), 1, 2) || '.';
            ELSE
               ls_emboss_name_eng := SUBSTR(TRIM(ls_emboss_name_eng), 1, 1) || '.';
            END IF;
            ls_emboss_second_name_eng := '';
         END IF;
      END IF;

      ls_emboss_full_name := pkg_Debit_Card.Sf_emboss_full_name(ls_emboss_name_eng,
                                                                ls_emboss_second_name_eng,
                                                                ls_emboss_surname_eng);
      RETURN ls_emboss_full_name;
   END;

   FUNCTION sf_get_card_status_desc(status VARCHAR2) RETURN VARCHAR2 IS
      status_desc VARCHAR2 (200);
   BEGIN
      IF status IS NOT NULL
      THEN
         SELECT explanation
           INTO status_desc
           FROM cbs_cc_card_status_code
          WHERE status_code LIKE status;

         RETURN status_desc;
      ELSE
         log_at ('7158_ccard_get_status_ws', 'WS for checking card status did not find card in card system. Check PseudoPAN.');
         status_desc := 'Card not found in system!';
         RETURN status_desc;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         log_at ('7158_wrong_status', status);
         RETURN 'Wrong Status code entered!!!';
   END;

   PROCEDURE SP_CCARD_STATUS_CHANGE_WS(pn_app_id        IN  NUMBER,
                                       ps_response_code OUT VARCHAR2,
                                       ps_response_desc OUT VARCHAR2)
   IS
      CURSOR cur_ccoper IS
         SELECT customer_no,
                tx_no,
                status_will_be_updated,
                substatus,
                userid,
                card_id_no
           FROM cbs_credit_card_upd_app_tx
          WHERE app_id = pn_app_id;

      r_ccoper                cur_ccoper%ROWTYPE;

      serviceUrl              VARCHAR2 (2000);
      soapAction              VARCHAR2 (2000);
      namespace               VARCHAR2 (2000);
      methodName              VARCHAR2 (2000);
      req                     Pkg_Soap.request;
      resp                    Pkg_Soap.response;
      result                  CLOB;

      l_parser                DBMS_XMLPARSER.Parser;
      l_doc                   DBMS_XMLDOM.DOMDocument;
      l_nl                    DBMS_XMLDOM.DOMNodeList;
      l_n                     DBMS_XMLDOM.DOMNode;

      ld_starttime            DATE;
      ld_endtime              DATE;

      ls_BS_CWS_SERVICE_URL   VARCHAR2 (200);
      l_pseudopanno           VARCHAR2 (20);
      pn_banksoft_no          NUMBER;
   BEGIN
      pkg_parametre.deger('BS_CWS_SERVICE_URL', ls_BS_CWS_SERVICE_URL);

      FOR c_ccoper IN cur_ccoper LOOP
         r_ccoper := c_ccoper;
      END LOOP;

      ld_starttime := SYSDATE;
      l_pseudopanno := r_ccoper.card_id_no;
      pn_banksoft_no := r_ccoper.customer_no;
      serviceUrl := ls_BS_CWS_SERVICE_URL;
      namespace := 'http://www.banksoft.com.tr';
      methodName := 'UpdateCardStatus';
      soapAction := namespace || '/KirgizDemirWS/' || methodName;
      namespace := 'xmlns="' || namespace || '"';

      req := Pkg_Soap.new_request(methodName, namespace);
      Pkg_Soap.ADD_PARAMETER(req, 'URT', NULL,
         '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateCardStatusRequestType"><![CDATA[' || SUBSTR (l_pseudopanno, 1, 19) || ']]></PSEUDOPAN>'
         || '<CARDSTATUS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateCardStatusRequestType"><![CDATA[' || r_ccoper.status_will_be_updated || ']]></CARDSTATUS>'
         || '<CARDSUBSTATUS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateCardStatusRequestType"><![CDATA[' || NVL (r_ccoper.substatus, '0') || ']]></CARDSUBSTATUS>'
         || '<USERCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateCardStatusRequestType"><![CDATA[' || r_ccoper.userid || ']]></USERCODE>');

      resp := Pkg_Soap.invoke_utf8_v11_card(req, serviceUrl, soapAction);
      result := resp.doc.getstringval();

      result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr"', '');
      result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"', '');
      
      l_parser := DBMS_XMLPARSER.newParser;

      DBMS_XMLPARSER.parseclob(l_parser, result);
      l_doc := DBMS_XMLPARSER.getDocument(l_parser);
      l_nl := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode(l_doc), 'UpdateCardStatusResponse/UpdateCardStatusResult');

      FOR cur_emp IN 0 .. DBMS_XMLDOM.getLength(l_nl) - 1 LOOP
         l_n := DBMS_XMLDOM.item(l_nl, cur_emp);
         -- Use XPATH syntax to assign values to he elements of the collection.
         DBMS_XSLPROCESSOR.valueOf(l_n, 'RCODE/text()', ps_response_Code);
         DBMS_XSLPROCESSOR.valueOf(l_n, 'RDESC/text()', ps_response_Desc);
      END LOOP;

      ld_endtime := SYSDATE;
      sp_upd_credit_Card_app_islem('UPD',
                                   pn_app_id,
                                   pn_banksoft_no,
                                   ps_response_Code,
                                   ps_response_Desc,
                                   NULL,
                                   NULL,
                                   NULL);

      IF (SUBSTR(ps_response_Code, 1, 16) = '000') THEN
         UPDATE cbs_credit_card
            SET status = r_ccoper.status_will_be_updated
          WHERE customer_no = r_ccoper.customer_no
            AND SUBSTR(CARD_ID_NO, 1, 16) = SUBSTR(r_ccoper.card_id_no, 1, 16);
      END IF;

      Pkg_debit_Card.WS_LOG('CREDIT CARD', serviceUrl, methodName, ld_starttime, ld_endtime, ps_response_Code, NULL, r_ccoper.tx_no, pn_app_id, result, REQ.BODY);
   EXCEPTION
      WHEN OTHERS THEN
         ROLLBACK;
         ps_response_Code := '096';
         ps_response_Desc := SQLCODE || ' ' || SQLERRM;
         Pkg_debit_Card.WS_LOG('CREDIT CARD', serviceUrl, methodName, ld_starttime, ld_endtime, '096', SQLCODE || ' ' || SQLERRM, r_ccoper.tx_no, pn_app_id, result, REQ.BODY);
         log_at('SP_CCARD_Status_Change_WS', SQLCODE || ' ' || SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;

    PROCEDURE SP_CCARD_GET_OVERBALANCE_WS(PN_CUSTOMER_NO IN VARCHAR2, PS_PSEUDOPAN IN VARCHAR2, PS_OVERBALANCE OUT VARCHAR2) IS
      ps_cc_status            VARCHAR2(3);
      serviceUrl              VARCHAR2(2000);
      soapAction              VARCHAR2(2000);
      namespace               VARCHAR2(2000);
      methodName              VARCHAR2(2000);
      req                     PKG_SOAP.REQUEST;
      resp                    PKG_SOAP.RESPONSE;
      result                  CLOB;

      l_parser                DBMS_XMLPARSER.PARSER;
      l_doc                   DBMS_XMLDOM.DOMDOCUMENT;
      l_nl                    DBMS_XMLDOM.DOMNODELIST;
      l_n                     DBMS_XMLDOM.DOMNODE;

      ld_starttime            DATE;
      ld_endtime              DATE;
      ls_pseudopan            VARCHAR2(20);

      ls_BS_CWS_SERVICE_URL   VARCHAR2(200);

      ls_response_code        VARCHAR2(3);
      ls_response_desc        VARCHAR2(200);
   BEGIN
      pkg_parametre.deger ('BS_CWS_SERVICE_URL', ls_BS_CWS_SERVICE_URL);

      BEGIN
         ld_starttime := SYSDATE;

         serviceUrl := ls_BS_CWS_SERVICE_URL;
         namespace := 'http://www.banksoft.com.tr';
         methodName := 'GetCreditCardInfo';
         soapAction := namespace || '/' || methodname;
         namespace := 'xmlns="' || namespace || '"';

         req := Pkg_Soap.new_request(methodName, namespace);
         Pkg_Soap.ADD_PARAMETER(req, 'SDI', NULL, '<CRMNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GetCreditCardInfoRequestType"><![CDATA[' || pn_customer_no || ']]></CRMNO>');
         resp := Pkg_Soap.invoke_utf8_v11_card_clob (req, serviceUrl, soapAction);

         result := resp.doc.getclobval();
         result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr"', '');
         result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GetCreditCardInfoResponseType"', '');

         l_parser := DBMS_XMLPARSER.newParser;
         DBMS_XMLPARSER.parseclob(l_parser, result);
         l_doc := DBMS_XMLPARSER.getDocument(l_parser);
         l_nl := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode(l_doc), 'GetCreditCardInfoResponse/GetCreditCardInfoResult/GetCreditCardInfoResponseType');

         FOR cur_emp IN 0 .. DBMS_XMLDOM.getLength (l_nl) - 1 LOOP
            l_n := DBMS_XMLDOM.item(l_nl, cur_emp);
            -- Use XPATH syntax to assign values to he elements of the collection.
            DBMS_XSLPROCESSOR.valueOf(l_n, 'PseudoPAN/text()', ls_pseudopan);

            IF SUBSTR(ls_pseudopan, 0, 16) = SUBSTR(ps_pseudopan, 0, 16) THEN
               DBMS_XSLPROCESSOR.valueOf (l_n, 'Overbalance/text()', ps_overbalance);
               DBMS_XSLPROCESSOR.valueOf (l_n, 'RCODE/text()', ls_response_code);
               DBMS_XSLPROCESSOR.valueOf (l_n, 'RDESC/text()', ls_response_desc);
            END IF;
         END LOOP;

         ld_endtime := SYSDATE;

         Pkg_debit_Card.WS_LOG('CREDIT CARD', serviceUrl, methodName, ld_starttime, ld_endtime, ls_response_Code, NULL,  NULL, NULL, result, REQ.BODY);
      EXCEPTION
         WHEN OTHERS THEN
            ROLLBACK;
            ls_response_Code := '096';
            ls_response_Desc := SQLCODE || ' ' || SQLERRM;
            Pkg_debit_Card.WS_LOG ('CREDIT CARD', serviceUrl, methodName, ld_starttime, ld_endtime, '096', SQLCODE || ' ' || SQLERRM, NULL, NULL, result, REQ.BODY);
            log_at ('SP_CCARD_GET_OVERBALANCE_WS', SQLCODE || ' ' || SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END;
      
   END;

/******************************************************************************
  NAME        : PROCEDURE SP_UPDATELIMITREQAPP_WS
  Prepared By : Nurzalat Alimzhan uulu
  Date        : 20.09.2018
  Purpose     : Update Limit of a client --KOM-31
******************************************************************************/ 
PROCEDURE SP_UPDATELIMITREQAPP_WS(pn_tx_no          IN  NUMBER,
                                  pn_tran_type      IN  NUMBER,                 -- IadgarB
                                  pn_customer       IN  NUMBER,                 -- IadgarB
                                  pn_req_limit      IN  NUMBER DEFAULT NULL,    -- IadgarB
                                  pn_apr_limit      IN  NUMBER DEFAULT NULL,    -- IadgarB
                                  ps_response_code  OUT VARCHAR2,
                                  ps_response_desc  OUT VARCHAR2) IS
    serviceUrl              VARCHAR2(2000);
    soapAction              VARCHAR2(2000);
    namespace               VARCHAR2(2000);
    methodName              VARCHAR2(2000);
    pn_app_id               NUMBER;
    req                     pkg_soap.request;
    resp                    pkg_soap.response;
    result                  CLOB;
    l_parser                dbms_xmlparser.parser;
    l_doc                   dbms_xmldom.domdocument;
    l_nl                    dbms_xmldom.domnodelist;
    l_n                     dbms_xmldom.domnode;
    ld_starttime            DATE;
    ld_endtime              DATE;
    ls_bs_cws_service_url   VARCHAR2(200);
  BEGIN
    pkg_parametre.deger('BS_CWS_SERVICE_URL', ls_bs_cws_service_url);
    pn_app_id := pkg_genel.genel_kod_al('CBS_CARD_CREDIT_APP');
    ld_starttime := SYSDATE;
    
    serviceUrl := ls_BS_CWS_SERVICE_URL;
    namespace := 'http://www.banksoft.com.tr';
    methodName := 'UpdateLimitRequestApproval';
    soapAction := namespace || '/KirgizDemirWS/' || methodName;
    namespace := 'xmlns="' || namespace || '"';

    req := Pkg_Soap.new_request(methodName, namespace);
    --BOM IadgarB
    Pkg_Soap.add_parameter(req, 'ULI', NULL,
                            '<TRANTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateLimitRequestType"><![CDATA['|| pn_tran_type || ']]></TRANTYPE>' ||
                            '<CUSTOMERNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateLimitRequestType"><![CDATA['|| pn_customer || ']]></CUSTOMERNO>' ||
                            '<REQUESTEDSALESLIMIT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateLimitRequestType"><![CDATA['|| pn_req_limit || ']]></REQUESTEDSALESLIMIT>'||
                            '<APPROVEDSALESLIMIT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateLimitRequestType"><![CDATA['|| pn_apr_limit || ']]></APPROVEDSALESLIMIT>' ||
                            '<USERCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateLimitRequestType"><![CDATA['|| SUBSTR (USER, 1, 8)  || ']]></USERCODE>');
    --EOM IadgarB
    resp := Pkg_Soap.invoke_utf8_v11_card(req, serviceUrl, soapAction);
    result := resp.doc.getstringval();

    result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/UpdateLimitResponseType"','');
    result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr"','');
 
    l_parser := dbms_xmlparser.newParser;

    dbms_xmlparser.parseclob(l_parser, result);
    l_doc := dbms_xmlparser.getDocument(l_parser);
    l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'UpdateLimitRequestApprovalResponse/UpdateLimitRequestApprovalResult');

    FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl) - 1 LOOP
        l_n := dbms_xmldom.item(l_nl, cur_emp);
        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueOf(l_n,'RCODE',ps_response_Code);
        dbms_xslprocessor.valueOf(l_n,'RDESC',ps_response_Desc);
    END LOOP;
 
    ld_endtime := SYSDATE;

    Pkg_debit_Card.WS_LOG('CREDIT CARD LIMIT UPDATE', serviceUrl, methodName, ld_starttime, ld_endtime, ps_response_Code, ps_response_Desc, pn_tx_no, pn_app_id, result, REQ.BODY);

  EXCEPTION
    WHEN OTHERS THEN
        rollback;
        ps_response_Code:= '096';
        ps_response_Desc := sqlcode||' '||sqlerrm ; 
        Pkg_debit_Card.WS_LOG('CREDIT CARD LIMIT UPDATE', serviceUrl, methodName, ld_starttime, ld_endtime, '096', sqlcode || ' ' || sqlerrm, pn_tx_no, pn_app_id, result, REQ.BODY);
  END;
  
/******************************************************************************
  NAME        : PROCEDURE SP_STATSIMREQ_WS
  Prepared By : Nurzalat Alimzhan uulu
  Date        : 20.09.2018
  Purpose     : Statement Simulation on a card for certain date  --KOM-32
******************************************************************************/ 
  procedure SP_STATSIMREQ_WS(PS_CARD_ID_NO IN VARCHAR2,
                              PS_CUST_NO IN VARCHAR2,
                              PD_STATEMENTDATE IN VARCHAR2,--date format YYYYMMDD
                              PS_CARDNO OUT VARCHAR2,
                              PS_CUSTOMERNO OUT VARCHAR2,
                              PS_CRMNO OUT VARCHAR2,
                              PS_CUSTOMERNAME OUT VARCHAR2,
                              PS_LASTSTATEMENTDATE OUT VARCHAR2,
                              PS_LASTPAYMENTDATE OUT VARCHAR2,
                              PS_NEARESTSTATEMENTDATE OUT VARCHAR2,
                              PS_STATEMENTCODE OUT VARCHAR2,
                              PS_MINPAYMENTAMOUNT OUT VARCHAR2,
                              PS_TOTALDEBT OUT VARCHAR2,
                              PS_RESPONSE_CODE OUT VARCHAR2,
                              PS_RESPONSE_DESC OUT VARCHAR2,
                              PC_REF OUT CURSORREFERENCETYPE)
is
 SERVICEURL VARCHAR2(2000);
 SOAPACTION VARCHAR2(2000);
 NAMESPACE VARCHAR2(2000);
 METHODNAME VARCHAR2(2000);
 REQ PKG_SOAP.REQUEST;
 RESP PKG_SOAP.RESPONSE;
 RESULT CLOB;

 L_PARSER  DBMS_XMLPARSER.PARSER;
 L_DOC     DBMS_XMLDOM.DOMDOCUMENT;
 L_NL_PARENT      DBMS_XMLDOM.DOMNODELIST;
 L_NL_CHILD      DBMS_XMLDOM.DOMNODELIST;
 L_NL_DETAILS      DBMS_XMLDOM.DOMNODELIST;
 L_N_PARENT       DBMS_XMLDOM.DOMNODE;
 L_N_CHILD       DBMS_XMLDOM.DOMNODE;
 L_N_DETAILS       DBMS_XMLDOM.DOMNODE;

 LD_STARTTIME DATE;
 LD_ENDTIME DATE;

 LS_BS_CWS_SERVICE_URL VARCHAR2(200);
 LS_SUBCARDNO VARCHAR2(200);
 LS_SUBCUSTOMERNO VARCHAR2(200);
 LS_REESKDATE VARCHAR2(200);
 LS_SOURCE VARCHAR2(200);
 LS_TRANSACTIONDATE VARCHAR2(200);
 LS_DESCRIPTION VARCHAR2(200);
 LS_MERCHANTNAME VARCHAR2(200);
 LS_MERCHANTCITY VARCHAR2(200);
 LS_CODE VARCHAR2(200);
 LS_TYPE VARCHAR2(200);
 LS_AMOUNT VARCHAR2(200);
 LS_ORGAMOUNT VARCHAR2(200);
 PC_REF_TEMP CURSORREFERENCETYPE;
 R_DETAILS STATSIMREQ_LIST;
begin
pkg_parametre.deger('BS_CWS_SERVICE_URL',ls_BS_CWS_SERVICE_URL);

 ld_starttime:=SYSDATE;
 serviceUrl :=ls_BS_CWS_SERVICE_URL;
 namespace := 'http://www.banksoft.com.tr';
 methodName := 'StatementSimulation';
 soapAction := namespace || '/KirgizDemirWS/' || methodName;
 namespace := 'xmlns="' || namespace || '"';

 req := Pkg_Soap.new_request(methodName || 'Request', namespace);

 Pkg_Soap.add_parameter(
  req, 'SSRT', NULL,
'<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/StatementSimulationRequestType"><![CDATA['|| ps_card_id_no || ']]></PSEUDOPAN>' ||
'<CUSTOMERNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/StatementSimulationRequestType"><![CDATA['|| ps_cust_no || ']]></CUSTOMERNO>' ||
'<STATEMENTDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/StatementSimulationRequestType"><![CDATA['|| pd_statementdate || ']]></STATEMENTDATE>'
);

 resp := Pkg_Soap.invoke_utf8_v11_card(req, serviceUrl, soapAction);

 result := resp.doc.getstringval();
 
 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr"','');
 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/StatementSimulationResponseType"','');
 
 l_parser := dbms_xmlparser.newParser;

 dbms_xmlparser.parseclob(l_parser, result);
 l_doc := dbms_xmlparser.getDocument(l_parser);

 l_nl_parent := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'StatementSimulationRequestResponse/StatementSimulationRequestResult');
 l_nl_child := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'StatementSimulationRequestResponse/StatementSimulationRequestResult/StatementSimulationSummaryType');
 l_nl_details := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'StatementSimulationRequestResponse/StatementSimulationRequestResult/StatementSimulationDetailType/StatementSimulationDetailType');
 --using own TYPE to parse xml response nurzalata
 r_details := statsimreq_list();
 
 FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl_parent) - 1 LOOP
  l_n_parent := dbms_xmldom.item(l_nl_parent, cur_emp);
  -- Use XPATH syntax to assign values to he elements of the collection.
  dbms_xslprocessor.valueOf(l_n_parent,'RCODE/text()',ps_response_Code);
  dbms_xslprocessor.valueOf(l_n_parent,'RDESC/text()',ps_response_Desc);
 END LOOP;
 FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl_child) - 1 LOOP
  l_n_child := dbms_xmldom.item(l_nl_child, cur_emp);
  -- Use XPATH syntax to assign values to he elements of the collection.
  dbms_xslprocessor.valueOf(l_n_child,'CARDNO/text()',ps_CARDNO);
  dbms_xslprocessor.valueOf(l_n_child,'CUSTOMERNO/text()',ps_CUSTOMERNO);
  dbms_xslprocessor.valueOf(l_n_child,'CRMNO/text()',ps_CRMNO);
  dbms_xslprocessor.valueOf(l_n_child,'CUSTOMERNAME/text()',ps_CUSTOMERNAME);
  dbms_xslprocessor.valueOf(l_n_child,'LASTSTATEMENTDATE/text()',ps_LASTSTATEMENTDATE);
  dbms_xslprocessor.valueOf(l_n_child,'LASTPAYMENTDATE/text()',ps_LASTPAYMENTDATE);
  dbms_xslprocessor.valueOf(l_n_child,'NEARESTSTATEMENTDATE/text()',ps_NEARESTSTATEMENTDATE);
  dbms_xslprocessor.valueOf(l_n_child,'STATEMENTCODE/text()',ps_STATEMENTCODE);
  dbms_xslprocessor.valueOf(l_n_child,'MINPAYMENTAMOUNT/text()',ps_MINPAYMENTAMOUNT);
  dbms_xslprocessor.valueOf(l_n_child,'TOTALDEBT/text()',ps_TOTALDEBT);
 END LOOP;
 FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl_details) - 1 LOOP
  l_n_details := dbms_xmldom.item(l_nl_details, cur_emp);
  dbms_xslprocessor.valueOf(l_n_child,'CARDNO/text()',ls_subCARDNO);
  dbms_xslprocessor.valueOf(l_n_child,'CUSTOMERNO/text()',ls_subCUSTOMERNO);
  dbms_xslprocessor.valueOf(l_n_child,'REESKDATE/text()',ls_REESKDATE);
  dbms_xslprocessor.valueOf(l_n_child,'SOURCE/text()',ls_SOURCE);
  dbms_xslprocessor.valueOf(l_n_child,'TRANSACTIONDATE/text()',ls_TRANSACTIONDATE);
  dbms_xslprocessor.valueOf(l_n_child,'DESCRIPTION/text()',ls_DESCRIPTION);
  dbms_xslprocessor.valueOf(l_n_child,'MERCHANTNAME/text()',ls_MERCHANTNAME);
  dbms_xslprocessor.valueOf(l_n_child,'MERCHANTCITY/text()',ls_MERCHANTCITY);
  dbms_xslprocessor.valueOf(l_n_child,'CODE/text()',ls_CODE);
  dbms_xslprocessor.valueOf(l_n_child,'TYPE/text()',ls_TYPE);
  dbms_xslprocessor.valueOf(l_n_child,'AMOUNT/text()',ls_AMOUNT);
  dbms_xslprocessor.valueOf(l_n_child,'ORGAMOUNT/text()',ls_ORGAMOUNT);
  r_details.extend();
  r_details(cur_emp+1) := statsimreq_details(ls_subCARDNO, ls_subCUSTOMERNO, ls_REESKDATE, ls_SOURCE, ls_TRANSACTIONDATE, ls_DESCRIPTION, ls_MERCHANTNAME, ls_MERCHANTCITY, ls_CODE, ls_TYPE, ls_AMOUNT, ls_ORGAMOUNT);
 END LOOP;
 open PC_REF for
        SELECT * FROM table(cast (r_details as statsimreq_list));
 ld_endtime:=SYSDATE;

 Pkg_debit_Card.WS_LOG('CREDIT CARD STATSIMREQ',serviceUrl,methodName,ld_starttime,ld_endtime,ps_response_Code,NULL,null/*r_ccoper.tx_no*/,null/*pn_app_id*/,result,REQ.BODY);  

EXCEPTION
 WHEN OTHERS THEN
   rollback;
   ps_response_Code:= '096';
   ps_response_Desc := sqlcode||' '||sqlerrm ; 
   Pkg_debit_Card.WS_LOG('CREDIT CARD STATSIMREQ',serviceUrl,methodName,ld_starttime,ld_endtime,'096',sqlcode||' '||sqlerrm,null/*r_ccoper.tx_no*/,null/*pn_app_id*/,result,REQ.BODY);
   log_at('SP_STATSIMREQ_WS', sqlcode||' '||sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/******************************************************************************
  NAME        : PROCEDURE SP_CUSTGROUP_UPD_WS
  Prepared By : IadgarB
  Date        : 27.03.2020
  Purpose     : Customer Group Update
******************************************************************************/ 
PROCEDURE SP_CUSTGROUP_UPD_WS(PN_CUSTOMER_NO IN NUMBER, PN_BS_NO IN NUMBER, PS_CUST_GROUP IN VARCHAR2) 
IS
    pn_app_id             NUMBER := pkg_genel.genel_kod_al ('CBS_CARD_CREDIT_APP');
    ps_response_code      VARCHAR2(2000);
    ps_response_desc      VARCHAR2(2000);
    serviceUrl            VARCHAR2 (2000);
    soapAction            VARCHAR2 (2000);
    namespace             VARCHAR2 (2000);
    methodName            VARCHAR2 (2000);
    req                   Pkg_Soap.request;
    resp                  Pkg_Soap.response;
    result                CLOB;                         --NVARCHAR2(32767);
    referenceId           INTEGER;

    l_parser              DBMS_XMLPARSER.Parser;
    l_doc                 DBMS_XMLDOM.DOMDocument;
    l_nl                  DBMS_XMLDOM.DOMNodeList;
    l_n                   DBMS_XMLDOM.DOMNode;

    ld_starttime          DATE;
    ld_endtime            DATE;
    ls_BS_WS_SERVICE_URL  VARCHAR2 (200);
    ls_BANKCODE           VARCHAR2 (200);

  BEGIN
    pkg_parametre.deger ('BS_CWS_SERVICE_URL', ls_BS_WS_SERVICE_URL);
    pkg_parametre.deger ('OUR_BANK_CODE', ls_BANKCODE);

    ld_starttime := SYSDATE;

    serviceUrl := ls_BS_WS_SERVICE_URL;
    namespace := 'http://www.banksoft.com.tr';
    methodName := 'PersonalInfoUpdate';
    soapAction := namespace || '/KirgizDemirWS/' || methodName;
    namespace := 'xmlns="' || namespace || '"';

    req := Pkg_Soap.new_request(methodName, namespace);

    Pkg_Soap.ADD_PARAMETER (
         req,
         'PIT',
         NULL,
            '<CBSNO                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || LPAD (SUBSTR (PN_CUSTOMER_NO, 1, 13), 13, '0')   || ']]></CBSNO>'
         || '<BSCUSTOMERNO              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || PN_BS_NO || ']]></BSCUSTOMERNO>' --BS Number
         || '<USERID                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || SUBSTR (USER, 1, 8) || ']]></USERID>' 
         || '<DEALER_CODE               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || SUBSTR (USER, 1, 8) || ']]></DEALER_CODE>'
         || '<BANKCODE                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || ls_BANKCODE || ']]></BANKCODE>'
         || '<CUSTOMER_GROUP            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || PS_CUST_GROUP || ']]></CUSTOMER_GROUP>'
        ); 

    resp := Pkg_Soap.invoke_utf8_v11_card (req, serviceUrl, soapAction);
    result := resp.doc.getstringval ();
          
    result := REPLACE (result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"', '');
    result := REPLACE (result, ' xmlns="http://www.banksoft.com.tr"', '');

    l_parser := DBMS_XMLPARSER.newParser;
    DBMS_XMLPARSER.parseclob(l_parser, result);
    
    l_doc := DBMS_XMLPARSER.getDocument(l_parser);
    l_nl := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode(l_doc), 'PersonalInfoUpdateResponse/PersonalInfoUpdateResult');

    FOR cur_emp IN 0 .. DBMS_XMLDOM.getLength(l_nl) - 1
    LOOP
        l_n := DBMS_XMLDOM.item (l_nl, cur_emp);
        DBMS_XSLPROCESSOR.valueOf (l_n, 'RCODE', ps_response_Code);
        DBMS_XSLPROCESSOR.valueOf (l_n, 'RDESC', ps_response_Desc);
    END LOOP;

    ld_endtime := SYSDATE;

    Pkg_debit_Card.WS_LOG ('CREDIT_CARD_CGROUP_UPDATE',
                            serviceUrl,
                            methodName,
                            ld_starttime,
                            ld_endtime,
                            ps_response_Code,
                            ps_response_Desc,
                            NULL,
                            pn_app_id,
                            result,
                            REQ.BODY);
  EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        ps_response_Code := '999';
        ps_response_Desc := SQLCODE || ' ' || SQLERRM;
        Pkg_debit_Card.WS_LOG ('CREDIT_CARD_CGROUP_UPDATE',
                                serviceUrl,
                                methodName,
                                ld_starttime,
                                ld_endtime,
                                ps_response_Code,
                                ps_response_Desc,
                                NULL,
                                pn_app_id,
                                result,
                                REQ.BODY);
  END;
 
/******************************************************************************
  NAME        : PROCEDURE SP_CUSTGROUP_UPD_WS
  Prepared By : NurmilaZ
  Date        : 27.03.2020
  Purpose     : Customer Group Update
******************************************************************************/ 
PROCEDURE SP_WS_CUSTGROUP(PN_CUSTOMER_NO IN NUMBER, PN_BS_NO IN NUMBER, PS_CUST_GROUP IN VARCHAR2,LS_STATEMENT_CODE IN VARCHAR2 ,  PS_PINSENDINGBRANCH IN VARCHAR2, PS_SENDINGBRANCH  IN VARCHAR2)  ----GulkaiyrK cbs-394
IS
  PN_APP_ID             NUMBER := PKG_GENEL.GENEL_KOD_AL ('CBS_CARD_CREDIT_APP');
    PS_RESPONSE_CODE      VARCHAR2(2000);
    PS_RESPONSE_DESC      VARCHAR2(2000);
    SERVICEURL            VARCHAR2 (2000);
    SOAPACTION            VARCHAR2 (2000);
    NAMESPACE             VARCHAR2 (2000);
    METHODNAME            VARCHAR2 (2000);
    REQ                   PKG_SOAP.REQUEST;
    RESP                  PKG_SOAP.RESPONSE;
    RESULT                CLOB;                         --NVARCHAR2(32767);
    REFERENCEID           INTEGER;

    L_PARSER              DBMS_XMLPARSER.PARSER;
    L_DOC                 DBMS_XMLDOM.DOMDOCUMENT;
    L_NL                  DBMS_XMLDOM.DOMNODELIST;
    L_N                   DBMS_XMLDOM.DOMNODE;

    LD_STARTTIME          DATE;
    LD_ENDTIME            DATE;
    LS_BS_WS_SERVICE_URL  VARCHAR2 (200);
    LS_BANKCODE           VARCHAR2 (200);
    CARD_PIN_SENDINGBRANCH   VARCHAR2 (200);
   -- PS_SENDINGBRANCH  VARCHAR2 (200);
    
 
  BEGIN
    PKG_PARAMETRE.DEGER ('BS_CWS_SERVICE_URL', LS_BS_WS_SERVICE_URL);
    PKG_PARAMETRE.DEGER ('OUR_BANK_CODE', LS_BANKCODE);

    LD_STARTTIME := SYSDATE;

    SERVICEURL := LS_BS_WS_SERVICE_URL;
    NAMESPACE := 'http://www.banksoft.com.tr';
    METHODNAME := 'PersonalInfoUpdate';
    SOAPACTION := NAMESPACE || '/KirgizDemirWS/' || METHODNAME;
    NAMESPACE := 'xmlns="' || NAMESPACE || '"';

    REQ := PKG_SOAP.NEW_REQUEST(METHODNAME, NAMESPACE);

    PKG_SOAP.ADD_PARAMETER (
         REQ,
         'PIT',
         NULL,
            '<CBSNO                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || LPAD (SUBSTR (PN_CUSTOMER_NO, 1, 13), 13, '0')   || ']]></CBSNO>'
         || '<BSCUSTOMERNO              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || PN_BS_NO || ']]></BSCUSTOMERNO>' --BS Number
         || '<USERID                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || SUBSTR (USER, 1, 8) || ']]></USERID>' 
         || '<DEALER_CODE               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || SUBSTR (USER, 1, 8) || ']]></DEALER_CODE>'
         || '<BANKCODE                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || LS_BANKCODE || ']]></BANKCODE>'
         || '<CUSTOMER_GROUP            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || PS_CUST_GROUP || ']]></CUSTOMER_GROUP>'
         || '<STATEMENT_CODE            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || LS_STATEMENT_CODE        || ']]></STATEMENT_CODE >' 
         || '<CARD_PINSENDINGBRANCH     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || LPAD (PS_PINSENDINGBRANCH, 4, '0')         || ']]></CARD_PINSENDINGBRANCH> '
         || '<BRANCH_CODE               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || LPAD (PS_SENDINGBRANCH, 4, '0')|| ']]></BRANCH_CODE >'   --GulkaiyrK cbs-394    
         || '<PRODUCTUPGRADE             xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' ||    'Y'  || ']]></PRODUCTUPGRADE>'  --GulkaiyrK cbs-394
     ); 

    RESP := PKG_SOAP.INVOKE_UTF8_V11_CARD (REQ, SERVICEURL, SOAPACTION);
    RESULT := RESP.DOC.GETSTRINGVAL ();
          
    RESULT := REPLACE (RESULT, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"', '');
    RESULT := REPLACE (RESULT, ' xmlns="http://www.banksoft.com.tr"', '');

    L_PARSER := DBMS_XMLPARSER.NEWPARSER;
    DBMS_XMLPARSER.PARSECLOB(L_PARSER, RESULT);
    
    L_DOC := DBMS_XMLPARSER.GETDOCUMENT(L_PARSER);
    L_NL := DBMS_XSLPROCESSOR.SELECTNODES(DBMS_XMLDOM.MAKENODE(L_DOC), 'PersonalInfoUpdateResponse/PersonalInfoUpdateResult');

    FOR CUR_EMP IN 0 .. DBMS_XMLDOM.GETLENGTH(L_NL) - 1
    LOOP
        L_N := DBMS_XMLDOM.ITEM (L_NL, CUR_EMP);
        DBMS_XSLPROCESSOR.VALUEOF (L_N, 'RCODE', PS_RESPONSE_CODE);
        DBMS_XSLPROCESSOR.VALUEOF (L_N, 'RDESC', PS_RESPONSE_DESC);
    END LOOP;

    LD_ENDTIME := SYSDATE;

    PKG_DEBIT_CARD.WS_LOG ('CREDIT_CARD_CGROUP_UPDATE',
                            SERVICEURL,
                            METHODNAME,
                            LD_STARTTIME,
                            LD_ENDTIME,
                            PS_RESPONSE_CODE,
                            PS_RESPONSE_DESC,
                            NULL,
                            PN_APP_ID,
                            RESULT,
                            REQ.BODY);
  EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        PS_RESPONSE_CODE := '999';
        PS_RESPONSE_DESC := SQLCODE || ' ' || SQLERRM;
        PKG_DEBIT_CARD.WS_LOG ('CREDIT_CARD_CGROUP_UPDATE',
                                SERVICEURL,
                                METHODNAME,
                                LD_STARTTIME,
                                LD_ENDTIME,
                                PS_RESPONSE_CODE,
                                PS_RESPONSE_DESC,
                                NULL,
                                PN_APP_ID,
                                RESULT,
                                REQ.BODY);
  END;
  /******************************************************************************
      NAME        : PROCEDURE SP_PRODUCT_CODE_UPGRADE
      Prepared By : Nurzalat Alimzhan uulu
      Date        : 16.07.2018
      Purpose     : Upgrade Product Code and Reissue of Lost Cards WS
   ******************************************************************************/
   PROCEDURE SP_PRODUCT_CODE_UPGRADE (PN_APP_ID             IN  NUMBER,
                                      PS_RESPONSE_CODE      OUT VARCHAR2,
                                      PS_RESPONSE_DESC      OUT VARCHAR2,
                                      PS_NEW_PAN            OUT VARCHAR2,
                                      PS_NEW_CARDNO         OUT VARCHAR2)
   IS
      CURSOR CUR_CCOPER IS 
                SELECT * FROM CBS_CREDIT_CARD_UPD_APP_TX WHERE APP_ID = PN_APP_ID;

      CURSOR CUR_CC_PROD_CODE (LS_PRODUCT_CODE VARCHAR2) IS 
                SELECT * FROM CBS_PRODUCT_CODES WHERE CODE = LS_PRODUCT_CODE;

      R_CCOPER                CUR_CCOPER%ROWTYPE;
      R_CC_PROD_CODE          CUR_CC_PROD_CODE%ROWTYPE;
      SERVICEURL              VARCHAR2 (2000);
      SOAPACTION              VARCHAR2 (2000);
      NAMESPACE               VARCHAR2 (2000);
      METHODNAME              VARCHAR2 (2000);
      REQ                     PKG_SOAP.REQUEST;
      RESP                    PKG_SOAP.RESPONSE;
      RESULT                  CLOB;

      L_PARSER                DBMS_XMLPARSER.PARSER;
      L_DOC                   DBMS_XMLDOM.DOMDOCUMENT;
      L_NL                    DBMS_XMLDOM.DOMNODELIST;
      L_N                     DBMS_XMLDOM.DOMNODE;

      LD_STARTTIME            DATE;
      LD_ENDTIME              DATE;

      LS_BS_CWS_SERVICE_URL   VARCHAR2 (200);
      L_PSEUDOPANNO           VARCHAR2 (20);
      PN_BANKSOFT_NO          NUMBER;
      PN_EXTEND_EXP_DATE      VARCHAR2 (1) := 'N';
      LS_HEADER_METHOD   VARCHAR2 (256);
      LS_HEADER_USER     VARCHAR2 (256);
      LS_HEADER_PASS     VARCHAR2 (256);
   BEGIN
      PKG_PARAMETRE.DEGER ('BS_CWS_SERVICE_URL', LS_BS_CWS_SERVICE_URL);

      FOR C_CCOPER IN CUR_CCOPER
      LOOP
         R_CCOPER := C_CCOPER;
      END LOOP;

      FOR C_CC_PROD_CODE IN CUR_CC_PROD_CODE (R_CCOPER.NEW_PRODUCT_CODE)
      LOOP
         R_CC_PROD_CODE := C_CC_PROD_CODE;
      END LOOP;

      IF R_CCOPER.STATUS_WILL_BE_UPDATED='Y' THEN
          PN_EXTEND_EXP_DATE := 'Y';
      END IF;
      
      LD_STARTTIME := SYSDATE;
      L_PSEUDOPANNO := R_CCOPER.CARD_ID_NO;
      PN_BANKSOFT_NO := R_CCOPER.CUSTOMER_NO;
      SERVICEURL := LS_BS_CWS_SERVICE_URL;
      NAMESPACE := 'http://www.banksoft.com.tr';
      METHODNAME := 'ProductUpgrade';
      SOAPACTION := NAMESPACE || '/KirgizDemirWS/' || METHODNAME;
      NAMESPACE := 'xmlns="' || NAMESPACE || '"';

      REQ := PKG_SOAP.NEW_REQUEST (METHODNAME, NAMESPACE);

      PKG_SOAP.ADD_PARAMETER ( REQ, 'PUI', NULL,
         '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || SUBSTR (L_PSEUDOPANNO, 1, 19) || ']]></PSEUDOPAN>'
         || '<NEWPRODUCTCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CCOPER.NEW_PRODUCT_CODE || ']]></NEWPRODUCTCODE>'
         || '<NEWCARDGRUP xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CC_PROD_CODE.CARD_GROUP || ']]></NEWCARDGRUP>'
         || '<NEWCARDSTYLE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CC_PROD_CODE.CARD_STYLE_CODE || ']]></NEWCARDSTYLE>'
         || '<CARD_PINSENDINGBRANCH xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || LPAD(R_CCOPER.CARD_PINSENDINGBRANCH, 4, '0') || ']]></CARD_PINSENDINGBRANCH>'
         || '<PINEMBOSSFLAG xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CCOPER.PINEMBOSSFLAG || ']]></PINEMBOSSFLAG>'
         || '<PRICING_GROUP xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CCOPER.PRICING_GROUP || ']]></PRICING_GROUP>'
         || '<STATEMENTCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CCOPER.STATEMENTCODE || ']]></STATEMENTCODE>'
         || '<OLDCARDSTATUS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CCOPER.STATUS_WILL_BE_UPDATED || ']]></OLDCARDSTATUS>'
         || '<OLDCARDSUBSTATUS xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CCOPER.SUBSTATUS || ']]></OLDCARDSUBSTATUS>'
         || '<USERCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || R_CCOPER.USERID || ']]></USERCODE>'
         || '<EXTEND_EXP_DATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeRequestType"><![CDATA[' || PN_EXTEND_EXP_DATE || ']]></EXTEND_EXP_DATE>');

      RESP := PKG_SOAP.INVOKE_UTF8_V11_CARD (REQ, SERVICEURL, SOAPACTION);

      RESULT := RESP.DOC.GETSTRINGVAL();

      RESULT := REPLACE (RESULT, ' xmlns="http://www.banksoft.com.tr"', '');
      RESULT := REPLACE (RESULT, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ProductUpgradeResponseType"', '');

      L_PARSER := DBMS_XMLPARSER.NEWPARSER;

      DBMS_XMLPARSER.PARSECLOB (L_PARSER, RESULT);
      L_DOC := DBMS_XMLPARSER.GETDOCUMENT (L_PARSER);
      L_NL := DBMS_XSLPROCESSOR.SELECTNODES (DBMS_XMLDOM.MAKENODE (L_DOC), 'ProductUpgradeResponse/ProductUpgradeResult');

      FOR CUR_EMP IN 0 .. DBMS_XMLDOM.GETLENGTH (L_NL) - 1
      LOOP
         L_N := DBMS_XMLDOM.ITEM (L_NL, CUR_EMP);
         -- Use XPATH syntax to assign values to he elements of the collection.
         DBMS_XSLPROCESSOR.VALUEOF (L_N, 'NEWCARDNO/text()', PS_NEW_CARDNO);
         DBMS_XSLPROCESSOR.VALUEOF (L_N, 'NEWPSEUDOPAN/text()', PS_NEW_PAN);
         DBMS_XSLPROCESSOR.VALUEOF (L_N, 'RCODE/text()', PS_RESPONSE_CODE);
         DBMS_XSLPROCESSOR.VALUEOF (L_N, 'RDESC/text()', PS_RESPONSE_DESC);
      END LOOP;

      LD_ENDTIME := SYSDATE;

      SP_UPD_CREDIT_CARD_APP_ISLEM ('UPD',
                                    PN_APP_ID,
                                    PN_BANKSOFT_NO,
                                    PS_RESPONSE_CODE,
                                    PS_RESPONSE_DESC,
                                    NULL,
                                    PS_NEW_PAN,
                                    NULL);

      PKG_DEBIT_CARD.WS_LOG ('CREDIT CARD',
                             SERVICEURL,
                             METHODNAME,
                             LD_STARTTIME,
                             LD_ENDTIME,
                             PS_RESPONSE_CODE,
                             NULL,
                             R_CCOPER.TX_NO,
                             PN_APP_ID,
                             RESULT,
                             REQ.BODY);
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         PS_RESPONSE_CODE := '096';
         PS_RESPONSE_DESC := SQLCODE || ' ' || SQLERRM;
         PKG_DEBIT_CARD.WS_LOG ('CREDIT CARD', SERVICEURL, METHODNAME, LD_STARTTIME, LD_ENDTIME, '096', SQLCODE || ' ' || SQLERRM, R_CCOPER.TX_NO, PN_APP_ID, RESULT, REQ.BODY);
         LOG_AT ('SP_PRODUCT_CODE_UPGRADE', SQLCODE || ' ' || SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;
FUNCTION SF_CHECK_PROPOSAL_MONTH(PN_MUSTERI_NO NUMBER) RETURN BOOLEAN
IS
LS_COUNT NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO LS_COUNT
      FROM CBS_VW_KREDI_TEKLIF_IZLEME WHERE MUSTERI_NO = PN_MUSTERI_NO 
                                  AND DURUM_KODU = 'A' 
                                  AND DURUM = 'P'
                                  AND TO_CHAR(ONAY_TARIH,'MMYYYY') = TO_CHAR(PKG_MUHASEBE.BANKA_TARIHI_BUL,'MMYYYY');
    IF LS_COUNT > 0 THEN
        RETURN TRUE;
    ELSE 
        RETURN FALSE; 
    END IF;                     
EXCEPTION
        WHEN OTHERS THEN
          RETURN TRUE;            
END;
FUNCTION SF_GET_CUSTGROUP_EXP(PN_CODE VARCHAR2) RETURN VARCHAR2
IS
LN_CODE VARCHAR2(100 BYTE);
CURSOR CUR_EXP IS
   SELECT EXPLANATION FROM CBS_CC_CUSTOMER_GROUP WHERE CODE=PN_CODE;
ROW_CUR_EXP CUR_EXP%ROWTYPE;
BEGIN

    FOR ROW_CUR_EXP IN CUR_EXP LOOP 
     LN_CODE := ROW_CUR_EXP.EXPLANATION;
    END LOOP;
    
    RETURN LN_CODE;
END;
FUNCTION SF_GET_PRODUCT_EXP(PN_CODE VARCHAR2) RETURN VARCHAR2
IS
LN_CODE VARCHAR2(100 BYTE);
CURSOR CUR_EXP IS
   SELECT EXPLANATION FROM CBS_PRODUCT_CODES WHERE CODE=PN_CODE;
ROW_CUR_EXP CUR_EXP%ROWTYPE;
BEGIN

    FOR ROW_CUR_EXP IN CUR_EXP LOOP 
     LN_CODE := ROW_CUR_EXP.EXPLANATION;
    END LOOP;
    
    RETURN LN_CODE;
END;
FUNCTION SF_GET_PRICING_EXP(PN_CODE VARCHAR2) RETURN VARCHAR2
IS
LN_CODE VARCHAR2(100 BYTE);
CURSOR CUR_EXP IS
   SELECT EXPLANATION FROM CBS_PRICE_GROUP_CODES WHERE CODE=PN_CODE;
ROW_CUR_EXP CUR_EXP%ROWTYPE;
BEGIN

    FOR ROW_CUR_EXP IN CUR_EXP LOOP 
     LN_CODE := ROW_CUR_EXP.EXPLANATION;
    END LOOP;
    
    RETURN LN_CODE;
END;
FUNCTION SF_GET_STATEMENT_EXP(PN_CODE VARCHAR2) RETURN VARCHAR2
IS
LN_CODE VARCHAR2(100 BYTE);
CURSOR CUR_EXP IS
   SELECT EXPLANATION FROM CBS_CC_STATEMENT_CODE WHERE CODE=PN_CODE;
ROW_CUR_EXP CUR_EXP%ROWTYPE;
BEGIN

    FOR ROW_CUR_EXP IN CUR_EXP LOOP 
     LN_CODE := ROW_CUR_EXP.EXPLANATION;
    END LOOP;
    
    RETURN LN_CODE;
END;
FUNCTION SF_GET_CARD_STYLE_CODE_EXP(PN_CODE VARCHAR2) RETURN VARCHAR2
IS
LN_CODE VARCHAR2(100 BYTE);
CURSOR CUR_EXP IS
   SELECT EXPLANATION FROM CBS_CARD_STYLE_CODES WHERE CODE=PN_CODE;
ROW_CUR_EXP CUR_EXP%ROWTYPE;
BEGIN

    FOR ROW_CUR_EXP IN CUR_EXP LOOP 
     LN_CODE := ROW_CUR_EXP.EXPLANATION;
    END LOOP;
    
    RETURN LN_CODE;
END;

/******************************************************************************
  NAME        : PROCEDURE SP_WS_CUSTGROUP
  Prepared By : GulkaiyrK
  Date        : 20.05.2021
  Purpose     :  Customer and Statement  Group Update screen 7160
******************************************************************************/ 
procedure sp_state_cust_group(pn_customer_no in number, pn_bs_no in number, ps_cust_group in varchar2 ,ls_statement_code in varchar2  )  ----GulkaiyrK cbs-394
is
    pn_app_id             number := pkg_genel.genel_kod_al ('CBS_CARD_CREDIT_APP');
    ps_response_code      varchar2(2000);
    ps_response_desc      varchar2(2000);
    serviceurl            varchar2 (2000);
    soapaction            varchar2 (2000);
    namespace             varchar2 (2000);
    methodname            varchar2 (2000);
    req                   pkg_soap.request;
    resp                  pkg_soap.response;
    result                clob;                         --NVARCHAR2(32767);
    referenceid           integer;

    l_parser              dbms_xmlparser.parser;
    l_doc                 dbms_xmldom.domdocument;
    l_nl                  dbms_xmldom.domnodelist;
    l_n                   dbms_xmldom.domnode;

    ld_starttime          date;
    ld_endtime            date;
    ls_bs_ws_service_url  varchar2 (200);
    ls_bankcode           varchar2 (200);
     
 
  begin
    pkg_parametre.deger ('BS_CWS_SERVICE_URL', ls_bs_ws_service_url);
    pkg_parametre.deger ('OUR_BANK_CODE', ls_bankcode);                            

    ld_starttime := sysdate;

    serviceurl := ls_bs_ws_service_url;
    namespace := 'http://www.banksoft.com.tr';
    methodname := 'PersonalInfoUpdate';
    soapaction := namespace || '/KirgizDemirWS/' || methodname;
    namespace := 'xmlns="' || namespace || '"';

    req := pkg_soap.new_request(methodname, namespace);

    pkg_soap.add_parameter (
         req,
         'PIT',
         null,
            '<CBSNO                     xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || lpad (substr (pn_customer_no, 1, 13), 13, '0')   || ']]></CBSNO>'
         || '<BSCUSTOMERNO              xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || pn_bs_no || ']]></BSCUSTOMERNO>' --BS Number
         || '<USERID                    xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || substr (user, 1, 8) || ']]></USERID>' 
         || '<DEALER_CODE               xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || substr (user, 1, 8) || ']]></DEALER_CODE>'
         || '<BANKCODE                  xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || ls_bankcode || ']]></BANKCODE>'
         || '<CUSTOMER_GROUP            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || ps_cust_group || ']]></CUSTOMER_GROUP>'
         || '<STATEMENT_CODE            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' || ls_statement_code        || ']]></STATEMENT_CODE >' 
         || '<PRODUCTUPGRADE            xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PersonalInfoType2"><![CDATA[' ||    'N'  || ']]></PRODUCTUPGRADE>'   
     ); 

    resp := pkg_soap.invoke_utf8_v11_card (req, serviceurl, soapaction);
    result := resp.doc.getstringval ();
          
    result := replace (result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"', '');
    result := replace (result, ' xmlns="http://www.banksoft.com.tr"', '');

    l_parser := dbms_xmlparser.newparser;
    dbms_xmlparser.parseclob(l_parser, result);
    
    l_doc := dbms_xmlparser.getdocument(l_parser);
    l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc), 'PersonalInfoUpdateResponse/PersonalInfoUpdateResult');

    for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1
    loop
        l_n := dbms_xmldom.item (l_nl, cur_emp);
        dbms_xslprocessor.valueof (l_n, 'RCODE', ps_response_code);
        dbms_xslprocessor.valueof (l_n, 'RDESC', ps_response_desc);
    end loop;

    ld_endtime := sysdate;

    pkg_debit_card.ws_log ('7160_CSGROUP_UPDATE',
                            serviceurl,
                            methodname,
                            ld_starttime,
                            ld_endtime,
                            ps_response_code,
                            ps_response_desc,
                            null,
                            pn_app_id,
                            result,
                            req.body);
  exception
    when others then
        rollback;
        ps_response_code := '999';
        ps_response_desc := sqlcode || ' ' || sqlerrm;
        pkg_debit_card.ws_log ('7160_CSGROUP_UPDATE',
                                serviceurl,
                                methodname,
                                ld_starttime,
                                ld_endtime,
                                ps_response_code,
                                ps_response_desc,
                                null,
                                pn_app_id,
                                result,
                                req.body);
  end;

   /******************************************************************************
    NAME        : PROCEDURE SP_FINANCIAL_MAINTENANCE_CALL_WS
    Prepared By : NursultanSa
    Date        : 08.07.2022
    Purpose     :  CBS-415 Money transfers from the customers’ debit account to the customers’ credit limit through CBS
******************************************************************************/ 
    PROCEDURE SP_FINANCIAL_MAINTENANCE_CALL_WS(
         TX_NO NUMBER,
         PN_MSGCODE NUMBER,
         PS_PSEUDOPAN VARCHAR2,
         PS_TRNDATE VARCHAR2,
         PS_VALDATE VARCHAR2,
         PN_TRNAMOUNT NUMBER,
         PS_TRNTYPE VARCHAR2,
         PS_TRNCODE VARCHAR2,
         PS_TRNSUBCODE VARCHAR2,
         PS_TRNDESC VARCHAR2,
         PS_SOURCECODE VARCHAR2,
         PS_REFERANCE VARCHAR2,
         PS_USERCODE VARCHAR, 
         PS_RESPONSE_CODE OUT VARCHAR2, 
         PS_RESPONSE_DESC OUT VARCHAR2
   ) IS 
        SERVICEURL              VARCHAR2(2000);
        SOAPACTION              VARCHAR2(2000);
        NAMESPACE               VARCHAR2(2000);
        METHODNAME              VARCHAR2(2000);
        PN_APP_ID               NUMBER;
        REQ                     PKG_SOAP.REQUEST;
        RESP                    PKG_SOAP.RESPONSE;
        RESULT                  CLOB;
        L_PARSER                DBMS_XMLPARSER.PARSER;
        L_DOC                   DBMS_XMLDOM.DOMDOCUMENT;
        L_NL                    DBMS_XMLDOM.DOMNODELIST;
        L_N                     DBMS_XMLDOM.DOMNODE;
        LD_STARTTIME            DATE;
        LD_ENDTIME              DATE;
        LS_BS_CWS_SERVICE_URL   VARCHAR2(200);
       
    BEGIN
        LD_STARTTIME := SYSDATE;
        PKG_PARAMETRE.DEGER('BS_CWS_SERVICE_URL', LS_BS_CWS_SERVICE_URL);
        PN_APP_ID := PKG_GENEL.GENEL_KOD_AL('FM_KOD');
        
        SERVICEURL := LS_BS_CWS_SERVICE_URL;
        NAMESPACE  := 'http://www.banksoft.com.tr';
        METHODNAME := 'FinancialMaintenance';
        SOAPACTION := NAMESPACE || '/KirgizDemirWS/' || METHODNAME;
        NAMESPACE  := 'xmlns="' || NAMESPACE || '"';

        REQ := PKG_SOAP.NEW_REQUEST(METHODNAME, NAMESPACE);

        PKG_SOAP.ADD_PARAMETER(REQ, 'FMReq', NULL,
            '<MSGCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['   || PN_MSGCODE    || ']]></MSGCODE>'    || 
            '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA[' || PS_PSEUDOPAN  || ']]></PSEUDOPAN>'  ||
            '<TRNDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['   || PS_TRNDATE    || ']]></TRNDATE>'    ||
            '<VALDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['   || PS_VALDATE    || ']]></VALDATE>'    ||
            '<TRNAMOUNT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA[' || to_char(PN_TRNAMOUNT, '9999999999999999999.99')  || ']]></TRNAMOUNT>'  ||
            '<TRNTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['   || PS_TRNTYPE    || ']]></TRNTYPE>'    ||
            '<TRNCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['   || PS_TRNCODE    || ']]></TRNCODE>'    ||
            '<TRNSUBCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['|| PS_TRNSUBCODE || ']]></TRNSUBCODE>' ||
            '<REFERANCE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA[' || PS_REFERANCE  || ']]></REFERANCE>'  ||
            '<USERCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['  || PS_USERCODE   || ']]></USERCODE>'   ||
            '<SOURCECODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['|| PS_SOURCECODE || ']]></SOURCECODE>' ||
            '<TRNDESC xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceRequestType"><![CDATA['   || PS_TRNDESC    || ']]></TRNDESC>');
        
        RESP := PKG_SOAP.INVOKE_UTF8_V11_CARD(REQ, SERVICEURL, SOAPACTION);
        RESULT := RESP.DOC.GETSTRINGVAL();

        RESULT:= REPLACE(RESULT,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/FinancialMaintenanceResponseType"','');
        RESULT:= REPLACE(RESULT,' xmlns="http://www.banksoft.com.tr"','');
    
        L_PARSER := DBMS_XMLPARSER.NEWPARSER;

        DBMS_XMLPARSER.PARSECLOB(L_PARSER, RESULT);
        L_DOC := DBMS_XMLPARSER.GETDOCUMENT(L_PARSER);
        L_NL := DBMS_XSLPROCESSOR.SELECTNODES(DBMS_XMLDOM.MAKENODE(L_DOC),'FinancialMaintenanceResponse/FinancialMaintenanceResult');

        FOR CUR_EMP IN 0 .. DBMS_XMLDOM.GETLENGTH(L_NL) - 1 LOOP
            L_N := DBMS_XMLDOM.ITEM(L_NL, CUR_EMP);
            DBMS_XSLPROCESSOR.VALUEOF(L_N,'RCODE',PS_RESPONSE_CODE);
            DBMS_XSLPROCESSOR.VALUEOF(L_N,'RDESC',PS_RESPONSE_DESC);
        END LOOP;
    
        LD_ENDTIME := SYSDATE;

        PKG_DEBIT_CARD.WS_LOG('FINANCIAL_MAINTENANCE', SERVICEURL, METHODNAME, LD_STARTTIME, LD_ENDTIME, PS_RESPONSE_CODE, PS_RESPONSE_DESC, TX_NO, PN_APP_ID, RESULT, REQ.BODY);

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            PS_RESPONSE_CODE := '999';
            PS_RESPONSE_DESC := SQLCODE || ' ' || SQLERRM;
            PKG_DEBIT_CARD.WS_LOG('FINANCIAL_MAINTENANCE', SERVICEURL, METHODNAME, LD_STARTTIME, LD_ENDTIME, PS_RESPONSE_CODE, PS_RESPONSE_DESC, TX_NO, PN_APP_ID, RESULT, REQ.BODY);
    END;


   /******************************************************************************
    NAME        : function get_credit_card_list
    Prepared By : NursultanSa
    Date        : 08.07.2022
    Purpose     :  CBS-415 Money transfers from the customers’ debit account to the customers’ credit limit through CBS
   ******************************************************************************/ 

    function get_credit_card_list (pn_customer_no in number) return cbs.credit_card_ntt 
    is 
        cc_nt                   credit_card_ntt := credit_card_ntt();
        l_card_no               varchar2(20);
        l_pseudopan             varchar2(20);
        l_status                varchar2(10);
        
        serviceUrl              VARCHAR2(2000);
        soapAction              VARCHAR2(2000);
        namespace               VARCHAR2(2000);
        methodName              VARCHAR2(2000);
        req                     PKG_SOAP.REQUEST;
        resp                    PKG_SOAP.RESPONSE;
        result                  CLOB;
        l_parser                DBMS_XMLPARSER.PARSER;
        l_doc                   DBMS_XMLDOM.DOMDOCUMENT;
        l_nl                    DBMS_XMLDOM.DOMNODELIST;
        l_n                     DBMS_XMLDOM.DOMNODE;
        ld_starttime            DATE;
        ld_endtime              DATE;
        ls_BS_CWS_SERVICE_URL   VARCHAR2(200);
        LS_RESPONSE_CODE        VARCHAR2 (10);
        
        procedure add_card ( p_card_no varchar2
                            ,p_pseudopan varchar2
                            ,p_status varchar2) 
        is 
        begin
            cc_nt.extend();
            cc_nt(cc_nt.last) := credit_card_ot(pn_customer_no, p_card_no, p_pseudopan, p_status);
        end add_card;
    BEGIN
        pkg_parametre.deger ('BS_CWS_SERVICE_URL', ls_BS_CWS_SERVICE_URL);

        ld_starttime := SYSDATE;

        serviceUrl := ls_BS_CWS_SERVICE_URL;
        namespace := 'http://www.banksoft.com.tr';
        methodName := 'GetCreditCardInfo';
        soapAction := namespace || '/' || methodname;
        namespace := 'xmlns="' || namespace || '"';

        req := Pkg_Soap.new_request(methodName, namespace);
        Pkg_Soap.ADD_PARAMETER(req, 'SDI', NULL, '<CRMNO xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GetCreditCardInfoRequestType"><![CDATA[' || LPAD(SUBSTR(pn_customer_no, 1, 13), 13, '0') || ']]></CRMNO>');
        resp := Pkg_Soap.invoke_utf8_v11_card_clob (req, serviceUrl, soapAction);
--        resp := Pkg_Soap.invoke_utf8_v11_cib_clob (req, serviceUrl, soapAction);

        result := resp.doc.getclobval();
        result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr"', '');
        result := REPLACE(result, ' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/GetCreditCardInfoResponseType"', '');

        l_parser := DBMS_XMLPARSER.newParser;
        DBMS_XMLPARSER.parseclob(l_parser, result);
        l_doc := DBMS_XMLPARSER.getDocument(l_parser);
        l_nl := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode(l_doc), 'GetCreditCardInfoResponse/GetCreditCardInfoResult/GetCreditCardInfoResponseType');

        FOR l_count IN 0 .. DBMS_XMLDOM.getLength (l_nl) - 1 LOOP
            l_n := DBMS_XMLDOM.item(l_nl, l_count);
            DBMS_XSLPROCESSOR.valueOf(l_n, 'PseudoPAN/text()', l_pseudopan);
            DBMS_XSLPROCESSOR.valueOf(l_n, 'Cardnumber/text()', l_card_no);
            DBMS_XSLPROCESSOR.valueOf(l_n, 'Status/text()', l_status);  
            DBMS_XSLPROCESSOR.valueOf (l_n, 'RCODE/text()', ls_response_code);   
            if LS_RESPONSE_CODE = '000' then add_card(l_card_no, l_pseudopan, l_status); end if;
        END LOOP;
        ld_endtime := SYSDATE;
        
        return cc_nt;
    exception 
        when others then 
            PKG_DEBIT_CARD.WS_LOG('GetCreditCardInfo', SERVICEURL, METHODNAME, LD_STARTTIME, LD_ENDTIME, '999', SQLCODE || ' ' || SQLERRM || dbms_utility.format_error_backtrace, null, null, RESULT, REQ.BODY);
            return null;  
    END;
END;
/

