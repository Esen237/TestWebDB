create PACKAGE BODY     PKG_INT_LOAN_TRX IS  

FUNCTION  PostPayInstallment(ps_lang varchar2,
                    ps_account_number varchar2,
                    ps_source_iban varchar2,
                    ps_channel_code varchar2 default '1',
                    ps_user_code varchar2 default 'CINT_CALLER',      
                    pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_role number := 7777;
ln_tran_no number;
ln_tran_code number;
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ln_cash_code number;
ln_from_account_number number;
ln_from_customer_number number;
ls_branch_code varchar2(3);
ls_currency_code varchar2(3);
ls_customer_type varchar2(1);
ln_no number;
ld_maturity_date date;
ln_day number;
ln_tutar number;
ln_calculated_close_interest number;
ln_total_interest number := 0;
ln_total_collection number;
ln_installment_interest number := 0;
ln_basic_date_number number;
ln_interest_rate number;

ls_source_currency_code varchar2(3 byte);
ln_source_account_no number;
ln_source_initial_balance number := 0;
ln_source_final_balance number := 0;
ln_source_amount number := 0;
ls_returncode varchar2(3):='000';
BEGIN

--Will deploying

     
      open pc_ref for
        select to_char(ln_tran_no) as transaction_number,
                ls_currency_code as currency_code,
                ln_source_initial_balance as initial_balance,
                ln_source_final_balance as final_balance,
                ln_total_collection as amount
                
        from dual;
          
  return ls_returncode;
  
EXCEPTION
    when no_data_found then
        log_at('newib','PostPayInstallment' || ln_tran_no, sqlerrm, dbms_utility.format_error_backtrace);
          return '452'; 
    when others then 
         log_at('newib','PostPayInstallment' || ln_tran_no, sqlerrm, dbms_utility.format_error_backtrace);
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm); 
         rollback;
         if ls_returncode= '999' then
          raise;
         end if; 
         open pc_ref for select sysdate from dual;
         return ls_returncode;
END;                                                                                       
END;
/

