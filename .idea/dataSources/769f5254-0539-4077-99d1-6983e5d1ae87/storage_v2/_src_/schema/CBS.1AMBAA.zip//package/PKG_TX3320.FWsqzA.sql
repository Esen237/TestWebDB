create PACKAGE     Pkg_Tx3320 IS

/******************************************************************************
   Name       : PKG_TX3320
   Created By : Gulnihal Cengiz
   Date    	  : 20.10.2005
   Purpose	  : YETAR - CBS_ROL_URUN_ISLEM_IPTAL
******************************************************************************/

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER );

  PROCEDURE Data_Kopyala_Silerek(pn_islem_no NUMBER,pn_rol NUMBER, pn_islem_kod NUMBER, pn_zaman NUMBER, pn_limit NUMBER,
 		   				ps_modul VARCHAR2, ps_urun_tur VARCHAR2, ps_urun_sinif VARCHAR2,
						ps_ayni_kullanici VARCHAR2 , ps_ayni_bolum VARCHAR2) ;

 PROCEDURE Data_Kopyala_Saklayarak(pn_islem_no NUMBER,pn_rol NUMBER, pn_islem_kod NUMBER, pn_zaman NUMBER, pn_limit NUMBER,
 		   				ps_modul VARCHAR2, ps_urun_tur VARCHAR2, ps_urun_sinif VARCHAR2,
						ps_ayni_kullanici VARCHAR2 , ps_ayni_bolum VARCHAR2) ;

 PROCEDURE Data_Kopyala_Saklayarak_Urunsz(pn_islem_no NUMBER,pn_rol NUMBER, pn_islem_kod NUMBER, pn_zaman NUMBER, pn_limit NUMBER,
 		   				ps_modul VARCHAR2, ps_urun_tur VARCHAR2, ps_urun_sinif VARCHAR2,
						ps_ayni_kullanici VARCHAR2 , ps_ayni_bolum VARCHAR2) ;

END;


/

