create PACKAGE BODY Pkg_Ihracat IS
/*--------------------------------------------------------------------------*/
Function GumrukKapiAdiBul(pn_kapi_no number) return varchar2 is
    ls_kapi_adi				cbs_gumruk_kapilari.KAPI_ADI%TYPE;
begin
	select g.KAPI_ADI
	into ls_kapi_adi
	from cbs_gumruk_kapilari g
	where kapi_no=pn_kapi_no;

	return ls_kapi_adi;
exception
	when no_data_found then
		 return null;
end;
/*--------------------------------------------------------------------------*/
Procedure DBTBilgiAktar(pn_txno number,ps_numara varchar2,pd_tarih date,pn_kapino	number) is
BEGIN
 	insert into cbs_dbt_islem
	(TX_NO,DBTID,TARIH, NUMARA, GUMRUK_KAPISI, DOVIZ_KODU, TUTAR, EFEKTIFI_GETIREN, PASAPORT_NO, TEYIT_YAZI_TARIHI, DURUM_KODU, BOLUM_KODU, TEYIT_YAZI_NO)
	(select pn_txno,DBTID,TARIH, NUMARA, GUMRUK_KAPISI, DOVIZ_KODU, TUTAR, EFEKTIFI_GETIREN, PASAPORT_NO, TEYIT_YAZI_TARIHI, DURUM_KODU, BOLUM_KODU, TEYIT_YAZI_NO
	from cbs_dbt
	where NUMARA=ps_numara AND TARIH=pd_tarih AND GUMRUK_KAPISI=pn_kapino);
END;
--------------------------------------------------------------------------
Function  DBTKullanilanTutar (ps_numara varchar2,pd_tarih date,pn_kapino number) return number is
		  ln_kullanilan		 NUMBER;
BEGIN
	 /*
	 --TODO 1
	 select sum(nvl(tutar,0))
	 into ln_kullanilan
	 from cbs_ihracat
	 where dbt_no=ps_numara
	 and dbt_tarih=pd_tarih;
	 */
	 select NVL(TUTAR,0)-NVL(DBT_BAKIYESI,0)
	 into ln_kullanilan
	 from cbs_DBT
	 where NUMARA=ps_numara
	 and TARIH=pd_tarih
	 and GUMRUK_KAPISI=pn_kapino;

	 return ln_kullanilan;
exception
     when no_data_found then
	 	  return 0;
END;
--------------------------------------------------------------------------
--------------------------------------------------------------------------
Procedure  DBTBakiyeGuncelle (ps_tur varchar2,ps_numara varchar2,pd_tarih date,pn_kapino number,pn_tutar number) is
	  ln_last_tutar				 number;
BEGIN
	 if ps_tur='A' then
	 	ln_last_tutar:=nvl(pn_tutar,0);
	 else--'B'
	 	ln_last_tutar:= -1*nvl(pn_tutar,0);
	 end if;

	 update CBS_DBT
	 set DBT_BAKIYESI=nvl(DBT_BAKIYESI,0)+nvl(ln_last_tutar,0)
	 where NUMARA=ps_numara
	 and TARIH=pd_tarih
	 and GUMRUK_KAPISI=pn_kapino;

END;
--------------------------------------------------------------------------

Procedure ITH_IHR_tanimla(ps_type varchar2,pn_mus_no number, ps_unvan varchar2,
  						  ps_tanimla_1 varchar2, ps_tanimla_2 varchar2, ps_tanimla_3 varchar2,ps_tanimla_4 varchar2) is
 cursor cur_tanim is
  select * from cbs_ith_ihr_tanim
   where  musteri_no = pn_mus_no
     and tanimlanan_1 = ps_tanimla_1
	for update;
 row_tanim cur_tanim%rowtype;

begin
  open cur_tanim;
  fetch cur_tanim into row_tanim;
  if cur_tanim%notfound then
    insert into cbs_ith_ihr_tanim (tanim_tipi, musteri_no,unvan, tanimlanan_1, tanimlanan_2, tanimlanan_3, tanimlanan_4, durum_kodu)
	                       values ( ps_type, pn_mus_no,ps_unvan, ps_tanimla_1, ps_tanimla_2, ps_tanimla_3, ps_tanimla_4,'V');
  else
    update cbs_ith_ihr_tanim
	   set tanimlanan_2 = ps_tanimla_2,
		   tanimlanan_3 = ps_tanimla_3,
		   tanimlanan_4 = ps_tanimla_4,
		   tanim_tipi = ps_type,
		   durum_kodu = 'V'
     where current of cur_tanim;
  end if;
  close cur_tanim;
end;
--------------------------------------------------------------------------
--------------------------------------------------------------------------
Function  GirilmisDBT (ps_numara varchar2,pd_tarih date,pn_kapino number) return number is
		  ln_count		 NUMBER;
BEGIN
	 --TODO 1
	 select count(*)
	 into ln_count
	 from cbs_dbt
	 where numara=ps_numara
	 and tarih=pd_tarih
	 and gumruk_kapisi=pn_kapino;

	 if ln_count>0 then
	 	return 1;--true
	 else
	 	 return 0;--false
	 end if;

exception
     when no_data_found then
	 	  return 0;
END;
--------------------------------------------------------------------------

Procedure IhracatDosyaBilgiAktar(pn_txno number,ps_refno varchar2) is
BEGIN

 	insert into cbs_ihracat_islem
	(TX_NO,REFERANS_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, IHRACATCI_MUSTERI_NO, ITHALATCI_FIRMA_UNVANI, ITHALATCI_FIRMA_ADRES1, ITHALATCI_BANKA_UNVANI, ITHALATCI_BANKA_ADRES1, DOVIZ_KODU, TUTAR, INDIRIM_TUTARI, BEDELSIZ_TESLIM, AVAL, AVAL_TUTARI, DOVIZ_GELIS_SEKLI, IHRAC_SURE_SONU, KREDI_KAYNAGI, MUHABIR_MASRAFI, ISTATISTIK_KODU, MAL_CINSI, MBANKA_MUSTERI_NO, MBANKA_HESAP_NO, MASRAF_HESAP_NO, REZERVASYON_NO, KUR, DBT_TARIH, DBT_NO, GELEN_HAVALE_REFNO, IMALATCI_UNVANI, IMALATCI_MUSTERI_NO, IHRACAT_ULKE_KODU, FIILI_IHRAC_TARIHI, DOVIZ_GELIS_SONGUN, DTH_HESAP_NO, TRL_HESAP_NO, BOLUM_KODU, ITHALATCI_FIRMA_ADRES2, ITHALATCI_FIRMA_ADRES3, ITHALATCI_FIRMA_ADRES4, ITHALATCI_BANKA_ADRES2, ITHALATCI_BANKA_ADRES3, ITHALATCI_BANKA_ADRES4,DBT_GUMRUK, YPHAVALE_ODEME_NO,DURUM_KODU,ACILIS_TARIHI,TESLIM_SEKLI)
	(select pn_txno,REFERANS_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, IHRACATCI_MUSTERI_NO, ITHALATCI_FIRMA_UNVANI, ITHALATCI_FIRMA_ADRES1, ITHALATCI_BANKA_UNVANI, ITHALATCI_BANKA_ADRES1, DOVIZ_KODU, TUTAR, INDIRIM_TUTARI, BEDELSIZ_TESLIM, AVAL, AVAL_TUTARI, DOVIZ_GELIS_SEKLI, IHRAC_SURE_SONU, KREDI_KAYNAGI, MUHABIR_MASRAFI, ISTATISTIK_KODU, MAL_CINSI, MBANKA_MUSTERI_NO, MBANKA_HESAP_NO, MASRAF_HESAP_NO, REZERVASYON_NO, KUR, DBT_TARIH, DBT_NO, GELEN_HAVALE_REFNO, IMALATCI_UNVANI, IMALATCI_MUSTERI_NO, IHRACAT_ULKE_KODU, FIILI_IHRAC_TARIHI, DOVIZ_GELIS_SONGUN, DTH_HESAP_NO, TRL_HESAP_NO, BOLUM_KODU, ITHALATCI_FIRMA_ADRES2, ITHALATCI_FIRMA_ADRES3, ITHALATCI_FIRMA_ADRES4, ITHALATCI_BANKA_ADRES2, ITHALATCI_BANKA_ADRES3, ITHALATCI_BANKA_ADRES4, DBT_GUMRUK, YPHAVALE_ODEME_NO,DURUM_KODU,ACILIS_TARIHI,TESLIM_SEKLI
	from cbs_ihracat
	where REFERANS_NO=ps_refno);

	insert into cbs_ihracat_police_islem(TX_NO,POLICE_NO, DOVIZ_KODU, POLICE_TARIHI, POLICE_TUTARI, DURUM_KODU, REFERANS_NO)
    (select pn_txno,POLICE_NO, DOVIZ_KODU, POLICE_TARIHI, POLICE_TUTARI, DURUM_KODU, REFERANS_NO
    from cbs_ihracat_police where REFERANS_NO = ps_refno);

	Pkg_Akreditif.ihracat_masraf_kopyala(pn_txno,ps_refno);

END;
-----------------------------------

Function  IhracatDosyaBakiyesi(ps_referans varchar2) return number is
		  ln_bakiye		 NUMBER;
		  ln_tutar		 NUMBER;
		  ln_odeme_tutari		 NUMBER;

BEGIN

 	 select nvl(DOSYA_BAKIYESI,0)
	 into ln_bakiye
	 from cbs_ihracat
	 where REFERANS_NO=ps_referans;

	 return ln_bakiye;

END;
-----------------------------------
Procedure GBBilgiAktar(pn_txno number, pn_numara number, pd_tarih date, pn_kapino number) is
ln_temp  number;
begin
  insert into cbs_gb_islem(tx_no, gb_no, gb_tarih, gumruk_kapisi, musteri_no, doviz_kodu,
	                       gb_tutar, teslim_sekli, fob_tutar, navlun_tutar, sigorta_tutar,
						   gb_usd_tutar, ulke_kodu, fiili_ihrac_tarihi, doviz_gelis_son_gun,
						   araci_banka_farkli, araci_banka_adi, araci_banka_adres_1, araci_banka_adres_2,
						   araci_banka_adres_3, araci_banka_adres_4, referans, sevk_no, bagli_sube,
						   durum_kodu, gb_bakiye, gb_id, terkin_tutari)
                   (select pn_txno, gb_no, gb_tarih, gumruk_kapisi, musteri_no, doviz_kodu,
	                       gb_tutar, teslim_sekli, fob_tutar, navlun_tutar, sigorta_tutar,
						   gb_usd_tutar, ulke_kodu, fiili_ihrac_tarihi, doviz_gelis_son_gun,
						   araci_banka_farkli, araci_banka_adi, araci_banka_adres_1, araci_banka_adres_2,
						   araci_banka_adres_3, araci_banka_adres_4, referans, sevk_no, bagli_sube,
						   durum_kodu, gb_bakiye, gb_id, terkin_tutari
                      from cbs_gb
					 where gb_no = pn_numara
					   and gb_tarih = pd_tarih
					   and gumruk_kapisi = pn_kapino);
end;
-----------------------------------
Function  IhracatDosyaOdemeVar(ps_referans varchar2) return boolean is
BEGIN
	 return false;
END;
-----------------------------------
Function  gb_varmi_kontrol(pn_numara number, pd_tarih date, pn_kapino number) return varchar2 is
ln_temp number;
begin
  select 1 into ln_temp
    from cbs_gb
   where gb_no = pn_numara
     and gb_tarih = pd_tarih
	 and gumruk_kapisi = pn_kapino
	 and durum_kodu = 'ACIK';
  return 'E';  --kullanilmis
  exception
    when no_data_found then
	  return 'H'; --kullanilMAmis
	when others then
	   Raise_application_error(-20100,Pkg_Hata.getUCPOINTER || '606' || Pkg_Hata.getdelimiter || to_char(SQLCODE)|| ' '|| sqlerrm  || Pkg_Hata.getUCPOINTER);
end;
-----------------------------------
Function  gb_ihracat_iliskilenmis(ps_ref varchar2,pn_vesaikno number default NULL) return varchar2 is
		  ln_temp number;
begin
	  select 1 into ln_temp
	    from cbs_gb
	   where referans = ps_ref
	     and nvl(sevk_no,0) = nvl(pn_vesaikno,0)
		 and durum_kodu = 'ACIK';

	return 'E';   --iliskilenmis

exception
    when no_data_found then
	  return 'H';  --iliskilenmemis
	when too_many_rows then
	  return 'H';  --birden fazla GB ile iliskilenmis..
	when others then
	   Raise_application_error(-20100,Pkg_Hata.getUCPOINTER || '607' || Pkg_Hata.getdelimiter || to_char(SQLCODE)|| ' '|| sqlerrm  || Pkg_Hata.getUCPOINTER);
end;
-----------------------------------
Function  gb_ihracatiliskili_gbno_al(ps_ref IN varchar2, pn_sevkno number) return number is
		 ln_gbno number;
BEGIN
		select g.gb_no
		into ln_gbno
		from cbs_gb g
		where g.referans = ps_ref
		and g.durum_kodu = 'ACIK'
		and nvl(g.sevk_no,0) = nvl(pn_sevkno,0);

		return ln_gbno;
exception
		when no_data_found then
			 return null;

END;
-----------------------------------
Function  gb_ihracatiliskili_gbtarihi_al(ps_ref IN varchar2,pn_sevkno number) return date is
		 ln_gbtarihi date;
BEGIN
		select g.gb_tarih
		into ln_gbtarihi
		from cbs_gb g
		where g.referans = ps_ref
		and g.durum_kodu = 'ACIK'
		and nvl(g.sevk_no,0) = nvl(pn_sevkno,0);

		return ln_gbtarihi;
exception
		when no_data_found then
			 return null;

END;
-----------------------------------
Function  gb_ihracatiliskili_gbgumruk_al(ps_ref IN varchar2,pn_sevkno number) return number is
	 ln_gbgumrukkapisi number;
BEGIN
		select g.gumruk_kapisi
		into ln_gbgumrukkapisi
		from cbs_gb g
		where g.referans = ps_ref
		and g.durum_kodu = 'ACIK'
		and nvl(g.sevk_no,0) = nvl(pn_sevkno,0);

		return ln_gbgumrukkapisi;
exception
		when no_data_found then
			 return null;

END;

-----------------------------------

Function  IhracatTeslimSekliAl(ps_referans varchar2,pn_vesaikno number) return varchar2 is
		 ls_teslim_sekli varchar2(3);
BEGIN

	 select teslim_sekli
	   into ls_teslim_sekli
	   from cbs_vw_ihracat
	  where referans = ps_referans
	    and nvl(vesaik_no,0) = nvl(pn_vesaikno,0);

	 return ls_teslim_sekli;
exception
		when no_data_found then
			 return null;
END;
-------------------------------------
Procedure  BakiyeGuncelle(pn_islem_no number, ps_tur varchar2,ps_ihracat_tur varchar2,ps_referans varchar2,pn_vesaikno number,pn_tutar number) is
	 ln_last_tutar				 number;
	 ln_bak						 number;
BEGIN
	 if ps_tur='A' then
	 	ln_last_tutar:=nvl(pn_tutar,0);
	 else--'B'
	 	ln_last_tutar:= -1*nvl(pn_tutar,0);
	 end if;
	 if ps_ihracat_tur = 'AKREDITIF' then
	 	select AKREDITIF_BAKIYESI
		into ln_bak
		from cbs_akreditif a
		 where a.REFERANS = ps_referans;

		if nvl(ln_bak,0)+nvl(ln_last_tutar,0) <= 0
		then
			update cbs_akreditif a
			set AKREDITIF_BAKIYESI = 0
			where a.REFERANS = ps_referans;
		else
			update cbs_akreditif a
			set AKREDITIF_BAKIYESI = nvl(AKREDITIF_BAKIYESI,0)+nvl(ln_last_tutar,0)
			where a.REFERANS = ps_referans;
		end if;
	 elsif ps_ihracat_tur = 'VESAIK' then
 	 	update cbs_akr_vesaik_sevk a
		   set VESAIK_BAKIYESI = nvl(VESAIK_BAKIYESI,0)+nvl(ln_last_tutar,0)
		 where a.REFERANS = ps_referans
		   and a.VESAIK_NO = pn_vesaikno;
	 elsif ps_ihracat_tur ='DOSYA' then
	 	update cbs_ihracat a
		   set DOSYA_BAKIYESI = nvl(DOSYA_BAKIYESI,0)+nvl(ln_last_tutar,0)
		 where a.REFERANS_NO = ps_referans;
	 elsif 	ps_ihracat_tur = 'PESIN' then
	 	update cbs_akreditif a
		   set pesin_odenen_tutar = nvl(pesin_odenen_tutar,0)+nvl(ln_last_tutar,0)
		 where a.REFERANS = ps_referans;
	 elsif 	ps_ihracat_tur = 'YUKLEME' then
	 	update cbs_akreditif a
		   set yukleme_tutari = nvl(yukleme_tutari,0)+nvl(ln_last_tutar,0)
		where a.REFERANS = ps_referans;
	 elsif ps_ihracat_tur = 'VESAIKRISK' then
 	 	update cbs_akr_vesaik_sevk a
		   set VESAIK_RISKI = nvl(VESAIK_RISKI,0)+nvl(ln_last_tutar,0)
		 where a.REFERANS = ps_referans
		   and a.VESAIK_NO = pn_vesaikno;
	 end if;

	 insert into cbs_ihracat_bakiye_log
	 (islem_no, ISLEM_ID,TUR,IHRACAT_TIPI, REFERANS, VESAIK_NO, TUTAR)
	 values
	 (pn_islem_no, Pkg_Genel.genel_kod_al('IHRACAT_BAKIYE_LOG'),ps_tur,ps_ihracat_tur,ps_referans,pn_vesaikno,pn_tutar);

END;
---------------------------------------
Procedure GBTerkinTutariGuncelle(ps_tur varchar2,pn_numara number, pd_tarih date, pn_kapino	number,pn_tutar number) is
	ln_last_tutar						number;
BEGIN
	 if ps_tur='A' then
	 	ln_last_tutar:=nvl(pn_tutar,0);
	 else--'B'
	 	ln_last_tutar:= -1*nvl(pn_tutar,0);
	 end if;

	 update cbs_gb
	    set TERKIN_TUTARI = nvl(TERKIN_TUTARI,0)+nvl(ln_last_tutar,0)
	  where gb_no = pn_numara
        and gb_tarih = pd_tarih
	    and gumruk_kapisi = pn_kapino;
END;
---------------------------------------
Procedure GBBakiyeGuncelle(ps_tur varchar2,pn_numara number, pd_tarih date, pn_kapino	number,pn_tutar number) is
	ln_last_tutar						number;
BEGIN
	 if ps_tur='A' then
	 	ln_last_tutar:=nvl(pn_tutar,0);
	 else--'B'
	 	ln_last_tutar:= -1*nvl(pn_tutar,0);
	 end if;

	 update cbs_gb
	    set GB_BAKIYE=nvl(GB_BAKIYE,0)+nvl(ln_last_tutar,0)
	  where gb_no = pn_numara
        and gb_tarih = pd_tarih
	    and gumruk_kapisi = pn_kapino;
END;
---------------------------------------
Procedure IhracatDurumKoduGuncelle(ps_tur varchar2,ps_ref varchar2,pn_vesaikno number,ps_durum_kodu varchar2) is
BEGIN
    if ps_tur='DOSYA' then
	 	update cbs_ihracat
		set DURUM_KODU=ps_durum_kodu
		where referans_no=ps_ref;
	elsif ps_tur='VESAIK' then
		update cbs_akr_vesaik_sevk
		set DURUM_KODU=ps_durum_kodu
		where referans=ps_ref
		and vesaik_no=pn_vesaikno;
	end if;
END;
---------------------------------------
procedure dbt_bilgi_al(pn_dbt_id in number, ps_dbt_no out varchar2, pd_dbt_tarih out date, pn_dbt_kapi out number) is
begin
  select numara, tarih, gumruk_kapisi
    into ps_dbt_no, pd_dbt_tarih, pn_dbt_kapi
    from cbs_dbt
   where dbtid = pn_dbt_id;
  exception
    when no_data_found then
	  ps_dbt_no := null;
	  pd_dbt_tarih := null;
	  pn_dbt_kapi := null;
	when others then
      Raise_application_error(-20100,Pkg_Hata.getUCPOINTER || '616' || Pkg_Hata.getdelimiter|| to_char(pn_dbt_id) || Pkg_Hata.getdelimiter || to_char(SQLCODE)|| ' '|| sqlerrm  || Pkg_Hata.getUCPOINTER);
end;
---------------------------------------
procedure gb_bilgi_al(pn_gb_id in number, pn_gb_no out number, pd_gb_tarih out date, pn_gb_kapi out number, pd_dvz_son out date) is
begin
  select gb_no, gb_tarih, gumruk_kapisi, doviz_gelis_son_gun
    into pn_gb_no, pd_gb_tarih, pn_gb_kapi, pd_dvz_son
    from cbs_gb
   where gb_id = pn_gb_id;
  exception
    when no_data_found then
	  pn_gb_no := null;
	  pd_gb_tarih := null;
	  pn_gb_kapi := null;
	when others then
      Raise_application_error(-20100,Pkg_Hata.getUCPOINTER || '617' || Pkg_Hata.getdelimiter|| to_char(pn_gb_id) || Pkg_Hata.getdelimiter || to_char(SQLCODE)|| ' '|| sqlerrm  || Pkg_Hata.getUCPOINTER);
end;
---------------------------------------
procedure odeme_ilk_bilgileri_al(ps_referans varchar2, pn_vesaik number,
	                                 pn_ihracatci_musteri out number,  ps_dosya_doviz out varchar2,
									 pn_bakiye out number, pn_vesaik_riski out number,
									 ps_teslim_sekli out varchar2, ps_urun_tur out varchar2,
	                                 ps_urun_sinif out varchar2, ps_teyit_kodu out varchar2,
									 pn_imalatci_musteri out number, pn_tutar out number) is
begin
  select ihracatci_musteri_no, doviz_kodu, bakiye,
         decode(nvl(pn_vesaik,0),0,null,Pkg_Akreditif.vesaik_risk_tutari_al(ps_referans, pn_vesaik)) vesaik_riski,
         teslim_sekli, urun_tur_kod, urun_sinif_kod, decode(nvl(pn_vesaik,0),0,null,
		 Pkg_Akreditif.akreditif_teyit_kodu(ps_referans)) teyit_kodu, imalatci_musteri_no, tutar
	into pn_ihracatci_musteri, ps_dosya_doviz, pn_bakiye, pn_vesaik_riski,
	     ps_teslim_sekli ,ps_urun_tur, ps_urun_sinif, ps_teyit_kodu, pn_imalatci_musteri, pn_tutar
    from cbs_vw_ihracat
   where referans = ps_referans
	 and nvl(vesaik_no,0) = nvl(pn_vesaik,0)
	 and durum_kodu not in ('I', 'K');

end;
---------------------------------------
function ihracatci_al(ps_ref varchar2, pn_vesaik_no number) return number is
ln_ihr number;
begin
  select ihracatci_musteri_no
	into ln_ihr
    from cbs_vw_ihracat
   where referans = ps_ref
	 and nvl(vesaik_no,0) = nvl(pn_vesaik_no,0);
  return ln_ihr;
  exception
    when no_data_found then
	  return null;
	when others then
      Raise_application_error(-20100,Pkg_Hata.getUCPOINTER || '621' || Pkg_Hata.getdelimiter || ps_ref || '-' || to_char(nvl(pn_vesaik_no,0) ) || Pkg_Hata.getdelimiter || to_char(SQLCODE)|| ' '|| sqlerrm  || Pkg_Hata.getUCPOINTER);

end;
---------------------------------------
function gb_id_al( pn_gb_no number, pd_gb_tarih date, pn_gb_kapi number) return number is
 ln_gbid number;
BEGIN
	select gb_id
	into ln_gbid
	from cbs_gb
	where gb_no=pn_gb_no
	and gb_tarih=pd_gb_tarih
	and gumruk_kapisi=pn_gb_kapi;

    return ln_gbid;
END;
---------------------------------------
function ihracat_bakiyesi(ps_ref varchar2, pn_vesaik_no number) return number is
ln_bakiye number;
begin
  select bakiye
    into ln_bakiye
	from cbs_vw_ihracat
   where referans = ps_ref
     and nvl(vesaik_no,0) = nvl(pn_vesaik_no,0);
   return ln_bakiye;
end;
---------------------------------------
procedure ihracat_dvz_son_gun_guncelle(ps_ref varchar2, pn_vesaik_no number, pd_date date) is
begin
  if nvl(pn_vesaik_no,0) = 0 then
    update cbs_ihracat a
	   set a.doviz_gelis_songun = pd_date
	 where a.referans_no = ps_ref;
  else
    update cbs_akr_vesaik_sevk
	   set doviz_gelis_son_gun = pd_date
	 where referans = ps_ref
	   and vesaik_no = pn_vesaik_no;
	   end if;
end;

---------------------------------------
procedure gb_iliskili_ref_guncelle(ps_tur varchar2,pn_islem_no number,pn_gb_id number, ps_ref varchar2, pn_vesaik_no number) is
begin
	 if ps_tur='EKLE' then
		 update cbs_gb
		    set referans = ps_ref,
			    sevk_no = pn_vesaik_no,
				referans_islem=pn_islem_no
		  where gb_id = pn_gb_id
		  and referans_islem is null;
	elsif ps_tur='SIL' then
		  update cbs_gb
		    set referans = NULL,
			    sevk_no = NULL,
				referans_islem=null
		  where referans_islem=pn_islem_no;
		  --and gb_id = pn_gb_id
	end if;
end;
---------------------------------------
Function  IhracatKullanilanTutar(ps_referans varchar2) return number is
		  ln_kullanilan		 					 NUMBER;
		  ln_tutar		 					 NUMBER;
		  ln_odeme_tutari		 			 NUMBER;

BEGIN

 	 select nvl(TUTAR,0)-nvl(DOSYA_BAKIYESI,0)
	 into ln_kullanilan
	 from cbs_ihracat
	 where REFERANS_NO=ps_referans;

	 return ln_kullanilan;
END;
---------------------------------------
---------------------------------------
  Function masraf_kontrol_yap(ps_odeyecek varchar2) return varchar2 is
  begin
    if ps_odeyecek in ('EXPORTER') then
	 return 'Y';
	else
	 return 'N';
	end if;
  end;
--------------------------------------
  Function masraf_kontrol_yap_nonakr(ps_odeyecek varchar2) return varchar2 is
  begin
    if ps_odeyecek in ('EXPORTER') then
	 return 'Y';
	else
	 return 'N';
	end if;
  end;
  -------------------------------------------------------------------------------
 Function DBT_Teyit_Yazi_No(pn_gb_no number, pd_gb_tarih date, pn_gb_kapi number) return number is
  ln_yazino		number;
 BEGIN
	 select TEYIT_YAZI_NO
	 into ln_yazino
	 from cbs_dbt
	 where TARIH=pd_gb_tarih
	 and  NUMARA=pn_gb_no and  GUMRUK_KAPISI=pn_gb_kapi;

	 return ln_yazino;

 END;
---------------------------------------
 Function  ihracat_ulke_kodu(ps_referans varchar2) return varchar2 is
 ls_temp varchar2(10);
 begin
  select mal_gonderilecek_ulke
    into ls_temp
	from cbs_akreditif
   where referans = ps_referans;
    return ls_temp;
   exception
    when no_data_found then
	 begin
	  select ihracat_ulke_kodu
	    into ls_temp
		from cbs_ihracat
	   where referans_no = ps_referans;
	    return ls_temp;
	   exception
        when no_data_found then
		  return null;
	  end;
 end;
---------------------------------------
 Function  ihracat_mal_cinsi(ps_referans varchar2) return varchar2 is
 ls_temp varchar2(100);
 begin
  select mal_cinsi
    into ls_temp
	from cbs_ihracat
   where referans_no = ps_referans;
   return ls_temp;
	   exception
        when no_data_found then
		   return null;
 end;
---------------------------------------
Function  ihracat_modul_al return varchar2 is
Begin
  return 'EXPORT';
end;
---------------------------------------
Function m_hesap_3200(ps_modul varchar2, ps_urun_tur varchar2) return varchar2 is
begin
   if     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      and ps_urun_tur in  ('NOSTRO-LC', 'NOSTRO-FC') then
	  return 'E';
   else
     return 'H';
   end if;
end;
---------------------------------------
Function alacak_hesap_3202(ps_modul varchar2, ps_urun_tur varchar2) return varchar2 is
begin
   if     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      and ps_urun_tur in ('CURRENT','DEMAND DEP') then
	  return 'E';
   else
     return 'H';
   end if;
end;
---------------------------------------
Function muhabir_hesap_3202(ps_modul varchar2, ps_urun_tur varchar2) return varchar2 is
begin
   if     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      and ps_urun_tur in ('NOSTRO-LC', 'NOSTRO-FC') then
	  return 'E';
   else
     return 'H';
   end if;
end;
---------------------------------------
Function dth_hesap_3202(ps_modul varchar2, ps_urun_tur varchar2) return varchar2 is
begin
   if     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      and ps_urun_tur in ('CURRENT','DEMAND DEP') then
	  return 'E';
   else
     return 'H';
   end if;
end;
---------------------------------------
FUNCTION lc_hesap_3207(ps_modul VARCHAR2, ps_urun_tur VARCHAR2) RETURN VARCHAR2 IS
BEGIN
   IF     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      AND ps_urun_tur  IN ('CURRENT','DEMAND DEP') THEN
	  RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
---------------------------------------
FUNCTION odeme_referans(ps_tip VARCHAR2, ps_urun_tur VARCHAR2) RETURN VARCHAR2 IS
BEGIN
   IF     ps_tip <> 'AKREDITIF'
      AND ps_urun_tur NOT IN ('ADVANCE') THEN
	  RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
---------------------------------------
FUNCTION dvz_kredi_hesap_3207(ps_modul VARCHAR2, ps_urun_tur VARCHAR2) RETURN VARCHAR2 IS
BEGIN
   IF     ps_modul = Pkg_Kredi.modul_tur_kod  and ps_urun_tur in('CASH')   THEN
	  RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
Function m_hesap_2062(ps_modul varchar2, ps_urun_tur varchar2) return varchar2 is
begin
   if     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      and ps_urun_tur in ('CURRENT','DEMAND DEP') then
	  return 'E';
   else
     return 'H';
   end if;
end;
Function masraf_hesap_3200(ps_modul varchar2, ps_urun_tur varchar2) return varchar2 is
begin
   if     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      and ps_urun_tur in ('CURRENT','DEMAND DEP') then
	  return 'E';
   else
     return 'H';
   end if;
end;
----------
Function acc_credit_2030(ps_modul varchar2, ps_urun_tur varchar2) return varchar2 is
begin
   if     ps_modul = Pkg_Hesap.modul_tur_vadesiz
      and ps_urun_tur in ('CURRENT') then
	  return 'E';
   else
     return 'H';
   end if;
end;
-----------------------------
---------------------------------------
---------------------------------------
---------------------------------------
END;
/

