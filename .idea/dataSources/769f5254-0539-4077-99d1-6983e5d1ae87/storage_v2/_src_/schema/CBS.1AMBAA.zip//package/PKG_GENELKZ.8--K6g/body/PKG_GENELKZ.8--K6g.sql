create PACKAGE BODY     pkg_genelkz IS


	  l_uc		  VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  	  l_ara		  VARCHAR2(3):=Pkg_Hata.getDELIMITER;
----------------------------------------------------------------------------------------------------
Function GetExternalAccountNo(ps_dkgrup_kod varchar2,
			 					ps_modul_tur_kod VARCHAR2,
								ps_urun_tur_kod VARCHAR2,
								ps_urun_sinif_kod VARCHAR2,
								ps_curr_kod VARCHAR2,
								ps_branchcd VARCHAR2) return varchar2 is

	ls_gl_account 	varchar2(8);
	ls_ex_gl 	varchar2(3);
	ls_firstcount		varchar2(5);
	ln_lastindex		number;
	ls_externalaccountno	   varchar2(9);
	ls_bankcode varchar2(9);
	ls_external varchar2(9);
	ln_sum1	   number:=0;
	ln_sum2	   number:=0;
	ln_sum3	   number:=0;

BEGIN

	 --return ls_external;

	 if instr(ps_urun_tur_kod,'NOSTRO')=0 and ps_dkgrup_kod not in ('1003','1002') then

		 Pkg_Muhasebe.DK_BUL( ps_dkgrup_kod,
		 					  ps_modul_tur_kod,
							  ps_urun_tur_kod,
							  ps_urun_sinif_kod, 1, NULL, NULL, NULL, ls_gl_account);

		select EX_GL
		into ls_ex_gl
		from cbs_exgl_map
		where GL_NO=ls_gl_account
		and CURRENCY_CODE=ps_curr_kod;

	    ls_bankcode:=pkg_genelkz.GetOurBICCode(ps_branchcd);
		ls_firstcount := lpad(to_char(pkg_genel.genel_kod_al('ACC.EXTRN.'|| ps_branchcd ||'.' || ls_ex_gl )),5,'0');
		 --ln_lastindex  := pkg_genel.genel_kod_al('HESAP.EXTRNLAST');

		ls_external:=substr(ls_firstcount,1,3) || ls_ex_gl || 'X' || substr(ls_firstcount,4,2);

		ln_sum1:=mod(7*substr(ls_bankcode,7,1),10) + mod(1*substr(ls_bankcode,8,1),10)+mod(3*substr(ls_bankcode,9,1),10);

		ln_sum2:=mod(3*substr(ls_external,1,1),10) + mod(7*substr(ls_external,2,1),10)+mod(1*substr(ls_external,3,1),10)+
			 mod(3*substr(ls_external,4,1),10) + mod(7*substr(ls_external,5,1),10)+mod(1*substr(ls_external,6,1),10)+
			 mod(7*substr(ls_external,8,1),10)+mod(1*substr(ls_external,9,1),10);

		ln_sum3:=mod(ln_sum1+ln_sum2,10)*3;

		ls_external:=replace(ls_external,'X',mod(ln_sum3,10));

	end if;

	return ls_external;

 	EXCEPTION
 		  WHEN NO_DATA_FOUND THEN
                  RAISE_APPLICATION_ERROR(-20100,l_uc || '1157' || l_ara || ps_dkgrup_kod ||'-'|| ps_modul_tur_kod ||'-'|| ps_urun_tur_kod ||'-'|| ps_urun_sinif_kod ||'-'|| ls_gl_account || l_uc);

END;
------------------------------------------------------------------------------------------------------
  Function GetOurBranchCode(ps_biccode VARCHAR2) return varchar2 is
  	   ls_branchcode				  varchar2(9);
  BEGIN
  	   select BRANCH_CODE
	   into ls_branchcode
	   from CBS_DKB_INFO
	   where BIC_CODE=ps_biccode;

	   return ls_branchcode;
  END;
-----------------------------------------------------------------------
  Function GetOurBICCode(ps_branchcd VARCHAR2) return varchar2 is
  	   ls_biccode				  varchar2(9);
  BEGIN
  	   select BIC_CODE
	   into ls_biccode
	   from CBS_DKB_INFO
	   where BRANCH_CODE=ps_branchcd;

	   return ls_biccode;
  END;
---------------------------------------------------------------------------------------------------
Function GetBadListBICCode return varchar2 is
  	   ls_biccode				  varchar2(9);
  BEGIN
      ls_biccode:='195301070';
  	  return ls_biccode;
  END;
---------------------------------------------------------------------------------------------------
Function GetBadListToAccount return varchar2 is
  	   ls_acc				  varchar2(9);
  BEGIN
      ls_acc:='000080900';
  	  return ls_acc;
  END;
-----------------------------------------------------------------------------
Function GetBadListTaxType(ps_ref varchar2) return varchar2 is
  	  ls_income				  varchar2(6);
  BEGIN

	select TAX_TYPE_CODE
	into ls_income
	from cbs_bad_list
	where reference=ps_ref;

  	  return ls_income;
  END;
--------------------------------------------------------------------------------
Function GetCurrencyCodeFromISO(ps_isocode in varchar2) return varchar2 is
	ls_currcode					varchar2(3);
BEGIN

	 select DOVIZ_KODU
	 into ls_currcode
	 from cbs_doviz_kodlari
	 where ISO_CODE=ps_isocode;

	 return ls_currcode	;
END;
--------------------------------------------------------------------------------------
Function GetGLExternalRNN(ps_extaccno varchar2) return varchar2 is
		 ls_rnnno					  varchar2(12);
BEGIN
	  select RNN_NO
	 into ls_rnnno
	 from CBS_CLEARING_GL_EXT_MAP
	 where EXTERNAL_ACCOUNT_NO=ps_extaccno;

	 return ls_rnnno	;
END;
-------------------------------------------------------------------------------------------
Function GetGLExternal(ps_extaccno varchar2) return varchar2 is
		 ls_glno					  varchar2(8);
BEGIN
	  select GL_NO
	 into ls_glno
	 from CBS_CLEARING_GL_EXT_MAP
	 where EXTERNAL_ACCOUNT_NO=ps_extaccno;

	 return ls_glno	;
END;
-------------------------------------------------------------------------------------------
Function GetGLExternalFromName(ps_extaccno varchar2) return varchar2 is
		 ls_fromname					  varchar2(70);
BEGIN
	  select FROM_NAME
	 into ls_fromname
	 from CBS_CLEARING_GL_EXT_MAP
	 where EXTERNAL_ACCOUNT_NO=ps_extaccno;

	 return ls_fromname	;
END;
-----------------------------------------------------------------------------------------------------
  Function GetDKBMainBKName(ps_branchcd varchar2) return varchar2 is
		 ls_fromname					  varchar2(70);
BEGIN
	  select HEAD_NAME
	 into ls_fromname
	 from CBS_DKB_INFO
	 where BRANCH_CODE=ps_branchcd;

	 return ls_fromname	;
END;
-----------------------------------------------------------------------------------------------------
  Function GetDKBChiefName(ps_branchcd varchar2) return varchar2 is
		 ls_fromname					  varchar2(70);
BEGIN
	  select CHIEF_NAME
	 into ls_fromname
	 from CBS_DKB_INFO
	 where BRANCH_CODE=ps_branchcd;

	 return ls_fromname	;
END;

--------------------------------------------------------------------------------------------------
Function GetCustomermanagerName(pn_customerno varchar2) return varchar2 is
  		 ls_fromname					  varchar2(70);
BEGIN
	 select rtrim(ltrim(MANAGER_NAME || MANAGER_SURNAME || MANAGER_PATRONYMIC_NAME))
	 into ls_fromname
	 from CBS_MUSTERI
	 where MUSTERI_NO=pn_customerno;

	 return ls_fromname	;
END;
--------------------------------------------------------------------------------------------------
  Function GetGLExternalIRS(ps_extaccno varchar2) return varchar2 is
	ls_irs					  varchar2(1);
  BEGIN
	  select SOR_CODE
	 into ls_irs
	 from CBS_CLEARING_GL_EXT_MAP
	 where EXTERNAL_ACCOUNT_NO=ps_extaccno;

	 return ls_irs	;
  END;
  --------------------------------------------------------------------------------
  Function GetGLExternalSECO(ps_extaccno varchar2) return varchar2 is
  		   ls_seco				  varchar2(1);
  BEGIN
	  select SECO_CODE
	 into ls_seco
	 from CBS_CLEARING_GL_EXT_MAP
	 where EXTERNAL_ACCOUNT_NO=ps_extaccno;

	 return ls_seco;
  END;
---------------------------------------------------------------------------------------------------
Function GetKayitKullaniciBolumKodu(pn_islemno number) return varchar2 is
		 ls_kod varchar2(20);
BEGIN
	 select kayit_kullanici_bolum_kodu
	 into ls_kod
	 from cbs_islem
	 where numara=pn_islemno;

	 return ls_kod;
END;
----------------------------------------------------------------------------------------------------
END;
/

