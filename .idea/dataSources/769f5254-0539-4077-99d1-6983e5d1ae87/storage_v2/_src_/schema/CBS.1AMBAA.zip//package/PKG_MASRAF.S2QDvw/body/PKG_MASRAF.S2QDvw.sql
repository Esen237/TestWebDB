create PACKAGE BODY     "PKG_MASRAF"
IS
   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION bsmv_hesapla (pn_tutar NUMBER)
      RETURN NUMBER
   IS
   BEGIN
      RETURN (pn_tutar * 0 / 100);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION masraf_yaratilmali (
      pn_islem_kodu       IN NUMBER,
      pc_modul_tur_kod       cbs_islem.modul_tur_kod%TYPE,
      pc_urun_tur_kod        cbs_islem.urun_tur_kod%TYPE,
      pc_urun_sinif_kod      cbs_islem.urun_sinif_kod%TYPE)
      RETURN BOOLEAN
   IS
      ln_ret     BOOLEAN;
      ln_dummy   NUMBER;

      CURSOR c_masraf_var_3
      IS
         SELECT 1
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kodu
                AND modul_tur_kod = pc_modul_tur_kod
                AND urun_tur_kod = pc_urun_tur_kod
                AND urun_sinif_kod = pc_urun_sinif_kod
                AND pkg_muhasebe.banka_tarihi_bul BETWEEN NVL (
                                                             start_date,
                                                             pkg_muhasebe.banka_tarihi_bul)
                                                      AND NVL (
                                                             end_date,
                                                             pkg_muhasebe.banka_tarihi_bul);

      CURSOR c_masraf_var_2
      IS
         SELECT 1
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kodu
                AND modul_tur_kod = pc_modul_tur_kod
                AND urun_tur_kod = pc_urun_tur_kod
                AND urun_sinif_kod IS NULL
                AND pkg_muhasebe.banka_tarihi_bul BETWEEN NVL (
                                                             start_date,
                                                             pkg_muhasebe.banka_tarihi_bul)
                                                      AND NVL (
                                                             end_date,
                                                             pkg_muhasebe.banka_tarihi_bul);

      CURSOR c_masraf_var_1
      IS
         SELECT 1
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kodu
                AND modul_tur_kod = pc_modul_tur_kod
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND pkg_muhasebe.banka_tarihi_bul BETWEEN NVL (
                                                             start_date,
                                                             pkg_muhasebe.banka_tarihi_bul)
                                                      AND NVL (
                                                             end_date,
                                                             pkg_muhasebe.banka_tarihi_bul);

      CURSOR c_masraf_var_0
      IS
         SELECT 1
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kodu
                AND modul_tur_kod IS NULL
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND pkg_muhasebe.banka_tarihi_bul BETWEEN NVL (
                                                             start_date,
                                                             pkg_muhasebe.banka_tarihi_bul)
                                                      AND NVL (
                                                             end_date,
                                                             pkg_muhasebe.banka_tarihi_bul);
   BEGIN
      ln_ret := FALSE;

      OPEN c_masraf_var_3;

      FETCH c_masraf_var_3 INTO ln_dummy;

      IF c_masraf_var_3%FOUND
      THEN
         CLOSE c_masraf_var_3;

         ln_ret := TRUE;
         RETURN (ln_ret);
      END IF;

      CLOSE c_masraf_var_3;

      OPEN c_masraf_var_2;

      FETCH c_masraf_var_2 INTO ln_dummy;

      IF c_masraf_var_2%FOUND
      THEN
         CLOSE c_masraf_var_2;

         ln_ret := TRUE;
         RETURN (ln_ret);
      END IF;

      CLOSE c_masraf_var_2;

      OPEN c_masraf_var_1;

      FETCH c_masraf_var_1 INTO ln_dummy;

      IF c_masraf_var_1%FOUND
      THEN
         CLOSE c_masraf_var_1;

         ln_ret := TRUE;
         RETURN (ln_ret);
      END IF;

      CLOSE c_masraf_var_1;

      OPEN c_masraf_var_0;

      FETCH c_masraf_var_0 INTO ln_dummy;

      IF c_masraf_var_0%FOUND
      THEN
         CLOSE c_masraf_var_0;

         ln_ret := TRUE;
         RETURN (ln_ret);
      END IF;

      CLOSE c_masraf_var_0;

      RETURN (ln_ret);
   END;

   /*--------------------------------------------------------------------------------------------------- */
   --BOM CQ4879 MederT 02112015
   FUNCTION masraf_fix_var (ps_masraf_kod   IN     cbs_masraf_tur.kodu%TYPE,
                            pn_islem_kodu   IN     NUMBER,
                            pn_musteri_no   IN     NUMBER,
                            ps_modul        IN     VARCHAR2 DEFAULT NULL,
                            ps_urun_tur     IN     VARCHAR2 DEFAULT NULL,
                            ps_urun_sinif   IN     VARCHAR2 DEFAULT NULL,
                            pn_tutar        IN OUT NUMBER,
                            ps_dvz          IN OUT VARCHAR2,
                            pn_min_tutar       OUT NUMBER,
                            pn_max_tutar       OUT NUMBER)
      RETURN NUMBER
   IS
      -- if muaf var then returns 1
      -- else returns 0
      ln_temp         NUMBER;
      ls_dvz          VARCHAR2 (3);
      lb_fix_var      BOOLEAN;
      ls_oran_sabit   VARCHAR2 (1);

      CURSOR c_fix_0
      IS
         SELECT tutar,
                doviz,
                oran_sabit,
                NVL (min_tutar, 0),
                NVL (max_tutar, 0)
           FROM cbs_musteri_islem_masraf_fix
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod IS NULL
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND pn_tutar >= NVL (range_start, pn_tutar)
                AND pn_tutar <= NVL (range_end, pn_tutar)
                AND ps_dvz = NVL (doviz, ps_dvz);

      CURSOR c_fix_1
      IS
         SELECT tutar,
                doviz,
                oran_sabit,
                NVL (min_tutar, 0),
                NVL (max_tutar, 0)
           FROM cbs_musteri_islem_masraf_fix
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND pn_tutar >= NVL (range_start, pn_tutar)
                AND pn_tutar <= NVL (range_end, pn_tutar)
                AND ps_dvz = NVL (doviz, ps_dvz);

      CURSOR c_fix_2
      IS
         SELECT tutar,
                doviz,
                oran_sabit,
                NVL (min_tutar, 0),
                NVL (max_tutar, 0)
           FROM cbs_musteri_islem_masraf_fix
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod IS NULL
                AND pn_tutar >= NVL (range_start, pn_tutar)
                AND pn_tutar <= NVL (range_end, pn_tutar)
                AND ps_dvz = NVL (doviz, ps_dvz);

      CURSOR c_fix_3
      IS
         SELECT tutar,
                doviz,
                oran_sabit,
                NVL (min_tutar, 0),
                NVL (max_tutar, 0)
           FROM cbs_musteri_islem_masraf_fix
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod = ps_urun_sinif
                AND pn_tutar >= NVL (range_start, pn_tutar)
                AND pn_tutar <= NVL (range_end, pn_tutar)
                AND ps_dvz = NVL (doviz, ps_dvz);

      CURSOR c_m_tur
      IS
         SELECT sabit_oran
           FROM cbs_masraf_tur
          WHERE kodu = ps_masraf_kod;
   BEGIN
      OPEN c_fix_3;

      FETCH c_fix_3
         INTO ln_temp,
              ls_dvz,
              ls_oran_sabit,
              pn_min_tutar,
              pn_max_tutar;

      IF c_fix_3%NOTFOUND
      THEN
         CLOSE c_fix_3;

         OPEN c_fix_2;

         FETCH c_fix_2
            INTO ln_temp,
                 ls_dvz,
                 ls_oran_sabit,
                 pn_min_tutar,
                 pn_max_tutar;

         IF c_fix_2%NOTFOUND
         THEN
            CLOSE c_fix_2;

            OPEN c_fix_1;

            FETCH c_fix_1
               INTO ln_temp,
                    ls_dvz,
                    ls_oran_sabit,
                    pn_min_tutar,
                    pn_max_tutar;

            IF c_fix_1%NOTFOUND
            THEN
               CLOSE c_fix_1;

               OPEN c_fix_0;

               FETCH c_fix_0
                  INTO ln_temp,
                       ls_dvz,
                       ls_oran_sabit,
                       pn_min_tutar,
                       pn_max_tutar;

               IF c_fix_0%NOTFOUND
               THEN
                  CLOSE c_fix_0;

                  lb_fix_var := FALSE;
               ELSE
                  CLOSE c_fix_0;

                  lb_fix_var := TRUE;
               END IF;
            ELSE
               CLOSE c_fix_1;

               lb_fix_var := TRUE;
            END IF;
         ELSE
            CLOSE c_fix_2;

            lb_fix_var := TRUE;
         END IF;
      ELSE
         CLOSE c_fix_3;

         lb_fix_var := TRUE;
      END IF;

      IF lb_fix_var
      THEN
         pn_tutar := ln_temp;
         ps_dvz := ls_dvz;

         IF ls_oran_sabit = 'O'
         THEN
            RETURN 2;
         ELSE
            RETURN 1;
         END IF;
      ELSE
         RETURN 0;
      END IF;
   END;

   --EOM CQ4879 MederT 02112015
   /*--------------------------------------------------------------------------------------------------- */
   FUNCTION masraf_muaf_var (ps_masraf_kod   IN cbs_masraf_tur.kodu%TYPE,
                             pn_islem_kodu   IN NUMBER,
                             pn_musteri_no   IN NUMBER,
                             ps_modul        IN VARCHAR2 DEFAULT NULL,
                             ps_urun_tur     IN VARCHAR2 DEFAULT NULL,
                             ps_urun_sinif   IN VARCHAR2 DEFAULT NULL)
      RETURN NUMBER
   IS
      -- if muaf var then returns 1
      -- else returns 0
      ln_temp       NUMBER;
      lb_muaf_var   BOOLEAN;

      CURSOR c_muaf_0
      IS
         SELECT 1
           FROM cbs_musteri_islem_masraf_muaf
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod IS NULL
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL;

      CURSOR c_muaf_1
      IS
         SELECT 1
           FROM cbs_musteri_islem_masraf_muaf
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL;

      CURSOR c_muaf_2
      IS
         SELECT 1
           FROM cbs_musteri_islem_masraf_muaf
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod IS NULL;

      CURSOR c_muaf_3
      IS
         SELECT 1
           FROM cbs_musteri_islem_masraf_muaf
          WHERE     musteri_no = pn_musteri_no
                AND islem_kodu = pn_islem_kodu
                AND masraf_kodu = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod = ps_urun_sinif;
   BEGIN
      OPEN c_muaf_3;

      FETCH c_muaf_3 INTO ln_temp;

      IF c_muaf_3%NOTFOUND
      THEN
         CLOSE c_muaf_3;

         OPEN c_muaf_2;

         FETCH c_muaf_2 INTO ln_temp;

         IF c_muaf_2%NOTFOUND
         THEN
            CLOSE c_muaf_2;

            OPEN c_muaf_1;

            FETCH c_muaf_1 INTO ln_temp;

            IF c_muaf_1%NOTFOUND
            THEN
               CLOSE c_muaf_1;

               OPEN c_muaf_0;

               FETCH c_muaf_0 INTO ln_temp;

               IF c_muaf_0%NOTFOUND
               THEN
                  CLOSE c_muaf_0;

                  lb_muaf_var := FALSE;
               ELSE
                  CLOSE c_muaf_0;

                  lb_muaf_var := TRUE;
               END IF;
            ELSE
               CLOSE c_muaf_1;

               lb_muaf_var := TRUE;
            END IF;
         ELSE
            CLOSE c_muaf_2;

            lb_muaf_var := TRUE;
         END IF;
      ELSE
         CLOSE c_muaf_3;

         lb_muaf_var := TRUE;
      END IF;

      IF lb_muaf_var
      THEN
         RETURN 1;
      ELSE
         RETURN 0;
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_tutarlari_al (ps_masraf_kod           VARCHAR2,
                                  pn_islem_kodu           NUMBER,
                                  ps_modul                VARCHAR2,
                                  ps_urun_tur             VARCHAR2,
                                  ps_urun_sinif           VARCHAR2,
                                  pn_min_yuzde        OUT NUMBER,
                                  pn_max_yuzde        OUT NUMBER,
                                  pn_min_tutar        OUT NUMBER,
                                  pn_max_tutar        OUT NUMBER,
                                  pn_tutar            OUT NUMBER,
                                  ps_bsmv_al          OUT VARCHAR2,
                                  ps_sabit_oran       OUT VARCHAR2,
                                  pn_yuzde            OUT NUMBER,
                                  ps_dvz              OUT VARCHAR2,
                                  ps_tum_doviz        OUT VARCHAR2,
                                  ps_kom_kur_kullan   OUT VARCHAR2)
   IS
      CURSOR c_0
      IS
         SELECT min_yuzde,
                max_yuzde,
                min_tutar,
                max_tutar,
                tutar,
                bsmv_alinir,
                sabit_oran,
                yuzde,
                dvz,
                tum_dovizler,
                kom_kur_kullan
           FROM cbs_masraf_tur
          WHERE     pkg_muhasebe.banka_tarihi_bul BETWEEN NVL (
                                                             start_date,
                                                             pkg_muhasebe.banka_tarihi_bul)
                                                      AND NVL (
                                                             end_date,
                                                             pkg_muhasebe.banka_tarihi_bul)
                AND kodu = ps_masraf_kod;

      r_0   c_0%ROWTYPE;

      CURSOR c_1
      IS
         SELECT NVL (min_yuzde, r_0.min_yuzde),
                NVL (max_yuzde, r_0.max_yuzde),
                NVL (min_tutar, r_0.min_tutar),
                NVL (max_tutar, r_0.max_tutar),
                NVL (tutar, r_0.tutar),
                NVL (bsmv_alinir, r_0.bsmv_alinir),
                NVL (sabit_oran, r_0.sabit_oran),
                NVL (yuzde, r_0.yuzde),
                NVL (dvz, r_0.dvz),
                NVL (tum_dovizler, r_0.tum_dovizler)
           FROM cbs_islem_masraf_tanim
          WHERE     islem_kod = pn_islem_kodu
                AND masraf_kod = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL;

      CURSOR c_2
      IS
         SELECT NVL (min_yuzde, r_0.min_yuzde),
                NVL (max_yuzde, r_0.max_yuzde),
                NVL (min_tutar, r_0.min_tutar),
                NVL (max_tutar, r_0.max_tutar),
                NVL (tutar, r_0.tutar),
                NVL (bsmv_alinir, r_0.bsmv_alinir),
                NVL (sabit_oran, r_0.sabit_oran),
                NVL (yuzde, r_0.yuzde),
                NVL (dvz, r_0.dvz),
                NVL (tum_dovizler, r_0.tum_dovizler)
           FROM cbs_islem_masraf_tanim
          WHERE     islem_kod = pn_islem_kodu
                AND masraf_kod = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod IS NULL;

      CURSOR c_3
      IS
         SELECT NVL (min_yuzde, r_0.min_yuzde),
                NVL (max_yuzde, r_0.max_yuzde),
                NVL (min_tutar, r_0.min_tutar),
                NVL (max_tutar, r_0.max_tutar),
                NVL (tutar, r_0.tutar),
                NVL (bsmv_alinir, r_0.bsmv_alinir),
                NVL (sabit_oran, r_0.sabit_oran),
                NVL (yuzde, r_0.yuzde),
                NVL (dvz, r_0.dvz),
                NVL (tum_dovizler, r_0.tum_dovizler)
           FROM cbs_islem_masraf_tanim
          WHERE     islem_kod = pn_islem_kodu
                AND masraf_kod = ps_masraf_kod
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod = ps_urun_sinif;
   /*       exception
            when others then
               raise_application_error(-20100,pkg_hata.getucpointer||'202'|| pkg_hata.getdelimiter ||sqlerrm||pkg_hata.getucpointer);
   */
   BEGIN
      OPEN c_0;

      FETCH c_0 INTO r_0;

      CLOSE c_0;

      ps_kom_kur_kullan := r_0.kom_kur_kullan;

      OPEN c_3;

      FETCH c_3
         INTO pn_min_yuzde,
              pn_max_yuzde,
              pn_min_tutar,
              pn_max_tutar,
              pn_tutar,
              ps_bsmv_al,
              ps_sabit_oran,
              pn_yuzde,
              ps_dvz,
              ps_tum_doviz;

      IF c_3%NOTFOUND OR (ps_sabit_oran IS NULL)
      THEN
         CLOSE c_3;

         OPEN c_2;

         FETCH c_2
            INTO pn_min_yuzde,
                 pn_max_yuzde,
                 pn_min_tutar,
                 pn_max_tutar,
                 pn_tutar,
                 ps_bsmv_al,
                 ps_sabit_oran,
                 pn_yuzde,
                 ps_dvz,
                 ps_tum_doviz;

         IF c_2%NOTFOUND OR (ps_sabit_oran IS NULL)
         THEN
            CLOSE c_2;

            OPEN c_1;

            FETCH c_1
               INTO pn_min_yuzde,
                    pn_max_yuzde,
                    pn_min_tutar,
                    pn_max_tutar,
                    pn_tutar,
                    ps_bsmv_al,
                    ps_sabit_oran,
                    pn_yuzde,
                    ps_dvz,
                    ps_tum_doviz;

            IF c_1%NOTFOUND OR (ps_sabit_oran IS NULL)
            THEN
               CLOSE c_1;

               OPEN c_0;

               FETCH c_0
                  INTO pn_min_yuzde,
                       pn_max_yuzde,
                       pn_min_tutar,
                       pn_max_tutar,
                       pn_tutar,
                       ps_bsmv_al,
                       ps_sabit_oran,
                       pn_yuzde,
                       ps_dvz,
                       ps_tum_doviz,
                       ps_kom_kur_kullan;

               CLOSE c_0;
            ELSE
               CLOSE c_1;
            END IF;
         ELSE
            CLOSE c_2;
         END IF;
      ELSE
         CLOSE c_3;
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_aralik_tutar_al (ps_masraf_kod              VARCHAR2,
                                     pn_islem_kodu              NUMBER,
                                     ps_modul                   VARCHAR2,
                                     ps_urun_tur                VARCHAR2,
                                     ps_urun_sinif              VARCHAR2,
                                     pn_tutar                   NUMBER,
                                     ps_dvz                     VARCHAR2 /*masraf_tanim doviz*/
                                                                        ,
                                     ps_msrf_dvz                VARCHAR2 /*istenen cinsteki doviz */
                                                                        ,
                                     ps_doviz                   VARCHAR2 /*islem dovizi */
                                                                        ,
                                     pn_min_tutar        IN OUT NUMBER,
                                     pn_max_tutar        IN OUT NUMBER,
                                     pn_tutar_o          IN OUT NUMBER,
                                     ps_kom_kur_kullan   IN     VARCHAR2)
   IS
      CURSOR c_0
      IS
         SELECT pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_masraf_tur_aralik
          WHERE     kodu = ps_masraf_kod
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           tutar_yuzde,
                                                           NULL,
                                                           NULL)
           FROM cbs_masraf_tur_aralik
          WHERE     kodu = ps_masraf_kod
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND ps_kom_kur_kullan = 'E';

      CURSOR c_1
      IS
         SELECT pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           tutar_yuzde,
                                                           NULL,
                                                           NULL)
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'E';

      CURSOR c_2
      IS
         SELECT pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           tutar_yuzde,
                                                           NULL,
                                                           NULL)
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'E';

      CURSOR c_3
      IS
         SELECT pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              tutar_yuzde,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod = ps_urun_sinif
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_yuzde,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           tutar_yuzde,
                                                           NULL,
                                                           NULL)
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod = ps_urun_sinif
                AND ps_kom_kur_kullan = 'E';

      ln_min_tutar   NUMBER;
      ln_max_tutar   NUMBER;
      ln_tutar       NUMBER;
   BEGIN
      OPEN c_3;

      FETCH c_3 INTO ln_min_tutar, ln_max_tutar, ln_tutar;

      IF c_3%NOTFOUND
      THEN
         CLOSE c_3;

         OPEN c_2;

         FETCH c_2 INTO ln_min_tutar, ln_max_tutar, ln_tutar;

         IF c_2%NOTFOUND
         THEN
            CLOSE c_2;

            OPEN c_1;

            FETCH c_1 INTO ln_min_tutar, ln_max_tutar, ln_tutar;

            IF c_1%NOTFOUND
            THEN
               CLOSE c_1;

               OPEN c_0;

               FETCH c_0 INTO ln_min_tutar, ln_max_tutar, ln_tutar;

               IF c_0%NOTFOUND
               THEN
                  CLOSE c_0;
               ELSE
                  CLOSE c_0;

                  pn_min_tutar := ln_min_tutar;
                  pn_max_tutar := ln_max_tutar;
                  pn_tutar_o := ln_tutar;
               END IF;
            ELSE
               CLOSE c_1;

               pn_min_tutar := ln_min_tutar;
               pn_max_tutar := ln_max_tutar;
               pn_tutar_o := ln_tutar;
            END IF;
         ELSE
            CLOSE c_2;

            pn_min_tutar := ln_min_tutar;
            pn_max_tutar := ln_max_tutar;
            pn_tutar_o := ln_tutar;
         END IF;
      ELSE
         CLOSE c_3;

         pn_min_tutar := ln_min_tutar;
         pn_max_tutar := ln_max_tutar;
         pn_tutar_o := ln_tutar;
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_aralik_yuzde_tutar_al (
      ps_masraf_kod              VARCHAR2,
      pn_islem_kodu              NUMBER,
      ps_modul                   VARCHAR2,
      ps_urun_tur                VARCHAR2,
      ps_urun_sinif              VARCHAR2,
      pn_tutar                   NUMBER,
      ps_dvz                     VARCHAR2               /*masraf_tanim doviz*/
                                         ,
      ps_msrf_dvz                VARCHAR2          /*istenen cinsteki doviz */
                                         ,
      ps_doviz                   VARCHAR2                    /*islem dovizi */
                                         ,
      pn_min_yuzde        IN OUT NUMBER,
      pn_max_yuzde        IN OUT NUMBER,
      pn_yuzde            IN OUT NUMBER,
      pn_min_tutar        IN OUT NUMBER,
      pn_max_tutar        IN OUT NUMBER,
      ps_kom_kur_kullan   IN     VARCHAR2)
   IS
      CURSOR c_0
      IS
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_masraf_tur_aralik a
          WHERE     kodu = ps_masraf_kod
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_aralik,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_aralik,
                                                           NULL,
                                                           NULL)
           FROM cbs_masraf_tur_aralik a
          WHERE     kodu = ps_masraf_kod
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        NULL,
                                        NULL)
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        NULL,
                                        NULL)
                AND ps_kom_kur_kullan = 'E';

      CURSOR c_1
      IS
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_aralik,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_aralik,
                                                           NULL,
                                                           NULL)
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'E';

      CURSOR c_2
      IS
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_aralik,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_aralik,
                                                           NULL,
                                                           NULL)
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod IS NULL
                AND ps_kom_kur_kullan = 'E';

      CURSOR c_3
      IS
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              min_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A'),
                pkg_kur.doviz_doviz_karsilik (ps_dvz,
                                              ps_msrf_dvz,
                                              NULL,
                                              max_tutar_aralik,
                                              1,
                                              NULL,
                                              NULL,
                                              'N',
                                              'A')
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod = ps_urun_sinif
                AND ps_kom_kur_kullan = 'H'
         UNION ALL
         SELECT min_tutar_yuzde,
                max_tutar_yuzde,
                tutar_yuzde,
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           min_tutar_aralik,
                                                           NULL,
                                                           NULL),
                pkg_komisyon_kur.kom_doviz_doviz_karsilik (ps_dvz,
                                                           ps_msrf_dvz,
                                                           NULL,
                                                           max_tutar_aralik,
                                                           NULL,
                                                           NULL)
           FROM cbs_islem_masraf_aralik
          WHERE     masraf_kodu = ps_masraf_kod
                AND islem_kodu = pn_islem_kodu
                AND pn_tutar BETWEEN pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_baslangic,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                                 AND pkg_kur.doviz_doviz_karsilik (
                                        ps_dvz,
                                        ps_doviz,
                                        NULL,
                                        aralik_bitis,
                                        1,
                                        NULL,
                                        NULL,
                                        'N',
                                        'A')
                AND modul_tur_kod = ps_modul
                AND urun_tur_kod = ps_urun_tur
                AND urun_sinif_kod = ps_urun_sinif
                AND ps_kom_kur_kullan = 'E';

      ln_min_yuzde   NUMBER;
      ln_max_yuzde   NUMBER;
      ln_yuzde       NUMBER;
      ln_min_tutar   NUMBER;
      ln_max_tutar   NUMBER;
   --      into ln_min_yuzde, ln_max_yuzde, ln_yuzde, ln_min_tutar, ln_max_tutar
   BEGIN
      OPEN c_3;

      FETCH c_3
         INTO ln_min_yuzde,
              ln_max_yuzde,
              ln_yuzde,
              ln_min_tutar,
              ln_max_tutar;

      IF c_3%NOTFOUND
      THEN
         CLOSE c_3;

         OPEN c_2;

         FETCH c_2
            INTO ln_min_yuzde,
                 ln_max_yuzde,
                 ln_yuzde,
                 ln_min_tutar,
                 ln_max_tutar;

         IF c_2%NOTFOUND
         THEN
            CLOSE c_2;

            OPEN c_1;

            FETCH c_1
               INTO ln_min_yuzde,
                    ln_max_yuzde,
                    ln_yuzde,
                    ln_min_tutar,
                    ln_max_tutar;

            IF c_1%NOTFOUND
            THEN
               CLOSE c_1;

               OPEN c_0;

               FETCH c_0
                  INTO ln_min_yuzde,
                       ln_max_yuzde,
                       ln_yuzde,
                       ln_min_tutar,
                       ln_max_tutar;

               IF c_0%NOTFOUND
               THEN
                  CLOSE c_0;
               ELSE
                  CLOSE c_0;

                  pn_min_yuzde := ln_min_yuzde;
                  pn_max_yuzde := ln_max_yuzde;
                  pn_yuzde := ln_yuzde;
                  pn_min_tutar := ln_min_tutar;
                  pn_max_tutar := ln_max_tutar;
               END IF;
            ELSE
               CLOSE c_1;

               pn_min_yuzde := ln_min_yuzde;
               pn_max_yuzde := ln_max_yuzde;
               pn_yuzde := ln_yuzde;
               pn_min_tutar := ln_min_tutar;
               pn_max_tutar := ln_max_tutar;
            END IF;
         ELSE
            CLOSE c_2;

            pn_min_yuzde := ln_min_yuzde;
            pn_max_yuzde := ln_max_yuzde;
            pn_yuzde := ln_yuzde;
            pn_min_tutar := ln_min_tutar;
            pn_max_tutar := ln_max_tutar;
         END IF;
      ELSE
         CLOSE c_3;

         pn_min_yuzde := ln_min_yuzde;
         pn_max_yuzde := ln_max_yuzde;
         pn_yuzde := ln_yuzde;
         pn_min_tutar := ln_min_tutar;
         pn_max_tutar := ln_max_tutar;
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_hesapla (ps_masraf_kod     IN     cbs_masraf_tur.kodu%TYPE,
                             pn_tutar          IN     NUMBER,
                             pn_islem_kodu     IN     NUMBER,
                             pn_rol            IN     NUMBER,
                             pn_musteri_no     IN     NUMBER,
                             ps_doviz          IN     VARCHAR2,
                             pn_masraf            OUT NUMBER,
                             pn_bsmv              OUT NUMBER,
                             ps_msrf_dvz       IN     VARCHAR2 DEFAULT NULL,
                             ps_modul          IN     VARCHAR2 DEFAULT NULL,
                             ps_urun_tur       IN     VARCHAR2 DEFAULT NULL,
                             ps_urun_sinif     IN     VARCHAR2 DEFAULT NULL,
                             pc_bolum_kodu     IN     VARCHAR2 DEFAULT NULL,
                             pc_hesap_numara   IN     NUMBER DEFAULT NULL)
   IS       --sevalb 160407 bolum kodu terminal icin kullanilmak uzere eklendi
      ln_min_yuzde            cbs_masraf_tur.min_yuzde%TYPE;
      ln_max_yuzde            cbs_masraf_tur.max_yuzde%TYPE;
      ln_min_tutar            cbs_masraf_tur.min_tutar%TYPE;
      ln_max_tutar            cbs_masraf_tur.max_tutar%TYPE; --fix CQ4879 MederT 02112015
      ln_tutar                cbs_masraf_tur.tutar%TYPE;
      lc_bsmv_al              cbs_masraf_tur.bsmv_alinir%TYPE;
      ls_sabit_oran           cbs_masraf_tur.sabit_oran%TYPE;
      ln_oranli               NUMBER;
      ln_yuzde                NUMBER;
      ln_temp                 NUMBER;
      ln_rol_artma_marj       NUMBER;
      ln_rol_azaltma_marj     NUMBER;
      ln_rol_min_tutar        NUMBER;
      ln_rol_max_tutar        NUMBER;
      lb_check_rol            BOOLEAN;
      ls_dvz                  VARCHAR2 (3);
      ls_tum_doviz            VARCHAR2 (1);
      ls_msrf_dvz             VARCHAR2 (3);
      ln_fix                  NUMBER;
      ls_dvz_temp             VARCHAR2 (3);
      ls_kom_kur_kullan       VARCHAR2 (1);
      lb_kom_kur_kullan       VARCHAR2 (1);

      --BOM CQ4879 MederT 02112015
      ln_fix_min_tutar        cbs_musteri_islem_masraf_fix.min_tutar%TYPE;
      ln_fix_max_tutar        cbs_musteri_islem_masraf_fix.max_tutar%TYPE;
      --EOM CQ4879 MederT 02112015

      ls_musteri_tipi         VARCHAR2 (100);
      ln_atm_msrf_adet        NUMBER;
      ls_atm_msrf_dvz         VARCHAR2 (3);
      ls_personelden_alinir   VARCHAR2 (1);

      CURSOR cur_musteri_personel_mi
      IS
         SELECT 1
           FROM cbs_musteri
          WHERE musteri_no = pn_musteri_no AND personel_sicil_no IS NOT NULL;

      CURSOR cur_atm_masraf_kriter
      IS
         SELECT charge_amount, charge_currency
           FROM cbs_masraf_kriterleri
          WHERE     charge_code = ps_masraf_kod
                AND terminal_branch_code = pc_bolum_kodu
                AND DECODE (pkg_hesap.hesaptandovizkodual (pc_hesap_numara),
                            pkg_genel.lc_al, pkg_genel.lc_al,
                            'USD') = charge_currency;

      CURSOR cur_masraf_personel
      IS
         SELECT personelden_alinir
           FROM cbs_masraf_tur
          WHERE kodu = ps_masraf_kod;
   BEGIN
      OPEN cur_musteri_personel_mi;

      FETCH cur_musteri_personel_mi INTO ln_temp;

      IF cur_musteri_personel_mi%NOTFOUND
      THEN
         CLOSE cur_musteri_personel_mi;
      ELSE
         CLOSE cur_musteri_personel_mi;
       
         --B-O-M sevalb 090507 personel masraf flag degisiklikleri
         OPEN cur_masraf_personel;

         FETCH cur_masraf_personel INTO ls_personelden_alinir;

         CLOSE cur_masraf_personel;

         IF NVL (ls_personelden_alinir, 'H') = 'H'
         THEN
            pn_masraf := 0;
            pn_bsmv := 0;
            RETURN;
         END IF;
      --E-O-M sevalb 090507 personel masraf flag degisiklikleri
      END IF;

      IF ps_msrf_dvz IS NULL
      THEN
         ls_msrf_dvz := ps_doviz;
      ELSE
         ls_msrf_dvz := ps_msrf_dvz;
      END IF;

      ln_temp :=
         masraf_muaf_var (ps_masraf_kod,
                          pn_islem_kodu,
                          pn_musteri_no,
                          ps_modul,
                          ps_urun_tur,
                          ps_urun_sinif);


      IF ln_temp = 0
      THEN                                                          --muaf yok
         BEGIN
            masraf_tutarlari_al (ps_masraf_kod,
                                 pn_islem_kodu,
                                 ps_modul,
                                 ps_urun_tur,
                                 ps_urun_sinif,
                                 ln_min_yuzde,
                                 ln_max_yuzde,
                                 ln_min_tutar,
                                 ln_max_tutar,
                                 ln_tutar,
                                 lc_bsmv_al,
                                 ls_sabit_oran,
                                 ln_yuzde,
                                 ls_dvz,
                                 ls_tum_doviz,
                                 ls_kom_kur_kullan);
            ls_dvz_temp := ls_dvz;
            ln_temp := pn_tutar;                      --CQ4879 MederT 21012016
            ls_dvz := ps_doviz;                       --CQ4879 MederT 21012016
            ln_fix :=
               masraf_fix_var (ps_masraf_kod,
                               pn_islem_kodu,
                               pn_musteri_no,
                               ps_modul,
                               ps_urun_tur,
                               ps_urun_sinif,
                               ln_temp,
                               ls_dvz,
                               ln_fix_min_tutar,
                               ln_fix_max_tutar);     --CQ4879 MederT 02112015

            log_at('mutlu', ln_fix, ps_masraf_kod,ln_temp);
            IF ln_fix = 1
            THEN                          --fix deger alinacak, tutar girilmi?
               IF ls_kom_kur_kullan = 'E'
               THEN
                  --komisyon kurundan donusum yapilmasi istenmis...
                  IF    ls_dvz = pkg_genel.lc_al
                     OR ls_msrf_dvz = pkg_genel.lc_al
                  THEN
                     pn_masraf :=
                        pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                           ls_dvz,
                           ls_msrf_dvz,
                           NULL,
                           NVL (ln_temp, 0),
                           NULL,
                           NULL);
                  ELSE              --hic lc olmayinca bu kuru kullanmiyoz....
                     pn_masraf :=
                        pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                      ls_msrf_dvz,
                                                      NULL,
                                                      NVL (ln_temp, 0),
                                                      1,
                                                      NULL,
                                                      NULL,
                                                      'N',
                                                      'A');
                  END IF;
               ELSE
                  pn_masraf :=
                     pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                   ls_msrf_dvz,
                                                   NULL,
                                                   NVL (ln_temp, 0),
                                                   1,
                                                   NULL,
                                                   NULL,
                                                   'N',
                                                   'A');
               END IF;
            ELSIF ln_fix = 2
            THEN                           --fix oran alinacak, oran girilmis.
--               log_at('mutlu2', pn_masraf, ls_kom_kur_kullan);
               pn_masraf := NVL (pn_tutar, 0) * ln_temp / 100;

               --BOM CQ4879 MederT 02112015
               IF ln_fix_min_tutar != 0 AND pn_masraf < ln_fix_min_tutar
               THEN
                  pn_masraf := ln_fix_min_tutar;
               ELSIF ln_fix_max_tutar != 0 AND pn_masraf > ln_fix_max_tutar
               THEN
                  pn_masraf := ln_fix_max_tutar;
               END IF;

               --EOM CQ4879 MederT 02112015
               IF ls_kom_kur_kullan = 'E'
               THEN
                  --komisyon kurundan donusum yapilmasi istenmis...
                  IF    ps_doviz = pkg_genel.lc_al
                     OR ls_msrf_dvz = pkg_genel.lc_al
                  THEN
                     pn_masraf :=
                        pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                           ps_doviz,
                           ls_msrf_dvz,
                           NULL,
                           NVL (pn_masraf, 0),
                           NULL,
                           NULL);
                  --log_at('mutlu5', pn_masraf, ls_msrf_dvz);
                  ELSE              --hic lc olmayinca bu kuru kullanmiyoz....
                     pn_masraf :=
                        pkg_kur.doviz_doviz_karsilik (ps_doviz,
                                                      ls_msrf_dvz,
                                                      NULL,
                                                      NVL (pn_masraf, 0),
                                                      1,
                                                      NULL,
                                                      NULL,
                                                      'N',
                                                      'A');
                  --log_at('mutlu4', pn_masraf, ls_kom_kur_kullan);
                  END IF;
               ELSE
                  --log_at('mutlu3', pn_masraf, ps_doviz,ls_msrf_dvz);
                  pn_masraf :=
                     pkg_kur.doviz_doviz_karsilik (ps_doviz,
                                                   ls_msrf_dvz,
                                                   NULL,
                                                   NVL (pn_masraf, 0),
                                                   1,
                                                   NULL,
                                                   NULL,
                                                   'N',
                                                   'A');
               --log_at('mutlu4', pn_masraf, ls_kom_kur_kullan);
               END IF;
            ELSE                                                    -- fix yok
               -- B-O-M Sevalb 300307 fix yok oncesine ATM masraf parametresinden degerlerin alinmasi eklendi.
               IF NVL (pc_hesap_numara, 0) <> 0
               THEN
                  SELECT COUNT (*)
                    INTO ln_atm_msrf_adet
                    FROM cbs_masraf_kriterleri
                   WHERE     charge_code = ps_masraf_kod
                         AND terminal_branch_code = pc_bolum_kodu
                         AND DECODE (
                                pkg_hesap.hesaptandovizkodual (
                                   pc_hesap_numara),
                                pkg_genel.lc_al, pkg_genel.lc_al,
                                'USD') = charge_currency;
               END IF;

               IF NVL (ln_atm_msrf_adet, 0) <> 0
               THEN
                  OPEN cur_atm_masraf_kriter;

                  FETCH cur_atm_masraf_kriter INTO pn_masraf, ls_atm_msrf_dvz; --sevalb 160407 oran aliniyor

                  CLOSE cur_atm_masraf_kriter;

                  pn_masraf :=
                     pkg_kur.doviz_doviz_karsilik (
                        ls_atm_msrf_dvz,
                        ls_msrf_dvz,
                        NULL,
                        NVL (pn_masraf, 0) * NVL (pn_tutar, 0) / 100,
                        1,
                        NULL,
                        NULL,
                        'N',
                        'A');
               ELSE
                  --E-O-M
                  ls_dvz := ls_dvz_temp;

                  BEGIN
                     lb_check_rol := TRUE;

                     BEGIN         --rol icin gerekli degerler de aliniyor....
                        SELECT artma_marj,
                               azaltma_marj,
                               min_tutar,
                               max_tutar
                          INTO ln_rol_artma_marj,
                               ln_rol_azaltma_marj,
                               ln_rol_min_tutar,
                               ln_rol_max_tutar
                          FROM cbs_islem_masraf_rol_tanim
                         WHERE     islem_kodu = pn_islem_kodu
                               AND masraf_kodu = ps_masraf_kod
                               AND rol_kodu = pn_rol;
                     EXCEPTION
                        WHEN NO_DATA_FOUND
                        THEN
                           lb_check_rol := FALSE;
                        WHEN OTHERS
                        THEN
                           raise_application_error (
                              -20100,
                                 pkg_hata.getucpointer
                              || '204'
                              || pkg_hata.getdelimiter
                              || SQLERRM
                              || pkg_hata.getucpointer);
                     END;

                     IF ls_dvz <> ls_msrf_dvz
                     THEN --defined for different curreny, turn into tx/wanted currency
                        IF ls_kom_kur_kullan = 'E'
                        THEN
                           --komisyon kurundan donusum yapilmasi istenmis...
                           IF    ls_dvz = pkg_genel.lc_al
                              OR ls_msrf_dvz = pkg_genel.lc_al
                           THEN
                              ln_min_tutar :=
                                 pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                    ls_dvz,
                                    ls_msrf_dvz,
                                    NULL,
                                    ln_min_tutar,
                                    NULL,
                                    NULL);
                              ln_max_tutar :=
                                 pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                    ls_dvz,
                                    ls_msrf_dvz,
                                    NULL,
                                    ln_max_tutar,
                                    NULL,
                                    NULL);
                              ln_tutar :=
                                 pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                    ls_dvz,
                                    ls_msrf_dvz,
                                    NULL,
                                    ln_tutar,
                                    NULL,
                                    NULL);
                              ln_rol_min_tutar :=
                                 pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                    ls_dvz,
                                    ls_msrf_dvz,
                                    NULL,
                                    ln_rol_min_tutar,
                                    NULL,
                                    NULL);
                              ln_rol_max_tutar :=
                                 pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                    ls_dvz,
                                    ls_msrf_dvz,
                                    NULL,
                                    ln_rol_max_tutar,
                                    NULL,
                                    NULL);
                           ELSE     --hic lc olmayinca bu kuru kullanmiyoz....
                              ln_min_tutar :=
                                 pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                               ls_msrf_dvz,
                                                               NULL,
                                                               ln_min_tutar,
                                                               1,
                                                               NULL,
                                                               NULL,
                                                               'N',
                                                               'A');
                              ln_max_tutar :=
                                 pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                               ls_msrf_dvz,
                                                               NULL,
                                                               ln_max_tutar,
                                                               1,
                                                               NULL,
                                                               NULL,
                                                               'N',
                                                               'A');
                              ln_tutar :=
                                 pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                               ls_msrf_dvz,
                                                               NULL,
                                                               ln_tutar,
                                                               1,
                                                               NULL,
                                                               NULL,
                                                               'N',
                                                               'A');
                              ln_rol_min_tutar :=
                                 pkg_kur.doviz_doviz_karsilik (
                                    ls_dvz,
                                    ls_msrf_dvz,
                                    NULL,
                                    ln_rol_min_tutar,
                                    1,
                                    NULL,
                                    NULL,
                                    'N',
                                    'A');
                              ln_rol_max_tutar :=
                                 pkg_kur.doviz_doviz_karsilik (
                                    ls_dvz,
                                    ls_msrf_dvz,
                                    NULL,
                                    ln_rol_max_tutar,
                                    1,
                                    NULL,
                                    NULL,
                                    'N',
                                    'A');
                           END IF;
                        ELSE
                           ln_min_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_min_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_max_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_max_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_rol_min_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_rol_min_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_rol_max_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_rol_max_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                        END IF;
                     END IF;

                     IF ls_kom_kur_kullan = 'E'
                     THEN
                        --komisyon kurundan donusum yapilmasi istenmis...
                        IF    NVL (ls_dvz, ls_msrf_dvz) = pkg_genel.lc_al
                           OR ls_msrf_dvz = pkg_genel.lc_al
                           OR ps_doviz = pkg_genel.lc_al
                        THEN
                           lb_kom_kur_kullan := 'E';
                        ELSE
                           lb_kom_kur_kullan := 'H';
                        END IF;
                     ELSE
                        lb_kom_kur_kullan := 'H';
                     END IF;

                     IF ls_sabit_oran = 'S'
                     THEN                           --sabitse basamak kontrol?
                        masraf_aralik_tutar_al (ps_masraf_kod,
                                                pn_islem_kodu,
                                                ps_modul,
                                                ps_urun_tur,
                                                ps_urun_sinif,
                                                pn_tutar,
                                                ls_dvz,
                                                ls_msrf_dvz,
                                                ps_doviz,
                                                ln_min_tutar,
                                                ln_max_tutar,
                                                ln_tutar,
                                                lb_kom_kur_kullan);
                     ELSE                        --oranl? ise basamak kontrol?
                        masraf_aralik_yuzde_tutar_al (ps_masraf_kod,
                                                      pn_islem_kodu,
                                                      ps_modul,
                                                      ps_urun_tur,
                                                      ps_urun_sinif,
                                                      pn_tutar,
                                                      ls_dvz,
                                                      ls_msrf_dvz,
                                                      ps_doviz,
                                                      ln_min_yuzde,
                                                      ln_max_yuzde,
                                                      ln_yuzde,
                                                      ln_min_tutar,
                                                      ln_max_tutar,
                                                      lb_kom_kur_kullan);
                     END IF;

                     IF ls_sabit_oran = 'S'
                     THEN                               --sabit de?er al?n?yor
                        pn_masraf := ln_tutar;

                        IF lb_check_rol
                        THEN
                           IF ln_rol_min_tutar IS NOT NULL
                           THEN
                              IF pn_masraf < ln_rol_min_tutar
                              THEN
                                 pn_masraf := ln_rol_min_tutar;
                              END IF;
                           END IF;

                           IF ln_rol_max_tutar IS NOT NULL
                           THEN
                              IF pn_masraf > ln_rol_max_tutar
                              THEN
                                 pn_masraf := ln_rol_max_tutar;
                              END IF;
                           END IF;
                        END IF;
                     ELSE
                        --log_at(ls_dvz,ls_msrf_dvz, 't3');
                        
                        ln_oranli := NVL (pn_tutar, 0) * ln_yuzde / 100;
                        pn_masraf := ln_oranli;
                        
                        /*
                        if ls_kom_kur_kullan = 'E' then
                        --komisyon kurundan donusum yapilmasi istenmis...
                          if nvl(ls_dvz, ls_msrf_dvz) = pkg_genel.lc_al or ls_msrf_dvz= pkg_genel.lc_al then
                            pn_masraf := pkg_komisyon_kur.kom_doviz_doviz_karsilik(nvl(ls_dvz, ls_msrf_dvz), ls_msrf_dvz, null, ln_oranli, null, null);
                          else
                             pn_masraf := pkg_kur.doviz_doviz_karsilik(nvl(ls_dvz, ls_msrf_dvz), ls_msrf_dvz, null, ln_oranli, 1, null, null, 'N', 'A');
                          end if;
                        else
                          pn_masraf := pkg_kur.doviz_doviz_karsilik(nvl(ls_dvz, ls_msrf_dvz), ls_msrf_dvz, null, ln_oranli, 1, null, null, 'N', 'A');
                        end if;
                        */
                        IF lb_check_rol AND ln_rol_max_tutar IS NOT NULL
                        THEN
                           IF ln_oranli > ln_rol_max_tutar
                           THEN
                              pn_masraf := ln_rol_max_tutar;
                           END IF;
                        ELSE
                           IF NVL (ln_max_tutar, 0) > 0
                           THEN                    --maksimum tutar girildiyse
                              
                              IF ln_oranli > ln_max_tutar
                              THEN --hesaplanan oran al?nabilecek maks miktardan fazla ise
                                 pn_masraf := ln_max_tutar;
                              END IF;
                           END IF;
                        END IF;

                        IF lb_check_rol AND ln_rol_min_tutar IS NOT NULL
                        THEN
                            
                           IF ln_oranli < ln_rol_min_tutar
                           THEN
                              pn_masraf := ln_rol_min_tutar;
                           END IF;
                        ELSE
                           
                           IF NVL (ln_min_tutar, 0) > 0
                           THEN                     --minimum tutar girildiyse
                              IF ln_oranli < ln_min_tutar
                              THEN --hesaplanan oran al?nabilecek min miktardan az ise
                                 pn_masraf := ln_min_tutar;
                              END IF;
                           END IF;
                        END IF;
                     END IF;
                  END;                              --cur_musteri_fix%notfound
               END IF;
            END IF;

            IF lc_bsmv_al = 'E'
            THEN
               IF ls_msrf_dvz <> pkg_genel.lc_al
               THEN
                  ln_temp := pkg_kur.dak_to_lc (ls_msrf_dvz, pn_masraf);
                  pn_bsmv := bsmv_hesapla (ln_temp);
                  pn_bsmv :=
                     pkg_kur.doviz_doviz_karsilik (pkg_genel.lc_al,
                                                   ls_msrf_dvz,
                                                   NULL,
                                                   pn_bsmv,
                                                   1,
                                                   NULL,
                                                   NULL,
                                                   'O',
                                                   'A');
               ELSE
                  pn_bsmv := bsmv_hesapla (pn_masraf);
               END IF;
            ELSE
               pn_bsmv := 0;
            END IF;
         END;                                      --cur_musteri_muaf%notfound
      ELSE
         pn_masraf := 0;
         pn_bsmv := 0;
      END IF;

      pn_masraf := pkg_kur.yuvarla (ls_msrf_dvz, pn_masraf);
      pn_bsmv := pkg_kur.yuvarla (ls_msrf_dvz, pn_bsmv);
   END;

   /*--------------------------------------------------------------------------------------------------- */
   PROCEDURE get_rol_min_max_tutar (pn_hesaplanan             NUMBER,
                                    pn_rol_marj_arti          NUMBER,
                                    pn_rol_marj_eksi          NUMBER,
                                    pn_rol_min_tutar          NUMBER,
                                    pn_rol_max_tutar          NUMBER,
                                    pn_max_tutar              NUMBER,
                                    pn_min_tutar              NUMBER,
                                    pn_max             IN OUT NUMBER,
                                    pn_min             IN OUT NUMBER)
   IS
   BEGIN
      pn_max :=
         NVL (pn_hesaplanan + (pn_hesaplanan * pn_rol_marj_arti / 100),
              pn_max);

      IF pn_rol_max_tutar IS NOT NULL
      THEN                                --rol i?in maksimum de?er girildiyse
         pn_max := pn_rol_max_tutar;
      END IF;

      pn_min :=
         NVL (pn_hesaplanan - (pn_hesaplanan * pn_rol_marj_eksi / 100),
              pn_min);

      IF pn_rol_min_tutar IS NOT NULL
      THEN                                 --rol i?in minimum de?er girildiyse
         pn_min := pn_rol_min_tutar;
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE get_min_max_tutar (pn_tutar                    NUMBER,
                                ps_sabit_oran               VARCHAR2,
                                pn_max_tutar                NUMBER,
                                pn_min_tutar                NUMBER,
                                pn_max_yuzde                NUMBER,
                                pn_min_yuzde                NUMBER,
                                pn_max_hesap_tutar   IN OUT NUMBER,
                                pn_min_hesap_tutar   IN OUT NUMBER)
   IS
      ln_temp   NUMBER;
   BEGIN
      IF ps_sabit_oran = 'S'
      THEN              --sabit masraf al?nacak... oranlar dikkate al?nmayacak
         pn_max_hesap_tutar := pn_max_tutar;
         pn_min_hesap_tutar := pn_min_tutar;
      ELSE                         --tutarlar dahilinde oranl? masraf al?nacak
         ln_temp := pn_tutar * pn_max_yuzde / 100;
         

         IF pn_max_tutar IS NOT NULL AND pn_max_tutar != 0 -- nursultanT 26.10.2018  NULL became 0 it leads to 'pn_max_hesap_tutar := 0;' 
         THEN                                        -- maximum tutar girilmis
            pn_max_hesap_tutar := pn_max_tutar;
         ELSE
            pn_max_hesap_tutar := ln_temp;
         END IF;

         ln_temp := pn_tutar * pn_min_yuzde / 100;

         IF pn_min_tutar IS NOT NULL
         THEN
            pn_min_hesap_tutar := pn_min_tutar;
         ELSE
            pn_min_hesap_tutar := ln_temp;
         END IF;
 
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_kontrol (pn_alinan       IN     NUMBER,
                             pn_hesaplanan   IN     NUMBER,
                             ps_masraf_kod   IN     cbs_masraf_tur.kodu%TYPE,
                             pn_tutar        IN     NUMBER,
                             pn_islem_kodu   IN     NUMBER,
                             pn_rol          IN     NUMBER,
                             pn_musteri_no   IN     NUMBER,
                             ps_doviz        IN     VARCHAR2,
                             pn_masraf       IN OUT NUMBER,
                             pn_bsmv         IN OUT NUMBER,
                             ps_msrf_dvz     IN     VARCHAR2 DEFAULT NULL,
                             ps_modul        IN     VARCHAR2 DEFAULT NULL,
                             ps_urun_tur     IN     VARCHAR2 DEFAULT NULL,
                             ps_urun_sinif   IN     VARCHAR2 DEFAULT NULL)
   IS
      ln_min_yuzde            NUMBER;
      ln_max_yuzde            NUMBER;
      ln_min_tutar            NUMBER;
      ln_max_tutar            NUMBER;
      ln_tutar                NUMBER;
      lc_bsmv_al              VARCHAR2 (1);
      ls_sabit_oran           VARCHAR2 (1);
      ln_oranli               NUMBER;
      ln_yuzde                NUMBER;
      ln_rol_artma_marj       NUMBER;
      ln_rol_azaltma_marj     NUMBER;
      ln_rol_min_tutar        NUMBER;
      ln_rol_max_tutar        NUMBER;
      lb_check_rol            BOOLEAN;
      ln_olabilen             NUMBER;
      ln_temp                 NUMBER;
      ln_max_hesap_tutar      NUMBER;
      ln_min_hesap_tutar      NUMBER;
      ls_dvz                  VARCHAR2 (3);
      ls_tum_doviz            VARCHAR2 (1);
      ls_msrf_dvz             VARCHAR2 (3);
      ln_fix                  NUMBER;
      ls_kom_kur_kullan       VARCHAR2 (1);
      lb_kom_kur_kullan       VARCHAR2 (1);
      --BOM CQ4879 MederT 02112015
      ln_fix_min_tutar        cbs_musteri_islem_masraf_fix.min_tutar%TYPE;
      ln_fix_max_tutar        cbs_musteri_islem_masraf_fix.max_tutar%TYPE;
      --EOM CQ4879 MederT 02112015
      ls_fix_dvz              VARCHAR2 (3);           --CQ5676 MederT 30112016

      CURSOR cur_musteri_personel_mi
      IS
         SELECT 1
           FROM cbs_musteri
          WHERE musteri_no = pn_musteri_no AND personel_sicil_no IS NOT NULL;

      --B-O-M sevalb 15122010 personel masraf flag degisiklikleri
      CURSOR cur_masraf_personel
      IS
         SELECT personelden_alinir
           FROM cbs_masraf_tur
          WHERE kodu = ps_masraf_kod;

      ls_personelden_alinir   VARCHAR2 (1);
   --E-O-M sevalb 15122010 personel masraf flag degisiklikleri
   BEGIN
      OPEN cur_musteri_personel_mi;

      FETCH cur_musteri_personel_mi INTO ln_temp;

      IF cur_musteri_personel_mi%NOTFOUND
      THEN
         CLOSE cur_musteri_personel_mi;
      ELSE
         CLOSE cur_musteri_personel_mi;

         pn_masraf := 0;
         pn_bsmv := 0;

         --B-O-M sevalb 15122010 personel masraf flag degisiklikleri
         OPEN cur_masraf_personel;

         FETCH cur_masraf_personel INTO ls_personelden_alinir;

         CLOSE cur_masraf_personel;

         --E-O-M sevalb 15122010 personel masraf flag degisiklikleri

         IF pn_alinan > 0 AND NVL (ls_personelden_alinir, 'H') = 'H'
         THEN
            Raise_application_error (
               -20100,
                  pkg_hata.getUCPOINTER
               || '231'
               || pkg_hata.getDELIMITER
               || TO_CHAR (pn_musteri_no)
               || pkg_hata.getUCPOINTER);
         END IF;

         RETURN;
      END IF;

      -- log_at('ps_msrf_dvz', ps_msrf_dvz, 'ps_doviz', ps_doviz);
      IF ps_msrf_dvz IS NULL
      THEN
         ls_msrf_dvz := ps_doviz;
      ELSE
         ls_msrf_dvz := ps_msrf_dvz;
      END IF;

      ls_fix_dvz := ps_doviz;                         --CQ5676 MederT 30112016
      ln_temp :=
         masraf_muaf_var (ps_masraf_kod,
                          pn_islem_kodu,
                          pn_musteri_no,
                          ps_modul,
                          ps_urun_tur,
                          ps_urun_sinif);

      IF ln_temp = 0
      THEN                                                          --muaf yok
         BEGIN
            --definition al...
            masraf_tutarlari_al (ps_masraf_kod,
                                 pn_islem_kodu,
                                 ps_modul,
                                 ps_urun_tur,
                                 ps_urun_sinif,
                                 ln_min_yuzde,
                                 ln_max_yuzde,
                                 ln_min_tutar,
                                 ln_max_tutar,
                                 ln_tutar,
                                 lc_bsmv_al,
                                 ls_sabit_oran,
                                 ln_yuzde,
                                 ls_dvz,
                                 ls_tum_doviz,
                                 ls_kom_kur_kullan);
            ln_fix :=
               masraf_fix_var (ps_masraf_kod,
                               pn_islem_kodu,
                               pn_musteri_no,
                               ps_modul,
                               ps_urun_tur,
                               ps_urun_sinif,
                               ln_temp,
                               ls_fix_dvz,
                               ln_fix_min_tutar,
                               ln_fix_max_tutar); --CQ5676 MederT 30112016     --CQ4879 MederT 02112015

            IF ln_fix = 0
            THEN                                                    -- fix yok
               BEGIN
                  lb_check_rol := TRUE;

                  BEGIN
                     SELECT artma_marj,
                            azaltma_marj,
                            min_tutar,
                            max_tutar
                       INTO ln_rol_artma_marj,
                            ln_rol_azaltma_marj,
                            ln_rol_min_tutar,
                            ln_rol_max_tutar
                       FROM cbs_islem_masraf_rol_tanim
                      WHERE     islem_kodu = pn_islem_kodu
                            AND masraf_kodu = ps_masraf_kod
                            AND rol_kodu = pn_rol;
                  EXCEPTION
                     WHEN NO_DATA_FOUND
                     THEN
                        lb_check_rol := FALSE;
                     WHEN OTHERS
                     THEN
                        raise_application_error (
                           -20100,
                              pkg_hata.getucpointer
                           || '204'
                           || pkg_hata.getdelimiter
                           || SQLERRM
                           || pkg_hata.getucpointer);
                  END;

                  IF ls_dvz <> ls_msrf_dvz
                  THEN --defined for different curreny, turn into tx/wanted currency
                     IF ls_kom_kur_kullan = 'E'
                     THEN
                        --komisyon kurundan donusum yapilmasi istenmis...
                        IF    ls_dvz = pkg_genel.lc_al
                           OR ls_msrf_dvz = pkg_genel.lc_al
                        THEN
                           ln_min_tutar :=
                              pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                 ls_dvz,
                                 ls_msrf_dvz,
                                 NULL,
                                 ln_min_tutar,
                                 NULL,
                                 NULL);
                           ln_max_tutar :=
                              pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                 ls_dvz,
                                 ls_msrf_dvz,
                                 NULL,
                                 ln_max_tutar,
                                 NULL,
                                 NULL);
                           ln_tutar :=
                              pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                 ls_dvz,
                                 ls_msrf_dvz,
                                 NULL,
                                 ln_tutar,
                                 NULL,
                                 NULL);
                           ln_rol_min_tutar :=
                              pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                 ls_dvz,
                                 ls_msrf_dvz,
                                 NULL,
                                 ln_rol_min_tutar,
                                 NULL,
                                 NULL);
                           ln_rol_max_tutar :=
                              pkg_komisyon_kur.kom_doviz_doviz_karsilik (
                                 ls_dvz,
                                 ls_msrf_dvz,
                                 NULL,
                                 ln_rol_max_tutar,
                                 NULL,
                                 NULL);
                        ELSE        --hic lc olmayinca bu kuru kullanmiyoz....
                           ln_min_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_min_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_max_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_max_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_rol_min_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_rol_min_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                           ln_rol_max_tutar :=
                              pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                            ls_msrf_dvz,
                                                            NULL,
                                                            ln_rol_max_tutar,
                                                            1,
                                                            NULL,
                                                            NULL,
                                                            'N',
                                                            'A');
                        END IF;
                     ELSE
                        ln_min_tutar :=
                           pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                         ls_msrf_dvz,
                                                         NULL,
                                                         ln_min_tutar,
                                                         1,
                                                         NULL,
                                                         NULL,
                                                         'N',
                                                         'A');
                        ln_max_tutar :=
                           pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                         ls_msrf_dvz,
                                                         NULL,
                                                         ln_max_tutar,
                                                         1,
                                                         NULL,
                                                         NULL,
                                                         'N',
                                                         'A');
                        ln_tutar :=
                           pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                         ls_msrf_dvz,
                                                         NULL,
                                                         ln_tutar,
                                                         1,
                                                         NULL,
                                                         NULL,
                                                         'N',
                                                         'A');
                        ln_rol_min_tutar :=
                           pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                         ls_msrf_dvz,
                                                         NULL,
                                                         ln_rol_min_tutar,
                                                         1,
                                                         NULL,
                                                         NULL,
                                                         'N',
                                                         'A');
                        ln_rol_max_tutar :=
                           pkg_kur.doviz_doviz_karsilik (ls_dvz,
                                                         ls_msrf_dvz,
                                                         NULL,
                                                         ln_rol_max_tutar,
                                                         1,
                                                         NULL,
                                                         NULL,
                                                         'N',
                                                         'A');
                     END IF;
                  END IF;

                  IF ls_kom_kur_kullan = 'E'
                  THEN
                     --komisyon kurundan donusum yapilmasi istenmis...
                     IF    NVL (ls_dvz, ls_msrf_dvz) = pkg_genel.lc_al
                        OR ls_msrf_dvz = pkg_genel.lc_al
                        OR ps_doviz = pkg_genel.lc_al
                     THEN
                        lb_kom_kur_kullan := 'E';
                     ELSE
                        lb_kom_kur_kullan := 'H';
                     END IF;
                  ELSE
                     lb_kom_kur_kullan := 'H';
                  END IF;

                  IF ls_sabit_oran = 'S'
                  THEN                              --sabitse basamak kontrol?
                     masraf_aralik_tutar_al (ps_masraf_kod,
                                             pn_islem_kodu,
                                             ps_modul,
                                             ps_urun_tur,
                                             ps_urun_sinif,
                                             pn_tutar,
                                             ls_dvz,
                                             ls_msrf_dvz,
                                             ps_doviz,
                                             ln_min_tutar,
                                             ln_max_tutar,
                                             ln_tutar,
                                             lb_kom_kur_kullan);
                  ELSE                           --oranl? ise basamak kontrol?
                     masraf_aralik_yuzde_tutar_al (ps_masraf_kod,
                                                   pn_islem_kodu,
                                                   ps_modul,
                                                   ps_urun_tur,
                                                   ps_urun_sinif,
                                                   pn_tutar,
                                                   ls_dvz,
                                                   ls_msrf_dvz,
                                                   ps_doviz,
                                                   ln_min_yuzde,
                                                   ln_max_yuzde,
                                                   ln_yuzde,
                                                   ln_min_tutar,
                                                   ln_max_tutar,
                                                   lb_kom_kur_kullan);
                  END IF;

                  IF lb_check_rol
                  THEN --rol ?zerinde marj tan?mlanm??, sadece bu kontrol edilir.
                     get_rol_min_max_tutar (pn_hesaplanan,
                                            ln_rol_artma_marj,
                                            ln_rol_azaltma_marj,
                                            ln_rol_min_tutar,
                                            ln_rol_max_tutar,
                                            ln_max_tutar,
                                            ln_min_tutar,
                                            ln_max_hesap_tutar,
                                            ln_min_hesap_tutar);
                  ELSE                                        --check rol done
                     get_min_max_tutar (pn_tutar,
                                        ls_sabit_oran,
                                        ln_max_tutar,
                                        ln_min_tutar,
                                        ln_max_yuzde,
                                        ln_min_yuzde,
                                        ln_max_hesap_tutar,
                                        ln_min_hesap_tutar);
                  END IF;

                  ln_max_hesap_tutar :=
                     pkg_kur.yuvarla (ls_msrf_dvz, ln_max_hesap_tutar);
                  ln_min_hesap_tutar :=
                     pkg_kur.yuvarla (ls_msrf_dvz, ln_min_hesap_tutar);

--log_at('masrf',ln_max_hesap_tutar,ln_min_hesap_tutar);
                  IF ln_min_hesap_tutar > ln_max_hesap_tutar
                  THEN
                     ln_max_hesap_tutar := ln_min_hesap_tutar;
                  END IF;

                  IF pn_alinan > ln_max_hesap_tutar
                  THEN
                     raise_application_error (
                        -20100,
                           pkg_hata.getucpointer
                        || '205'
                        || pkg_hata.getdelimiter
                        || LTRIM (
                              TO_CHAR (ln_max_hesap_tutar,
                                       '999,999,999,999,999,999,999.99'))
                        || pkg_hata.getucpointer);
                     RETURN;
                  END IF;

                  IF pn_alinan < ln_min_hesap_tutar
                  THEN
                     raise_application_error (
                        -20100,
                           pkg_hata.getucpointer
                        || '206'
                        || pkg_hata.getdelimiter
                        || LTRIM (
                              TO_CHAR (ln_min_hesap_tutar,
                                       '999,999,999,999,999,999,999.99'))
                        || pkg_hata.getucpointer);
                     RETURN;
                  END IF;
               END;                                 --cur_musteri_fix%notfound
            ELSE                                          --fix de?er al?nacak
               ls_dvz := ls_fix_dvz;                  --CQ5676 MederT 30112016

               IF pn_alinan <> pn_hesaplanan
               THEN
                  raise_application_error (
                     -20100,
                        pkg_hata.getucpointer
                     || '247'
                     || pkg_hata.getdelimiter
                     || TO_CHAR (pn_musteri_no)
                     || pkg_hata.getdelimiter
                     || LTRIM (
                           TO_CHAR (pn_hesaplanan,
                                    '999,999,999,999,999,999,999.99'))
                     || pkg_hata.getucpointer);
                  RETURN;
               END IF;
            END IF;

            IF lc_bsmv_al = 'E'
            THEN
               IF ls_msrf_dvz <> pkg_genel.lc_al
               THEN
                  ln_temp := pkg_kur.dak_to_lc (ls_msrf_dvz, pn_alinan);
                  pn_bsmv := bsmv_hesapla (ln_temp);
                  pn_bsmv :=
                     pkg_kur.doviz_doviz_karsilik (pkg_genel.lc_al,
                                                   ls_msrf_dvz,
                                                   NULL,
                                                   pn_bsmv,
                                                   1,
                                                   NULL,
                                                   NULL,
                                                   'O',
                                                   'A');
               ELSE
                  pn_bsmv := bsmv_hesapla (pn_alinan);
               END IF;
            ELSE
               pn_bsmv := 0;
            END IF;
         END;                                      --cur_musteri_muaf%notfound
      ELSE                                         --musteri muafiyeti var....
         pn_bsmv := NVL (pn_bsmv, 0);
         pn_masraf := NVL (pn_masraf, 0);

         IF pn_alinan > 0
         THEN
            raise_application_error (
               -20100,
                  pkg_hata.getucpointer
               || '231'
               || pkg_hata.getdelimiter
               || TO_CHAR (pn_musteri_no)
               || pkg_hata.getucpointer);
            RETURN;
         END IF;
      END IF;

      pn_masraf := pkg_kur.yuvarla (ls_msrf_dvz, pn_masraf);
      pn_bsmv := pkg_kur.yuvarla (ls_msrf_dvz, pn_bsmv);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION sf_masraf_adi (ps_masraf_kodu cbs_masraf_tur.kodu%TYPE)
      RETURN VARCHAR2
   IS
      ls_masraf_aciklama   cbs_masraf_tur.adi%TYPE;
   BEGIN
      SELECT adi
        INTO ls_masraf_aciklama
        FROM cbs_masraf_tur
       WHERE kodu = ps_masraf_kodu;

      RETURN ls_masraf_aciklama;
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '221' || pkg_hata.getucpointer);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE check_default_deger (
      ps_masraf_kod   IN cbs_masraf_odeyen.masraf_kodu%TYPE)
   IS
      ln_def   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO ln_def
        FROM cbs_masraf_odeyen
       WHERE masraf_kodu = ps_masraf_kod AND default_deger = 'E';

      IF ln_def = 0
      THEN
         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '223' || pkg_hata.getucpointer);
      ELSIF ln_def > 1
      THEN
         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '224' || pkg_hata.getucpointer);
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION default_odeyen (
      ps_masraf_kod   IN cbs_masraf_odeyen.masraf_kodu%TYPE)
      RETURN VARCHAR2
   IS
      ls_odeyecek   VARCHAR2 (30);
   BEGIN
      SELECT odeyecek
        INTO ls_odeyecek
        FROM cbs_masraf_odeyen
       WHERE masraf_kodu = ps_masraf_kod AND default_deger = 'E';

      RETURN (ls_odeyecek);
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '225'
            || pkg_hata.getdelimiter
            || SQLERRM
            || pkg_hata.getucpointer);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION masraf_girilmis (
      pn_islem_no            NUMBER,
      pn_islem_kodu       IN NUMBER,
      pc_modul_tur_kod       cbs_islem.modul_tur_kod%TYPE,
      pc_urun_tur_kod        cbs_islem.urun_tur_kod%TYPE,
      pc_urun_sinif_kod      cbs_islem.urun_sinif_kod%TYPE)
      RETURN BOOLEAN
   IS
      ln_cnt   NUMBER := 0;
   BEGIN
      IF masraf_yaratilmali (pn_islem_kodu,
                             pc_modul_tur_kod,
                             pc_urun_tur_kod,
                             pc_urun_sinif_kod)
      THEN
         SELECT COUNT (*)
           INTO ln_cnt
           FROM cbs_masraf
          WHERE cbs_masraf.islem_no = pn_islem_no;

         IF NVL (ln_cnt, 0) = 0
         THEN
            RETURN FALSE;
         ELSE
            RETURN TRUE;
         END IF;
      END IF;

      RETURN TRUE;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION masraf_hesaplanan_al (
      pn_islem_kodu   IN NUMBER,
      ps_masraf_kod   IN cbs_masraf_tur.kodu%TYPE)
      RETURN NUMBER
   IS
      CURSOR cur_masraf
      IS
         SELECT hesaplanan
           FROM cbs_masraf
          WHERE islem_no = pn_islem_kodu AND masraf_kodu = ps_masraf_kod;

      ls_hesaplanan   cbs_masraf.hesaplanan%TYPE;
   BEGIN
      OPEN cur_masraf;

      FETCH cur_masraf INTO ls_hesaplanan;

      IF cur_masraf%NOTFOUND
      THEN
         CLOSE cur_masraf;

         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '2003' || pkg_hata.getucpointer);
      END IF;

      CLOSE cur_masraf;

      RETURN (ls_hesaplanan);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE open_masraf_cur (pn_islem_no NUMBER)
   IS
   BEGIN
      OPEN cur_masraf (pn_islem_no);
    null;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE fetch_masraf_cur (row_masraf   OUT cur_masraf%ROWTYPE,
                               ls_ok        OUT VARCHAR2)
   IS
   BEGIN
      FETCH cur_masraf INTO row_masraf;

      IF cur_masraf%NOTFOUND
      THEN
         ls_ok := 'H';
      ELSE
         ls_ok := 'E';
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE close_masraf_cur
   IS
   BEGIN
      CLOSE cur_masraf;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_yarat (
      pn_islem_no          NUMBER,
      pn_islem_kod         cbs_islem.islem_kod%TYPE,
      pc_modul_tur_kod     cbs_islem.modul_tur_kod%TYPE,
      pc_urun_tur_kod      cbs_islem.urun_tur_kod%TYPE,
      pc_urun_sinif_kod    cbs_islem.urun_sinif_kod%TYPE,
      pn_tutar             cbs_islem.tutar%TYPE,
      pc_bolum_kodu        cbs_islem.amir_bolum_kodu%TYPE,
      pc_doviz_kod         cbs_islem.doviz_kod%TYPE,
      pn_musteri_numara    cbs_islem.musteri_numara%TYPE,
      pc_hesap_numara      cbs_islem.hesap_numara%TYPE,
      pc_kasa_kod          cbs_islem.kasa_kod%TYPE,
      ps_msrf_dvz          cbs_islem.doviz_kod%TYPE DEFAULT NULL)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;

      l_ucpointer    VARCHAR2 (3) := pkg_hata.getucpointer;
      l_delimiter    VARCHAR2 (3) := pkg_hata.getdelimiter;
      ln_i           NUMBER;
      ln_masraf      NUMBER;
      ln_bsmv        NUMBER;
      ls_odeyecek    VARCHAR2 (30);
      ls_msrf_dvz    VARCHAR2 (3);
      lb_yaratildi   BOOLEAN := FALSE;

    
      CURSOR cur_islem_masraf_3
      IS
         SELECT im.islem_kod, im.masraf_kod, mt.adi
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kod
                AND modul_tur_kod = pc_modul_tur_kod
                AND urun_tur_kod = pc_urun_tur_kod
                AND urun_sinif_kod = pc_urun_sinif_kod;

      CURSOR cur_islem_masraf_2
      IS
         SELECT im.islem_kod, im.masraf_kod, mt.adi
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kod
                AND modul_tur_kod = pc_modul_tur_kod
                AND urun_tur_kod = pc_urun_tur_kod
                AND urun_sinif_kod IS NULL;

      CURSOR cur_islem_masraf_1
      IS
         SELECT im.islem_kod, im.masraf_kod, mt.adi
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kod
                AND modul_tur_kod = pc_modul_tur_kod
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL;

      CURSOR cur_islem_masraf_0
      IS
         SELECT im.islem_kod, im.masraf_kod, mt.adi
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE     im.masraf_kod = mt.kodu
                AND im.islem_kod = pn_islem_kod
                AND modul_tur_kod IS NULL
                AND urun_tur_kod IS NULL
                AND urun_sinif_kod IS NULL;
   BEGIN
   
     log_at('swift 2.1', pn_islem_kod || '-' || pc_modul_tur_kod || '-' ||  pc_urun_tur_kod || '-' || pc_urun_sinif_kod);
      
      IF ps_msrf_dvz IS NULL
      THEN
         ls_msrf_dvz := pc_doviz_kod;
      ELSE
         ls_msrf_dvz := ps_msrf_dvz;
      END IF;

      ln_i := 1;
   
      FOR row_islem_masraf IN cur_islem_masraf_3
      LOOP
         masraf_hesapla (row_islem_masraf.masraf_kod,
                         pn_tutar,
                         pn_islem_kod,
                         pkg_baglam.rol_numara,
                         pn_musteri_numara,
                         pc_doviz_kod,
                         ln_masraf,
                         ln_bsmv,
                         ls_msrf_dvz,
                         pc_modul_tur_kod,
                         pc_urun_tur_kod,
                         pc_urun_sinif_kod,
                         pc_bolum_kodu,
                         pc_hesap_numara); --160407 sevalb bolum hesap eklendi
         --    if nvl(ln_masraf,0) >0 then
         ls_odeyecek :=
            pkg_masraf.default_odeyen (row_islem_masraf.masraf_kod);

         INSERT INTO cbs_masraf (islem_no,
                                 sira,
                                 masraf_kodu,
                                 adi,
                                 hesaplanan,
                                 alinan,
                                 bsmv,
                                 odeyecek,
                                 durum,
                                 dvz,
                                 masraf_alinacak_hesap_no)
              VALUES (pn_islem_no,
                      ln_i,
                      row_islem_masraf.masraf_kod,
                      row_islem_masraf.adi,
                      ln_masraf,
                      ln_masraf,
                      NVL (ln_bsmv, 0),
                      ls_odeyecek,
                      'INVALID',
                      ls_msrf_dvz,
                      pc_hesap_numara);

         
         ln_i := ln_i + 1;
      --    end if;
      --mutlu test    lb_yaratildi := true;
      END LOOP;
      IF NOT (lb_yaratildi)
      THEN
      
         FOR row_islem_masraf IN cur_islem_masraf_2
         LOOP
            masraf_hesapla (row_islem_masraf.masraf_kod,
                            pn_tutar,
                            pn_islem_kod,
                            pkg_baglam.rol_numara,
                            pn_musteri_numara,
                            pc_doviz_kod,
                            ln_masraf,
                            ln_bsmv,
                            ls_msrf_dvz,
                            pc_modul_tur_kod,
                            pc_urun_tur_kod,
                            pc_urun_sinif_kod,
                            pc_bolum_kodu,
                            pc_hesap_numara); --160407 sevalb bolum hesap eklendi
            --        if nvl(ln_masraf,0) >0 then
            ls_odeyecek :=
               pkg_masraf.default_odeyen (row_islem_masraf.masraf_kod);
            INSERT INTO cbs_masraf (islem_no,
                                    sira,
                                    masraf_kodu,
                                    adi,
                                    hesaplanan,
                                    alinan,
                                    bsmv,
                                    odeyecek,
                                    durum,
                                    dvz,
                                    masraf_alinacak_hesap_no)
                 VALUES (pn_islem_no,
                         ln_i,
                         row_islem_masraf.masraf_kod,
                         row_islem_masraf.adi,
                         ln_masraf,
                         ln_masraf,
                         NVL (ln_bsmv, 0),
                         ls_odeyecek,
                         'INVALID',
                         ls_msrf_dvz,
                         pc_hesap_numara);

            ln_i := ln_i + 1;
         --        end if;
         --mutlu test    lb_yaratildi := true;
         END LOOP;
      END IF;

      IF NOT (lb_yaratildi)
      THEN
         FOR row_islem_masraf IN cur_islem_masraf_1
         LOOP
            masraf_hesapla (row_islem_masraf.masraf_kod,
                            pn_tutar,
                            pn_islem_kod,
                            pkg_baglam.rol_numara,
                            pn_musteri_numara,
                            pc_doviz_kod,
                            ln_masraf,
                            ln_bsmv,
                            ls_msrf_dvz,
                            pc_modul_tur_kod,
                            pc_urun_tur_kod,
                            pc_urun_sinif_kod,
                            pc_bolum_kodu,
                            pc_hesap_numara); --160407 sevalb bolum hesap eklendi
            --        if nvl(ln_masraf,0) >0 then
            ls_odeyecek :=
               pkg_masraf.default_odeyen (row_islem_masraf.masraf_kod);

            INSERT INTO cbs_masraf (islem_no,
                                    sira,
                                    masraf_kodu,
                                    adi,
                                    hesaplanan,
                                    alinan,
                                    bsmv,
                                    odeyecek,
                                    durum,
                                    dvz,
                                    masraf_alinacak_hesap_no)
                 VALUES (pn_islem_no,
                         ln_i,
                         row_islem_masraf.masraf_kod,
                         row_islem_masraf.adi,
                         ln_masraf,
                         ln_masraf,
                         NVL (ln_bsmv, 0),
                         ls_odeyecek,
                         'INVALID',
                         ls_msrf_dvz,
                         pc_hesap_numara);

            ln_i := ln_i + 1;
         --        end if;
         --mutlu test    lb_yaratildi := true;
         END LOOP;
      END IF;
        
      IF NOT (lb_yaratildi)
      THEN
         FOR row_islem_masraf IN cur_islem_masraf_0
         LOOP
            masraf_hesapla (row_islem_masraf.masraf_kod,
                            pn_tutar,
                            pn_islem_kod,
                            pkg_baglam.rol_numara,
                            pn_musteri_numara,
                            pc_doviz_kod,
                            ln_masraf,
                            ln_bsmv,
                            ls_msrf_dvz,
                            pc_modul_tur_kod,
                            pc_urun_tur_kod,
                            pc_urun_sinif_kod,
                            pc_bolum_kodu,
                            pc_hesap_numara); --160407 sevalb bolum hesap eklendi
            --        if nvl(ln_masraf,0) >0 then
            ls_odeyecek :=
               pkg_masraf.default_odeyen (row_islem_masraf.masraf_kod);

            INSERT INTO cbs_masraf (islem_no,
                                    sira,
                                    masraf_kodu,
                                    adi,
                                    hesaplanan,
                                    alinan,
                                    bsmv,
                                    odeyecek,
                                    durum,
                                    dvz,
                                    masraf_alinacak_hesap_no)
                 VALUES (pn_islem_no,
                         ln_i,
                         row_islem_masraf.masraf_kod,
                         row_islem_masraf.adi,
                         ln_masraf,
                         ln_masraf,
                         NVL (ln_bsmv, 0),
                         ls_odeyecek,
                         'INVALID',
                         ls_msrf_dvz,
                         pc_hesap_numara);

            ln_i := ln_i + 1;
         --        end if;
         --mutlu test    lb_yaratildi := true;
         END LOOP;
         
      END IF;

      COMMIT;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION masraf_yaratilmis (
      pn_islem_no         IN NUMBER,
      pn_islem_kodu       IN NUMBER,
      pc_modul_tur_kod       cbs_islem.modul_tur_kod%TYPE,
      pc_urun_tur_kod        cbs_islem.urun_tur_kod%TYPE,
      pc_urun_sinif_kod      cbs_islem.urun_sinif_kod%TYPE)
      RETURN VARCHAR2
   IS
      ln_cnt   NUMBER := 0;
   BEGIN
      /*** tdl                                                        ***/
      /*** islem parametreleri degistiginde yeniden hesaplanmali ***/

      IF masraf_yaratilmali (pn_islem_kodu,
                             pc_modul_tur_kod,
                             pc_urun_tur_kod,
                             pc_urun_sinif_kod)
      THEN
         SELECT COUNT (*)
           INTO ln_cnt
           FROM cbs_masraf
          WHERE islem_no = pn_islem_no;

         IF ln_cnt > 0
         THEN
            RETURN 'E';                                           --is created
         ELSE
            RETURN 'H';                                       --is not created
         END IF;
      ELSE
         RETURN 'N';                                       --no need to create
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_update_et (pn_islem_no    NUMBER,
                               pn_sira        NUMBER,
                                
                               pn_alinan      NUMBER,
                               ps_odeyecek    VARCHAR2,
                               pn_bsmv        NUMBER)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      UPDATE cbs_masraf
         SET ( alinan, bsmv, odeyecek) =
                (SELECT pn_alinan, pn_bsmv, ps_odeyecek FROM DUAL)
       WHERE islem_no = pn_islem_no AND sira = pn_sira;

      COMMIT;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   
   procedure masraf_update_data(pn_islem_no number, pn_sira number,pn_hesaplanan number, pn_alinan number,
                             ps_odeyecek varchar2, pn_bsmv number) is-- GulkaiyrK cbs-52

    pragma autonomous_transaction;

  begin
      update cbs_masraf
         set (  hesaplanan, alinan, bsmv, odeyecek)
           = (select pn_hesaplanan, pn_alinan, pn_bsmv, ps_odeyecek from dual)
       where islem_no = pn_islem_no
         and sira = pn_sira;

      commit;
  end;
 /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE validate_masraf (pn_islem_no NUMBER)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      UPDATE cbs_masraf
         SET durum = 'VALID'
       WHERE islem_no = pn_islem_no;

      COMMIT;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION masraf_can_be_changed (pn_islem_no NUMBER)
      RETURN VARCHAR2
   IS
      ls_drm   VARCHAR2 (10);
      ln_tmp   NUMBER;
   BEGIN
      SELECT DISTINCT durum
        INTO ls_drm
        FROM cbs_masraf
       WHERE islem_no = pn_islem_no;

      IF ls_drm = 'VALID'
      THEN
         BEGIN                                     -- check if islem is posted
            SELECT 1
              INTO ln_tmp
              FROM cbs_islem
             WHERE numara = pn_islem_no;

            RETURN 'NO_CHANGE';                       --it is posted no change
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN                        --islem is not posted allow for change
               RETURN 'CHANGE_ALLOW';
         END;
      ELSE
         RETURN 'CHANGE_ALLOW';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'CHANGE_ALLOW';
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION toplam_masraf (pn_islem_no NUMBER)
      RETURN NUMBER
   IS
      ln_temp   NUMBER;
   BEGIN
      SELECT SUM (alinan + bsmv)
        INTO ln_temp
        FROM cbs_masraf
       WHERE islem_no = pn_islem_no AND durum = 'VALID';

      RETURN ln_temp;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_toplamlari (pn_islem_no   IN     NUMBER,
                                pn_masraf        OUT NUMBER,
                                pn_bsmv          OUT NUMBER)
   IS
      ln_mas    NUMBER;
      ln_bsmv   NUMBER;
   BEGIN
      SELECT SUM (alinan), SUM (bsmv)
        INTO ln_mas, ln_bsmv
        FROM cbs_masraf
       WHERE islem_no = pn_islem_no AND durum = 'VALID';

      pn_masraf := ln_mas;
      pn_bsmv := ln_bsmv;
   EXCEPTION
      WHEN OTHERS
      THEN
         pn_masraf := 0;
         pn_bsmv := 0;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE secimlik_masraf_yarat (
      pn_islem_no          NUMBER,
      pn_islem_kod         cbs_islem.islem_kod%TYPE,
      pc_modul_tur_kod     cbs_islem.modul_tur_kod%TYPE,
      pc_urun_tur_kod      cbs_islem.urun_tur_kod%TYPE,
      pc_urun_sinif_kod    cbs_islem.urun_sinif_kod%TYPE,
      pn_tutar             cbs_islem.tutar%TYPE,
      pc_bolum_kodu        cbs_islem.amir_bolum_kodu%TYPE,
      pc_doviz_kod         cbs_islem.doviz_kod%TYPE,
      pn_musteri_numara    cbs_islem.musteri_numara%TYPE,
      pc_hesap_numara      cbs_islem.hesap_numara%TYPE,
      pc_kasa_kod          cbs_islem.kasa_kod%TYPE,
      ps_referans          VARCHAR2)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;

      l_ucpointer   VARCHAR2 (3) := pkg_hata.getucpointer;
      l_delimiter   VARCHAR2 (3) := pkg_hata.getdelimiter;
      ln_masraf     NUMBER;
      ln_bsmv       NUMBER;
      ls_odeyecek   VARCHAR2 (30);

      CURSOR cur_islem_masraf
      IS
         SELECT im.islem_kod, im.masraf_kod, mt.adi
           FROM cbs_islem_masraf_tanim im, cbs_masraf_tur mt
          WHERE im.masraf_kod = mt.kodu AND im.islem_kod = pn_islem_kod;
   BEGIN
      DELETE FROM cbs_masraf_secimlik
            WHERE islem_no = pn_islem_no;

      FOR row_islem_masraf IN cur_islem_masraf
      LOOP
         masraf_hesapla (row_islem_masraf.masraf_kod,
                         pn_tutar,
                         pn_islem_kod,
                         pkg_baglam.rol_numara,
                         pn_musteri_numara,
                         pc_doviz_kod,
                         ln_masraf,
                         ln_bsmv,
                         pc_doviz_kod,
                         pc_modul_tur_kod,
                         pc_urun_tur_kod,
                         pc_urun_sinif_kod,
                         pc_bolum_kodu,
                         pc_hesap_numara); --160407 sevalb bolum hesap eklendi

         ln_masraf := 5; --masraf derdiyle ugrassmamak icin kafadan 5 atiyorum, hs

         --    if nvl(ln_masraf,0) >0 then
         ls_odeyecek :=
            pkg_masraf.default_odeyen (row_islem_masraf.masraf_kod);


         INSERT INTO cbs_masraf_secimlik (islem_no,
                                          sira,
                                          masraf_kodu,
                                          adi,
                                          hesaplanan,
                                          alinan,
                                          bsmv,
                                          odeyecek,
                                          durum,
                                          dvz)
              VALUES (pn_islem_no,
                      pkg_genel.genel_kod_al ('SABIT_MASRAF'),
                      row_islem_masraf.masraf_kod,
                      row_islem_masraf.adi,
                      ln_masraf,
                      ln_masraf,
                      ln_bsmv,
                      ls_odeyecek,
                      'VALID',
                      pc_doviz_kod);
      --    end if;
      END LOOP;

      COMMIT;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION bsmv_hesapla (ps_masraf_kodu    cbs_masraf_tur.kodu%TYPE,
                          pn_tutar          NUMBER)
      RETURN NUMBER
   IS
      lc_bsmv_al   cbs_masraf_tur.bsmv_alinir%TYPE;
      ln_bsmv      NUMBER;
   BEGIN
      BEGIN
         SELECT bsmv_alinir
           INTO lc_bsmv_al
           FROM cbs_masraf_tur
          WHERE kodu = ps_masraf_kodu;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20100,
                  pkg_hata.getucpointer
               || '203'
               || pkg_hata.getdelimiter
               || SQLERRM
               || pkg_hata.getucpointer);
      END;

      IF lc_bsmv_al = 'E'
      THEN
         ln_bsmv := bsmv_hesapla (pn_tutar);
      ELSE
         ln_bsmv := 0;
      END IF;

      RETURN ln_bsmv;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE iptal_icin_log_at (pn_islem_no        NUMBER,
                                ps_referans        VARCHAR2,
                                pn_sira_no         NUMBER,
                                ps_masraf_kodu     VARCHAR2,
                                pn_tahsil_tutar    NUMBER,
                                pn_vs_no           NUMBER DEFAULT 0)
   IS
   BEGIN
      INSERT INTO cbs_masraf_ith_ihr_ipt_log (islem_no,
                                              referans,
                                              sira_no,
                                              masraf_kodu,
                                              tahsil_edilen,
                                              vs_no,
                                              banka_tarihi)
           VALUES (pn_islem_no,
                   ps_referans,
                   pn_sira_no,
                   ps_masraf_kodu,
                   pn_tahsil_tutar,
                   pn_vs_no,
                   pkg_muhasebe.banka_tarihi_bul);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE iptal_icin_log_at_taksit (
      pn_islem_no              NUMBER,
      ps_referans              VARCHAR2,
      pn_taksit_no             NUMBER,
      pd_taksit_odeme_tarih    DATE,
      pn_taksit_tutari         NUMBER,
      ps_masraf_kodu           VARCHAR2,
      pn_vs_no                 NUMBER DEFAULT 0)
   IS
   BEGIN
      INSERT INTO cbs_masraf_taksit_iptal_log (islem_no,
                                               referans,
                                               taksit_no,
                                               onceki_odeme_tarih,
                                               tahsil_edilen,
                                               masraf_kodu,
                                               vs_no,
                                               banka_tarihi)
           VALUES (pn_islem_no,
                   ps_referans,
                   pn_taksit_no,
                   pd_taksit_odeme_tarih,
                   pn_taksit_tutari,
                   ps_masraf_kodu,
                   pn_vs_no,
                   pkg_muhasebe.banka_tarihi_bul);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_guncelleme_kontrolu (pn_islem_no          NUMBER,
                                         ps_block             VARCHAR2,
                                         ps_rowid             VARCHAR2,
                                         ps_column            VARCHAR2,
                                         pd_column            VARCHAR2,
                                         ps_oldvalue   IN OUT VARCHAR2)
   IS
      guncellenmis_exception   EXCEPTION;
      ln_retval                NUMBER := 0;
      ls_sqlstr                VARCHAR2 (2000);
      ls_sql_template          VARCHAR2 (2000);
      ls_source_table          VARCHAR2 (30);
      ls_dest_table            VARCHAR2 (30);
   BEGIN
      IF ps_block = 'CBS_MASRAF_ITH_IHR_ISL'
      THEN
         --todo 1: set the source and destination table names
         ls_source_table := 'CBS_MASRAF_ITH_IHR_ISL';
         ls_dest_table := 'CBS_MASRAF_ITH_IHR';

         IF ps_column <> 'TX_NO'
         THEN
            --todo 2: set the primary key count (default 1)
            ls_sql_template := pkg_guncel.differencetemplatesinglerecord (2);
            --todo 3: do not alter until next todo :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --todo 4: set the primary keys bu suffixing the counts to destination_pk/source_pk
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'REFERANS');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK2', 'SIRA_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REFERANS');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK2', 'SIRA_NO');

            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      END IF;

      IF ps_block = 'CBS_MASRAF_TAKSIT_ISLEM'
      THEN
         --todo 1: set the source and destination table names
         ls_source_table := 'CBS_MASRAF_TAKSIT_ISLEM';
         ls_dest_table := 'CBS_MASRAF_TAKSIT';

         IF ps_column <> 'TX_NO'
         THEN
            --todo 2: set the primary key count (default 1)
            ls_sql_template := pkg_guncel.differencetemplatemultirecord (2);
            --todo 3: do not alter until next todo :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --todo 4: set the primary keys bu suffixing the counts to destination_pk/source_pk
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'REFERANS');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK2', 'TAKSIT_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REFERANS');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK2', 'TAKSIT_NO');

            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      END IF;

      IF ps_block = 'CBS_SABIT_MASRAF'
      THEN
         --todo 1: set the source and destination table names
         ls_source_table := 'CBS_MASRAF_ITH_IHR_ISL';
         ls_dest_table := 'CBS_MASRAF_ITH_IHR';

         IF ps_column <> 'TX_NO'
         THEN
            --todo 2: set the primary key count (default 1)
            ls_sql_template := pkg_guncel.differencetemplatemultirecord (2);
            --todo 3: do not alter until next todo :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --todo 4: set the primary keys bu suffixing the counts to destination_pk/source_pk
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'REFERANS');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK2', 'SIRA_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REFERANS');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK2', 'SIRA_NO');

            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE onay_sonrasi (pn_islem_no    NUMBER,
                           ps_ref         VARCHAR2,
                           pn_vs_no       NUMBER,
                           ps_source      VARCHAR2,
                           ps_masraf      VARCHAR2)
   IS
      CURSOR c_01
      IS
         SELECT a.masraf_kodu,
                a.sira_no,
                a.referans,
                NVL (a.tutar, 0) eski_tutar,
                NVL (b.tutar, 0) yeni_tutar,
                NVL (b.tahsil_edilemeyen, 0) tahsil_edilemeyen
           FROM cbs_masraf_ith_ihr a, cbs_masraf_ith_ihr_isl b
          WHERE     b.islem_no = pn_islem_no
                AND b.komisyon_tipi = 'CONSTANT'        --not like 'D?NEMSEL%'
                AND a.referans = b.referans
                AND a.vs_no = b.vs_no
                AND b.vs_no = pn_vs_no       --source ?nemli de?ili sa?lar....
                AND a.masraf_kodu = b.masraf_kodu
                AND a.sira_no = b.sira_no
                AND a.tutar <> b.tutar;

      r_01   c_01%ROWTYPE;
   BEGIN
      UPDATE cbs_masraf_ith_ihr_isl
         SET referans = ps_ref,
             durum = 'VALID',
             vs_no = NVL (pn_vs_no, 0),
             source = ps_source
       WHERE islem_no = pn_islem_no;

      --taksitli olmayan masraflar?n tahsil edilen ve edilmeyen tutarlar? d?zenlenir.
      UPDATE cbs_masraf_ith_ihr_isl b
         SET tahsil_edilemeyen =
                  DECODE (komisyon_tipi,
                          'CONSTANT', tutar,
                          'TUTAR', tutar,
                          hesaplanan)
                - NVL (tahsil_toplam, 0),
             tahsil_toplam = NVL (tahsil_toplam, 0)
       WHERE islem_no = pn_islem_no AND komisyon_tipi NOT LIKE 'DONEMSEL%';

      --if new payment plan is generated
      IF ps_masraf IS NOT NULL
      THEN
         UPDATE cbs_masraf_taksit_islem
            SET referans = ps_ref,
                vs_no = NVL (pn_vs_no, 0),
                masraf_kodu = ps_masraf      --sadece bu olu?turulabilir......
          WHERE islem_no = pn_islem_no;
      END IF;

      --set up ollected and uncollected amounts for charges in installments
      UPDATE cbs_masraf_ith_ihr_isl b
         SET (tahsil_edilemeyen, tahsil_toplam) =
                (SELECT   SUM (NVL (taksit_tutari, 0))
                        - SUM (NVL (odenen_tutar, 0)),
                        NVL (tahsil_toplam, 0) --+ sum(nvl(odenen_tutar,0))
                   FROM cbs_masraf_taksit_islem a
                  WHERE     islem_no = pn_islem_no
                        AND a.masraf_kodu = b.masraf_kodu
                        AND a.referans = b.referans
                        AND a.vs_no = b.vs_no)
       WHERE islem_no = pn_islem_no AND komisyon_tipi LIKE 'DONEMSEL%';
   END;

   /*------------------------------------------------------------------------------------------------------*/
   PROCEDURE reddetme_sonrasi (pn_islem_no NUMBER, ps_ref VARCHAR2)
   IS
   BEGIN
      UPDATE cbs_masraf_ith_ihr_isl
         SET durum = 'RED'
       WHERE islem_no = pn_islem_no;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE iptal_onay_sonrasi_odeme (pn_islem_no NUMBER, ps_ref VARCHAR2)
   IS                                                  -- islem iptal edilemez
      CURSOR c_01
      IS
         SELECT referans,
                tahsil_edilen,
                masraf_kodu,
                sira_no,
                vs_no
           FROM cbs_masraf_ith_ihr_ipt_log
          WHERE islem_no = pn_islem_no;

      r_01   c_01%ROWTYPE;

      CURSOR c_02
      IS
         SELECT referans,
                taksit_no,
                onceki_odeme_tarih,
                tahsil_edilen,
                vs_no,
                masraf_kodu
           FROM cbs_masraf_taksit_iptal_log
          WHERE islem_no = pn_islem_no;

      r_02   c_02%ROWTYPE;
   BEGIN
      --bu masraf?n yaratt??? ?deme geri al?n?r.......
      OPEN c_01;

      LOOP
         FETCH c_01 INTO r_01;

         EXIT WHEN c_01%NOTFOUND;

         UPDATE cbs_masraf_ith_ihr
            SET tahsil_toplam = NVL (tahsil_toplam, 0) - r_01.tahsil_edilen,
                tahsil_edilemeyen =
                   NVL (tahsil_edilemeyen, 0) + r_01.tahsil_edilen
          WHERE     referans = r_01.referans
                AND masraf_kodu = r_01.masraf_kodu
                AND sira_no = r_01.sira_no;
      END LOOP;

      CLOSE c_01;

      --taksit ?demesi geri al?n?r
      OPEN c_02;

      LOOP
         FETCH c_02 INTO r_02;

         EXIT WHEN c_02%NOTFOUND;

         UPDATE cbs_masraf_taksit
            SET taksit_odeme_tarih = r_02.onceki_odeme_tarih,
                odenen_tutar = odenen_tutar - r_02.tahsil_edilen
          WHERE     referans = r_02.referans
                AND masraf_kodu = r_02.masraf_kodu
                AND taksit_no = r_02.taksit_no;
      END LOOP;

      CLOSE c_02;

      --masraf logu iptal edilir....
      UPDATE cbs_masraf_ith_ihr_ipt_log
         SET durum = 'IPTAL'
       WHERE islem_no = pn_islem_no;

      UPDATE cbs_masraf_ith_ihr_isl
         SET durum = 'IPTAL'
       WHERE islem_no = pn_islem_no;

      UPDATE cbs_masraf_ith_ihr_gecici
         SET status = 'I'
       WHERE yaratan_tx_no = pn_islem_no;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE iptal_onay_sonrasi_grs_guncel (pn_islem_no    NUMBER,
                                            ps_ref         VARCHAR2,
                                            pn_vs_no       NUMBER)
   IS
   BEGIN
      --status iptal konumuna getirilir ve tahsil edilen vs. oldu?u gibi b?rak?l?r...
      UPDATE cbs_masraf_ith_ihr
         SET durum = 'IPTAL'
       WHERE     referans = ps_ref
             AND vs_no = NVL (pn_vs_no, 0)
             AND sira_no IN (SELECT sira_no
                               FROM cbs_masraf_ith_ihr_isl
                              WHERE islem_no = pn_islem_no);

      --masraf logu iptal edilir....
      UPDATE cbs_masraf_ith_ihr_ipt_log
         SET durum = 'IPTAL'
       WHERE islem_no = pn_islem_no;

      UPDATE cbs_masraf_ith_ihr_isl
         SET durum = 'IPTAL'
       WHERE islem_no = pn_islem_no;

      UPDATE cbs_masraf_ith_ihr_gecici
         SET status = 'I'
       WHERE yaratan_tx_no = pn_islem_no;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE muhasebe_sonrasi_odeme (pn_islem_no NUMBER, ps_ref VARCHAR2)
   IS
      CURSOR cur_msrf
      IS
         SELECT referans,
                masraf_kodu,
                tahsil_toplam,
                tahsil_edilemeyen,
                durum,
                sira_no,
                vs_no
           FROM cbs_masraf_ith_ihr_isl b
          WHERE islem_no = pn_islem_no;

      row_msrf   cur_msrf%ROWTYPE;

      CURSOR cur_taks
      IS
         SELECT referans,
                taksit_no,
                taksit_odeme_tarih,
                odenen_tutar,
                bsmv,
                masraf_kodu,
                vs_no
           FROM cbs_masraf_taksit_islem b
          WHERE islem_no = pn_islem_no;

      row_taks   cur_taks%ROWTYPE;
   BEGIN
      /* burada de?i?en masraf itemlar? i?in update ge?ilir...... */
      OPEN cur_msrf;

      LOOP
         FETCH cur_msrf INTO row_msrf;

         EXIT WHEN cur_msrf%NOTFOUND;

         UPDATE cbs_masraf_ith_ihr
            SET tahsil_toplam = row_msrf.tahsil_toplam,
                tahsil_edilemeyen = row_msrf.tahsil_edilemeyen,
                durum = row_msrf.durum
          WHERE     referans = ps_ref
                AND masraf_kodu = row_msrf.masraf_kodu
                AND sira_no = row_msrf.sira_no;
      END LOOP;

      CLOSE cur_msrf;

      OPEN cur_taks;

      LOOP
         FETCH cur_taks INTO row_taks;

         EXIT WHEN cur_taks%NOTFOUND;

         UPDATE cbs_masraf_taksit
            SET taksit_odeme_tarih = row_taks.taksit_odeme_tarih,
                odenen_tutar = row_taks.odenen_tutar,
                bsmv = row_taks.bsmv
          WHERE     referans = ps_ref
                AND masraf_kodu = row_taks.masraf_kodu
                AND vs_no = row_taks.vs_no
                AND taksit_no = row_taks.taksit_no;
      END LOOP;

      CLOSE cur_taks;

      /* yeni masraf tan?mlanm??sa onlarda eklenir...... */
      INSERT INTO cbs_masraf_ith_ihr (referans,
                                      sira_no,
                                      masraf_kodu,
                                      adi,
                                      dvz,
                                      komisyon_tipi,
                                      tahsil_toplam,
                                      tahsil_edilemeyen,
                                      odeyecek,
                                      oran,
                                      tutar,
                                      devre_gun_sayisi,
                                      taksit_sayisi,
                                      taksit_bas_tarih,
                                      taksit_bitis_tarih,
                                      hesaplanan,
                                      bsmv,
                                      durum,
                                      vs_no,
                                      source,
                                      yillik_oran,
                                      yil_donem_sayisi)
         (SELECT ps_ref,
                 sira_no,
                 a.masraf_kodu,
                 a.adi,
                 a.dvz,
                 a.komisyon_tipi,
                 a.tahsil_toplam,
                 a.tahsil_edilemeyen,
                 a.odeyecek,
                 a.oran,
                 a.tutar,
                 a.devre_gun_sayisi,
                 a.taksit_sayisi,
                 a.taksit_bas_tarih,
                 a.taksit_bitis_tarih,
                 a.hesaplanan,
                 a.bsmv,
                 a.durum,
                 a.vs_no,
                 a.source,
                 a.yillik_oran,
                 a.yil_donem_sayisi
            FROM cbs_masraf_ith_ihr_isl a
           WHERE     a.islem_no = pn_islem_no
                 AND NOT EXISTS
                            (SELECT 1
                               FROM cbs_masraf_ith_ihr b
                              WHERE     b.referans = a.referans
                                    AND b.masraf_kodu = a.masraf_kodu
                                    AND b.sira_no = a.sira_no));
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE muhasebe_sonrasi_grs_guncel (pn_islem_no    NUMBER,
                                          ps_ref         VARCHAR2,
                                          pn_vs_no       NUMBER)
   IS
   BEGIN
      DELETE FROM cbs_masraf_taksit a
            WHERE     referans = ps_ref
                  AND vs_no = NVL (pn_vs_no, 0)
                  AND EXISTS
                         (SELECT 1
                            FROM cbs_masraf_taksit_islem b
                           WHERE     referans = ps_ref
                                 AND islem_no = pn_islem_no
                                 AND b.masraf_kodu = a.masraf_kodu --b.taksit_no = a.taksit_no
                                 AND b.vs_no = NVL (pn_vs_no, 0));

      -- sadece 1 masraf taksitli olabilir        and b.masraf_kodu = a.masraf_kodu

      DELETE FROM cbs_masraf_ith_ihr a
            WHERE     referans = ps_ref
                  AND vs_no = NVL (pn_vs_no, 0)
                  AND EXISTS
                         (SELECT 1
                            FROM cbs_masraf_ith_ihr_isl b
                           WHERE     referans = ps_ref
                                 AND islem_no = pn_islem_no
                                 AND b.masraf_kodu = a.masraf_kodu
                                 AND b.sira_no = a.sira_no
                                 AND b.vs_no = NVL (pn_vs_no, 0));

      INSERT INTO cbs_masraf_ith_ihr (referans,
                                      sira_no,
                                      masraf_kodu,
                                      adi,
                                      dvz,
                                      komisyon_tipi,
                                      tahsil_toplam,
                                      tahsil_edilemeyen,
                                      odeyecek,
                                      oran,
                                      tutar,
                                      devre_gun_sayisi,
                                      taksit_sayisi,
                                      taksit_bas_tarih,
                                      taksit_bitis_tarih,
                                      hesaplanan,
                                      bsmv,
                                      durum,
                                      vs_no,
                                      source,
                                      yillik_oran,
                                      yil_donem_sayisi)
         (SELECT ps_ref,
                 sira_no,
                 masraf_kodu,
                 adi,
                 dvz,
                 komisyon_tipi,
                 tahsil_toplam,
                 tahsil_edilemeyen,
                 odeyecek,
                 oran,
                 tutar,
                 devre_gun_sayisi,
                 taksit_sayisi,
                 taksit_bas_tarih,
                 taksit_bitis_tarih,
                 hesaplanan,
                 bsmv,
                 durum,
                 vs_no,
                 source,
                 yillik_oran,
                 yil_donem_sayisi
            FROM cbs_masraf_ith_ihr_isl
           WHERE islem_no = pn_islem_no);

      INSERT INTO cbs_masraf_taksit (referans,
                                     taksit_no,
                                     taksit_tarihi,
                                     taksit_tutari,
                                     taksit_odeme_tarih,
                                     odenen_tutar,
                                     bsmv,
                                     masraf_kodu,
                                     vs_no)
         (SELECT referans,
                 taksit_no,
                 taksit_tarihi,
                 taksit_tutari,
                 taksit_odeme_tarih,
                 odenen_tutar,
                 bsmv,
                 masraf_kodu,
                 vs_no
            FROM cbs_masraf_taksit_islem
           WHERE islem_no = pn_islem_no);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION min_masraf_al (ps_masraf_kodu VARCHAR2, ps_dvz VARCHAR2)
      RETURN NUMBER
   IS
      CURSOR c_0
      IS
         SELECT *
           FROM cbs_masraf_tur
          WHERE     TRUNC (SYSDATE) BETWEEN NVL (start_date, TRUNC (SYSDATE))
                                        AND NVL (end_date, TRUNC (SYSDATE))
                AND kodu = ps_masraf_kodu;

      r_0            c_0%ROWTYPE;
      ln_min_tutar   NUMBER;
   BEGIN
      OPEN c_0;

      FETCH c_0 INTO r_0;

      IF c_0%NOTFOUND
      THEN
         CLOSE c_0;

         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '202'
            || pkg_hata.getdelimiter
            || SQLERRM
            || pkg_hata.getucpointer);
      END IF;

      CLOSE c_0;

      ln_min_tutar := r_0.min_tutar;

      IF r_0.dvz <> ps_dvz
      THEN           --farkl? cins doviz i?in tan?mlanm?? i?lem dovizine ?evir
         ln_min_tutar :=
            pkg_kur.doviz_doviz_karsilik (r_0.dvz,
                                          ps_dvz,
                                          NULL,
                                          ln_min_tutar,
                                          1,
                                          NULL,
                                          NULL,
                                          'N',
                                          'A');
      END IF;

      RETURN ln_min_tutar;
   END;

   /* --------------------------------------------------------------------------------------------------- */

   FUNCTION referanstan_musteri_no_al (ps_referans VARCHAR2)
      RETURN NUMBER
   IS
      ls_referans   VARCHAR2 (16);
   BEGIN
      SELECT DISTINCT (musteri_no)
        INTO ls_referans
        FROM cbs_vw_masraf
       WHERE referans = ps_referans;

      RETURN ls_referans;
   END;

   /* --------------------------------------------------------------------------------------------------- */

   FUNCTION masraf_adi_al (ps_masraf_kodu VARCHAR2)
      RETURN VARCHAR2
   IS
      ls_masraf_kodu   VARCHAR2 (50);
   BEGIN
      SELECT adi
        INTO ls_masraf_kodu
        FROM cbs_masraf_tur
       WHERE kodu = ps_masraf_kodu;

      RETURN ls_masraf_kodu;
   END;

   /* --------------------------------------------------------------------------------------------------- */

   PROCEDURE islem_komisyon_oran_tutar_al (pn_islem_no               NUMBER,
                                           pn_oran               OUT NUMBER,
                                           pn_komisyon_toplami   OUT NUMBER)
   IS
   BEGIN
      SELECT NVL (oran, 0),
             NVL (tahsil_toplam, 0) + NVL (tahsil_edilemeyen, 0)
        INTO pn_oran, pn_komisyon_toplami
        FROM cbs_masraf_ith_ihr
       WHERE referans = (SELECT referans
                           FROM cbs_tm_hg_acilis_islem
                          WHERE tx_no = pn_islem_no);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         pn_oran := 0;
         pn_komisyon_toplami := 0;
   END;

   /* --------------------------------------------------------------------------------------------------- */

   FUNCTION masraf_girilen_tutar_al (
      pn_islem_kodu   IN NUMBER,
      ps_masraf_kod   IN cbs_masraf_tur.kodu%TYPE)
      RETURN NUMBER
   IS
      CURSOR cur_masraf
      IS
         SELECT alinan
           FROM cbs_masraf
          WHERE islem_no = pn_islem_kodu AND masraf_kodu = ps_masraf_kod;

      ls_alinan   cbs_masraf.alinan%TYPE;
   BEGIN
      OPEN cur_masraf;

      FETCH cur_masraf INTO ls_alinan;

      IF cur_masraf%NOTFOUND
      THEN
         CLOSE cur_masraf;

         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '2003' || pkg_hata.getucpointer);
      END IF;

      CLOSE cur_masraf;

      RETURN (ls_alinan);
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE masraf_koduna_dkgrup_dk_aktar (
      ps_masraf_kodu    cbs_masraf_dkgrup_dk.masraf_kodu%TYPE)
   IS
   BEGIN
      INSERT INTO cbs_masraf_dkgrup_dk (masraf_kodu, dk_grup_kodu)
         SELECT ps_masraf_kodu, dk_grup_kodu
           FROM cbs_dk_grup_kodlari
          WHERE dk_grup_kodu NOT IN (SELECT dk_grup_kodu
                                       FROM cbs_masraf_dkgrup_dk
                                      WHERE masraf_kodu = ps_masraf_kodu);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION tum_masraf_dkgruplar_tanimlimi (
      ps_masraf_kodu    cbs_masraf_dkgrup_dk.masraf_kodu%TYPE)
      RETURN VARCHAR2
   IS
      count1   NUMBER;
      count2   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO count1
        FROM cbs_masraf_dkgrup_dk
       WHERE masraf_kodu = ps_masraf_kodu;

      SELECT COUNT (*) INTO count2 FROM cbs_dk_grup_kodlari;

      IF count1 <> count2
      THEN
         RETURN 'H';
      ELSE
         RETURN 'E';
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         NULL;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION masraf_girilmis_mi (
      pn_islem_no       NUMBER,
      ps_masraf_kodu    cbs_masraf_dkgrup_dk.masraf_kodu%TYPE)
      RETURN NUMBER
   IS
      ln_cnt   NUMBER := 0;
   BEGIN
      SELECT COUNT (*)
        INTO ln_cnt
        FROM cbs_masraf
       WHERE     cbs_masraf.islem_no = pn_islem_no
             AND cbs_masraf.masraf_kodu = ps_masraf_kodu;

      IF NVL (ln_cnt, 0) = 0
      THEN
         RETURN 0;
      ELSE
         RETURN 1;
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE gecici_gercek_icin_kaydet (
      pn_islem_no              NUMBER,
      ps_referans              VARCHAR2,
      ps_masraf_kodu           VARCHAR2,
      pn_vs_no                 NUMBER,
      pn_taksit_no             NUMBER,
      pd_taksit_odeme_tarih    DATE,
      pn_taksit_tutari         NUMBER,
      pn_hesap                 NUMBER,
      pd_vade                  DATE DEFAULT NULL,
      ps_sureli                VARCHAR2 DEFAULT 'E',
      ps_sube                  VARCHAR2 DEFAULT NULL,
      pn_musteri               NUMBER DEFAULT NULL,
      ps_vergi                 VARCHAR2 DEFAULT 'H')
   IS
      ld_gecici_tarih          DATE;
      ld_sonraki_donem_basi    DATE;
      ld_son_gecici_tarih      DATE;
      ld_gerceklesecek_tarih   DATE;
      ln_gerceklesecek_tutar   NUMBER;
      ls_sube                  VARCHAR2 (10);
      ln_musteri               NUMBER;
      ln_donem_sayi            NUMBER;
      ln_gerceklesen           NUMBER := 0;
      ln_gun_tutar             NUMBER;

      CURSOR c_0
      IS
         SELECT *
           FROM cbs_masraf_ith_ihr_isl
          WHERE islem_no = pn_islem_no AND masraf_kodu = ps_masraf_kodu;

      r_0                      c_0%ROWTYPE;

      CURSOR c_1
      IS
         SELECT *
           FROM cbs_masraf_taksit_islem
          WHERE     islem_no = pn_islem_no
                AND masraf_kodu = ps_masraf_kodu
                AND taksit_no = pn_taksit_no;

      r_1                      c_1%ROWTYPE;

      ls_dk_grup               CBS_MUSTERI.dk_grup_kod%TYPE;
      ls_dk                    VARCHAR2 (30);
   BEGIN
      OPEN c_0;

      FETCH c_0 INTO r_0;

      CLOSE c_0;

      OPEN c_1;

      FETCH c_1 INTO r_1;

      CLOSE c_1;

      --(ps_sureli=E) ve (komisyon tutar veya oran) ve (vade bo? olamaz)......

      --kac gune bolecegini bulamazsin !!!

      IF     (ps_sureli = 'E')
         AND (r_0.komisyon_tipi NOT LIKE 'DONEMSEL%')
         AND pd_vade IS NULL
      THEN
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '1404'
            || pkg_hata.getdelimiter
            || ps_referans
            || pkg_hata.getucpointer);
      END IF;

      ld_son_gecici_tarih := r_1.taksit_tarihi;

      IF r_0.komisyon_tipi IN ('DONEMSEL TUTAR', 'DONEMSEL ORAN')
      THEN
         ld_sonraki_donem_basi := r_1.taksit_tarihi + r_0.devre_gun_sayisi;
      ELSIF r_0.komisyon_tipi IN ('DONEMSEL YORAN', 'DONEMSEL YTUTA')
      THEN
         ld_sonraki_donem_basi :=
            ADD_MONTHS (r_1.taksit_tarihi, (12 / r_0.yil_donem_sayisi));
      ELSE
         ld_sonraki_donem_basi := pd_vade;
      END IF;

      IF ps_sube IS NULL
      THEN
         SELECT amir_bolum_kodu
           INTO ls_sube
           FROM cbs_islem
          WHERE numara = pn_islem_no;
      ELSE
         ls_sube := ps_sube;
      END IF;

      IF pn_musteri IS NULL
      THEN
         ln_musteri := pkg_hesap.hesaptanmusterinoal (pn_hesap);
      ELSE
         ln_musteri := pn_musteri;
      END IF;

      ls_dk_grup := pkg_musteri.sf_musteri_dk_grup_kod_al (ln_musteri);
      ls_dk := Pkg_Muhasebe.Komisyon_DK_Bul (ls_dk_grup, ps_masraf_kodu);

      IF Pkg_Muhasebe.DK_Varmi (ls_sube, ls_dk, pkg_genel.lc_al) = 'H'
      THEN
         Raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '698'
            || pkg_hata.getdelimiter
            || ls_sube
            || '-'
            || ls_dk
            || pkg_hata.getdelimiter
            || pkg_genel.lc_al
            || pkg_hata.getucpointer);
      END IF;

      IF ps_sureli = 'E'
      THEN
         IF TRUNC ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30) =
               ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30)
         THEN
            --tam bolunebiliyor
            ln_donem_sayi :=
               ROUND ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30);
         ELSE
            --tam bolunemiyor, kes ve 1 ekle
            ln_donem_sayi :=
                 TRUNC ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30)
               + 1;
         END IF;

         ln_gun_tutar :=
            ROUND (
                 pn_taksit_tutari
               / (ld_sonraki_donem_basi - ld_son_gecici_tarih),
               2);

         FOR j IN 1 .. ln_donem_sayi
         LOOP
            ld_gecici_tarih :=
               pkg_tarih.geri_is_gunu (r_1.taksit_tarihi + (j * 30) + 1);

            IF ld_gecici_tarih > ld_sonraki_donem_basi
            THEN
               ld_gecici_tarih := ld_sonraki_donem_basi;
            END IF;

            IF j = ln_donem_sayi
            THEN
               ln_gerceklesecek_tutar := pn_taksit_tutari - ln_gerceklesen;
            ELSE
               ln_gerceklesecek_tutar :=
                  ROUND (
                     ln_gun_tutar * (ld_gecici_tarih - ld_son_gecici_tarih));
               ln_gerceklesen := ln_gerceklesen + ln_gerceklesecek_tutar;
            END IF;

            ld_gerceklesecek_tarih := ld_gecici_tarih;

            IF ld_gerceklesecek_tarih < pkg_muhasebe.banka_tarihi_bul
            THEN
               --eger 30 gunden fazla gecikme yaptiysa ald??? gun gerce?e atmal?
               ld_gerceklesecek_tarih := pkg_muhasebe.banka_tarihi_bul;
            END IF;

            INSERT INTO cbs_masraf_ith_ihr_gecici (referans,
                                                   vs_no,
                                                   masraf_kodu,
                                                   taksit_no,
                                                   gecici_sira_no,
                                                   gerceklesecek_tarih,
                                                   gerceklesecek_tutar,
                                                   yaratan_tx_no,
                                                   status,
                                                   sube,
                                                   musteri_no,
                                                   doviz_kodu,
                                                   vergili_mi)
                 VALUES (ps_referans,
                         pn_vs_no,
                         ps_masraf_kodu,
                         pn_taksit_no,
                         j,
                         ld_gerceklesecek_tarih,
                         ln_gerceklesecek_tutar,
                         pn_islem_no,
                         'A',
                         ls_sube,
                         ln_musteri,
                         r_0.dvz,
                         ps_vergi);

            ld_son_gecici_tarih := ld_gecici_tarih;
         END LOOP;
      ELSE                --suresiz ise vade gonderilmiyor.. hepsini at?yoruz.
         INSERT INTO cbs_masraf_ith_ihr_gecici (referans,
                                                vs_no,
                                                masraf_kodu,
                                                taksit_no,
                                                gecici_sira_no,
                                                gerceklesecek_tarih,
                                                gerceklesecek_tutar,
                                                yaratan_tx_no,
                                                status,
                                                sube,
                                                musteri_no,
                                                doviz_kodu,
                                                vergili_mi)
                 VALUES (
                           ps_referans,
                           pn_vs_no,
                           ps_masraf_kodu,
                           pn_taksit_no,
                           1,
                           NVL (pd_taksit_odeme_tarih,
                                pkg_muhasebe.banka_tarihi_bul),
                           pn_taksit_tutari,
                           pn_islem_no,
                           'A',
                           ls_sube,
                           ln_musteri,
                           r_0.dvz,
                           ps_vergi);
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */
   FUNCTION Sf_Masraf_UrunUygunmu (
      ps_urun_tur_kod    cbs_hesap.urun_tur_kod%TYPE)
      RETURN VARCHAR2
   IS
      ls_uygun   VARCHAR2 (1) := 'H';
   BEGIN
      IF ps_urun_tur_kod IN ('CURRENT', 'DEMAND DEP', 'TRANSIT')
      THEN        -- CQ5507 BAHIANAB 29042016 ADDED NEW PRODUCT TYPE "TRANSIT"
         ls_uygun := 'E';
      ELSE
         ls_uygun := 'H';
      END IF;

      RETURN ls_uygun;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;

   /* --------------------------------------------------------------------------------------------------- */
   PROCEDURE gecici_gercek_icin_kaydet_eod (
      pn_yarat_tx              NUMBER,
      pn_sira_no               NUMBER,
      ps_referans              VARCHAR2,
      ps_masraf_kodu           VARCHAR2,
      pn_vs_no                 NUMBER,
      pn_taksit_no             NUMBER,
      pd_taksit_odeme_tarih    DATE,
      pn_taksit_tutari         NUMBER,
      pn_hesap                 NUMBER,
      pd_vade                  DATE DEFAULT NULL,
      ps_sureli                VARCHAR2 DEFAULT 'E',
      ps_sube                  VARCHAR2,
      pn_musteri               NUMBER DEFAULT NULL,
      ps_vergi                 VARCHAR2 DEFAULT 'H')
   IS
      ld_gecici_tarih          DATE;
      ld_sonraki_donem_basi    DATE;
      ld_son_gecici_tarih      DATE;
      ld_gerceklesecek_tarih   DATE;
      ln_gerceklesecek_tutar   NUMBER;
      ls_sube                  VARCHAR2 (10);
      ln_musteri               NUMBER;
      ln_donem_sayi            NUMBER;
      ln_gerceklesen           NUMBER := 0;
      ln_gun_tutar             NUMBER;

      CURSOR c_0
      IS
         SELECT *
           FROM cbs_masraf_ith_ihr
          WHERE     referans = ps_referans
                AND sira_no = pn_sira_no
                AND masraf_kodu = ps_masraf_kodu;

      r_0                      c_0%ROWTYPE;

      CURSOR c_1
      IS
         SELECT *
           FROM cbs_masraf_taksit
          WHERE     referans = ps_referans
                AND masraf_kodu = ps_masraf_kodu
                AND vs_no = NVL (pn_vs_no, 0)
                AND taksit_no = pn_taksit_no;

      r_1                      c_1%ROWTYPE;

      ls_dk_grup               CBS_MUSTERI.dk_grup_kod%TYPE;
      ls_dk                    VARCHAR2 (30);
   BEGIN
      OPEN c_0;

      FETCH c_0 INTO r_0;

      CLOSE c_0;

      OPEN c_1;

      FETCH c_1 INTO r_1;

      CLOSE c_1;

      --(ps_sureli=E) ve (komisyon tutar veya oran) ve (vade bo? olamaz)......

      --kac gune bolecegini bulamazsin !!!

      IF     (ps_sureli = 'E')
         AND (r_0.komisyon_tipi NOT LIKE 'DONEMSEL%')
         AND pd_vade IS NULL
      THEN
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '1404'
            || pkg_hata.getdelimiter
            || ps_referans
            || pkg_hata.getucpointer);
      END IF;

      ld_son_gecici_tarih := r_1.taksit_tarihi;

      IF r_0.komisyon_tipi IN ('DONEMSEL TUTAR', 'DONEMSEL ORAN')
      THEN
         ld_sonraki_donem_basi := r_1.taksit_tarihi + r_0.devre_gun_sayisi;
      ELSIF r_0.komisyon_tipi IN ('DONEMSEL YORAN', 'DONEMSEL YTUTA')
      THEN
         ld_sonraki_donem_basi :=
            ADD_MONTHS (r_1.taksit_tarihi, (12 / r_0.yil_donem_sayisi));
      ELSE
         ld_sonraki_donem_basi := pd_vade;
      END IF;

      ls_sube := ps_sube;

      IF pn_musteri IS NULL
      THEN
         ln_musteri := pkg_hesap.hesaptanmusterinoal (pn_hesap);
      ELSE
         ln_musteri := pn_musteri;
      END IF;

      ls_dk_grup := pkg_musteri.sf_musteri_dk_grup_kod_al (ln_musteri);
      ls_dk := Pkg_Muhasebe.Komisyon_DK_Bul (ls_dk_grup, ps_masraf_kodu);

      IF Pkg_Muhasebe.DK_Varmi (ls_sube, ls_dk, pkg_genel.lc_al) = 'H'
      THEN
         Raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '698'
            || pkg_hata.getdelimiter
            || ls_sube
            || '-'
            || ls_dk
            || pkg_hata.getdelimiter
            || pkg_genel.lc_al
            || pkg_hata.getucpointer);
      END IF;

      IF ps_sureli = 'E'
      THEN
         IF TRUNC ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30) =
               ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30)
         THEN
            --tam bolunebiliyor
            ln_donem_sayi :=
               ROUND ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30);
         ELSE
            --tam bolunemiyor, kes ve 1 ekle
            ln_donem_sayi :=
                 TRUNC ( (ld_sonraki_donem_basi - ld_son_gecici_tarih) / 30)
               + 1;
         END IF;

         ln_gun_tutar :=
            ROUND (
                 pn_taksit_tutari
               / (ld_sonraki_donem_basi - ld_son_gecici_tarih),
               2);

         FOR j IN 1 .. ln_donem_sayi
         LOOP
            ld_gecici_tarih :=
               pkg_tarih.geri_is_gunu (r_1.taksit_tarihi + (j * 30) + 1);

            IF ld_gecici_tarih > ld_sonraki_donem_basi
            THEN
               ld_gecici_tarih := ld_sonraki_donem_basi;
            END IF;

            IF j = ln_donem_sayi
            THEN
               ln_gerceklesecek_tutar := pn_taksit_tutari - ln_gerceklesen;
            ELSE
               ln_gerceklesecek_tutar :=
                  ROUND (
                     ln_gun_tutar * (ld_gecici_tarih - ld_son_gecici_tarih));
               ln_gerceklesen := ln_gerceklesen + ln_gerceklesecek_tutar;
            END IF;

            ld_gerceklesecek_tarih := ld_gecici_tarih;

            IF ld_gerceklesecek_tarih < pkg_muhasebe.banka_tarihi_bul
            THEN
               --eger 30 gunden fazla gecikme yaptiysa ald??? gun gerce?e atmal?
               ld_gerceklesecek_tarih := pkg_muhasebe.banka_tarihi_bul;
            END IF;

            INSERT INTO cbs_masraf_ith_ihr_gecici (referans,
                                                   vs_no,
                                                   masraf_kodu,
                                                   taksit_no,
                                                   gecici_sira_no,
                                                   gerceklesecek_tarih,
                                                   gerceklesecek_tutar,
                                                   yaratan_tx_no,
                                                   status,
                                                   sube,
                                                   musteri_no,
                                                   doviz_kodu,
                                                   vergili_mi)
                 VALUES (ps_referans,
                         pn_vs_no,
                         ps_masraf_kodu,
                         pn_taksit_no,
                         j,
                         ld_gerceklesecek_tarih,
                         ln_gerceklesecek_tutar,
                         pn_yarat_tx,
                         'A',
                         ls_sube,
                         ln_musteri,
                         r_0.dvz,
                         ps_vergi);

            ld_son_gecici_tarih := ld_gecici_tarih;
         END LOOP;
      ELSE                --suresiz ise vade gonderilmiyor.. hepsini at?yoruz.
         INSERT INTO cbs_masraf_ith_ihr_gecici (referans,
                                                vs_no,
                                                masraf_kodu,
                                                taksit_no,
                                                gecici_sira_no,
                                                gerceklesecek_tarih,
                                                gerceklesecek_tutar,
                                                yaratan_tx_no,
                                                status,
                                                sube,
                                                musteri_no,
                                                doviz_kodu,
                                                vergili_mi)
                 VALUES (
                           ps_referans,
                           pn_vs_no,
                           ps_masraf_kodu,
                           pn_taksit_no,
                           1,
                           NVL (pd_taksit_odeme_tarih,
                                pkg_muhasebe.banka_tarihi_bul),
                           pn_taksit_tutari,
                           pn_yarat_tx,
                           'A',
                           ls_sube,
                           ln_musteri,
                           r_0.dvz,
                           ps_vergi);
      END IF;
   END;

   /* --------------------------------------------------------------------------------------------------- */

   FUNCTION musteri_tipi_al (pn_musteri_no NUMBER)
      RETURN VARCHAR2
   IS
      ls_tip   VARCHAR2 (100);
      ln_cnt   NUMBER;
   BEGIN
      ls_tip := pkg_musteri.sf_musteri_urun_tur_al (pn_musteri_no);

      IF ls_tip <> 'INDIVIDUAL'
      THEN
         ls_tip := 'CORPORATE';
      END IF;

      RETURN ls_tip;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;

   /* --------------------------------------------------------------------------------------------------- */



    /*******************************************************************************
    Name:   calculate_commissions_for_CIB
    Prepared By:    Chyngyz Omurov
    Date:   06.07.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:    calculate special commissions for swift in CIB
*******************************************************************************/

   FUNCTION calculate_commissions_for_CIB (
      pn_islem_no          NUMBER,
      ps_urun_sinif_kod    cbs_islem.urun_sinif_kod%TYPE,
      pn_tutar             cbs_islem.tutar%TYPE,
      ps_doviz_kod         cbs_islem.doviz_kod%TYPE,
      pn_musteri_numara    cbs_islem.musteri_numara%TYPE,
      pn_hesap_numara      cbs_islem.hesap_numara%TYPE)
      RETURN NUMBER
   IS
      ln_ben_const      NUMBER := 0;
      ln_ben_prop       NUMBER := 0;
      ln_ben_min        NUMBER := 0;
      ln_ben_max        NUMBER := 0;

      ln_our_const      NUMBER := 0;
      ln_our_prop       NUMBER := 0;
      ln_our_min        NUMBER := 0;
      ln_our_max        NUMBER := 0;

      ln_gour_const     NUMBER := 0;
      ln_gour_prop      NUMBER := 0;
      ln_gour_min       NUMBER := 0;
      ln_gour_max       NUMBER := 0;

      ln_const          NUMBER := 0;
      ln_prop           NUMBER := 0;
      ln_min            NUMBER := 0;
      ln_max            NUMBER := 0;

      ln_charge_total   NUMBER := 0;
      ln_charge_const   NUMBER := 0;
      ln_charge_prop    NUMBER := 0;

      ln_return_const   NUMBER := 0;
      ln_return_prop    NUMBER := 0;

      ln_cdf_rate       NUMBER := 0;
   BEGIN
   
     log_at('commissions 0',ps_doviz_kod || ' ' || pn_musteri_numara || ' ' || ln_cdf_rate || ' ' || ln_ben_prop || ' ' || ln_ben_const || ' ' || ln_ben_min || ' ' || 
     ln_ben_max || ' ' || ln_our_prop || ln_our_const || ' ' || ln_our_min || ' ' || ln_our_max || ' ' || ln_gour_prop || ' ' || ln_gour_const || ' ' ||  ln_gour_min || ' ' ||   ln_gour_max);
      --get special commissions into the declared variables
      pkg_tx4052.Get_Special_Cdf_Rates (ps_doviz_kod,
                                        pn_musteri_numara,
                                        ln_cdf_rate,
                                        ln_ben_prop,
                                        ln_ben_const,
                                        ln_ben_min,
                                        ln_ben_max,
                                        ln_our_prop,
                                        ln_our_const,
                                        ln_our_min,
                                        ln_our_max,
                                        ln_gour_prop,
                                        ln_gour_const,
                                        ln_gour_min,
                                        ln_gour_max);

     log_at('commissions 1',ps_doviz_kod || ' ' || pn_musteri_numara || ' ' || ln_cdf_rate || ' ' || ln_ben_prop || ' ' || ln_ben_const || ' ' || ln_ben_min || ' ' || 
     ln_ben_max || ' ' || ln_our_prop || ln_our_const || ' ' || ln_our_min || ' ' || ln_our_max || ' ' || ln_gour_prop || ' ' || ln_gour_const || ' ' ||  ln_gour_min || ' ' ||   ln_gour_max);
      IF ps_urun_sinif_kod LIKE 'CIB BEN%'
      THEN
         ln_const := ln_ben_const;
         ln_prop := ln_ben_prop;
         ln_min := ln_ben_min;
         ln_max := ln_ben_max;
      ELSIF ps_urun_sinif_kod LIKE 'CIB OUR%'
      THEN
         ln_const := ln_our_const;
         ln_prop := ln_our_prop;
         ln_min := ln_our_min;
         ln_max := ln_our_max;
      ELSIF ps_urun_sinif_kod LIKE 'CIB GOUR%'
      THEN
         ln_const := ln_gour_const;
         ln_prop := ln_gour_prop;
         ln_min := ln_gour_min;
         ln_max := ln_gour_max;
      END IF;


      log_at('commissions 2', pn_islem_no);
      IF     ln_const IS NOT NULL
         AND ln_prop IS NOT NULL
         AND ln_min IS NOT NULL
         AND ln_max IS NOT NULL
      THEN
         ln_charge_total := ROUND (ln_const + ln_prop / 100 * pn_tutar, 2);
      ELSE
         ln_charge_total := -1; --charge amount will be taken from standard (already calculated)
      END IF;


      IF ln_charge_total >= 0
      THEN                                           --use special commissions
         IF ln_charge_total > ln_max
         THEN
            ln_charge_total := ln_max;
         END IF;

         IF ln_charge_total < ln_min
         THEN
            ln_charge_total := ln_min;
         END IF;

         --IBFCTRNSF2 sabit
         --IBFCTRNSFR oran

         IF ln_charge_total < ln_const
         THEN -- if max < const (wrongly entered in 4052, checking just in case)
            ln_charge_const := ln_charge_total;
            ln_charge_prop := 0;
         ELSE
            ln_charge_const := ln_const;
            ln_charge_prop := ln_charge_total - ln_charge_const;
         END IF;

         log_at('commissions 3', pn_islem_no);
         UPDATE cbs_masraf
            SET HESAPLANAN = ln_charge_const, ALINAN = ln_charge_const
          WHERE islem_no = pn_islem_no AND masraf_kodu = 'IBFCTRNSF2'; -- constant part

         UPDATE cbs_masraf
            SET HESAPLANAN = ln_charge_prop, ALINAN = ln_charge_prop
          WHERE islem_no = pn_islem_no AND masraf_kodu = 'IBFCTRNSFR'; -- proportional part
      END IF;

      SELECT NVL (ALINAN, HESAPLANAN)
        INTO ln_return_const
        FROM cbs_masraf
       WHERE islem_no = pn_islem_no AND masraf_kodu = 'IBFCTRNSF2'; -- constant part

      SELECT NVL (ALINAN, HESAPLANAN)
        INTO ln_return_prop
        FROM cbs_masraf
       WHERE islem_no = pn_islem_no AND masraf_kodu = 'IBFCTRNSFR'; -- proportional part

      RETURN ln_return_const + ln_return_prop;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at (
            'swiftcib pkg_masraf.calculate_commissions_for_CIB',
               'pn_islem_no='
            || pn_islem_no
            || ' pn_hesap_numara='
            || pn_hesap_numara,
            SQLERRM,
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RAISE;
   END;

   /*******************************************************************************
       Name:   CD_sum_for_period
       Prepared By:    Chyngyz Omurov
       Date:   18.02.2015
       Base Project:   CQ509 - SWIFT via CIB
       Purpose:    calculate total amount in user balance which deposited with cash for the given period
   *******************************************************************************/
   FUNCTION CD_sum_for_period (pn_hesapno      NUMBER,
                               pd_begindate    DATE,
                               pd_enddate      DATE)
      RETURN NUMBER
   IS
      /* BOM cq5735 ChyngyzO 31.01.2017 */
      CURSOR cursor_tx
      IS
           SELECT I.ISLEM_KOD,
                  S.FIS_ISLEM_NUMARA,
                  SUM (S.DV_TUTAR) DV_TUTAR,
                  S.DOVIZ_KOD,
                  S.TUR
             FROM (SELECT SI.fis_islem_numara,
                          SI.dv_tutar,
                          SI.doviz_kod,
                          SI.tur
                     FROM CBS_SATIR SI
                    WHERE     Si.HESAP_NUMARA = TO_CHAR (pn_hesapno)
                          AND SI.fis_tur = 'G'
                          AND SI.FIS_YARATILDIGI_BANKA_TARIH BETWEEN pd_begindate
                                                                 AND pd_enddate)
                  S
                  JOIN CBS_ISLEM I ON S.FIS_ISLEM_NUMARA = I.NUMARA
            WHERE     I.DURUM IN ('P', 'N')
                  AND i.kayit_tarih BETWEEN pd_begindate AND pd_enddate
         GROUP BY I.ISLEM_KOD,
                  S.FIS_ISLEM_NUMARA,
                  S.DOVIZ_KOD,
                  S.TUR
         ORDER BY S.FIS_ISLEM_NUMARA;

      /* EOM cq5735 ChyngyzO 31.01.2017 */

      ln_cd_count           NUMBER := 0;
      ln_cash_fx_count      NUMBER := 0;

      ln_charged_cdf        NUMBER := 0;
      ln_cdf_rate           NUMBER := 0;
      ln_prev_used_cd_sum   NUMBER := 0;
   BEGIN
      FOR rw_tx IN cursor_tx
      LOOP
         IF rw_tx.ISLEM_KOD = 6200 AND rw_tx.TUR = 'A'
         THEN
            ln_cd_count := ln_cd_count + rw_tx.DV_TUTAR;
         ELSIF rw_tx.ISLEM_KOD = 1207 AND rw_tx.TUR = 'A'
         THEN
            SELECT COUNT (*)
              INTO ln_cash_fx_count
              FROM CBS_ARBITRAJ_ISLEM
             WHERE TX_NO = rw_tx.FIS_ISLEM_NUMARA AND CASH_RATE = '1'; --REGEXP_LIKE (aciklama, '\((\s)*???*', 'i') ;

            IF ln_cash_fx_count > 0
            THEN
               ln_cd_count := ln_cd_count + rw_tx.DV_TUTAR;
            END IF;
         ELSIF rw_tx.ISLEM_KOD = 4025 AND rw_tx.TUR = 'A'
         THEN
            SELECT COUNT (*)
              INTO ln_cash_fx_count
              FROM CBS_DTH_DOVIZ_SATIS_ISLEM
             WHERE TX_NO = rw_tx.FIS_ISLEM_NUMARA AND CASH_RATE = '1'; --REGEXP_LIKE (aciklama, '\((\s)*???*', 'i') ;

            IF ln_cash_fx_count > 0
            THEN
               ln_cd_count := ln_cd_count + rw_tx.DV_TUTAR;
            END IF;
         ELSIF rw_tx.ISLEM_KOD = 4003 AND rw_tx.TUR = 'B'
         THEN                           --check if cdf was taken for this OGMT
            BEGIN
               SELECT HESAPLANAN
                 INTO ln_charged_cdf
                 FROM CBS.CBS_MASRAF
                WHERE     islem_no = rw_tx.FIS_ISLEM_NUMARA
                      AND masraf_kodu = 'YPGDDALSAT';

               SELECT Pkg_Message.Split (B.FIELD19, '###', 3)
                 INTO ln_cdf_rate
                 FROM CBS.CBS_YPHAVALE_GIDEN_ACILIS a, CORPINT.TBL_TXTODO b
                WHERE     A.TX_NO = rw_tx.FIS_ISLEM_NUMARA
                      AND A.TODO_TXNO = B.TX_NO;

               IF NVL (ln_charged_cdf, 0) > 0 AND NVL (ln_cdf_rate, 0) > 0
               THEN
                  ln_prev_used_cd_sum :=
                     ROUND (ln_charged_cdf * 100 / ln_cdf_rate, 2);
                  ln_cd_count := ln_cd_count - ln_prev_used_cd_sum;
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  NULL;
            END;
         ELSIF rw_tx.TUR = 'B'
         THEN
            ln_cd_count := ln_cd_count - rw_tx.DV_TUTAR;
         END IF;

         IF ln_cd_count < 0
         THEN
            ln_cd_count := 0;
         END IF;
      END LOOP;

      RETURN ln_cd_count;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at (
            'swiftcib',
            'CD_sum_for_period',
               'Error pn_hesapno='
            || pn_hesapno
            || ' pd_begindate='
            || pd_begindate
            || ' pd_enddate='
            || pd_enddate,
            SQLERRM);
         RETURN 0;
   END;

   FUNCTION CD_sum_for_period_OLD (pn_hesapno      NUMBER,
                                   pd_begindate    DATE,
                                   pd_enddate      DATE)
      RETURN NUMBER
   IS
      CURSOR cursor_tx (
         pd_date    DATE)
      IS
           SELECT I.ISLEM_KOD,
                  S.FIS_ISLEM_NUMARA,
                  S.MUSTERI_HESAP_NUMARA,
                  S.DV_TUTAR,
                  S.DOVIZ_KOD,
                  S.TUR
             FROM CBS_SATIR S JOIN CBS_ISLEM I ON S.FIS_ISLEM_NUMARA = I.NUMARA
            WHERE     S.HESAP_NUMARA = pn_hesapno
                  AND S.fis_tur = 'G'
                  AND S.HESAP_TUR_KODU = 'VS'
                  AND S.FIS_MUHASEBELESTIGI_TARIH = pd_date
                  AND I.DURUM IN ('P', 'N')
         ORDER BY S.FIS_ISLEM_NUMARA;

      ld_iter       DATE := pd_begindate;

      ln_cd_count   NUMBER := 0;
   BEGIN
      LOOP
         FOR rw_tx IN cursor_tx (ld_iter)
         LOOP
            IF rw_tx.ISLEM_KOD = 6200 AND rw_tx.TUR = 'A'
            THEN
               ln_cd_count := ln_cd_count + rw_tx.DV_TUTAR;
            ELSIF rw_tx.TUR = 'B'
            THEN
               ln_cd_count := ln_cd_count - rw_tx.DV_TUTAR;
            END IF;

            IF ln_cd_count < 0
            THEN
               ln_cd_count := 0;
            END IF;
         END LOOP;

         IF ld_iter = pd_enddate
         THEN
            EXIT;
         ELSE
            ld_iter := ld_iter + 1;
         END IF;
      END LOOP;

      RETURN ln_cd_count;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at (
            'swiftcib',
            'CD_sum_for_period',
               'Error pn_hesapno='
            || pn_hesapno
            || ' pd_begindate='
            || pd_begindate
            || ' pd_enddate='
            || pd_enddate,
            SQLERRM);
         RETURN 0;
   END;

   /*******************************************************************************
       Name:   calculate_CDF_for_CIB
       Prepared By:    Chyngyz Omurov
       Date:   18.02.2015
       Base Project:   CQ509 - SWIFT via CIB
       Purpose:    calculate cash deposit fee for the given customer account
   *******************************************************************************/

   FUNCTION calculate_CDF_for_CIB (
      pn_islem_no          NUMBER,
      pn_islem_kod         cbs_islem.islem_kod%TYPE,
      ps_modul_tur_kod     cbs_islem.modul_tur_kod%TYPE,
      ps_urun_tur_kod      cbs_islem.urun_tur_kod%TYPE,
      ps_urun_sinif_kod    cbs_islem.urun_sinif_kod%TYPE,
      pn_tutar             cbs_islem.tutar%TYPE,
      ps_doviz_kod         cbs_islem.doviz_kod%TYPE,
      pn_musteri_numara    cbs_islem.musteri_numara%TYPE,
      pn_hesap_numara      cbs_islem.hesap_numara%TYPE)
      RETURN NUMBER
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;


      CURSOR cursor_cdf_rate
      IS
         SELECT cdf_rate
           FROM CBS_IB_SWIFT_CDF
          WHERE     customer_no = pn_musteri_numara
                AND currency_cod = ps_doviz_kod;

      ln_cdf_rate            NUMBER := 0;
      ln_sum30               NUMBER := 0;
      ln_sum60               NUMBER := 0;
      ln_available_balance   NUMBER := 0;
      ln_charge              NUMBER := 0;
      ln_cdf_total           NUMBER := 0;
      ln_cdf_60              NUMBER := 0;
      ln_cdf_30              NUMBER := 0;

      ln_cdf_rate_standard   NUMBER := 0;
      ln_region              NUMBER := 1;

      ln_ben_const           NUMBER := 0;
      ln_ben_prop            NUMBER := 0;
      ln_ben_min             NUMBER := 0;
      ln_ben_max             NUMBER := 0;

      ln_our_const           NUMBER := 0;
      ln_our_prop            NUMBER := 0;
      ln_our_min             NUMBER := 0;
      ln_our_max             NUMBER := 0;

      ln_gour_const          NUMBER := 0;
      ln_gour_prop           NUMBER := 0;
      ln_gour_min            NUMBER := 0;
      ln_gour_max            NUMBER := 0;
   BEGIN
      --get region of the branch in which account was opened
      BEGIN
         SELECT DECODE (B.REGION_NO, 1, 1, 2)
           INTO ln_region
           FROM cbs_hesap h, CBS_BOLUM b
          WHERE H.SUBE_KODU = B.KODU AND h.hesap_no = pn_hesap_numara;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            ln_region := 1;                                          --BISHKEK
      END;


      --get regional standard CDF rate (for all customers)
      pkg_tx4054.Get_REGION_CDF_Rates (ps_doviz_kod,
                                       ln_region,
                                       ln_cdf_rate_standard);

      --get special CDF rate
      pkg_tx4052.Get_Special_Cdf_Rates (ps_doviz_kod,
                                        pn_musteri_numara,
                                        ln_cdf_rate,
                                        ln_ben_prop,
                                        ln_ben_const,
                                        ln_ben_min,
                                        ln_ben_max,
                                        ln_our_prop,
                                        ln_our_const,
                                        ln_our_min,
                                        ln_our_max,
                                        ln_gour_prop,
                                        ln_gour_const,
                                        ln_gour_min,
                                        ln_gour_max);


      ln_cdf_rate := NVL (ln_cdf_rate, ln_cdf_rate_standard); --if cdf rate is not defined for this customer set standard rate

      --ln_cdf_rate := 0; --!!!!!!!!!!!!!!!!!!!!!!!! delete, for testing only!!!!!!!!!!!!!!!!!!!!!!!!!

      IF NVL (ln_cdf_rate, 0) = 0 OR NVL (pn_tutar, 0) = 0
      THEN
         RETURN ln_charge;
      END IF;

      --calculate sum of cash deposits for last 30 and 60 days

      ln_sum30 :=
         PKG_MASRAF.CD_SUM_FOR_PERIOD (pn_hesap_numara,
                                       PKG_MUHASEBE.BANKA_TARIHI_BUL - 30,
                                       PKG_MUHASEBE.BANKA_TARIHI_BUL);

      ln_sum60 :=
         PKG_MASRAF.CD_SUM_FOR_PERIOD (pn_hesap_numara,
                                       PKG_MUHASEBE.BANKA_TARIHI_BUL - 60,
                                       PKG_MUHASEBE.BANKA_TARIHI_BUL - 31);

      --get available balance
      ln_available_balance :=
         NVL (Pkg_Hesap.Kullanilabilir_Bakiye_Al (pn_hesap_numara), 0);

      --check whether CDF can be applied => if the current balance without cash depositted amount is smaller then swift amoun then apply

      IF ln_available_balance - (ln_sum30 + ln_sum60) <= 0
      THEN
         ln_cdf_total := pn_tutar;
      ELSE
         ln_cdf_total :=
            pn_tutar - (ln_available_balance - (ln_sum30 + ln_sum60));
      END IF;

      IF ln_cdf_total > 0
      THEN
         --apply CDF, first apply to cash deposits with discount  i.e. which are in the interval [t-60, t-31]
         --ln_sum60 = 40 ln_sum30 = 100 ln_cdf_total = 75

         IF ln_sum60 - ln_cdf_total > 0
         THEN -- if cash deposits in [t-60, t-31] covers insufficient amount then take all amount from this interval (with discount)
            ln_cdf_60 := ln_cdf_total;
         ELSE
            ln_cdf_60 := ln_sum60;
         END IF;

         IF ln_sum30 - (ln_cdf_total - ln_cdf_60) > 0
         THEN -- if cash deposits in [t-30, t] covers remaining insufficient amount
            ln_cdf_30 := ln_cdf_total - ln_cdf_60;
         ELSE
            ln_cdf_30 := ln_sum30;
         END IF;

         ln_charge := (ln_cdf_60 * ln_cdf_rate / 100) / 2; -- with 50% discount

         ln_charge := ln_charge + (ln_cdf_30 * ln_cdf_rate / 100); -- without discount
      END IF;

      ln_charge := ROUND (ln_charge, 2);

      UPDATE cbs_masraf
         SET HESAPLANAN = ln_charge, ALINAN = ln_charge
       WHERE islem_no = pn_islem_no AND masraf_kodu = 'YPGDDALSAT';

      COMMIT;

      RETURN ln_charge;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at (
            'swiftcib pkg_masraf.calculate_CDF_for_CIB',
               'pn_islem_no='
            || pn_islem_no
            || ' pn_hesap_numara='
            || pn_hesap_numara,
            SQLERRM,
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

         RAISE;
   END;


   -- AdiletK 22.02.2017 CQ1016 calculates commission amount but doesn't put it into the cbs_masraf
   FUNCTION masraf_tutari_hesapla (ps_masraf_kod      cbs_masraf_tur.kodu%TYPE,
                                   pn_tutar           NUMBER,
                                   pn_islem_kodu      NUMBER,
                                   pn_rol             NUMBER,
                                   pn_musteri_no      NUMBER,
                                   ps_doviz           VARCHAR2,
                                   ps_msrf_dvz        VARCHAR2 DEFAULT NULL,
                                   ps_modul           VARCHAR2 DEFAULT NULL,
                                   ps_urun_tur        VARCHAR2 DEFAULT NULL,
                                   ps_urun_sinif      VARCHAR2 DEFAULT NULL,
                                   pc_bolum_kodu      VARCHAR2 DEFAULT NULL,
                                   pc_hesap_numara    VARCHAR2 DEFAULT NULL)
      RETURN NUMBER                    -- return comm amount for a transaction
   IS
      ln_masraf   NUMBER := 0;
      ln_bsmv     NUMBER := 0;
   BEGIN
      masraf_hesapla (ps_masraf_kod,
                      pn_tutar,
                      pn_islem_kodu,
                      pn_rol,
                      pn_musteri_no,
                      ps_doviz,
                      ln_masraf,
                      ln_bsmv,
                      ps_msrf_dvz,
                      ps_modul,
                      ps_urun_tur,
                      ps_urun_sinif,
                      pc_bolum_kodu,
                      pc_hesap_numara);          -- calculating the commission

      RETURN ln_masraf;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at ('Comm calculation',
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RETURN 0;
   END;
END;
/

