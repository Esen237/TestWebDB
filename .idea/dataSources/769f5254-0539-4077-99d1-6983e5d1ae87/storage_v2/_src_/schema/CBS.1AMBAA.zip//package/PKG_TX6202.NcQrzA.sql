create PACKAGE     Pkg_Tx6202 IS

/******************************************************************************
   Name       : PKG_TX6202
   Created By : Gulnihal Cengiz
   Date    	  : 10/08/2004
   Purpose	  : Cari Efektif Alis
******************************************************************************/
  FUNCTION  Efektif_Alis_Referansi_Al RETURN VARCHAR2 ;
  FUNCTION  EF_Satis_Istatistik_Kodu_Al(pn_referans_no CBS_CARI_EFEKTIF_ALIS.referans_no%TYPE) RETURN VARCHAR2;
  FUNCTION  EF_Alis_Istatistik_Kodu_Al(pn_referans_no CBS_CARI_EFEKTIF_ALIS.referans_no%TYPE) RETURN VARCHAR2;
  FUNCTION  Sf_Hesap_Urun_Uygunmu(ps_urun_tur_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

END;


/

