create PACKAGE     PKG_TX4050 IS
/******************************************************************************
Name       : PKG_TX4050
Created By : Bilal GUL
Purpose    : Merkez Bankasi Gunluk Kur Alma
******************************************************************************/
  -- TX Event Listesi

  --BOM IadgarB 18.09.2018
  Function get_day_currency(ps_tarih date, ps_doviz_kodu varchar2) return number;
  Procedure Populate_CBS_GUNLUK_KUR_DETAY(ps_text varchar2);                    -- Insert into CBS_GUNLUK_KUR_DETAY table
  Procedure Currency_Approve(pn_islem_no number);                               -- Verify/Approve Transaction
  Function Set_Currencies(ps_text varchar2, ps_date date) return varchar2;      -- Create Transaction
  --EOM IadgarB 18.09.2018

  Procedure mb_kur_al(pn_islem_no number);
  Procedure mb_kur_temizle(pn_islem_no number);

  Procedure Kontrol_Sonrasi(pn_islem_no number);                                -- Islem giris kontrolden gectikten sonra cagrilir
  Procedure Dogrulama_Sonrasi(pn_islem_no number);                              -- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);                                  -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );                            -- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);                                   -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);                               -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);                                  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);                                  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);                                  -- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);
END;

/

