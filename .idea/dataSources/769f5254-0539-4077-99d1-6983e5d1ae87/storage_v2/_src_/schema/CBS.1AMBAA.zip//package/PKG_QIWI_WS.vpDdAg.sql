create PACKAGE     pkg_qiwi_ws AS
/******************************************************************************
    Name       : PKG_QIWI_WS
    Created By : roman.shakirov
    Created Date: 05.09.2011
    Purpose   : API for QIWI web service ( through third party QIWI firm connect to USIP) 
******************************************************************************/
function checkAgent(pn_agentId number,pn_tran_code number default 0,pn_paymentId number default 0) return varchar2;
procedure addPayment(pn_tran_code number ,pn_paymentId number, pn_agentId number, pn_amount number, 
    ps_docNo varchar2 ,ps_Status out varchar2);
procedure cancelPayment(pn_tran_code number ,pn_paymentId number, pd_cancelDate date ,ps_Status out varchar2);

--B-O-M sevalb 19042012 sdlc23975_Modification for screens connected to USIP web-services
procedure sp_ins_usip_qiwi_log(  ps_tran_type varchar2, 
                                 pn_tran_code number , 
                                 pn_paymentId number, 
                                 pn_agentId number, 
                                 pn_amount number, 
                                 ps_docNo varchar2 ,
                                 ps_Status  varchar2,
                                 ps_status_description varchar2,
                                 ps_agent_name varchar2,
                                 ps_IsAgentExist varchar2, 
                                 ps_IsEnabled   varchar2,
                                 ps_return_code varchar2,
                                 ps_REQUEST_XML   clob ,
                                 ps_RESPONSE_XML clob);
procedure sp_checkAgent(pn_agentId number,pn_tran_code number default 0,pn_paymentId number default 0,ps_AgentName out varchar2, ps_IsAgentExist out varchar2, ps_IsEnabled out varchar2); 
--E-O-M sevalb 19042012 sdlc23975_Modification for screens connected to USIP web-services                                
END pkg_qiwi_ws;

/

