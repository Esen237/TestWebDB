create PACKAGE                   PKG_REST IS

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send http request to rest service
******************************************************************************/
FUNCTION sendRequest(url IN VARCHAR2, method_type IN VARCHAR2, req_content IN VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add varchar2 url parameter
******************************************************************************/
PROCEDURE addParam(params IN OUT NOCOPY VARCHAR2, param_key IN VARCHAR2, param_value IN VARCHAR2);

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add clob url parameter
******************************************************************************/
PROCEDURE addParam(params IN OUT NOCOPY VARCHAR2, param_key IN VARCHAR2, param_value IN CLOB);

/******************************************************************************
NAME        : FUNCTION sendRequestJson
Prepared By : Bahiana Bektemir kyzy
Date        : 27.05.2021
Purpose     : Send https request with JSON payload to rest service   
******************************************************************************/
FUNCTION sendRequestJson(ps_url IN VARCHAR2,ps_method_type IN VARCHAR2,ps_req_content IN VARCHAR2,ps_res_content IN OUT CLOB) RETURN VARCHAR2;
END PKG_REST;
/

