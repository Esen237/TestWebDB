create PACKAGE Pkg_Masraf_Tx22060 IS

  -- TX Event Listesi
  --?HRACAT ve ?THALAT ekranlar?nda kullan?lan MASRAF objeleri i?in paket

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2); 		-- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);		-- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);-- Islem iptal edildikten sonra cagrilir

  PROCEDURE onay_sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);  --onaydan sonra ca?r?l?r.....
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);		-- Islem reddedildikten sonra cagrilir

  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);  		-- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);		-- Islem iptal edilirse

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER);			-- Islemin muhasebelesmesi icin cagrilir

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  PROCEDURE muhasebe_sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);  --muhasebeden sonra ca?r?l?r.....

  PROCEDURE EOD_Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER, ps_referans VARCHAR2, pn_vs_no NUMBER, ps_masraf_kodu VARCHAR2);
  Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2;

END;

/

