create PACKAGE PKG_TX4125 IS

  /******************************************************************************
   Name       : PKG_TX4125
   Created By : Bilal GUL
   Date	   	  : 18/03/2004
   Purpose	  : LEHIMIZE VERILEN TEMINAT MEKTUPLARI GIRISI
  ******************************************************************************/

  --TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrili

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Function masraf_kontrol_yap(ps_odeyecek varchar2) return varchar2;

  Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2;

END;


/

