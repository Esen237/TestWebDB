create PACKAGE Pkg_Tx2060 IS

  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54
  -- Purpose : Hesap A??l??lar?n?nda kullan?lacakt?r.
  FUNCTION  Sf_Urun_Tur_Uygunmu(ps_urun_tur_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  PROCEDURE Yaratma_Oncesi(pn_islem_no NUMBER); 		-- Islem giris kontrolden once cagrilir
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		-- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			-- Islem iptal edildikten sonra cagrilir
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);				-- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		-- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			-- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		-- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			-- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);-- Islem iptal edildikten sonra cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip


END Pkg_Tx2060;


/

