create PACKAGE     "PKG_SOA_TRANSACTION" IS

TYPE CursorReferenceType IS REF CURSOR;
/******************************************************************************
 NAME : FUNCTION booktobooktransfer
 Prepared By : Almas Nurhozhaev
 Date : 06.12.07
 Purpose : book to book transfer transaction
******************************************************************************/
FUNCTION booktobooktransfer(pn_fromaccountno IN VARCHAR2,
 pn_toaccountno IN VARCHAR2,
 ps_amount IN VARCHAR2,
 ps_description IN VARCHAR2,
 ps_currencycode IN VARCHAR2,
 ps_isdekont IN VARCHAR2,
 ps_paymentcode IN VARCHAR2,
 pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------------------------------------------------------------
/******************************************************************************
 NAME : FUNCTION MakeEFT
 Prepared By : Almas Nurhozhaev
 Date : 04.07.08
 Purpose : Make clearing transaction
******************************************************************************/
FUNCTION MakeEFT(ps_from_acc          VARCHAR2,
                 ps_payee_info        VARCHAR2,
                 pd_trandate          VARCHAR2,
                 ps_sender_name       VARCHAR2,
                 ps_sender_phone      VARCHAR2,
                 ps_bank_code         VARCHAR2,
                 ps_payee_name        VARCHAR2,
                 ps_to_account        VARCHAR2,
                 pn_amount            VARCHAR2,
                 ps_description       VARCHAR2,
                 ps_save_payee_flag   VARCHAR2,
                 ps_payee_nick        VARCHAR2,
                 ps_payee_phone       VARCHAR2,
                 pn_rnn               VARCHAR2,
                 pn_doc_no            VARCHAR2,
                 pn_stat              VARCHAR2,
                 pn_paycode           VARCHAR2,
                 pn_income            VARCHAR2,
                 ps_payment_type      VARCHAR2,
                 pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
 NAME : FUNCTION CancelClearing
 Prepared By : Almas Nurhozhaev
 Date : 04.07.08
 Purpose : Cancel clearing transaction
******************************************************************************/
FUNCTION CancelClearing(p_TXNO IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
 * Method Name : MakeContact
 * Description : Gets Message Information
 * Prepared By : Almas Nurhozhaev
 * Modified Date : 03.04.2008
 ******************************************************************************/
FUNCTION MakeContact(ps_OptionCD IN VARCHAR2,
 ps_From_PersonID IN VARCHAR2,
 ps_ChannelCD IN VARCHAR2,
 ps_Content IN VARCHAR2,
 ps_ToPerson IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
 NAME : FXBuySell
 Prepared By : Almas Nurhozhaev
 Date : 07.07.2008
 Purpose : Foreign Exchange Buy Sell
******************************************************************************/
FUNCTION FXBuySell(ps_trantype IN VARCHAR2,
 pn_BORC_HESAP_NO IN VARCHAR2,
 ps_DOVIZ_KODU IN VARCHAR2,
 pn_KUR IN VARCHAR2,
 pn_TUTAR IN VARCHAR2,
 pn_ALACAK_HESAP_NO IN VARCHAR2,
 ps_ISTATISTIK_KODU IN VARCHAR2,
 ps_ACIKLAMA IN VARCHAR2,
 pn_REZERVASYON_NO IN VARCHAR2,
 ps_MASRAF IN VARCHAR2,
 ps_TAHSIL_ADILEN_TOPLAM_TUTAR IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
 NAME : FUNCTION MakeArbitrage
 Prepared By : Almas Nurhozhaev
 Date : 07.07.2008
 Purpose : Make Arbitraje
******************************************************************************/
FUNCTION MakeArbitrage(pn_fromaccountno IN VARCHAR2,
 pn_toaccountno IN VARCHAR2,
 ps_fromcurrency IN VARCHAR2,
 ps_tocurrency IN VARCHAR2,
 pn_parity IN VARCHAR2,
 pn_fromamount IN VARCHAR2,
 pn_toamount IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
 NAME : FUNCTION CreateTimeDepositeAccount
 Prepared By : Muzaffar Khalyknazarov
 Date : 21.12.2007
 Purpose : Create Time Deposit Account
******************************************************************************/
FUNCTION CreateTimeDepositeAccount(ps_customerid IN VARCHAR2,
 ps_modultur IN VARCHAR2,
 ps_uruntur IN VARCHAR2,
 ps_urunsinif IN VARCHAR2,
 ps_nickname IN VARCHAR2,
 ps_currcode IN VARCHAR2,
 ps_anapara IN VARCHAR2,
 ps_valortarihi IN VARCHAR2,
 ps_borckaydi IN VARCHAR2,
 ps_borcluhesapnumarasi IN VARCHAR2,
 ps_muhabirhesapnumarasi IN VARCHAR2,
 ps_dknumarasi IN VARCHAR2,
 ps_vade_islem_bilgisi IN VARCHAR2,
 ps_ara_odeme_bilgisi IN VARCHAR2,
 ps_otomatik_temdit IN VARCHAR2,
 ps_periodsure IN VARCHAR2,
 ps_periodcins IN VARCHAR2,
 ps_sonraki_baslangic_tarihi IN VARCHAR2,
 ps_ara_odeme_islem_bilgisi IN VARCHAR2,
 ps_vade_tarihi IN VARCHAR2,
 ps_geri_donus_hesap_numarasi IN VARCHAR2,
 ps_esas_gun_sayisi IN VARCHAR2,
 ps_faiz_orani IN VARCHAR2,
 ps_aciklama IN VARCHAR2,
 ps_sube IN VARCHAR2,
 ps_acilistarihi IN VARCHAR2,
 ps_net_faiz IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
FUNCTION MakeRateDemand(ps_option IN VARCHAR2,
                        ps_customerid IN VARCHAR2,
                        ps_buysell IN VARCHAR2,
                        ps_currcode IN VARCHAR2,
                        ps_amount IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION MakeClosingTimeDeposit
   Prepared By : Muzaffar Khalyknazarov
   Date        : 03.02.09
   Purpose     : Make clearing transaction
******************************************************************************/
FUNCTION MakeClosingTimeDeposit(pn_tdaccount  IN VARCHAR2,
                                pn_amount     IN VARCHAR2,
                                ps_doviz_kodu IN VARCHAR2,
                                pc_ref        OUT   cursorreferencetype) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION MakeClosingTimeDeposit
   Prepared By : Muzaffar Khalyknazarov
   Date        : 03.02.09
   Purpose     : Make clearing transaction
******************************************************************************/
FUNCTION MakeRepTimeDeposit(pn_fromaccountno    IN VARCHAR2,
                            pn_tdaccount        IN VARCHAR2,
                            pn_amount           IN VARCHAR2,
                            ps_doviz_kodu       IN VARCHAR2,
                            pc_ref              OUT   cursorreferencetype) RETURN VARCHAR2;
/**********************************************************************
   NAME        : FUNCTION MAKESwift
   Prepared By : Almas Nurkhozhayev
   Date        : 17.08.10
   Purpose     : Make SWIFT transaction
******************************************************************************/
FUNCTION MAKESwift(pd_amount        IN VARCHAR2,
                   pd_currency      IN VARCHAR2,
                   pd_accountid     IN VARCHAR2,
                   ps_ulkekodu      IN VARCHAR2,
                   ps_valor_tarihi  IN VARCHAR2,
                   ps_aciklama      IN VARCHAR2,
                   ps_acilistarihi  IN VARCHAR2,
                   p_PayeeName      IN VARCHAR2,
                   p_PayeeAddress   IN VARCHAR2,
                   ps_toAccountNo   IN VARCHAR2,
                   ps_muhabirmasraf IN VARCHAR2,
                   pn_paymentno     IN VARCHAR2,
                   ps_swiftcode     IN VARCHAR2,
                   ps_statcode      IN VARCHAR2,
                   ps_BankName      IN VARCHAR2,
                   pn_CHARGE_AMOUNT IN VARCHAR2,
                   ps_telpass       IN VARCHAR2,
                   ps_RecDesc       IN VARCHAR2,
                   ps_Recvisite     IN VARCHAR2,
                   ps_CityName      IN VARCHAR2,
                   pn_commAccount   IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : SendEmailMessage
   Prepared By : Almas Nurhozhaev
   Date        : 21.01.2008
   Purpose     : Send Email Message
******************************************************************************/
FUNCTION SendEmailMessage(ps_SENDER  IN VARCHAR2,
                        ps_RECIPIENT  IN VARCHAR2,
                        ps_SUBJECT  IN VARCHAR2,
                        ps_BODY_CONTENT IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : VirtualCardRequest
   Prepared By : Almas Nurhozhaev
   Date        : 13.02.2011
   Purpose     : Virtual Card Transactions
******************************************************************************/
FUNCTION VirtualCardRequest(ps_OptionCD IN VARCHAR2,
                            ps_PseudoPAN IN VARCHAR2, 
                            ps_LimitAmount IN VARCHAR2,
                            ps_SuppCashLimitAmount IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : CCDebtPayment
   Prepared By :  Nurhat UCA
   Date        : 17.12.2012
   Purpose     : Credit Card Debt Payment
******************************************************************************/
FUNCTION CCDebtPayment(  ps_CardNo IN VARCHAR2,
                            ps_Amount IN VARCHAR2,
                            ps_Currency IN VARCHAR2,
                            ps_branchCode IN VARCHAR2,
                            ps_tranDate IN VARCHAR2,
                            ps_valDate IN VARCHAR2,
                            ps_TranDesc IN VARCHAR2,
                            ps_ficheNo IN VARCHAR2,
                            ps_ficheDate IN VARCHAR2,
                            ps_reconcilation_no  IN VARCHAR2,
                            ps_pseudopan IN VARCHAR2) RETURN VARCHAR2;
                            
/******************************************************************************
   NAME        : sendSMS
   Prepared By : Almas Nurhozhaev
   Date        : 14.02.2011
   Purpose     : Send SMS
******************************************************************************/
FUNCTION sendSMS(ps_option IN VARCHAR2,
                 ps_subject IN VARCHAR2,
                 ps_message_body IN VARCHAR2,            
                 ps_mobile_no IN VARCHAR2,
                 ps_pwd_id IN VARCHAR2,
                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION payforservices
   Prepared By : Almas Nurhozhaev
   Date        : 07.03.11
   Purpose     : transaction to pay for services
******************************************************************************/
FUNCTION PayForServices(pn_fromaccountno   IN VARCHAR2,
                        ps_amount          IN VARCHAR2,
                        ps_description     IN VARCHAR2,
                        ps_currencycode    IN VARCHAR2,
                        ps_institution     IN VARCHAR2,
                        ps_phone_area_code IN VARCHAR2,
                        ps_phone_no        IN VARCHAR2,
                        ps_service_code    IN VARCHAR2,
                        ps_service_no      IN VARCHAR2,
                        pc_ref           OUT cursorreferencetype) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION CancelPayment
   Prepared By : Almas Nurhozhaev
   Date        : 07.03.11
   Purpose     : Cancel Payment
******************************************************************************/
FUNCTION CancelPayment(pn_option    IN VARCHAR2,
                       ps_person_id IN VARCHAR2,
                       ps_customer_id IN VARCHAR2,
                       ps_payment_id IN VARCHAR2,
                       pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION makeWSPaymentRequest
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : Payment Request for web service USIP
******************************************************************************/
FUNCTION makeWSPaymentRequest(ps_amount    IN VARCHAR2,
                              ps_transaction_number IN VARCHAR2,
                              ps_service_id IN VARCHAR2,
                              ps_account_number IN VARCHAR2,
                              ps_receipt_number IN VARCHAR2,
                              ps_receipt_datetime IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'),
                              pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION getWSPaymentStatus
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : gets Payment Status for web service USIP
******************************************************************************/
FUNCTION getWSPaymentStatus(ps_amount    IN VARCHAR2,
                            ps_transaction_number IN VARCHAR2,
                            pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;    
/******************************************************************************
   NAME        : FUNCTION makeWSCancelPayment
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : Cancel Payment Request for web service USIP
******************************************************************************/
FUNCTION makeWSCancelPayment(ps_transaction_number IN VARCHAR2,
                             pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION makeKTWSRequest
   Prepared By : Almas Nurhozhaev
   Date        : 28.11.11
   Purpose     : make KT Request through WS
******************************************************************************/
FUNCTION makeKTWSRequest(ps_PARAM1 IN VARCHAR2,
                         ps_SERVICE_ID IN VARCHAR2,
                         ps_SUPPLIER_ID IN VARCHAR2,
                         ps_QID IN VARCHAR2,
                         ps_QM IN VARCHAR2,
                         ps_SID IN VARCHAR2,
                         ps_OP IN VARCHAR2,
                         ps_SUM IN VARCHAR2,
                         ps_AGENT_ID IN VARCHAR2,
                         pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;

/*******************************************************************************
    Name        : FUNCTION payWsTax
    Prepared By : Almas Nurkhozhayev
    Date:       : 01.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : send info that customer will pay for given tax
*******************************************************************************/
FUNCTION payWsTax(ps_tin_number      IN varchar2,
                  ps_amount          IN varchar2,
                  ps_tax_type        IN varchar2,
                  ps_tax_district    IN varchar2,
                  ps_tax_subdistrict IN varchar2,
                  ps_tx_no           IN varchar2,
                  ps_datetime        IN varchar2,
                  ps_vehicle_plate      IN varchar2,
                  pc_ref        OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION makeTaxPayment
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : make payment for tax house over clearing
*******************************************************************************/
FUNCTION makeTaxPayment(ps_tin_number      IN varchar2,
                        ps_namesurname     IN varchar2,
                        ps_type_id         IN varchar2,
                        ps_region_id       IN varchar2,
                        ps_district_id     IN varchar2,
                        ps_sub_district_id IN varchar2,
                        ps_amount          IN varchar2,
                        ps_explanation_id  IN varchar2,
                        ps_from_account    IN varchar2,
                        ps_person_id       IN varchar2,
                        ps_vehicle_plate   IN varchar2,
                        pc_ref         OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION makeCampusSattlement
    Prepared By : Almas Nurkhozhayev
    Date:       : 19.08.2020
    Base Project: CBS-56 - Tuition fee via Payment Terminals Settlement
    Purpose     : Tuition fee via Payment Terminals Settlement by clearing
*******************************************************************************/
FUNCTION makeCampusSattlement(pc_ref OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION sendTaxHouseReport
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : calls tax house report with xml parameter
*******************************************************************************/
FUNCTION sendTaxHouseReport(ps_xml_data OUT CLOB) return varchar2;

/*******************************************************************************
    Name        : FUNCTION notifyCustomer
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : notify customer about processed transactions
*******************************************************************************/
FUNCTION notifyCustomer(pn_islem_no      IN NUMBER,
                        pn_islem_kod      IN NUMBER,
                        pn_musteri_no     IN NUMBER,
                        ps_eod                IN VARCHAR2) return varchar2;

/*******************************************************************************
    Name        : FUNCTION addToNotifyList
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : The transaction is added to notification waiting list
*******************************************************************************/
FUNCTION addToNotifyList(pn_islem_no      IN NUMBER,
                        pn_islem_kod      IN NUMBER,
                        pn_musteri_no IN NUMBER) return varchar2;

/*******************************************************************************
    Name        : FUNCTION sendDynamicNotifications
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : notify customer about his/her accounts, obligations or personal information
*******************************************************************************/

FUNCTION sendDynamicNotifications return varchar2;

/*******************************************************************************
    Name        : FUNCTION dynamicTranProcess
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - Processing transactions with additional dynamical steps
    Purpose     : process transaction using dynamic code fragments

    Usage: After each transaction, this process will be called from pkg_muhasebe.muhasebelestir.
    Its main purpose is to give opportunity to run extra functions after the transaction in a 
    dynamic way, so that the code of the dynamic function call be easily modified through
    the time period.
*******************************************************************************/

FUNCTION dynamicTranProcess(pn_islem_no      IN NUMBER,
                        pn_islem_kod     IN NUMBER,
                        pn_musteri_no    IN NUMBER) return varchar2;

/*******************************************************************************
    Name        : PROCEDURE addToDynamicNotifyList
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - Processing transactions with additional dynamical steps
    Purpose     : add transaction to dynamic processing list
*******************************************************************************/

FUNCTION addToDynamicNotifyList(pn_islem_no      IN NUMBER,
                        pn_islem_kod     IN NUMBER,
                        pn_musteri_no IN NUMBER) return varchar2;

/*******************************************************************************
    Name        : PROCEDURE getEowEom
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : get whether it is end of week or/and end of month
*******************************************************************************/

PROCEDURE getEowEom(ps_eow IN OUT VARCHAR2,
                                    ps_eom IN OUT VARCHAR2);
                                                                     
/*******************************************************************************
    Name        : PROCEDURE setNextEowEom
    Prepared By : Adilet Kachkeev
    Date:       : 09.12.2014
    Base Project: CQ000867 - E-mail notification for processed financial transactions
    Purpose     : set new dates for end of week or/and end of month
*******************************************************************************/
PROCEDURE setNextEowEom(ps_eow IN VARCHAR2,
                        ps_eom IN VARCHAR2);

/*******************************************************************************
    Name        : FUNCTION makeWsDealerPayment
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Make ws call to make dealer payment on the Company's Billing System
*******************************************************************************/
FUNCTION makeWsDealerPayment( ps_company_id IN varchar2,
                               ps_dealer_id IN varchar2,
                               ps_amount IN varchar2,
                               ps_currency IN varchar2,
                               ps_current_date IN varchar2,
                               ps_bank_date IN varchar2,
                               ps_cbs_txno IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) return varchar2;  

/*******************************************************************************
    Name        : FUNCTION cancelWsDealerPayment
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Make ws call to cancel dealer payment on the Company's Billing System
*******************************************************************************/
FUNCTION cancelWsDealerPayment(ps_company_id IN varchar2,
                               ps_dealer_id IN varchar2,
                               ps_amount IN varchar2,
                               ps_currency IN varchar2,
                               ps_current_date IN varchar2,
                               ps_bank_date IN varchar2,
                               ps_cbs_txno IN VARCHAR2,
                               ps_company_txno IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) return varchar2;                                          
--BOM CQ5717 MederT 13012017
/******************************************************************************
   NAME        : FUNCTION makeElcardWSOutcome
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Decrease Elcard Card balance WS
******************************************************************************/
FUNCTION makeElcardWSOutcome(pn_amount    IN NUMBER,
                              ps_account_number IN VARCHAR2,
                              pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;
    
/******************************************************************************
   NAME        : FUNCTION makeElcardWSIncome
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Increase Elcard Card balance WS
******************************************************************************/                          
FUNCTION makeElcardWSIncome(pn_amount    IN NUMBER,
                              ps_account_number IN VARCHAR2,
                              pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;
                              
/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWS
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS
******************************************************************************/                          
FUNCTION CheckElcardBalanceWS(ps_account_number IN VARCHAR2,
                              pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWSFront
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS Front
******************************************************************************/                          
FUNCTION CheckElcardBalanceWSFront(ps_account_number IN VARCHAR2,
                              pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWSBack
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS back
******************************************************************************/                          
FUNCTION CheckElcardBalanceWSBack(ps_account_number IN VARCHAR2,
                              pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;
                                                                                          
/******************************************************************************
   NAME        : PROCEDURE CallElcardWS
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Decrease/Increase Elcard Card balance WS
******************************************************************************/                          
PROCEDURE CallElcardWS(ps_tur IN VARCHAR2,
                          pn_amount    IN NUMBER,
                          ps_transaction_number IN VARCHAR2,
                          ps_account_number IN VARCHAR2,
                          pn_fis    IN NUMBER,
                          pn_numara    IN NUMBER,
                          pn_tx_no    IN NUMBER
                          );

/******************************************************************************
   NAME        : PROCEDURE AddElcardWSQueue
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : Add row to WS queue
******************************************************************************/                          
PROCEDURE AddElcardWSQueue(ps_transaction_number IN VARCHAR2,
                              pn_tx_no    IN NUMBER,
                              pn_fis    IN NUMBER
                              );

/******************************************************************************
   NAME        : PROCEDURE InsertElcardWSLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : InsertElcardWSLog
******************************************************************************/                          
PROCEDURE InsertElcardWSLog(pn_tx_no    IN NUMBER,
                              pn_fis    IN NUMBER,
                              pn_numara    IN NUMBER,
                              ps_tur IN VARCHAR2,
                              ps_transaction_number IN VARCHAR2,
                              ps_account_number IN VARCHAR2,
                              pn_amount    IN NUMBER,
                              ps_status IN VARCHAR2,
                              pn_is_proc    IN NUMBER
                              );

/******************************************************************************
   NAME        : PROCEDURE UpdateElcardWSLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : UpdateElcardWSLog
******************************************************************************/                          
PROCEDURE UpdateElcardWSLog(pn_tx_no    IN NUMBER,
                              pn_fis    IN NUMBER,
                              pn_numara    IN NUMBER,
                              ps_account_number IN VARCHAR2,
                              pn_amount    IN NUMBER,
                              ps_status IN VARCHAR2,
                              pn_is_proc    IN NUMBER
                              );

/******************************************************************************
   NAME        : PROCEDURE InsertElcardBalanceLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : InsertElcardBalanceLog
******************************************************************************/                          
PROCEDURE InsertElcardBalanceLog(ps_account_number IN VARCHAR2,
                              pn_balance    IN NUMBER
                              );
                                                                                      
/******************************************************************************
   NAME        : FUNCTION getElcardIPCBalance
   Prepared By : Meder Toitonov
   Date        : 17.02.2017
   Purpose     : get Elcard Card balance WS
******************************************************************************/                          
FUNCTION getElcardIPCBalance(ps_account_number IN VARCHAR2) RETURN NUMBER;

/******************************************************************************
   NAME        : FUNCTION processElcardWSQueue
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : prcoess Elcard WS queue
******************************************************************************/                          
PROCEDURE processElcardWSQueue(pn_tx_no number default null, pn_fis number default null);
--EOM CQ5717 MederT 13012017   

/******************************************************************************
   NAME        : PROCEDURE processElcardWSQueue
   Prepared By : NurmilaZ
   Date        : 26.08.2020
   Purpose     : process Update Customer
******************************************************************************/                        
FUNCTION EditCustomerElcard(pn_musteri IN number, pn_islem_no IN varchar2) RETURN NUMBER; 
/******************************************************************************
   NAME        : FUNCTION processElcardWSQueue
   Prepared By : NurmilaZ
   Date        : 24072020
   Purpose     : process Elcard ListCustomerCards
******************************************************************************/                          
PROCEDURE getdatabyelcard(pn_customer_no in number);                                                                                                                                                                                                                     
END Pkg_Soa_Transaction;
/

