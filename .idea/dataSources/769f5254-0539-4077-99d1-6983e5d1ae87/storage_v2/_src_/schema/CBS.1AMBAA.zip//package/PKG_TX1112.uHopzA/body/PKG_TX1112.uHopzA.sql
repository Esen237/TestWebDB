create PACKAGE BODY PKG_TX1112 IS
	pn_1112_alacak_hesap_sube_kodu        number;
	pn_1112_alacak_hesap_no       		  number;
	pn_1112_istatistik_kod         		  number;
	pn_1112_doviz_kodu        			  number;
	pn_1112_lc_tutar        			  number;
	pn_1112_fc_tutar        			  number;
	pn_1112_banka_aciklama        		  number;
	pn_1112_bloke_hesap_sube_kodu         number;
	pn_1112_bloke_hesap_no        		  number;
	pn_1112_musteri_aciklama        	  number;
	pn_1112_cek_referans        		  number;
	pn_1112_fis_aciklama        		  number;
	pn_1112_kur_lc        				  number;
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
  	   null;
 End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_musteri_no 	     number := 0;
  ld_banka_tarihi        date ;
  ld_teslim_tarihi       date ;
  ln_cek_no		         cbs_cek.cek_no%type;
  ln_cek_tutari	         cbs_cek.cek_tutari%type;
  ls_durum_kodu	 		 cbs_cek.durum_kodu%type;
  ln_cek_bloke_hesap_no  cbs_cek.cek_bloke_hesap_no%type;
  ln_alacak_hesap_no	 cbs_cek.alacak_hesap_no%type;
  ln_alacak_musteri_no   cbs_cek.alacak_musteri_no%type;
  Begin
  ld_banka_tarihi := pkg_muhasebe.banka_tarihi_bul;
 /* girilen bloke cek tutari alinir */
    select cek_no,cek_tutari ,cek_bloke_hesap_no ,durum_kodu,
		   alacak_hesap_no,alacak_musteri_no
	into   ln_cek_no, ln_cek_tutari ,ln_cek_bloke_hesap_no,ls_durum_kodu,
		   ln_alacak_hesap_no,ln_alacak_musteri_no
	from   cbs_cek_islem
    where  tx_no = pn_islem_no;

    update cbs_cek
	set bloke_tarihi = null,
		durum_kodu = 'A',
		bloke_f ='H',
		alacak_musteri_no = ln_alacak_musteri_no,
		alacak_hesap_no = ln_alacak_hesap_no
	where cek_no = ln_cek_no ;

  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin

 	/* Red edildi */
    update cbs_cek_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;

  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;

	ln_fis_no				   cbs_fis.numara%type ;
	ls_islem_kod               cbs_islem.islem_kod%type :='1112';
	ls_musteri_aciklama        varchar2(2000);
	ls_banka_aciklama          varchar2(2000);
	ln_musteri_no			   cbs_musteri.musteri_no%TYPE;
	ln_hesap_no		   		   cbs_cek.hesap_no%TYPE;
	ln_bloke_hesap_no		   cbs_cek.hesap_no%TYPE;
	ls_bloke_hesap_sube_kodu   cbs_cek.hesap_sube_kodu%TYPE;
    ln_alacak_hesap_no		   cbs_cek.hesap_no%TYPE;
	ls_alacak_hesap_sube_kodu  cbs_cek.hesap_sube_kodu%TYPE;
	ln_tutar			   	   cbs_cek.cek_tutari%TYPE;
	ls_fis_aciklama			   cbs_fis.aciklama%type;
	ls_doviz_kodu			   cbs_cek.doviz_kodu%type;
	ln_plan_no				   number :=1;
	cursor islem_cursor (pn_islemno cbs_islem.numara%type) is
	   	select musteri_no,
			   hesap_no,
   			   Decode( cek_bloke_hesap_no,null,null,Pkg_Hesap.HesaptanSubeAl(cek_bloke_hesap_no) ),
			   cek_bloke_hesap_no,
			   Decode( alacak_hesap_no,null,null,Pkg_Hesap.HesaptanSubeAl(alacak_hesap_no) ),
			   alacak_hesap_no ,
			   doviz_kodu,
			   cek_tutari ,
			   aciklama
			from cbs_cek_islem
			where islem_tanim_kod = 1112 and
			      tx_no=pn_islemno;

  Begin

/* islem bilgisi detaylari alinir */

	 if islem_cursor%isopen then
	   close islem_cursor;
	 end if;

	  open islem_cursor(pn_islem_no);
	    fetch islem_cursor into ln_musteri_no,ln_hesap_no,ls_bloke_hesap_sube_kodu,ln_bloke_hesap_no,
		   		 			  	ls_alacak_hesap_sube_kodu,ln_alacak_hesap_no,ls_doviz_kodu,ln_tutar ,ls_banka_aciklama;
		   if islem_cursor%notfound then
	          close islem_cursor;
	       end if;
		  close islem_cursor;

/*** Liste Deger Atama K?sm? **/

/**** varchar list ****/

   pkg_parametre.deger('1112_FIS_ACIKLAMA',ls_fis_aciklama);
--   pkg_parametre.deger('1112_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   varchar_list(pn_1112_fis_aciklama) 	 := ls_fis_aciklama ;
   varchar_list(pn_1112_banka_aciklama)  := ls_banka_aciklama;
   varchar_list(pn_1112_musteri_aciklama):=  ls_banka_aciklama; --ls_musteri_aciklama;
   varchar_list(pn_1112_cek_referans) 	 := to_char(ln_hesap_no);

   varchar_list(pn_1112_doviz_kodu)		 	   := ls_doviz_kodu;
   varchar_list(pn_1112_bloke_hesap_sube_kodu) := ls_bloke_hesap_sube_kodu;
   varchar_list(pn_1112_bloke_hesap_no)        := to_char(ln_bloke_hesap_no);
   varchar_list(pn_1112_alacak_hesap_sube_kodu):= ls_alacak_hesap_sube_kodu;
   varchar_list(pn_1112_alacak_hesap_no)       := to_char(ln_alacak_hesap_no);

/**** number list ****/
 if ls_doviz_kodu = pkg_genel.lc_al then
   number_list(pn_1112_fc_tutar):=ln_tutar ;
   number_list(pn_1112_lc_tutar):=ln_tutar ;
 else
   number_list(pn_1112_fc_tutar):=ln_tutar ;
   number_list(pn_1112_lc_tutar):= pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.lc_al,null,ln_tutar,1,null,null,'N','A');
 end if;

   number_list(pn_1112_kur_lc):= pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A');

/**** date list ****/
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							ln_plan_no,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							0,
							ls_fis_aciklama);

	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

 Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '185' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

  End;

Begin
/* parametre index numaralar? bulunur.*/
	pn_1112_alacak_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1112_ALACAK_HESAP_SUBE_KODU');
	pn_1112_alacak_hesap_no :=pkg_muhasebe.parametre_index_bul('1112_ALACAK_HESAP_NO');
	pn_1112_istatistik_kod :=pkg_muhasebe.parametre_index_bul('1112_ISTATISTIK_KOD');
	pn_1112_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1112_DOVIZ_KODU');
	pn_1112_lc_tutar :=pkg_muhasebe.parametre_index_bul('1112_LC_TUTAR');
	pn_1112_fc_tutar :=pkg_muhasebe.parametre_index_bul('1112_FC_TUTAR');
	pn_1112_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1112_BANKA_ACIKLAMA');
	pn_1112_bloke_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1112_BLOKE_HESAP_SUBE_KODU');
	pn_1112_bloke_hesap_no :=pkg_muhasebe.parametre_index_bul('1112_BLOKE_HESAP_NO');
	pn_1112_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1112_MUSTERI_ACIKLAMA');
	pn_1112_cek_referans :=pkg_muhasebe.parametre_index_bul('1112_CEK_REFERANS');
	pn_1112_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1112_FIS_ACIKLAMA');
	pn_1112_kur_lc :=pkg_muhasebe.parametre_index_bul('1112_KUR_LC');

END ;
/

