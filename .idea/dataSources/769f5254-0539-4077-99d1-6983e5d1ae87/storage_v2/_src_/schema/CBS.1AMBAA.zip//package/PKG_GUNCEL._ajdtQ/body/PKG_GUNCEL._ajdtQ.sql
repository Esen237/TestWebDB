create PACKAGE BODY pkg_guncel IS


Procedure Harici_Kod_Cagir(pn_islem_kod	   NUMBER,
		  				   ps_block		   VARCHAR2,
						   ps_rowid   	   VARCHAR2,
		  				   ps_column  	   VARCHAR2,
  		   				   pd_column  	   VARCHAR2,
						   pc_cikis_yeri   varchar2,
						   ps_oldvalue IN OUT varchar2) is
     Cursor c1 is
       Select 1
         from user_procedures up
        where object_name = 'PKG_TX'||to_char(pn_islem_kod)
          and procedure_name = upper(pc_cikis_yeri);

     ln_dummy	         number;
     ln_islem_kod      	 number;
     lc_plsql_block	   	 varchar2(2000);
     Islem_Bulunamadi_exception	exception;

   Begin

     open c1;
     fetch c1 into ln_islem_kod;
     if c1%notfound then
       close c1;
       raise Islem_Bulunamadi_exception;
     end if;

	 ln_islem_kod:=pn_islem_kod;
     lc_plsql_block := 'BEGIN  PKG_TX'||to_char(ln_islem_kod)||'.'||pc_cikis_yeri||'('||to_char(ln_islem_kod)||',''' || ps_block || ''',''' || ps_rowid || ''',''' || ps_column || ''',''' || pd_column || ''',:1);'||' END;';

     --PKG_TX2002.Guncelleme_Kontrolu(ln_islem_kod,ps_block,ps_rowid,ps_column,pd_column,ps_oldvalue);

     EXECUTE IMMEDIATE lc_plsql_block USING IN OUT ps_oldvalue;

	 exception
     		  when others then
			     raise_application_error(-20100,sqlerrm);
   End;

--Vadesiz Hesap G?ncelleme---------------------------------------------------------------
  Function Guncellenmis(ps_block   VARCHAR2,
  		   			    ps_rowid   VARCHAR2,
  		   				ps_column  VARCHAR2,
  		   				pd_column  VARCHAR2,
						pn_txno	   NUMBER,
						ps_oldvalue IN OUT VARCHAR2) return BOOLEAN is

  	   ls_sqlstr		VARCHAR2(2000);
	   ln_retval		NUMBER:=0;
  Begin
  --Source: g?ncel tablo
  --Destination: orjinal tablo

  	 Harici_Kod_Cagir(pn_txno, ps_block,ps_rowid, ps_column, pd_column, 'Guncelleme_Kontrolu',ps_oldvalue);

  	 return true;--G?ncellenmi?

  exception
  	  when others then
	  	   return false;--de?i?memi?
  End;
--######################################################################################

  Function DifferenceTemplateSingleRecord(pn_pk_count NUMBER) return VARCHAR2 is
   	  ls_sql_template					 VARCHAR2(2000);
	  ln_count							 NUMBER;
   BEGIN

   		ls_sql_template:='SELECT 1,to_char(NVL(d.DESTINATION_COLUMN,decode(a.DATA_TYPE,''DATE'','''',0))) FROM DESTINATION_TABLE d, SOURCE_TABLE s,user_tab_columns a ' ||
		  ' WHERE s.rowid=''SOURCE_ROWID'' ' ||
		  ' and a.table_name=upper(''SOURCE_TABLE'') and a.column_name=upper(''SOURCE_COLUMN'') ' ||
		  ' AND NVL(s.SOURCE_COLUMN,decode(a.DATA_TYPE,''DATE'','''',0))<>NVL(d.DESTINATION_COLUMN,decode(a.DATA_TYPE,''DATE'','''',0)) ';

	    For ln_count IN 1..pn_pk_count LOOP
		  ls_sql_template:= ls_sql_template || ' AND d.DESTINATION_PK' || to_char(ln_count) || '=s.SOURCE_PK' || to_char(ln_count);
		END LOOP;

   		return	ls_sql_template;
   END;
--######################################################################################
  Function DifferenceTemplateMultiRecord(pn_pk_count NUMBER) return VARCHAR2 is
   	  ls_sql_template					 VARCHAR2(2000);
   BEGIN

   		ls_sql_template:='select 1,to_char(NVL(d.DESTINATION_COLUMN,decode(a.DATA_TYPE,''DATE'','''',0))) from DESTINATION_TABLE d, SOURCE_TABLE s, user_tab_columns a  ' ||
						' WHERE s.rowid=''SOURCE_ROWID'' ' ||
					    ' AND a.table_name=upper(''SOURCE_TABLE'') and a.column_name=upper(''SOURCE_COLUMN'') ' ||
						' AND NVL(s.SOURCE_COLUMN,decode(a.DATA_TYPE,''DATE'','''',0))<>NVL(d.DESTINATION_COLUMN,decode(a.DATA_TYPE,''DATE'','''',0))';

	 	For ln_count IN 1..pn_pk_count LOOP
		  ls_sql_template:= ls_sql_template || ' AND d.DESTINATION_PK' || to_char(ln_count) || '(+)=s.SOURCE_PK' || to_char(ln_count);
		END LOOP;

   		return	ls_sql_template;
   END;
--######################################################################################

    Function Degismis(ps_block   VARCHAR2,
  		   				ps_rowid   VARCHAR2,
  		   				ps_column  VARCHAR2,
  		   				ps_newvalue  VARCHAR2,
						ps_oldvalue IN OUT VARCHAR2) return BOOLEAN is
	ls_sql_template					 VARCHAR2(2000);
	ln_retval						   NUMBER:=0;
  BEGIN
	ls_sql_template:=' select 1,to_char(NVL(b.'|| ps_column || ',decode(a.DATA_TYPE,''DATE'','''',0))) from user_tab_columns a ,' || ps_block || ' b ' ||
					 ' where b.rowid=''' || ps_rowid ||  ''' ' ||
				     ' AND a.table_name=upper(''' || ps_block ||''') and a.column_name=upper('''|| ps_column ||''') ' ||
					 ' AND NVL(b.' || ps_column ||',decode(a.DATA_TYPE,''DATE'','''',0))<>NVL(''' || ps_newvalue ||''',decode(a.DATA_TYPE,''DATE'','''',0))';

	execute immediate ls_sql_template into ln_retval,ps_oldvalue;

	if ln_retval<>1 then
		return false;
	else
		return true;
	end if;
  exception
  		   when others then
		   		return false;
  END;
--######################################################################################
END;
/

