create PACKAGE pkg_sms IS

  ----------------------- Customizable Section -----------------------

  -- Customize the SMTP host, port and your domain name below.
  sms_host   VARCHAR2(500) := 'http://api.clickatell.com/http/sendmsg?api_id=2503547&user=timucinaltinpinar&password=demir4kazak&to=';
  sms_port   PLS_INTEGER   := 25;
  sms_domain VARCHAR2(256) := 'demirbank.kz';

  -- Customize the signature that will appear in the email's MIME header.
  -- Useful for versioning.
  MAILER_ID   CONSTANT VARCHAR2(256) := 'SMS by DEMIRBANK';

  -- Send Automatic Messages --JOB--
  PROCEDURE SendAutoSMS(ps_sender in varchar2);

  -- Send Automatic Messages --JOB--
  PROCEDURE AddToSMSQueue(ps_MESSAGE_CODE  in varchar2, ps_PRIORITY in number, ps_RECIPIENT  in varchar2, ps_BODY_CONTENT in varchar2);

  FUNCTION SendSMSMessage(ps_RECIPIENT  in varchar2, ps_BODY_CONTENT in varchar2) return varchar2;

  function url_filter(ps_url varchar2) return varchar2;

END;


/

