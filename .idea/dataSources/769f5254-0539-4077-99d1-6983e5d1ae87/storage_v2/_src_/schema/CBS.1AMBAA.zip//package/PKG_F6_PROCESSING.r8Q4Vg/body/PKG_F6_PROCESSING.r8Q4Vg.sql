create PACKAGE BODY PKG_F6_PROCESSING AS

FUNCTION F6_MESSAGE_TO_JSON(P_MESSAGE VARCHAR2, P_INDEX NUMBER) RETURN VARCHAR2
IS
    tmpVar VARCHAR2(5000);
    responseObj varchar2(5000);
    details varchar2(2000);
    jsonObj JSON_OBJECT_T := JSON_OBJECT_T();
BEGIN
   details := P_MESSAGE;
   jsonObj.put('indexNo', P_INDEX);
   jsonObj.put('Count', TO_NUMBER(PKG_ATM.SATIR_AYIR(details, 9)));
   jsonObj.put('CalculationDate', TO_CHAR(TO_DATE(pkg_atm.satir_ayir(details, 8), 'YYYYMMDD'), 'YYYY-MM-DD'));
   jsonObj.put('CustomerNo', TO_NUMBER(pkg_atm.satir_ayir(details, 13)));
   jsonObj.put('CardNumber', TRIM(pkg_atm.satir_ayir(details, 19)));
   jsonObj.put('TransactionCode', pkg_atm.satir_ayir(details, 2));
   jsonObj.put('TransactionSubCode', NVL(TRIM(pkg_atm.satir_ayir(details, 2)), NULL));
   jsonObj.put('ChannelCode', pkg_atm.satir_ayir(details, 2));
   jsonObj.put('MerchantBranch', NVL(TRIM(pkg_atm.satir_ayir(details, 4)), NULL));
   jsonObj.put('MerchantNumber', NVL(TRIM(pkg_atm.satir_ayir(details, 15)), NULL));
   jsonObj.put('CustomerBranch', pkg_atm.satir_ayir(details, 4));
   jsonObj.put('isResident', pkg_atm.satir_ayir(details, 1));
   jsonObj.put('Currency', NVL(TRIM(pkg_atm.satir_ayir(details, 3)), NULL));
   jsonObj.put('TransactionAmount', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('SettlementCurrency', NVL(TRIM(pkg_atm.satir_ayir(details, 3)), NULL));
   jsonObj.put('SettlementAmount', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('BillingCurrency', NVL(TRIM(pkg_atm.satir_ayir(details, 3)), NULL));
   jsonObj.put('BillingAmountWithoutFee', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('BillingFee', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('DebitCreditFlag', pkg_atm.satir_ayir(details, 1));  
   jsonObj.put('SalesBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('CashBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('OverLimitBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('OtherPricipalDebt', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('LatePaymentFeeBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('IssuanceFeeBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('AnnualFeeBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('FeeBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('InstalmentBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('LatePaymentInterestBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('CreditInterestBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('OverLimitInterestBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('CustomerMoney', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('RevolveLoanBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('RevolveInterestBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('RevolveTaxBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('TaxBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('CutoffInterestBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('MoneySendFeeBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('RevolveInstallmentLoanBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('RevolveFeeTaxBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('LastPeriodFeeTaxBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('LatePaymentInstallmentInterestBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('RevolveInstallmentInterestBalance', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('RRN', NVL(TRIM(pkg_atm.satir_ayir(details, 12)), NULL));
   jsonObj.put('SettlementFlag', NVL(TRIM(pkg_atm.satir_ayir(details, 1)), NULL));
   jsonObj.put('BillingFeeTax', PKG_ATM_FILE.ConvertStringToNumber(pkg_atm.satir_ayir(details, 18)));
   jsonObj.put('Details', P_MESSAGE);  
 
   tmpVar := jsonObj.to_string;
      
   SELECT JSON_SERIALIZE(tmpVar PRETTY)
     INTO responseObj
     FROM DUAL;
     
   RETURN responseObj;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       log_at('F6_MESSAGE_TO_JSON', P_MESSAGE, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     WHEN OTHERS THEN
        log_at('F6_MESSAGE_TO_JSON', P_MESSAGE, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
       DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM || ' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END F6_MESSAGE_TO_JSON;
-------------------------------------------------------------------
PROCEDURE F6_FILE_TO_JSON(P_LINK_DIR VARCHAR2, P_FILE_NAME VARCHAR2, P_TX_NO NUMBER)
IS
    LINE VARCHAR2(2000);
    LINE_TYPE VARCHAR2(1);
    responseObj CLOB;
    lineCount NUMBER;
    v_index NUMBER := 1;
    RRN VARCHAR2(15);
    totalAmount NUMBER;
    jsonObjHeader JSON_OBJECT_T := JSON_OBJECT_T();
    jsonObjTrailer JSON_OBJECT_T := JSON_OBJECT_T();
    jsonObj JSON_OBJECT_T := JSON_OBJECT_T();
    jsonObjList JSON_OBJECT_T := JSON_OBJECT_T();
    jsonList JSON_ARRAY_T := JSON_ARRAY_T();
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    PKG_DOSYA.DOSYA_AC(P_LINK_DIR, P_FILE_NAME, 'r');
    LOOP
        PKG_DOSYA.SATIRAL(LINE);
        LINE_TYPE := PKG_ATM.SATIR_AYIR(LINE, 1);
        IF LINE_TYPE = 'H' THEN
            jsonObjHeader.put('ReferenceNumber', PKG_ATM.SATIR_AYIR(LINE, 10));
        ELSIF LINE_TYPE = 'D' THEN
            jsonObjList := JSON_OBJECT_T.parse(PKG_ATM.F6_MESSAGE_TO_JSON(PKG_ATM.SATIR_AYIR(LINE, 625), v_index));
            v_index := v_index + 1;
            jsonList.append(jsonObjList);
        ELSIF LINE_TYPE = 'T' THEN
            jsonObjTrailer.put('Count', TO_NUMBER(PKG_ATM.SATIR_AYIR(LINE, 9)));
            jsonObjTrailer.put('LineCount', jsonList.get_size);
            jsonObjTrailer.put('TotalBillingAmount', TO_NUMBER(PKG_ATM.SATIR_AYIR(LINE, 19), '9999999999999999.99'));
        END IF;
    END LOOP;
    EXCEPTION 
        WHEN NO_DATA_FOUND THEN
            PKG_DOSYA.DOSYA_KAPA ('r');
            jsonObj.put('Header',jsonObjHeader);
            jsonObj.put('Trailer',jsonObjTrailer);
            jsonObj.put('Details',jsonList);
            responseObj := jsonObj.to_clob;
            lineCount := jsonObjTrailer.get_number('LineCount');
            RRN := jsonObjHeader.get_string('ReferenceNumber');
            totalAmount := jsonObjTrailer.get_number('TotalBillingAmount');
            INSERT INTO CBS.F6_FILE_JSON_LOG(TX_NO, METADATA, FILE_NAME, COUNT_TX_LINE, REFERENCE_NO, TOTAL_AMOUNT) 
              VALUES (P_TX_NO, responseObj, P_FILE_NAME, NVL(lineCount, 0), RRN, NVL(totalAmount, 0));
            COMMIT;
        WHEN OTHERS THEN
            PKG_DOSYA.DOSYA_KAPA ('r');
            log_at('F6_FILE_TO_JSON', P_TX_NO || ' / ' ||P_FILE_NAME, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM || ' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);    
END F6_FILE_TO_JSON;
-----------------------------------------------------------------
END PKG_F6_PROCESSING;
/

