create PACKAGE BODY     pkg_parametre IS

  C_GENERAL_MODUL_CODE constant varchar2(5) := 'GNRL';

  ------------------------------------------------------------------------------------

  FUNCTION COMPILE_TX(pnumber in number,perr out varchar2) return number is

    Cursor c1 is
      Select *
        from cbs_parametre
       where islem_tanim_kod=pnumber
        order by sira;

    r_c1                       c1%ROWTYPE;
    r_c2                       cbs_parametre%ROWTYPE;
    result           number;
  Begin
      open c1;
         Loop
          Fetch c1 into r_c1;
          Exit when c1%notfound;
          if r_c1.tip='N' then
            result:=pkg_parametre.parse_number(r_c1.deger,r_c1.sira,pnumber,
                          r_c2.p_code,r_c2.p_char_val1,r_c2.p_char_val2,
                          r_c2.p_char_val3,r_c2.p_oper1,r_c2.p_oper2,r_c2.p_oper3);
            if result < 0 then
              perr:=' Error occured while parsing parameter '||r_c1.kod||' Error: '||to_char(result);
              return -1;
            end if;
            update cbs_parametre set  P_CODE=r_c2.P_CODE,
                                  P_OPER1=r_c2.P_OPER1,
                                  P_OPER2=r_c2.P_OPER2,
                                  P_OPER3=r_c2.P_OPER3,
                                  P_CHAR_VAL1=r_c2.P_CHAR_VAL1,
                                  P_CHAR_VAL2=r_c2.P_CHAR_VAL2,
                                  P_CHAR_VAL3=r_c2.P_CHAR_VAL3
               where numara=r_c1.numara;
        end if;
          if r_c1.tip='B' then
            result:=pkg_parametre.parse_boolean(r_c1.deger,r_c1.sira,pnumber,
                          r_c2.p_code,r_c2.p_char_val1,r_c2.p_char_val2,
                          r_c2.p_char_val3,r_c2.p_oper1,r_c2.p_oper2,r_c2.p_oper3,r_c2.p_oper_type);
            if result < 0 then
              perr:=' Error occured while parsing parameter '||r_c1.kod||' Error: '||to_char(result);
              return -1;
            end if;
            update cbs_parametre set  P_CODE=r_c2.P_CODE,
                                  P_OPER1=r_c2.P_OPER1,
                                  P_OPER2=r_c2.P_OPER2,
                                  P_OPER3=r_c2.P_OPER3,
                                  P_CHAR_VAL1=r_c2.P_CHAR_VAL1,
                                  P_CHAR_VAL2=r_c2.P_CHAR_VAL2,
                                  P_CHAR_VAL3=r_c2.P_CHAR_VAL3,
                                  P_OPER_TYPE=r_c2.P_OPER_TYPE
               where numara=r_c1.numara;
        end if;
          if r_c1.tip='V' then
            result:=pkg_parametre.parse_varchar(r_c1.deger,r_c1.sira,pnumber,
                          r_c2.p_code,r_c2.p_char_val1,r_c2.p_char_val2,
                          r_c2.p_char_val3,r_c2.p_oper1,r_c2.p_oper2,r_c2.p_oper3);
            if result < 0 then
              perr:=' Error occured while parsing parameter '||r_c1.kod||' Error: '||to_char(result);
              return -1;
            end if;
            update cbs_parametre set  P_CODE=r_c2.P_CODE,
                                  P_OPER1=r_c2.P_OPER1,
                                  P_OPER2=r_c2.P_OPER2,
                                  P_OPER3=r_c2.P_OPER3,
                                  P_CHAR_VAL1=r_c2.P_CHAR_VAL1,
                                  P_CHAR_VAL2=r_c2.P_CHAR_VAL2,
                                  P_CHAR_VAL3=r_c2.P_CHAR_VAL3
               where numara=r_c1.numara;
        end if;
          if r_c1.tip='D' then
            result:=pkg_parametre.parse_date(r_c1.deger,r_c1.sira,pnumber,
                          r_c2.p_code,r_c2.p_char_val1,r_c2.p_char_val2,
                          r_c2.p_char_val3,r_c2.p_oper1,r_c2.p_oper2,r_c2.p_oper3);
            if result < 0 then
              perr:=' Error occured while parsing parameter '||r_c1.kod||' Error: '||to_char(result);
              return -1;
            end if;
            update cbs_parametre set  P_CODE=r_c2.P_CODE,
                                  P_OPER1=r_c2.P_OPER1,
                                  P_OPER2=r_c2.P_OPER2,
                                  P_OPER3=r_c2.P_OPER3,
                                  P_CHAR_VAL1=r_c2.P_CHAR_VAL1,
                                  P_CHAR_VAL2=r_c2.P_CHAR_VAL2,
                                  P_CHAR_VAL3=r_c2.P_CHAR_VAL3
               where numara=r_c1.numara;
        end if;
      end loop;
      close c1;
      commit;
      return 1;
  Exception
    when others then
       rollback;
       perr:=' SQL Error : '||to_char(SQLCODE);
       return -2;
  End;


FUNCTION validate_token(pstring varchar2,token_type varchar2,psira number,pmuh_plan_numara number) RETURN number IS
  first_operand         varchar2(2000);
  second_operand         varchar2(2000);
  temp_numara                number;
  numara_deger             number(35,3);
  operator_position1 number;
  operator_position2 number;
BEGIN
          begin  -- see if it is another parametre
        first_operand:=rtrim(ltrim(pstring));
          select numara
            into temp_numara
            from cbs_parametre
           where ( upper(kod)=first_operand and tip=token_type )
             and ( ( tur ='G' ) or
                   ( tur ='T' and islem_tanim_kod = pmuh_plan_numara and sira < psira)
              ) ;
           return temp_numara; -- found, return the parameter number
        exception
            when no_data_found then
              if token_type ='N' then
                -- not a parametre, is it a number
                second_operand:=translate(first_operand,'.0123456789ABCGDEFGPHI]JKLMNOVPQRS^TU\VWXYZ,;','.0123456789');
                if (second_operand is null) or (length(first_operand)!=length(second_operand)) then
                    return -1;
                end if;
                begin
                  numara_deger:=to_number(first_operand,'999999999999999999.99');
                exception
                    when others then
                      return -1;
                end;
              end if;
              if token_type ='B' then
                -- not a parametre, is it a boolean value
                if (first_operand not in ('T','F','1','0','D','Y')) then
                    return -1;
                end if;
              end if;
              if token_type ='V' then
                operator_position1:=instr(first_operand,'"',1,1);
                operator_position2:=instr(first_operand,'"',operator_position1+1,1);
                if operator_position1=1 and operator_position2=length(first_operand) then
                    return 0;
                else return -1;
                end if;
              end if;
              if token_type ='D' then
                -- date does not accept constant values
                if (first_operand not in ('TODAY','TOMORROW','YESTERDAY','BUGUN','DUN','YARIN')) then
                    return -1;
                end if;
              end if;
        end;
  return 0;
END;

FUNCTION PARSE_BOOLEAN(p1 varchar2,psira number,pmuh_plan_numara number,
                       p_code out number,p_char_val1 out varchar2,p_char_val2 out varchar2,p_char_val3 out varchar2,p_oper1 out number,p_oper2 out number,p_oper3 out number,
                       p_oper_type out number) RETURN NUMBER IS
    temp_numara                    number;
    pointer                         number;
    operator_position     number;
    operator_position2     number;
    pstring                            varchar2(2000);
    string_length                number;
    operator                        varchar2(100);
    first_operand                varchar2(100);
    second_operand            varchar2(100);
    third_operand              varchar2(100);
    result                            number;
    operand_type                varchar2(1);
begin
    p_char_val1:=null;
    p_char_val2:=null;
    p_char_val3:=null;
    p_oper1:=null;
    p_oper2:=null;
    p_oper3:=null;
    p_oper_type:=null;
    pstring:=upper(p1);
    string_length:=length(pstring);
    operator_position:=instr(pstring,'<');
    if operator_position=0 then
      operator_position:=instr(pstring,'>');
      if operator_position=0 then
         operator_position:=instr(pstring,'!');
          if operator_position!=0 then
         first_operand:=substr(pstring,operator_position+1,1);
         if first_operand != '=' then
              return -1;
         end if;
         end if;
         if operator_position=0 then
           operator_position:=instr(pstring,'=');
           if operator_position=0 then
                   operator_position:=instr(pstring,'&');
             if operator_position=0 then
                       operator_position:=instr(pstring,'|');
               if operator_position=0 then
                   p_code:=0; -- no valid operator
               else
                   p_code:=6; -- |
             end if;
             else
                  p_code:=5; -- &
             end if;
           else
                p_code:=4; -- =
           end if;
         else
              p_code:=3; -- !=
         end if;
      else
          p_code:=2; -- >
      end if;
    else
        p_code:=1; -- <
    end if;
    if operator_position!=0 then -- there is a operator
        operator:=substr(pstring,operator_position,1);
        if operator in ('&','|') then
         first_operand:=rtrim(ltrim(substr(pstring,1,operator_position-1)));
      result:=validate_token(first_operand,'B',psira ,pmuh_plan_numara );
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val1:=first_operand;
        else
          p_oper1:=result;
        end if;
         second_operand:=rtrim(ltrim(substr(pstring,operator_position+1,string_length-operator_position)));
      result:=validate_token(second_operand,'B',psira ,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val2:=second_operand;
        else
          p_oper2:=result;
        end if;
        else -- operator is <>!=
         first_operand:=rtrim(ltrim(substr(pstring,1,operator_position-1)));
      result:=validate_token(first_operand,'N',psira,pmuh_plan_numara);
      if result<0 then
        result:=validate_token(first_operand,'V',psira,pmuh_plan_numara);
        if result<0 then
          result:=validate_token(first_operand,'D',psira ,pmuh_plan_numara);
          if result<0 then
            return -1 ; -- unexpected type
          elsif result=0 then
              operand_type:='D';
              p_oper_type:=1;
                p_char_val1:=first_operand;
          else
              p_oper1:=result;
              operand_type:='D';
              p_oper_type:=1;
          end if;
        elsif result=0 then
            operand_type:='V';
              p_char_val1:=substr(first_operand,2,length(first_operand)-2);
          p_oper_type:=2;
        else
            p_oper1:=result;
            operand_type:='V';
          p_oper_type:=2;
        end if;
      elsif result=0 then
            operand_type:='N';
           p_char_val1:=first_operand;
         p_oper_type:=3;
      else
           p_oper1:=result;
            operand_type:='N';
         p_oper_type:=3;
      end if;
      if substr(pstring,operator_position+1,1) = '=' then
          second_operand:=rtrim(ltrim(substr(pstring,operator_position+2,string_length-operator_position-1)));
      else
          second_operand:=rtrim(ltrim(substr(pstring,operator_position+1,string_length-operator_position)));
      end if;
      if operand_type = 'D' then
          result:=validate_token(second_operand,'D',psira ,pmuh_plan_numara );
        if result<0 then
           return -1 ; -- unexpected type
        elsif result=0 then
              p_char_val2:=second_operand;
        else
             p_oper2:=result;
        end if;
        elsif operand_type = 'V' then
          result:=validate_token(second_operand,'V',psira ,pmuh_plan_numara );
        if result<0 then
           return -1 ; -- unexpected type
        elsif result=0 then
              p_char_val2:=substr(second_operand,2,length(second_operand)-2);
        else
             p_oper2:=result;
        end if;
        elsif operand_type = 'N' then
          result:=validate_token(second_operand,'N',psira,pmuh_plan_numara);
        if result<0 then
           return -1 ; -- unexpected type
        elsif result=0 then
              p_char_val2:=second_operand;
        else
             p_oper2:=result;
        end if;
        end if;
    end if;
    else    -- no operator, so validate the token as number
     result:=validate_token(pstring,'B',psira,pmuh_plan_numara);
          p_code:=0;
     if result<0 then
            return -1;
       elsif result=0 then
            p_char_val1:=pstring;
       else
          p_oper1:=result;
       end if;
    end if;
    return 0;
end;

FUNCTION parse_date(p1 varchar2,psira number,pmuh_plan_numara number,
                       p_code out number,p_char_val1 out varchar2,p_char_val2 out varchar2,p_char_val3 out varchar2,p_oper1 out number,p_oper2 out number,p_oper3 out number) RETURN NUMBER IS
    temp_numara                    number;
    pointer                         number;
    operator_position     number;
    operator_position2     number;
    pstring                            varchar2(2000);
    string_length                number;
    operator                        varchar2(100);
    first_operand                varchar2(100);
    second_operand            varchar2(100);
    third_operand              varchar2(100);
    result                            number;
begin
    p_char_val1:=null;
    p_char_val2:=null;
    p_char_val3:=null;
    p_oper1:=null;
    p_oper2:=null;
    p_oper3:=null;
    pstring:=upper(p1);
    string_length:=length(pstring);
  operator_position:=instr(pstring,'?');
    if operator_position!=0 then -- there is a operator
        p_code:=2;
        operator:=substr(pstring,operator_position,1);
       first_operand:=rtrim(ltrim(substr(pstring,1,operator_position-1)));
        operator_position2:=instr(pstring,':');
        if operator_position2=0 then
            return -2; -- : expected
        end if;
        second_operand:=rtrim(ltrim(substr(pstring,operator_position+1,operator_position2-operator_position-1)));
        third_operand:=rtrim(ltrim(substr(pstring,operator_position2+1,string_length-operator_position2)));
      result:=validate_token(first_operand,'B',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val1:=first_operand;
        else
          p_oper1:=result;
        end if;
        result:=validate_token(second_operand,'D',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val2:=second_operand;
        else
          p_oper2:=result;
        end if;
        result:=validate_token(third_operand,'D',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val3:=third_operand;
        else
          p_oper3:=result;
        end if;
    else    -- no operator, so validate the token as date
         p_code:=1;
     result:=validate_token(pstring,'D',psira,pmuh_plan_numara);
     if result<0 then
            return -1;
       elsif result=0 then
            p_char_val1:=pstring;
       else
          p_oper1:=result;
       end if;
    end if;
    return 0;
end;

FUNCTION parse_number(p1 varchar2,psira number,pmuh_plan_numara number,
                       p_code out number,p_char_val1 out varchar2,p_char_val2 out varchar2,p_char_val3 out varchar2,p_oper1 out number,p_oper2 out number,p_oper3 out number) RETURN NUMBER IS
    temp_numara                    number;
    pointer                         number;
    operator_position     number;
    operator_position2     number;
    pstring                            varchar2(2000);
    string_length                number;
    operator                        varchar2(100);
    first_operand                varchar2(100);
    second_operand            varchar2(100);
    third_operand              varchar2(100);
    result                            number;
begin
    p_char_val1:=null;
    p_char_val2:=null;
    p_char_val3:=null;
    p_oper1:=null;
    p_oper2:=null;
    p_oper3:=null;
    pstring:=upper(p1);
    string_length:=length(pstring);
    operator_position:=instr(pstring,'+');
    if operator_position=0 then
      operator_position:=instr(pstring,'-');
      if operator_position=0 then
        operator_position:=instr(pstring,'*');
        if operator_position=0 then
          operator_position:=instr(pstring,'/');
          if operator_position=0 then
            operator_position:=instr(pstring,'?');
                    if operator_position=0 then
                      p_code:=6; -- No Operator
                    else
                        p_code:=5; -- ?
                    end if;
          else
               p_code:=4; -- /
          end if;
        else
            p_code:=3;-- *
        end if;
      else
          p_code:=2; -- -
      end if;
    else
        p_code:=1; --  +
    end if;
    if operator_position!=0 then -- there is a operator
        operator:=substr(pstring,operator_position,1);
       first_operand:=rtrim(ltrim(substr(pstring,1,operator_position-1)));
        if operator = '?' then  -- there are 3 operand
        operator_position2:=instr(pstring,':');
        if operator_position2=0 then
            return -2; -- : expected
        end if;
        second_operand:=rtrim(ltrim(substr(pstring,operator_position+1,operator_position2-operator_position-1)));
        third_operand:=rtrim(ltrim(substr(pstring,operator_position2+1,string_length-operator_position2)));
      result:=validate_token(first_operand,'B',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val1:=first_operand;
        else
          p_oper1:=result;
        end if;
      result:=validate_token(second_operand,'N',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val2:=second_operand;
        else
          p_oper2:=result;
        end if;
      result:=validate_token(third_operand,'N',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val3:=third_operand;
        else
          p_oper3:=result;
        end if;
    else
      result:=validate_token(first_operand,'N',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val1:=first_operand;
        else
          p_oper1:=result;
        end if;
        second_operand:=rtrim(ltrim(substr(pstring,operator_position+1,string_length-operator_position)));
        result:=validate_token(second_operand,'N',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val2:=second_operand;
        else
          p_oper2:=result;
        end if;
      end if;
        else    -- no operator, so validate the token as number
            result:=validate_token(pstring,'N',psira,pmuh_plan_numara);
        if result<0 then
            return -1;
        elsif result=0 then
            p_char_val1:=pstring;
        else
          p_oper1:=result;
        end if;
    end if;
    return 0;
end;

  FUNCTION parse_varchar(p1 varchar2,psira number,pmuh_plan_numara number,
                         p_code out number,p_char_val1 out varchar2,p_char_val2 out varchar2,p_char_val3 out varchar2,p_oper1 out number,p_oper2 out number,p_oper3 out number) RETURN NUMBER IS
      temp_numara                    number;
      pointer                         number;
      operator_position     number;
      operator_position2     number;
      pstring                            varchar2(2000);
      string_length                number;
      operator                        varchar2(100);
      first_operand                varchar2(100);
      second_operand            varchar2(100);
      third_operand              varchar2(100);
      result                            number;
  begin
      p_char_val1:=null;
      p_char_val2:=null;
      p_char_val3:=null;
      p_oper1:=null;
      p_oper2:=null;
      p_oper3:=null;
      pstring:=upper(p1);
      string_length:=length(pstring);
      operator_position:=instr(pstring,'+');
      if operator_position=0 then
        operator_position:=instr(pstring,'?');
      end if;
      if operator_position!=0 then -- there is a operator
          operator:=substr(pstring,operator_position,1);
         first_operand:=rtrim(ltrim(substr(pstring,1,operator_position-1)));
          if operator = '?' then  -- there are 3 operand
              p_code:=2;
          operator_position2:=instr(pstring,':');
          if operator_position2=0 then
              return -2; -- : expected
          end if;
          second_operand:=rtrim(ltrim(substr(pstring,operator_position+1,operator_position2-operator_position-1)));
          third_operand:=rtrim(ltrim(substr(pstring,operator_position2+1,string_length-operator_position2)));
        result:=validate_token(first_operand,'B',psira,pmuh_plan_numara);
          if result<0 then
              return -1;
          elsif result=0 then
              p_char_val1:=first_operand;
          else
            p_oper1:=result;
          end if;
          result:=validate_token(second_operand,'V',psira,pmuh_plan_numara);
          if result<0 then
              return -1;
          elsif result=0 then
              p_char_val2:=substr(second_operand,2,length(second_operand)-2);
          else
            p_oper2:=result;
          end if;
          result:=validate_token(third_operand,'V',psira,pmuh_plan_numara);
          if result<0 then
              return -1;
          elsif result=0 then
              p_char_val3:=substr(third_operand,2,length(third_operand)-2);
          else
            p_oper3:=result;
          end if;
     else       -- there are 2 operands
              p_code:=1;
        result:=validate_token(first_operand,'V',psira,pmuh_plan_numara);
          if result<0 then
              return -1;
          elsif result=0 then
              p_char_val1:=substr(first_operand,2,length(first_operand)-2);
          else
            p_oper1:=result;
          end if;
        second_operand:=rtrim(ltrim(substr(pstring,operator_position+1,string_length-operator_position)));
          result:=validate_token(second_operand,'V',psira,pmuh_plan_numara);
          if result<0 then
              return -1;
          elsif result=0 then
              p_char_val2:=substr(second_operand,2,length(second_operand)-2);
          else
            p_oper2:=result;
          end if;
    end if;
      else    -- no operator, so validate the token as varchar
        result:=validate_token(pstring,'V',psira,pmuh_plan_numara);
           p_code:=0;
          if result<0 then
              return -1;
          elsif result=0 then
              p_char_val1:=substr(pstring,2,length(pstring)-2);
          else
            p_oper1:=result;
          end if;
           return 0;
      end if;
      return 0;
  end;

------------------
  PROCEDURE Deger (pKod in varchar2, pdeger out number) is
  begin
    select to_number(p.deger)
      into pdeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod ||pkg_hata.getUCPOINTER);
  end;

  PROCEDURE Deger (pKod in varchar2, pdeger out varchar2) is
  temp_Deger varchar2(2000);
  begin
    select p.deger
      into temp_Deger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    pdeger  := substr(temp_deger,2,length(temp_deger)-2);
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod||pkg_hata.getUCPOINTER);
  end;

  PROCEDURE Deger (pKod in varchar2, pdeger out date) is
  begin
    select to_date(p.deger,'dd/mm/yyyy')
      into pdeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod||pkg_hata.getUCPOINTER);
  end;

  PROCEDURE Deger (pKod in varchar2, pdeger out boolean) is
    ddeger varchar2(5);
  begin
    select DECODE(UPPER(TRIM(deger)),'T','TRUE','1','TRUE','D','TRUE','FALSE')
      into ddeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    pdeger:=ddeger='TRUE';
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod||pkg_hata.getUCPOINTER);
  end;

------------------

  PROCEDURE deger ( pModul_Tur_Kod  in varchar2,
                    pUrun_Tur_Kod   in varchar2,
                    pUrun_Sinif_Kod in varchar2,
                    pKod            in varchar2,
                    pdeger          out number
              ) is

    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;

   cursor c1 is
        Select usp.Deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
   cursor c2 is
      Select usp.Deger
        from cbs_urun_tur_parametre usp,cbs_parametre
       where usp.modul_tur_kod = pmodul_tur_kod
          and usp.urun_tur_kod = purun_tur_kod
         and parametre_numara = numara
         and upper(kod) = upper(pkod);
     cursor c3 is
           Select deger
             from cbs_Parametre
            where modul_tur_kod = pmodul_tur_kod
           and upper(kod) = upper(pkod);

  BEGIN
            open c1;
          fetch c1 into Temp_deger;
          if c1%found then
             close c1;
             pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
             Return;
          end if;
      close c1;
          open c2;
          fetch c2 into Temp_deger;
          if c2%found then
             close c2;
             pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
                Return;
          end if;
          close c2;
            open c3;
            fetch c3 into temp_deger;
             if c3%found then
               close c3;
               pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
               Return;
            else
              close c3;
              Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1029'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
            end if;
   Exception
    When others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1028'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
End;



  Procedure Deger ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
               ,pdeger          out varchar2
              ) is
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    Temp_deger2 cbs_urun_sinif_parametre.deger%TYPE;
    p_length number;

    cursor c1 is
        select usp.deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
    cursor c2 is
         select usp.deger
        into temp_deger
        from cbs_urun_tur_parametre usp,cbs_parametre
       where usp.modul_tur_kod = pmodul_tur_kod
         and usp.urun_tur_kod = purun_tur_kod
         and parametre_numara = numara
         and upper(kod) = upper(pkod);
    cursor c3 is
      select deger
        into temp_deger
        from cbs_parametre
       where modul_tur_kod = pmodul_tur_kod
         and upper(kod)    = upper(pkod);

  BEGIN
        open c1;
      fetch c1 into temp_deger;
      if c1%found then
        close c1;
           temp_deger:=ltrim(rtrim(temp_deger));
          p_length:=length(temp_deger);
          pdeger:= substr(temp_deger,2,p_length-2);
          return;
      end if;
      close c1;
          open c2;
          fetch c2 into temp_deger;
          if c2%found then
            close c2;
            temp_deger:=ltrim(rtrim(temp_deger));
            p_length:=length(temp_deger);
            pdeger:= substr(temp_deger,2,p_length-2);
            return;
          end if;
          close c2;
              open c3;
              fetch c3 into temp_deger;
              if c3%found then
                close c3;
                temp_deger:=ltrim(rtrim(temp_deger));
                p_length:=length(temp_deger);
                pdeger:= substr(temp_deger,2,p_length-2);
                return;
              else
                close c3;
                Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1029'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
              end if;

    exception
      when others then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1028'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
  END;
------------------------------------
  Function Deger ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
              ) return varchar2 is
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    Temp_deger2 cbs_urun_sinif_parametre.deger%TYPE;
    p_length number;
    pdeger     varchar2(20);

    cursor c1 is
        select usp.deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
    cursor c2 is
         select usp.deger
        into temp_deger
        from cbs_urun_tur_parametre usp,cbs_parametre
       where usp.modul_tur_kod = pmodul_tur_kod
         and usp.urun_tur_kod = purun_tur_kod
         and parametre_numara = numara
         and upper(kod) = upper(pkod);
    cursor c3 is
      select deger
        into temp_deger
        from cbs_parametre
       where modul_tur_kod = pmodul_tur_kod
         and upper(kod)    = upper(pkod);

  BEGIN
        open c1;
      fetch c1 into temp_deger;
      if c1%found then
        close c1;
           temp_deger:=ltrim(rtrim(temp_deger));
          p_length:=length(temp_deger);
          pdeger:= substr(temp_deger,2,p_length-2);
          return pdeger;
      end if;
      close c1;
          open c2;
          fetch c2 into temp_deger;
          if c2%found then
            close c2;
            temp_deger:=ltrim(rtrim(temp_deger));
            p_length:=length(temp_deger);
            pdeger:= substr(temp_deger,2,p_length-2);
            return pdeger;
          end if;
          close c2;
              open c3;
              fetch c3 into temp_deger;
              if c3%found then
                close c3;
                temp_deger:=ltrim(rtrim(temp_deger));
                p_length:=length(temp_deger);
                pdeger:= substr(temp_deger,2,p_length-2);
                return pdeger;
              else
                close c3;
                Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1029'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
              end if;
        return pdeger;
    exception
      when others then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1028'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
  END;

-------------------------------------
  Function Banka_tarihi_bul return date is
   ld_tarih date;
  Begin
      select banka_tarihi
        into ld_tarih
        from cbs_system;
      return ld_tarih;
  Exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1030'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
  End;

  Function Sonraki_Banka_tarihi_bul return date is
   ld_tarih date;
  Begin
      select sonraki_banka_tarihi
        into ld_tarih
        from cbs_system;
      return ld_tarih;
  Exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1030'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
  End;

  Function Onceki_banka_tarihi_bul return date is
   ld_tarih date;
  Begin
      select onceki_banka_tarihi
        into ld_tarih
        from cbs_system;
      return ld_tarih;
  Exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1030'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
  End;

  Procedure Deger( pModul_Tur_Kod    in varchar2
               ,pUrun_Tur_Kod     in varchar2
               ,pUrun_Sinif_Kod   in varchar2
               ,pKod              in varchar2
               ,pdeger            out date
              ) is
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    p_length number;
    cursor c1 is
        Select usp.Deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
     cursor c2 is
          Select usp.Deger
            from cbs_urun_tur_parametre usp,cbs_parametre
           where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
             and parametre_numara = numara
             and upper(kod) = upper(pkod);
     cursor c3 is
          select deger
          from cbs_parametre
         where modul_tur_kod = pmodul_tur_kod
           and upper(kod)    = upper(pkod);


  BEGIN
        open c1;
      fetch c1 into Temp_deger;
      if c1%found then
       close c1;
         if temp_deger in ('TODAY','BUGUN') then
              pdeger:=banka_tarihi_bul;
         end if;
         if temp_deger in ('YESTERDAY','DUN') then
              pdeger:=onceki_banka_tarihi_bul;
         end if;
         if temp_deger in ('TOMORROW','YARIN') then
              pdeger:=sonraki_banka_tarihi_bul;
         end if;
         Return;
      end if;
      close c1;
            open c2;
            fetch c2 into Temp_deger;
            if c2%found then
               close c2;
                 if temp_deger in ('TODAY','BUGUN') then
                   pdeger:=banka_tarihi_bul;
                 end if;
                 if temp_deger in ('YESTERDAY','DUN') then
                    pdeger:=onceki_banka_tarihi_bul;
                 end if;
                 if temp_deger in ('TOMORROW','YARIN') then
                    pdeger:=sonraki_banka_tarihi_bul;
                 end if;
                 return;
            end if;
            close c2;
                  open c3;
                  fetch c3 into temp_deger;
                  if c3%found then
                     close c3;
                     if temp_deger in ('TODAY','BUGUN') then
                       pdeger:=banka_tarihi_bul;
                     end if;
                     if temp_deger in ('YESTERDAY','DUN') then
                       pdeger:=onceki_banka_tarihi_bul;
                     end if;
                     if temp_deger in ('TOMORROW','YARIN') then
                       pdeger:=sonraki_banka_tarihi_bul;
                     end if;
                     return;
                  else
                    close c3;
                    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1029'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
                  end if;
     exception
      when others then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1028'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
  end;

  Procedure Deger ( pModul_Tur_Kod     in varchar2
               ,pUrun_Tur_Kod      in varchar2
               ,pUrun_Sinif_Kod    in varchar2
               ,pKod               in varchar2
               ,pdeger             out boolean
              )  is
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    p_length number;
    cursor c1 is
        Select usp.Deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
     cursor c2 is
       Select usp.Deger
         from cbs_urun_tur_parametre usp,cbs_parametre
        where usp.modul_tur_kod = pmodul_tur_kod
          and usp.urun_tur_kod = purun_tur_kod
          and parametre_numara = numara
          and upper(kod) = upper(pkod);
     cursor c3 is
       Select deger
         from cbs_Parametre
        where modul_tur_kod = pmodul_tur_kod
          and upper(kod)    = upper(pkod);

  BEGIN
    open c1;
    fetch c1 into Temp_deger;
    if c1%found then
       close c1;
       temp_deger:=upper(ltrim(rtrim(temp_deger)));
          if ( temp_deger in ('T','1','D')) then
            pdeger:=TRUE;
          else
            pdeger:=FALSE;
          end if;
         Return;
    end if;
    close c1;
          open c2;
          fetch c2 into Temp_deger;
          if c2%found then
            close c2;
            temp_deger:=upper(ltrim(rtrim(temp_deger)));
            if ( temp_deger in ('T','1','D')) then
                 pdeger:=TRUE;
            else
                pdeger:=FALSE;
            end if;
            Return;
          end if;
          close c2;
                  open c3;
                fetch c3 into temp_deger;
                if c3%found then
                   close c3;
                   temp_deger:=upper(ltrim(rtrim(temp_deger)));
                   if ( temp_deger in ('T','1','D')) then
                     pdeger:=TRUE;
                   else
                     pdeger:=FALSE;
                   end if;
                     Return;
                else
                  close c3;
                  Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1029'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
                end if;
    exception
    When others then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1028'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
  END;

  FUNCTION Al ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
               ,pdeger          out number
              ) return number is

  -- Return Codes
  -- -1701 Parametre bulunamadi
  -- -2000 Others
  -- 1 Parametre bulundu
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    cursor c1 is
        Select usp.Deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
    cursor c2 is
      Select usp.Deger
        from cbs_urun_tur_parametre usp,cbs_parametre
       where usp.modul_tur_kod = pmodul_tur_kod
         and usp.urun_tur_kod = purun_tur_kod
         and parametre_numara = numara
         and upper(kod) = upper(pkod);
    cursor c3 is
      Select deger
        from cbs_Parametre
       where modul_tur_kod = pmodul_tur_kod
         and upper(kod) = upper(pkod);

  BEGIN
   begin
    open c1;
    fetch c1 into Temp_deger;
    if c1%found then
       close c1;
       pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
         Return 1;
    end if;
    close c1;
          open c2;
          fetch c2 into Temp_deger;
          if c2%found then
             close c2;
             pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
               Return 1;
          end if;
          close c2;
                open c3;
                fetch c3 into temp_deger;
                if c3%found then
                   close c3;
                   pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
                   Return 1;
                else
                  close c3;
                  null; -- Continue searching under GENERAL PARAMETERS
                  -- return -1;
                end if;
    exception
     When others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 3');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    End;

    -- Try to find parameter under  GENERAL MODULE
    ---------------------------------------------------------------
    begin

      select deger
          into temp_deger
          from cbs_parametre
         where modul_tur_kod = C_GENERAL_MODUL_CODE
         and upper(kod) = upper(pkod);

      pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
        return 1;

    exception
        when no_data_found then
--        pkg_hata_kontrol.parametre_deger(1,upper(pkod));
--        pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 1 ');
        return -1701;  -- Undefined Parameter : %%1 %%2
      when others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 4');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    end;

    /*
    begin

        select usp.deger
          into temp_deger
          from urun_sinif_parametre usp,parametre
         where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
           and parametre_numara  = numara
           and upper(kod)        = upper(pkod);

       pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
         return 1;

    exception
        when no_data_found then

          begin
                select usp.deger
                  into temp_deger
                  from urun_tur_parametre usp,parametre
                 where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
                   and parametre_numara  = numara
                   and upper(kod)        = upper(pkod);

               pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
                 return 1;

           exception
               when no_data_found then
                    begin
                            select deger
                              into temp_deger
                              from Parametre
                             where modul_tur_kod = C_GENERAL_MODUL_CODE
                             and upper(kod) = upper(pkod);
                          pdeger:=to_number(temp_deger,'99999999999999999999999999999999999.999');
                            return 1;
                    exception
                            when no_data_found then
                            pkg_hata_kontrol.parametre_deger(1,upper(pkod));
                            pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 1 ');
                            return -1701;  -- Undefined Parameter : %%1 %%2
                          when others then
                              pkg_hata_kontrol.parametre_deger(1,sqlerrm);
                              pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 4');pkg_hata_kontrol.push(-2000000);
                              return -2000000;
                    end;
                when others then
                        pkg_hata_kontrol.parametre_deger(1,sqlerrm);
                        pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 5');pkg_hata_kontrol.push(-2000000);
                        return -2000000;
              end;

      when others then
          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 6');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    end;
    */

  EXCEPTION
    when others then
--      pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--      pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 7');pkg_hata_kontrol.push(-2000000);
      return -2000000;
  END;

  FUNCTION Varchar_Al ( pModul_Tur_Kod    in varchar2
                       ,pUrun_Tur_Kod     in varchar2
                       ,pUrun_Sinif_Kod   in varchar2
                       ,pKod in varchar2
                      ) return varchar2 is
    p_temp  varchar2(2000);
    p_sonuc number;
  Begin
      p_sonuc:=Al(pModul_Tur_Kod, pUrun_Tur_Kod, pUrun_Sinif_Kod, pKod,p_temp);
      if p_sonuc <0 then
          return '';
      end if;
    return p_temp;
  End;

  FUNCTION Number_Al ( pModul_Tur_Kod    in varchar2
                      ,pUrun_Tur_Kod     in varchar2
                      ,pUrun_Sinif_Kod   in varchar2
                      ,pKod              in varchar2
                     ) return number is
    p_temp  number;
    p_sonuc number;
  Begin

      p_sonuc:=Al(pModul_Tur_Kod, pUrun_Tur_Kod, pUrun_Sinif_Kod, pKod,p_temp);
      if p_sonuc <0 then
          return 0;
      end if;
    return p_temp;

  End;

  FUNCTION Al ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
               ,pdeger          out varchar2
              ) return number is
  -- Return Codes
  -- -1 Parametre bulunamadi
  -- -2 Others
  -- 1 Parametre bulundu
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    Temp_deger2 cbs_urun_sinif_parametre.deger%TYPE;
    p_length number;
  BEGIN
    begin
        select usp.deger
          into temp_deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
         temp_deger:=ltrim(rtrim(temp_deger));
         p_length:=length(temp_deger);
         pdeger:= substr(temp_deger,2,p_length-2);
         return 1;
    exception
        when no_data_found then
      begin
          select usp.deger
            into temp_deger
            from cbs_urun_tur_parametre usp,cbs_parametre
           where usp.modul_tur_kod = pmodul_tur_kod
             and usp.urun_tur_kod = purun_tur_kod
             and parametre_numara = numara
             and upper(kod) = upper(pkod);
           temp_deger:=ltrim(rtrim(temp_deger));
           p_length:=length(temp_deger);
           pdeger:= substr(temp_deger,2,p_length-2);
           return 1;
      exception
          when no_data_found then
           begin

                select deger
                  into temp_deger
                  from cbs_parametre
                 where modul_tur_kod = pmodul_tur_kod
                 and upper(kod)    = upper(pkod);

                 temp_deger:=ltrim(rtrim(temp_deger));
                 p_length:=length(temp_deger);
                 pdeger:= substr(temp_deger,2,p_length-2);

               return 1;

           exception
                when no_data_found then
                null ; -- Continue searching under GENERAL PARAMETERS
                --return -1;
              when others then
--                  pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--                  pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 8');pkg_hata_kontrol.push(-2000000);
                  return -2000000;
           end;

        when others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 9');pkg_hata_kontrol.push(-2000000);
          return -2000000;

        end;
      when others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 10');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    end;

    -- Try to find parameter under GENERAL PARAMETERS
    ---------------------------------------------------------------
    Begin

       Select deger
        into temp_deger
        from cbs_parametre
        where modul_tur_kod = C_GENERAL_MODUL_CODE
           and upper(kod)    = upper(pkod);

       temp_deger:=ltrim(rtrim(temp_deger));
       p_length:=length(temp_deger);
       pdeger:= substr(temp_deger,2,p_length-2);

      return 1;

    Exception
     When no_data_found then
--          pkg_hata_kontrol.parametre_deger(1,upper(pkod));
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 2');
          return -1701;  -- Undefined Parameter : %%1 %%2
      When others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 11');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    End;

    /*
    Begin
        Select usp.Deger
          into Temp_deger
          from urun_sinif_parametre usp,parametre
         where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
         temp_deger:=ltrim(rtrim(temp_deger));
         p_length:=length(temp_deger);
         pdeger:= substr(temp_deger,2,p_length-2);
         Return 1;
    Exception
        When no_data_found then
      Begin

          Select usp.Deger
            into Temp_deger
            from urun_tur_parametre usp,parametre
           where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
             and parametre_numara  = numara
             and upper(kod)        = upper(pkod);

           temp_deger:=ltrim(rtrim(temp_deger));
           p_length:=length(temp_deger);
           pdeger:= substr(temp_deger,2,p_length-2);
           Return 1;

      Exception
          When no_data_found then
         Begin

             Select deger
                 into temp_deger
                 from Parametre
                 where modul_tur_kod = C_GENERAL_MODUL_CODE
                 and upper(kod)    = upper(pkod);

             temp_deger:=ltrim(rtrim(temp_deger));
               p_length:=length(temp_deger);
               pdeger:= substr(temp_deger,2,p_length-2);

               Return 1;

         Exception
              When no_data_found then
                pkg_hata_kontrol.parametre_deger(1,upper(pkod));
                pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 2');
                return -1701;  -- Undefined Parameter : %%1 %%2
            When others then
                pkg_hata_kontrol.parametre_deger(1,sqlerrm);
                pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 11');pkg_hata_kontrol.push(-2000000);
                return -2000000;
         End;
        When others then
            pkg_hata_kontrol.parametre_deger(1,sqlerrm);
            pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 12');pkg_hata_kontrol.push(-2000000);
            return -2000000;
        End;
      When others then
          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 13');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    End;
    */
  EXCEPTION
      when others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 14');pkg_hata_kontrol.push(-2000000);
          return -2000000;
  END;

  FUNCTION Al ( pModul_Tur_Kod    in varchar2
               ,pUrun_Tur_Kod     in varchar2
               ,pUrun_Sinif_Kod   in varchar2
               ,pKod              in varchar2
               ,pdeger            out date
              ) return number is
  -- Return Codes
  -- -1 Parametre bulunamadi
  -- -2 Others
  -- 1 Parametre bulundu
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    p_length number;
  BEGIN
    Begin
        Select usp.Deger
          into Temp_deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
         if temp_deger in ('TODAY','BUGUN') then
             pdeger:=pkg_muhasebe.banka_tarihi_bul;
         end if;
         if temp_deger in ('YESTERDAY','DUN') then
             pdeger:=pkg_muhasebe.onceki_banka_tarihi_bul;
         end if;
         if temp_deger in ('TOMORROW','YARIN') then
             pdeger:=pkg_muhasebe.sonraki_banka_tarihi_bul;
         end if;
         Return 1;
    Exception
        When no_data_found then
      Begin
          Select usp.Deger
            into Temp_deger
            from cbs_urun_tur_parametre usp,cbs_parametre
           where usp.modul_tur_kod = pmodul_tur_kod
             and usp.urun_tur_kod = purun_tur_kod
             and parametre_numara = numara
             and upper(kod) = upper(pkod);
           if temp_deger in ('TODAY','BUGUN') then
               pdeger:=pkg_muhasebe.banka_tarihi_bul;
           end if;
           if temp_deger in ('YESTERDAY','DUN') then
               pdeger:=pkg_muhasebe.onceki_banka_tarihi_bul;
           end if;
           if temp_deger in ('TOMORROW','YARIN') then
               pdeger:=pkg_muhasebe.sonraki_banka_tarihi_bul;
           end if;
           return 1;

      exception
          when no_data_found then
          begin

                select deger
                  into temp_deger
                  from cbs_parametre
                  where modul_tur_kod = pmodul_tur_kod
                  and upper(kod)    = upper(pkod);

                if temp_deger in ('TODAY','BUGUN') then
                    pdeger:=pkg_muhasebe.banka_tarihi_bul;
                end if;
                if temp_deger in ('YESTERDAY','DUN') then
                    pdeger:=pkg_muhasebe.onceki_banka_tarihi_bul;
                end if;
                if temp_deger in ('TOMORROW','YARIN') then
                    pdeger:=pkg_muhasebe.sonraki_banka_tarihi_bul;
                end if;
                return 1;

          exception
              when no_data_found then
                  null ; -- Continue searching under GENERAL PARAMETERS
                  --return -1;
            when others then
--                pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--                pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 15');pkg_hata_kontrol.push(-2000000);
                return -2000000;
          end;
        when others then
--              pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--              pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 16');pkg_hata_kontrol.push(-2000000);
              return -2000000;
      end;
      when others then
--            pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--            pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 17');pkg_hata_kontrol.push(-2000000);
            return -2000000;
    end;

    -- Try to find parameter under GENERAL PARAMETERS
    ---------------------------------------------------------------
     begin

        select deger
          into temp_deger
          from cbs_parametre
         where modul_tur_kod = C_GENERAL_MODUL_CODE
           and upper(kod)    = upper(pkod);

        if temp_deger in ('TODAY','BUGUN') then
           pdeger:=pkg_muhasebe.banka_tarihi_bul;
        end if;

        if temp_deger in ('YESTERDAY','DUN') then
           pdeger:=pkg_muhasebe.onceki_banka_tarihi_bul;
        end if;

        if temp_deger in ('TOMORROW','YARIN') then
           pdeger:=pkg_muhasebe.sonraki_banka_tarihi_bul;
        end if;

        return 1;

    exception
         when no_data_found then
--              pkg_hata_kontrol.parametre_deger(1,upper(pkod));
--              pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 3');
              return -1701;  -- Undefined Parameter : %%1 %%2
          when others then
--              pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--              pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 18');pkg_hata_kontrol.push(-2000000);
              return -2000000;
    end;

    /*
    Begin

        Select usp.Deger
          into Temp_deger
          from urun_sinif_parametre usp,parametre
         where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
           and parametre_numara = numara
           and upper(kod) = upper(pkod);

         if temp_deger in ('TODAY','BUGUN') then
             pdeger:=pkg_muhasebe.banka_tarihi_bul;
         end if;
         if temp_deger in ('YESTERDAY','DUN') then
             pdeger:=pkg_muhasebe.onceki_banka_tarihi_bul;
         end if;
         if temp_deger in ('TOMORROW','YARIN') then
             pdeger:=pkg_muhasebe.sonraki_banka_tarihi_bul;
         end if;
         Return 1;
    Exception
        When no_data_found then
      Begin
          Select usp.Deger
            into Temp_deger
            from urun_tur_parametre usp,parametre
           where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
             and parametre_numara = numara
             and upper(kod) = upper(pkod);
           if temp_deger in ('TODAY','BUGUN') then
               pdeger:=pkg_muhasebe.banka_tarihi_bul;
           end if;
           if temp_deger in ('YESTERDAY','DUN') then
               pdeger:=pkg_muhasebe.onceki_banka_tarihi_bul;
           end if;
           if temp_deger in ('TOMORROW','YARIN') then
               pdeger:=pkg_muhasebe.sonraki_banka_tarihi_bul;
           end if;
           return 1;

      exception
          when no_data_found then
          begin

                select deger
                  into temp_deger
                  from parametre
                  where modul_tur_kod = C_GENERAL_MODUL_CODE
                  and upper(kod)    = upper(pkod);

                if temp_deger in ('TODAY','BUGUN') then
                    pdeger:=pkg_muhasebe.banka_tarihi_bul;
                end if;
                if temp_deger in ('YESTERDAY','DUN') then
                    pdeger:=pkg_muhasebe.onceki_banka_tarihi_bul;
                end if;
                if temp_deger in ('TOMORROW','YARIN') then
                    pdeger:=pkg_muhasebe.sonraki_banka_tarihi_bul;
                end if;
                return 1;

          exception
              when no_data_found then
                pkg_hata_kontrol.parametre_deger(1,upper(pkod));
                pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 3');
                return -1701;  -- Undefined Parameter : %%1 %%2
            when others then
                pkg_hata_kontrol.parametre_deger(1,sqlerrm);
                pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 18');pkg_hata_kontrol.push(-2000000);
                return -2000000;
          end;
        when others then
            pkg_hata_kontrol.parametre_deger(1,sqlerrm);
            pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 19');pkg_hata_kontrol.push(-2000000);
            return -2000000;
      end;
      when others then
          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 20');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    end;
    */

  exception
      when others then
--        pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--        pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 21');pkg_hata_kontrol.push(-2000000);
        return -2000000;
  end;

  FUNCTION Al ( pModul_Tur_Kod     in varchar2
               ,pUrun_Tur_Kod      in varchar2
               ,pUrun_Sinif_Kod    in varchar2
               ,pKod               in varchar2
               ,pdeger             out boolean
              ) return number is
  -- Return Codes
  -- -1 Parametre bulunamadi
  -- -2 Others
  -- 1 Parametre bulundu
    Temp_deger cbs_urun_sinif_parametre.deger%TYPE;
    p_length number;
  BEGIN
    Begin
        Select usp.Deger
          into Temp_deger
          from cbs_urun_sinif_parametre usp,cbs_parametre
         where usp.modul_tur_kod = pmodul_tur_kod
           and usp.urun_tur_kod = purun_tur_kod
           and usp.urun_sinif_kod = purun_sinif_kod
           and parametre_numara = numara
           and upper(kod) = upper(pkod);
            temp_deger:=upper(ltrim(rtrim(temp_deger)));
          if ( temp_deger in ('T','1','D')) then
            pdeger:=TRUE;
          else
            pdeger:=FALSE;
          end if;
         Return 1;
    Exception
        When no_data_found then
          Begin
              Select usp.Deger
               into Temp_deger
               from cbs_urun_tur_parametre usp,cbs_parametre
              where usp.modul_tur_kod = pmodul_tur_kod
                and usp.urun_tur_kod = purun_tur_kod
                and parametre_numara = numara
                and upper(kod) = upper(pkod);
                 temp_deger:=upper(ltrim(rtrim(temp_deger)));
               if ( temp_deger in ('T','1','D')) then
                 pdeger:=TRUE;
               else
                 pdeger:=FALSE;
               end if;
              Return 1;
         Exception
             When no_data_found then
                 Begin

                     Select deger
                       into temp_deger
                       from cbs_Parametre
                       where modul_tur_kod = pmodul_tur_kod
                       and upper(kod)    = upper(pkod);

                     temp_deger:=upper(ltrim(rtrim(temp_deger)));
                   if ( temp_deger in ('T','1','D')) then
                     pdeger:=TRUE;
                   else
                     pdeger:=FALSE;
                   end if;
                     Return 1;
                 Exception
                        When no_data_found then
                          null ; -- Continue searching under GENERAL PARAMETERS
                          --return -1;
                     When others then
                          -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
                          -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 22');pkg_hata_kontrol.push(-2000000);
                          return -2000000;
                 End;

            When others then
                  -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
                  -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 23');pkg_hata_kontrol.push(-2000000);
                  return -2000000;
         End;

    When others then
        -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
        -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 24');pkg_hata_kontrol.push(-2000000);
        return -2000000;
    End;

    -- Try to find parameter under GENERAL PARAMETERS
    ---------------------------------------------------------------
    Begin

        select deger
          into temp_deger
          from cbs_parametre
           where modul_tur_kod = C_GENERAL_MODUL_CODE
           and upper(kod)    = upper(pkod);

        temp_deger:=upper(ltrim(rtrim(temp_deger)));
        if ( temp_deger in ('T','1','D')) then
           pdeger:=TRUE;
        else
           pdeger:=FALSE;
        end if;
        return 1;

    Exception
         When no_data_found then
          -- pkg_hata_kontrol.parametre_deger(1,upper(pkod));
          -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 4');
          return -1701;  -- Undefined Parameter : %%1 %%2
       When others then
            -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
            -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 25');pkg_hata_kontrol.push(-2000000);
            return -2000000;
    End;

    /*
    Begin

        Select usp.Deger
          into Temp_deger
          from urun_sinif_parametre usp,parametre
          where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
            and parametre_numara  = numara
            and upper(kod)        = upper(pkod);

        temp_deger:=upper(ltrim(rtrim(temp_deger)));
        if ( temp_deger in ('T','1','D')) then
          pdeger:=TRUE;
        else
          pdeger:=FALSE;
        end if;
         Return 1;

    Exception
        When no_data_found then
        Begin

            Select usp.Deger
             into Temp_deger
             from urun_tur_parametre usp,parametre
            where usp.modul_tur_kod = C_GENERAL_MODUL_CODE
              and parametre_numara = numara
              and upper(kod) = upper(pkod);
               temp_deger:=upper(ltrim(rtrim(temp_deger)));
             if ( temp_deger in ('T','1','D')) then
               pdeger:=TRUE;
             else
               pdeger:=FALSE;
             end if;
            Return 1;

       Exception
           When no_data_found then
           Begin

               select deger
                 into temp_deger
                 from parametre
                 where modul_tur_kod = C_GENERAL_MODUL_CODE
                 and upper(kod)    = upper(pkod);

               temp_deger:=upper(ltrim(rtrim(temp_deger)));
             if ( temp_deger in ('T','1','D')) then
               pdeger:=TRUE;
             else
               pdeger:=FALSE;
             end if;
               Return 1;
           Exception
               When no_data_found then
                pkg_hata_kontrol.parametre_deger(1,upper(pkod));
                pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 4');
                return -1701;  -- Undefined Parameter : %%1 %%2
             When others then
                  pkg_hata_kontrol.parametre_deger(1,sqlerrm);
                  pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 25');pkg_hata_kontrol.push(-2000000);
                  return -2000000;
           End;
          When others then
              pkg_hata_kontrol.parametre_deger(1,sqlerrm);
              pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 26');pkg_hata_kontrol.push(-2000000);
              return -2000000;
       End;

    When others then
          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 27');pkg_hata_kontrol.push(-2000000);
          return -2000000;
    End;
    */
  EXCEPTION
      when others then
          --pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 28');pkg_hata_kontrol.push(-2000000);
          return -2000000;
  END;

  FUNCTION Al (pKod in varchar2, pdeger out number)   return number is
  begin
    select to_number(p.deger)
      into pdeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    return 1;
  exception
    When no_data_found then
        pdeger:=null;
        -- pkg_hata_kontrol.parametre_deger(1,upper(pkod));
        -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 30');
        return -1701;  -- Undefined Parameter : %%1 %%2

    when others then
          pdeger:=null;
          -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 30');pkg_hata_kontrol.push(-2000000);
          return -2000000;
  end;

  FUNCTION Al (pKod in varchar2, pdeger out varchar2) return number is
  temp_Deger varchar2(2000);
  begin
    select p.deger
      into temp_Deger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    pdeger  := substr(temp_deger,2,length(temp_deger)-2);
    return 1;
  exception
    When no_data_found then
        pdeger:=null;
        -- pkg_hata_kontrol.parametre_deger(1,upper(pkod));
        -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 35');
        return -1701;  -- Undefined Parameter : %%1 %%2

    when others then
          pdeger:=null;
          -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 35');pkg_hata_kontrol.push(-2000000);
          return -2000000;
  end;

  FUNCTION Al (pKod in varchar2, pdeger out date)     return number is
  begin
    select to_date(p.deger,'dd/mm/yyyy')
      into pdeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    return 1;

  exception
    When no_data_found then
        pdeger:=null;
        -- pkg_hata_kontrol.parametre_deger(1,upper(pkod));
        -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 40');
        return -1701;  -- Undefined Parameter : %%1 %%2

    when others then
          pdeger:=null;
          -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 40');pkg_hata_kontrol.push(-2000000);
          return -2000000;
  end;

  FUNCTION Al (pKod in varchar2, pdeger out boolean)  return number is
    ddeger varchar2(5);
  begin
    select DECODE(UPPER(TRIM(deger)),'T','TRUE','1','TRUE','D','TRUE','FALSE')
      into ddeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    pdeger:=ddeger='TRUE';
    return 1;
  exception
    When no_data_found then
        pdeger:=null;
        -- pkg_hata_kontrol.parametre_deger(1,upper(pkod));
        -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al Loc : 45');
        return -1701;  -- Undefined Parameter : %%1 %%2

    when others then
          pdeger:=null;
          -- pkg_hata_kontrol.parametre_deger(1,sqlerrm);
          -- pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 45');pkg_hata_kontrol.push(-2000000);
          return -2000000;
  end;

  procedure Parametre_Yaz(
                    pislem_numara in number,
                                      varchar_list  in pkg_muhasebe.varchar_array,
                                      number_list   in pkg_muhasebe.number_array,
                                      date_list     in pkg_muhasebe.date_array,
                                      boolean_list  in pkg_muhasebe.boolean_array
  ) is
    Pragma Autonomous_Transaction;
    i                      number;
    l_kod                  cbs_parametre.kod%type;
    l_aciklama             varchar2(40);
  begin

      -- Debug ama?li bir rutin
/*
       i := varchar_list.FIRST;
       WHILE i IS NOT NULL LOOP
             insert into cbs_islem_parametre_deger (islem_numara,parametre_numara,deger)
                  values (pislem_numara,i,varchar_list(i));
             i := varchar_list.NEXT(i);
       END LOOP;
       i := number_list.FIRST;
       WHILE i IS NOT NULL LOOP
             insert into islem_parametre_deger (islem_numara,parametre_numara,deger)
                  values (pislem_numara,i,number_list(i));
             i := number_list.NEXT(i);
       END LOOP;
       i := date_list.FIRST;
       WHILE i IS NOT NULL LOOP
             insert into islem_parametre_deger (islem_numara,parametre_numara,deger)
                  values (pislem_numara,i,to_char(date_list(i),'DDMMYYYY'));
             i := date_list.NEXT(i);
       END LOOP;
       i := boolean_list.FIRST;
       WHILE i IS NOT NULL LOOP
             IF boolean_list(i) THEN
                  insert into islem_parametre_deger (islem_numara,parametre_numara,deger)
                       values (pislem_numara,i,'T');
             ELSE
                  insert into islem_parametre_deger (islem_numara,parametre_numara,deger)
                       values (pislem_numara,i,'F');
             END IF;
             i := boolean_list.NEXT(i);
       END LOOP;
       commit;
*/
  null;
  end;


  Function Parametre_Oku(
                    pislem_numara in number,
                                      varchar_list  in out pkg_muhasebe.varchar_array,
                                      number_list   in out pkg_muhasebe.number_array,
                                      date_list     in out pkg_muhasebe.date_array,
                                      boolean_list  in out pkg_muhasebe.boolean_array
  ) return number is
/*
  p_tip    varchar2(10);
  Cursor c_v is
    Select par.numara,isl.deger
      from parametre par, islem_parametre_deger isl
     where isl.islem_numara=pislem_numara
          and par.numara=isl.parametre_numara
          and tip = p_tip;

    r_c_v                  c_v%ROWTYPE;
*/
  Begin
      /*
    p_tip:='V';
       Open c_v;
        Loop
            fetch c_v into r_c_v;
            exit when c_v%notfound;
          varchar_list(r_c_v.numara):=r_c_v.deger;
      End Loop;
    Close c_v;
    p_tip:='N';
       Open c_v;
        Loop
            fetch c_v into r_c_v;
            exit when c_v%notfound;
          number_list(r_c_v.numara):=to_number(r_c_v.deger);
      End Loop;
    Close c_v;
    p_tip:='D';
       Open c_v;
        Loop
            fetch c_v into r_c_v;
            exit when c_v%notfound;
          date_list(r_c_v.numara):=to_date(r_c_v.deger,'DDMMYYYY');
      End Loop;
    Close c_v;
    p_tip:='B';
       Open c_v;
        Loop
            fetch c_v into r_c_v;
            exit when c_v%notfound;
          if r_c_v.deger = 'T' then
            boolean_list(r_c_v.numara):=TRUE;
          else
            boolean_list(r_c_v.numara):=FALSE;
          end if;
      End Loop;
    Close c_v;
    */
    return 1;
  exception
    when others then
        return -1;
  End;

function fun_get_prod_of_prm ( pn_tx_code        in  number
                              ,ps_parameter      in  varchar2
                              ,ps_value          in  varchar2
                              ,ps_modul_tur_kod  out varchar2
                              ,ps_urun_tur_kod   out varchar2
                              ,ps_urun_sinif_kod out varchar2
                              ) return number is

/*  cursor vc_prod is
       select modul_tur_kod, urun_tur_kod, urun_sinif_kod
        from  cbs_urun_islem
        where islem_tanim_kod = pn_tx_code;

  vr_prod vc_prod%rowtype;

  vs_modul_tur_kod      modul_tur.kod%type;
  vs_urun_tur_kod       urun_tur.kod%type;
  vs_urun_sinif_kod     urun_sinif.kod%type;

  vn_found_count number := 0;
  vn_ret         number;

  vs_value       varchar2(100);
*/
begin

/*
   open vc_prod;
   fetch vc_prod into vr_prod;
   if vc_prod%notfound then
      close vc_prod;
      pkg_hata_kontrol.parametre_deger(1, pn_tx_code);
      pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.fun_get_prod_of_prm');pkg_hata_kontrol.push(-1702);
      return -1702;  -- Tx does not use any product : %%1 (%%2)
   end if;
   loop
       vn_ret := pkg_parametre.al( pmodul_tur_kod => vr_prod.modul_tur_kod,purun_tur_kod => vr_prod.urun_tur_kod,purun_sinif_kod => vr_prod.urun_sinif_kod, pkod =>  ps_parameter, pdeger => vs_value );
       if vn_ret < 0 then return vn_ret; end if;

       if vs_value = ps_value then
          vn_found_count := vn_found_count + 1;
          if vn_found_count > 1 then
              close vc_prod;
              pkg_hata_kontrol.parametre_deger(1,'pkg_parametre.fun_get_prod_of_prm');pkg_hata_kontrol.push(-1703);
              return -1703;  -- Parameter has the same value in different products (%%1)
          end if;
          vs_modul_tur_kod  := vr_prod.modul_tur_kod;
          vs_urun_tur_kod   := vr_prod.urun_tur_kod;
          vs_urun_sinif_kod := vr_prod.urun_sinif_kod;
       end if;

       fetch vc_prod into vr_prod;
       exit when vc_prod%notfound ;

   end loop;
   close vc_prod;

   if vn_found_count = 1 then
       ps_modul_tur_kod  := vs_modul_tur_kod;
       ps_urun_tur_kod   := vs_urun_tur_kod;
       ps_urun_sinif_kod := vs_urun_sinif_kod;
   else
       pkg_hata_kontrol.parametre_deger(1,ps_parameter);
       pkg_hata_kontrol.parametre_deger(2,ps_value);
       pkg_hata_kontrol.parametre_deger(3,'pkg_parametre.fun_get_prod_of_prm');pkg_hata_kontrol.push(-1704);
       return -1704;  -- Can not found any products for parameter : %%1 having value : %%2 (%%3)
   end if;
*/
   return 1;

exception
   when others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 35');pkg_hata_kontrol.push(-2000000);
          return -2000000;
end;

function fun_get_prod_of_prm ( pn_tx_code        in  number
                              ,ps_parameter      in  varchar2
                              ,pn_value          in  number
                              ,ps_modul_tur_kod  out varchar2
                              ,ps_urun_tur_kod   out varchar2
                              ,ps_urun_sinif_kod out varchar2
                              ) return number is
/*
  cursor vc_prod is
       select modul_tur_kod, urun_tur_kod, urun_sinif_kod
        from  urun_islem
        where islem_tanim_kod = pn_tx_code;

  vr_prod vc_prod%rowtype;

  vs_modul_tur_kod      modul_tur.kod%type;
  vs_urun_tur_kod       urun_tur.kod%type;
  vs_urun_sinif_kod     urun_sinif.kod%type;

  vn_found_count number := 0;
  vn_ret         number;

  vn_value       varchar2(100);
*/
begin
/*
   open vc_prod;
   fetch vc_prod into vr_prod;
   if vc_prod%notfound then
      close vc_prod;
      pkg_hata_kontrol.parametre_deger(1, pn_tx_code);
      pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.fun_get_prod_of_prm');pkg_hata_kontrol.push(-1702);
      return -1702;  -- Tx does not use any product : %%1 (%%2)
   end if;
   loop
       vn_ret := pkg_parametre.al( pmodul_tur_kod => vr_prod.modul_tur_kod,purun_tur_kod => vr_prod.urun_tur_kod,purun_sinif_kod => vr_prod.urun_sinif_kod, pkod =>  ps_parameter, pdeger => vn_value );
       if vn_ret < 0 then return vn_ret; end if;

       if vn_value = pn_value then
          vn_found_count := vn_found_count + 1;
          if vn_found_count > 1 then
              close vc_prod;
              pkg_hata_kontrol.parametre_deger(1,'pkg_parametre.fun_get_prod_of_prm');pkg_hata_kontrol.push(-1703);
              return -1703;  -- Parameter has the same value in different products (%%1)
          end if;
          vs_modul_tur_kod  := vr_prod.modul_tur_kod;
          vs_urun_tur_kod   := vr_prod.urun_tur_kod;
          vs_urun_sinif_kod := vr_prod.urun_sinif_kod;
       end if;

       fetch vc_prod into vr_prod;
       exit when vc_prod%notfound ;

   end loop;
   close vc_prod;

   if vn_found_count = 1 then
       ps_modul_tur_kod  := vs_modul_tur_kod;
       ps_urun_tur_kod   := vs_urun_tur_kod;
       ps_urun_sinif_kod := vs_urun_sinif_kod;
   else
       pkg_hata_kontrol.parametre_deger(1,ps_parameter);
       pkg_hata_kontrol.parametre_deger(2,pn_value);
       pkg_hata_kontrol.parametre_deger(3,'pkg_parametre.fun_get_prod_of_prm');pkg_hata_kontrol.push(-1704);
       return -1704;  -- Can not found any products for parameter : %%1 having value : %%2 (%%3)
   end if;

   return 1;
*/
   return 1;
exception
   when others then
--          pkg_hata_kontrol.parametre_deger(1,sqlerrm);
--          pkg_hata_kontrol.parametre_deger(2,'pkg_parametre.al -- Loc : 35');pkg_hata_kontrol.push(-2000000);
          return -2000000;
end;

  --------------------------------------------------------------------------------------------------------
  function fun_check_value ( ps_parameter      in  varchar2
                            ,ps_modul_tur_kod  in  varchar2
                            ,ps_value          in  varchar2
                            ) return boolean
  is
    vn_exist                number;
  BEGIN

     begin
          select 1
            into vn_exist
            from cbs_parametre p
           where p.modul_tur_kod      = ps_modul_tur_kod
           and upper(p.kod)         = upper(ps_parameter)
           and ( ps_value in (select deger from cbs_parametre_gecerli_deger pgd where pgd.parametre_numara=p.numara)
                 or
                 '"'||ps_value||'"' in (select deger from cbs_parametre_gecerli_deger pgd where pgd.parametre_numara=p.numara)
               );
     exception
          when no_data_found then
          -- Try to find parameter under GENERAL PARAMETERS
          ---------------------------------------------------------------
          Begin

                select 1
                  into vn_exist
                  from cbs_parametre p
                 where p.modul_tur_kod      = C_GENERAL_MODUL_CODE
                 and upper(p.kod)         = upper(ps_parameter)
                 and ( ps_value in (select deger from cbs_parametre_gecerli_deger pgd where pgd.parametre_numara=p.numara)
                       or
                       '"'||ps_value||'"' in (select deger from cbs_parametre_gecerli_deger pgd where pgd.parametre_numara=p.numara)
                     );
          Exception
            When no_data_found then return false;
            When others        then return false;
          End;
        when others then return false;
     end;

     if nvl(vn_exist,0) = 1 then
        return true;
     else
        return false;
     end if;

  EXCEPTION
      when others then return false;
  END;


  FUNCTION lc_mi ( ps_Modul_Tur_Kod    in varchar2
                       ,ps_Urun_Tur_Kod     in varchar2
                       ,ps_Urun_Sinif_Kod   in varchar2)
                       return varchar2 is
  ls_lc_mi varchar2(1) := 'H';
  Begin
        Select lc
      into  ls_lc_mi
      from  cbs_urun_sinif
      where modul_tur_kod = ps_Modul_Tur_Kod and
              urun_tur_kod  = ps_urun_tur_kod and
            kod =ps_urun_sinif_kod;

    return ls_lc_mi;
    Exception
      When Others Then return 'H';
  End;
------------------------------------------------------------------------------
--BOM IadgarB CBS-157
 FUNCTION get_aciklama(pKod in varchar2) return varchar2 is
    lc_text varchar2(100);
  begin
    select aciklama
      into lc_text
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
       
     return lc_text;
  exception
    when others then
      return '';
  end;
--EOM IadgarB CBS-157
-------------------------------------------------------------------------------
END;
/

