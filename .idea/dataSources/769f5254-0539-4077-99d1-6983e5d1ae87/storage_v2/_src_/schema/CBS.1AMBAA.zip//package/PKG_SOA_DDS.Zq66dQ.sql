create PACKAGE     pkg_soa_dds AS

TYPE CursorReferenceType IS REF CURSOR;
/******************************************************************************
   NAME:        log_invoice_upload
   PURPOSE:     Save the information (log) about the user file upload.
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
  FUNCTION log_invoice_upload(   ps_person_id       IN  varchar2,
                                ps_tran_cd         IN  varchar2,
                                ps_filename        IN  varchar2,
                                ps_invoice_count   IN  varchar2,
                                ps_error_message   IN  varchar2,
                                pc_ref             OUT CursorReferenceType) RETURN varchar2;
/******************************************************************************
   NAME:        insert_invoice
   PURPOSE:     Save the invoice to table for further processing
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
  FUNCTION insert_invoice(
                                ps_tran_cd         IN  varchar2,
                                ps_customer_id     IN  varchar2,
                                ps_file_upload_id  IN  varchar2,
                                ps_invoice_no      IN  varchar2,
                                ps_invoice_date    IN  varchar2,
                                ps_customer_okpo   IN  varchar2,
                                ps_customer_inn    IN  varchar2,
                                ps_customer_sfkr   IN  varchar2,
                                ps_customer_bank_bic   IN  varchar2,
                                ps_customer_name       IN  varchar2,
                                ps_customer_debit_account_no   IN  varchar2,
                                ps_customer_bank_name  IN  varchar2,
                                ps_beneficiar_name     IN  varchar2,
                                ps_beneficiar_cr_account_no    IN  varchar2,
                                ps_beneficiar_account_no           IN  varchar2,
                                ps_beneficiar_bank_bic IN  varchar2,
                                ps_beneficiar_bank_name    IN  varchar2,
                                ps_payment_code        IN  varchar2,
                                ps_payment_details     IN  varchar2,
                                ps_amount              IN  varchar2,
                                ps_currency            IN  varchar2,
                                ps_created_by          IN  varchar2,
                                ps_amount_in_words     IN  varchar2,
                                ps_alloc_reference     IN  varchar2,
                                ps_customer_ref_id     IN  varchar2,
                                pc_ref                 OUT  CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME:        process_invoice
   PURPOSE:     To make a payment transaction by the invoice
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
FUNCTION process_invoice (      ps_channel_cd   IN    varchar2,
                                ps_customer_id  IN    varchar2,
                                ps_invoice_id   IN    varchar2) RETURN VARCHAR2;
/******************************************************************************
   NAME:        update_invoice_status
   PURPOSE:     To update the status of the payment
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
PROCEDURE update_invoice_status( ps_invoice_id   IN    varchar2,
                                ps_status       IN    varchar2,
                                ps_error_code   IN    varchar2,
                                ps_error_desc   IN    varchar2);
/******************************************************************************
   NAME:        update_payment_info
   PURPOSE:     To set the payment information, to set transaction no by which
                payment was done, and set payment method
                ('CLEARING', 'GROSS', ..)
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
PROCEDURE update_payment_info(  ps_invoice_id   IN  varchar2,
                                ps_payment_method   IN  varchar2,
                                ps_payment_table    IN  varchar2,
                                ps_value_date       IN  varchar2,
                                pn_txno         IN      varchar2);
/******************************************************************************
   NAME:        refresh_invoice_statuses
   PURPOSE:     To refresh invoice statuses, to refresh if the transactions were
                approved, canceled, done and so on.
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
PROCEDURE refresh_invoice_statuses( ps_customer_id   IN  varchar2);
/******************************************************************************
   NAME:        create_b2b_transfer
   PURPOSE:     To create b2b transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
FUNCTION create_b2b_transfer(   ps_channel_cd   IN      varchar2,
                                ps_customer_id  IN      varchar2,
                                ps_fromaccount  IN      varchar2,
                                ps_toaccount    IN      varchar2,
                                ps_amount       IN      varchar2,
                                ps_description  IN      varchar2,
                                ps_currencycode IN      varchar2,
                                ps_discontistiyormu IN  varchar2,
                                ps_person_id        IN  varchar2,
                                ps_payeename        IN  varchar2,
                                ps_internalacc      IN  varchar2,
                                ps_paymentcode      IN  varchar2,
                                ps_fromirsseco      IN  varchar2,
                                ps_toirsseco        IN  varchar2,
                                ps_commission       IN  varchar2,
                                ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                pc_ref              OUT CursorReferenceType) return VARCHAR2;
/******************************************************************************
   NAME:        create_b2ob_transfer
   PURPOSE:     To create b20b transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
FUNCTION create_b2ob_transfer(  ps_channel_cd   IN      varchar2,
                                ps_customer_id  IN      varchar2,
                                ps_fromaccount  IN      varchar2,
                                ps_toaccount    IN      varchar2,
                                ps_amount       IN      varchar2,
                                ps_description  IN      varchar2,
                                ps_currencycode IN      varchar2,
                                ps_discontistiyormu IN  varchar2,
                                ps_person_id        IN  varchar2,
                                ps_payeename        IN  varchar2,
                                ps_internalacc      IN  varchar2,
                                ps_paymentcode      IN  varchar2,
                                ps_fromirsseco      IN  varchar2,
                                ps_toirsseco        IN  varchar2,
                                ps_commission       IN  varchar2,
                                ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                pc_ref              OUT CursorReferenceType) return VARCHAR2;
/******************************************************************************
   NAME:        create_gross_transfer
   PURPOSE:     To create gross transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
function create_gross_transfer(     ps_channel_cd   IN  varchar2,
                                    ps_customer_id  IN  varchar2,
                                    ps_person_id    IN  varchar2,
                                    ps_fromaccount  IN  varchar2,
                                    ps_transfer_date    IN  varchar2,
                                    ps_sender_name      IN  varchar2,
                                    ps_sender_phone     IN  varchar2,
                                    ps_bank_code        IN  varchar2,
                                    ps_payee_name       IN  varchar2,
                                    ps_toaccount    IN  varchar2,
                                    ps_amount       IN  varchar2,
                                    ps_description  IN  varchar2,
                                    ps_payment_code      IN  varchar2,
                                    ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                    ps_currency        IN  varchar2, -- Nursultan Mukhambet uulu 22.04.2022 ibc-101
                                    pc_ref              OUT CursorReferenceType) return VARCHAR2;
/******************************************************************************
   NAME:        create_clearing_transfer
   PURPOSE:     To create clearing transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014
******************************************************************************/
FUNCTION create_clearing_transfer(  ps_channel_cd   IN      varchar2,
                                    ps_customer_id  IN  varchar2,
                                    ps_person_id        IN  varchar2,
                                    ps_fromaccount  IN  varchar2,
                                    ps_transfer_date    IN  varchar2,
                                    ps_sender_name      IN  varchar2,
                                    ps_sender_phone     IN  varchar2,
                                    ps_bank_code        IN  varchar2,
                                    ps_payee_name       IN  varchar2,
                                    ps_toaccount        IN  varchar2,
                                    ps_amount           IN  varchar2,
                                    ps_description      IN  varchar2,
                                    ps_payment_code     IN  varchar2,
                                    ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                    ps_currency        IN  varchar2, -- Nursultan Mukhambet uulu 22.04.2022 ibc-101
                                    pc_ref              OUT cursorReferenceType) return VARCHAR2;

/******************************************************************************
   NAME:        insert_swift_invoice
   PURPOSE:     Save the invoice to table for further processing
   PREPARED BY: Azat Dzhanybekov
   DATE:        17.12.2020
******************************************************************************/
  FUNCTION insert_swift_invoice(
               ps_customer_debit_account_no   IN  varchar2,
               ps_value_date          IN  varchar2,
               ps_amount              IN  varchar2,
               ps_currency            IN  varchar2,
               ps_commission_type IN  varchar2,
               ps_commission_account_no IN  varchar2,
               ps_beneficiar_country_code   IN  varchar2,
               ps_beneficiar_bank_bic IN  varchar2,
               ps_beneficiar_cr_account_no    IN  varchar2,
               ps_beneficiar_name     IN  varchar2,
               ps_beneficiar_address   IN  varchar2,
               ps_beneficiar_bank_branch_name    IN  varchar2,
               ps_payment_code        IN  varchar2,
               ps_payment_details     IN  varchar2,
               ps_contract_date    IN  varchar2,
               ps_contract_no      IN  varchar2,
               ps_invoice_date    IN  varchar2,
               ps_invoice_no      IN  varchar2,
               ps_customer_id     IN  varchar2,
               ps_created_by          IN  varchar2,
               pc_ref                 OUT  CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME:        process_swift_invoice
   PURPOSE:     To make a payment transaction by the invoice
   PREPARED BY: Azat Dzhanybekov
   DATE:        21.12.2020
******************************************************************************/
FUNCTION process_swift_invoice (      ps_channel_cd   IN    varchar2,
                                ps_customer_id  IN    varchar2,
                                ps_invoice_id   IN    varchar2) RETURN VARCHAR2;

/******************************************************************************
   NAME:        process_swift_invoice
   PURPOSE:     To make a payment transaction by the invoice
   PREPARED BY: Azat Dzhanybekov
   DATE:        21.12.2020
******************************************************************************/
FUNCTION  create_swift_transfer(  ps_channel_cd       IN  VARCHAR2,
                                           ps_customer_id      IN  VARCHAR2,
                                           ps_person_id        IN  VARCHAR2,
                                           ps_todo_txno IN  VARCHAR2,
                                           ps_sender_acc_no IN VARCHAR2,
                                           ps_country_code IN VARCHAR2,
                                           ps_currency IN VARCHAR2,
                                           ps_amount IN VARCHAR2,
                                           ps_value_date IN VARCHAR2,
                                           ps_charge_party IN VARCHAR2, --who pays charge,  (BEN, OUR, GOUR)
                                           ps_stat_code IN VARCHAR2,
                                           ps_description IN VARCHAR2,
                                           ps_comm_acc_no IN VARCHAR2,
                                           ps_charge_amount IN VARCHAR2,
                                           ps_ben_acc_no IN VARCHAR2,
                                           ps_ben_name IN VARCHAR2,
                                           ps_ben_address IN VARCHAR2,
                                           ps_ben_swiftcode IN VARCHAR2, --bic code of beneficiary bank
                                           ps_ii_bic IN VARCHAR2,                 --intermediary institution bic code

                                           ps_person        IN VARCHAR2,
                                           ps_tran_status    IN VARCHAR2,
                                           ps_contract_date IN VARCHAR2,
                                           ps_contract_no IN VARCHAR2,
                                           ps_corrbank_name IN VARCHAR2,
                                           ps_filename IN VARCHAR2,
                                           ps_ben_bank_branch IN VARCHAR2,

                                           ps_invoice_date IN VARCHAR2,
                                           ps_invoice_no IN VARCHAR2,

                                           pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

END PKG_SOA_DDS;
/

