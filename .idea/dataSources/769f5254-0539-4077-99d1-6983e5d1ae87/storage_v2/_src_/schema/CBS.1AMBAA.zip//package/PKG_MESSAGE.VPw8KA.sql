create Package Pkg_Message is

TYPE CursorReferenceType is REF CURSOR;
/*cursor cursor_clear is
	   		  select m.MSG_ID, m.MSG_KIND MSG_KIND, m.FILE_NAME FILE_NAME, m.FIRST_HEADER FIRST_HEADER, m.SECOND_HEADER SECOND_HEADER, m.MSG_REFERENCE MSG_REFERENCE,
			         m.TOTAL_TRAN_DATE TOTAL_TRAN_DATE, m.TOTAL_TRAN_CURR TOTAL_TRAN_CURR, m.TOTAL_TRAN_AMOUNT TOTAL_TRAN_AMOUNT, md.DC_TYPE DC_TYPE,
					 md.FROM_ACCOUNT FROM_ACCOUNT, md.FROM_NAME FROM_NAME, md.FROM_RNN FROM_RNN, md.FROM_CHIEF FROM_CHIEF,md.FROM_MAINBK FROM_MAINBK,
					 md.FROM_IRS FROM_IRS, md.FROM_SECO FROM_SECO, md.FROM_BRANCH FROM_BRANCH, md.FROM_HQ FROM_HQ,md.FROM_NBACCOUNT FROM_NBACCOUNT, md.TO_BRANCH TO_BRANCH,
				     md.TO_HQ TO_HQ,md.TO_NBACCOUNT TO_NBACCOUNT,md.TO_ACCOUNT TO_ACCOUNT, md.TO_NAME TO_NAME, md.TO_RNN TO_RNN, md.TO_IRS TO_IRS, md.TO_SECO TO_SECO, md.DOC_NUM DOC_NUM,
					 md.DOC_DATE DOC_DATE, md.DOC_SEND DOC_SEND, md.DOC_VO DOC_VO, md.DOC_PSO DOC_PSO, md.DOC_KNP DOC_KNP, md.DOC_PRT DOC_PRT,
					 md.DOC_ASSIGN DOC_ASSIGN, md.DOC_BCLASS DOC_BCLASS,md.CANCEL_REFERENCE,md.CANCEL_KIND,md.CANCEL_DATE,md.CANCEL_REASON,
					  md.DOC_FM, md.DOC_NM, md.DOC_FT, md.DOC_DT, md.MSG_CODE
			   from cbs_clearing_messages m, cbs_clearing_messages_detail md
			   where m.MSG_ID = md.MSG_ID;*/


FUNCTION  OpenFile(ps_filename IN VARCHAR2,ps_type IN varchar2) RETURN utl_file.file_type;
--------------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  WriteLine(file_obj IN utl_file.file_type, ps_inputtext IN VARCHAR2) RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  ReadLine(file_obj IN utl_file.file_type, ps_outputtext OUT VARCHAR2) RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  CloseFile(file_obj IN OUT utl_file.file_type) RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
Function Write2File(ps_filename in varchar2,ps_inputtext in varchar2) return varchar2;
--------------------------------------------------------------------------------------------------------------------------------------------------
Function Split(ps_str in varchar2,ps_delimeter in varchar2,pn_valindx in number) return varchar2;
--------------------------------------------------------------------------------------------------------------------------------------------------
Function PrepareField(ps_str in varchar2,pn_length in number,
		 					 	ps_padchar in varchar2,ps_justification in varchar2,ps_fieldtype IN VARCHAR2 default 'CHAR')  return varchar2;
--------------------------------------------------------------------------------------------------------------------------------------------------
Function SendMT100Message( pn_mesgid in NUMBER) RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
Function SendMT102Message(pn_mesgid in NUMBER)  RETURN VARCHAR2;
Function SendMT102TaxMessage(pn_mesgid in NUMBER)  RETURN VARCHAR2;
Function SendMT102OrdMessage(pn_mesgid in NUMBER)  RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  GetPansionMT102Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2;
---------------------------------------------------------------------------------------
Function SendMT998Message(pn_mesgid in NUMBER)  RETURN VARCHAR2;

--------------------------------------------------------------------------------------------------------------------------------------------------
Function GetBankCodes(ps_gbc IN varchar2)  RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
Function GetMT900Messages(ps_filename  IN varchar2 DEFAULT NULL)  RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
Function GetMT940Messages(ps_filename  IN varchar2 DEFAULT NULL)  RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION GetMT100Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION GetMT102Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
Function UploadInstClearingFile(ps_filename IN varchar2 default null)  RETURN VARCHAR2;
--------------------------------------------------------------------------------------
Function ReadCityCodes(ps_gbc IN varchar2)  RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION  GetScanMT100Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION  GetScanMT102Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
Function GetMT950Messages(ps_filename IN varchar2 default null)  RETURN VARCHAR2;
-----------------------------------------------------------------------------------
Function SendMT920Message(pn_mesgid in NUMBER) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
End;


/

