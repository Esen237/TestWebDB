create PACKAGE PKG_KASA IS

/******************************************************************************
   Name       : PKG_KASA
   Created By : Seval Balci
   Date    	  : 06.08.04
   Purpose	  : Kasa islemleri ile ilgili procedure ve fonksiyonlar
******************************************************************************/
 Function  sf_yeni_kasakodu_Al(ps_branch varchar2 ) return  varchar2;
 Function kasa_modul_tur_kod return varchar2;
 Function kasa_urun_tur_kod return varchar2;
 Function kasa_urun_sinif_kod return varchar2;
 Function kasa_baglimi(ps_kasa_kodu varchar2) return varchar2;
 Function kullanici_kasaya_baglimi(ps_kullanici_kodu varchar2) return varchar2;
 Procedure kasa_kodu_al(ps_sube varchar2,ps_kullanici_kodu varchar2, ps_kasa_kodu out varchar2,pn_tanim_no out number);
 Function kupur_kod_adi_al(pn_kupur_kodu number,ps_doviz varchar2) return varchar2;
 Function kupur_kontrolu_yapilsin(pn_islem_kod number default null) return varchar2;
 Procedure kasa_sifir_bakiyeli_yarat(ps_kasa_kodu varchar2, ps_sube_kodu varchar2 ,ps_doviz_kodu varchar2 default null);
 Function kullanici_kasa_kodu(ps_sube varchar2,ps_kullanici_kodu varchar2) return varchar2;
 /* Ana kasa islemleri */
 Function ana_kasa_kodu return varchar2 ;
-- Function ana_kasa_sube return varchar2 ;
 Procedure ana_kasa_yarat( ps_sube_kodu varchar2) ;
 Procedure kasa_isleme_at (pn_tx_no 		  number,
 		   				   pn_islem_kod	  cbs_islem.islem_kod%type,
						   ps_kasa_kodu       cbs_kasa_kodlari.kasa_kodu%type,
						   ps_sube_kodu		  varchar2,
						   ps_kullanici_kodu  varchar2,
						   pn_tanim_no number,
						   ps_urun_sinif_kod varchar2 default pkg_kasa.kasa_urun_sinif_kod,
   						   ps_origin_islem_kod varchar2 default null,
						   pn_tutar1 number default null,
  						   ps_doviz1 varchar2 default null,
  						   ps_islem_1 varchar2 default null,
  						   pn_tutar2 number default null,
  						   ps_doviz2 varchar2 default null,
  						   ps_islem_2 varchar2	default null					 );

 --Procedure ana_kasa_yarat (
 /* kapama ile ilgili islemler */
 Function kullanici_kapama_yetkilimi( ps_kasa_kodu varchar2, ps_sube varchar2,ps_kullanici_kodu varchar2) return varchar2;
 Function kasa_bakiye_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2,pd_date date default null) return number;
 Function kasa_kupur_bakiye_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2,pn_kupur_kodu number, pd_date date default null) return number;
 Procedure bekleyen_kasa_islemi_varmi(pn_islem_no number,ps_kasa_kodu varchar2 default null);
 Function kasa_kupur_islem_kod( ps_kod varchar2) return varchar2;
 Function kasa_kupur_toplambakiye_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2, pd_date date default null) return number;
 Function kasa_kupur_toplamadet_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2, pd_date date default null) return number;
 Procedure kasa_gunsonu_bakiye_at(pd_date date default pkg_muhasebe.banka_tarihi_bul) ;
 Function subeye_kasa_baglanabilir(ps_sube varchar2 ) return varchar2;
 Procedure yenidovizkodu_tanimlaninca(ps_doviz_kodu varchar2 );
 Function kasa_uygunmu( ps_sube_kodu varchar2,ps_kasa_kodu varchar2) return varchar2;
 Procedure kasa_bakiye_kontrol(ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2,pn_tutar number default 0,pd_date date default null) ;
 Function exchange_kasa_kodu return varchar2 ;
 END;


/

