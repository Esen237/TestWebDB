create PACKAGE BODY Pkg_Leasing IS

------------------------------------------------------------------------------
 FUNCTION ana_mal_kodu_al RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
   SELECT NVL(MAX(kod),0)
     INTO ln_temp
	FROM CBS_LEASING_MAL_ANA;
	RETURN ln_temp+1;
 END;
------------------------------------------------------------------------------
 FUNCTION detay_mal_kodu_al(pn_ana_kod NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
   SELECT NVL(MAX(kod),0)
     INTO ln_temp
	 FROM CBS_LEASING_MAL_DETAY
    WHERE ana_kod = pn_ana_kod;
	RETURN ln_temp+1;
 END;
------------------------------------------------------------------------------
 FUNCTION sozlesme_baslangic_tarihi_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER) RETURN DATE IS
 ld_bas_tarih DATE;
 BEGIN
   SELECT sozlesme_tarihi
     INTO ld_bas_tarih
     FROM CBS_LEASING_SOZLESME
	WHERE musteri_no = pn_musteri_no
	  AND sozlesme_no = pn_sozlesme_no;
	RETURN ld_bas_tarih;
 END;
------------------------------------------------------------------------------
 FUNCTION sozlesme_bitis_tarihi_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER) RETURN DATE IS
 ld_bas_tarih DATE;
 ln_sure NUMBER;
 ld_bit_tarih DATE;
 BEGIN
   SELECT sozlesme_sure, sozlesme_tarihi
     INTO ln_sure, ld_bas_tarih
     FROM CBS_LEASING_SOZLESME
	WHERE musteri_no = pn_musteri_no
	  AND sozlesme_no = pn_sozlesme_no;
	ld_bit_tarih := Pkg_Tarih.geri_is_gunu(ADD_MONTHS(ld_bas_tarih, 12*ln_sure)+1);

	RETURN ld_bit_tarih;
 END;
------------------------------------------------------------------------------
 FUNCTION fatura_sira_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER,
                         pn_odeme_no NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
   SELECT NVL(MAX(sira_no),0)
     INTO ln_temp
     FROM CBS_LEASING_FATURA
	WHERE musteri_no = pn_musteri_no
	  AND sozlesme_no = pn_musteri_no
	  AND odeme_plan_no = pn_odeme_no;
	ln_temp := ln_temp + 1;
	RETURN ln_temp;
 END;
------------------------------------------------------------------------------
 FUNCTION odeme_plan_no_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
   SELECT NVL(MAX(odeme_plan_no),0)
     INTO ln_temp
     FROM CBS_LEASING
	WHERE musteri_no = pn_musteri_no
	  AND sozlesme_no = pn_musteri_no;
	ln_temp := ln_temp + 1;
	RETURN ln_temp;
 END;
------------------------------------------------------------------------------
FUNCTION ana_mal_adi_al(pn_mal_kodu NUMBER) RETURN VARCHAR2 IS
 ls_temp VARCHAR2(100);
 BEGIN
   SELECT tanim
     INTO ls_temp
	 FROM CBS_LEASING_MAL_ANA
    WHERE kod = pn_mal_kodu;
	RETURN ls_temp;
 END;
------------------------------------------------------------------------------
 FUNCTION detay_mal_adi_al(pn_ana_kod NUMBER, pn_detay_kod NUMBER) RETURN VARCHAR2 IS
 ls_temp VARCHAR2(100);
 BEGIN
   SELECT tanim
     INTO ls_temp
	 FROM CBS_LEASING_MAL_DETAY
    WHERE ana_kod = pn_ana_kod
	  AND kod = pn_detay_kod;
	RETURN ls_temp;
 END;
------------------------------------------------------------------------------
FUNCTION doviz_kullanilir(pn_musteri_no NUMBER, pn_krd_tklf_str_no NUMBER,
                          ps_dvz VARCHAR2) RETURN NUMBER IS
CURSOR c_0 IS
  SELECT a.modul_tur_kod, a.urun_tur_kod, a.urun_sinif_kod
    FROM cbs_vw_kredilimit_urungrupsnf a, cbs_vw_aktif_kredi_teklif b
   WHERE a.musteri_no = pn_musteri_no
     AND b.teklif_satir_no = pn_krd_tklf_str_no
     AND a.musteri_no = b.musteri_no
     AND a.urun_grup_no = b.kredi_turu;
 r_0 c_0%ROWTYPE;
 --1:true
 --0:false
 BEGIN
   OPEN c_0;
    FETCH c_0 INTO r_0;
    IF c_0%NOTFOUND THEN
     CLOSE c_0;
     RETURN 0;
    END IF;
   CLOSE c_0;
   IF Pkg_Genel.Urun_sinif_doviz_cinsi(r_0.modul_tur_kod, r_0.urun_tur_kod,
                                       r_0.urun_sinif_kod) = 'E' THEN
      IF ps_dvz = Pkg_Genel.lc_al THEN
	     RETURN 1;
	  ELSE
	     RETURN 0;
	  END IF;
   ELSE
      IF ps_dvz != Pkg_Genel.lc_al THEN
	    RETURN 1;
      ELSE
	    RETURN 0;
	  END IF;
   END IF;
  END;
------------------------------------------------------------------------------
 FUNCTION odeme_plan_faiz_al(pn_hesap_no NUMBER) RETURN NUMBER IS
 CURSOR c_0 IS
   SELECT NVL(SUM(NVL(faiz,0)),0)
     FROM CBS_HESAP_KREDI_TAKSIT
	WHERE hesap_no = pn_hesap_no;
  ln_temp NUMBER;
 BEGIN
  OPEN c_0;
  FETCH c_0 INTO ln_temp;
  CLOSE c_0;
  RETURN ln_temp;
 END;
------------------------------------------------------------------------------
 FUNCTION odeme_plan_kdv_al(pn_hesap_no NUMBER) RETURN NUMBER IS
 CURSOR c_0 IS
   SELECT NVL(SUM(NVL(kdv,0)),0)
     FROM CBS_HESAP_KREDI_TAKSIT
	WHERE hesap_no = pn_hesap_no;
  ln_temp NUMBER;
 BEGIN
  OPEN c_0;
  FETCH c_0 INTO ln_temp;
  CLOSE c_0;
  RETURN ln_temp;
 END;
------------------------------------------------------------------------------
 FUNCTION masraf_kod_al RETURN NUMBER IS
  ln_ret NUMBER;
 BEGIN
   SELECT NVL(MAX(NVL(kod,0)),0) + 1
     INTO ln_ret
	 FROM CBS_LEASING_MASRAF_CINS;
   RETURN ln_ret;
 END;
------------------------------------------------------------------------------
   FUNCTION modul_tur_al RETURN VARCHAR2
   IS
   BEGIN
		RETURN 'KREDI';

   END ;
------------------------------------------------------------------------------
   FUNCTION urun_tur_al RETURN VARCHAR2
   IS
   BEGIN
   		RETURN 'LEASING';
   END;
------------------------------------------------------------------------------

  PROCEDURE sp_isleme_at (pn_musteri_no       CBS_LEASING.musteri_no%TYPE,
   			 			   pn_sozlesme_no      CBS_LEASING.sozlesme_no%TYPE,
						   pn_odeme_plan_no		   CBS_LEASING.odeme_plan_no%TYPE,
  			   			   pn_tx_no   		   NUMBER,
						   pn_islem_tanim_kod  CBS_HESAP_KREDI_ISLEM.islem_tanim_kod%TYPE DEFAULT 3262)
 IS
  ln_hesap_no NUMBER;
 BEGIN

 	  SELECT hesap_no
	  INTO ln_hesap_no
	  FROM CBS_LEASING
	  WHERE musteri_no = pn_musteri_no AND
	   			 sozlesme_no = pn_sozlesme_no AND
 			 	 odeme_plan_no = pn_odeme_plan_no ;


 	  INSERT INTO CBS_LEASING_ISLEM
	  ( musteri_no, sozlesme_no, odeme_plan_no, hesap_no,
		    durum_kodu, kredi_teklif_satir_numara, plan_doviz_kodu,
		    yurt_ici_disi, mal_bedeli_baz_maliyet,
		    masraf_toplami, pesinat,
		    toplam_baz_maliyet, faiz_orani, vade_tarihi,
		     pesin_faiz_alinsin,
		    pesin_faiz_orani, pesin_faiz_bas_tar,
		    donem_basi_sonu, odeme_turu, taksit_sayisi,
		    taksit_once_sonra, artis_siklik, artis_oran,
		    ara_odeme_siklik, ara_odeme_tutar, donem_siklik,
		    kdv_alinsin, kdv_orani, acilis_tarihi, sube_kodu,
		    islem_tanim_kod,tx_no )
	   SELECT
		   musteri_no, sozlesme_no, odeme_plan_no, hesap_no,
		   durum_kodu, kredi_teklif_satir_numara, plan_doviz_kodu,
		   yurt_ici_disi, mal_bedeli_baz_maliyet,
		   masraf_toplami, pesinat,
		   toplam_baz_maliyet, faiz_orani, vade_tarihi,
		     pesin_faiz_alinsin,
		   pesin_faiz_orani, pesin_faiz_bas_tar,
		   donem_basi_sonu, odeme_turu, taksit_sayisi,
		   taksit_once_sonra, artis_siklik, artis_oran,
		   ara_odeme_siklik, ara_odeme_tutar, donem_siklik,
		   kdv_alinsin, kdv_orani, acilis_tarihi, sube_kodu,
		   pn_islem_tanim_kod,	   pn_tx_no
	   FROM CBS_LEASING
	   WHERE musteri_no = pn_musteri_no AND
	   			 sozlesme_no = pn_sozlesme_no AND
 			 	 odeme_plan_no = pn_odeme_plan_no ;


   		INSERT INTO CBS_HESAP_KREDI_ISLEM(tx_no, islem_tanim_kod,
		hesap_no, musteri_no, doviz_kodu, tutar, durum_kodu, sube_kodu, musteri_dk_no,
		urun_tur_kod, urun_sinif_kod, modul_tur_kod, kredi_teklif_satir_numara, kredi_vade,
		kredi_kullandirim_kodu, endeks_doviz_kodu, kullandirim_doviz_kodu, son_gun_faizi,
		acilis_kuru, faiz_orani, faiz_siklik, faiz_siklik_tipi, faiz_tahakkuk_tarihi, komisyon_orani,
		komisyon_tutari, komisyon_tahsilat_donemi, fon_orani, bsmv_orani, alacak_hesap_no,
		iliskili_hesap_no, kur_farki, extre_masrafi, sinirlama_kodu, kaynak_kodu, istatistik_kodu,
		urun_grup_no, referans, faiz_tahakkuk_hesap_no, vergi_tahakkuk_hesap_no, birikmis_faiz_tutari,
		birikmis_komisyon_tutari, esas_gun_sayisi, acilis_tarihi, kapanis_tarihi, bsmv_alinsin,
		kkdf_alinsin, endeks_doviz_tutari, gecenyil_faiz_tutari, tahsiledilen_faiz_tutari,
		tahsiledilen_komisyon_tutari, gecenyil_komisyon_tutari, birikmis_sch_faizi, gecenyil_sch_faizi,
		son_islem_kuru, gecenyil_anaparakurfark_gelir, gecenyil_anaparakurfark_zarar,
		gecenyil_faizkurfark_gelir, gecenyil_faizkurfark_zarar, gecenyil_komiskurfark_gelir,
		gecenyil_komiskurfark_zarar, faiz_baslangic_tarihi, sch_faiz_orani, eski_hesap_no,
		eski_hesap_ekno, eski_faizhesap_ekno, eski_komhesap_ekno, odeme_turu,
		taksit_sayisi, taksit_once_sonra, artis_siklik, artis_oran, ara_odeme_siklik, ara_odeme_tutar,
		donem_siklik, kredi_turu, sch_faiz_tur, tahakkuk_sch_faiz_tutari			)

		SELECT pn_tx_no,pn_islem_tanim_kod, hesap_no, musteri_no, doviz_kodu, tutar, durum_kodu, sube_kodu, musteri_dk_no,
		urun_tur_kod, urun_sinif_kod, modul_tur_kod, kredi_teklif_satir_numara, kredi_vade,
		kredi_kullandirim_kodu, endeks_doviz_kodu, kullandirim_doviz_kodu, son_gun_faizi,
		acilis_kuru, faiz_orani, faiz_siklik, faiz_siklik_tipi, faiz_tahakkuk_tarihi, komisyon_orani,
		komisyon_tutari, komisyon_tahsilat_donemi, fon_orani, bsmv_orani, alacak_hesap_no,
		iliskili_hesap_no, kur_farki, extre_masrafi, sinirlama_kodu, kaynak_kodu, istatistik_kodu,
		urun_grup_no, referans, faiz_tahakkuk_hesap_no, vergi_tahakkuk_hesap_no, birikmis_faiz_tutari,
		birikmis_komisyon_tutari, esas_gun_sayisi, acilis_tarihi, kapanis_tarihi, bsmv_alinsin,
		kkdf_alinsin, endeks_doviz_tutari, gecenyil_faiz_tutari, tahsiledilen_faiz_tutari,
		tahsiledilen_komisyon_tutari, gecenyil_komisyon_tutari, birikmis_sch_faizi, gecenyil_sch_faizi,
		son_islem_kuru, gecenyil_anaparakurfark_gelir, gecenyil_anaparakurfark_zarar,
		gecenyil_faizkurfark_gelir, gecenyil_faizkurfark_zarar, gecenyil_komiskurfark_gelir,
		gecenyil_komiskurfark_zarar, faiz_baslangic_tarihi, sch_faiz_orani, eski_hesap_no,
		eski_hesap_ekno, eski_faizhesap_ekno, eski_komhesap_ekno,odeme_turu,
		taksit_sayisi, taksit_once_sonra, artis_siklik, artis_oran, ara_odeme_siklik, ara_odeme_tutar,
		donem_siklik, kredi_turu, sch_faiz_tur, tahakkuk_sch_faiz_tutari
		FROM CBS_HESAP_KREDI
		WHERE hesap_no = ln_hesap_no  ;

				 INSERT INTO CBS_HESAP_KREDI_TAKSIT_ISLEM
				 (
				 TX_NO, SIRA_NO, TAKSIT, ANAPARA, FAIZ, KKDF, BSMV, VADE_TARIH,
				 KAL_ANAPARA,KDV, KDVLI_TAKSIT, TAHSIL_EDILECEK_TAKSIT,
				 HESAP_NO, DURUM_KODU, ODEME_TARIHI,
				 GECIKME_FAIZ_TUTARI, KUR_TRL, ANAPARA_TRL, FAIZ_TRL, KDV_TRL
				  )
				 SELECT
				  pn_TX_NO, SIRA_NO, TAKSIT, ANAPARA, FAIZ, KKDF, BSMV,
				  VADE_TARIH, KAL_ANAPARA, KDV, KDVLI_TAKSIT, TAHSIL_EDILECEK_TAKSIT,
				  HESAP_NO, DURUM_KODU, ODEME_TARIHI,
				  GECIKME_FAIZ_TUTARI,KUR_TRL, ANAPARA_TRL, FAIZ_TRL, KDV_TRL
			FROM CBS_HESAP_KREDI_TAKSIT
		    WHERE hesap_no = ln_hesap_no ;
		--		  durum_kodu = 'A'  ;
		  BEGIN
			INSERT INTO CBS_HESAP_KREDI_OZEL_TKST_ISL
				(hesap_no ,
			     taksit_sira_no,
  			     odeme,
				 tx_no)
		  	SELECT
			   hesap_no      ,
			   taksit_sira_no     ,
  			   odeme ,
			   pn_tx_no
			FROM CBS_HESAP_KREDI_OZEL_TKST
		    WHERE hesap_no = ln_hesap_no  ;
		END;

 END;

  /*****************************************************************************************************************/
  /*  Function Sf_Bitmemis_HesapIslem_Var_Mi									               			   		   */
 /*****************************************************************************************************************/
 FUNCTION Sf_BitmemisIslem_Var_Mi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
 		  			 			  pn_sozlesme_no      CBS_LEASING.sozlesme_no%TYPE,
						   		  pn_odeme_plan_no		   CBS_LEASING.odeme_plan_no%TYPE,
 		  						  pn_islem_no CBS_ISLEM.numara%TYPE
								  ) RETURN NUMBER
  IS
    ln_tx_no   CBS_ISLEM.numara%TYPE  := 0;
	onayda_bekleyen_islem_var 		 EXCEPTION;
  BEGIN
	   SELECT  MAX(tx_no)
	   INTO    ln_tx_no
	   FROM   CBS_LEASING_ISLEM a , CBS_ISLEM b
	   WHERE  a.musteri_no = pn_musteri_no AND
	   		  a.sozlesme_no = pn_sozlesme_no AND
			  odeme_plan_no = pn_odeme_plan_no AND
	   		  a.tx_no = b.numara AND
			  a.tx_no <> pn_islem_no AND
	   		  Pkg_Tx.islem_bitmis_mi(b.numara)= 0;

	   IF  NVL(ln_tx_no,0) <> 0 THEN
	   	   RAISE 	onayda_bekleyen_islem_var;
	   END IF;

	   RETURN ln_tx_no ;

    EXCEPTION
	  WHEN OTHERS THEN
  	   	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '917' ||Pkg_Hata.getdelimiter|| ln_tx_no  || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
	END;

/*****************************************************************************************************************/
/*   Procedure sf_min_odenmemis_taksiti_bul								               			  */
  /****************************************************************************************************************/
	 PROCEDURE sf_min_odenmemis_taksiti_bul (pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
			 								 pd_vade_tarihi DATE ,
											 pn_taksit_sira_no  OUT NUMBER,
											 pd_taksit_vade OUT DATE )
	 IS

	 BEGIN
	 	  SELECT MIN(sira_no),MIN( vade_tarih)
		  INTO pn_taksit_sira_no  ,pd_taksit_vade
		  FROM CBS_HESAP_KREDI_TAKSIT
		  WHERE hesap_no = pn_hesap_no AND
		  		vade_tarih <= NVL(pd_vade_Tarihi,Pkg_Muhasebe.banka_tarihi_bul) AND
				durum_kodu = 'A';

	  EXCEPTION WHEN OTHERS THEN NULL;

	 END;

 FUNCTION Sf_TahsilHesap_UrunUygunmu(ps_urun_tur_kod CBS_HESAP_KREDI.urun_tur_kod%TYPE ) RETURN VARCHAR2
 IS
   ls_uygun VARCHAR2(1) := 'H';
 BEGIN
 /*
  if ps_urun_tur_kod in ( 'TASARRF-TP','TASARRF-YP','MUSTAK-TP','MUSTAK-YP') then
    	ls_uygun :=  'E';
  end if;
		   return 'H';
	*/
	 RETURN 'E';
    EXCEPTION
	  WHEN OTHERS THEN RETURN 'H';
	END ;

 /***************************************************************************************************************/
  /*   Function	sf_istatistikkod_uygunmu											      				      */
  /*   faiz istatistik kodlar?n?n d?viz koduna ba?l? olarak listelenmesini sa?lar  */
  /****************************************************************************************************************/
 FUNCTION sf_istatistikkod_uygunmu(ps_istatistik_kodu CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2
  IS
  ls_sonuc VARCHAR2(1) := 'H';
  BEGIN

	 /*  if  (ps_istatistik_kodu between '7300' and '7399' ) then
		  	  return 'E';
		else
	  	      return 'H';
		end if;
		*/
		RETURN 'E';
  EXCEPTION
	  WHEN NO_DATA_FOUND THEN RETURN 'H';
  END ;
------------------------------------------------------------------------------
 FUNCTION teklif_referans_al(pn_islem_no NUMBER) RETURN VARCHAR2 IS
  CURSOR c_0 IS
    SELECT referans, sozlesme_no
	  FROM CBS_LEASING_TEKLIF
	 WHERE yaratan_tx_no = pn_islem_no;
	r_0 c_0%ROWTYPE;
 BEGIN
  OPEN c_0;
    FETCH c_0 INTO r_0;
	IF c_0%NOTFOUND THEN
	   CLOSE c_0;
	   RETURN NULL;
	END IF;
   CLOSE c_0;
   RETURN TO_CHAR(r_0.sozlesme_no) || ' - ' || r_0.referans;
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_isleme_at_tklf(pn_islem_no NUMBER, ps_referans VARCHAR2, pn_islem_kod NUMBER) IS
 BEGIN
   INSERT INTO CBS_LEASING_ISLEM(tx_no, musteri_no, sozlesme_no, odeme_plan_no,
               hesap_no, durum_kodu, kredi_teklif_satir_numara, plan_doviz_kodu,
			   yurt_ici_disi, mal_bedeli_baz_maliyet, masraf_toplami, pesinat,
			   toplam_baz_maliyet, faiz_orani, vade_tarihi, istatistik_kodu,
			   aciklama, pesin_faiz_alinsin, pesin_faiz_orani, pesin_faiz_bas_tar,
			   donem_basi_sonu, odeme_turu, taksit_sayisi, taksit_once_sonra,
			   artis_siklik, artis_oran, ara_odeme_siklik, ara_odeme_tutar,
			   donem_siklik, kdv_alinsin, kdv_orani, acilis_tarihi, sube_kodu,
			   islem_tanim_kod, ilave_faiz,  referans, taksit_baslangic_tarihi,
			   devir_bedeli, devir_bedeli_doviz, kiralananin_yeri)
    (SELECT pn_islem_no, musteri_no, sozlesme_no, odeme_plan_no,
	        hesap_no, durum_kodu, kredi_teklif_satir_numara, plan_doviz_kodu,
			yurt_ici_disi, mal_bedeli_baz_maliyet, masraf_toplami, pesinat,
			toplam_baz_maliyet, faiz_orani, vade_tarihi, istatistik_kodu,
			aciklama, pesin_faiz_alinsin, pesin_faiz_orani, pesin_faiz_bas_tar,
			donem_basi_sonu, odeme_turu, taksit_sayisi, taksit_once_sonra,
			artis_siklik, artis_oran, ara_odeme_siklik, ara_odeme_tutar,
			donem_siklik, kdv_alinsin, kdv_orani, NULL, sube_kodu,
			pn_islem_kod, ilave_faiz, referans, acilis_tarihi,
			devir_bedeli, devir_bedeli_doviz, kiralananin_yeri
	   FROM CBS_LEASING_TEKLIF
	  WHERE referans = ps_referans);
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_isleme_at_asil(pn_islem_no NUMBER, ps_referans VARCHAR2, pn_islem_kod NUMBER) IS
 BEGIN
   INSERT INTO CBS_LEASING_ISLEM(tx_no, musteri_no, sozlesme_no, odeme_plan_no,
               hesap_no, durum_kodu, kredi_teklif_satir_numara, plan_doviz_kodu,
			   yurt_ici_disi, mal_bedeli_baz_maliyet, masraf_toplami, pesinat,
			   toplam_baz_maliyet, faiz_orani, vade_tarihi, istatistik_kodu,
			   aciklama, pesin_faiz_alinsin, pesin_faiz_orani, pesin_faiz_bas_tar,
			   donem_basi_sonu, odeme_turu, taksit_sayisi, taksit_once_sonra,
			   artis_siklik, artis_oran, ara_odeme_siklik, ara_odeme_tutar,
			   donem_siklik, kdv_alinsin, kdv_orani, acilis_tarihi, sube_kodu,
			   islem_tanim_kod, ilave_faiz,  referans, taksit_baslangic_tarihi,
			   devir_bedeli, devir_bedeli_doviz, kiralananin_yeri, sch_faiz_orani )
    (SELECT pn_islem_no, musteri_no, sozlesme_no, odeme_plan_no,
	        hesap_no, durum_kodu, kredi_teklif_satir_numara, plan_doviz_kodu,
			yurt_ici_disi, mal_bedeli_baz_maliyet, masraf_toplami, pesinat,
			toplam_baz_maliyet, faiz_orani, vade_tarihi, istatistik_kodu,
			aciklama, pesin_faiz_alinsin, pesin_faiz_orani, pesin_faiz_bas_tar,
			donem_basi_sonu, odeme_turu, taksit_sayisi, taksit_once_sonra,
			artis_siklik, artis_oran, ara_odeme_siklik, ara_odeme_tutar,
			donem_siklik, kdv_alinsin, kdv_orani, acilis_tarihi, sube_kodu,
			pn_islem_kod, ilave_faiz, referans, taksit_baslangic_tarihi,
			devir_bedeli, devir_bedeli_doviz, kiralananin_yeri, sch_faiz_orani
	   FROM CBS_LEASING
	  WHERE referans = ps_referans);
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_taksit_isleme_at_hesap(pn_islem_no NUMBER, pn_hesap_no NUMBER) IS
 BEGIN
   INSERT INTO CBS_HESAP_KREDI_TAKSIT_ISLEM(tx_no, sira_no, taksit, anapara, faiz,
               kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit,
			   tahsil_edilecek_taksit, hesap_no, durum_kodu, odeme_tarihi,
			   kur_trl, anapara_trl, faiz_trl, kdv_trl, gecikme_faiz_tutari)
       (SELECT pn_islem_no,  sira_no, taksit, anapara, faiz,
	           kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit,
			   tahsil_edilecek_taksit, hesap_no, durum_kodu, odeme_tarihi,
			   kur_trl, anapara_trl, faiz_trl, kdv_trl, gecikme_faiz_tutari
	      FROM CBS_HESAP_KREDI_TAKSIT
	     WHERE hesap_no = pn_hesap_no);
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_taksit_isleme_at_tklf(pn_islem_no NUMBER, pn_musteri_no NUMBER,
                                    pn_sozlesme_no NUMBER, pn_odeme_plan_no NUMBER) IS
 BEGIN
   INSERT INTO CBS_HESAP_KREDI_TAKSIT_ISLEM(tx_no, sira_no, taksit, anapara, faiz,
               kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit,
			   tahsil_edilecek_taksit, hesap_no, durum_kodu, odeme_tarihi,
			   kur_trl, anapara_trl, faiz_trl, kdv_trl)
       (SELECT pn_islem_no,  sira_no, taksit, anapara, faiz,
	           kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit,
			   tahsil_edilecek_taksit, hesap_no, durum_kodu, odeme_tarihi,
			   kur_trl, anapara_trl, faiz_trl, kdv_trl
	      FROM CBS_LEASING_TAKSIT_TEKLIF
	     WHERE musteri_no = pn_musteri_no
		   AND sozlesme_no = pn_sozlesme_no
		   AND odeme_plan_no = pn_odeme_plan_no);
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_ozel_taksit_isleme_at(pn_islem_no NUMBER, pn_hesap_no NUMBER) IS
 BEGIN
	INSERT INTO CBS_HESAP_KREDI_OZEL_TKST_ISL(hesap_no, taksit_sira_no, odeme, tx_no)
		  	SELECT hesap_no, taksit_sira_no, odeme, pn_islem_no
			  FROM CBS_HESAP_KREDI_OZEL_TKST
		     WHERE hesap_no = pn_hesap_no  ;
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2) IS
  CURSOR c_0 IS
   SELECT musteri_no, sozlesme_no, odeme_plan_no
     FROM CBS_LEASING_TEKLIF
	WHERE referans = ps_referans;
  r_0 c_0%ROWTYPE;

 BEGIN
   OPEN c_0;
   FETCH c_0 INTO r_0;
   CLOSE c_0;

   leasing_isleme_at_tklf(pn_islem_no, ps_referans, 3261);

   INSERT INTO CBS_LEASING_FATURA_ISLEM (tx_no, sira_no, musteri_no, sozlesme_no,
               odeme_plan_no, hesap_no, durum_kodu, ana_mal_kodu, detay_mal_kodu,
			   fatura_kdv_orani, fatura_tarih, fatura_no, fatura_doviz, fatura_tutar,
			   fatura_kdv_tutar, fatura_toplam_tutar, fatura_parite,
			   fatura_plan_dvz_karsilik, satici_unvani, satici_adresi,
			   referans, proforma_fatura)
    (SELECT pn_islem_no, sira_no, musteri_no, sozlesme_no,
	        odeme_plan_no, hesap_no, durum_kodu, ana_mal_kodu, detay_mal_kodu,
			fatura_kdv_orani, fatura_tarih, fatura_no, fatura_doviz, fatura_tutar,
			fatura_kdv_tutar, fatura_toplam_tutar, fatura_parite,
			fatura_plan_dvz_karsilik, satici_unvani, satici_adresi,
			referans, proforma_fatura
	   FROM CBS_LEASING_FATURA_TKLF
	  WHERE referans = ps_referans);

   INSERT INTO CBS_LEASING_KEFIL_ISLEM (tx_no, referans, sira_no, unvani, kanuni_adresi, durum_kodu)
    (SELECT pn_islem_no, referans, sira_no, unvani, kanuni_adresi, durum_kodu
	  FROM CBS_LEASING_KEFIL
	 WHERE referans = ps_referans);

	leasing_taksit_isleme_at_tklf(pn_islem_no, r_0.musteri_no, r_0.sozlesme_no, r_0.odeme_plan_no);

   INSERT INTO CBS_HESAP_KREDI_OZEL_TKST_ISL(tx_no, taksit_sira_no, odeme, hesap_no)
		(SELECT pn_islem_no, taksit_sira_no, odeme,  hesap_no
		   FROM CBS_LEASING_TEKLIF_OZEL_TKST
		  WHERE musteri_no = r_0.musteri_no
		    AND sozlesme_no = r_0.sozlesme_no
			AND odeme_plan_no =  r_0.odeme_plan_no);
 END;
------------------------------------------------------------------------------
 FUNCTION son_gercek_taksit_tarihi(pn_islem_no NUMBER) RETURN DATE IS
  CURSOR c_0 IS
    SELECT * FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
	 WHERE tx_no = pn_islem_no
	 ORDER BY sira_no DESC;
  r_0 c_0%ROWTYPE;
  ld_date DATE;
 BEGIN
   OPEN c_0;
   LOOP
     FETCH c_0 INTO r_0;
	 IF c_0%NOTFOUND THEN
	    EXIT;
	 END IF;
     IF NVL(r_0.kal_anapara,0) = 0 THEN
	   ld_date := r_0.vade_tarih;
	 ELSE
	   EXIT;
	 END IF;
	END LOOP;
   CLOSE c_0;
   RETURN ld_date;
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_masraf_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2) IS
  CURSOR c_ls IS
   SELECT musteri_no, sozlesme_no, odeme_plan_no, hesap_no
     FROM CBS_LEASING
	WHERE referans = ps_referans;
  r_ls c_ls%ROWTYPE;

  CURSOR c_lms IS
   SELECT *
     FROM CBS_LEASING_MASRAF_ANA
	WHERE referans = ps_referans;
  r_lms c_lms%ROWTYPE;

  CURSOR c_bitmez IS
    SELECT NVL(COUNT(*),0) sayi
	  FROM CBS_LEASING_MASRAF_ANA_ISLEM, CBS_ISLEM
	 WHERE referans = ps_referans
	   AND numara = tx_no
	   AND numara <> pn_islem_no
	   AND Pkg_Tx.Islem_bitmis_mi(tx_no) = 0;
  ln_temp NUMBER;

 BEGIN
   OPEN c_bitmez;
   FETCH c_bitmez INTO ln_temp;
   CLOSE c_bitmez;
   IF ln_temp<>0 THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '721' ||  Pkg_Hata.getDelimiter || ps_referans || Pkg_Hata.getUCPOINTER);
   END IF;
   OPEN c_lms;
     FETCH c_lms INTO r_lms;
	 IF c_lms%NOTFOUND THEN
	   --ilk defa masraf tan?mlanacak
	    OPEN c_ls;
         FETCH c_ls INTO r_ls;
        CLOSE c_ls;
		INSERT INTO CBS_LEASING_MASRAF_ANA_ISLEM
		           (tx_no, referans, musteri_no, sozlesme_no, odeme_plan_no, durum_kodu)
		   VALUES (pn_islem_no, ps_referans, r_ls.musteri_no, r_ls.sozlesme_no, r_ls.odeme_plan_no, 'A');
		CLOSE c_lms;
		RETURN;
	 END IF;
   CLOSE c_lms;
   --daha ?nceden masraf girilmi?. Kay?t d?zeltilecek...
   INSERT INTO CBS_LEASING_MASRAF_ANA_ISLEM
	           (tx_no, referans, musteri_no, sozlesme_no, odeme_plan_no, durum_kodu)
	  VALUES (pn_islem_no, ps_referans, r_lms.musteri_no, r_lms.sozlesme_no, r_lms.odeme_plan_no, 'A');

   INSERT INTO CBS_LEASING_MASRAF_ISLEM(tx_no, sira_no, durum_kodu, belge_tarihi, belge_no, firma, odeme_tarihi, masraf_cinsi, masraf_doviz, masraf_tutar, masraf_kur_parite, plan_dvz_karsiligi,
   bloke_var, bloke_referans, bloke_tarihi, blokeli_tutar, referans)

       SELECT pn_islem_no, sira_no, durum_kodu, belge_tarihi, belge_no, firma, odeme_tarihi, masraf_cinsi, masraf_doviz, masraf_tutar, masraf_kur_parite, plan_dvz_karsiligi, bloke_var, bloke_referans,
 bloke_tarihi, blokeli_tutar, referans

	     FROM CBS_LEASING_MASRAF
		WHERE referans = ps_referans;
 END;
------------------------------------------------------------------------------
 FUNCTION leasing_hesap_no_al(ps_ref VARCHAR2) RETURN NUMBER IS
  CURSOR c_ls IS
   SELECT hesap_no
     FROM CBS_LEASING
	WHERE referans = ps_ref;
  r_ls c_ls%ROWTYPE;
 BEGIN
   OPEN c_ls;
    FETCH c_ls INTO r_ls;
    IF c_ls%NOTFOUND THEN
	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '722' ||  Pkg_Hata.getDelimiter || ps_ref || Pkg_Hata.getUCPOINTER);
	END IF;
   CLOSE c_ls;
   RETURN r_ls.hesap_no;
 END;
------------------------------------------------------------------------------
 FUNCTION leasing_plan_doviz_al(ps_ref VARCHAR2) RETURN VARCHAR2 IS
  CURSOR c_ls IS
   SELECT plan_doviz_kodu
     FROM CBS_LEASING
	WHERE referans = ps_ref;
  r_ls c_ls%ROWTYPE;
 BEGIN
   OPEN c_ls;
    FETCH c_ls INTO r_ls;
    IF c_ls%NOTFOUND THEN
	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '722' ||  Pkg_Hata.getDelimiter || ps_ref || Pkg_Hata.getUCPOINTER);
	END IF;
   CLOSE c_ls;
   RETURN r_ls.plan_doviz_kodu;
 END;
------------------------------------------------------------------------------
 FUNCTION masraf_cinsi_adi(pn_masraf_cinsi NUMBER) RETURN VARCHAR2 IS
 CURSOR c_0 IS
  SELECT aciklama
    FROM CBS_LEASING_MASRAF_CINS
   WHERE kod = pn_masraf_cinsi;
   r_0 c_0%ROWTYPE;
 BEGIN
    OPEN c_0;
	FETCH c_0 INTO r_0;
	IF c_0%NOTFOUND THEN
	  CLOSE c_0;
	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '723' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_masraf_cinsi)|| Pkg_Hata.getUCPOINTER);
    END IF;
	CLOSE c_0;
	RETURN r_0.aciklama;
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_tadilat_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2) IS
  CURSOR c_0 IS
   SELECT hesap_no
     FROM CBS_LEASING
	WHERE referans = ps_referans;
  r_0 c_0%ROWTYPE;
 BEGIN
   OPEN c_0;
   FETCH c_0 INTO r_0;
   CLOSE c_0;
   leasing_isleme_at_asil(pn_islem_no, ps_referans, 3263);
   leasing_masraf_kopyala(pn_islem_no, ps_referans);
   leasing_taksit_isleme_at_hesap(pn_islem_no, r_0.hesap_no);
   leasing_ozel_taksit_isleme_at(pn_islem_no, r_0.hesap_no);
 END;
------------------------------------------------------------------------------
 PROCEDURE leasing_tadilat_yap(pn_islem_no NUMBER, ps_referans VARCHAR2) IS
  CURSOR c_lms IS
  SELECT *
    FROM CBS_LEASING_MASRAF_ANA_ISLEM
   WHERE tx_no = pn_islem_no;
  r_lms c_lms%ROWTYPE;

  CURSOR c_pln IS
  SELECT *
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
   WHERE tx_no = pn_islem_no
     AND vade_tarih < Pkg_Muhasebe.banka_tarihi_bul
  ORDER BY sira_no
  FOR UPDATE;

  CURSOR c_pln_new IS
  SELECT *
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
   WHERE tx_no = pn_islem_no
     AND vade_tarih >= Pkg_Muhasebe.banka_tarihi_bul
  ORDER BY sira_no DESC
  FOR UPDATE;

  CURSOR c_pln_ilk IS
  SELECT *
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
   WHERE tx_no = pn_islem_no
     AND vade_tarih >= Pkg_Muhasebe.banka_tarihi_bul
	 AND durum_kodu = 'A'
	 AND anapara > 0
  ORDER BY sira_no ASC
  FOR UPDATE;
  r_pln_ilk c_pln_ilk%ROWTYPE;

  CURSOR c_pln_odenmis_gecmis IS
  SELECT *
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
   WHERE tx_no = pn_islem_no
     AND (  vade_tarih < Pkg_Muhasebe.banka_tarihi_bul
	     OR durum_kodu <> 'A')
  ORDER BY sira_no ASC
  FOR UPDATE;

  CURSOR c_ekle IS
  SELECT *
    FROM CBS_LEASING_MASRAF_ISLEM
   WHERE tx_no = pn_islem_no
     AND masraf_secildi = 'E'
   ORDER BY sira_no;

  CURSOR c_leas IS
  SELECT *
    FROM CBS_LEASING
   WHERE referans = ps_referans;
  r_leas c_leas%ROWTYPE;

  CURSOR c_pln_kalan_sayi IS
  SELECT NVL(COUNT(*),0) sayi
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
   WHERE tx_no = pn_islem_no
     AND vade_tarih >= Pkg_Muhasebe.banka_tarihi_bul
	 AND durum_kodu = 'A'
	 AND anapara > 0;
  r_pln_kalan c_pln_kalan_sayi%ROWTYPE;

  ln_ekle_faiz NUMBER := 0;
  ln_ekle_anapara NUMBER := 0;
  ln_blokeli NUMBER := 0;
  ln_faiz NUMBER := 0;
  ln_fark NUMBER := 0;
  ln_gun NUMBER;
  ln_sira NUMBER;
  ln_muaf_gun NUMBER;
  ln_ekle_tutar NUMBER;

  lv_odeme_1 Pkg_Type.v_odeme_plan;
  ln_kkdf_orani NUMBER := 0;
  ln_bsmv_orani NUMBER := 0;
  ls_vergi VARCHAR2(1) := 'H';
  ls_fon VARCHAR2(1) := 'H';
  ls_once_sonra VARCHAR2(6) := 'ONCEKI';
  ln_total_oran NUMBER := 0;
  ln_faiz_orani NUMBER;
  ls_kdv VARCHAR2(1);
  ln_kdv_orani  NUMBER;
  ln_taksit_sayi NUMBER;
  ls_doviz VARCHAR2(3);
  ln_kalan_anapara NUMBER;
  ld_ilk_taksit_tarih DATE;
  i NUMBER := 0;
  ld_ode_tar DATE;
 BEGIN
   OPEN c_lms;
   FETCH c_lms INTO r_lms;
   CLOSE c_lms;

   OPEN c_leas;
   FETCH c_leas INTO r_leas;
   CLOSE c_leas;

   DELETE FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
    WHERE tx_no = pn_islem_no;

   leasing_taksit_isleme_at_hesap(pn_islem_no, r_leas.hesap_no);

   Pkg_Parametre.deger(   'LEASING', NULL, NULL, 'MASRAF_MUAF_ISGUNU', ln_muaf_gun);

   FOR r_ekle IN c_ekle LOOP
    IF r_ekle.odeme_tarihi IS NULL THEN
	   ld_ode_tar := Pkg_Muhasebe.banka_tarihi_bul;
	ELSE
	   ld_ode_tar := r_ekle.odeme_tarihi;
	END IF;
    IF r_ekle.bloke_var = 'E' THEN
	  IF r_ekle.bloke_tarihi > Pkg_Tarih.ileri_gun(ld_ode_tar, ln_muaf_gun) THEN
	    --bloke masraf ?dendikten sonra konmu?. Aradaki faizini al
	    ln_gun := r_ekle.bloke_tarihi - ld_ode_tar;
	    ln_faiz := (ln_gun/360) * (NVL(r_ekle.plan_dvz_karsiligi, r_ekle.masraf_tutar) * r_leas.faiz_orani/100);
        ln_gun := Pkg_Muhasebe.banka_tarihi_bul - r_ekle.bloke_tarihi;
		ln_faiz := ln_faiz + (ln_gun/360) * ((NVL(r_ekle.plan_dvz_karsiligi, r_ekle.masraf_tutar)-r_ekle.blokeli_tutar)* r_leas.faiz_orani/100);
	  END IF;
	ELSE
	  IF Pkg_Muhasebe.banka_tarihi_bul > Pkg_Tarih.ileri_gun(ld_ode_tar, ln_muaf_gun) THEN
	    --bloke yok ama muaf olarak tan?mlanan s?re i?inde getirmemi?. Faiz Al.
		  ln_gun := Pkg_Muhasebe.banka_tarihi_bul - ld_ode_tar;
		  ln_faiz := (ln_gun/360) * (NVL(r_ekle.plan_dvz_karsiligi, r_ekle.masraf_tutar) * r_leas.faiz_orani/100);
	  ELSE
	      ln_gun := 0;
		  ln_faiz := 0;
	  END IF;
	END IF;
	ln_ekle_faiz := ln_ekle_faiz + ln_faiz;   --toplam faizi bul
	ln_ekle_anapara := ln_ekle_anapara + NVL(r_ekle.plan_dvz_karsiligi, r_ekle.masraf_tutar); --toplam anaparay? bul
	ln_blokeli := ln_blokeli + NVL(r_ekle.blokeli_tutar,0);
	ln_faiz := 0;
   END LOOP;

   IF r_lms.tadilat_yontem = 'ARATAKSIT' THEN
       FOR r_pln IN c_pln LOOP
		   --tarihi ge?mi?lerin kalan ana paras?n? artt?r.
		   UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
		      SET kal_anapara = kal_anapara + ln_ekle_anapara
			WHERE CURRENT OF c_pln;
	   END LOOP;
       FOR r_pln IN c_pln_new LOOP
		   --tarihi gelmemi?lerin sirasin? artt?r.
		   ln_sira := r_pln.sira_no;
		   UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
		      SET sira_no = sira_no + 1
			WHERE CURRENT OF c_pln_new;
	   END LOOP;
	   INSERT INTO CBS_HESAP_KREDI_TAKSIT_ISLEM(
	               tx_no, sira_no, taksit, anapara, faiz,
				   vade_tarih, kal_anapara, kdv, kdvli_taksit,
				   tahsil_edilecek_taksit, hesap_no, durum_kodu)
			SELECT pn_islem_no, ln_sira, taksit, anapara, faiz,
				   vade_tarih, kal_anapara, kdv, kdvli_taksit,
				   tahsil_edilecek_taksit, hesap_no, 'A'
			  FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
			 WHERE tx_no = pn_islem_no
			   AND sira_no = ln_sira + 1;
	   UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
	      SET taksit = ln_ekle_faiz + ln_ekle_anapara,
		      anapara = ln_ekle_anapara,
			  faiz = ln_ekle_faiz,
			  vade_tarih = Pkg_Muhasebe.banka_tarihi_bul,
			  kdv = (ln_ekle_faiz + ln_ekle_anapara) * NVL(r_leas.kdv_orani,0)/100,
			  kdvli_taksit = ln_ekle_faiz + ln_ekle_anapara + ((ln_ekle_faiz + ln_ekle_anapara)* NVL(r_leas.kdv_orani,0)/100),
			  tahsil_edilecek_taksit =  ln_ekle_faiz + ln_ekle_anapara + ((ln_ekle_faiz + ln_ekle_anapara)* NVL(r_leas.kdv_orani,0)/100)
		WHERE tx_no = pn_islem_no
		  AND sira_no = ln_sira;
   ELSIF r_lms.tadilat_yontem = 'ILKTAKSIT' THEN
     	OPEN c_pln_ilk;
		FETCH c_pln_ilk INTO r_pln_ilk;
		IF c_pln_ilk%FOUND THEN
		   IF r_pln_ilk.vade_tarih>Pkg_Tarih.ileri_gun(Pkg_Muhasebe.banka_tarihi_bul, ln_muaf_gun) THEN
			   ln_gun := r_pln_ilk.vade_tarih - Pkg_Muhasebe.banka_tarihi_bul;
			   ln_fark := (ln_gun/360) * ((ln_ekle_anapara-ln_blokeli) * r_leas.faiz_orani/100);
		   ELSE
			   ln_gun := 0;
			   ln_fark := 0;
		   END IF;
	       FOR r_pln IN c_pln_odenmis_gecmis LOOP
			   --tarihi ge?mi?lerin veya ?denmi?lerin kalan ana paras?n? artt?r.
			   UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
			      SET kal_anapara = kal_anapara + ln_ekle_anapara
				WHERE CURRENT OF c_pln_odenmis_gecmis;
		   END LOOP;
		   ln_ekle_tutar := ln_ekle_faiz + ln_ekle_anapara + ln_fark;
		   UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
		      SET --kal_anapara = kal_anapara + ln_eklenecek,
			      anapara = anapara + ln_ekle_anapara,
			      taksit = taksit + ln_ekle_tutar,
			      faiz = faiz + ln_ekle_faiz + ln_fark,
      			  kdv = kdv + (ln_ekle_tutar * NVL(r_leas.kdv_orani,0)/100),
			      kdvli_taksit = kdvli_taksit + ln_ekle_tutar + (ln_ekle_tutar * NVL(r_leas.kdv_orani,0)/100),
			      tahsil_edilecek_taksit = tahsil_edilecek_taksit + ln_ekle_tutar + (ln_ekle_tutar * NVL(r_leas.kdv_orani,0)/100)
		    WHERE CURRENT OF c_pln_ilk;
		ELSE
		  CLOSE c_pln_ilk;
		  --?denecek taksit kalmam?? hatas?.....
	  	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '724' || Pkg_Hata.getUCPOINTER);
		END IF;
		CLOSE c_pln_ilk;
   ELSE   --esit dagit cbs_leasing
     ln_faiz_orani := r_leas.faiz_orani/12; --faizoran? y?ll?k
     ls_kdv := r_leas.kdv_alinsin;
     ln_kdv_orani := r_leas.kdv_orani;
     ls_doviz := r_leas.plan_doviz_kodu;
	 OPEN c_pln_kalan_sayi;
	 FETCH c_pln_kalan_sayi INTO r_pln_kalan;
	 CLOSE c_pln_kalan_sayi;
	 IF r_pln_kalan.sayi = 0 THEN
	  	RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '724' || Pkg_Hata.getUCPOINTER);
	 END IF;
     ln_taksit_sayi := r_pln_kalan.sayi;
	 OPEN c_pln_ilk;
	 FETCH c_pln_ilk INTO r_pln_ilk;
	 IF c_pln_ilk%FOUND THEN
	    IF r_pln_ilk.vade_tarih>Pkg_Tarih.ileri_gun(Pkg_Muhasebe.banka_tarihi_bul, ln_muaf_gun) THEN
		   ln_gun := r_pln_ilk.vade_tarih - Pkg_Muhasebe.banka_tarihi_bul;
		   ln_fark := (ln_gun/360) * ((ln_ekle_anapara-ln_blokeli) * r_leas.faiz_orani/100);
	    ELSE
		   ln_gun := 0;
		   ln_fark := 0;
	    END IF;
	 ELSE
	   CLOSE c_pln_ilk;
	  --?denecek taksit kalmam?? hatas?.....
  	   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '724' || Pkg_Hata.getUCPOINTER);
	 END IF;
	 CLOSE c_pln_ilk;
     ld_ilk_taksit_tarih := r_pln_ilk.vade_tarih;
     ln_kalan_anapara := ln_ekle_anapara;
   	 lv_odeme_1 := Pkg_Type.v_odeme_plan();
     Pkg_Faiz_Hesaplari.sabit_odemeli(lv_odeme_1,
	               ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani,
	               ln_total_oran, ln_kdv_orani, ls_vergi, ls_fon, ls_kdv,
			  	   ln_taksit_sayi, ls_doviz, ln_kalan_anapara, ld_ilk_taksit_tarih,
			  	   ls_once_sonra, pd_donem_bas_son =>'S', pn_faiz_ilave=>0);
	 FOR r_pln IN c_pln_ilk LOOP
	   i := i+1;
	   UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
	      SET kal_anapara = kal_anapara + lv_odeme_1(i).v_kalan_anapara,
		      anapara = anapara + lv_odeme_1(i).v_anapara,
		      taksit = taksit + lv_odeme_1(i).v_taksit,
		      faiz = faiz + lv_odeme_1(i).v_faiz,
     		  kdv = kdv + lv_odeme_1(i).v_kdv,
		      kdvli_taksit = kdvli_taksit + lv_odeme_1(i).v_taksit + lv_odeme_1(i).v_kdv,
		      tahsil_edilecek_taksit = tahsil_edilecek_taksit + lv_odeme_1(i).v_taksit + lv_odeme_1(i).v_kdv
	    WHERE CURRENT OF c_pln_ilk;
	    IF i = 1 THEN
		   UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
		      SET taksit = taksit + ln_ekle_faiz + ln_fark,
			      faiz = faiz + ln_ekle_faiz + ln_fark,
	     		  kdv = kdv + (ln_ekle_faiz + ln_fark) * NVL(r_leas.kdv_orani,0)/100,
			      kdvli_taksit = kdvli_taksit + ln_ekle_faiz + ln_fark + ((ln_ekle_faiz + ln_fark) * NVL(r_leas.kdv_orani,0)/100),
			      tahsil_edilecek_taksit = tahsil_edilecek_taksit +  ln_ekle_faiz + ln_fark + ((ln_ekle_faiz + ln_fark) * NVL(r_leas.kdv_orani,0)/100)
		    WHERE CURRENT OF c_pln_ilk;
		END IF;
	 END LOOP;
   END IF;
 END;
------------------------------------------------------------------------------
 FUNCTION odeme_plan_anapara_al(pn_hesap_no NUMBER) RETURN NUMBER IS
 CURSOR c_0 IS
   SELECT NVL(SUM(NVL(anapara,0)),0)
     FROM CBS_HESAP_KREDI_TAKSIT
	WHERE hesap_no = pn_hesap_no;
  ln_temp NUMBER;
 BEGIN
  OPEN c_0;
  FETCH c_0 INTO ln_temp;
  CLOSE c_0;
  RETURN ln_temp;
 END;
------------------------------------------------------------------------------
 FUNCTION odeme_plan_kalan_faiz_al(pn_hesap_no NUMBER) RETURN NUMBER IS
 CURSOR c_0 IS
   SELECT NVL(SUM(NVL(faiz,0)),0)
     FROM CBS_HESAP_KREDI_TAKSIT
	WHERE hesap_no = pn_hesap_no
	  AND durum_kodu = 'A';
  ln_temp NUMBER;
 BEGIN
  OPEN c_0;
  FETCH c_0 INTO ln_temp;
  CLOSE c_0;
  RETURN ln_temp;
 END;
------------------------------------------------------------------------------
 FUNCTION odeme_plan_kalan_kdv_al(pn_hesap_no NUMBER) RETURN NUMBER IS
 CURSOR c_0 IS
   SELECT NVL(SUM(NVL(kdv,0)),0)
     FROM CBS_HESAP_KREDI_TAKSIT
	WHERE hesap_no = pn_hesap_no
	  AND durum_kodu = 'A';
  ln_temp NUMBER;
 BEGIN
  OPEN c_0;
  FETCH c_0 INTO ln_temp;
  CLOSE c_0;
  RETURN ln_temp;
 END;
------------------------------------------------------------------------------
 FUNCTION teklif_yaratan_tx_no(ps_ref VARCHAR2) RETURN NUMBER IS
 CURSOR c_0 IS
   SELECT yaratan_tx_no
     FROM CBS_LEASING_TEKLIF
	WHERE referans = ps_ref;
   ln_temp NUMBER;
 BEGIN
  OPEN c_0;
  FETCH c_0 INTO ln_temp;
  CLOSE c_0;
  RETURN ln_temp;
 END;

------------------------------------------------------------------------------
 FUNCTION son_gercek_taksit_sayisi(pn_hesap_no NUMBER) RETURN NUMBER IS
  CURSOR c_0 IS
    SELECT * FROM CBS_HESAP_KREDI_TAKSIT
	 WHERE hesap_no = pn_hesap_no
	 ORDER BY sira_no DESC;
  r_0 c_0%ROWTYPE;
  ln_sira NUMBER;
 BEGIN
   OPEN c_0;
   LOOP
     FETCH c_0 INTO r_0;
	 IF c_0%NOTFOUND THEN
	    EXIT;
	 END IF;
     IF NVL(r_0.kal_anapara,0) = 0 THEN
	   ln_sira := r_0.sira_no;
	 ELSE
	   EXIT;
	 END IF;
	END LOOP;
   CLOSE c_0;
   RETURN ln_sira;
 END;
------------------------------------------------------------------------------
 END Pkg_Leasing;
/

