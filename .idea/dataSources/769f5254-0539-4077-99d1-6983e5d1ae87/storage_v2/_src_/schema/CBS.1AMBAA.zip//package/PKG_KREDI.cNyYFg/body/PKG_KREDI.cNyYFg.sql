create PACKAGE BODY     "PKG_KREDI" IS
 /*****************************************************************************************************************/
 /*   Function Kredi Teklif_ReferansNo_Al                                                                                  */
 /*   kredi teklif referans numarasi alinir                                                                           */
 /*****************************************************************************************************************/
  FUNCTION  Sf_Kredi_Teklif_ReferansNo_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu   CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_referans     VARCHAR2(20);
     ln_sira_no      NUMBER := 0;
   BEGIN
/* islemi yaratan kullanicinin bolum kodu alinir . */
     ls_bolum_kodu := Pkg_Baglam.bolum_kodu ;
     ls_referans   := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.KRD';
     ln_sira_no    := Pkg_Genel.genel_kod_al(ls_referans);
     ls_referans   := ls_referans || '.' ||LPAD(ln_sira_no,5,0);

     RETURN ls_referans;

    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '285' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END Sf_Kredi_Teklif_ReferansNo_Al;

  /*****************************************************************************************************************/
  /*   Function    Sf_Kredi_Kullandir_Acikla                                                                             */
  /*   kredi kulland?r a??klamesi al?n?r                                                                             */
  /****************************************************************************************************************/
  FUNCTION Sf_Kredi_Kullandir_Acikla( ps_kullandirim_kodu CBS_KREDI_KULLANDIRIM_KODLARI.kullandirim_kodu%TYPE ) RETURN CBS_BLOKE_NEDEN_KODLARI.aciklama%TYPE
  IS
     ls_aciklama   CBS_KREDI_KULLANDIRIM_KODLARI.aciklama%TYPE ;
    BEGIN

       SELECT aciklama
       INTO   ls_aciklama
       FROM   CBS_KREDI_KULLANDIRIM_KODLARI
       WHERE  kullandirim_kodu =  ps_kullandirim_kodu;

       RETURN ls_aciklama;

    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '427' || Pkg_Hata.getUCPOINTER);
    END  Sf_Kredi_Kullandir_Acikla;

  /*****************************************************************************************************************/
  /*   Function    sf_kredi_Urun_Doviz_Kodu_LC_mi                                                                             */
  /*  d?viz kodu local currency mi                                                                                       */
  /****************************************************************************************************************/
  FUNCTION Sf_kredi_Urun_Doviz_Kodu_LC_mi(pn_kredi_turu_numara CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2
  IS
     ls_lc  VARCHAR2(1) := 'H';
  BEGIN

       SELECT lc_mi
       INTO   ls_lc
       FROM   CBS_URUN_GRUBU
       WHERE  numara = pn_kredi_turu_numara;

       RETURN ls_lc ;

    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '455' || Pkg_Hata.getUCPOINTER);
  END  sf_kredi_urun_Doviz_Kodu_LC_mi;
  /*****************************************************************************************************************/
  /*    Function sf_teklif_durumu_al                                                                         */
  /****************************************************************************************************************/
 FUNCTION sf_teklif_durumu_al(pn_kredi_teklif_no CBS_KREDI_TEKLIF.TEKLIF_no%TYPE ) RETURN  VARCHAR2
  IS
     ls_durum CBS_KREDI_TEKLIF.durum_kodu%TYPE;
  BEGIN

        SELECT durum_kodu
      INTO ls_durum
      FROM CBS_KREDI_TEKLIF
      WHERE teklif_no = pn_kredi_teklif_no;

      RETURN ls_durum ;

    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '569' ||  Pkg_Hata.getdelimiter|| TO_CHAR(pn_kredi_teklif_no)|| Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END ;

  /*****************************************************************************************************************/
  /*  Procedure sp_krediteklif_bilgisi_al                                                                     */
  /****************************************************************************************************************/
 PROCEDURE sp_krediteklif_bilgisi_al(pn_kredi_teklif_no CBS_KREDI_TEKLIF.teklif_no%TYPE ,
                                     ps_modul_tur_kod    OUT CBS_KREDI_TEKLIF.modul_tur_kod%TYPE,
                                    ps_urun_tur_kod        OUT CBS_KREDI_TEKLIF.urun_tur_kod%TYPE,
                                    ps_urun_sinif_kod    OUT CBS_KREDI_TEKLIF.urun_sinif_kod%TYPE,
                                    pn_musteri_no        OUT CBS_KREDI_TEKLIF.musteri_no%TYPE,
                                    ps_teklif_referans    OUT CBS_KREDI_TEKLIF.teklif_referans%TYPE,
                                    pd_teklif_tarihi    OUT CBS_KREDI_TEKLIF.teklif_tarihi%TYPE,
                                    ps_teklif_turu        OUT CBS_KREDI_TEKLIF.teklif_turu%TYPE,
                                    ps_teklif_durumu    OUT CBS_KREDI_TEKLIF.durum_kodu%TYPE)
 IS
 BEGIN
       SELECT modul_tur_kod,urun_tur_kod,
               urun_sinif_kod,musteri_no,teklif_referans,
             teklif_tarihi,teklif_turu,durum_kodu
     INTO      ps_modul_tur_kod,ps_urun_tur_kod,ps_urun_sinif_kod,
               pn_musteri_no,ps_teklif_referans,pd_teklif_tarihi,
             ps_teklif_turu,ps_teklif_durumu
      FROM  CBS_KREDI_TEKLIF
      WHERE teklif_no =pn_kredi_teklif_no;

 END;

  /*****************************************************************************************************************/
  /*  Function sf_islemden_teklifmusteri_al                                                                 */
  /****************************************************************************************************************/
 FUNCTION sf_islemden_teklifmusteri_al(    pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE) RETURN CBS_MUSTERI.musteri_no%TYPE
 IS
   ln_musteri_no CBS_MUSTERI.musteri_no%TYPE;
  BEGIN
               SELECT musteri_numara
          INTO ln_musteri_no
          FROM   CBS_ISLEM
          WHERE  numara = pn_tx_no;

    RETURN ln_musteri_no;
  END;

  /*****************************************************************************************************************/
  /*   Function    Sf_MusteriTipi_Teklife_Uygun                                                                             */
  /*   kredi kulland?r a??klamesi al?n?r                                                                             */
  /****************************************************************************************************************/

  FUNCTION Sf_MusteriTipi_Teklife_Uygun( ps_musteri_tipi CBS_MUSTERI.musteri_tipi_kod%TYPE) RETURN VARCHAR2
  IS
     ls_uygun  VARCHAR2(1) := 'H';
  BEGIN
        ls_uygun:= case  when ps_musteri_tipi='4' then 'H' else 'E' end; --seval.colak 10112021 Viktors optimization request
      /* SELECT DECODE( ps_musteri_tipi,'4','H','E') --4:Banks mutluo 21.10.2004 Almati  --seval.colak 10112021 Viktors optimization request 
       INTO ls_uygun
       FROM dual;
       */
       RETURN ls_uygun ;

    EXCEPTION
      WHEN OTHERS THEN RETURN 'H';
  END Sf_MusteriTipi_Teklife_Uygun;

  /******************************************************************************************************************/
  /*   Function sf_bitmemis_islem_var_mi                                                                                     */
  /*   girilen musteri numaras?na ait onay bekleyen bitmemi? i?lem var m?                                           */
  /******************************************************************************************************************/
 FUNCTION  Sf_Bitmemis_TeklifIslem_Var_Mi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                             pn_islem_no   CBS_ISLEM.numara%TYPE ,
                                         pn_islem_tanim_kod CBS_ISLEM.islem_kod%TYPE DEFAULT NULL) RETURN NUMBER

  IS
    ln_tx_no   CBS_ISLEM.numara%TYPE  := 0;
    ln_teklif_no   NUMBER  := 0;
    onayda_bekleyen_islem_var          EXCEPTION;
    onay_bekleyen_teklif_giris_var  EXCEPTION;
  BEGIN
       SELECT  MAX(tx_no)
       INTO    ln_tx_no
       FROM   CBS_ISLEM b, CBS_KREDI_TEKLIF_ISLEM a
       WHERE  a.musteri_no = pn_musteri_no AND
                 a.tx_no = b.numara AND
              a.tx_no <> pn_islem_no AND
                 Pkg_Tx.ISLEM_BITMIS_MI(b.numara)= 0;


       IF  NVL(ln_tx_no,0) <> 0 THEN
              RAISE     onayda_bekleyen_islem_var;
        ELSE
        -- Yeni giris a?amesinda kontrol edilir (1300), teklif onayi yapilmamis yeni giris varsa */
            IF      pn_islem_tanim_kod IS NOT NULL THEN
                 SELECT MAX(teklif_no)
                   INTO   ln_teklif_no
                    FROM   CBS_KREDI_TEKLIF
                 WHERE  musteri_no IN (SELECT musteri_no
                                           FROM CBS_KREDI_TEKLIF_ISLEM a
                                       WHERE  a.musteri_no = pn_musteri_no )
                        AND durum_kodu = 'Y';
                 IF NVL(ln_teklif_no,0) <> 0 THEN
                     RAISE onay_bekleyen_teklif_giris_var;
                 END IF;
            END IF;
       END IF;


       RETURN NVL(ln_tx_no,0) ;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 0;
       WHEN onay_bekleyen_teklif_giris_var THEN
               RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '515' ||Pkg_Hata.getdelimiter|| TO_CHAR(ln_teklif_no)  || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
      WHEN onayda_bekleyen_islem_var THEN
               RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '456' ||Pkg_Hata.getdelimiter|| TO_CHAR(ln_tx_no)  || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '457' || Pkg_Hata.getUCPOINTER);
    END;

  /******************************************************************************************************************/
  /*   Function  Sf_Onayli_Teklifi_VarMi                                                                                 */
  /*   girilen musteri numaras?na ait onayli teklif numarasi varsa teklif numarasi dondurulur                         */
  /******************************************************************************************************************/
 FUNCTION   Sf_Onayli_Teklifi_VarMi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN NUMBER
   IS
    ln_teklif_no   CBS_KREDI_TEKLIF.teklif_no%TYPE  := 0;
  BEGIN
       SELECT  MAX(teklif_no)
       INTO    ln_teklif_no
       FROM    CBS_KREDI_TEKLIF a
       WHERE   a.musteri_no = pn_musteri_no AND
                  durum_kodu = 'A' ;

       RETURN nvl(ln_teklif_no,0) ;

    EXCEPTION
      WHEN OTHERS THEN RETURN 0;
    END;

  /******************************************************************************************************************/
  /*   Function  Sf_Bekleyen_Kredi_Teklif_No_Al                                                                             */
  /*   girilen Y yeni giris durum kodunda onay bekleyen teklif numaras? bulunur.                         */
  /******************************************************************************************************************/
  FUNCTION  Sf_Bekleyen_Kredi_Teklif_No_Al(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE ) RETURN CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE
  IS
    ln_teklif_no   CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE;
  BEGIN

    SELECT MAX(teklif_no)
    INTO ln_teklif_no
    FROM CBS_KREDI_TEKLIF
    WHERE durum_kodu = 'Y' AND
          musteri_no = pn_musteri_no;

     RETURN ln_teklif_no ;
    EXCEPTION
      WHEN OTHERS THEN RETURN 0;

  END;

  /******************************************************************************************************************/
  /*   Function Sf_Varolan_Teklifden_Uretilmis                                                                     */
  /*   girilen tekilf numaras?n?n varolan bir teklifden uretildiyse reff_teklif_no su dondurulur                    */
  /******************************************************************************************************************/
 FUNCTION  Sf_Varolan_Teklifden_Uretilmis(pn_teklif_no CBS_KREDI_TEKLIF.teklif_no%TYPE) RETURN NUMBER
 IS

    ln_teklif_no   CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE;
  BEGIN

    SELECT MAX(ref_teklif_no)
    INTO ln_teklif_no
    FROM CBS_KREDI_TEKLIF
    WHERE teklif_no = pn_teklif_no;
     IF pn_teklif_no <>  ln_teklif_no THEN
          RETURN ln_teklif_no ;
     ELSE
          RETURN 0 ;
     END IF;

    EXCEPTION
      WHEN OTHERS THEN RETURN 0;

  END;


  /*****************************************************************************************************************/
  /*   Procedure Sp_KrediTeklifi_AnaTabloya_At                                                                          */
  /*   Kredi teklif i?lem tablolar?ndan ana tablolara kay?t aktar?lmesi                                            */
  /****************************************************************************************************************/

  PROCEDURE Sp_KrediTeklifi_AnaTabloya_At(pn_tx_no CBS_ISLEM.numara%TYPE)
  IS
    ln_teklif_no       CBS_KREDI_TEKLIF.teklif_no%TYPE;
    ln_islem_tanim_kod CBS_KREDI_TEKLIF_ISLEM.islem_tanim_kod%TYPE;
    ln_musteri_no       CBS_KREDI_TEKLIF.musteri_no%TYPE;
    ls_bolum_kodu       varchar2(10);
    ln_row_counter          integer := 0;
    ln_counter           integer := 0;
    
    --BOM ErkinZu 22.04.17 cq614
    TYPE appNoSatirRec IS RECORD(
        app CBS_KREDI_TEKLIF_SATIR_ISLEM.APP_NO%TYPE,
        satir CBS_KREDI_TEKLIF_SATIR_ISLEM.TEKLIF_SATIR_NO%TYPE
    );
    TYPE appNoSatirTab IS TABLE of appNoSatirRec;
    appNoSatirVar appNoSatirTab := appNoSatirTab();
    
    CURSOR satir_islem_cur IS
    SELECT app_no, teklif_satir_no
    FROM CBS_KREDI_TEKLIF_SATIR_ISLEM
    WHERE tx_no =pn_tx_no and satir_durum is null;
    --EOM ErkinZu 22.04.17 cq614
  BEGIN
      SELECT teklif_no ,islem_tanim_kod ,musteri_no ,bolum_kodu
      INTO ln_teklif_no ,ln_islem_tanim_kod,ln_musteri_no,ls_bolum_kodu
      FROM CBS_KREDI_TEKLIF_ISLEM
      WHERE tx_no =pn_tx_no ;

      --BOM ErkinZu cq 614
      BEGIN
        --If count is 0 then there are no new lines in this TX
        select count(*) 
        into ln_row_counter
        from CBS_KREDI_TEKLIF_SATIR_ISLEM
        where tx_no =pn_tx_no and satir_durum is null; 
        
        if ln_row_counter > 0 then   
          FOR satir_isl IN satir_islem_cur LOOP
            ln_counter := ln_counter + 1;
            appNoSatirVar.extend();
            appNoSatirVar(ln_counter).app := satir_isl.app_no;
            appNoSatirVar(ln_counter).satir := satir_isl.teklif_satir_no; 
          END LOOP;
        end if;
      END;
      --EOM ErkinZu cq 614

  /* kredi teklif islem tablosundan ana tablosuna kay?t aktar?lmesi */
     INSERT INTO CBS_KREDI_TEKLIF
     (teklif_no, teklif_tarihi, teklif_referans, musteri_no, teklif_turu, komite_tipi,
       kayit_giris_tarihi, kayit_yaratan_kullanici_kodu ,durum_kodu,ref_teklif_no,aciklama,
       modul_tur_kod,urun_tur_kod,urun_sinif_kod,bolum_kodu )  
     SELECT
       teklif_no, teklif_tarihi, teklif_referans, musteri_no, teklif_turu, komite_tipi,
       kayit_giris_tarihi, kayit_yaratan_kullanici_kodu,durum_kodu,ref_teklif_no,aciklama,
       modul_tur_kod,urun_tur_kod,urun_sinif_kod,ls_bolum_kodu 
     FROM CBS_KREDI_TEKLIF_ISLEM
     WHERE tx_no =pn_tx_no ;

  /* kredi teklif sat?r islem tablosundan ana tablosuna kay?t aktar?lmesi */
     INSERT INTO CBS_KREDI_TEKLIF_SATIR
     ( teklif_no,
      teklif_satir_no,
      kredi_turu,doviz_kodu,
      vade_suresi,vade_tipi,
      mevcut_risk_tl,
      mevcut_risk_yp,
      mevcut_limit_tl,
      mevcut_limit_yp,
      onerilen_limit_tl,
      onerilen_limit_yp,
      onerilen_vade_suresi,
      onerilen_vade_tipi,
      kredi_kullandirim_kodu,
      aciklama,
      satir_durum,
      ref_teklif_no,
      MUSTERI_NO,
      REF_TEKLIF_SATIR_NO ,
      LINE,
      tranches, -- AdiletK 08032016 CQ4713 adding tranches and maturity date
      maturity_date, -- AdiletK 08032016 CQ4713 adding tranches and maturity date
      real_limit, -- AdiletK 08032016 CQ4713 adding real limit
      app_no) --ErkinZu 07042017 CQ614 adding number of application
     SELECT
      ln_teklif_no,
      teklif_satir_no,
      kredi_turu,doviz_kodu,
      vade_suresi,vade_tipi,
      mevcut_risk_tl,
      mevcut_risk_yp,
      mevcut_limit_tl,
      mevcut_limit_yp,
      onerilen_limit_tl,
      onerilen_limit_yp,
      onerilen_vade_suresi,
      onerilen_vade_tipi,
      kredi_kullandirim_kodu,
      aciklama,satir_durum ,
      ref_teklif_no,
      ln_musteri_no,
      ref_teklif_satir_no,
      line,
      tranches, -- AdiletK 08032016 CQ4713 adding tranches and maturity date
      maturity_date,-- AdiletK 08032016 CQ4713 adding tranches and maturity date
      /* KalysbekA cbs-95 */
      case when nvl(tranches, 'N') = 'N' and nvl(line, 'NO') = 'YES' then onerilen_limit_yp
        when nvl(tranches, 'N') = 'N' and nvl(line, 'NO') = 'NO' then  mevcut_risk_yp --Kalysbeka cbs-340 02112020
        when nvl(tranches, 'N') = 'Y' and nvl(line, 'NO') = 'NO' then onerilen_limit_yp
      else 0
      end,
   /* KalysbekA cbs-95 */
     app_no --ErkinZu 07042017 CQ614 adding number of application
     FROM CBS_KREDI_TEKLIF_SATIR_ISLEM
     WHERE tx_no =pn_tx_no ;

  /* kredi teklif teminat islem tablosundan ana tablosuna kay?t aktar?lmesi */
    INSERT INTO CBS_KREDI_TEKLIF_TEMINAT
    ( teklif_no, sira_no, teminat_kodu, teminat_alt_kodu,
      tutar, marj,katilim_orani, alma_gun_sayisi,
      kayit_giris_tarihi, kayit_yaratan_kullanici_kodu,
      ref_teklif_no,doviz_kodu,ref_sira_no,grup_no)
    SELECT
     ln_teklif_no, sira_no, teminat_kodu, teminat_alt_kodu,
     tutar, marj,katilim_orani, NVL(alma_gun_sayisi,0),
     kayit_giris_tarihi, kayit_yaratan_kullanici_kodu,
     ref_teklif_no,doviz_kodu,ref_sira_no,NVL(grup_no,0)
    FROM CBS_KREDI_TEKLIF_TEMINAT_ISLEM
    WHERE tx_no = pn_tx_no ;

  /* kredi teklif sat?r teminat islem tablosundan ana tablosuna kay?t aktar?lmesi */
    INSERT INTO CBS_KREDI_TEKLIF_SATIR_TEMINAT
    (  teklif_no ,teklif_satir_no ,sira_no,teminat_kodu,teminat_alt_kodu,tutar,
      marj,katilim_orani,alma_gun_sayisi,kayit_giris_tarihi,kayit_yaratan_kullanici_kodu,
      ref_teklif_no,doviz_kodu , ref_teklif_satir_no ,ref_sira_no,grup_no)
    SELECT
      ln_teklif_no ,teklif_satir_no ,sira_no,teminat_kodu,teminat_alt_kodu,tutar,
      marj,katilim_orani,NVL(alma_gun_sayisi,0),kayit_giris_tarihi,kayit_yaratan_kullanici_kodu,
      ref_teklif_no,doviz_kodu , ref_teklif_satir_no,ref_sira_no,NVL(grup_no,0)
    FROM  CBS_KREDI_TKLF_SATIR_TMN_ISLM
    WHERE tx_no = pn_tx_no;

  /* kredi teklif limit islem tablosundan ana tablosuna kay?t aktar?lmesi */
   INSERT INTO CBS_KREDI_TEKLIF_LIMIT
    (  teklif_no, nakit_mevcut_risk_tl,
        nakit_mevcut_risk_yp, nakit_mevcut_limit_tl,
        nakit_mevcut_limit_yp,
        nakit_onerilen_limit_tl,
        nakit_onerilen_limit_yp,
        gayrinakit_mevcut_risk_tl,
        gayrinakit_mevcut_risk_yp,
        gayrinakit_mevcut_limit_tl,
        gayrinakit_mevcut_limit_yp,
        gayrinakit_onerilen_limit_tl,
        gayrinakit_onerilen_limit_yp,
        genel_doviz_kodu,
        genel_mevcut_risk_tl,
        genel_mevcut_risk_yp,
        genel_mevcut_limit_tl,
        genel_mevcut_limit_yp,
        genel_onerilen_limit_tl,
        genel_onerilen_limit_yp,
        grup_doviz_kodu,
        grup_mevcut_risk_tl,
        grup_mevcut_risk_yp,
        grup_mevcut_limit_tl,
        grup_mevcut_limit_yp,
        grup_onerilen_limit_tl,
        grup_onerilen_limit_yp,
        kayit_giris_tarihi,
        kayit_yaratan_kullanici_kodu,
        ref_teklif_no,
        aciklama,
        MEVCUT_YENILEME_VADE,
        ONERILEN_YENILEME_VADE,
        LINE, VALIDITY_DATE_OF_LINE, MEVCUT_LINE, MEVCUT_VALIDITY_DATE,MEVCUT_LIM_DVZ, --hs,20061205
        LINE_AMOUNT --sevalb 140607
        )
    SELECT
        ln_teklif_no,
        nakit_mevcut_risk_tl,
        nakit_mevcut_risk_yp,
        nakit_mevcut_limit_tl,
        nakit_mevcut_limit_yp,
        nakit_onerilen_limit_tl,
        nakit_onerilen_limit_yp,
        gayrinakit_mevcut_risk_tl,
        gayrinakit_mevcut_risk_yp,
        gayrinakit_mevcut_limit_tl,
        gayrinakit_mevcut_limit_yp,
        gayrinakit_onerilen_limit_tl,
        gayrinakit_onerilen_limit_yp,
        genel_doviz_kodu,
        genel_mevcut_risk_tl,
        genel_mevcut_risk_yp,
        genel_mevcut_limit_tl,
        genel_mevcut_limit_yp,
        genel_onerilen_limit_tl,
        genel_onerilen_limit_yp,
        grup_doviz_kodu,
        grup_mevcut_risk_tl,
        grup_mevcut_risk_yp,
        grup_mevcut_limit_tl,
        grup_mevcut_limit_yp,
        grup_onerilen_limit_tl,
        grup_onerilen_limit_yp,
        kayit_giris_tarihi,
        kayit_yaratan_kullanici_kodu,
        ref_teklif_no,
        aciklama,
        mevcut_yenileme_vade,
        onerilen_yenileme_vade,
        line, validity_date_of_line,mevcut_line,mevcut_validity_date,mevcut_lim_dvz --hs,20061205
        ,line_amount --sevalb 140607
    FROM  CBS_KREDI_TEKLIF_LIMIT_ISLEM
    WHERE tx_no = pn_tx_no ;
    
    --BOM aisuluud cq 5568
    insert into CBS_CURR_STRUCT_OF_INCOME 
    (customer_no, currency, share_percent, proposal_no, ref_proposal_no)
    select ln_musteri_no, currency, share_percent, proposal_no, ref_proposal_no
    from CBS_CURR_STRUCT_OF_INCOME_TX
    where tx_no = pn_tx_no;
    --EOM aisuluud cq 5568

    --BOM ErkinZu cq 614
    if ln_counter > 0 then
        for i in 1..ln_counter loop
            update cbs_cib_loan_application
            set teklif_satir_no = appNoSatirVar(i).satir
            where app_no = appNoSatirVar(i).app;
        end loop;
    end if;
    --EOM ErkinZu cq 614

  EXCEPTION
   WHEN OTHERS THEN
    log_at('pkg_kredi_anatabloya_at_error', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '459' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;
  /*****************************************************************************************************************/
  /*   Procedure Sp_Teklifi_IslemTablosuna_At                                                                          */
  /*   Kredi teklif ana tablolar?ndan i?lem tablolar?na yeni i?lem ve teklif numaras?nda kay?t aktar?lmesi,           */
 /*    eski teklif numaras? ref_teklif_no alan?nda saklanmaktad?r                                                               */
  /****************************************************************************************************************/
  PROCEDURE Sp_Teklifi_IslemTablosuna_At(pn_islem_tanim_kod NUMBER,pn_eski_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE,
                                            pn_yeni_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE,
                                        ps_yeni_teklif_referans CBS_KREDI_TEKLIF_ISLEM.teklif_referans%TYPE,
                                            pn_yeni_tx_no CBS_ISLEM.numara%TYPE,
                                        pd_yeni_teklif_tarihi CBS_KREDI_TEKLIF_ISLEM.teklif_tarihi%TYPE,
                                        ps_durum_kodu  CBS_KREDI_TEKLIF.durum_kodu%TYPE)
  IS
   ln_teklif_satir_no      NUMBER;
   ln_eski_teklif_satir_no NUMBER;
   ln_musteri_no  NUMBER;
   ls_eski_genel_doviz  CBS_HESAP_KREDI.doviz_kodu%TYPE;
   ln_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE; --cq614 ErkinZu 09042017
        CURSOR cur_teklif_satir IS
          SELECT
          pn_yeni_tx_no,
          teklif_satir_no ,
          kredi_turu,doviz_kodu,
          vade_suresi,vade_tipi,
          mevcut_risk_tl,
          mevcut_risk_yp,
          mevcut_limit_tl,
          mevcut_limit_yp,
          onerilen_limit_tl,
          onerilen_limit_yp,
          onerilen_vade_suresi,
          onerilen_vade_tipi,
          kredi_kullandirim_kodu,aciklama,'ESKI',
          pn_yeni_teklif_no,
          pn_eski_teklif_no,
          musteri_no,
          ref_teklif_no,
          line,
          tranches, -- AdiletK 08032016 CQ4713 adding tranches and maturity date
          maturity_date, -- AdiletK 08032016 CQ4713 adding tranches and maturity date
          real_limit, -- AdiletK 08032016 CQ4712 adding real limit
          app_no
        FROM CBS_KREDI_TEKLIF_SATIR
        WHERE teklif_no =pn_eski_teklif_no  ;
          --  and  (nvl(onerilen_limit_tl,0) <> 0 or nvl(onerilen_limit_yp,0) <> 0);

     CURSOR cur_teklif_satir_teminat_islem IS
      SELECT
          pn_yeni_tx_no ,teklif_satir_no ,sira_no,teminat_kodu,teminat_alt_kodu,tutar,
          marj,katilim_orani,alma_gun_sayisi,kayit_giris_tarihi,kayit_yaratan_kullanici_kodu,pn_yeni_teklif_no,
          pn_eski_teklif_no,doviz_kodu,ref_teklif_no,
          NVL(grup_no,0) grup_no
        FROM  CBS_KREDI_TEKLIF_SATIR_TEMINAT
        WHERE teklif_no = pn_eski_teklif_no AND
              teklif_satir_no = ln_eski_teklif_satir_no;

    CURSOR  cursor_cbs_kredi_teklif_limit IS
    SELECT * FROM CBS_KREDI_TEKLIF_LIMIT
    WHERE teklif_no = pn_eski_teklif_no;

-- B-O-M AdiletK 08032016 CQ4713 adding tranches and maturity date
    ln_real_limit NUMBER;
    ln_risk NUMBER;
    ld_matur_date DATE;
-- E-O-M AdiletK 08032016 CQ4713 adding tranches and maturity date    
 BEGIN
         SELECT musteri_no
        INTO ln_musteri_no
        FROM CBS_KREDI_TEKLIF
        WHERE teklif_no =pn_eski_teklif_no ;

      /* kredi teklif islem tablosundan ana tablosuna kay?t aktar?lmesi */
         INSERT INTO CBS_KREDI_TEKLIF_ISLEM
         (tx_no,teklif_no, teklif_tarihi, teklif_referans, musteri_no, teklif_turu, komite_tipi,
          islem_tanim_kod, kayit_giris_tarihi, kayit_yaratan_kullanici_kodu ,durum_kodu ,ref_teklif_no,aciklama
          , modul_tur_kod,urun_tur_kod,urun_sinif_kod,bolum_kodu )  
         SELECT
           pn_yeni_tx_no,pn_yeni_teklif_no, pd_yeni_teklif_tarihi,
           ps_yeni_teklif_referans, musteri_no, teklif_turu, komite_tipi,
           pn_islem_tanim_kod, kayit_giris_tarihi, kayit_yaratan_kullanici_kodu,
           ps_durum_kodu ,
           DECODE(pn_islem_tanim_kod,1300,pn_eski_teklif_no,ref_teklif_no),
           aciklama, modul_tur_kod,urun_tur_kod,urun_sinif_kod,bolum_kodu 
         FROM CBS_KREDI_TEKLIF
         WHERE teklif_no =pn_eski_teklif_no ;

      /* kredi teklif sat?r teminat islem tablosundan ana tablosuna kay?t aktar?lmesi */
     FOR cur_teklifsatir IN cur_teklif_satir LOOP
             ln_app_no := cur_teklifsatir.app_no;
             ln_eski_teklif_satir_no := cur_teklifsatir.teklif_satir_no;
           /*sevalb 12.12.2003  yeni teklif giris de eski kayit ise ayn? numara kullan?lmal?*/
                ln_teklif_satir_no := cur_teklifsatir.teklif_satir_no;
            /* if  pn_islem_tanim_kod in('1301','1302') then
                   ln_teklif_satir_no := cur_teklifsatir.teklif_satir_no;
                 else
                ln_teklif_satir_no :=  pkg_genel.genel_kod_al('TEKLIF_SATIR_NO');
              end if;
                */

       IF pn_islem_tanim_kod = 1300 THEN     /*yeni giris ise son limit riskleri alinir */
          Pkg_Limit.Sp_Musteri_Urun_Limit_Risk_Al(  ln_musteri_no,
                                                       cur_teklifsatir.kredi_turu,
                                                     cur_teklifsatir.doviz_kodu,
                                                     cur_teklifsatir.teklif_satir_no,
                                                     cur_teklifsatir.mevcut_limit_tl,
                                                     cur_teklifsatir.mevcut_limit_yp,
                                                      cur_teklifsatir.mevcut_risk_tl,
                                                        cur_teklifsatir.mevcut_risk_yp);

       END IF;

        begin        
            select l.mevcut_yenileme_vade,
                     nvl(m.fc_risk, 0)
            into ld_matur_date,
                  ln_risk
            from cbs_kredi_teklif_limit l
            left join cbs_musteri_urun_limit m
            on m.urun_grub_no = cur_teklifsatir.kredi_turu and
                 m.fc_doviz_kodu = cur_teklifsatir.doviz_kodu and
                 m.kredi_teklif_satir_numara = cur_teklifsatir.teklif_satir_no
            where m.musteri_no =   ln_musteri_no and
                      l.teklif_no = pn_eski_teklif_no;
        exception when no_data_found then
            ln_risk := cur_teklifsatir.real_limit;
        end;
        
        if cur_teklifsatir.tranches is not null and cur_teklifsatir.tranches = 'Y' then
            ld_matur_date := cur_teklifsatir.maturity_date;
        end if;

              INSERT INTO CBS_KREDI_TEKLIF_SATIR_ISLEM
             ( tx_no, teklif_satir_no, kredi_turu,doviz_kodu,vade_suresi,vade_tipi,
              mevcut_risk_tl,mevcut_risk_yp,mevcut_limit_tl,mevcut_limit_yp,onerilen_limit_tl,
              onerilen_limit_yp,onerilen_vade_suresi,onerilen_vade_tipi,kredi_kullandirim_kodu,aciklama,
              satir_durum ,teklif_no,ref_teklif_no,MUSTERI_NO ,ref_teklif_satir_no,line, tranches, maturity_date, real_limit, app_no ) -- AdiletK 08032016 CQ4713 adding tranches and maturity date CQ4712 real limit
              VALUES
             ( pn_yeni_tx_no,
               ln_teklif_satir_no,
               cur_teklifsatir.kredi_turu,
               cur_teklifsatir.doviz_kodu,
               cur_teklifsatir.vade_suresi,
               cur_teklifsatir.vade_tipi,
               cur_teklifsatir.mevcut_risk_tl,
               cur_teklifsatir.mevcut_risk_yp,
               cur_teklifsatir.mevcut_limit_tl,
               cur_teklifsatir.mevcut_limit_yp,
               cur_teklifsatir.onerilen_limit_tl,
               cur_teklifsatir.onerilen_limit_yp,
               cur_teklifsatir.onerilen_vade_suresi,
               cur_teklifsatir.onerilen_vade_tipi,
               cur_teklifsatir.kredi_kullandirim_kodu,
               cur_teklifsatir.aciklama,
               'ESKI', pn_yeni_teklif_no,
                DECODE(pn_islem_tanim_kod,1300,
               pn_eski_teklif_no,
               cur_teklifsatir.ref_teklif_no),
               ln_musteri_no ,
               cur_teklifsatir.teklif_satir_no,
               cur_teklifsatir.line,
               nvl(cur_teklifsatir.tranches, 'N'), -- AdiletK 08032016 CQ4713 adding tranches and maturity date
               cur_teklifsatir.maturity_date, -- AdiletK 08032016 CQ4713 adding tranches and maturity date
               nvl(cur_teklifsatir.real_limit, cur_teklifsatir.onerilen_limit_yp), -- AdiletK 08032016 CQ4712 adding real limit
               ln_app_no
               );
            /** satir teminat sartlar? insert edilir. */


           FOR  cur_teklif_satir_tmn_islem IN  cur_teklif_satir_teminat_islem LOOP

                      INSERT INTO CBS_KREDI_TKLF_SATIR_TMN_ISLM
                    (  tx_no ,teklif_satir_no ,sira_no,teminat_kodu,teminat_alt_kodu,tutar,
                      marj,katilim_orani,alma_gun_sayisi,kayit_giris_tarihi,
                      kayit_yaratan_kullanici_kodu, teklif_no,ref_teklif_no,doviz_kodu,
                      ref_teklif_satir_no, ref_sira_no,grup_no)
                      VALUES
                     (   pn_yeni_tx_no, ln_teklif_satir_no, cur_teklif_satir_tmn_islem.sira_no,
                       cur_teklif_satir_tmn_islem.teminat_kodu, cur_teklif_satir_tmn_islem.teminat_alt_kodu,
                       cur_teklif_satir_tmn_islem.tutar,
                       cur_teklif_satir_tmn_islem.marj, cur_teklif_satir_tmn_islem.katilim_orani, cur_teklif_satir_tmn_islem.alma_gun_sayisi,
                       cur_teklif_satir_tmn_islem.kayit_giris_tarihi, cur_teklif_satir_tmn_islem.kayit_yaratan_kullanici_kodu,
                       pn_yeni_teklif_no,
                       DECODE(pn_islem_tanim_kod,1300,pn_eski_teklif_no,cur_teklif_satir_tmn_islem.ref_teklif_no),
                       cur_teklif_satir_tmn_islem.doviz_kodu,
                       cur_teklif_satir_tmn_islem.teklif_satir_no,
                       cur_teklif_satir_tmn_islem.sira_no,
                       cur_teklif_satir_tmn_islem.grup_no);
           END LOOP;

     END LOOP;
      /* kredi teklif teminat islem tablosundan ana tablosuna kay?t aktar?lmesi */
        INSERT INTO CBS_KREDI_TEKLIF_TEMINAT_ISLEM
        ( tx_no, sira_no, teminat_kodu, teminat_alt_kodu,
          tutar, marj,katilim_orani, alma_gun_sayisi,
          kayit_giris_tarihi, kayit_yaratan_kullanici_kodu,
          teklif_no,ref_teklif_no,doviz_kodu,ref_sira_no,grup_no)
        SELECT
         pn_yeni_tx_no, sira_no, teminat_kodu, teminat_alt_kodu,
         tutar, marj,katilim_orani, alma_gun_sayisi,
         kayit_giris_tarihi, kayit_yaratan_kullanici_kodu,
         pn_yeni_teklif_no,
         DECODE(pn_islem_tanim_kod,1300,pn_eski_teklif_no,ref_teklif_no),
         doviz_kodu,sira_no,grup_no
        FROM CBS_KREDI_TEKLIF_TEMINAT
        WHERE teklif_no = pn_eski_teklif_no;


      /* kredi teklif limit islem tablosundan ana tablosuna kay?t aktar?lmesi */
    FOR cur_cbs_kredi_teklif_limit IN cursor_cbs_kredi_teklif_limit
    LOOP
      IF pn_islem_tanim_kod = 1300 THEN     /*yeni giris ise son limit riskleri alinir */
        ls_eski_genel_doviz :=  cur_cbs_kredi_teklif_limit.genel_doviz_kodu ;
          Pkg_Limit.SP_MUSTERI_LIMIT_RISK_AL ( ln_musteri_no,
                                              cur_cbs_kredi_teklif_limit.genel_doviz_kodu,
                                            cur_cbs_kredi_teklif_limit.genel_mevcut_limit_tl,
                                            cur_cbs_kredi_teklif_limit.genel_mevcut_limit_yp,
                                            cur_cbs_kredi_teklif_limit.genel_mevcut_risk_tl,
                                            cur_cbs_kredi_teklif_limit.genel_mevcut_risk_yp,
                                            cur_cbs_kredi_teklif_limit.nakit_mevcut_limit_tl,
                                            cur_cbs_kredi_teklif_limit.nakit_mevcut_limit_yp,
                                            cur_cbs_kredi_teklif_limit.nakit_mevcut_risk_tl,
                                            cur_cbs_kredi_teklif_limit.nakit_mevcut_risk_yp,
                                            cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_limit_tl,
                                            cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_limit_yp,
                                            cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_risk_tl,
                                             cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_risk_yp,
                                            cur_cbs_kredi_teklif_limit.line_amount );--sevalb 140607
       END IF;

        INSERT INTO CBS_KREDI_TEKLIF_LIMIT_ISLEM
        (  tx_no, nakit_mevcut_risk_tl, nakit_mevcut_risk_yp, nakit_mevcut_limit_tl,
            nakit_mevcut_limit_yp, nakit_onerilen_limit_tl, nakit_onerilen_limit_yp,
            gayrinakit_mevcut_risk_tl, gayrinakit_mevcut_risk_yp, gayrinakit_mevcut_limit_tl,
            gayrinakit_mevcut_limit_yp, gayrinakit_onerilen_limit_tl, gayrinakit_onerilen_limit_yp,
            genel_doviz_kodu, genel_mevcut_risk_tl, genel_mevcut_risk_yp, genel_mevcut_limit_tl, genel_mevcut_limit_yp, genel_onerilen_limit_tl,
            genel_onerilen_limit_yp, grup_doviz_kodu, grup_mevcut_risk_tl, grup_mevcut_risk_yp, grup_mevcut_limit_tl, grup_mevcut_limit_yp,
            grup_onerilen_limit_tl,    grup_onerilen_limit_yp, kayit_giris_tarihi, kayit_yaratan_kullanici_kodu,teklif_no,ref_teklif_no,aciklama,
            MEVCUT_YENILEME_VADE, ONERILEN_YENILEME_VADE,
            LINE, VALIDITY_DATE_OF_LINE,MEVCUT_LINE,MEVCUT_VALIDITY_DATE,MEVCUT_LIM_DVZ --hs,20061205
            ,LINE_AMOUNT--sevalb 140607
            )
        VALUES
         (  pn_yeni_tx_no,
            cur_cbs_kredi_teklif_limit.nakit_mevcut_risk_tl,
            cur_cbs_kredi_teklif_limit.nakit_mevcut_risk_yp,
            cur_cbs_kredi_teklif_limit.nakit_mevcut_limit_tl,
            cur_cbs_kredi_teklif_limit.nakit_mevcut_limit_yp,
            cur_cbs_kredi_teklif_limit.nakit_onerilen_limit_tl,
            cur_cbs_kredi_teklif_limit.nakit_onerilen_limit_yp,
            cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_risk_tl,
            cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_risk_yp,
            cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_limit_tl,
            cur_cbs_kredi_teklif_limit.gayrinakit_mevcut_limit_yp,
            cur_cbs_kredi_teklif_limit.gayrinakit_onerilen_limit_tl,
            cur_cbs_kredi_teklif_limit.gayrinakit_onerilen_limit_yp,
            NVL(cur_cbs_kredi_teklif_limit.genel_doviz_kodu, ls_eski_genel_doviz),
            cur_cbs_kredi_teklif_limit.genel_mevcut_risk_tl,
            cur_cbs_kredi_teklif_limit.genel_mevcut_risk_yp,
            cur_cbs_kredi_teklif_limit.genel_mevcut_limit_tl,
            cur_cbs_kredi_teklif_limit.genel_mevcut_limit_yp,
            cur_cbs_kredi_teklif_limit.genel_onerilen_limit_tl,
            cur_cbs_kredi_teklif_limit.genel_onerilen_limit_yp,
            cur_cbs_kredi_teklif_limit.grup_doviz_kodu,
            cur_cbs_kredi_teklif_limit.grup_mevcut_risk_tl,
            cur_cbs_kredi_teklif_limit.grup_mevcut_risk_yp,
            cur_cbs_kredi_teklif_limit.grup_mevcut_limit_tl,
            cur_cbs_kredi_teklif_limit.grup_mevcut_limit_yp,
            cur_cbs_kredi_teklif_limit.grup_onerilen_limit_tl,
            cur_cbs_kredi_teklif_limit.grup_onerilen_limit_yp,
            cur_cbs_kredi_teklif_limit.kayit_giris_tarihi,
            cur_cbs_kredi_teklif_limit.kayit_yaratan_kullanici_kodu,
            pn_yeni_teklif_no,
            DECODE(pn_islem_tanim_kod,1300,pn_eski_teklif_no,cur_cbs_kredi_teklif_limit.ref_teklif_no),
            cur_cbs_kredi_teklif_limit.aciklama,
            cur_cbs_kredi_teklif_limit.mevcut_yenileme_vade,
            cur_cbs_kredi_teklif_limit.onerilen_yenileme_vade,
--hs,20061205
            cur_cbs_kredi_teklif_limit.LINE,
            cur_cbs_kredi_teklif_limit.VALIDITY_DATE_OF_LINE,
            DECODE(pn_islem_tanim_kod,1300,cur_cbs_kredi_teklif_limit.LINE,cur_cbs_kredi_teklif_limit.MEVCUT_LINE),
            DECODE(pn_islem_tanim_kod,1300,cur_cbs_kredi_teklif_limit.VALIDITY_DATE_OF_LINE,cur_cbs_kredi_teklif_limit.MEVCUT_VALIDITY_DATE),
            DECODE(pn_islem_tanim_kod,1300,cur_cbs_kredi_teklif_limit.genel_doviz_kodu,cur_cbs_kredi_teklif_limit.MEVCUT_LIM_DVZ)--hs,20061205
            ,cur_cbs_kredi_teklif_limit.line_amount --sevalb 140607

             );

    END LOOP ;
    
-- BOM aisuluud cq5568 
 INSERT INTO CBS_CURR_STRUCT_OF_INCOME_TX
        ( tx_no, customer_no, currency, share_percent, proposal_no, ref_proposal_no)
        SELECT
         pn_yeni_tx_no,ln_musteri_no, currency, share_percent, pn_yeni_teklif_no,
         DECODE(pn_islem_tanim_kod,1300,pn_eski_teklif_no,ref_proposal_no)
        FROM CBS_CURR_STRUCT_OF_INCOME
        WHERE proposal_no = pn_eski_teklif_no;

-- EOM aisuluud cq5568


  EXCEPTION
   WHEN OTHERS THEN
   log_at('pkg_kredi_islemtablosuna_at_error', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '460' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;

  /******************************************************************************************************************/
  /*   Function Sf_Kredi_Teminat_SiraNo_Al                                                                                 */
  /*   Girilen musteri numaras? baz?nda Kredi Teminat S?ra Numaras? al?n?r                                */
  /******************************************************************************************************************/
  FUNCTION  Sf_Kredi_Teminat_SiraNo_Al(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE ) RETURN CBS_KREDI_TEMINAT_TANIM.TEMINAT_SIRA_NO%TYPE
  IS
    ln_teminat_sirano   CBS_KREDI_TEMINAT_TANIM.teminat_sira_no%TYPE;
  BEGIN

    SELECT MAX(NVL(TEMINAT_SIRA_NO,0))+1
    INTO ln_teminat_sirano
    FROM CBS_KREDI_TEMINAT_GIRIS
    WHERE musteri_no=pn_musteri_no;

    RETURN ln_teminat_sirano ;
    EXCEPTION
      WHEN OTHERS THEN RETURN 0;

  END;

  /******************************************************************************************************************/
  /*   Function Sf_Onceki_Kredi_Teklif_No_Al                                                                             */
  /*   Girilen teklifin onceki teklif numaras? al?n?r                                                                 */
  /******************************************************************************************************************/
   FUNCTION  Sf_Onceki_Kredi_Teklif_No_Al(pn_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE ) RETURN CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE
   IS
    ln_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE;
   BEGIN

        SELECT NVL(ref_teklif_no,0)
        INTO  ln_teklif_no
        FROM CBS_KREDI_TEKLIF
        WHERE teklif_no = pn_teklif_no ;

    RETURN ln_teklif_no  ;

    EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '463' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

  END;

  /******************************************************************************************************************/
  /*   Function Sf_Onceki_Kredi_Teklif_No_Al                                                                             */
  /*   Girilen teklifin onceki teklif numaras? al?n?r                                                                 */
  /******************************************************************************************************************/
  FUNCTION Sf_Islemden_Kredi_Teklif_No_Al(pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE ) RETURN CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE
   IS
    ln_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE;
   BEGIN

        SELECT teklif_no
        INTO  ln_teklif_no
        FROM  CBS_KREDI_TEKLIF_ISLEM
        WHERE tx_no = pn_tx_no ;

    RETURN ln_teklif_no  ;

    EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '464' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

  END;

  /******************************************************************************************************************/
  /*   Procedure Sp_Onceki_Kredi_Teklifi_Kapat                                                                                     */
  /*   Talep durum kodu K statusune guncellenip kapat?l?r                                                                                    */
  /******************************************************************************************************************/
  PROCEDURE Sp_Onceki_Kredi_Teklifi_Kapat(pn_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE)
  IS
    ln_eski_teklif_no CBS_KREDI_TEKLIF.teklif_no%TYPE;
  BEGIN

      IF NVL(pn_teklif_no,0)  <> 0 THEN
            UPDATE CBS_KREDI_TEKLIF
            SET durum_kodu ='K'
            WHERE  teklif_no <> pn_teklif_no AND
                    musteri_no IN (SELECT musteri_no
                                      FROM CBS_KREDI_TEKLIF
                                   WHERE teklif_no =pn_teklif_no);
        END IF;
    EXCEPTION WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '462' || Pkg_Hata.getDelimiter ||TO_CHAR(pn_teklif_no) ||Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;

  /******************************************************************************************************************/
  /*   Function Sf_Kredi_Turu_Aciklamasi_Al                                                                              */
  /*   kredi turunun aciklamasi getirilir                                                                            */
  /******************************************************************************************************************/
   FUNCTION  Sf_Kredi_Turu_Aciklamasi_Al( pn_kredi_turu_no  CBS_URUN_GRUBU.numara%TYPE) RETURN CBS_URUN_GRUBU.tanim%TYPE
   IS
     ls_tanim  CBS_URUN_GRUBU.tanim%TYPE;
   BEGIN

        SELECT tanim
        INTO  ls_tanim
        FROM  CBS_URUN_GRUBU
        WHERE numara = pn_kredi_turu_no;

    RETURN ls_tanim;

    EXCEPTION
    WHEN  OTHERS THEN
          RETURN NULL;
   END;


  /******************************************************************************************************************/
  /*   Function Sf_Onceki_Kredi_Teklif_No_Al                                                                             */
  /*   Girilen teklifin onceki teklif numaras? al?n?r                                                                 */
  /******************************************************************************************************************/
   FUNCTION  Sf_Teminat_Alt_Kod_Aciklamasi(ps_teminat_kodu CBS_TEMINAT_ALT_KODLARI.teminat_kodu%TYPE, ps_teminat_alt_kodu CBS_TEMINAT_ALT_KODLARI.teminat_alt_kodu%TYPE) RETURN CBS_TEMINAT_ALT_KODLARI.aciklama%TYPE
   IS
    ls_aciklama CBS_TEMINAT_ALT_KODLARI.aciklama%TYPE;
   BEGIN

        SELECT aciklama
        INTO  ls_aciklama
        FROM  CBS_TEMINAT_ALT_KODLARI
        WHERE teminat_kodu = ps_teminat_kodu AND
              teminat_alt_kodu = ps_teminat_alt_kodu;

   IF ls_aciklama IS NULL THEN
       SELECT aciklama
       INTO  ls_aciklama
       FROM  CBS_TEMINAT_KODLARI
       WHERE teminat_kodu = ps_teminat_kodu ;
    END IF;

    RETURN ls_aciklama;

    EXCEPTION
     WHEN NO_DATA_FOUND THEN
              SELECT aciklama
            INTO  ls_aciklama
            FROM  CBS_TEMINAT_KODLARI
            WHERE teminat_kodu = ps_teminat_kodu ;

          RETURN ls_aciklama ;

      WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '466' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
    END;


  /******************************************************************************************************************/
  /*   Procedure Sp_Aktif_Kredi_Guncel_Getir                                                                                */
  /*   1301 nolu islem icerisinde musteri veya teklif referans gonderilirip ilgili bilgiler dondurulur                  */
  /******************************************************************************************************************/
 PROCEDURE Sp_Aktif_Kredi_Guncel_Getir(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                           ps_teklif_referans IN OUT CBS_KREDI_TEKLIF_ISLEM.TEKLIF_REFERANS%TYPE,
                                       pn_teklif_no     OUT  CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE,
                                       pd_teklif_tarihi OUT  CBS_KREDI_TEKLIF_ISLEM.teklif_tarihi%TYPE)
 IS
BEGIN
    IF ps_teklif_referans IS NULL OR trim(ps_teklif_referans) ='' THEN
         pn_teklif_no := Pkg_Kredi. Sf_Bekleyen_Kredi_Teklif_No_Al(pn_musteri_no);

        SELECT teklif_referans,teklif_no ,teklif_tarihi
        INTO   ps_teklif_referans,pn_teklif_no ,pd_teklif_tarihi
        FROM   CBS_KREDI_TEKLIF
        WHERE  teklif_no= pn_teklif_no;
    ELSE
        SELECT teklif_no ,teklif_tarihi
        INTO  pn_teklif_no ,pd_teklif_tarihi
        FROM  CBS_KREDI_TEKLIF
        WHERE teklif_referans = ps_teklif_referans;
    END IF;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN NULL;
  WHEN OTHERS  THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '477' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END ;

  /******************************************************************************************************************/
  /*   Function sf_kredi_referans_musterino_al                                                                               */
  /*   kredi referans nosu g?nderilip musteri numaras? al?n?r                                                        */
  /******************************************************************************************************************/
  FUNCTION sf_kredi_referans_musterino_al(ps_teklif_referans CBS_KREDI_TEKLIF_ISLEM.teklif_referans%TYPE) RETURN CBS_MUSTERI.musteri_no%TYPE
   IS
    ln_musteri_no  CBS_MUSTERI.musteri_no%TYPE;
   BEGIN

        SELECT musteri_no
        INTO  ln_musteri_no
        FROM  CBS_KREDI_TEKLIF
        WHERE teklif_referans = ps_teklif_referans;

    RETURN ln_musteri_no;

    EXCEPTION
        WHEN  OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '478' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;

  /******************************************************************************************************************/
  /*   Procedure sp_kredi_teklif_guncelle                                                                                   */
  /*   kredi teklif g?ncellemesi                                                                                    */
  /******************************************************************************************************************/
 PROCEDURE sp_kredi_teklif_guncelle(pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE)
 IS
   ln_teklif_no    CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE;
  BEGIN

    SELECT teklif_no
    INTO  ln_teklif_no
    FROM  CBS_KREDI_TEKLIF_ISLEM
    WHERE tx_no = pn_tx_no ;

/* teklif kayd?n?n aktar?lmesi */
    UPDATE CBS_KREDI_TEKLIF
    SET ( TEKLIF_TURU,KOMITE_TIPI, DURUM_KODU,ACIKLAMA ) = (SELECT TEKLIF_TURU,KOMITE_TIPI, DURUM_KODU ,ACIKLAMA
                                           FROM CBS_KREDI_TEKLIF_ISLEM
                                           WHERE tx_no = pn_tx_no)
    WHERE teklif_no = ln_teklif_no ;

/* teklif limit kayd?n?n aktar?lmesi */
    UPDATE CBS_KREDI_TEKLIF_LIMIT
    SET ( NAKIT_MEVCUT_RISK_TL, NAKIT_MEVCUT_RISK_YP, NAKIT_MEVCUT_LIMIT_TL, NAKIT_MEVCUT_LIMIT_YP, NAKIT_ONERILEN_LIMIT_TL, NAKIT_ONERILEN_LIMIT_YP, GAYRINAKIT_MEVCUT_RISK_TL, GAYRINAKIT_MEVCUT_RISK_YP, GAYRINAKIT_MEVCUT_LIMIT_TL, GAYRINAKIT_MEVCUT_LIMIT_YP, GAYRINAKIT_ONERILEN_LIMIT_TL, GAYRINAKIT_ONERILEN_LIMIT_YP, GENEL_DOVIZ_KODU, GENEL_MEVCUT_RISK_TL, GENEL_MEVCUT_RISK_YP, GENEL_MEVCUT_LIMIT_TL, GENEL_MEVCUT_LIMIT_YP, GENEL_ONERILEN_LIMIT_TL, GENEL_ONERILEN_LIMIT_YP, GRUP_DOVIZ_KODU, GRUP_MEVCUT_RISK_TL, GRUP_MEVCUT_RISK_YP, GRUP_MEVCUT_LIMIT_TL, GRUP_MEVCUT_LIMIT_YP, GRUP_ONERILEN_LIMIT_TL, GRUP_ONERILEN_LIMIT_YP,
            MEVCUT_YENILEME_VADE,ONERILEN_YENILEME_VADE,LINE,
            VALIDITY_DATE_OF_LINE,LINE_AMOUNT
     )
        = (SELECT NAKIT_MEVCUT_RISK_TL, NAKIT_MEVCUT_RISK_YP, NAKIT_MEVCUT_LIMIT_TL, NAKIT_MEVCUT_LIMIT_YP, NAKIT_ONERILEN_LIMIT_TL, NAKIT_ONERILEN_LIMIT_YP, GAYRINAKIT_MEVCUT_RISK_TL, GAYRINAKIT_MEVCUT_RISK_YP, GAYRINAKIT_MEVCUT_LIMIT_TL, GAYRINAKIT_MEVCUT_LIMIT_YP, GAYRINAKIT_ONERILEN_LIMIT_TL, GAYRINAKIT_ONERILEN_LIMIT_YP, GENEL_DOVIZ_KODU, GENEL_MEVCUT_RISK_TL, GENEL_MEVCUT_RISK_YP, GENEL_MEVCUT_LIMIT_TL, GENEL_MEVCUT_LIMIT_YP, GENEL_ONERILEN_LIMIT_TL, GENEL_ONERILEN_LIMIT_YP, GRUP_DOVIZ_KODU, GRUP_MEVCUT_RISK_TL, GRUP_MEVCUT_RISK_YP, GRUP_MEVCUT_LIMIT_TL, GRUP_MEVCUT_LIMIT_YP,
                    GRUP_ONERILEN_LIMIT_TL, GRUP_ONERILEN_LIMIT_YP,MEVCUT_YENILEME_VADE,ONERILEN_YENILEME_VADE,
                  LINE, VALIDITY_DATE_OF_LINE,LINE_AMOUNT
           FROM CBS_KREDI_TEKLIF_LIMIT_ISLEM
           WHERE tx_no = pn_tx_no)
    WHERE teklif_no = ln_teklif_no ;

/* Master detail iliskisine uygun olarak kayitlar silinir. */
   DELETE FROM  CBS_KREDI_TEKLIF_SATIR_TEMINAT
   WHERE teklif_no = ln_teklif_no ;

   DELETE FROM  CBS_KREDI_TEKLIF_TEMINAT
   WHERE teklif_no = ln_teklif_no ;

   DELETE FROM CBS_KREDI_TEKLIF_SATIR
   WHERE teklif_no = ln_teklif_no ;
   
   --BOM aisuluud cq5568
   DELETE FROM CBS_CURR_STRUCT_OF_INCOME
   WHERE proposal_no = ln_teklif_no ;
   
   --EOM aisuluud cq5568



/* teklif satir kay?tlar?n?n aktar?lmesi */
   INSERT INTO CBS_KREDI_TEKLIF_SATIR(TEKLIF_NO , TEKLIF_SATIR_NO, KREDI_TURU, DOVIZ_KODU, VADE_SURESI, VADE_TIPI, MEVCUT_RISK_TL, MEVCUT_RISK_YP,
               MEVCUT_LIMIT_TL,MEVCUT_LIMIT_YP,ONERILEN_LIMIT_TL,ONERILEN_LIMIT_YP, ONERILEN_VADE_SURESI,ONERILEN_VADE_TIPI,
             KREDI_KULLANDIRIM_KODU,ACIKLAMA,SATIR_DURUM,REF_TEKLIF_NO ,MUSTERI_NO,LINE,TRANCHES,MATURITY_DATE,--GulkaiyrK CBS-96
             APP_NO) --ErkinZu 19.04.2017, CQ614
   SELECT TEKLIF_NO , TEKLIF_SATIR_NO, KREDI_TURU, DOVIZ_KODU, VADE_SURESI, VADE_TIPI, MEVCUT_RISK_TL, MEVCUT_RISK_YP,
               MEVCUT_LIMIT_TL,MEVCUT_LIMIT_YP,ONERILEN_LIMIT_TL,ONERILEN_LIMIT_YP, ONERILEN_VADE_SURESI,ONERILEN_VADE_TIPI,
             KREDI_KULLANDIRIM_KODU,ACIKLAMA,SATIR_DURUM,REF_TEKLIF_NO,MUSTERI_NO,LINE,TRANCHES,MATURITY_DATE,--GulkaiyrK CBS-96
             APP_NO --ErkinZu 19.04.2017, CQ614
   FROM  CBS_KREDI_TEKLIF_SATIR_ISLEM
   WHERE tx_no = pn_tx_no;

/* teklif teminat islem kayitlarinin aktarilmasi*/
   INSERT INTO CBS_KREDI_TEKLIF_TEMINAT ( TEKLIF_NO, SIRA_NO, TEMINAT_KODU, TEMINAT_ALT_KODU, TUTAR, MARJ, KATILIM_ORANI, ALMA_GUN_SAYISI,
                                                  KAYIT_GIRIS_TARIHI, KAYIT_YARATAN_KULLANICI_KODU, REF_TEKLIF_NO,DOVIZ_KODU,grup_no)
   SELECT TEKLIF_NO, SIRA_NO, TEMINAT_KODU, TEMINAT_ALT_KODU, TUTAR, MARJ, KATILIM_ORANI, ALMA_GUN_SAYISI, KAYIT_GIRIS_TARIHI,
              KAYIT_YARATAN_KULLANICI_KODU, REF_TEKLIF_NO,DOVIZ_KODU ,NVL(grup_no,0)
   FROM CBS_KREDI_TEKLIF_TEMINAT_ISLEM
   WHERE tx_no = pn_tx_no;

/* teklif cbs_kredi_teklif_satir teminat*/
   INSERT INTO CBS_KREDI_TEKLIF_SATIR_TEMINAT (  TEKLIF_NO,TEKLIF_SATIR_NO,SIRA_NO,TEMINAT_KODU,TEMINAT_ALT_KODU,TUTAR,
                                                      MARJ,KATILIM_ORANI,ALMA_GUN_SAYISI,KAYIT_GIRIS_TARIHI, KAYIT_YARATAN_KULLANICI_KODU,REF_TEKLIF_NO,DOVIZ_KODU,grup_no)
   SELECT TEKLIF_NO,TEKLIF_SATIR_NO,SIRA_NO,TEMINAT_KODU,TEMINAT_ALT_KODU,TUTAR,
              MARJ,KATILIM_ORANI,ALMA_GUN_SAYISI,KAYIT_GIRIS_TARIHI, KAYIT_YARATAN_KULLANICI_KODU,REF_TEKLIF_NO,DOVIZ_KODU,NVL(grup_no,0)
   FROM  CBS_KREDI_TKLF_SATIR_TMN_ISLM
   WHERE tx_no = pn_tx_no;
   

   --BOM aisuluud cq 5568
    insert into CBS_CURR_STRUCT_OF_INCOME 
    (customer_no, currency, share_percent, proposal_no, ref_proposal_no)
    select customer_no, currency, share_percent, proposal_no, ref_proposal_no
    from CBS_CURR_STRUCT_OF_INCOME_TX
    where tx_no = pn_tx_no;
    
    --EOM aisuluud cq 5568




  EXCEPTION
    WHEN  OTHERS THEN
    log_at('pkg_kredi_teklif_guncelle_error', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '480' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
 END;

 /******************************************************************************************************************/
 /*   Procedure sp_kredi_teklif_guncelle                                                                                   */
 /*   kredi teklif g?ncellemesi                                                                                    */
 /******************************************************************************************************************/
 PROCEDURE sp_teklif_durum_guncelle(pn_teklif_no CBS_KREDI_TEKLIF.teklif_no%TYPE ,ps_yeni_durum_kodu CBS_KREDI_TEKLIF.durum_kodu%TYPE)
 IS
 BEGIN
      UPDATE CBS_KREDI_TEKLIF
      SET durum_kodu = ps_yeni_durum_kodu
      WHERE teklif_no = pn_teklif_no;

  EXCEPTION
    WHEN  OTHERS THEN
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '481' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
 END;


  FUNCTION Sf_kredi_urun_gayri_nakdimi(pn_kredi_turu_numara CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2
  IS
     ls_lc  VARCHAR2(1) := 'H';
  BEGIN

       SELECT nakdi_mi
       INTO   ls_lc
       FROM   CBS_URUN_GRUBU
       WHERE  numara = pn_kredi_turu_numara;

       RETURN ls_lc ;

    EXCEPTION
      WHEN OTHERS THEN NULL;
  END ;

 /******************************************************************************************************************/
 /*   Procedure sp_teklif_genel_limit_kontrol                                                                                   */
 /*   kosullar?n kontrol edilmesi                                                                                */
 /******************************************************************************************************************/
 PROCEDURE sp_teklif_gayrinakdilimit_var( pn_tx_no CBS_KREDI_TEKLIF_ISLEM.tx_no%TYPE,
                                              ps_nakdi_varmi  OUT VARCHAR2,
                                          ps_gayrinakdi_varmi OUT VARCHAR2)

  IS
     CURSOR cursor_teklif_satir IS
       SELECT kredi_turu,
             onerilen_limit_yp
       FROM  CBS_KREDI_TEKLIF_SATIR_ISLEM
      WHERE tx_no = pn_tx_no ;

      ln_nakdi                    NUMBER := 0;
      ln_gayrinakdi          NUMBER := 0;
      ln_nakit_risk           NUMBER := 0;
      ln_nakit               NUMBER ;
      ln_gayrinakit           NUMBER ;
      ln_gayrinakit_risk      NUMBER := 0;
      gayrinakit_limit_tanimli_degil  EXCEPTION;
      nakit_limit_tanimli_degil       EXCEPTION;
      ln_toplam_nakdi                  number := 0;
      ln_toplam_gnakdi                  number := 0;
 BEGIN
       FOR  cur_teklif_Satir IN cursor_teklif_satir
      LOOP
           IF   Pkg_Kredi.Sf_kredi_urun_gayri_nakdimi(cur_teklif_Satir.kredi_turu) = 'E'  THEN
               ln_nakdi := ln_nakdi + 1;
                ln_toplam_nakdi := ln_toplam_nakdi + nvl(cur_teklif_Satir.onerilen_limit_yp,0);
         ELSE
                ln_gayrinakdi := ln_gayrinakdi + 1;
              ln_toplam_gnakdi := ln_toplam_gnakdi + nvl(cur_teklif_Satir.onerilen_limit_yp,0);
         END IF;
      END LOOP;

/* limitler mevcut ise girisi yap?lm?? m?? */
       IF  NVL(ln_nakdi,0)  <> 0 THEN
                    ps_nakdi_varmi := 'H' ;
             /* nakdi limit tanimlanmis mi ? */
              SELECT nakit_onerilen_limit_yp,
                      nakit_mevcut_risk_yp
              INTO  ln_nakit, ln_nakit_risk
              FROM  CBS_KREDI_TEKLIF_LIMIT_ISLEM
              WHERE tx_no = pn_tx_no ;

              IF  NVL(ln_nakit,0) = 0  and nvl(ln_toplam_nakdi,0) <> 0 THEN
                    RAISE nakit_limit_tanimli_degil ;
              ELSE
                    ps_nakdi_varmi := 'E' ;
              END IF;

       ELSE
              ps_nakdi_varmi := 'H';

       END IF;

       IF NVL(ln_gayrinakdi,0) <> 0 THEN
                 ps_gayrinakdi_varmi  := 'H' ;
                 /* gayri nakdi limit tanimlanmis mi ? */
              SELECT gayrinakit_onerilen_limit_yp,
                     gayrinakit_mevcut_risk_yp
              INTO   ln_gayrinakit,
                        ln_gayrinakit_risk
              FROM   CBS_KREDI_TEKLIF_LIMIT_ISLEM
              WHERE  tx_no = pn_tx_no ;

              IF  NVL(ln_gayrinakit ,0) = 0 and nvl(ln_toplam_gnakdi,0) <> 0 THEN
                    RAISE gayrinakit_limit_tanimli_degil ;
                ELSE
                       ps_gayrinakdi_varmi  := 'E' ;
              END IF;
       ELSE
              ps_gayrinakdi_varmi  := 'H';
       END IF;

   EXCEPTION
    WHEN nakit_limit_tanimli_degil THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '517' || Pkg_Hata.getUCPOINTER);

    WHEN gayrinakit_limit_tanimli_degil THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '518' || Pkg_Hata.getUCPOINTER);
    WHEN  OTHERS THEN
           RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '516' || Pkg_Hata.getUCPOINTER);

 END;


  /*****************************************************************************************************************/
  /*   Function    Sf_Hesap_Bloke_Konan_Urunmu                                                                                     */
  /*   Bloke konulabilen urunler icerisinde degilse lov de gorulmeyecektir.                                                                                 */
  /****************************************************************************************************************/
   FUNCTION Sf_Alacak_Hesap_Uygunmu(pn_hesap_no CBS_BLOKE_ISLEM.hesap_no%TYPE ) RETURN VARCHAR2
   IS
     ln_adet NUMBER;
    BEGIN

        SELECT  1
       INTO    ln_adet
       FROM    CBS_HESAP
       WHERE   urun_tur_kod IN ( 'CURRENT','DEMAND DEP', 'TRANSIT') -- CQ5507 BAHIANAB 29042016 ADDED NEW PRODUCT TYPE "TRANSIT"
                  AND hesap_no =pn_hesap_no;

        IF NVL(ln_adet,0) <> 0 THEN
           RETURN 'E';
        ELSE
           RETURN 'H';
        END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 'H';
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '484' || Pkg_Hata.getUCPOINTER);
    END Sf_Alacak_Hesap_Uygunmu;

  /*****************************************************************************************************************/
  /*   Function    Sf_Sinirlandirma_Kodu_Acikla                                                                        */
  /*   sinirlandirma kod a??klamesi al?n?r                                                                              */
  /****************************************************************************************************************/
  FUNCTION Sf_Sinirlandirma_Kodu_Acikla( ps_sinirlama_kodu CBS_SINIRLAMA_KODLARI.sinirlama_kodu%TYPE ) RETURN CBS_SINIRLAMA_KODLARI.aciklama%TYPE
  IS
     ls_aciklama   CBS_SINIRLAMA_KODLARI.aciklama%TYPE ;
    BEGIN

       SELECT aciklama
       INTO   ls_aciklama
       FROM   CBS_SINIRLAMA_KODLARI
       WHERE  sinirlama_kodu =  ps_sinirlama_kodu;

       RETURN ls_aciklama;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
   END;

  /*****************************************************************************************************************/
  /*   Function    Sf_Kaynak_Kodu_Acikla                                                                        */
  /*   kaynak kod a??klamesi al?n?r                                                                              */
  /****************************************************************************************************************/
  FUNCTION Sf_Kaynak_Kodu_Acikla( ps_kaynak_kodu CBS_KAYNAK_KODLARI.kaynak_kodu%TYPE ) RETURN CBS_KAYNAK_KODLARI.aciklama%TYPE
  IS
     ls_aciklama   CBS_KAYNAK_KODLARI.aciklama%TYPE := NULL;
    BEGIN

     IF ps_kaynak_kodu IS NOT NULL THEN
       SELECT aciklama
       INTO   ls_aciklama
       FROM   CBS_KAYNAK_KODLARI
       WHERE  Kaynak_kodu =  ps_Kaynak_kodu;
     END IF;

    RETURN ls_aciklama;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
   END;

  /***************************************************************************************************************/
  /*   Function    sf_faiz_siklik_suresi_tanimla                                                                        */
  /*   faiz siklik s?resi tanimlanip tanimlanmadigi kontrol edilir. buna g?re formda girise izin verilir.          */
  /****************************************************************************************************************/
  FUNCTION sf_faiz_siklik_suresi_tanimla( ps_siklik_kodu CBS_FAIZ_SIKLIK_KODLARI.siklik_kodu%TYPE) RETURN CBS_FAIZ_SIKLIK_KODLARI.aciklama%TYPE
    IS
     ls_sonuc  CHAR(1) := 'E'  ;
    BEGIN

       SELECT sure_tanimlansin
       INTO   ls_sonuc
       FROM   CBS_FAIZ_SIKLIK_KODLARI
       WHERE  siklik_kodu =   ps_siklik_kodu;

       RETURN ls_sonuc ;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 'E';
   END;

  /***************************************************************************************************************/
  /*   Function    sf_kredi_istatistikkod_uygunmu                                                                        */
  /*   faiz istatistik kodlar?n?n d?viz koduna ba?l? olarak listelenmesini sa?lar  */
  /****************************************************************************************************************/
 FUNCTION sf_kredi_istatistikkod_uygunmu(ps_doviz_kodu CBS_DOVIZ_KODLARI.doviz_kodu%TYPE, ps_istatistik_kodu CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2
  IS
  ls_sonuc VARCHAR2(1) := 'H';
  BEGIN
   /*if ps_doviz_kodu is not null then
         if ps_doviz_kodu = pkg_genel.lc_al then
            if ps_istatistik_kodu in('T0303','T0304') then
                return 'E';
            else
                return 'H';
            end if;
         else
            if  (ps_istatistik_kodu between '7300' and '7311' )  or
            ps_istatistik_kodu in('7320','5431','5580','7316','7317') then
                return 'E';
            else
                return 'H';
            end if;
         end if;
    else
        return 'H';
    end if;
      */

      RETURN 'E';
  EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 'H';
  END ;

 /***************************************************************************************************************/
 /*   Function sf_kredi_dk_bul                                                                                        */
 /*  kredi dk_bul procedurunu ?a??r?l?r. musterinini dk grubu bulunup, ?a?r?l?r                                      */
 /**************************************************************************************************************/
  FUNCTION sf_kredi_dk_bul( pn_musteri_no CBS_MUSTERI.musteri_no%TYPE ,ps_modul_tur_kod  VARCHAR2,ps_urun_tur_kod  VARCHAR2 ,ps_urun_sinif_kod VARCHAR2 ,pn_gl_index NUMBER default 1) RETURN VARCHAR2
  IS
    ln_gl_group_code NUMBER;
    ln_gl_index NUMBER :=pn_gl_index;
    lb_kosul_1 BOOLEAN :=NULL;
    lb_kosul_2 BOOLEAN :=NULL;
    lb_kosul_3 BOOLEAN :=NULL;
    ls_gl_code VARCHAR2(200) := NULL;
  BEGIN
      SELECT dk_grup_kod
      INTO ln_gl_group_code
      FROM CBS_MUSTERI
      WHERE musteri_no = pn_musteri_no ;

      Pkg_Muhasebe.dk_bul ( ln_gl_group_code, ps_modul_tur_kod, ps_urun_tur_kod, ps_urun_sinif_kod, ln_gl_index, lb_kosul_1, lb_kosul_2, lb_kosul_3, ls_gl_code );

     RETURN ls_gl_code ;

   EXCEPTION
    WHEN  OTHERS THEN
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '485' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END ;

 /***************************************************************************************************************/
 /*  Procedure sp_vade_tarihi_uygunmu                                                                                */
 /*  girilen vade tarihi is g?n? ise ve girilen vade tarihinden b?y?kse hata verilir                             */
 /**************************************************************************************************************/
 PROCEDURE sp_vade_tarihi_uygunmu( pn_teklif_satir_no CBS_KREDI_TEKLIF_SATIR.teklif_satir_no%TYPE, pd_vade_tarihi CBS_HESAP_KREDI.kredi_vade%TYPE)
  IS
     ln_teklif_no NUMBER;
       ld_valor_tarihi DATE;
     ls_vade_tipi  VARCHAR2(20);
     ln_vade_suresi NUMBER;
     ln_retval NUMBER;
     teklif_valorunden_ileri_tarih EXCEPTION;
     tatil_gunu                       EXCEPTION;
   BEGIN
      IF Pkg_Tarih.gun_ozellik(pd_vade_tarihi) != 0 THEN
            RAISE tatil_gunu;
      END IF;
         ln_teklif_no :=Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL( pn_teklif_satir_no);
       SELECT DECODE(vade_tipi,'DAY','D','MONTH','M','YEAR','Y'),NVL(vade_suresi,0)
      INTO   ls_vade_tipi ,ln_vade_suresi
      FROM   CBS_KREDI_TEKLIF_SATIR
      WHERE  teklif_no = ln_teklif_no AND teklif_satir_no = pn_teklif_satir_no;

      ln_retval := Pkg_Tarih.vade_tarihini_bul ( Pkg_Muhasebe.BANKA_TARIHI_BUL,ln_vade_suresi, ls_vade_tipi, 'N', ld_valor_tarihi,NULL );

      IF pd_vade_tarihi IS NOT NULL AND TO_DATE(pd_vade_tarihi,'DD/MM/YYYY') > TO_DATE(ld_valor_tarihi,'DD/MM/YYYY') THEN
            RAISE teklif_valorunden_ileri_tarih;
      END IF;

    EXCEPTION
      WHEN tatil_gunu THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '486' || Pkg_Hata.getUCPOINTER);
      WHEN teklif_valorunden_ileri_tarih THEN
             SELECT DECODE(ls_vade_tipi,'D','DAY','M','MONTH','Y','YEAR',ls_vade_tipi)
         INTO ls_vade_tipi FROM dual;
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '487' || Pkg_Hata.getDelimiter|| TO_CHAR(ln_vade_suresi) ||' '|| ls_vade_tipi ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
    WHEN NO_DATA_FOUND THEN NULL;
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '488' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;

  /****************************************************************************************************************/
  /*   Function     subemi_genel_mudurluk_mu                                                                            */
  /*   bolum kodu sube ise 'S' genel mudurluk ise 'G' dondurulur                                                  */
  /****************************************************************************************************************/
  FUNCTION subemi_genel_mudurluk_mu(ps_bolum_kodu CBS_BOLUM.kodu%TYPE) RETURN VARCHAR2
  IS
    ls_sonuc VARCHAR2(1) ;
    BEGIN
       SELECT DECODE(sube_f,'E','S','G')
       INTO   ls_sonuc
       FROM   CBS_BOLUM
       WHERE  kodu = ps_bolum_kodu;

       RETURN ls_sonuc;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
   END;

  /****************************************************************************************************************/
  /*   Function     sf_faiz_tahakkuk_tarihi_bul                                                                         */
  /****************************************************************************************************************/
 FUNCTION sf_faiz_tahakkuk_tarihi_bul(ps_faiz_siklik_tipi CBS_HESAP_KREDI.FAIZ_SIKLIK_TIPI%TYPE ,
                                         ps_faiz_siklik CBS_HESAP_KREDI.FAIZ_SIKLIK%TYPE ,
                                         pd_faiz_tarihi DATE DEFAULT Pkg_Muhasebe.banka_tarihi_bul,
                                      ps_vade_tarihi DATE DEFAULT Pkg_Muhasebe.banka_tarihi_bul
                                       ) RETURN CBS_HESAP_KREDI.FAIZ_TAHAKKUK_TARIHI%TYPE
 IS
       ld_valor_tarihi DATE;
     ls_vade_tipi  VARCHAR2(20);
     ln_retval NUMBER;
   BEGIN

       SELECT DECODE(ps_faiz_siklik_tipi,'DAY','D','MONTH','M','YEAR','Y')
      INTO   ls_vade_tipi
      FROM   dual;

      /* vade tarihinde ise */
     IF  ps_faiz_siklik_tipi in( 'MATURITY DATE','INSTALLMENT DATE') THEN
         RETURN ps_vade_tarihi ;
     ELSIF  ps_faiz_siklik_tipi =  'EOM' THEN
      /*is gunu*/
          RETURN  LAST_DAY(Pkg_Tarih.AYIN_SON_IS_GUNU(ADD_MONTHS(pd_faiz_tarihi, NVL(ps_faiz_siklik,0) *1) )) ;
     ELSIF     ps_faiz_siklik_tipi = 'EOQ' THEN
     /* son gun is gunu olmesi istenmedi */
     RETURN  LAST_DAY(Pkg_Tarih.donemin_SON_IS_GUNU(ADD_MONTHS(pd_faiz_tarihi, NVL(ps_faiz_siklik,0) *3) )) ;
     ELSIF     ps_faiz_siklik_tipi = 'EOY' THEN
     /* son gun is gunu olmesi istenmedi */
       RETURN LAST_DAY( Pkg_Tarih.yilin_SON_IS_GUNU(ADD_MONTHS(pd_faiz_tarihi, NVL(ps_faiz_siklik,0) *12) )) ;
     ELSE
     /*is gunu*/
       ln_retval := Pkg_Tarih.vade_tarihini_bul ( pd_faiz_tarihi,NVL(ps_faiz_siklik,0), ls_vade_tipi, 'N', ld_valor_tarihi,NULL );
     END IF;

      RETURN ld_valor_tarihi;

    EXCEPTION
     WHEN NO_DATA_FOUND THEN RETURN NULL ;
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '491' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;

  /*****************************************************************************************************************/
  /*  Function modul_tur_kod                                                                                                */
  /*  modul bilgisi dondurulur                                                                                       */
  /*****************************************************************************************************************/
   FUNCTION modul_tur_kod RETURN VARCHAR2
   IS
   BEGIN
           RETURN 'LOAN';
   END;

  /*****************************************************************************************************************/
  /*  Procedure kredi_hesap_ac                                                                                                */
  /*  genel kredi a??l?? moduludur                                                                               */
  /*****************************************************************************************************************/

PROCEDURE kredi_hesap_ac(  ps_modul_tur VARCHAR2, ps_urun_tur VARCHAR2, ps_urun_sinif VARCHAR2,
                            pn_musteri_no NUMBER, ps_doviz VARCHAR2, ps_sube VARCHAR2, pd_vade DATE,
                            ps_referans VARCHAR2, pn_hesap_no OUT NUMBER ,
                            p_musteri_dk_no        CBS_HESAP_KREDI.MUSTERI_DK_NO%TYPE DEFAULT NULL,
                            p_tutar    CBS_HESAP_KREDI.tutar%TYPE DEFAULT 0,
                            p_extre_masrafi    CBS_HESAP_KREDI.extre_masrafi%TYPE DEFAULT 'H',
                            p_iliskili_hesap_no    CBS_HESAP_KREDI.iliskili_hesap_no%TYPE DEFAULT NULL,
                            p_kredi_teklif_satir_numara    CBS_HESAP_KREDI.kredi_teklif_satir_numara%TYPE DEFAULT NULL,
                            p_kredi_kullandirim_kodu    CBS_HESAP_KREDI.kredi_kullandirim_kodu%TYPE DEFAULT NULL,
                            p_endeks_doviz_kodu    CBS_HESAP_KREDI.endeks_doviz_kodu%TYPE DEFAULT NULL,
                            p_kullandirim_doviz_kodu    CBS_HESAP_KREDI.kullandirim_doviz_kodu%TYPE DEFAULT NULL,
                            p_son_gun_faizi    CBS_HESAP_KREDI.son_gun_faizi%TYPE DEFAULT NULL,
                            p_acilis_kuru    CBS_HESAP_KREDI.acilis_kuru%TYPE DEFAULT NULL,
                            p_faiz_orani    CBS_HESAP_KREDI.faiz_orani%TYPE DEFAULT NULL,
                            p_faiz_siklik    CBS_HESAP_KREDI.faiz_siklik%TYPE DEFAULT NULL,
                            p_faiz_siklik_tipi    CBS_HESAP_KREDI.faiz_siklik_tipi%TYPE DEFAULT NULL,
                            p_faiz_tahakkuk_tarihi    CBS_HESAP_KREDI.faiz_tahakkuk_tarihi%TYPE DEFAULT NULL,
                            p_komisyon_orani    CBS_HESAP_KREDI.komisyon_orani%TYPE DEFAULT NULL,
                            p_komisyon_tutari    CBS_HESAP_KREDI.komisyon_tutari%TYPE DEFAULT NULL,
                            p_komisyon_tahsilat_donemi    CBS_HESAP_KREDI.komisyon_tahsilat_donemi%TYPE DEFAULT NULL,
                            p_fon_orani    CBS_HESAP_KREDI.fon_orani%TYPE DEFAULT NULL,
                            p_bsmv_orani    CBS_HESAP_KREDI.bsmv_orani%TYPE DEFAULT NULL,
                            p_alacak_hesap_no    CBS_HESAP_KREDI.alacak_hesap_no%TYPE DEFAULT NULL,
                            p_kur_farki    CBS_HESAP_KREDI.kur_farki%TYPE DEFAULT NULL,
                            p_sinirlama_kodu    CBS_HESAP_KREDI.sinirlama_kodu%TYPE DEFAULT NULL,
                            p_kaynak_kodu    CBS_HESAP_KREDI.kaynak_kodu%TYPE DEFAULT NULL,
                            p_istatistik_kodu    CBS_HESAP_KREDI.istatistik_kodu%TYPE DEFAULT NULL,
                            p_urun_grup_no    CBS_HESAP_KREDI.urun_grup_no%TYPE DEFAULT NULL,
--                            p_kredi_teklif_no    cbs__kredi.kredi_teklif_no%type default null,
                            p_faiz_tahakkuk_hesap_no    CBS_HESAP_KREDI.faiz_tahakkuk_hesap_no%TYPE DEFAULT NULL,
                            p_vergi_tahakkuk_hesap_no    CBS_HESAP_KREDI.vergi_tahakkuk_hesap_no%TYPE DEFAULT NULL,
                            p_birikmis_faiz_tutari    CBS_HESAP_KREDI.birikmis_faiz_tutari%TYPE DEFAULT 0,
                            p_birikmis_komisyon_tutari    CBS_HESAP_KREDI.birikmis_komisyon_tutari%TYPE DEFAULT 0 ,
                            p_esas_gun_sayisi             CBS_HESAP_KREDI.ESAS_GUN_SAYISI%TYPE DEFAULT 360,
                            p_acilis_tarihi    CBS_HESAP_KREDI.acilis_tarihi%TYPE DEFAULT Pkg_Muhasebe.Banka_Tarihi_Bul,
                            p_endeks_doviz_tutari NUMBER DEFAULT 0,
                            p_sch_faiz_orani NUMBER DEFAULT 0,
                            p_eski_hesap_no NUMBER DEFAULT 0,
                            p_eski_hesap_ekno NUMBER DEFAULT 0,
                            p_eski_faiz_ekno NUMBER DEFAULT 0,
                            p_eski_kom_ekno NUMBER DEFAULT 0,
                            p_odeme_turu        VARCHAR2 DEFAULT NULL,
                            p_taksit_sayisi        NUMBER DEFAULT NULL,
                            p_taksit_once_sonra    VARCHAR2 DEFAULT NULL,
                            p_artis_siklik        NUMBER DEFAULT NULL,
                            p_artis_oran        NUMBER DEFAULT NULL,
                            p_ara_odeme_siklik    NUMBER DEFAULT NULL,
                            p_ara_odeme_tutar        NUMBER DEFAULT NULL,
                            p_donem_siklik        NUMBER DEFAULT NULL,
                            p_kredi_turu        NUMBER DEFAULT NULL,
                            p_sch_faiz_tur VARCHAR2 DEFAULT NULL,
                            p_tahakkuk_sch_faiz_tutari NUMBER DEFAULT 0    ,
                            p_temdit_tarihi               DATE DEFAULT NULL,
                            p_repayment_type                     CBS_HESAP_KREDI.repayment_type%TYPE DEFAULT NULL,
                            p_prefix_istatistik_kodu           CBS_HESAP_KREDI.prefix_istatistik_kodu%TYPE DEFAULT NULL,
                            p_prefix_istatistik_kodu_faiz       CBS_HESAP_KREDI.prefix_istatistik_kodu_faiz%TYPE DEFAULT NULL,
                            p_istatistik_kodu_faiz                CBS_HESAP_KREDI.istatistik_kodu_faiz%TYPE DEFAULT NULL,
                            p_prefix_istatistik_kodu_kapa       CBS_HESAP_KREDI.prefix_istatistik_kodu_kapama%TYPE DEFAULT NULL,
                            p_istatistik_kodu_kapama          CBS_HESAP_KREDI.istatistik_kodu_kapama%TYPE DEFAULT NULL,
                            p_ana_kredi_hesap_no          cbs_hesap_kredi.ana_kredi_hesap_no%type default null,
                            p_pastdue_faiz_anapara_sec          cbs_hesap_kredi.pastdue_faiz_anapara_sec%type default null,
                            p_pastdue_faiz_orani number default null    ,
                            p_yearly_int_rate    number    default null,
                            p_alacak_secimi         cbs_hesap_kredi.alacak_secimi%type default null,
                            p_alacak_dk_no         cbs_hesap_kredi.alacak_dk_no%type default null,
                            p_CONTRACT_STATUS    cbs_hesap_kredi.CONTRACT_STATUS%type default 1,
                            p_gecmis_aylarin_faizi  number default null ,
                            p_gecmis_aylarin_komisyonu number default null,
                            p_taksit_baslangic_tarihi     date default null,
                            p_ek_taksit_faiz             number default null,
                            p_report_cust_type             varchar2 default null,
                            pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE default null,  --chyngyzo 28102014 cqdb614  add app_no
                            p_loan_numara CBS_HESAP_KREDI.LOAN_NUMARA%TYPE default null, --VictorK 17062015
                            p_agreement_date  CBS_HESAP_KREDI.agreement_date%TYPE default null, -- CQ5318 additinal fields KonstantinJ 26052016
                            p_agreement_no  CBS_HESAP_KREDI.agreement_no%TYPE default null, -- CQ5318 additinal fields KonstantinJ 26052016
                            p_transaction_type  CBS_HESAP_KREDI.transaction_type%TYPE default null, -- CQ5935 ViktorT 22032018
                            p_yearly_effective_int_rate  CBS_HESAP_KREDI.yearly_effective_int_rate%TYPE default null, -- CQ5935 ViktorT 22032018
                            -- B-O-M seval.colak 09052021 
                            p_odeme_plan_no             cbs_hesap_kredi.odeme_plan_no%type  default null ,
                            p_odeme_gunu                cbs_hesap_kredi.odeme_gunu%type  default null ,
                            p_taksit_siklik             cbs_hesap_kredi.taksit_siklik%type  default null ,
                            p_odemesiz_ay_sayisi        cbs_hesap_kredi.odemesiz_ay_sayisi%type  default null ,
                            p_faiz_yontemi_methodu      cbs_hesap_kredi.faiz_yontemi_methodu%type  default null ,
                            p_faiz_hesaplama_tipi       cbs_hesap_kredi.faiz_hesaplama_tipi%type  default null,
                            p_penalty_rate              cbs_hesap_kredi.penalty_rate%type  default null ,
                            -- E-O-M seval.colak 09052021 
                            p_faiz_orani_tipi            cbs_hesap_kredi.faiz_orani_tipi%type  default null ,
                            p_monthly_int_Rate           cbs_hesap_kredi.monthly_int_Rate%type  default null 
                            )
 IS
    -- gayrinakdi kredi hesab? a??l?r
  ln_hesap_no NUMBER;
  ln_grup_kod NUMBER;
  ls_gl_code VARCHAR2(30);
  ln_teklif_no  NUMBER NULL;
  ls_var varchar2(200);
  dkyok     exception;
  ls_musteri_tip   varchar2(1);
  BEGIN
    ln_hesap_no := Pkg_Genel.genel_kod_al('HESAP.VDSZ');
    IF ps_urun_tur not in ( 'TAHAKKUK','ACCRUAL','NONACCRUAL') THEN
           if p_pastdue_faiz_anapara_sec in ('FAIZ','ANAPARA','TAX','ACCRUAL-INTEREST','ACCRUAL-TAX','ACCRUAL-DELAYED-INTEREST','NONACCRUAL-INTEREST','NONACCRUAL-DELAYED-INTEREST') then --seval.colak 23112021 nonaccrual addition
             ls_gl_code := p_musteri_dk_no ;
         else
             SELECT dk_grup_kod
             INTO ln_grup_kod
             FROM CBS_MUSTERI
             WHERE musteri_no = pn_musteri_no;
              Pkg_Muhasebe.dk_bul(   ln_grup_kod, ps_modul_tur, ps_urun_tur,  ps_urun_sinif,  1,
                               FALSE, FALSE, FALSE, ls_gl_code);
        end if;
    ELSE
          ls_gl_code := p_musteri_dk_no ;
    END IF;

     ls_var:= Pkg_Muhasebe.DK_VARMI(ps_sube,ls_gl_code, ps_doviz);
     
     IF ls_var <> 'E' THEN
        RAISE dkyok;
     END IF;

    if p_report_cust_type is null
    then
        ls_musteri_tip := pkg_musteri.sf_musteri_tipi_al(pn_musteri_no);
    else
        ls_musteri_tip := p_report_cust_type;
    end if;

    INSERT INTO CBS_HESAP_KREDI(hesap_no, musteri_no, doviz_kodu, tutar, durum_kodu,
                                sube_kodu, musteri_dk_no, urun_tur_kod, urun_sinif_kod,
                                modul_tur_kod, kredi_vade, referans,
                                kredi_teklif_satir_numara    ,kredi_kullandirim_kodu    ,
                                endeks_doviz_kodu    ,kullandirim_doviz_kodu    ,son_gun_faizi    ,
                                acilis_kuru    ,faiz_orani    ,faiz_siklik    ,faiz_siklik_tipi    ,
                                faiz_tahakkuk_tarihi    ,komisyon_orani    ,komisyon_tutari    ,
                                komisyon_tahsilat_donemi    ,fon_orani    ,bsmv_orani    ,alacak_hesap_no    ,                        iliskili_hesap_no    ,
                                kur_farki    ,extre_masrafi    ,sinirlama_kodu    ,
                                kaynak_kodu    ,istatistik_kodu    ,urun_grup_no    ,
                                faiz_tahakkuk_hesap_no    ,vergi_tahakkuk_hesap_no    ,
                                birikmis_faiz_tutari    ,birikmis_komisyon_tutari ,
                                esas_gun_sayisi,
                                acilis_tarihi,
                                endeks_doviz_tutari ,
                                son_islem_kuru,
                                sch_faiz_orani, odeme_turu, taksit_sayisi,
                                taksit_once_sonra, artis_siklik, artis_oran,
                                ara_odeme_siklik, ara_odeme_tutar, donem_siklik, kredi_turu,
                                sch_faiz_tur ,
                                tahakkuk_sch_faiz_tutari,
                                temdit_tarihi,
                                repayment_type,
                                prefix_istatistik_kodu,
                                prefix_istatistik_kodu_faiz,
                                istatistik_kodu_faiz,
                                prefix_istatistik_kodu_kapama,
                                istatistik_kodu_kapama,
                                ana_kredi_hesap_no,
                                pastdue_faiz_anapara_sec,
                                pastdue_faiz_orani,
                                yearly_int_rate,
                                alacak_secimi,
                                alacak_dk_no,
                                contract_status,
                                gecmis_aylarin_faizi,
                                gecmis_aylarin_komisyonu,
                                taksit_baslangic_tarihi,
                                ek_taksit_faiz,
                                REPORT_CUSTOMER_TYPE,
                                APP_NO, --chyngyzo 27102014 cqdb614  add app_no
                                loan_numara,  --VictorK 17062015
                                   agreement_date, -- CQ5318 additinal fields KonstantinJ 26052016
                                agreement_no,    -- CQ5318 additinal fields KonstantinJ 26052016
                                transaction_type, -- CQ 5935 ViktorT 22032018
                                yearly_effective_int_rate, -- CQ 5935 ViktorT 22032018
                                -- B-O-M seval.colak 09052021
                                odeme_plan_no,
                                odeme_gunu,
                                taksit_siklik,
                                odemesiz_ay_sayisi,
                                faiz_yontemi_methodu,
                                faiz_hesaplama_tipi,
                                penalty_rate,
                                -- E-O-M seval.colak 09052021
                                -- B-O-M seval.colak 29032022
                                faiz_orani_tipi  ,
                                monthly_int_Rate  
                                -- E-O-M seval.colak 29032022
                                )
                        VALUES (ln_hesap_no, pn_musteri_no, ps_doviz, p_tutar, 'A',
                                ps_sube, ls_gl_code,
                                ps_urun_tur, ps_urun_sinif,
                                ps_modul_tur, pd_vade, ps_referans,
                                p_kredi_teklif_satir_numara    ,p_kredi_kullandirim_kodu    ,
                                p_endeks_doviz_kodu    ,p_kullandirim_doviz_kodu    ,p_son_gun_faizi    ,
                                p_acilis_kuru    ,p_faiz_orani    ,p_faiz_siklik    ,p_faiz_siklik_tipi    ,
                                p_faiz_tahakkuk_tarihi    ,p_komisyon_orani    ,p_komisyon_tutari    ,
                                p_komisyon_tahsilat_donemi    ,p_fon_orani    ,p_bsmv_orani    ,
                                p_alacak_hesap_no    ,
                                p_iliskili_hesap_no    ,
                                p_kur_farki    ,
                                NVL(p_extre_masrafi,'H'),p_sinirlama_kodu    ,p_kaynak_kodu    ,
                                p_istatistik_kodu    ,
                                p_urun_grup_no    ,
                                p_faiz_tahakkuk_hesap_no    ,
                                p_vergi_tahakkuk_hesap_no    ,
                                p_birikmis_faiz_tutari    ,
                                p_birikmis_komisyon_tutari,NVL(p_esas_gun_sayisi,360),
                                NVL(p_acilis_tarihi,Pkg_Muhasebe.banka_tarihi_bul),
                                DECODE(p_endeks_doviz_kodu,NULL,0,p_endeks_doviz_tutari) ,
                                DECODE(p_endeks_doviz_kodu,NULL,NULL,p_acilis_kuru),
                                p_sch_faiz_orani, p_odeme_turu, p_taksit_sayisi,
                                p_taksit_once_sonra, p_artis_siklik, p_artis_oran,
                                p_ara_odeme_siklik, p_ara_odeme_tutar, p_donem_siklik, p_kredi_turu,
                                p_sch_faiz_tur ,
                                p_tahakkuk_sch_faiz_tutari,
                                p_temdit_tarihi        ,
                                p_repayment_type,
                                p_prefix_istatistik_kodu,
                                p_prefix_istatistik_kodu_faiz,
                                p_istatistik_kodu_faiz,
                                p_prefix_istatistik_kodu_kapa,
                                p_istatistik_kodu_kapama,
                                P_ana_kredi_hesap_no,
                                P_pastdue_faiz_anapara_sec,
                                p_pastdue_faiz_orani,
                                p_yearly_int_rate,
                                p_alacak_secimi    ,
                                p_alacak_dk_no,
                                p_contract_status,
                                p_gecmis_aylarin_faizi,
                                p_gecmis_aylarin_komisyonu,
                                p_taksit_baslangic_tarihi,
                                p_ek_taksit_faiz,
                                ls_musteri_tip,
                                pn_app_no,  --chyngyzo 27102014 cqdb614  add app_no
                                p_loan_numara,
                                    p_agreement_date ,  -- CQ5318 additinal fields KonstantinJ 26052016
                                p_agreement_no,       -- CQ5318 additinal fields KonstantinJ 26052016
                                p_transaction_type, -- CQ 5935 ViktorT 22032018
                                p_yearly_effective_int_rate ,-- CQ 5935 ViktorT 22032018
                                -- B-O-M seval.colak 09052021
                                p_odeme_plan_no,
                                p_odeme_gunu,
                                p_taksit_siklik,
                                p_odemesiz_ay_sayisi,
                                p_faiz_yontemi_methodu,
                                p_faiz_hesaplama_tipi,
                                p_penalty_rate ,
                                 -- E-O-M seval.colak 09052021 
                                 -- B-O-M seval.colak 29032022
                                p_faiz_orani_tipi  ,
                                p_monthly_int_Rate  
                                -- E-O-M seval.colak 29032022
                               );
                   Pkg_Hesap.HESAP_BAKIYE_OLUSTUR(
                                 ln_hesap_no,
                                 0,
                                 0,
                                 0,
                                 Pkg_Parametre.deger(
                                 ps_modul_tur ,ps_urun_tur,ps_urun_sinif,
                                 'BAKIYE_KARAKTERI'));
    pn_hesap_no := ln_hesap_no;
  EXCEPTION
   WHEN dkyok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '704' || Pkg_Hata.getdelimiter || ls_gl_code||  Pkg_Hata.getdelimiter || ps_sube|| Pkg_Hata.getdelimiter ||ps_doviz|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '533' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

  END;

  /*****************************************************************************************************************/
  /*  Procedure sp_islemden_kredi_hesap_acilis                                                                                                */
  /*  Hesap no dondurulur                                                                                   */
  /*****************************************************************************************************************/
 PROCEDURE sp_islemden_kredi_hesap_acilis(pn_islem_no NUMBER,pn_hesap_no OUT CBS_HESAP_KREDI.hesap_no%TYPE ,ps_doviz_kodu OUT CBS_HESAP_KREDI.doviz_kodu%TYPE)
  IS

    ls_modul_tur_kod  CBS_HESAP_KREDI.modul_tur_kod%TYPE;
    ls_urun_tur_kod   CBS_HESAP_KREDI.urun_tur_kod%TYPE;
    ls_urun_sinif_kod CBS_HESAP_KREDI.urun_sinif_kod%TYPE;
    ln_adet NUMBER := 0;
    ln_taksit_sayisi number := 0;
    ls_vade date;
    ln_app_no number; --cq614 ErkinZu 26.04.2017
    ln_musteri_no number; --cq614 ErkinZu 26.04.2017
    ln_satir_no number; --cq614 ErkinZu 26.04.2017
    ln_odeme_plan_no number; -- seval.colak 09052021
    
    CURSOR cursor_hesap IS
         SELECT * FROM CBS_HESAP_KREDI_ISLEM
         WHERE tx_no = pn_islem_no;

   BEGIN

      FOR cur_hesap IN cursor_hesap LOOP
         ls_vade := cur_hesap.kredi_vade ;
         ln_musteri_no := cur_hesap.musteri_no;
         ln_satir_no := cur_hesap.kredi_teklif_satir_numara;
         ln_odeme_plan_no := cur_hesap.odeme_plan_no; -- seval.colak 09052021
           ps_doviz_kodu := cur_hesap.doviz_kodu;
             Pkg_Kredi.kredi_hesap_ac( ps_modul_tur => cur_hesap.modul_tur_kod,
                                      ps_urun_tur =>  cur_hesap.urun_tur_kod,
                                   ps_urun_sinif => cur_hesap.urun_sinif_kod,
                                   pn_musteri_no => cur_hesap.musteri_no,
                                   ps_doviz => cur_hesap.doviz_kodu,
                                   ps_sube => cur_hesap.sube_kodu,
                                   pd_vade =>  cur_hesap.kredi_vade,
                                   ps_referans => cur_hesap.referans,
                                   pn_hesap_no=> pn_hesap_no,
                                   p_musteri_dk_no => cur_hesap.musteri_dk_no,
                                   p_tutar => cur_hesap.tutar,
                                   p_extre_masrafi => cur_hesap.extre_masrafi,
                                   p_iliskili_hesap_no    => cur_hesap.iliskili_hesap_no,
                                   p_kredi_teklif_satir_numara => cur_hesap.kredi_teklif_satir_numara,
                                   p_kredi_kullandirim_kodu => cur_hesap.kredi_kullandirim_kodu,
                                   p_endeks_doviz_kodu => cur_hesap.endeks_doviz_kodu,
                                   p_kullandirim_doviz_kodu => cur_hesap.kullandirim_doviz_kodu,
                                   p_son_gun_faizi => cur_hesap.son_gun_faizi,
                                   p_acilis_kuru => cur_hesap.acilis_kuru,
                                   p_faiz_orani => cur_hesap.faiz_orani,
                                   p_faiz_siklik => cur_hesap.faiz_siklik,
                                   p_faiz_siklik_tipi => cur_hesap.faiz_siklik_tipi,
                                   p_faiz_tahakkuk_tarihi    => cur_hesap.faiz_tahakkuk_tarihi,
                                   p_komisyon_orani => cur_hesap.komisyon_orani,
                                   p_komisyon_tutari=>cur_hesap.komisyon_tutari,
                                   p_komisyon_tahsilat_donemi => cur_hesap.komisyon_tahsilat_donemi,
                                   p_fon_orani    => cur_hesap.fon_orani,
                                   p_bsmv_orani => cur_hesap.bsmv_orani,
                                   p_alacak_hesap_no => cur_hesap.alacak_hesap_no,
                                   p_kur_farki =>cur_hesap.kur_farki,
                                   p_sinirlama_kodu => cur_hesap.sinirlama_kodu,
                                   p_kaynak_kodu => cur_hesap.kaynak_kodu,
                                   p_istatistik_kodu => cur_hesap.istatistik_kodu,
                                   p_urun_grup_no     => cur_hesap.urun_grup_no,
                                    p_faiz_tahakkuk_hesap_no => cur_hesap.faiz_tahakkuk_hesap_no,
                                   p_vergi_tahakkuk_hesap_no => cur_hesap.vergi_tahakkuk_hesap_no,
                                   p_birikmis_faiz_tutari => cur_hesap.birikmis_faiz_tutari,
                                   p_birikmis_komisyon_tutari =>cur_hesap.birikmis_komisyon_tutari,
                                   p_esas_gun_sayisi => 360,--cur_hesap.esas_gun_sayisi ,  --esas gun sayisi
                                   p_acilis_tarihi =>Pkg_Muhasebe.Banka_Tarihi_Bul,  --acilis tarihi
                                   p_endeks_doviz_tutari => cur_hesap.endeks_doviz_tutari,
                                   p_sch_faiz_orani => cur_hesap.sch_faiz_orani,
                                   p_eski_hesap_no => cur_hesap.eski_hesap_no,
                                   p_eski_hesap_ekno =>cur_hesap.eski_hesap_ekno,
                                   p_eski_faiz_ekno => cur_hesap.eski_faizhesap_ekno,
                                   p_eski_kom_ekno => cur_hesap.eski_komhesap_ekno  ,
                                   p_sch_faiz_tur => cur_hesap.sch_faiz_tur,
                                   p_tahakkuk_sch_faiz_tutari => cur_hesap.tahakkuk_sch_faiz_tutari,
                                   p_temdit_tarihi => cur_hesap.temdit_tarihi,
                                   p_repayment_type                     => cur_hesap.repayment_type,
                                   p_prefix_istatistik_kodu       => cur_hesap.prefix_istatistik_kodu,
                                   p_prefix_istatistik_kodu_faiz  => cur_hesap.prefix_istatistik_kodu_faiz,
                                   p_istatistik_kodu_faiz          => cur_hesap.istatistik_kodu_faiz,
                                   p_prefix_istatistik_kodu_kapa  => cur_hesap.prefix_istatistik_kodu_kapama,
                                   p_istatistik_kodu_kapama          => cur_hesap.istatistik_kodu_kapama,
                                   p_pastdue_faiz_orani              => cur_hesap.pastdue_faiz_orani,
                                   p_yearly_int_rate              => cur_hesap.yearly_int_rate,
                                   p_alacak_secimi                  => cur_hesap.alacak_secimi,
                                   p_alacak_dk_no                    => cur_hesap.alacak_dk_no,
                                   p_CONTRACT_STATUS                => cur_hesap.CONTRACT_STATUS,
                                   p_gecmis_aylarin_faizi          => cur_hesap.gecmis_aylarin_faizi,
                                   p_gecmis_aylarin_komisyonu      => cur_hesap.gecmis_aylarin_komisyonu,
                                   p_taksit_baslangic_tarihi      =>cur_hesap.taksit_baslangic_tarihi,
                                   p_ek_taksit_faiz                  =>cur_hesap.ek_taksit_faiz,
                                   p_report_cust_type              =>cur_hesap.REPORT_CUSTOMER_TYPE,
                                   pn_app_no => cur_hesap.APP_NO,  --chyngyzo 27102014 cqdb614  add app_no
                                   p_loan_numara => cur_hesap.loan_numara, --VictorK 17062015
                                   p_agreement_date  => cur_hesap.agreement_date , -- CQ5318 additinal fields KonstantinJ 26052016
                                   p_agreement_no   => cur_hesap.agreement_no, -- CQ5318 additinal fields KonstantinJ 26052016
                                   p_transaction_type => cur_hesap.transaction_type, --CQ5935 ViktorT 22032018
                                   p_yearly_effective_int_rate => cur_hesap.yearly_effective_int_rate ,--CQ5935 ViktorT 22032018
                                   -- B-O-M seval.colak 09052021
                                   p_odeme_plan_no  =>  cur_hesap.odeme_plan_no,
                                   p_odeme_gunu  =>  cur_hesap.odeme_gunu,
                                   p_taksit_siklik  =>  cur_hesap.taksit_siklik,
                                   p_odemesiz_ay_sayisi  =>  cur_hesap.odemesiz_ay_sayisi,
                                   p_faiz_yontemi_methodu  =>  cur_hesap.faiz_yontemi_methodu,
                                   p_faiz_hesaplama_tipi  =>  cur_hesap.faiz_hesaplama_tipi,
                                   p_penalty_rate  =>  cur_hesap.penalty_rate ,
                                     -- E-O-M seval.colak 09052021 
                                      -- B-O-M seval.colak 29032022
                                    p_faiz_orani_tipi   =>  cur_hesap.faiz_orani_tipi,
                                    p_monthly_int_Rate  =>  cur_hesap.monthly_int_Rate
                                -- E-O-M seval.colak 29032022
                                   );
       END LOOP;

      /* islem tablolar?n?n hesap no alanlar? guncellenir*/
        UPDATE CBS_HESAP_KREDI_ISLEM
        SET    hesap_no  =pn_hesap_no
        WHERE tx_no = pn_islem_no;
/*280105 bireysel kredi alanlari guncellenmesi eklendi */
        UPDATE CBS_HESAP_KREDI
        SET    (KREDI_TURU, TAKSIT_SAYISI, TAKSIT_ONCE_SONRA, ARTIS_SIKLIK, ARTIS_ORAN, ARA_ODEME_SIKLIK, ARA_ODEME_TUTAR, DONEM_SIKLIK, ODEME_TURU, SCH_FAIZ_TUR,
                TAKSIT_BASLANGIC_TARIHI, EK_TAKSIT_FAIZ, GECMIS_AYLARIN_FAIZI, GECMIS_AYLARIN_KOMISYONU
                   )
               = (select
                      KREDI_TURU, TAKSIT_SAYISI, TAKSIT_ONCE_SONRA, ARTIS_SIKLIK, ARTIS_ORAN, ARA_ODEME_SIKLIK, ARA_ODEME_TUTAR, DONEM_SIKLIK, ODEME_TURU, SCH_FAIZ_TUR,
                   TAKSIT_BASLANGIC_TARIHI, EK_TAKSIT_FAIZ, GECMIS_AYLARIN_FAIZI, GECMIS_AYLARIN_KOMISYONU                  
                     from CBS_HESAP_KREDI_ISLEM
                  WHERE tx_no = pn_islem_no)
        WHERE hesap_no  =pn_hesap_no;

        UPDATE CBS_HESAP_KREDI
        SET    ACILIS_KREDI_VADE = ls_vade
        WHERE hesap_no  =pn_hesap_no;

        --BOM cq614 ErkinZu 26.04.2017
        ln_app_no := PKG_KREDI.SF_GET_CUSTOMER_APPNO(ln_musteri_no, ln_satir_no);
        if ln_app_no is not null then
            UPDATE cbs_hesap_kredi
            SET app_no = ln_app_no
            WHERE hesap_no = pn_hesap_no;
        end if;    
        --EOM cq614 ErkinZu 26.04.2017

        UPDATE CBS_ISLEM
        SET hesap_numara =pn_hesap_no
        WHERE numara = pn_islem_no;

        --B-O-M chyngyzo 26092014 cqdb614 desc: set loan application no 
          /*  BEGIN

                UPDATE CBS_HESAP_KREDI
                SET    APP_NO = (SELECT APP_NO FROM CBS_HESAP_KREDI_ISLEM WHERE TX_NO = PN_ISLEM_NO)
                WHERE hesap_no = pn_hesap_no;
                
               UPDATE CBS_CIB_LOAN_APPLICATION
               SET DISBURSED = 'Y'
               WHERE APP_NO = (SELECT APP_NO FROM CBS_HESAP_KREDI_ISLEM WHERE TX_NO = PN_ISLEM_NO);
               
                EXCEPTION WHEN OTHERS THEN NULL;
             END;*/
        --E-O-M chyngyzo 26092014 cqdb614 

        BEGIN
            SELECT COUNT(*)
            INTO ln_adet
            FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
            WHERE tx_no = pn_islem_no;

            IF NVL(ln_adet,0)  <> 0 THEN
               UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
               SET hesap_no = pn_hesap_no
               WHERE tx_no = pn_islem_no;

               insert into cbs_hesap_kredi_taksit(yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit,
                                                  durum_kodu ,odeme_tarihi,gecikme_faiz_tutari,kur_trl,anapara_trl,faiz_trl,kdv_trl,
                                                  taksit_gun_sayisi,hesaplama_gun_sayisi,taksit_baz_anapara,taksit_faiz_orani,taksit_bsmv_orani,taksit_kkdf_orani,ozel_odeme_tutari,orj_vergi_tutari,orj_faiz_tutari,ek_faiz_tutari,
                                                  deferred_interest ,deferred_delayed_interest,deferred_tax,paid_deferred_interest,paid_deferred_delayed_interest,paid_deferred_tax,tahsil_taksit,tahsil_anapara,tahsil_faiz,tahsil_kkdf,tahsil_bsmv,tahsil_gecikme_faiz_tutari,deferred_tax2,paid_deferred_tax2,tahakkuk_eh,-- seval.colak 09052021
                                                  penalty_amount,paid_penalty_amount,deferred_penalty_amount,paid_deferred_penalty_amount   -- seval.colak 09052021
                                                  ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
                                                   ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022
                                                  )
               select  pn_islem_no, pn_hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit,
                       NVL(durum_kodu,'A'), odeme_tarihi,gecikme_faiz_tutari,kur_trl,anapara_trl,faiz_trl,kdv_trl,
                       taksit_gun_sayisi,hesaplama_gun_sayisi,taksit_baz_anapara,taksit_faiz_orani,taksit_bsmv_orani,taksit_kkdf_orani,ozel_odeme_tutari,orj_vergi_tutari,orj_faiz_tutari,ek_faiz_tutari,
                       deferred_interest ,deferred_delayed_interest,deferred_tax,paid_deferred_interest,paid_deferred_delayed_interest,paid_deferred_tax,tahsil_taksit,tahsil_anapara,tahsil_faiz,tahsil_kkdf,tahsil_bsmv,tahsil_gecikme_faiz_tutari,deferred_tax2,paid_deferred_tax2,tahakkuk_eh, -- seval.colak 09052021
                       penalty_amount,paid_penalty_amount,deferred_penalty_amount,paid_deferred_penalty_amount  -- seval.colak 09052021
                       ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
                          ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022
               from cbs_hesap_kredi_taksit_islem
               where tx_no = pn_islem_no;

               if nvl( ln_odeme_plan_no ,0) = 0 then -- seval.colak 09052021
                   SELECT COUNT(*)
                   into ln_taksit_sayisi
                   FROM cbs_hesap_kredi_taksit
                   where hesap_no = pn_hesap_no ;
                        

                    UPDATE CBS_HESAP_KREDI
                    SET TAKSIT_SAYISI = ln_taksit_sayisi
                    WHERE   hesap_no  =pn_hesap_no ;
                end if;                         -- seval.colak 09052021

            END IF;
         EXCEPTION WHEN OTHERS THEN NULL;
        END ;

        BEGIN
        ln_adet := 0;
            SELECT COUNT(*)
            INTO ln_adet
            FROM cbs_hesap_kredi_ozel_tkst_isl
            WHERE tx_no = pn_islem_no;

            IF NVL(ln_adet,0)  <> 0 THEN
               UPDATE cbs_hesap_kredi_ozel_tkst_isl
               SET hesap_no = pn_hesap_no
               WHERE tx_no = pn_islem_no;

             insert into cbs_hesap_kredi_ozel_tkst (yaratan_tx_no, hesap_no, taksit_sira_no, odeme,
                                                    taksit_tipi  -- seval.colak 09052021
                                                    )
             select tx_no, hesap_no, taksit_sira_no, odeme,
                     taksit_tipi  -- seval.colak 09052021
               from   cbs_hesap_kredi_ozel_tkst_isl
              where  tx_no = pn_islem_no;

            END IF;
         EXCEPTION WHEN OTHERS THEN NULL;
        END ;

    EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '503' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;

  /*****************************************************************************************************************/
  /*  Function Sf_Bitmemis_HesapIslem_Var_Mi                                                                             */
 /*****************************************************************************************************************/
FUNCTION Sf_Bitmemis_HesapIslem_Var_Mi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                           pn_islem_no CBS_ISLEM.numara%TYPE,
                                        pn_teklif_satir_no  CBS_HESAP_KREDI.KREDI_TEKLIF_SATIR_NUMARA%TYPE) RETURN NUMBER
  IS
    ln_tx_no   CBS_ISLEM.numara%TYPE  := 0;
    onayda_bekleyen_islem_var          EXCEPTION;
  BEGIN
       SELECT  MAX(tx_no)
       INTO    ln_tx_no
       FROM   CBS_HESAP_KREDI_ISLEM a , CBS_ISLEM b
       WHERE  a.musteri_no = pn_musteri_no AND
                 a.tx_no = b.numara AND
              a.tx_no <> pn_islem_no AND
              a.kredi_teklif_satir_numara = pn_teklif_satir_no AND
                 Pkg_Tx.ISLEM_BITMIS_MI(b.numara)= 0;


       IF  NVL(ln_tx_no,0) <> 0 THEN
              RAISE     onayda_bekleyen_islem_var;
       END IF;

       RETURN ln_tx_no ;

    EXCEPTION
      WHEN OTHERS THEN
               RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '456' ||Pkg_Hata.getdelimiter|| ln_tx_no  || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
    END;

 /*****************************************************************************************************************/
 /*  Function sf_dovize_endeksli_kredimi                                                                     */
 /*****************************************************************************************************************/

 FUNCTION sf_dovize_endeksli_kredimi(ps_modul_tur_kod CBS_URUN_SINIF.modul_tur_kod%TYPE,
                                     ps_urun_tur_kod CBS_URUN_SINIF.urun_tur_kod%TYPE,
                                  ps_urun_sinif_kod   CBS_URUN_SINIF.kod%TYPE) RETURN VARCHAR2
  IS
   ls_uygun VARCHAR2(1) := 'H';
   BEGIN
        SELECT 'E'
        INTO ls_uygun
        FROM CBS_URUN_SINIF
        WHERE modul_tur_kod =ps_modul_tur_kod AND
              urun_tur_kod = ps_urun_tur_kod AND
              kod = ps_urun_sinif_kod AND
             -- ( kod like '%ENDEKS%' OR kod like '%END.%');
              kod IN (
               'ARAC DOVIZE ENDEKSLI',
               'DIGER T. DOVIZE END.',
               'DOVIZE ENDEKSLI-LC',
               'KONUT DOVIZE ENDEKS.',
               'PERSONEL-D. ENDEKSLI',
               'TUKETICI DOVIZE END.');

     RETURN ls_uygun ;

    EXCEPTION
      WHEN OTHERS THEN RETURN 'H';
   END;


 /*****************************************************************************************************************/
 /*  Procedure sp_kredi_teklif_satir_bakiyeal                                                             */
 /*****************************************************************************************************************/

 PROCEDURE sp_kredi_teklif_satir_bakiyeal( pn_teklif_no      NUMBER,
                                               pn_teklif_satir_no NUMBER ,
                                               pn_bakiye_tl OUT NUMBER,
                                           pn_bakiye_yp OUT NUMBER,
                                           ps_doviz_kodu OUT CBS_DOVIZ_KODLARI.doviz_kodu%TYPE,
                                           pn_risk_tl     OUT NUMBER,
                                           pn_risk_yp OUT NUMBER )

 IS
   ls_kredi_turu               CBS_KREDI_TEKLIF_SATIR.kredi_turu%TYPE;
   ln_musteri_no             CBS_KREDI_TEKLIF_SATIR.musteri_no%TYPE;
   ln_kredi_teklif_satir_no  CBS_KREDI_TEKLIF_SATIR.teklif_satir_no%TYPE;
   ln_mevcut_limit_tl         NUMBER;
   ln_mevcut_limit_yp        NUMBER;
   ln_mevcut_risk_tl         NUMBER;
   ln_mevcut_risk_yp          NUMBER;
 BEGIN

       SELECT a.doviz_kodu,
               b.musteri_no,
               a.kredi_turu ,
             a.teklif_satir_no
      INTO     ps_doviz_kodu,
              ln_musteri_no ,
            ls_kredi_turu ,
            ln_kredi_teklif_satir_no
      FROM  CBS_KREDI_TEKLIF_SATIR a, CBS_KREDI_TEKLIF b
      WHERE a.teklif_no =         pn_teklif_no AND
              a.teklif_no =b.teklif_no AND
              a.teklif_satir_no = pn_teklif_satir_no;

/* musteri urun limitden mevcut risk al?nir */
       Pkg_Limit.Sp_Musteri_Urun_Limit_Risk_Al(  ln_musteri_no,
                                                   ls_kredi_turu,
                                                 ps_doviz_kodu,
                                                 ln_kredi_teklif_satir_no,
                                                 ln_mevcut_limit_tl,
                                                 ln_mevcut_limit_yp,
                                                  ln_mevcut_risk_tl,
                                                    ln_mevcut_risk_yp);

        pn_bakiye_tl := NVL( ln_mevcut_limit_tl,0) - NVL(ln_mevcut_risk_tl,0);
        pn_bakiye_yp := NVL( ln_mevcut_limit_yp,0) - NVL(ln_mevcut_risk_yp,0);
        pn_risk_tl := NVL(ln_mevcut_risk_tl,0);
        pn_risk_yp := NVL(ln_mevcut_risk_yp,0);
    EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '510' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

 END ;

 /*****************************************************************************************************************/
 /*   Function sf_teklifsatir_bakiyetl                                                             */
 /*****************************************************************************************************************/
 FUNCTION sf_teklifsatir_bakiyetl(    pn_teklif_satir_no NUMBER ) RETURN NUMBER
 IS
    ln_bakiye_tl   NUMBER;
    ln_bakiye_yp   NUMBER;
    ln_risk_tl   NUMBER;
    ln_risk_yp   NUMBER;
    ls_doviz_kodu  CBS_DOVIZ_KODLARI.doviz_kodu%TYPE ;
    ln_teklif_no   NUMBER;
 BEGIN
    IF  NVL(pn_teklif_satir_no,0) <> 0 THEN
         ln_teklif_no := Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(pn_teklif_satir_no);
          Pkg_Kredi.sp_kredi_teklif_satir_bakiyeal(   ln_teklif_no,
                                                      pn_teklif_satir_no,
                                                        ln_bakiye_tl,
                                                     ln_bakiye_yp,
                                                        ls_doviz_kodu,
                                                     ln_risk_tl ,
                                                     ln_risk_yp );
    END IF;

    RETURN ln_bakiye_tl;

 END;
 /*****************************************************************************************************************/
 /*   Function sf_teklifsatir_bakiyeyp                                                             */
 /*****************************************************************************************************************/
 FUNCTION sf_teklifsatir_bakiyeyp(pn_teklif_satir_no NUMBER ) RETURN NUMBER
 IS
    ln_bakiye_tl   NUMBER;
    ln_bakiye_yp   NUMBER;
    ln_risk_tl   NUMBER;
    ln_risk_yp   NUMBER;

    ls_doviz_kodu  CBS_DOVIZ_KODLARI.doviz_kodu%TYPE ;
    ln_teklif_no   NUMBER;
 BEGIN
    IF  NVL(pn_teklif_satir_no,0) <> 0 THEN
         ln_teklif_no := Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(pn_teklif_satir_no);
          Pkg_Kredi.sp_kredi_teklif_satir_bakiyeal(   ln_teklif_no,
                                                      pn_teklif_satir_no,
                                                        ln_bakiye_tl,
                                                     ln_bakiye_yp,
                                                        ls_doviz_kodu,
                                                      ln_risk_tl ,
                                                     ln_risk_yp );
    END IF;

    RETURN ln_bakiye_yp;

 END;

 /*****************************************************************************************************************/
 /*    Function sf_teklifsatir_riskyp                                                         */
 /*****************************************************************************************************************/
  FUNCTION sf_teklifsatir_riskyp(pn_teklif_satir_no NUMBER ) RETURN NUMBER
 IS
    ln_bakiye_tl   NUMBER;
    ln_bakiye_yp   NUMBER;
    ln_risk_tl   NUMBER;
    ln_risk_yp   NUMBER;

    ls_doviz_kodu  CBS_DOVIZ_KODLARI.doviz_kodu%TYPE ;
    ln_teklif_no   NUMBER;
 BEGIN
    IF  NVL(pn_teklif_satir_no,0) <> 0 THEN
         ln_teklif_no := Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(pn_teklif_satir_no);
          Pkg_Kredi.sp_kredi_teklif_satir_bakiyeal(   ln_teklif_no,
                                                      pn_teklif_satir_no,
                                                        ln_bakiye_tl,
                                                     ln_bakiye_yp,
                                                        ls_doviz_kodu,
                                                      ln_risk_tl ,
                                                     ln_risk_yp );
    END IF;

    RETURN ln_risk_yp;

 END;

 /*****************************************************************************************************************/
 /*   Function sf_teklifsatir_risktl                                                             */
 /*****************************************************************************************************************/
 FUNCTION sf_teklifsatir_risktl(    pn_teklif_satir_no NUMBER ) RETURN NUMBER
 IS
    ln_bakiye_tl   NUMBER;
    ln_bakiye_yp   NUMBER;
    ln_risk_tl   NUMBER;
    ln_risk_yp   NUMBER;
    ls_doviz_kodu  CBS_DOVIZ_KODLARI.doviz_kodu%TYPE ;
    ln_teklif_no   NUMBER;
 BEGIN
    IF  NVL(pn_teklif_satir_no,0) <> 0 THEN
         ln_teklif_no := Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(pn_teklif_satir_no);
          Pkg_Kredi.sp_kredi_teklif_satir_bakiyeal(   ln_teklif_no,
                                                      pn_teklif_satir_no,
                                                        ln_bakiye_tl,
                                                     ln_bakiye_yp,
                                                        ls_doviz_kodu,
                                                     ln_risk_tl ,
                                                     ln_risk_yp );
    END IF;

    RETURN ln_risk_tl;

 END;

 /*****************************************************************************************************************/
 /*  Procedure sp_bakiye_kontrol                                                                 */
 /*****************************************************************************************************************/
 PROCEDURE sp_bakiye_kontrol(
                                --pn_teklif_no number,
                                pn_teklif_satir_no NUMBER ,
                               pn_tutar NUMBER,
                               ps_doviz_kodu CBS_DOVIZ_KODLARI.doviz_kodu%TYPE,
                            pn_risk_tl OUT NUMBER,
                            pn_risk_yp OUT NUMBER )
  IS
    ln_teklif_no NUMBER;
    ln_bakiye_tl NUMBER;
    ln_bakiye_yp NUMBER;
    ln_risk_tl   NUMBER;
    ln_risk_yp   NUMBER;
    ln_tl_risk_tutar  NUMBER;
    ln_yp_risk_tutar NUMBER ;
    ls_teklif_doviz_kodu CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
    tl_bakiye_asildi  EXCEPTION;
    yp_bakiye_asildi  EXCEPTION;
  BEGIN
         ln_teklif_no := Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(pn_teklif_satir_no);
         Pkg_Kredi.sp_kredi_teklif_satir_bakiyeal(ln_teklif_no,pn_teklif_satir_no ,ln_bakiye_tl,ln_bakiye_yp,ls_teklif_doviz_kodu ,ln_risk_tl ,ln_risk_yp);
       IF pn_tutar = 0 THEN
              ln_tl_risk_tutar := 0;
           ln_yp_risk_tutar := 0 ;
        ELSE
              ln_tl_risk_tutar :=  NVL(Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,Pkg_Genel.LC_AL,NULL,pn_tutar,1,NULL,NULL,'N','A'),0);
              ln_yp_risk_tutar  := pn_tutar * NVL(Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) /NVL(  Pkg_Kur.doviz_doviz_karsilik(ls_teklif_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) ;
        END IF;
       --sevalb 240407
      /* IF NVL(ln_tl_risk_tutar,0) > NVL(ln_bakiye_tl,0) THEN
             RAISE tl_bakiye_asildi ;
        END IF;
        */

       IF NVL(ln_yp_risk_tutar,0) > NVL(ln_bakiye_yp,0) THEN
                    RAISE yp_bakiye_asildi ;
       END IF;

       pn_risk_tl := NVL( ln_tl_risk_tutar,0);
       pn_risk_yp := NVL( ln_yp_risk_tutar,0);

    EXCEPTION
    WHEN tl_bakiye_asildi THEN
           RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '511' || Pkg_Hata.getDelimiter ||TO_CHAR(ln_bakiye_tl,'FM999G999G999G999G999G999G999G999G999D00') || Pkg_Hata.getDelimiter || TO_CHAR(ln_tl_risk_tutar,'FM999G999G999G999G999G999G999G999G999D00' )|| Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
    WHEN yp_bakiye_asildi THEN
           RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '512' || Pkg_Hata.getDelimiter ||TO_CHAR(ln_bakiye_yp,'FM999G999G999G999G999G999G999G999G999D00') || Pkg_Hata.getDelimiter || TO_CHAR(ln_yp_risk_tutar,'FM999G999G999G999G999G999G999G999G999D00')|| Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '513' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);


  END;

 /*****************************************************************************************************************/
 /*   Procedure sp_teklif_satir_risk_guncelle                                                             */
 /*****************************************************************************************************************/
 /* mevcut kredi teklif satir risk guncellemesi
teklifden yeni giris yapilana kadar korunmasi istendiginden ,guncellenmesi kaldirildi .*/

/*  Procedure sp_teklif_satir_risk_guncelle( pn_islem_no number,ps_islem varchar2 )
  is
   ln_teklif_satir_no number;
   ln_teklif_no number;
   ln_risk_tl  number;
   ln_risk_yp  number;
   ln_tutar    number;
   ls_doviz_kodu cbs_doviz_kodlari.doviz_kodu%type;
   ln_isaret number := 0;

  Begin
         select
        pkg_kredi.SF_SATIRNODAN_TEKLIFNOAL(kredi_teklif_satir_numara) kredi_teklif_no,
        kredi_teklif_satir_numara ,
        tutar,nvl(endeks_doviz_kodu,doviz_kodu)
       into    ln_teklif_no,ln_teklif_satir_no,ln_tutar, ls_doviz_kodu
       from cbs_hesap_kredi_islem
       where tx_no = pn_islem_no ;


     if ps_islem = 'ONAY' then
         ln_isaret := 1;
        pkg_kredi.sp_bakiye_kontrol(
                                         ln_teklif_satir_no,
                                         ln_tutar ,
                                         ls_doviz_kodu,
                                      ln_risk_tl ,
                                      ln_risk_yp);

     else
      --iptal sonrasi cikartilir.
         ln_isaret := -1;
     end if;


            update cbs_kredi_teklif_satir
          set     mevcut_risk_tl = nvl(mevcut_risk_tl,0) +  nvl(ln_risk_tl  * ln_isaret,0),
                mevcut_risk_yp = nvl(mevcut_risk_yp,0) + nvl(ln_isaret* ln_risk_yp ,0)
          where teklif_no        = ln_teklif_no and
                  teklif_satir_no = ln_teklif_satir_no;
      Exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '514' || pkg_hata.getDelimiter ||to_char(SQLCODE) || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

  End;
*/
 /*****************************************************************************************************************/
 /*   Function sf_tahakkuk_dk_tanimlimi                                                         */
 /*****************************************************************************************************************/

 PROCEDURE sf_tahakkuk_dk_tanimlimi(ps_sube_kodu  CBS_HESAP_KREDI.sube_kodu%TYPE,
                                        ps_doviz_kodu  CBS_HESAP_KREDI.doviz_kodu%TYPE,
                                    ps_faiz_dk_numara  OUT CBS_DKHESAP.numara%TYPE,
                                    ps_vergi_dk_numara OUT CBS_DKHESAP.numara%TYPE)

   IS
    ln_ret                NUMBER;
    ln_mevcut            NUMBER := 0;
    faizdk_tanimli_degil     EXCEPTION;
    vergidk_tanimli_degil     EXCEPTION;

   BEGIN
 /* DK hesap mevcut mu */
    IF ps_doviz_kodu = Pkg_Genel.lc_al THEN
            ln_ret :=  Pkg_Parametre.AL ( 'G_DK_FAIZ_TP', ps_faiz_dk_numara );
            ln_ret :=  Pkg_Parametre.AL ( 'G_DK_DIGER_TP', ps_vergi_dk_numara );
    ELSE
            ln_ret :=  Pkg_Parametre.AL ( 'G_DK_FAIZ_YP', ps_faiz_dk_numara );
            ln_ret :=  Pkg_Parametre.AL ( 'G_DK_DIGER_YP', ps_vergi_dk_numara );
    END IF;

    ln_mevcut := 0 ;
    SELECT 1 INTO ln_mevcut
    FROM CBS_DKHESAP
    WHERE bolum_kodu = NVL(ps_sube_kodu,Pkg_Baglam.bolum_kodu) AND
          numara = ps_faiz_dk_numara AND
          doviz_kod = ps_doviz_kodu ;

    IF ln_mevcut  = 0 THEN

       RAISE faizdk_tanimli_degil;
     END IF;
    ln_mevcut := 0 ;
    SELECT 1 INTO ln_mevcut
    FROM CBS_DKHESAP
    WHERE bolum_kodu = NVL(ps_sube_kodu,Pkg_Baglam.bolum_kodu) AND
          numara = ps_vergi_dk_numara AND
          doviz_kod = ps_doviz_kodu ;
    IF ln_mevcut  = 0 THEN
       RAISE vergidk_tanimli_degil;
     END IF;

    EXCEPTION
    WHEN  vergidk_tanimli_degil THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '525' || Pkg_Hata.getDelimiter ||ps_vergi_dk_numara||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

    WHEN  faizdk_tanimli_degil THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '526' || Pkg_Hata.getDelimiter ||ps_faiz_dk_numara||Pkg_Hata.getDelimiter||Pkg_Hata.getUCPOINTER);

    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '527' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

   END;

 /*****************************************************************************************************************/
 /*   Function sf_satirnodan_teklifnoal                                                     */
 /*****************************************************************************************************************/
 FUNCTION sf_satirnodan_teklifnoal(pn_teklif_satir_no NUMBER) RETURN NUMBER
  IS
   ln_teklif_no NUMBER;
  BEGIN
         SELECT a.teklif_no
       INTO ln_teklif_no
       FROM CBS_KREDI_TEKLIF_SATIR b ,CBS_KREDI_TEKLIF a
       WHERE a.teklif_no =b.teklif_no AND
                b.teklif_satir_no = pn_teklif_satir_no AND
                a.durum_kodu = 'A';

     RETURN ln_teklif_No;

  EXCEPTION
  WHEN OTHERS THEN
               SELECT MAX(a.teklif_no)
               INTO ln_teklif_no
               FROM CBS_KREDI_TEKLIF_SATIR b ,CBS_KREDI_TEKLIF a
               WHERE a.teklif_no =b.teklif_no AND
                         b.teklif_satir_no = pn_teklif_satir_no ;

                 RETURN ln_teklif_no;

  END;
 /*****************************************************************************************************************/
 /*   Procedure sp_faizvergi_tahakkukhesap_ac                                                         */
 /*****************************************************************************************************************/

  PROCEDURE sp_faizvergi_tahakkukhesap_ac (pn_islem_no NUMBER)
   IS
    ln_faiz_tahakkuk   CBS_HESAP_KREDI.faiz_tahakkuk_hesap_no%TYPE;
    ln_vergi_tahakkuk  CBS_HESAP_KREDI.vergi_tahakkuk_hesap_no%TYPE;
    ln_hesap_no        CBS_HESAP_KREDI.hesap_no%TYPE;
    ln_guncelle         NUMBER := 0;
    ln_mevcut           NUMBER := 0;

    ls_faiz_numara     CBS_DKHESAP.numara%TYPE;
    ls_vergi_numara    CBS_DKHESAP.numara%TYPE;
    ln_ret                NUMBER;

    CURSOR cursor_hesap IS
             SELECT
                     Pkg_Kredi.modul_tur_kod modul_tur_kod,
                    Pkg_Parametre.deger(Pkg_Kredi.modul_tur_kod,NULL, NULL, 'TAHAKKUK') urun_tur_kod,
                    DECODE(DOVIZ_KODU,Pkg_Genel.lc_al, Pkg_Parametre.deger(Pkg_Kredi.modul_tur_kod,NULL, NULL, 'FAIZ_TP'), Pkg_Parametre.deger(Pkg_Kredi.modul_tur_kod,NULL, NULL, 'FAIZ_YP')) faiz_urun_sinif,
                    DECODE(DOVIZ_KODU,Pkg_Genel.lc_al, Pkg_Parametre.deger(Pkg_Kredi.modul_tur_kod,NULL, NULL, 'DIGER_TP'), Pkg_Parametre.deger(Pkg_Kredi.modul_tur_kod,NULL, NULL, 'DIGER_YP')) vergi_urun_sinif,
                    hesap_no,
                    MUSTERI_NO,
                    DOVIZ_KODU,
                    0  tutar,
                    DURUM_KODU,
                    SUBE_KODU,
                    ILISKILI_HESAP_NO,
                    KREDI_VADE,
                    EXTRE_MASRAFI ,
                    faiz_tahakkuk_hesap_no,
                    vergi_tahakkuk_hesap_no,
                    KREDI_TEKLIF_SATIR_NUMARA
         FROM  CBS_HESAP_KREDI_ISLEM
         WHERE tx_no = pn_islem_no ;


   BEGIN
   FOR cur_hesap IN cursor_hesap LOOP
           Pkg_Kredi.sf_tahakkuk_dk_tanimlimi(cur_hesap.sube_kodu,cur_hesap.doviz_kodu,ls_faiz_numara ,ls_vergi_numara );
      /* faiz tahakkuk hesap */
          Pkg_Kredi.KREDI_HESAP_AC ( cur_hesap.MODUL_TUR_kod,
                                       cur_hesap.URUN_TUR_kod,
                                       cur_hesap.faiz_urun_sinif,
                                       cur_hesap.MUSTERI_NO,
                                       cur_hesap.DOVIZ_kodu,
                                       cur_hesap.SUBE_KODU,
                                       cur_hesap.KREDI_VADE,
                                        NULL, --Referans
                                        ln_faiz_tahakkuk,
                                        ls_faiz_numara,  --musteri_dk_no
                                        0 , --tutar
                                        'E',--    extre_masrafi
                                        cur_hesap.iliskili_hesap_no,
                                        p_kredi_teklif_satir_numara => cur_hesap.KREDI_TEKLIF_SATIR_NUMARA);

      /* vergi tahakkuk hesap */
               Pkg_Kredi.KREDI_HESAP_AC ( cur_hesap.MODUL_TUR_kod,
                                       cur_hesap.URUN_TUR_kod,
                                       cur_hesap.vergi_urun_sinif,
                                       cur_hesap.MUSTERI_NO,
                                       cur_hesap.DOVIZ_kodu,
                                       cur_hesap.SUBE_KODU,
                                       cur_hesap.KREDI_VADE,
                                        NULL, --Referans
                                        ln_vergi_tahakkuk,
                                        ls_vergi_numara,  --musteri_dk_no
                                        0 , --tutar
                                        'E',--    extre_masrafi
                                        cur_hesap.iliskili_hesap_no,
                                        p_kredi_teklif_satir_numara => cur_hesap.KREDI_TEKLIF_SATIR_NUMARA
                                        );


        ln_hesap_no :=cur_hesap.hesap_no;
    END LOOP;

        UPDATE CBS_HESAP_KREDI_ISLEM
        SET faiz_tahakkuk_hesap_no = ln_faiz_tahakkuk,
            vergi_tahakkuk_hesap_no =ln_vergi_tahakkuk
        WHERE  tx_no = pn_islem_no ;

        UPDATE CBS_HESAP_KREDI
        SET faiz_tahakkuk_hesap_no = ln_faiz_tahakkuk,
            vergi_tahakkuk_hesap_no =ln_vergi_tahakkuk
        WHERE hesap_no =ln_hesap_no ;
    --when dk_bulunamadi
    EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '535' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

   END;
 /*****************************************************************************************************************/
 /*     Procedure sp_kredihesap_isleme_at                                                                         */
 /*****************************************************************************************************************/

  PROCEDURE sp_kredihesap_isleme_at (pn_hesap_no          CBS_HESAP_KREDI.hesap_no%TYPE,
                                     pn_tx_no               CBS_HESAP_KREDI_ISLEM.tx_no%TYPE,
                                     pn_islem_tanim_kod CBS_HESAP_KREDI_ISLEM.islem_tanim_kod%TYPE DEFAULT 1303,
                                     pn_tutar            CBS_HESAP_KREDI_ISLEM.tutar%TYPE DEFAULT NULL,
                                     ps_durum_kodu          CBS_HESAP_KREDI_ISLEM.durum_kodu%TYPE DEFAULT NULL,
                                     ps_GERIODEME_KAPAMA_SECIMI    varchar2 DEFAULT NULL,
                                     ps_plan_degisiklik_secimi    VARCHAR2 DEFAULT NULL,
                                     ps_faiz_indirimi             VARCHAR2 DEFAULT NULL) --seval.colak 25052022
   IS
    ln_sira_no number ;
    ld_vade  date;
    BEGIN

               INSERT INTO CBS_HESAP_KREDI_ISLEM(tx_no, hesap_no, musteri_no,
            doviz_kodu,  durum_kodu, sube_kodu, musteri_dk_no, urun_tur_kod,
            urun_sinif_kod, modul_tur_kod, kredi_teklif_satir_numara, kredi_vade,
            kredi_kullandirim_kodu, endeks_doviz_kodu, kullandirim_doviz_kodu,
            son_gun_faizi, acilis_kuru, faiz_orani, faiz_siklik, faiz_siklik_tipi,
            faiz_tahakkuk_tarihi, komisyon_orani, komisyon_tutari,
            komisyon_tahsilat_donemi, fon_orani, bsmv_orani, alacak_hesap_no,
            iliskili_hesap_no,kur_farki, extre_masrafi,
            sinirlama_kodu, kaynak_kodu, urun_grup_no,
            referans, faiz_tahakkuk_hesap_no, vergi_tahakkuk_hesap_no, birikmis_faiz_tutari,
            birikmis_komisyon_tutari, esas_gun_sayisi, acilis_tarihi, kapanis_tarihi,
            bsmv_alinsin, kkdf_alinsin, endeks_doviz_tutari, gecenyil_faiz_tutari,
            tahsiledilen_faiz_tutari, tahsiledilen_komisyon_tutari,
            gecenyil_komisyon_tutari, birikmis_sch_faizi, gecenyil_sch_faizi,son_islem_kuru,
            gecenyil_anaparakurfark_gelir,gecenyil_anaparakurfark_zarar,gecenyil_faizkurfark_gelir,
            gecenyil_faizkurfark_zarar,gecenyil_komiskurfark_gelir,gecenyil_komiskurfark_zarar,
            faiz_baslangic_tarihi,kapamaonce_faizbaslangictarihi,sch_faiz_orani,
            odeme_turu, taksit_sayisi, taksit_once_sonra, artis_siklik, artis_oran, ara_odeme_siklik, ara_odeme_tutar, donem_siklik, kredi_turu,
            islem_tanim_kod,kapamaoncesi_birikmisfaiztutar, kapamaoncesi_birikmiskomstutar,
            sch_faiz_tur,tahakkuk_sch_faiz_tutari,temdit_tarihi,
            birikmis_faiz_tutari_round ,birikmis_komisyon_tutari_round,
            ays_birikmis_faiz_tutari_round, ays_birikmis_komisyon_tutari_r,
            repayment_type, prefix_istatistik_kodu,istatistik_kodu, prefix_istatistik_kodu_faiz, istatistik_kodu_faiz,
            prefix_istatistik_kodu_kapama, istatistik_kodu_kapama,
            tutar,TAHSILEDILEN_FAIZ_TUTARI_LC ,TAHSILEDILEN_KOMIS_TUTARI_LC,
            banka_tarihi,
            GERIODEME_KAPAMA_SECIMI,
            tahsil_hesap_doviz,
            pastdue_faiz_orani,
            yearly_int_rate,
            alacak_secimi ,
            alacak_dk_no,
            CONTRACT_STATUS,
            taksit_baslangic_tarihi,
            ek_taksit_faiz,
            gecmis_aylarin_faizi, gecmis_aylarin_komisyonu,
            plan_degisiklik_secimi,
            REPORT_CUSTOMER_TYPE,
            loan_numara, --cq1417 VictorK
            agreement_date, -- CQ5318 additinal fields KonstantinJ 26052016
           agreement_no,    -- CQ5318 additinal fields KonstantinJ 26052016
            transaction_type, -- CQ5935 ViktorT 22032018
            yearly_effective_int_rate, -- CQ5935 ViktorT 22032018
            -- B-O-M seval.colak 09052021 
            odeme_plan_no   ,
            odeme_gunu      ,
            taksit_siklik   ,
            odemesiz_ay_sayisi ,
            faiz_yontemi_methodu,
            faiz_hesaplama_tipi,
            penalty_rate,
            birikmis_gecikme_faiz_tutari ,
            tahsil_gecikme_faiz_tutari,
            paid_penalty_amount,
            advanced_commission_type    ,
            advanced_commission_rate    ,
            advanced_commission_amount    ,
            gecenyil_gecikme_faiz,
            gecenay_gecikme_faiz,
            gecikme_faiz_accruedtax  ,           
             -- E-O-M seval.colak 09052021
            LLP_RATE,  -- B-O-M SEVAL.COLAK 08122021
            FAIZ_GECIKME_GUN_SAYISI,
            AP_GECIKME_GUN_SAYISI,
            NONACCRUAL_DELAYED_INT_ACCOUNT_NO,
            NONACCRUAL_INT_ACCOUNT_NO,
            ACCRUAL_DELAYED_INT_ACCOUNT_NO,
            ACCRUAL_TAX_ACCOUNT_NO,
            ACCRUAL_INT_ACCOUNT_NO,  -- B-O-M SEVAL.COLAK 08122021  
            kalan_taksit_sayisi  ,    --seval.colak 27012022 3252 degisiklikleri 
            -- B-O-M seval.colak 29032022
            faiz_orani_tipi  ,
            monthly_int_Rate ,
            non_accrual_status,
            non_accrual_status_upd_date,
            -- E-O-M seval.colak 29032022
             penalty_amount ,--seval.colak 25042022
             faiz_indirimi , --seval.colak 25052022
             otomatik_tahsilat,  --seval.colak 15082022
             restructured_eh,  --seval.colak 15082022
             llp_amount  ,       --seval.colak 06092022
             rst_agreement_date,rst_agreement_no ,--seval.colak 13092022
             accrual_status_upd_date -- seval.colak 02112022
            )
        SELECT  pn_tx_no, hesap_no, musteri_no,
            doviz_kodu,  NVL(ps_durum_kodu,durum_kodu), sube_kodu, musteri_dk_no, urun_tur_kod,
            urun_sinif_kod, modul_tur_kod, kredi_teklif_satir_numara, kredi_vade,
            kredi_kullandirim_kodu, endeks_doviz_kodu,
            decode(pn_islem_tanim_kod,1305,null,kullandirim_doviz_kodu),
            son_gun_faizi, acilis_kuru, faiz_orani, faiz_siklik, faiz_siklik_tipi,
            faiz_tahakkuk_tarihi, komisyon_orani, komisyon_tutari,
            komisyon_tahsilat_donemi, fon_orani, bsmv_orani, alacak_hesap_no,
            iliskili_hesap_no,  kur_farki, extre_masrafi,
            sinirlama_kodu, kaynak_kodu,  urun_grup_no,
            referans, faiz_tahakkuk_hesap_no, vergi_tahakkuk_hesap_no, birikmis_faiz_tutari,
            birikmis_komisyon_tutari, esas_gun_sayisi, acilis_tarihi, kapanis_tarihi,
            bsmv_alinsin, kkdf_alinsin, endeks_doviz_tutari, gecenyil_faiz_tutari,
            tahsiledilen_faiz_tutari, tahsiledilen_komisyon_tutari,
            gecenyil_komisyon_tutari, birikmis_sch_faizi, gecenyil_sch_faizi,son_islem_kuru,
            gecenyil_anaparakurfark_gelir,gecenyil_anaparakurfark_zarar,gecenyil_faizkurfark_gelir,
            gecenyil_faizkurfark_zarar,gecenyil_komiskurfark_gelir,gecenyil_komiskurfark_zarar,
            faiz_baslangic_tarihi,faiz_baslangic_tarihi,sch_faiz_orani,
            odeme_turu, taksit_sayisi, taksit_once_sonra, artis_siklik, artis_oran,
            ara_odeme_siklik, ara_odeme_tutar, donem_siklik, kredi_turu,
            pn_islem_tanim_kod ,birikmis_faiz_tutari,birikmis_komisyon_tutari,
            sch_faiz_tur,tahakkuk_sch_faiz_tutari,temdit_tarihi,
            birikmis_faiz_tutari_round ,birikmis_komisyon_tutari_round,
            ays_birikmis_faiz_tutari_round, ays_birikmis_komisyon_tutari_r,
            repayment_type,NULL, NULL,prefix_istatistik_kodu_faiz, istatistik_kodu_faiz,
            prefix_istatistik_kodu_kapama, istatistik_kodu_kapama,DECODE( pn_islem_tanim_kod,1305, NULL,tutar),
            TAHSILEDILEN_FAIZ_TUTARI_LC ,TAHSILEDILEN_KOMIS_TUTARI_LC,
            pkg_muhasebe.banka_tarihi_bul    ,
            ps_GERIODEME_KAPAMA_SECIMI,
            decode(ps_GERIODEME_KAPAMA_SECIMI,null,null,pkg_genel.lc_al),
            pastdue_faiz_orani,yearly_int_rate,
            alacak_secimi ,
            alacak_dk_no,
            contract_status,
            taksit_baslangic_tarihi,
            ek_taksit_faiz,
            gecmis_aylarin_faizi,
            gecmis_aylarin_komisyonu,
            ps_plan_degisiklik_secimi,
            REPORT_CUSTOMER_TYPE,
            loan_numara, --cq 1417 VictorK
           agreement_date, -- CQ5318 additinal fields KonstantinJ 26052016
           agreement_no,    -- CQ5318 additinal fields KonstantinJ 26052016
           transaction_type, -- CQ5935 ViktorT 22032018
           yearly_effective_int_rate, -- CQ5935 ViktorT 22032018
           -- B-O-M seval.colak 09052021 
            odeme_plan_no   ,
            odeme_gunu      ,
            taksit_siklik   ,
            odemesiz_ay_sayisi ,
            faiz_yontemi_methodu,
            faiz_hesaplama_tipi ,
            penalty_rate,
            birikmis_gecikme_faiz_tutari ,
            tahsil_gecikme_faiz_tutari,
            paid_penalty_amount,
            advanced_commission_type    ,
            advanced_commission_rate    ,
            advanced_commission_amount    ,
            gecenyil_gecikme_faiz,
            gecenay_gecikme_faiz,
            gecikme_faiz_accruedtax  , 
              -- E-O-M seval.colak 09052021 
            LLP_RATE,  -- B-O-M SEVAL.COLAK 08122021
            FAIZ_GECIKME_GUN_SAYISI,
            AP_GECIKME_GUN_SAYISI,
            NONACCRUAL_DELAYED_INT_ACCOUNT_NO,
            NONACCRUAL_INT_ACCOUNT_NO,
            ACCRUAL_DELAYED_INT_ACCOUNT_NO,
            ACCRUAL_TAX_ACCOUNT_NO,
            ACCRUAL_INT_ACCOUNT_NO , -- B-O-M SEVAL.COLAK 08122021   
              --b-o-m seval.colak 27012022 3252 ekran degisiklikleri icin eklendi
            case when nvl(taksit_Sayisi,0) <=      ( select count(*)               
                                                      from cbs_hesap_kredi_taksit
                                                      where hesap_no= CBS_HESAP_KREDI.hesap_no and durum_kodu = 'A'  )
                  
            then nvl(taksit_Sayisi,0) else
                                ( select count(*)               
                                                      from cbs_hesap_kredi_taksit
                                                      where hesap_no= CBS_HESAP_KREDI.hesap_no and durum_kodu = 'A'  )
            end  kalan_taksit_sayisi    ,  
          --e-o-m seval.colak 27012022 3252 ekran degisiklikleri icin eklendi    
            -- B-O-M seval.colak 29032022
            faiz_orani_tipi  ,
            monthly_int_Rate,
            non_accrual_status,
            non_accrual_status_upd_date,
            -- E-O-M seval.colak 29032022 ,
            penalty_amount ,--seval.colak 25042022
            ps_faiz_indirimi,  --seval.colak 25052022
            otomatik_tahsilat , --seval.colak 15082022
            restructured_eh , --seval.colak 15082022
             llp_amount   ,      --seval.colak 06092022
             rst_agreement_date,rst_agreement_no, --seval.colak 13092022
              accrual_status_upd_date -- seval.colak 02112022
        FROM CBS_HESAP_KREDI
        WHERE hesap_no = pn_hesap_no  ;


        /*  taksitler isleme atilir.*/
            BEGIN
                 INSERT INTO CBS_HESAP_KREDI_TAKSIT_ISLEM
                 (
                  hesap_no    ,
                  sira_no    ,
                  taksit    ,
                  anapara    ,
                  faiz    ,
                  kkdf    ,
                  bsmv    ,
                  vade_tarih    ,
                  kal_anapara    ,
                  kdv    ,
                  kdvli_taksit    ,
                  tahsil_edilecek_taksit    ,
                  yaratildigi_tarih    ,
                  yaratan_kullanici    ,
                  durum_kodu    ,
                  odeme_tarihi  ,
                  gecikme_faiz_tutari,
                  tx_no ,
                  yaratan_tx_no,
                  -- B-O-M seval.colak 09052021
                  taksit_gun_sayisi,
                  hesaplama_gun_sayisi,
                  taksit_baz_anapara,
                  taksit_faiz_orani,
                  taksit_bsmv_orani,
                  taksit_kkdf_orani,
                  ozel_odeme_tutari,
                  orj_vergi_tutari,
                  orj_faiz_tutari,
                  ek_faiz_tutari,
                  deferred_interest ,
                  deferred_delayed_interest,
                  deferred_tax,
                  paid_deferred_interest,
                  paid_deferred_delayed_interest,
                  paid_deferred_tax,
                  tahsil_taksit,
                  tahsil_anapara,
                  tahsil_faiz,
                  tahsil_kkdf,
                  tahsil_bsmv,
                  tahsil_gecikme_faiz_tutari,
                  deferred_tax2,
                  paid_deferred_tax2,
                  tahakkuk_eh,
                  penalty_amount,
                  paid_penalty_amount,
                  deferred_penalty_amount,
                  paid_deferred_penalty_amount
              -- E-O-M seval.colak 09052021
                ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
                   ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022
                   )
                 SELECT
                  hesap_no    ,
                  sira_no    ,
                   NVL(taksit,ANAPARA),
                  anapara    ,
                  faiz    ,
                  kkdf    ,
                  bsmv    ,
                  vade_tarih    ,
                  kal_anapara    ,
                  kdv    ,
                  kdvli_taksit    ,
                  NVL(tahsil_edilecek_taksit,ANAPARA),
                  yaratildigi_tarih    ,
                  yaratan_kullanici    ,
                  durum_kodu    ,
                  odeme_tarihi  ,
                  gecikme_faiz_tutari,
                  pn_tx_no     ,
                  NVL(yaratan_tx_no, pn_tx_no ),
                  -- B-O-M seval.colak 09052021
                  taksit_gun_sayisi,
                  hesaplama_gun_sayisi,
                  taksit_baz_anapara,
                  taksit_faiz_orani,
                  taksit_bsmv_orani,
                  taksit_kkdf_orani,
                  ozel_odeme_tutari,
                  orj_vergi_tutari,
                  orj_faiz_tutari,
                  ek_faiz_tutari,
                  deferred_interest ,
                  deferred_delayed_interest,
                  deferred_tax,
                  paid_deferred_interest,
                  paid_deferred_delayed_interest,
                  paid_deferred_tax,
                  tahsil_taksit,
                  tahsil_anapara,
                  tahsil_faiz,
                  tahsil_kkdf,
                  tahsil_bsmv,
                  tahsil_gecikme_faiz_tutari,
                  deferred_tax2,
                  paid_deferred_tax2,
                  tahakkuk_eh,
                  penalty_amount,
                  paid_penalty_amount,
                  deferred_penalty_amount,
                  paid_deferred_penalty_amount
              -- E-O-M seval.colak 09052021
               ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
                  ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022
            FROM CBS_HESAP_KREDI_TAKSIT
            WHERE hesap_no = pn_hesap_no ;

             EXCEPTION WHEN OTHERS THEN NULL;
        END ;

        begin
            insert into cbs_hesap_kredi_ozel_tkst_isl
                (tx_no, taksit_sira_no, odeme, yaratildigi_tarih, yaratan_kullanici, hesap_no, yaratan_tx_no
                , taksit_tipi  -- seval.colak 09052021
                 )
              select
             pn_tx_no, taksit_sira_no, odeme, yaratildigi_tarih, yaratan_kullanici, hesap_no, yaratan_tx_no
             , taksit_tipi  -- seval.colak 09052021
             
            from cbs_hesap_kredi_ozel_tkst
            where hesap_no = pn_hesap_no  ;
          exception when others then null;
        end ;

/*****ozel durumlu islemler icin 3251 gibi */
    if ps_GERIODEME_KAPAMA_SECIMI = 'TAKSIT' then
        -- pkg_bireysel_kredi.sf_min_odenmemis_taksiti_bul(pn_hesap_no,pkg_muhasebe.banka_tarihi_bul,ln_sira_no,ld_vade ); --seval.colak 25052022 kapatildi.
              pkg_kredi_tahsilat.sf_min_odenmemis_taksiti_bul(pn_hesap_no,ln_sira_no,ld_vade ); --seval.colak 25052022 eklendi .ileri taksitliler icin de odeme yapilacak
            if nvl(ln_sira_no,0) <> 0 then
             update cbs_hesap_kredi_taksit_islem
             set TAKSIT_SECILDI = 'E'
              where tx_no = pn_tx_no and
                         sira_no =     ln_sira_no and
                    durum_kodu = 'A'    ;
            end if;
    end if;

    IF ps_GERIODEME_KAPAMA_SECIMI = 'ARA' OR ps_plan_degisiklik_secimi = 'TAKSIT TARIHI' THEN
             DELETE FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
              WHERE tx_no = pn_tx_no AND
                         NVL(Durum_kodu,'A') = 'A';
             DELETE FROM CBS_HESAP_KREDI_OZEL_TKST_ISL
              WHERE tx_no = pn_tx_no;

    END IF;

    if ps_GERIODEME_KAPAMA_SECIMI = 'KAPAMA' then
                update cbs_hesap_kredi_taksit_islem
             set TAKSIT_SECILDI = 'E'
              where tx_no = pn_tx_no and
                    durum_kodu = 'A';

    end if;
        BEGIN
              Pkg_Kredi.sp_onayonce_taksit_sakla(pn_tx_no, pn_hesap_no );
        EXCEPTION    WHEN OTHERS THEN NULL;
        END ;
    EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '528' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

   END;

 /*****************************************************************************************************************/
 /*     Procedure sp_kredihesap_bilgisi_al(pn_islem_no number)                                                      */
 /*****************************************************************************************************************/
  PROCEDURE sp_kredihesap_bilgisi_al(
                    pn_hesap_no                     CBS_HESAP_KREDI.hesap_no%TYPE,
                    p_musteri_no                 OUT CBS_HESAP_KREDI.musteri_no%TYPE,
                    p_doviz_kodu                 OUT CBS_HESAP_KREDI.doviz_kodu%TYPE,
                    p_tutar                     OUT CBS_HESAP_KREDI.tutar%TYPE,
                    p_durum_kodu                 OUT CBS_HESAP_KREDI.durum_kodu%TYPE,
                    p_sube_kodu                 OUT CBS_HESAP_KREDI.sube_kodu%TYPE,
                    p_musteri_dk_no             OUT CBS_HESAP_KREDI.musteri_dk_no%TYPE,
                    p_urun_tur_kod                 OUT CBS_HESAP_KREDI.urun_tur_kod%TYPE,
                    p_urun_sinif_kod             OUT CBS_HESAP_KREDI.urun_sinif_kod%TYPE,
                    p_modul_tur_kod                OUT CBS_HESAP_KREDI.modul_tur_kod%TYPE,
                    p_kredi_vade                OUT CBS_HESAP_KREDI.kredi_vade%TYPE,
                    p_endeks_doviz_kodu         OUT CBS_HESAP_KREDI.endeks_doviz_kodu%TYPE,
                    p_son_gun_faizi                OUT CBS_HESAP_KREDI.son_gun_faizi%TYPE,
                    p_faiz_orani                 OUT CBS_HESAP_KREDI.faiz_orani%TYPE,
                    p_faiz_siklik                 OUT CBS_HESAP_KREDI.faiz_siklik%TYPE,
                    p_faiz_siklik_tipi             OUT CBS_HESAP_KREDI.faiz_siklik_tipi%TYPE,
                    p_faiz_tahakkuk_tarihi         OUT CBS_HESAP_KREDI.faiz_tahakkuk_tarihi%TYPE,
                    p_komisyon_orani             OUT CBS_HESAP_KREDI.komisyon_orani%TYPE,
                    p_komisyon_tutari             OUT CBS_HESAP_KREDI.komisyon_tutari%TYPE,
                    p_alacak_hesap_no             OUT CBS_HESAP_KREDI.alacak_hesap_no%TYPE,
                    p_iliskili_hesap_no         OUT CBS_HESAP_KREDI.iliskili_hesap_no%TYPE,
                    p_extre_masrafi             OUT CBS_HESAP_KREDI.extre_masrafi%TYPE,
                    p_sinirlama_kodu             OUT CBS_HESAP_KREDI.sinirlama_kodu%TYPE,
                    p_kaynak_kodu                 OUT CBS_HESAP_KREDI.kaynak_kodu%TYPE,
                    p_birikmis_faiz_tutari         OUT CBS_HESAP_KREDI.birikmis_faiz_tutari%TYPE,
                    p_birikmis_komisyon_tutari    OUT CBS_HESAP_KREDI.birikmis_komisyon_tutari%TYPE,
                    p_faiz_tahakkuk_hesap_no     OUT CBS_HESAP_KREDI.faiz_tahakkuk_hesap_no%TYPE,
                    p_vergi_tahakkuk_hesap_no    OUT CBS_HESAP_KREDI.vergi_tahakkuk_hesap_no%TYPE,
                    p_FON_ORANI                    OUT CBS_HESAP_KREDI.FON_ORANI%TYPE,
                    p_BSMV_ORANI                OUT    CBS_HESAP_KREDI.BSMV_ORANI%TYPE,
                    p_ACILIS_KURU                OUT CBS_HESAP_KREDI.ACILIS_KURU%TYPE,
                    p_KUR_FARKI                    OUT CBS_HESAP_KREDI.KUR_FARKI%TYPE,
                    p_ISTATISTIK_KODU            OUT CBS_HESAP_KREDI.ISTATISTIK_KODU%TYPE,
                    p_KREDI_TEKLIF_NO            OUT CBS_KREDI_TEKLIF.TEKLIF_NO%TYPE,
                    p_KOMISYON_TAHSILAT_DONEMI    OUT CBS_HESAP_KREDI.KOMISYON_TAHSILAT_DONEMI%TYPE,
                    p_KREDI_KULLANDIRIM_KODU    OUT CBS_HESAP_KREDI.KREDI_KULLANDIRIM_KODU%TYPE,
                    p_KULLANDIRIM_DOVIZ_KODU    OUT CBS_HESAP_KREDI.KULLANDIRIM_DOVIZ_KODU%TYPE,
                    p_KREDI_TEKLIF_SATIR_NO        OUT CBS_HESAP_KREDI.KREDI_TEKLIF_SATIR_NUMARA%TYPE
                    )
   IS
  BEGIN
        SELECT
          musteri_no,
          doviz_kodu,
          tutar,
          durum_kodu,
          sube_kodu,
          musteri_dk_no,
          urun_tur_kod,
          urun_sinif_kod,
          modul_tur_kod,
          kredi_vade,
          endeks_doviz_kodu,
          son_gun_faizi,
          faiz_orani,
          faiz_siklik,
          faiz_siklik_tipi,
          faiz_tahakkuk_tarihi,
          komisyon_orani,
          komisyon_tutari,
          alacak_hesap_no,
          iliskili_hesap_no,
          extre_masrafi,
          sinirlama_kodu,
          kaynak_kodu,
          birikmis_faiz_tutari,
          birikmis_komisyon_tutari,
            faiz_tahakkuk_hesap_no,
          vergi_tahakkuk_hesap_no,
          fon_orani,
          bsmv_orani,
          acilis_kuru,
          kur_farki,
          istatistik_kodu,
          Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(kredi_teklif_satir_numara),
          komisyon_tahsilat_donemi,
          kredi_kullandirim_kodu,
          kullandirim_doviz_kodu,
          kredi_teklif_satir_numara
      INTO
          p_musteri_no ,
          p_doviz_kodu,
          p_tutar ,
          p_durum_kodu ,
          p_sube_kodu ,
          p_musteri_dk_no ,
          p_urun_tur_kod ,
          p_urun_sinif_kod,
          p_modul_tur_kod,
          p_kredi_vade,
          p_endeks_doviz_kodu ,
          p_son_gun_faizi,
          p_faiz_orani ,
          p_faiz_siklik ,
          p_faiz_siklik_tipi ,
          p_faiz_tahakkuk_tarihi ,
          p_komisyon_orani ,
          p_komisyon_tutari ,
          p_alacak_hesap_no ,
          p_iliskili_hesap_no,
          p_extre_masrafi ,
          p_sinirlama_kodu ,
          p_kaynak_kodu ,
          p_birikmis_faiz_tutari ,
          p_birikmis_komisyon_tutari,
          p_faiz_tahakkuk_hesap_no ,
          p_vergi_tahakkuk_hesap_no,
            p_fon_orani,
          p_bsmv_orani,
          p_acilis_kuru,
          p_kur_farki,
          p_istatistik_kodu,
          p_kredi_teklif_no,
          p_komisyon_tahsilat_donemi,
          p_kredi_kullandirim_kodu,
          p_kullandirim_doviz_kodu,
          p_kredi_teklif_satir_no
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no ;

      EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '523' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

  END;

 /*****************************************************************************************************************/
 /*     Procedure sp_kredihesap_bilgisi_guncelle(pn_islem_no number)                                                      */
 /*****************************************************************************************************************/

  PROCEDURE sp_kredihesap_bilgisi_guncelle(pn_islem_no NUMBER)
  IS
     ln_hesap_no NUMBER;
     ln_islem_tanim_kod CBS_HESAP_KREDI_ISLEM.islem_Tanim_kod%TYPE;
     ls_plan_degisiklik_secimi    varchar2(100); --seval.colak 13092022 
   
    CURSOR cursor_kredi_islem IS
          SELECT
              hesap_no,
              islem_Tanim_kod,
              plan_degisiklik_secimi
             FROM CBS_HESAP_KREDI_ISLEM
         WHERE  tx_no = pn_islem_no ;

  BEGIN
  FOR cur_islem IN cursor_kredi_islem LOOP
        ln_hesap_no := cur_islem.hesap_no ;
        ln_islem_tanim_kod := cur_islem.islem_Tanim_kod;
        ls_plan_degisiklik_secimi   := cur_islem.plan_degisiklik_secimi; --seval.colak 13092022
      
  END LOOP;
     
  UPDATE  CBS_HESAP_KREDI
  SET (       hesap_no,
              musteri_no,
              doviz_kodu,
            --  tutar, --seval.colak 08082022 accrual modification original tutar degerinin guncellenmesi istenmedi
              durum_kodu,
              sube_kodu,
              musteri_dk_no,
              urun_tur_kod,
              urun_sinif_kod,
              modul_tur_kod,
              kredi_vade,
              endeks_doviz_kodu,
              son_gun_faizi,
              faiz_orani,
              faiz_siklik,
              faiz_siklik_tipi,
              faiz_tahakkuk_tarihi,
              komisyon_orani,
              komisyon_tutari,
              alacak_hesap_no,
              iliskili_hesap_no,
              extre_masrafi,
              sinirlama_kodu,
              kaynak_kodu,
                faiz_tahakkuk_hesap_no,
              vergi_tahakkuk_hesap_no,
              fon_orani,
              bsmv_orani,
              acilis_kuru,
              kur_farki,
              istatistik_kodu,
              komisyon_tahsilat_donemi,
              kredi_kullandirim_kodu,
              kullandirim_doviz_kodu,
              kredi_teklif_satir_numara,
              ESAS_GUN_SAYISI,
              ACILIS_TARIHI,
              KAPANIS_TARIHI,
              kkdf_alinsin,
              bsmv_alinsin,
              endeks_doviz_tutari,
              Birikmis_komisyon_tutari,
              birikmis_faiz_tutari,
              SON_ISLEM_KURU,
              sch_faiz_orani,
              odeme_turu, taksit_sayisi,
              taksit_once_sonra,
              artis_siklik, artis_oran,
              ara_odeme_siklik, ara_odeme_tutar,
              donem_siklik, kredi_turu,
              sch_faiz_tur,
              tahakkuk_sch_faiz_tutari ,
              temdit_tarihi,
              repayment_type,
              prefix_istatistik_kodu,
              prefix_istatistik_kodu_faiz,
              istatistik_kodu_faiz,
              prefix_istatistik_kodu_kapama,
              istatistik_kodu_kapama,
              pastdue_faiz_orani    ,
                yearly_int_rate,
              alacak_secimi ,
              alacak_dk_no,
              contract_status,
              taksit_baslangic_tarihi,
              ek_taksit_faiz,
              REPORT_CUSTOMER_TYPE,
              loan_numara ,--VictorK cq 1417
                Agreement_no,  --CQ5318 Additional fields KonstantinJ 25052016
                 Agreement_Date, --CQ5318 Additional fields KonstantinJ 25052016
              Transaction_type, -- CQ5935 ViktorT 22032018
              Yearly_effective_int_rate ,-- CQ5935 ViktorT 22032018
             -- B-O-M seval.colak 09052021 
            odeme_plan_no   ,
            odeme_gunu      ,
            taksit_siklik   ,
            odemesiz_ay_sayisi ,
            faiz_yontemi_methodu,
            faiz_hesaplama_tipi,
            penalty_rate ,
             -- E-O-M seval.colak 09052021
               LLP_RATE,  -- B-O-M SEVAL.COLAK 08122021
            FAIZ_GECIKME_GUN_SAYISI,
            AP_GECIKME_GUN_SAYISI,
            NONACCRUAL_DELAYED_INT_ACCOUNT_NO,
            NONACCRUAL_INT_ACCOUNT_NO,
            ACCRUAL_DELAYED_INT_ACCOUNT_NO,
            ACCRUAL_TAX_ACCOUNT_NO,
            ACCRUAL_INT_ACCOUNT_NO  -- B-O-M SEVAL.COLAK 08122021  
            -- B-O-M seval.colak 29032022
              ,faiz_orani_tipi  , 
              monthly_int_Rate,
              non_accrual_status,
             non_accrual_status_upd_date,
            -- E-O-M seval.colak 29032022
             paid_penalty_amount,penalty_amount, --seval.colak 25042022  
             birikmis_gecikme_faiz_tutari ,--seval.colak 24062022
              otomatik_tahsilat , --seval.colak 15082022
              restructured_eh , --seval.colak 15082022
              llp_amount,         --seval.colak 06092022
              rst_agreement_no,rst_agreement_date ,--seval.colak 13092022
              accrual_status_upd_date -- seval.colak 02112022
              ) =
 (                   SELECT
                       hesap_no,
                      musteri_no,
                      doviz_kodu,
                     --  tutar, --seval.colak 08082022 accrual modification original tutar degerinin guncellenmesi istenmedi
                      durum_kodu,
                      sube_kodu,
                      musteri_dk_no,
                      urun_tur_kod,
                      urun_sinif_kod,
                      modul_tur_kod,
                      kredi_vade,
                      endeks_doviz_kodu,
                      son_gun_faizi,
                      faiz_orani,
                      faiz_siklik,
                      faiz_siklik_tipi,
                      faiz_tahakkuk_tarihi,
                      komisyon_orani,
                      komisyon_tutari,
                      alacak_hesap_no,
                      iliskili_hesap_no,
                      extre_masrafi,
                      sinirlama_kodu,
                      kaynak_kodu,
                        faiz_tahakkuk_hesap_no,
                      vergi_tahakkuk_hesap_no,
                      fon_orani,
                      bsmv_orani,
                      acilis_kuru,
                      kur_farki,
                      istatistik_kodu,
                      komisyon_tahsilat_donemi,
                      kredi_kullandirim_kodu,
                      kullandirim_doviz_kodu,
                      kredi_teklif_satir_numara,
                      esas_gun_sayisi,
                      acilis_tarihi,
                      kapanis_tarihi,
                      kkdf_alinsin,
                      bsmv_alinsin,
                      endeks_doviz_tutari,
                      birikmis_komisyon_tutari,
                      birikmis_faiz_tutari,
                      son_islem_kuru,
                      sch_faiz_orani ,
                      odeme_turu, taksit_sayisi,
                      taksit_once_sonra,
                      artis_siklik, artis_oran,
                      ara_odeme_siklik, ara_odeme_tutar,
                      donem_siklik, kredi_turu,
                      sch_faiz_tur,
                      tahakkuk_sch_faiz_tutari,
                       temdit_tarihi,
                       repayment_type,
                       prefix_istatistik_kodu,
                       prefix_istatistik_kodu_faiz,
                       istatistik_kodu_faiz,
                       prefix_istatistik_kodu_kapama,
                       istatistik_kodu_kapama,
                       pastdue_faiz_orani,
                          yearly_int_rate,
                       alacak_secimi ,
                      alacak_dk_no,
                      CONTRACT_STATUS,
                      taksit_baslangic_tarihi,
                      ek_taksit_faiz,
                      REPORT_CUSTOMER_TYPE,
                      loan_numara, --VictorK cq 1417
                      Agreement_no ,  --CQ5318 Additional fields KonstantinJ 25052016
                      Agreement_Date,     --CQ5318 Additional fields KonstantinJ 25052016
                     transaction_type,  -- CQ5935 ViktorT 22032018
                     yearly_effective_int_rate, -- CQ5935 ViktorT 22032018
                    -- B-O-M seval.colak 09052021 
                    odeme_plan_no   ,
                    odeme_gunu      ,
                    taksit_siklik   ,
                    odemesiz_ay_sayisi ,
                    faiz_yontemi_methodu,
                    faiz_hesaplama_tipi,
                    penalty_rate,
             -- E-O-M seval.colak 09052021
                    LLP_RATE,  -- B-O-M SEVAL.COLAK 08122021
                    FAIZ_GECIKME_GUN_SAYISI,
                    AP_GECIKME_GUN_SAYISI,
                    NONACCRUAL_DELAYED_INT_ACCOUNT_NO,
                    NONACCRUAL_INT_ACCOUNT_NO,
                    ACCRUAL_DELAYED_INT_ACCOUNT_NO,
                    ACCRUAL_TAX_ACCOUNT_NO,
                    ACCRUAL_INT_ACCOUNT_NO  -- B-O-M SEVAL.COLAK 08122021  
                    -- B-O-M seval.colak 29032022
                      ,faiz_orani_tipi  , 
                      monthly_int_Rate ,
                      non_accrual_status,
                       non_accrual_status_upd_date,
                    -- E-O-M seval.colak 29032022  
                    paid_penalty_amount,penalty_amount, --seval.colak 25042022
                    birikmis_gecikme_faiz_tutari ,--seval.colak 24062022
                    otomatik_tahsilat , --seval.colak 15082022
                    restructured_eh , --seval.colak 15082022
                    llp_amount  ,       --seval.colak 06092022
                    rst_agreement_no,rst_agreement_date, --seval.colak 13092022
                     accrual_status_upd_date -- seval.colak 02112022
                     FROM CBS_HESAP_KREDI_ISLEM
                     WHERE  tx_no = pn_islem_no )
        WHERE hesap_no = ln_hesap_no ;


       BEGIN
           DELETE  FROM CBS_HESAP_KREDI_TAKSIT
          WHERE hesap_no = ln_hesap_no ;

          INSERT INTO CBS_HESAP_KREDI_TAKSIT(yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
          --b-o-m seval.colak 28092021
            taksit_gun_sayisi    ,
            hesaplama_gun_sayisi    ,
            taksit_baz_anapara    ,
            taksit_faiz_orani    ,
            taksit_bsmv_orani    ,
            taksit_kkdf_orani    ,
            ozel_odeme_tutari    ,
            orj_vergi_tutari    ,
            orj_faiz_tutari    ,
            ek_faiz_tutari    ,
            deferred_interest    ,
            deferred_delayed_interest,
            deferred_tax    ,
            paid_deferred_interest    ,
            paid_deferred_delayed_interest,
            paid_deferred_tax    ,
            tahsil_taksit    ,
            tahsil_anapara    ,
            tahsil_faiz    ,
            tahsil_kkdf    ,
            tahsil_bsmv    ,
            tahsil_gecikme_faiz_tutari    ,
            deferred_tax2    ,
            paid_deferred_tax2    ,
            tahakkuk_eh    ,
            penalty_amount    ,
            paid_penalty_amount    ,
            deferred_penalty_amount    ,
            paid_deferred_penalty_amount   
             --e-o-m seval.colak 28092021 
             ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
              ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022
          )
          SELECT  pn_islem_no,ln_hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
              --b-o-m seval.colak 28092021
            taksit_gun_sayisi    ,
            hesaplama_gun_sayisi    ,
            taksit_baz_anapara    ,
            taksit_faiz_orani    ,
            taksit_bsmv_orani    ,
            taksit_kkdf_orani    ,
            ozel_odeme_tutari    ,
            orj_vergi_tutari    ,
            orj_faiz_tutari    ,
            ek_faiz_tutari    ,
            deferred_interest    ,
            deferred_delayed_interest,
            deferred_tax    ,
            paid_deferred_interest    ,
            paid_deferred_delayed_interest,
            paid_deferred_tax    ,
            tahsil_taksit    ,
            tahsil_anapara    ,
            tahsil_faiz    ,
            tahsil_kkdf    ,
            tahsil_bsmv    ,
            tahsil_gecikme_faiz_tutari    ,
            deferred_tax2    ,
            paid_deferred_tax2    ,
            tahakkuk_eh    ,
            penalty_amount    ,
            paid_penalty_amount    ,
            deferred_penalty_amount    ,
            paid_deferred_penalty_amount   
             --e-o-m seval.colak 28092021  
             ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
              ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022
          FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
             WHERE tx_no = pn_islem_no;
         EXCEPTION WHEN OTHERS THEN NULL;
     END;

    EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '524' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;

  /*****************************************************************************************************************/
 /*     Procedure sp_kredi_hesap_durum_guncelle                                                 */
 /*****************************************************************************************************************/
       PROCEDURE sp_kredi_hesap_durum_guncelle( pn_hesap_no CBS_HESAP.hesap_no%TYPE,ps_durum_kodu VARCHAR2)
      IS
     BEGIN
            UPDATE CBS_HESAP_KREDI
            SET durum_kodu = ps_durum_kodu ,
                kapanis_tarihi =  DECODE(ps_durum_kodu,'K',Pkg_Muhasebe.banka_Tarihi_bul,NULL)
            WHERE hesap_no =pn_hesap_no;

     EXCEPTION
         WHEN NO_DATA_FOUND THEN
           RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '536' || Pkg_Hata.getdelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer);
         WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '537' || Pkg_Hata.getdelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer);
 END;

 /*****************************************************************************************************************/
 /*     Procedure sp_hesap_krediteklifno_guncel                                             */
 /*****************************************************************************************************************/
/* procedure sp_hesap_krediteklifno_guncel( pn_eski_teklif_no         cbs_hesap_kredi.kredi_teklif_no%type,
                                              pn_yeni_teklif_no         cbs_hesap_kredi.kredi_teklif_no%type)
 is
 begin

         update cbs_hesap_kredi
         set    kredi_teklif_no   = pn_yeni_teklif_no
         where    kredi_teklif_no =pn_eski_teklif_no;

         update cbs_hesap_kredi_islem
         set    kredi_teklif_no  = pn_yeni_teklif_no
         where    kredi_teklif_no =pn_eski_teklif_no;

Exception
  when no_data_found then null;
  WHEN OTHERS
      THEN
         raise_application_error (-20100, pkg_hata.getucpointer || '571' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

 end;
*/
 /*****************************************************************************************************************/
 /*     Procedure sp_kredteklifdurumu_uygunmu                                             */
 /*****************************************************************************************************************/
  PROCEDURE sp_kredteklifdurumu_uygunmu(pn_islem_no NUMBER )
  IS
   ln_kredi_teklif_no          CBS_KREDI_TEKLIF.teklif_no%TYPE;
   ls_durum                      CBS_KREDI_TEKLIF.durum_kodu%TYPE;
   teklif_durumu_uygun_degil  EXCEPTION;
  BEGIN

      SELECT Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(kredi_teklif_satir_numara)
    INTO   ln_kredi_teklif_no
    FROM   CBS_HESAP_KREDI_ISLEM
    WHERE  tx_no = pn_islem_no ;

    ls_durum := Pkg_Kredi.sf_teklif_durumu_al(ln_kredi_teklif_no);

    IF   ls_durum <> 'A' THEN
        RAISE teklif_durumu_uygun_degil;
   END IF;

 EXCEPTION

  WHEN  OTHERS THEN
         RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getucpointer || '567' || Pkg_Hata.getdelimiter|| TO_CHAR (ln_kredi_teklif_no)|| Pkg_Hata.getdelimiter||ls_durum|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer    );

 END;
 /*****************************************************************************************************************/
 /*      Function Sf_Bitmemis_HesapIslm_VarMi                                         */
 /*****************************************************************************************************************/
 FUNCTION Sf_Bitmemis_HesapIslm_VarMi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                           pn_islem_no CBS_ISLEM.numara%TYPE,
                                        pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) RETURN NUMBER
 IS

    ln_tx_no   CBS_ISLEM.numara%TYPE  := 0;
    onayda_bekleyen_islem_var          EXCEPTION;
  BEGIN
       SELECT  MAX(tx_no)
       INTO    ln_tx_no
       FROM   CBS_HESAP_KREDI_ISLEM a , CBS_ISLEM b
       WHERE  a.musteri_no = NVL(pn_musteri_no,a.musteri_no) AND
                 a.tx_no = b.numara AND
              a.tx_no <> pn_islem_no AND
              hesap_no = pn_hesap_No AND
              Pkg_Tx.ISLEM_BITMIS_MI(b.numara)= 0 ;

       IF  NVL(ln_tx_no,0) <> 0 THEN
              RAISE     onayda_bekleyen_islem_var;
       END IF;

       RETURN ln_tx_no ;

    EXCEPTION
      WHEN OTHERS THEN
               RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '456' ||Pkg_Hata.getdelimiter|| ln_tx_no  || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
    END;
  /*****************************************************************************************************************/
  /*   Function    Sf_KrediHesap_UrunUygunmu                                                                    */
  /*   Sf_KrediHesap_UrunUygunmu                                                                        */
  /****************************************************************************************************************/
  FUNCTION Sf_KrediHesap_UrunUygunmu( ps_urun_tur_kod CBS_HESAP_KREDI.urun_tur_kod%TYPE ) RETURN VARCHAR2
  IS
     ls_uygun  VARCHAR2(1) := 'H';
  BEGIN
       IF  (ps_urun_tur_kod IN ('PLACEMENT', 'CRD.CARD','DEMAND DEP','OVERDRAFT','RT-CARD','ISSUED GR.','L/G','LOAN GIVEN','MEDIATION' ,'DEPO' ,'ACCRUAL','NONACCRUAL') ) --'PAST DUE','LEASING', sevalb 280507 -- seval.colak 09102021 ACCRUAL added ,-- seval.colak 23112021 NONACCRUAL added 
          OR  (Pkg_Bireysel_Kredi.Sf_BireyselUrunUygunmu (ps_urun_tur_kod) = 'E' )    OR substr(ps_urun_tur_kod,1,2) in ('PD','RT')
           
        THEN
             ls_uygun := 'H';
        ELSE
            ls_uygun := 'E';
        END IF;

       RETURN ls_uygun ;

    EXCEPTION
      WHEN OTHERS THEN RETURN 'H';
  END ;
  /*****************************************************************************************************************/
  /*   Procedure Sf_Kredi_Kapama_FaizKomis_Bul                                                                         */
  /****************************************************************************************************************/

 PROCEDURE Sp_Kredi_Kapama_FaizKomis_Bul( pn_hesap_no CBS_HESAP_KREDI_ISLEM.hesap_no%TYPE ,
                                              pn_faiz_tutari OUT NUMBER ,
                                          pn_komisyon_tutari OUT NUMBER,
                                          pd_faiz_tarihi DATE )
  IS
       ln_faiz_orani NUMBER ;
     ln_komisyon_orani  NUMBER;
     ln_esas_gun_sayisi NUMBER;
     ln_gun_sayisi       NUMBER;
     ln_bakiye            NUMBER;
     ls_doviz_kodu       CBS_HESAP_KREDI.doviz_kodu%TYPE;
   BEGIN
        SELECT NVL(faiz_orani,0),
               NVL(komisyon_orani,0),
               NVL(esas_gun_sayisi,0),
               NVL(ABS(bakiye),0),
               doviz_kodu
        INTO   ln_faiz_orani,
               ln_komisyon_orani,
               ln_esas_gun_sayisi,
               ln_bakiye ,
               ls_doviz_kodu
        FROM CBS_HESAP_KREDI  a,CBS_HESAP_BAKIYE b
        WHERE a.hesap_no =pn_hesap_no  AND
              a.hesap_no = b.hesap_no;

    IF pd_faiz_tarihi IS NOT NULL  THEN
         ln_gun_sayisi := TRUNC(pd_faiz_tarihi) -  TRUNC(Pkg_Muhasebe.banka_tarihi_bul);

         IF NVL(ln_faiz_orani,0) <> 0 AND  ln_gun_sayisi <> 0 AND ln_esas_gun_sayisi <> 0 THEN
                pn_faiz_tutari :=Pkg_Kur.yuvarla(ls_doviz_kodu, NVL((ln_bakiye * ln_faiz_orani  *ln_gun_sayisi )/ (ln_esas_gun_sayisi * 100) ,0));
          ELSE
                pn_faiz_tutari := 0;
         END IF;

            IF NVL(ln_komisyon_orani,0) <> 0 AND  ln_gun_sayisi <> 0 AND ln_esas_gun_sayisi <> 0 THEN
                  pn_komisyon_tutari :=  Pkg_Kur.yuvarla(ls_doviz_kodu,NVL(( ln_bakiye  * ln_komisyon_orani * ln_gun_sayisi )/ (ln_esas_gun_sayisi *100 ),0));
          ELSE
                pn_komisyon_tutari := 0;
         END IF;
    ELSE
          pn_faiz_tutari := 0;
          pn_komisyon_tutari := 0;
    END IF;


 EXCEPTION
  WHEN OTHERS
      THEN
         RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getucpointer || '588' || Pkg_Hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer    );

  END ;

  /*****************************************************************************************************************/
  /*  Procedure sf_kkdf_hesapla                                                                     */
  /****************************************************************************************************************/
 PROCEDURE sp_kkdf_faiz_tutar_hesapla(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
                                             pn_tutar NUMBER,
                                        pn_kur NUMBER DEFAULT 0,
                                      pn_kkdf_kredidoviz_tutar OUT NUMBER,
                                      pn_kkdf_tl_tutar OUT NUMBER,
                                      pn_faiz_tl_tutar OUT NUMBER )
  IS
  CURSOR cursor_hesap IS
      SELECT modul_tur_kod,
               urun_tur_kod,
             urun_sinif_kod,
             doviz_kodu,
             kkdf_alinsin
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;
      ln_kkdf_orani NUMBER := 0;
      ln_kur NUMBER ;
  BEGIN
   ln_kur := pn_kur;

      FOR cur_hesap IN cursor_hesap LOOP
        IF   cur_hesap.kkdf_alinsin = 'E' THEN
             ln_kkdf_orani :=Pkg_Parametre.NUMBER_AL(cur_hesap.MODUL_TUR_KOD,
                                                     cur_hesap.URUN_TUR_KOD,
                                                     cur_hesap.URUN_SINIF_KOD,
                                                     'KREDI_KKDF_ORANI' );
               IF NVL(ln_kur,0) = 0 THEN
                   ln_kur :=NVL(Pkg_Kur.doviz_doviz_karsilik(cur_hesap.doviz_kodu ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),0);
               END IF;

               IF NVL(pn_tutar,0) <> 0 AND ln_kkdf_orani <> 0 THEN
                pn_faiz_tl_tutar := Pkg_Kur.yuvarla( Pkg_Genel.lc_al,(ln_kur * pn_tutar));
                 pn_kkdf_tl_tutar := Pkg_Kur.yuvarla( Pkg_Genel.lc_al,(ln_kkdf_orani * pn_faiz_tl_tutar ) / 100);
                pn_kkdf_kredidoviz_tutar :=  Pkg_Kur.yuvarla( cur_hesap.doviz_kodu,pn_kkdf_tl_tutar/ln_kur );
              ELSE
                pn_faiz_tl_tutar := pn_tutar;
                pn_kkdf_kredidoviz_tutar := 0;
                 pn_kkdf_tl_tutar := 0;
            END IF;
        ELSE
            pn_faiz_tl_tutar := pn_tutar;
            pn_kkdf_kredidoviz_tutar := 0;
             pn_kkdf_tl_tutar := 0;
        END IF;

      END LOOP;
  END;


  /*****************************************************************************************************************/
  /*  Function sf_kkdf_hesapla
  /* kapama ekran? i?in haz?rlanm??t?r.                                                         */
  /****************************************************************************************************************/
 FUNCTION sf_kkdf_hesapla(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
                              pn_tutar NUMBER ,
                          pn_kur NUMBER DEFAULT 0,ps_kredidoviz_tutarli VARCHAR2 DEFAULT NULL) RETURN NUMBER
 IS
    ln_kkdf_kredidoviz_tutar NUMBER;
    ln_kkdf_tl_tutar  NUMBER;
    ln_faiz_tl_tutar  NUMBER ;

  BEGIN
             Pkg_Kredi.sp_kkdf_faiz_tutar_hesapla(pn_hesap_no,pn_tutar,pn_kur,
                                      ln_kkdf_kredidoviz_tutar,
                                      ln_kkdf_tl_tutar,
                                      ln_faiz_tl_tutar);
        IF ps_kredidoviz_tutarli IS NULL THEN
                RETURN ln_kkdf_kredidoviz_tutar;
        ELSE
                RETURN Pkg_Kur.yuvarla( Pkg_Genel.lc_al,ln_kkdf_tl_tutar);
        END IF;


  END;


  /*****************************************************************************************************************/
  /*  Procedure sp_bsmv_faiz_tutar_hesapla                                                                 */
  /****************************************************************************************************************/
 PROCEDURE sp_bsmv_faiz_tutar_hesapla(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
                                             pn_tutar NUMBER,
                                      pn_kur NUMBER DEFAULT 0 ,
                                      pn_bsmv_kredidoviz_tutar OUT NUMBER,
                                      pn_bsmv_tl_tutar OUT NUMBER,
                                      pn_faiz_tl_tutar OUT NUMBER )
  IS
  CURSOR cursor_hesap IS
      SELECT modul_tur_kod,
               urun_tur_kod,
             urun_sinif_kod,
             doviz_kodu,
             bsmv_alinsin
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;
      ln_bsmv_orani NUMBER := 0;
      ln_kur  NUMBER ;
  BEGIN

   ln_kur := pn_kur;
    FOR cur_hesap IN cursor_hesap LOOP

        IF   cur_hesap.bsmv_alinsin = 'E' THEN
                   Pkg_Parametre.DEGER ( 'G_BSMV_ORANI',ln_bsmv_orani  );

               IF NVL(ln_kur,0) = 0 THEN
                   ln_kur :=NVL(Pkg_Kur.doviz_doviz_karsilik(cur_hesap.doviz_kodu ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),0);
               END IF;

               IF NVL(pn_tutar,0) <> 0 AND ln_bsmv_orani <> 0 THEN
                pn_faiz_tl_tutar :=   Pkg_Kur.yuvarla( Pkg_Genel.lc_al, ln_kur * pn_tutar);
                 pn_bsmv_tl_tutar :=    Pkg_Kur.yuvarla( Pkg_Genel.lc_al,(ln_bsmv_orani * pn_faiz_tl_tutar ) / 100);
                pn_bsmv_kredidoviz_tutar := Pkg_Kur.yuvarla( cur_hesap.doviz_kodu,pn_bsmv_tl_tutar/ln_kur );
              ELSE
                pn_faiz_tl_tutar := pn_tutar;
                pn_bsmv_kredidoviz_tutar := 0;
                 pn_bsmv_tl_tutar := 0;
            END IF;
        ELSE
            pn_faiz_tl_tutar := pn_tutar;
            pn_bsmv_kredidoviz_tutar := 0;
             pn_bsmv_tl_tutar := 0;
        END IF;

      END LOOP;
  END;

  /*****************************************************************************************************************/
  /*  Function sf_bsmv_hesapla                                                                 */
  /* kapama ekran? i?in haz?rland?
  /****************************************************************************************************************/
 FUNCTION sf_bsmv_hesapla(pn_hesap_no NUMBER,pn_tutar NUMBER , pn_kur NUMBER DEFAULT 0,ps_kredidoviz_tutarli VARCHAR2 DEFAULT NULL) RETURN NUMBER
 IS
    ln_bsmv_kredidoviz_tutar NUMBER;
    ln_bsmv_tl_tutar  NUMBER;
    ln_faiz_tl_tutar  NUMBER ;

  BEGIN
             Pkg_Kredi.sp_bsmv_faiz_tutar_hesapla(pn_hesap_no,pn_tutar,pn_kur,
                                      ln_bsmv_kredidoviz_tutar,
                                      ln_bsmv_tl_tutar,
                                      ln_faiz_tl_tutar);

        IF ps_kredidoviz_tutarli IS NULL THEN
                RETURN ln_bsmv_kredidoviz_tutar;
        ELSE
                RETURN Pkg_Kur.yuvarla( Pkg_Genel.lc_al,ln_bsmv_tl_tutar);
        END IF;


  END;

 /*****************************************************************************************************************/
 /*  Function sf_bsmv_hesapla                                                                 */
 /* dovize endeksli kredi kapama
 /****************************************************************************************************************/
  FUNCTION sf_kkdfbsmv_hesapla(
                               ps_secim VARCHAR2 DEFAULT 'KKDF',
                          ps_doviz_kodu VARCHAR2,
                          pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
                              pn_tutar NUMBER,
                          pn_kur NUMBER ,
                          ps_bol VARCHAR2 DEFAULT 'E',
                          ps_kkdf_alinsin VARCHAR2 DEFAULT 'E',
                          ps_bsmv_alinsin VARCHAR2 DEFAULT 'E'
                           ) RETURN NUMBER
 IS
  CURSOR cursor_hesap IS
      SELECT modul_tur_kod,
               urun_tur_kod,
             urun_sinif_kod,
             doviz_kodu
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;

      ln_kkdf_orani NUMBER := 0;
       ln_sonuc         NUMBER := 0;
      ln_kur        NUMBER := 0;
      ln_bsmv_orani    NUMBER := 0;
  BEGIN

   IF ps_secim IS NOT NULL THEN
      IF NVL(pn_kur,0 ) = 0 THEN
            ln_kur := Pkg_Kur.doviz_doviz_karsilik(    ps_doviz_kodu ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A');
      ELSE
            ln_kur := pn_kur;
      END IF;

        FOR cur_hesap IN cursor_hesap LOOP
           IF ps_secim = 'KKDF' THEN
                IF   NVL(ps_kkdf_alinsin,'E') = 'E' THEN
                     ln_kkdf_orani :=Pkg_Parametre.NUMBER_AL(cur_hesap.MODUL_TUR_KOD,
                                                             cur_hesap.URUN_TUR_KOD,
                                                             cur_hesap.URUN_SINIF_KOD,
                                                             'KREDI_KKDF_ORANI' );

                     IF NVL(ps_bol,'E') = 'E' THEN
                            ln_sonuc:=Pkg_Kur.yuvarla( ps_doviz_kodu,((pn_tutar / ln_kur ) * ln_kkdf_orani) /100);
                     ELSE
                          ln_sonuc:=  Pkg_Kur.yuvarla( ps_doviz_kodu,((pn_tutar * ln_kur ) * ln_kkdf_orani) / 100);
                     END IF;

                ELSE
                    ln_sonuc :=  0;
                END IF ;
           ELSE
                IF   NVL(ps_BSMV_alinsin,'E') = 'E' THEN
                        Pkg_Parametre.DEGER ( 'G_BSMV_ORANI',ln_bsmv_orani  );
                    IF NVL(ps_bol,'E') = 'E' THEN
                            ln_sonuc:=Pkg_Kur.yuvarla( ps_doviz_kodu,((pn_tutar / ln_kur ) * ln_bsmv_orani) /100);
                    ELSE
                          ln_sonuc:= Pkg_Kur.yuvarla( ps_doviz_kodu,((pn_tutar * ln_kur ) * ln_bsmv_orani) /100);
                    END IF;
                 ELSE
                      ln_sonuc := 0;
                END IF;
            END IF;
         END LOOP;
   END IF;
    RETURN ln_sonuc;
    EXCEPTION WHEN OTHERS THEN RETURN  0;
  END;


   /*****************************************************************************************************************/
  /*  Function Sf_TahsilHesap_UrunUygunmu                                                     */
  /****************************************************************************************************************/
 FUNCTION Sf_TahsilHesap_UrunUygunmu(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE ) RETURN VARCHAR2
     IS
     ln_adet NUMBER;
    BEGIN

          SELECT  1
       INTO    ln_adet
       FROM    CBS_HESAP
       WHERE  hesap_no =pn_hesap_no and
                 urun_tur_kod IN ( 'CURRENT','DEMAND DEP', 'TRANSIT') and ---- CQ5507 BAHIANAB 29042016 ADDED NEW PRODUCT TYPE "TRANSIT"
                 pkg_Atm_transaction.Hesap_Card_hesap_mi(hesap_no)  = 'H'
                 and nvl(BADLIST_FLAG,'H') = 'H';  --seval.colak 06092022 loan modifications.
                 
        IF NVL(ln_adet,0) <> 0 THEN
           RETURN 'E';
        ELSE
           RETURN 'H';
        END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 'H';
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '484' || Pkg_Hata.getUCPOINTER);
    END ;

 /*****************************************************************************************************************/
 /*  Function sf_Bakiye_Al                                                             */
 /****************************************************************************************************************/
FUNCTION sf_Bakiye_Al(pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE ) RETURN CBS_HESAP_BAKIYE.bakiye%TYPE
   IS
     ln_bakiye CBS_HESAP_BAKIYE.bakiye%TYPE;
   BEGIN

      SELECT NVL(bakiye,0)
      INTO  ln_bakiye
      FROM  CBS_HESAP_BAKIYE
      WHERE hesap_no = pn_hesap_no;

    RETURN NVL(ln_bakiye,0);

    EXCEPTION
     WHEN NO_DATA_FOUND THEN RETURN 0 ;
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '593' ||Pkg_Hata.getdelimiter || TO_CHAR(pn_hesap_no) || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' ||SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END sf_Bakiye_Al;

  /******************************************************************************************************************/
  /*   Function sf_kredi_referans_musterino_al                                                                               */
  /*   kredi referans nosu g?nderilip musteri numaras? al?n?r                                                        */
  /******************************************************************************************************************/
   FUNCTION  sf_krediteklifno_musterinoal(pn_teklif_no CBS_KREDI_TEKLIF_ISLEM.teklif_no%TYPE) RETURN CBS_MUSTERI.musteri_no%TYPE
   IS
    ln_musteri_no  CBS_MUSTERI.musteri_no%TYPE;
   BEGIN

        SELECT musteri_no
        INTO  ln_musteri_no
        FROM  CBS_KREDI_TEKLIF
        WHERE teklif_no = pn_teklif_no;

    RETURN ln_musteri_no;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN NULL;
        WHEN  OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '478' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;

  /******************************************************************************************************************/
  /*   Function sf_kredi_musterinoal                                                                       */
  /******************************************************************************************************************/
    FUNCTION sf_kredi_musterinoal(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE) RETURN CBS_HESAP_KREDI.musteri_no%TYPE
     IS
    ln_musteri_no  CBS_MUSTERI.musteri_no%TYPE;
   BEGIN

        SELECT musteri_no
        INTO  ln_musteri_no
        FROM  CBS_HESAP_KREDI
        WHERE hesap_no = pn_hesap_no ;

    RETURN ln_musteri_no;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN NULL;
        WHEN  OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '478' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;

 /******************************************************************************************************************/
 /*   Function sf_islemhesapno_al                                                                   */
 /******************************************************************************************************************/
 FUNCTION sf_islemhesapno_al(pn_tx_no NUMBER) RETURN CBS_HESAP.hesap_no%TYPE
 IS
   ln_hesap_No CBS_HESAP.hesap_no%TYPE ;
 BEGIN
         SELECT hesap_numara
       INTO ln_hesap_no
       FROM CBS_ISLEM
       WHERE numara =pn_tx_no;

     RETURN ln_hesap_no;

 END;
 /******************************************************************************************************************/
 /*  procedure sp_hesapbilgi_al                                                           */
 /******************************************************************************************************************/
 PROCEDURE sp_hesapbilgi_al(pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE,
                                ps_modul_tur_kod  OUT CBS_HESAP_KREDI.modul_tur_kod%TYPE,
                                ps_urun_tur_kod   OUT CBS_HESAP_KREDI.urun_tur_kod%TYPE,
                                ps_urun_sinif_kod OUT CBS_HESAP_KREDI.urun_sinif_kod%TYPE,
                                pn_musteri_no       OUT CBS_HESAP_KREDI.musteri_no%TYPE,
                            ps_hesap_sube       OUT CBS_HESAP_KREDI.sube_kodu%TYPE,
                            ps_hesap_doviz       OUT CBS_HESAP_KREDI.doviz_kodu%TYPE,
                            pn_kredi_teklif_satir_no OUT CBS_HESAP_KREDI.kredi_teklif_satir_numara%TYPE,
                            pn_kredi_teklif_no          OUT CBS_KREDI_TEKLIF.teklif_no%TYPE )
 IS
 BEGIN
       SELECT modul_tur_kod,
              urun_tur_kod,
             urun_sinif_kod,
             musteri_no,
             sube_kodu,
             doviz_kodu,
             kredi_teklif_satir_numara,
             Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(kredi_teklif_satir_numara) kredi_teklif_no
      INTO
              ps_modul_tur_kod,
              ps_urun_tur_kod,
            ps_urun_sinif_kod,
            pn_musteri_no,
            ps_hesap_sube,
            ps_hesap_doviz,
            pn_kredi_teklif_satir_no,
            pn_kredi_teklif_no
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;

 END;

 /******************************************************************************************************************/
 /*   Function sf_musteriden_teklifnoal                                                       */
 /******************************************************************************************************************/
 FUNCTION sf_musteriden_teklifnoal(pn_musteri_no NUMBER) RETURN NUMBER
 IS
  ln_teklif_no NUMBER;
 BEGIN
       SELECT teklif_no
      INTO ln_teklif_no
      FROM CBS_KREDI_TEKLIF
      WHERE durum_kodu = 'A' AND
              musteri_No = pn_musteri_no    ;

    RETURN ln_teklif_no ;
 EXCEPTION
     WHEN   NO_DATA_FOUND THEN
               SELECT MAX(teklif_no)
                INTO ln_teklif_no
              FROM CBS_KREDI_TEKLIF
              WHERE durum_kodu = 'K' AND
                      musteri_No = pn_musteri_no    ;
       RETURN ln_teklif_no;
  END;

 /******************************************************************************************************************/
 /*     Function sf_tutarkuryuvarla                                                   */
 /******************************************************************************************************************/
  FUNCTION sf_tutarkuryuvarla(pn_tutar NUMBER, ps_doviz VARCHAR2) RETURN NUMBER
  IS
  BEGIN
         IF ps_doviz IS NOT NULL THEN
              RETURN  Pkg_Kur.yuvarla(ps_doviz ,pn_tutar);
        ELSE
         RETURN  0;
        END IF;
  END;

  PROCEDURE sp_faizkom_dk_tanimlimi(pn_islem_no NUMBER) IS
   ls_kredi_hesap_doviz_kodu               CBS_HESAP_KREDI.doviz_kodu%TYPE;
   iliskili_faiz_dk_yok                    EXCEPTION;
   iliskili_kom_dk_yok                       EXCEPTION;
   iliskili_komrees_dk_yok                 EXCEPTION;
   iliskili_faizrees_dk_yok                 EXCEPTION;
   faizdovizyok                             EXCEPTION;
   ln_faiz_orani                         NUMBER;
   ln_komisyon_orani                     NUMBER;
   ls_dk_grup_kod            CBS_MUSTERI.DK_GRUP_KOD%TYPE;
   ls_modul_tur_kod            CBS_HESAP.modul_tur_kod%TYPE;
   ls_urun_tur_kod            CBS_HESAP.urun_tur_kod%TYPE;
   ls_urun_sinif_kod        CBS_HESAP.urun_sinif_kod%TYPE;
   ls_komreesdk              VARCHAR2(2000);
   ls_faizreesdk              VARCHAR2(2000);
   ls_komdk                  VARCHAR2(2000);
   ls_faizdk                  VARCHAR2(2000);
   ls_hesap_no                CBS_HESAP_KREDI.hesap_no%TYPE;
   ls_bolum_kodu            CBS_HESAP_KREDI.sube_kodu%TYPE;
   ls_var                    VARCHAR2(1) := NULL;
   ls_dk                    VARCHAR2(2000);
   ls_doviz                    CBS_HESAP_KREDI.doviz_kodu%TYPE;
   ln_birikmiskom_arteksitutar    NUMBER;
   ln_birikmisfaiz_arteksitutar NUMBER;
   ln_gusin_no number;      --seval.colak 12042022
   delay_dk_yok exception;  --seval.colak 12042022
  BEGIN
   SELECT doviz_kodu,
          faiz_orani,
          komisyon_orani,
          Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no),
          modul_tur_kod,
           urun_tur_kod,
          urun_sinif_kod,
          TO_CHAR(hesap_no),
          sube_kodu,
          birikmiskom_arteksitutar,
          birikmisfaiz_arteksitutar
   INTO   ls_kredi_hesap_doviz_kodu,
          ln_faiz_orani,
          ln_komisyon_orani,
          ls_dk_grup_kod,
          ls_modul_tur_kod,
           ls_urun_tur_kod,
          ls_urun_sinif_kod,
          ls_hesap_no ,
          ls_bolum_kodu,
          ln_birikmiskom_arteksitutar,
          ln_birikmisfaiz_arteksitutar
   FROM CBS_HESAP_KREDI_ISLEM
   WHERE tx_no = pn_islem_no;
IF NVL(ln_faiz_orani,0) <> 0 OR NVL(ln_birikmisfaiz_arteksitutar,0) <> 0 THEN
    /*faiz gelir dk */
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 2,
                        NULL,NULL, NULL,ls_faizdk);
      IF ls_faizdk IS NULL THEN
           RAISE iliskili_faiz_dk_yok;
      END IF;
/*faiz reeskont dk */
 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 4,
                        NULL,NULL, NULL,ls_faizreesdk);
      IF     ls_faizreesdk IS NULL  THEN
              RAISE iliskili_faizrees_dk_yok;
      END IF;
/*faizrees*/
       ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_faizreesdk,ls_kredi_hesap_doviz_kodu);
     IF ls_var <> 'E' THEN
         ls_dk := ls_faizreesdk;
        ls_doviz:= ls_kredi_hesap_doviz_kodu;
        RAISE faizdovizyok;
     END IF;
/*faiz tl */
     ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_faizdk,Pkg_Genel.lc_al);
     IF ls_var <> 'E' THEN
         ls_dk := ls_faizdk;
        ls_doviz:= Pkg_Genel.lc_al;
       RAISE faizdovizyok;
     END IF;
 END IF;

 IF NVL(ln_komisyon_orani,0) <>0  OR NVL(ln_birikmiskom_arteksitutar,0) <> 0 THEN
/*komisyon dk */
 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 5,
                        NULL,NULL, NULL,ls_komdk);
      IF ls_komdk IS NULL THEN
              RAISE iliskili_kom_dk_yok;
      END IF;
/*komisyon reeskont dk */
 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 6,
                        NULL,NULL, NULL,ls_komreesdk);
      IF     ls_komreesdk IS NULL   THEN
              RAISE iliskili_komrees_dk_yok;
      END IF;
/*komrees*/
       ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_komreesdk,ls_kredi_hesap_doviz_kodu);
     IF ls_var <> 'E' THEN
         ls_dk := ls_komreesdk;
        ls_doviz:= ls_kredi_hesap_doviz_kodu;
        RAISE faizdovizyok;
     END IF;
/*komis tl */
     ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_komdk,Pkg_Genel.lc_al);
     IF ls_var <> 'E' THEN
         ls_dk := ls_komdk;
        ls_doviz:= Pkg_Genel.lc_al;
       RAISE faizdovizyok;
     END IF;
END IF;


-- b-o-m seval.colak 12042022 accrual modifications 
/* 10 -delay int income */
    ln_gusin_no := 10;
    ls_dk := null;
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, ln_gusin_no,
                        NULL,NULL, NULL,ls_dk);
      IF     ls_dk IS NULL   THEN
              RAISE delay_dk_yok;
      END IF;

       ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_dk,Pkg_Genel.lc_al);
     IF ls_var <> 'E' THEN
        -- ls_dk := ls_komreesdk;
        ls_doviz:= Pkg_Genel.lc_al;
        RAISE faizdovizyok;
     END IF;

-- Delay Int Accrual
    ln_gusin_no := 11; 
    ls_dk := null;
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, ln_gusin_no,
                        NULL,NULL, NULL,ls_dk);
      IF     ls_dk IS NULL   THEN
              RAISE delay_dk_yok;
      END IF;

       ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_dk,ls_kredi_hesap_doviz_kodu);
     IF ls_var <> 'E' THEN
        -- ls_dk := ls_komreesdk;
        ls_doviz:= ls_kredi_hesap_doviz_kodu;
        RAISE faizdovizyok;
     END IF;  

-- Penalty Income
    ln_gusin_no := 12;
    ls_dk := null;
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, ln_gusin_no,
                        NULL,NULL, NULL,ls_dk);
      IF     ls_dk IS NULL   THEN
              RAISE delay_dk_yok;
      END IF;

       ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_dk,Pkg_Genel.lc_al);
     IF ls_var <> 'E' THEN
        -- ls_dk := ls_komreesdk;
        ls_doviz:= Pkg_Genel.lc_al;
        RAISE faizdovizyok;
     END IF;       
   -- e-o-m seval.colak 12042022  
     

 EXCEPTION
   WHEN iliskili_faiz_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '700' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN iliskili_faizrees_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '701' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN iliskili_kom_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '702' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN iliskili_komrees_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '703' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN faizdovizyok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '704' || Pkg_Hata.getdelimiter || ls_dk||  Pkg_Hata.getdelimiter || ls_bolum_kodu|| Pkg_Hata.getdelimiter ||ls_doviz|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN delay_dk_yok THEN --seval.colak 12042022
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '6868' || Pkg_Hata.getdelimiter || ln_gusin_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN others THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '704' || Pkg_Hata.getdelimiter || ls_dk||  Pkg_Hata.getdelimiter || ls_bolum_kodu|| Pkg_Hata.getdelimiter ||ls_doviz|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
    
 END;

 /******************************************************************************************************************/
 /*     Function sf_endeks_doviz_kodu_al                                                   */
 /******************************************************************************************************************/
FUNCTION sf_endeks_doviz_kodu_al(pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE) RETURN VARCHAR2
 IS
  ls_endeks CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
 BEGIN
       SELECT endeks_doviz_kodu
      INTO ls_endeks
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;

     RETURN ls_endeks;
    EXCEPTION
    WHEN OTHERS THEN RETURN NULL;
 END;
 /******************************************************************************************************************/
 /*     Function sf_endeks_doviz_bakiye_al                                                   */
 /******************************************************************************************************************/
 FUNCTION sf_endeks_doviz_bakiye_al(pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE) RETURN NUMBER
 IS
  ln_tutar NUMBER;
 BEGIN
       SELECT endeks_doviz_tutari
      INTO ln_tutar
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;

     RETURN ln_tutar;
    EXCEPTION
    WHEN OTHERS THEN RETURN NULL;
 END;

  /*****************************************************************************************************************/
  /*    Function sf_teklif_durumu_al                                                                         */
  /****************************************************************************************************************/
 FUNCTION sf_kredi_hesap_durumu_al(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE ) RETURN  VARCHAR2
  IS
     ls_durum CBS_KREDI_TEKLIF.durum_kodu%TYPE;
  BEGIN

        SELECT durum_kodu
      INTO ls_durum
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;

      RETURN ls_durum ;

    EXCEPTION
      WHEN OTHERS THEN RETURN NULL;
  END ;

  /*****************************************************************************************************************/
  /*  function sf_kredi_faiztahak_tarih                                                                             */
  /****************************************************************************************************************/
 FUNCTION sf_kredi_faiztahak_tarih(ps_modul_tur_kod VARCHAR2, ps_urun_tur_kod VARCHAR2,ps_urun_sinif_kod VARCHAR2) RETURN VARCHAR2
 IS
  ls_uygun VARCHAR2(1):= 'E';
 BEGIN
        /*if ps_urun_sinif_kod in  ('ROTATIF-LC','ROTATIF-FC' ) then
             ls_uygun  := 'H';
        else
           ls_uygun  := 'E';
       end if;
       */
      RETURN ls_uygun;
 END ;

 FUNCTION sf_kredikapamaistatkod_uygunmu(ps_doviz_kodu CBS_DOVIZ_KODLARI.doviz_kodu%TYPE, ps_istatistik_kodu CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2
  IS
  ls_sonuc VARCHAR2(1) := 'H';
  BEGIN
   /*
   if ps_doviz_kodu is not null then
         if ps_doviz_kodu = pkg_genel.lc_al then
            if ps_istatistik_kodu     in('1062','1063', '1262','3319','T0305','T0306' ) then
                return 'E';
            else
                return 'H';
            end if;
         else
            if  (ps_istatistik_kodu between '3300' and '3320' )  or
            ps_istatistik_kodu in( 'T0201','T0202') then
                return 'E';
            else
                return 'H';
            end if;
         end if;
    else
        return 'H';
    end if;
     */
      RETURN 'E';
  EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 'H';
  END ;

 FUNCTION sf_vade_tarih_al(pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE) RETURN DATE
  IS
     ld_vade  CBS_HESAP_KREDI.kredi_vade%TYPE;
  BEGIN

        SELECT kredi_vade
      INTO ld_vade
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;

      RETURN ld_vade ;
  END ;

  PROCEDURE sp_vade_tarihi_guncelle(pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE ,pd_kredi_vade  CBS_HESAP_KREDI.kredi_vade%TYPE )
  IS
     ld_vade  CBS_HESAP_KREDI.kredi_vade%TYPE;
  BEGIN

        UPDATE CBS_HESAP_KREDI
      SET kredi_Vade = pd_kredi_vade
      WHERE hesap_no = pn_hesap_no;
  END ;

 FUNCTION sf_hesap_taksit_maxno_al(pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) RETURN NUMBER
 IS
   ln_sira NUMBER;
  BEGIN

        SELECT MAX(sira_no)
      INTO ln_sira
      FROM CBS_HESAP_KREDI_TAKSIT
      WHERE hesap_no = pn_hesap_no;       

    RETURN NVL(ln_sira,0);
    EXCEPTION WHEN OTHERS THEN RETURN 0;
 END;

  PROCEDURE sp_taksit_sira_guncelle(pn_islem_no NUMBER)
 IS
   ln_odeme_plan_no number ;-- seval.colak 09052021
 
   CURSOR cur_taksit IS
     SELECT sira_no
     FROM  CBS_HESAP_KREDI_TAKSIT_ISLEM
     WHERE tx_no = pn_islem_no
     ORDER BY vade_tarih
     FOR UPDATE OF sira_no;

     i NUMBER := 0;
     ln_adet  NUMBER ;
     ln_hesap_no number;
     ln_hsp_tkst_adet   number :=0;
  BEGIN
   -- B-O-M seval.colak 09052021     
    select odeme_plan_no ,hesap_no
    into   ln_odeme_plan_no  ,ln_hesap_no
    from   CBS_HESAP_KREDI_ISLEM
    WHERE tx_no = pn_islem_no  ;
    -- E-O-M seval.colak 09052021
    --b-o-m  seval.colak 02112022
    SELECT COUNT(*)
    INTO ln_hsp_tkst_adet
    FROM CBS_HESAP_KREDI_TAKSIT
    WHERE hesap_no = ln_hesap_no;        
    --e-o-m  seval.colak 02112022
  IF nvl(ln_odeme_plan_no,0) = 0 or nvl(ln_hsp_tkst_adet,0) <> 0 then -- seval.colak 02112022
        SELECT COUNT(*)
        INTO ln_adet
        FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
        WHERE tx_no = pn_islem_no;

        IF NVL(ln_adet,0) <> 0 THEN
            -- sirano unique oldugundan once farkli numaraya set edilir.
           UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
           SET sira_no = sira_no + 10000
           WHERE tx_no = pn_islem_no;
        END IF;

        FOR c_taksit IN cur_taksit LOOP
           i:= i + 1;
           -- seval.colak 02112022
           UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
           SET sira_no = i
           WHERE CURRENT OF cur_taksit;                   
        END LOOP;
        
    END IF;

  END;

PROCEDURE sp_taksit_vade_tutar_kontrol(pn_islem_no NUMBER ,pn_tutar  NUMBER DEFAULT NULL)
 IS
   ln_kredi_teklif_satir_numara             NUMBER;
   ln_kredi_hesap_tutar                   NUMBER;
   ls_kredi_hesap_doviz_kodu               CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
   ln_faiz_orani                         NUMBER;
   ln_komisyon_orani                     NUMBER;
   ls_dk_grup_kod                         CBS_MUSTERI.DK_GRUP_KOD%TYPE;
   ls_modul_tur_kod                         CBS_HESAP.modul_tur_kod%TYPE;
   ls_urun_tur_kod                         CBS_HESAP.urun_tur_kod%TYPE;
   ls_urun_sinif_kod                     CBS_HESAP.urun_sinif_kod%TYPE;
   ls_komreesdk                           VARCHAR2(2000);
   ls_faizreesdk                           VARCHAR2(2000);
   ls_hesap_no                             CBS_HESAP_KREDI.hesap_no%TYPE;
   ls_endeks_doviz_kodu                     CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
   ld_taksit_vade                         DATE;
   ld_kredi_vade                         DATE;
   ln_tutar                                 NUMBER;
   ln_toplam                             NUMBER;
   ls_repayment_type                     VARCHAR2(2000);
   taksit_tarihi_ayni                     EXCEPTION;
   taksit_tarihi_vadedenbuyuk             EXCEPTION;
   taksit_toplam_farkli                      EXCEPTION;

   CURSOR cur_taksit_vade IS
       SELECT vade_tarih
       FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no
               AND nvl(durum_kodu,'A')  = 'A'
       GROUP BY vade_tarih
       HAVING COUNT(*) > 1
       ORDER BY vade_tarih ;

   CURSOR cur_kredi_vade IS
       SELECT SIRA_NO,vade_tarih
       FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no AND
                vade_tarih > ld_kredi_vade AND
             nvl(durum_kodu,'A')  = 'A'
       ORDER BY SIRA_NO;

    CURSOR cur_taksit_toplam IS
       SELECT SUM(NVL(anapara,0) -nvl(tahsil_anapara,0)) toplam --seval.colak 19082022  minus tahsil_anapara added
       FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no    AND
                NVL(durum_kodu,'A') = 'A' ;      
           --  and vade_tarih >= Pkg_Muhasebe.banka_tarihi_bul;  --seval.colak 31012022 testlerde hataya yol acti
  BEGIN

   SELECT kredi_teklif_satir_numara,
             tutar,
          doviz_kodu,
          faiz_orani,
          komisyon_orani,
          Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no),
          modul_tur_kod,
           urun_tur_kod,
          urun_sinif_kod,
          endeks_doviz_kodu,
          kredi_vade,
          NVL(tutar,0),
          repayment_type
   INTO   ln_kredi_teklif_satir_numara,
             ln_kredi_hesap_tutar,
          ls_kredi_hesap_doviz_kodu,
          ln_faiz_orani,
          ln_komisyon_orani,
          ls_dk_grup_kod,
          ls_modul_tur_kod,
           ls_urun_tur_kod,
          ls_urun_sinif_kod,
          ls_endeks_doviz_kodu,
          ld_kredi_vade,
          ln_tutar,
          ls_repayment_type
   FROM CBS_HESAP_KREDI_ISLEM
   WHERE tx_no = pn_islem_no;

   Pkg_Kredi.sp_kredteklifdurumu_uygunmu(pn_islem_no);

   Pkg_Teminat.sp_teminat_kontrolsonra(pn_islem_no ,
               ln_kredi_teklif_satir_numara ,
             ln_kredi_hesap_tutar,
             ls_kredi_hesap_doviz_kodu ,
             ls_endeks_doviz_kodu );

 --  pkg_tx1303.sp_tahakkuk_dk_tanimlimi(pn_islem_no );
   Pkg_Kredi.sp_faizkom_dk_tanimlimi(pn_islem_no);

    FOR c_taksit_toplam IN cur_taksit_toplam
   LOOP
          ln_toplam := c_taksit_toplam.toplam;
   END LOOP;

   IF NVL(ln_toplam,0) <> NVL(NVL(pn_tutar,ln_tutar),0) AND ls_repayment_type = 'INSTALLMENT DATE' THEN
     RAISE taksit_toplam_farkli;
   END IF;

   FOR  c_taksit_vade IN cur_taksit_vade
   LOOP
          ld_taksit_vade := c_taksit_vade.vade_tarih;
   END LOOP;

    IF ld_taksit_vade IS NOT NULL THEN
      RAISE taksit_tarihi_ayni;
    END IF;

   FOR  c_kredi_vade IN cur_kredi_vade
   LOOP
          ld_taksit_vade := c_kredi_vade.vade_tarih;
   END LOOP;

    IF ld_taksit_vade IS NOT NULL THEN
      RAISE taksit_tarihi_vadedenbuyuk;
    END IF;


 EXCEPTION
   WHEN   taksit_tarihi_ayni THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '972' ||  Pkg_Hata.getdelimiter ||TO_CHAR( ld_taksit_vade,'DD/MM/YYYY') || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN   taksit_tarihi_vadedenbuyuk THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '971' || Pkg_Hata.getdelimiter ||TO_CHAR(ld_kredi_vade,'DD/MM/YYYY') || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN   taksit_toplam_farkli THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '973' ||  Pkg_Hata.getdelimiter  || TO_CHAR( NVL(NVL(pn_tutar,ln_tutar),0) ,'FM999G999G999G999G999G999G999G999G999D00')|| Pkg_Hata.getdelimiter  ||Pkg_Hata.getucpointer);
 END;

  PROCEDURE sp_onayonce_taksit_sakla(    pn_tx_no               CBS_HESAP_KREDI_ISLEM.tx_no%TYPE,
                                           pn_hesap_no          CBS_HESAP_KREDI.hesap_no%TYPE) IS
   ln_Adet  number := 0;
   /* Bireysel krediler ile birlikte hesap kredininde onay oncesi loglandi.*/
    Begin
       
       select count(*) 
       into ln_Adet 
       from CBS_HESAP_KREDI_ONAYONCE_ISL 
       where TX_NO= pn_tx_no  ;
       if   nvl(ln_Adet,0)   = 0 then 
        Begin
            INSERT INTO CBS_HESAP_KREDI_ONAYONCE_ISL( TX_NO, HESAP_NO, MUSTERI_NO, DOVIZ_KODU, TUTAR, DURUM_KODU, SUBE_KODU, MUSTERI_DK_NO, URUN_TUR_KOD, URUN_SINIF_KOD, MODUL_TUR_KOD, KREDI_TEKLIF_SATIR_NUMARA, KREDI_VADE, KREDI_KULLANDIRIM_KODU, ENDEKS_DOVIZ_KODU, KULLANDIRIM_DOVIZ_KODU, SON_GUN_FAIZI, ACILIS_KURU, FAIZ_ORANI, FAIZ_SIKLIK, FAIZ_SIKLIK_TIPI, FAIZ_TAHAKKUK_TARIHI, KOMISYON_ORANI, KOMISYON_TUTARI, KOMISYON_TAHSILAT_DONEMI, FON_ORANI, BSMV_ORANI, ALACAK_HESAP_NO, ILISKILI_HESAP_NO, KUR_FARKI, EXTRE_MASRAFI, SINIRLAMA_KODU, KAYNAK_KODU, ISTATISTIK_KODU, URUN_GRUP_NO, REFERANS, FAIZ_TAHAKKUK_HESAP_NO, VERGI_TAHAKKUK_HESAP_NO, BIRIKMIS_FAIZ_TUTARI, BIRIKMIS_KOMISYON_TUTARI, ESAS_GUN_SAYISI, ACILIS_TARIHI, KAPANIS_TARIHI, BSMV_ALINSIN, KKDF_ALINSIN, ENDEKS_DOVIZ_TUTARI, GECENYIL_FAIZ_TUTARI, TAHSILEDILEN_FAIZ_TUTARI, TAHSILEDILEN_KOMISYON_TUTARI, GECENYIL_KOMISYON_TUTARI, BIRIKMIS_SCH_FAIZI, GECENYIL_SCH_FAIZI, SON_ISLEM_KURU, GECENYIL_ANAPARAKURFARK_GELIR, GECENYIL_ANAPARAKURFARK_ZARAR, GECENYIL_FAIZKURFARK_GELIR, GECENYIL_FAIZKURFARK_ZARAR, GECENYIL_KOMISKURFARK_GELIR, GECENYIL_KOMISKURFARK_ZARAR, FAIZ_BASLANGIC_TARIHI, SCH_FAIZ_ORANI, ESKI_HESAP_NO, ESKI_HESAP_EKNO, ESKI_FAIZHESAP_EKNO, ESKI_KOMHESAP_EKNO, BIRIKMIS_FAIZ_TUTARI_ROUND, BIRIKMIS_KOMISYON_TUTARI_ROUND, AYS_BIRIKMIS_FAIZ_TUTARI_ROUND, AYS_BIRIKMIS_KOMISYON_TUTARI_R, KREDI_TURU, TAKSIT_SAYISI, TAKSIT_ONCE_SONRA, ARTIS_SIKLIK, ARTIS_ORAN, ARA_ODEME_SIKLIK, ARA_ODEME_TUTAR, DONEM_SIKLIK, ODEME_TURU, SCH_FAIZ_TUR, TEMDIT_TARIHI, TAHAKKUK_SCH_FAIZ_TUTARI, REPAYMENT_TYPE, PREFIX_ISTATISTIK_KODU, PREFIX_ISTATISTIK_KODU_FAIZ, ISTATISTIK_KODU_FAIZ, PREFIX_ISTATISTIK_KODU_KAPAMA, ISTATISTIK_KODU_KAPAMA, TAHSILEDILEN_FAIZ_TUTARI_LC, TAHSILEDILEN_KOMIS_TUTARI_LC, ANA_KREDI_HESAP_NO, PASTDUE_FAIZ_ANAPARA_SEC,TAKSIT_BASLANGIC_TARIHI, EK_TAKSIT_FAIZ, GECMIS_AYLARIN_FAIZI, GECMIS_AYLARIN_KOMISYONU,CONTRACT_STATUS,
            report_customer_type,accrued_interest_tax,accrued_commission_tax,app_no,loan_numara,agreement_date,agreement_no,transaction_type,yearly_effective_int_rate,penalty_amount,odeme_plan_no,odeme_gunu,taksit_siklik,odemesiz_ay_sayisi,faiz_yontemi_methodu,faiz_hesaplama_tipi ,penalty_rate,
             BIRIKMIS_GECIKME_FAIZ_TUTARI, TAHSIL_GECIKME_FAIZ_TUTARI,PAID_PENALTY_AMOUNT,ADVANCED_COMMISSION_TYPE,ADVANCED_COMMISSION_RATE,ADVANCED_COMMISSION_AMOUNT,GECENYIL_GECIKME_FAIZ,GECIKME_FAIZ_ACCRUEDTAX,
            LLP_RATE,  -- B-O-M SEVAL.COLAK 08122021
            FAIZ_GECIKME_GUN_SAYISI,
            AP_GECIKME_GUN_SAYISI,
            NONACCRUAL_DELAYED_INT_ACCOUNT_NO,
            NONACCRUAL_INT_ACCOUNT_NO,
            ACCRUAL_DELAYED_INT_ACCOUNT_NO,
            ACCRUAL_TAX_ACCOUNT_NO,
            ACCRUAL_INT_ACCOUNT_NO  -- B-O-M SEVAL.COLAK 08122021
            -- B-O-M seval.colak 29032022
              ,faiz_orani_tipi  , 
              monthly_int_Rate,
              non_accrual_status,
             non_accrual_status_upd_date,
            -- E-O-M seval.colak 29032022   
             otomatik_tahsilat , --seval.colak 15082022    
             restructured_eh , --seval.colak 15082022    
              llp_amount ,        --seval.colak 06092022   
               rst_agreement_date,rst_agreement_no, --seval.colak 13092022  
                accrual_status_upd_date -- seval.colak 02112022
             ) --seval.colak 09052021
            SELECT  PN_TX_NO,HESAP_NO, MUSTERI_NO, DOVIZ_KODU, TUTAR, DURUM_KODU, SUBE_KODU, MUSTERI_DK_NO, URUN_TUR_KOD, URUN_SINIF_KOD, MODUL_TUR_KOD, KREDI_TEKLIF_SATIR_NUMARA, KREDI_VADE, KREDI_KULLANDIRIM_KODU, ENDEKS_DOVIZ_KODU, KULLANDIRIM_DOVIZ_KODU, SON_GUN_FAIZI, ACILIS_KURU, FAIZ_ORANI, FAIZ_SIKLIK, FAIZ_SIKLIK_TIPI, FAIZ_TAHAKKUK_TARIHI, KOMISYON_ORANI, KOMISYON_TUTARI, KOMISYON_TAHSILAT_DONEMI, FON_ORANI, BSMV_ORANI, ALACAK_HESAP_NO, ILISKILI_HESAP_NO, KUR_FARKI, EXTRE_MASRAFI, SINIRLAMA_KODU, KAYNAK_KODU, ISTATISTIK_KODU, URUN_GRUP_NO, REFERANS, FAIZ_TAHAKKUK_HESAP_NO, VERGI_TAHAKKUK_HESAP_NO, BIRIKMIS_FAIZ_TUTARI, BIRIKMIS_KOMISYON_TUTARI, ESAS_GUN_SAYISI, ACILIS_TARIHI, KAPANIS_TARIHI, BSMV_ALINSIN, KKDF_ALINSIN, ENDEKS_DOVIZ_TUTARI, GECENYIL_FAIZ_TUTARI, TAHSILEDILEN_FAIZ_TUTARI, TAHSILEDILEN_KOMISYON_TUTARI, GECENYIL_KOMISYON_TUTARI, BIRIKMIS_SCH_FAIZI, GECENYIL_SCH_FAIZI, SON_ISLEM_KURU, GECENYIL_ANAPARAKURFARK_GELIR, GECENYIL_ANAPARAKURFARK_ZARAR, GECENYIL_FAIZKURFARK_GELIR, GECENYIL_FAIZKURFARK_ZARAR, GECENYIL_KOMISKURFARK_GELIR, GECENYIL_KOMISKURFARK_ZARAR, FAIZ_BASLANGIC_TARIHI, SCH_FAIZ_ORANI, ESKI_HESAP_NO, ESKI_HESAP_EKNO, ESKI_FAIZHESAP_EKNO, ESKI_KOMHESAP_EKNO, BIRIKMIS_FAIZ_TUTARI_ROUND, BIRIKMIS_KOMISYON_TUTARI_ROUND, AYS_BIRIKMIS_FAIZ_TUTARI_ROUND, AYS_BIRIKMIS_KOMISYON_TUTARI_R, KREDI_TURU, TAKSIT_SAYISI, TAKSIT_ONCE_SONRA, ARTIS_SIKLIK, ARTIS_ORAN, ARA_ODEME_SIKLIK, ARA_ODEME_TUTAR, DONEM_SIKLIK, ODEME_TURU, SCH_FAIZ_TUR, TEMDIT_TARIHI, TAHAKKUK_SCH_FAIZ_TUTARI, REPAYMENT_TYPE, PREFIX_ISTATISTIK_KODU, PREFIX_ISTATISTIK_KODU_FAIZ, ISTATISTIK_KODU_FAIZ, PREFIX_ISTATISTIK_KODU_KAPAMA, ISTATISTIK_KODU_KAPAMA, TAHSILEDILEN_FAIZ_TUTARI_LC, TAHSILEDILEN_KOMIS_TUTARI_LC, ANA_KREDI_HESAP_NO, PASTDUE_FAIZ_ANAPARA_SEC,TAKSIT_BASLANGIC_TARIHI, EK_TAKSIT_FAIZ, GECMIS_AYLARIN_FAIZI, GECMIS_AYLARIN_KOMISYONU,CONTRACT_STATUS,
            report_customer_type,accrued_interest_tax,accrued_commission_tax,app_no,loan_numara,agreement_date,agreement_no,transaction_type,yearly_effective_int_rate,penalty_amount,odeme_plan_no,odeme_gunu,taksit_siklik,odemesiz_ay_sayisi,faiz_yontemi_methodu,faiz_hesaplama_tipi,penalty_rate,   --seval.colak 09052021
            BIRIKMIS_GECIKME_FAIZ_TUTARI, TAHSIL_GECIKME_FAIZ_TUTARI,PAID_PENALTY_AMOUNT,ADVANCED_COMMISSION_TYPE,ADVANCED_COMMISSION_RATE,ADVANCED_COMMISSION_AMOUNT,GECENYIL_GECIKME_FAIZ,GECIKME_FAIZ_ACCRUEDTAX,
            LLP_RATE,  -- B-O-M SEVAL.COLAK 08122021
            FAIZ_GECIKME_GUN_SAYISI,
            AP_GECIKME_GUN_SAYISI,
            NONACCRUAL_DELAYED_INT_ACCOUNT_NO,
            NONACCRUAL_INT_ACCOUNT_NO,
            ACCRUAL_DELAYED_INT_ACCOUNT_NO,
            ACCRUAL_TAX_ACCOUNT_NO,
            ACCRUAL_INT_ACCOUNT_NO  -- B-O-M SEVAL.COLAK 08122021   
            -- B-O-M seval.colak 29032022
              ,faiz_orani_tipi  , 
              monthly_int_Rate ,
              non_accrual_status,
              non_accrual_status_upd_date,
            -- E-O-M seval.colak 13042022   
             otomatik_tahsilat , --seval.colak 15082022  
             restructured_eh , --seval.colak 15082022     
              llp_amount   ,      --seval.colak 06092022  
              rst_agreement_date,rst_agreement_no ,--seval.colak 13092022
               accrual_status_upd_date -- seval.colak 02112022
            FROM CBS_HESAP_KREDI
            WHERE hesap_no = pn_hesap_no ;
          Exception When Others Then Null;
        End;

        /*  taksitler isleme atilir.*/
        BEGIN
             INSERT INTO CBS_HESAP_KREDI_TAKS_ONAY_ISL
             (
              yaratan_tx_no,
              hesap_no    ,
              sira_no    ,
              taksit    ,
              anapara    ,
              faiz    ,
              kkdf    ,
              bsmv    ,
              vade_tarih    ,
              kal_anapara    ,
              kdv    ,
              kdvli_taksit    ,
              tahsil_edilecek_taksit    ,
              yaratildigi_tarih    ,
              yaratan_kullanici    ,
              durum_kodu    ,
              odeme_tarihi  ,
              gecikme_faiz_tutari,
              tx_no,
              -- B-O-M seval.colak 09052021
              taksit_gun_sayisi,
              hesaplama_gun_sayisi,
              taksit_baz_anapara,
              taksit_faiz_orani,
              taksit_bsmv_orani,
              taksit_kkdf_orani,
              ozel_odeme_tutari,
              orj_vergi_tutari,
              orj_faiz_tutari,
              ek_faiz_tutari,
              deferred_interest ,
              deferred_delayed_interest,
              deferred_tax,
              paid_deferred_interest,
              paid_deferred_delayed_interest,
              paid_deferred_tax,
              tahsil_taksit,
              tahsil_anapara,
              tahsil_faiz,
              tahsil_kkdf,
              tahsil_bsmv,
              tahsil_gecikme_faiz_tutari,
              deferred_tax2,
              paid_deferred_tax2,
              tahakkuk_eh,
              penalty_amount,
              paid_penalty_amount,
              deferred_penalty_amount,
              paid_deferred_penalty_amount
              -- E-O-M seval.colak 09052021
               ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
               ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022

              )
             SELECT
              NVL(yaratan_tx_no,pn_tx_no),
              hesap_no    ,
              sira_no    ,
              taksit    ,
              anapara    ,
              faiz    ,
              kkdf    ,
              bsmv    ,
              vade_tarih    ,
              kal_anapara    ,
              kdv    ,
              kdvli_taksit    ,
              tahsil_edilecek_taksit    ,
              yaratildigi_tarih    ,
              yaratan_kullanici    ,
              durum_kodu    ,
              odeme_tarihi  ,
              gecikme_faiz_tutari,
              pn_tx_no,
                -- B-O-M seval.colak 09052021
              taksit_gun_sayisi,
              hesaplama_gun_sayisi,
              taksit_baz_anapara,
              taksit_faiz_orani,
              taksit_bsmv_orani,
              taksit_kkdf_orani,
              ozel_odeme_tutari,
              orj_vergi_tutari,
              orj_faiz_tutari,
              ek_faiz_tutari,
              deferred_interest ,
              deferred_delayed_interest,
              deferred_tax,
              paid_deferred_interest,
              paid_deferred_delayed_interest,
              paid_deferred_tax,
              tahsil_taksit,
              tahsil_anapara,
              tahsil_faiz,
              tahsil_kkdf,
              tahsil_bsmv,
              tahsil_gecikme_faiz_tutari,
              deferred_tax2,
              paid_deferred_tax2,
              tahakkuk_eh,
              penalty_amount,
              paid_penalty_amount,
              deferred_penalty_amount,
              paid_deferred_penalty_amount                          
              -- E-O-M seval.colak 09052021
               ,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi --seval.colak 20012022
                ,paid_deferred_penalty_tax,paid_nonaccrual_deferred_delay_tax,paid_nonaccrual_deferred_tax --seval.colak 25052022
        FROM CBS_HESAP_KREDI_TAKSIT
        WHERE hesap_no = pn_hesap_no ;

        Begin
            INSERT INTO CBS_HESAP_KREDI_OZLTKSTONAYISL(tx_no, YARATAN_TX_NO, HESAP_NO, TAKSIT_SIRA_NO, ODEME, YARATILDIGI_TARIH, YARATAN_KULLANICI
                                                    , taksit_tipi  -- seval.colak 09052021
                                                      )
            SELECT  pn_tx_no,nvl(YARATAN_TX_NO,pn_tx_no), HESAP_NO, TAKSIT_SIRA_NO, ODEME, YARATILDIGI_TARIH, YARATAN_KULLANICI
                                , taksit_tipi  -- seval.colak 09052021
            FROM CBS_HESAP_KREDI_OZEL_TKST
              WHERE hesap_no = pn_hesap_no ;
          Exception When Others Then Null;
        End;

        EXCEPTION WHEN OTHERS THEN NULL;
      End;
    END IF;   
  EXCEPTION WHEN OTHERS THEN NULL;
 END;

 FUNCTION sf_islemvarsa_uyar(pn_islem_no NUMBER,
                                 pn_hesap_no NUMBER ,
                              pn_islem_kod NUMBER DEFAULT NULL) RETURN NUMBER
 IS
 ln_tx_no NUMBER :=0 ;
 ln_senet_no NUMBER :=0 ;
 ls_bolum_kodu VARCHAR2(200);
 onayda_bekleyen_islem_var EXCEPTION;

    CURSOR cur_islem IS
    SELECT numara tx_no
    FROM CBS_ISLEM a ,CBS_HESAP_KREDI_ISLEM b
    WHERE  numara > pn_islem_no AND
           islem_kod  = NVL(pn_islem_kod,islem_kod) AND
               a.numara= b.tx_no AND
            a.durum NOT IN ('D', '2','R') AND
            b.hesap_no = NVL(pn_hesap_no,b.hesap_no);
BEGIN
     FOR c_islem IN cur_islem LOOP
          ln_tx_no := c_islem.tx_no ;
     END LOOP;
        IF  NVL(ln_tx_no,0) <> 0 THEN
              RAISE onayda_bekleyen_islem_var;
        END IF;
        RETURN NVL(ln_tx_no,0);
  EXCEPTION
  WHEN onayda_bekleyen_islem_var THEN
               RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '975' ||Pkg_Hata.getdelimiter|| TO_CHAR(ln_tx_no)||  Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
  WHEN OTHERS THEN RETURN 0;

 END;

 PROCEDURE  sp_hesap_kapanabilir_mi( pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE)
 IS
  ls_uygun VARCHAR2(1) := 'H';
  uygun_degil EXCEPTION;
  ln_adet      NUMBER := 0;
  ln_toplam      NUMBER;

 BEGIN

       SELECT ABS(NVL(birikmis_faiz_tutari,0)) +
               ABS( NVL(birikmis_komisyon_tutari,0)) +
             ABS(NVL( bakiye,0))
      INTO ln_toplam
      FROM CBS_HESAP_KREDI a ,
             CBS_HESAP_BAKIYE b
      WHERE A.hesap_no = pn_hesap_no AND
              durum_kodu = 'A' AND
            a.hesap_no = b.hesap_no;

      IF  NVL(ln_toplam,0) <> 0  THEN
          ls_uygun := 'H';
           RAISE uygun_degil;
      ELSE
           ls_uygun := 'E';
       END IF;

     EXCEPTION WHEN OTHERS THEN
                         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '976' ||Pkg_Hata.getdelimiter||  Pkg_Hata.getUCPOINTER);

 END;

 FUNCTION sf_islem_taksit_maxno_al(pn_islem_no NUMBER ) RETURN NUMBER
 IS
   ln_sira NUMBER;
  BEGIN

      SELECT MAX(sira_no)
      INTO ln_sira
      FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
      WHERE tx_no = pn_islem_no;            

    RETURN NVL(ln_sira,0);
    EXCEPTION WHEN OTHERS THEN RETURN 0;
 END;

 Procedure sf_pastdue_kredi_hesap_ac(pn_kredi_hesap_no number,
                                         pn_iliskili_hesap_no number,
                                     pn_yaratan_islem_no    number,
                                     pn_yeni_islem_no    number ,
                                        pn_tutar number,
                                     ps_faiz_anapara varchar2 default 'FAIZ',
                                     pn_pastdue_hesap_no out number,
                                     pn_fis_no out number,
                                      ps_fis_kesilsin varchar2 default 'E')

   IS
   ls_musteri_dk_no  cbs_hesap_kredi.musteri_dk_no%type;
   ld_vade_faiz date;

    ln_1313_hesap_sube        number;
    ln_1313_iliskili_hesap_no        number;
    ln_1313_referans        number;
    ln_1313_hesap_no        number;
    ln_1313_fis_aciklama        number;
    ln_1313_banka_aciklama        number;
    ln_1313_doviz_kodu        number;
    ln_1313_musteri_aciklama        number;
    ln_1313_fc_tutar        number;
    ln_1313_kur        number;
    ln_1313_lc_tutar        number;

    --ta
    ln_1313_ILISKILI_SUBE    number;

    ln_islem_kod            number := 1313;
    varchar_list                    Pkg_Muhasebe.varchar_array;
    number_list                        Pkg_Muhasebe.number_array;
    date_list                        Pkg_Muhasebe.date_array;
    boolean_list                    Pkg_Muhasebe.boolean_array;
    ln_fis_no                        NUMBER:=0;
    ls_banka_aciklama                  VARCHAR2(2000);
    ls_musteri_aciklama                   VARCHAR2(2000);
    ls_aciklama                        VARCHAR2(2000);
    ls_islem_aciklama                VARCHAR2(2000);
    ls_fis_aciklama                VARCHAR2(2000);
    CURSOR cursor_hesap IS
             SELECT
                     modul_tur_kod,
                    urun_tur_kod ,
                    urun_sinif_kod,
                    hesap_no,
                    MUSTERI_NO,
                    DOVIZ_KODU,
                    pn_tutar  tutar,
                    'A' durum_kodu,
                    sube_kodu,
                     pn_iliskili_hesap_no iliskili_hesap_no,
                    kredi_vade,
                    extre_masrafi ,
                    faiz_tahakkuk_hesap_no,
                    vergi_tahakkuk_hesap_no,
                    kredi_teklif_satir_numara,
                    kredi_kullandirim_kodu,
                    0 faiz_siklik,
                    'MATURITY DATE' faiz_siklik_tipi,
                    kullandirim_doviz_kodu,
                    son_gun_faizi,
                    sinirlama_kodu,
                    kaynak_kodu,
                    urun_grup_no,
                    esas_gun_sayisi,
                    pkg_muhasebe.banka_tarihi_bul acilis_tarihi,
                    kredi_turu,
                    prefix_istatistik_kodu_faiz,
                    prefix_istatistik_kodu_kapama,
                    istatistik_kodu_faiz,
                    istatistik_kodu_kapama,
                    pastdue_faiz_orani,
                    yearly_int_rate
         FROM  CBS_HESAP_KREDI
         WHERE hesap_no = pn_kredi_hesap_no ;




   BEGIN

   FOR cur_hesap IN cursor_hesap LOOP
    if cur_hesap.urun_tur_kod <> 'PAST DUE' then  --sevalb 20052011 1303 den pastdue acilisda girilen urun sinif kullanilmali.
        if  cur_hesap.urun_tur_kod in ( 'LEASING','FACTORING','FORFEITING') then
            select  cur_hesap.urun_tur_kod ||'-' || DECODE(cur_hesap.doviz_kodu,pkg_genel.lc_al,'LC','FC')
            into cur_hesap.urun_sinif_kod
            from dual;
            cur_hesap.urun_tur_kod := 'PAST DUE';
        elsif  PKG_bireysel_kredi.Sf_BireyselUrunUygunmu(cur_hesap.urun_tur_kod) = 'E' then
            cur_hesap.urun_tur_kod := replace(cur_hesap.urun_tur_kod,'RT-','PD-');
            cur_hesap.urun_sinif_kod :=  cur_hesap.URUN_SINIF_KOD;
        elsif  cur_hesap.urun_tur_kod = 'COMMERCIAL' and cur_hesap.urun_sinif_kod ='MS FR-KYRSEFF-FC'  then
              cur_hesap.urun_tur_kod  := 'PAST DUE';
              cur_hesap.urun_sinif_kod := 'COM.-MSF-KYRSEFF-FC';
        elsif  cur_hesap.urun_tur_kod = 'COMMERCIAL' and cur_hesap.urun_sinif_kod ='MS FR-KYRSEFF-LC'  then
              cur_hesap.urun_tur_kod  := 'PAST DUE';
              cur_hesap.urun_sinif_kod := 'COM.-MSF-KYRSEFF-LC';
        elsif  cur_hesap.urun_tur_kod = 'INDUSTRY' and cur_hesap.urun_sinif_kod ='FC'  then
              cur_hesap.urun_tur_kod  := 'PAST DUE';
              cur_hesap.urun_sinif_kod := 'PD-INDUST-FC';
        elsif  cur_hesap.urun_tur_kod = 'INDUSTRY' and cur_hesap.urun_sinif_kod ='LC'  then
              cur_hesap.urun_tur_kod  := 'PAST DUE';
              cur_hesap.urun_sinif_kod := 'PD-INDUST-LC';
        elsif  cur_hesap.urun_tur_kod = 'AGRICUL' and cur_hesap.urun_sinif_kod ='FC'  then
              cur_hesap.urun_tur_kod  := 'PAST DUE';
              cur_hesap.urun_sinif_kod := 'PD-AGRICUL-FC';
        elsif  cur_hesap.urun_tur_kod = 'AGRICUL' and cur_hesap.urun_sinif_kod ='LC'  then
              cur_hesap.urun_tur_kod  := 'PAST DUE';
              cur_hesap.urun_sinif_kod := 'PD-AGRICUL-LC';
        elsif  cur_hesap.urun_tur_kod = 'RT-FIXRATE' and cur_hesap.urun_sinif_kod ='AGRICUL-LC'  then
              cur_hesap.urun_tur_kod  := 'PAST DUE';
              cur_hesap.urun_sinif_kod := 'PD-FIXRATE-AGRIC-LC';
        elsif (length(cur_hesap.urun_tur_kod || '-' || cur_hesap.urun_sinif_kod) > 20) then

            if  cur_hesap.urun_tur_kod = 'COMMERCIAL' and instr(cur_hesap.urun_sinif_kod, 'KYRSEFF-FC', 1, 1)>0  then
                    cur_hesap.urun_sinif_kod := 'COM.-MSF-KYRSEFF-FC';
            elsif  cur_hesap.urun_tur_kod = 'COMMERCIAL' and instr(cur_hesap.urun_sinif_kod, 'KYRSEFF-LC', 1, 1)>0  then
                    cur_hesap.urun_sinif_kod := 'COM.-MSF-KYRSEFF-LC';
            elsif  cur_hesap.urun_tur_kod = 'R.EST.CON.' and instr(cur_hesap.urun_sinif_kod, 'KYRSEFF -FC', 1, 1)>0  then
                    cur_hesap.urun_sinif_kod := 'R.EST.FRT KYRSEFF-FC';
            elsif  cur_hesap.urun_tur_kod = 'R.EST.CON.' and instr(cur_hesap.urun_sinif_kod, 'KYRSEFF -LC', 1, 1)>0  then
                    cur_hesap.urun_sinif_kod := 'R.EST.FRT KYRSEFF-LC';
            end if;

             cur_hesap.urun_tur_kod  := 'PAST DUE';
        else
             select cur_hesap.urun_tur_kod || '-' || cur_hesap.urun_sinif_kod
             into cur_hesap.urun_sinif_kod
             from dual;
             cur_hesap.urun_tur_kod  := 'PAST DUE';
        end if;
    end if;

    if ps_faiz_anapara = 'FAIZ' then

        ls_musteri_dk_no :=pkg_kredi.sf_kredi_dk_bul(cur_hesap.MUSTERI_NO,
                                                pkg_kredi.modul_tur_kod,
                                              cur_hesap.urun_tur_kod,
                                              cur_hesap.urun_sinif_kod,4) ;

--        ld_vade_faiz := ADD_MONTHS(pkg_muhasebe.banka_tarihi_bul,2);
        ld_vade_faiz := ADD_MONTHS(pkg_muhasebe.banka_tarihi_bul,3);--sevalb070607
        if pkg_tarih.gun_ozellik(ld_vade_faiz ) = 1 then
           ld_vade_faiz := pkg_tarih.ileri_is_gunu(ld_vade_faiz) ;
        end if ;
        --Sevalb 060607
        cur_hesap.pastdue_faiz_orani := 0;
    elsif ps_faiz_anapara = 'TAX' then
        ls_musteri_dk_no :=pkg_kredi.sf_kredi_dk_bul(cur_hesap.MUSTERI_NO,
                                                         pkg_kredi.modul_tur_kod,
                                                       cur_hesap.urun_tur_kod,
                                                       cur_hesap.urun_sinif_kod,5) ;

        ld_vade_faiz := ADD_MONTHS(pkg_muhasebe.banka_tarihi_bul,3);
        if pkg_tarih.gun_ozellik(ld_vade_faiz) = 1 then
           ld_vade_faiz := pkg_tarih.ileri_is_gunu(ld_vade_faiz) ;
        end if ;
        cur_hesap.pastdue_faiz_orani := 0;
    else
         ls_musteri_dk_no :=pkg_kredi.sf_kredi_dk_bul(cur_hesap.MUSTERI_NO,
                                                     pkg_kredi.modul_tur_kod,
                                                  cur_hesap.urun_tur_kod,
                                                  cur_hesap.urun_sinif_kod) ;

        --ld_vade_faiz := ADD_MONTHS(pkg_muhasebe.banka_tarihi_bul,6);
        ld_vade_faiz := ADD_MONTHS(pkg_muhasebe.banka_tarihi_bul,3); --sevalb070607
        if pkg_tarih.gun_ozellik(ld_vade_faiz ) = 1 then
           ld_vade_faiz := pkg_tarih.ileri_is_gunu(ld_vade_faiz) ;
        end if ;

    end if;

     Pkg_Kredi.KREDI_HESAP_AC (      pkg_kredi.modul_tur_kod,
                                     cur_hesap.urun_tur_kod,
                                     cur_hesap.urun_sinif_kod,
                                     cur_hesap.MUSTERI_NO,
                                     cur_hesap.DOVIZ_kodu,
                                     cur_hesap.SUBE_KODU,
                                     ld_vade_faiz,
                                     NULL,
                                     pn_pastdue_hesap_no,
                                     p_musteri_dk_no => ls_musteri_dk_no,  --musteri_dk_no
                                     p_tutar => pn_tutar , --tutar
                                     p_extre_masrafi => cur_hesap.extre_masrafi,--    extre_masrafi
                                     p_iliskili_hesap_no =>  pn_iliskili_hesap_no,
                                     p_kredi_teklif_satir_numara => cur_hesap.KREDI_TEKLIF_SATIR_NUMARA,
                                     p_kredi_kullandirim_kodu =>cur_hesap.kredi_kullandirim_kodu,
                                     p_faiz_siklik => cur_hesap.faiz_siklik,
                                     p_faiz_siklik_tipi => cur_hesap.faiz_siklik_tipi,
                                     p_faiz_tahakkuk_tarihi=> ld_vade_faiz,
                                     p_kullandirim_doviz_kodu=> cur_hesap.kullandirim_doviz_kodu,
                                     p_son_gun_faizi => cur_hesap.son_gun_faizi,
                                     p_sinirlama_kodu => cur_hesap.sinirlama_kodu,
                                     p_kaynak_kodu => cur_hesap.kaynak_kodu,
                                     p_urun_grup_no => cur_hesap.urun_grup_no,
                                     p_esas_gun_sayisi => cur_hesap.esas_gun_sayisi,
                                     p_acilis_tarihi => cur_hesap.acilis_tarihi,
                                     p_kredi_turu => cur_hesap.kredi_turu,
                                     p_prefix_istatistik_kodu_faiz => cur_hesap.prefix_istatistik_kodu_faiz,
                                     p_prefix_istatistik_kodu_kapa => cur_hesap.prefix_istatistik_kodu_kapama,
                                     p_istatistik_kodu_faiz =>cur_hesap.istatistik_kodu_faiz,
                                     p_istatistik_kodu_kapama => cur_hesap.istatistik_kodu_kapama,
                                     p_ana_kredi_hesap_no    =>cur_hesap.HESAP_NO,
                                     p_pastdue_faiz_anapara_sec =>ps_faiz_anapara,
                                     p_faiz_orani => cur_hesap.pastdue_faiz_orani,
                                     p_pastdue_faiz_orani => 0
                                         );


    if nvl(pn_pastdue_hesap_no,0) <> 0 and NVL(ps_fis_kesilsin,'E') = 'E' then
        ln_1313_hesap_sube :=pkg_muhasebe.parametre_index_bul('1313_HESAP_SUBE');
        ln_1313_iliskili_hesap_no :=pkg_muhasebe.parametre_index_bul('1313_ILISKILI_HESAP_NO');
        ln_1313_referans :=pkg_muhasebe.parametre_index_bul('1313_REFERANS');
        ln_1313_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1313_FIS_ACIKLAMA');
        ln_1313_fc_tutar :=pkg_muhasebe.parametre_index_bul('1313_FC_TUTAR');
        ln_1313_hesap_no :=pkg_muhasebe.parametre_index_bul('1313_HESAP_NO');
        ln_1313_kur :=pkg_muhasebe.parametre_index_bul('1313_KUR');
        ln_1313_lc_tutar :=pkg_muhasebe.parametre_index_bul('1313_LC_TUTAR');
        ln_1313_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1313_MUSTERI_ACIKLAMA');
        ln_1313_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1313_BANKA_ACIKLAMA');
        ln_1313_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1313_DOVIZ_KODU');
        ln_1313_ILISKILI_SUBE:=pkg_muhasebe.parametre_index_bul('1313_ILISKILI_SUBE');--TA

       ls_islem_aciklama :=   Pkg_Genel.ISLEM_ADI_AL(1313) ;
       Pkg_Parametre.deger('1313_BANKA_ACIKLAMA',ls_banka_aciklama) ;
       Pkg_Parametre.deger('1313_MUSTERI_ACIKLAMA',ls_musteri_aciklama) ;
       Pkg_Parametre.deger('1313_FIS_ACIKLAMA',ls_fis_aciklama);
       varchar_list(ln_1313_fis_aciklama)    := NVL(ls_fis_aciklama,ls_islem_aciklama);
        varchar_list(ln_1313_banka_aciklama):= ls_banka_aciklama || to_char(cur_hesap.hesap_no);
        varchar_list(ln_1313_musteri_aciklama) := ls_musteri_aciklama || to_char(cur_hesap.hesap_no);

        varchar_list(ln_1313_doviz_kodu) := cur_hesap.doviz_kodu;
        varchar_list(ln_1313_hesap_no) :=pn_pastdue_hesap_no ;
        varchar_list(ln_1313_hesap_sube) := cur_hesap.sube_kodu;
        varchar_list(ln_1313_iliskili_hesap_no) :=  pn_iliskili_hesap_no;
        varchar_list(ln_1313_ILISKILI_SUBE) := pkg_hesap.HesapSubeAl(pn_iliskili_hesap_no);--TA
        varchar_list(ln_1313_referans) := cur_hesap.hesap_no;
        number_list(ln_1313_fc_tutar) := abs(nvl( pn_tutar,0));
        number_list(ln_1313_kur) :=Pkg_Kur.doviz_doviz_karsilik(cur_hesap.doviz_kodu ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
        number_list(ln_1313_lc_tutar) := Pkg_Kur.doviz_doviz_karsilik(cur_hesap.doviz_kodu ,Pkg_Genel.lc_al,NULL,number_list(ln_1313_fc_tutar),1,NULL,NULL,'N','A');

        pn_fis_no:=Pkg_Muhasebe.fis_kes(ln_islem_kod,
                                        null,
                                        pn_yeni_islem_no,
                                        varchar_list,
                                        number_list,
                                        date_list,
                                        boolean_list,
                                        NULL,
                                        FALSE,
                                        0,--ln_fis_no,
                                        NULL );--ls_aciklama);


                Pkg_Muhasebe.MUHASEBELESTIR(pn_fis_no);
      end if;
    END LOOP;

    if ps_faiz_anapara  = 'FAIZ' then
        UPDATE CBS_HESAP_KREDI_ISLEM
        SET pastdue_faiz_hesap_no  =  pn_pastdue_hesap_no
        WHERE  tx_no =  pn_yaratan_islem_no ;

    elsif ps_faiz_anapara  = 'TAX' then
        UPDATE CBS_HESAP_KREDI_ISLEM
        SET PASTDUE_TAX_hesap_no  =  pn_pastdue_hesap_no
        WHERE  tx_no =  pn_yaratan_islem_no ;

    else
        UPDATE CBS_HESAP_KREDI_ISLEM
        SET pastdue_anapara_hesap_no  =  pn_pastdue_hesap_no
        WHERE  tx_no =  pn_yaratan_islem_no ;
    end if;

   Pkg_Kredi.sp_kredihesap_isleme_at (pn_pastdue_hesap_no,
                                             pn_yeni_islem_no,
                                     1313);
    EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '979' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

   END;



  PROCEDURE sp_pastdue_dk_tanimlimi(pn_islem_no NUMBER) IS
   ls_kredi_hesap_doviz_kodu               CBS_HESAP_KREDI.doviz_kodu%TYPE;
   gusin_tanimi_yok                         EXCEPTION;
   faizdovizyok                             EXCEPTION;
   ls_dk_grup_kod            CBS_MUSTERI.DK_GRUP_KOD%TYPE;
   ls_modul_tur_kod            CBS_HESAP.modul_tur_kod%TYPE;
   ls_urun_tur_kod            CBS_HESAP.urun_tur_kod%TYPE;
   ls_urun_sinif_kod       varchar2(200);   --CQ5031 Increase number of characters KonstantinJ 25092015  
   ls_faizreesdk              VARCHAR2(2000);
   ls_faizdk                  VARCHAR2(2000);
   ls_anadk                  VARCHAR2(2000);
   ls_hesap_no                CBS_HESAP_KREDI.hesap_no%TYPE;
   ls_bolum_kodu            CBS_HESAP_KREDI.sube_kodu%TYPE;
   ls_var                    VARCHAR2(1) := NULL;
   ls_dk                    VARCHAR2(2000);
   ls_doviz                    CBS_HESAP_KREDI.doviz_kodu%TYPE;
   ls_urun                    varchar2(200);
   ls_urun_sinif            varchar2(200);
  BEGIN

   SELECT doviz_kodu,
          Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no),
          modul_tur_kod,
           urun_tur_kod,
          urun_sinif_kod,
          TO_CHAR(hesap_no),
          nvl(sube_kodu,pkg_tx.Amir_BolumKodu_Al(pn_islem_no)) bolum_kodu
   INTO   ls_kredi_hesap_doviz_kodu,
          ls_dk_grup_kod,
          ls_modul_tur_kod,
           ls_urun_tur_kod,
          ls_urun_sinif_kod,
          ls_hesap_no,
          ls_bolum_kodu
   FROM CBS_HESAP_KREDI_ISLEM
   WHERE tx_no = pn_islem_no;

    ls_urun          := ls_urun_tur_kod;
    ls_urun_sinif := ls_urun_sinif_kod;

    if ls_urun =  'PAST DUE' or substr(ls_urun,1,3) = 'PD-' then
           ls_urun_tur_kod   := ls_urun;
           ls_urun_sinif_kod := ls_urun_sinif ;
    elsif  ls_urun_tur_kod in ( 'LEASING','FACTORING','FORFEITING') then
            select ls_urun_tur_kod ||'-' || DECODE(ls_kredi_hesap_doviz_kodu,pkg_genel.lc_al,'LC','FC')
            into ls_urun_sinif_kod
            from dual;
            ls_urun_tur_kod:= 'PAST DUE';
    elsif  PKG_bireysel_kredi.Sf_BireyselUrunUygunmu(ls_urun_tur_kod ) = 'E' then
            ls_urun_tur_kod := replace(ls_urun_tur_kod,'RT-','PD-');  --'RT-PASTDUE';
    else
            select ls_urun_tur_kod || '-' || ls_urun_sinif_kod
            into ls_urun_sinif_kod
            from dual;
            ls_urun_tur_kod := 'PAST DUE';
    end if;

/*gusin tanimlimi */

 if ls_urun <>  'PAST DUE' and substr(ls_urun,1,3) = 'PD-' then
/*faiz ana dk */
    --b-o-m seval.colak 10112021  accrual modification devreye alinacagi zaman pastdue acilmayacagi icin asagidaki kontrol kapatilacak./*
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 1,
                        NULL,NULL, NULL,ls_anadk);
    IF ls_anadk IS NULL THEN
       RAISE gusin_tanimi_yok;
    END IF;
     --*/ e-o-m seval.colak 10112021  accrual modification devreye alinacagi zaman pastdue acilmayacagi icin asagidaki kontrol kapatilacak./*
    
/*faiz gelir dk */
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 2,
                        NULL,NULL, NULL,ls_faizdk);
    IF ls_faizdk IS NULL THEN
       RAISE gusin_tanimi_yok;
    END IF;
/*faiz reeskont dk */
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 4,
                        NULL,NULL, NULL,ls_faizreesdk);
     IF ls_faizreesdk IS NULL  THEN
         RAISE gusin_tanimi_yok;
     END IF;

/*dk tanimlimi*/
/*ana dk*/
   --b-o-m seval.colak 10112021  accrual modification devreye alinacagi zaman pastdue acilmayacagi icin asagidaki kontrol kapatilacak./*
       ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_anadk,ls_kredi_hesap_doviz_kodu);
     IF ls_var <> 'E' THEN
         ls_dk := ls_anadk;
        ls_doviz:= ls_kredi_hesap_doviz_kodu;
        RAISE faizdovizyok;
     END IF;
 --*/ e-o-m seval.colak 29102021 artik pastdue principal aclmayacagindan kontrol edilmesi kapatildi.
/*faizrees*/
       ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_faizreesdk,ls_kredi_hesap_doviz_kodu);
     IF ls_var <> 'E' THEN
         ls_dk := ls_faizreesdk;
        ls_doviz:= ls_kredi_hesap_doviz_kodu;
        RAISE faizdovizyok;
     END IF;

/*faiz gelir tl */
     ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_faizdk,Pkg_Genel.lc_al);
     IF ls_var <> 'E' THEN
         ls_dk := ls_faizdk;
        ls_doviz:= Pkg_Genel.lc_al;
       RAISE faizdovizyok;
     END IF;
 End if;
 EXCEPTION
   WHEN gusin_tanimi_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '714' || Pkg_Hata.getdelimiter || ls_dk_grup_kod ||  Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN faizdovizyok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '715' || Pkg_Hata.getdelimiter || ls_dk||  Pkg_Hata.getdelimiter || ls_bolum_kodu|| Pkg_Hata.getdelimiter ||ls_doviz|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
 END;

 FUNCTION sf_acilis_vade_tarih_al(pn_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE) RETURN DATE
   IS
     ld_vade  CBS_HESAP_KREDI.kredi_vade%TYPE;
  BEGIN

        SELECT acilis_kredi_vade
      INTO ld_vade
      FROM CBS_HESAP_KREDI
      WHERE hesap_no = pn_hesap_no;

      RETURN ld_vade ;
  END ;


  procedure sp_taksit_geriodeme_tutarayni(pn_islem_no number ,pn_tutar number)
  is
     CURSOR cur_taksit IS
       SELECT SIRA_NO,
                 vade_tarih,
                 nvl(anapara,0) anapara
       FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no AND
             nvl(durum_kodu,'A')  = 'A'
       ORDER BY vade_tarih;
        ln_tutar number := 0;
        taksit_tutar_uygun_Degil exception;
        ls_repayment_type varchar2(200);
  Begin

         select   repayment_type
       into ls_repayment_type
         from cbs_hesap_kredi_islem
         where tx_no = pn_islem_no ;
   if  ls_repayment_type  = 'INSTALLMENT DATE' then
         for c_taksit in cur_taksit loop
           if nvl(ln_tutar,0) < nvl(pn_tutar,0) then
             ln_tutar := c_taksit.anapara + nvl(ln_tutar,0);
           end if;
       end loop;
    if nvl(ln_tutar,0) <> nvl(pn_tutar,0) then
               raise taksit_tutar_uygun_Degil;
         end if;
    end if;
    Exception when taksit_tutar_uygun_Degil then
              Raise_application_error(-20100,pkg_hata.getUCPOINTER || '978' || pkg_hata.getUCPOINTER);
  End;
------------------------------------------------------------------------------
FUNCTION  sf_dk_uygunmu(ps_dkno VARCHAR2) RETURN VARCHAR2
  IS
  BEGIN
       IF SUBSTR(ps_dkno,1,1) IN('6','7','8','9') OR
          SUBSTR(ps_dkno,1,3) IN('100','114','210','400','401','402') OR
             SUBSTR(ps_dkno,1,4) IN('1152') or
             SUBSTR(ps_dkno,1,5) IN('11519') or
          length(ps_dkno) <> 8
           THEN
         RETURN 'H';
        ELSE
          RETURN  'E';
       END IF;
  END;
----------------------------------------------------------------------------------------
FUNCTION sf_tarih_arasi_kredtak_varmi(pn_hesap_no number, pd_tarih1 date, pd_tarih2 date) return varchar is
ln_count number;

begin

  if pd_tarih1 is not null and pd_tarih2 is not null then
     select count(*) into ln_count
     from CBS_HESAP_KREDI_TAKSIT
     where hesap_no=pn_hesap_no
     and VADE_TARIH between pd_tarih1 and pd_tarih2;

  elsif pd_tarih1 is not null and pd_tarih2 is null then

     select count(*) into ln_count
     from CBS_HESAP_KREDI_TAKSIT
     where hesap_no=pn_hesap_no
     and VADE_TARIH > pd_tarih1;


  elsif pd_tarih1 is null and pd_tarih2 is not null then

     select count(*) into ln_count
     from CBS_HESAP_KREDI_TAKSIT
     where hesap_no=pn_hesap_no
     and VADE_TARIH <  pd_tarih2;
  else
     return 'E';
  end if;

  if nvl(ln_count,0) >0 then
     return 'E';
  else
     return 'H';
  end if;

end;

 FUNCTION sf_teklif_bolum_kodu_al(pn_musteri_no NUMBER) RETURN varchar2
 is
   ls_bolum_kodu    varchar2(10);
 BEGIN
       SELECT bolum_kodu
      INTO  ls_bolum_kodu
      FROM CBS_KREDI_TEKLIF
      WHERE teklif_no =sf_musteriden_teklifnoal(pn_musteri_no );

    RETURN ls_bolum_kodu ;
 EXCEPTION when others then return null;
 End ;
-------------------------------------------------------------------------------- 
--b-o-m sevalb 04032011
  FUNCTION sf_accrued_interest_tax_amt(pn_hesap_no NUMBER) RETURN number
   is
   ln_accrued_interest_tax  number := 0;
 BEGIN
       SELECT accrued_interest_tax
      INTO  ln_accrued_interest_tax
      FROM cbs_hesap_kredi
      WHERE hesap_no =pn_hesap_no;

    RETURN ln_accrued_interest_tax ;
 EXCEPTION when others then return 0;
 End ;
 FUNCTION sf_accrued_commision_tax_amt(pn_hesap_no NUMBER) RETURN number
 is
   ln_accrued_commission_tax  number := 0;
 BEGIN
       SELECT accrued_commission_tax
      INTO  ln_accrued_commission_tax
      FROM cbs_hesap_kredi
      WHERE hesap_no =pn_hesap_no;

    RETURN ln_accrued_commission_tax ;
 EXCEPTION when others then return 0;
 End ;
 
--e-o-m sevalb 04032011

--BOM cq614 ErkinZu 25042017 
FUNCTION sf_get_Customer_AppNo(pn_musteri_no NUMBER, pn_kredi_teklif_satir_no NUMBER) RETURN NUMBER
IS
    ln_app_no NUMBER;
BEGIN
    SELECT app_no
    INTO ln_app_no
    FROM cbs_kredi_teklif a, cbs_kredi_teklif_satir b
    WHERE a.teklif_no = b.teklif_no
    AND a.durum_kodu = 'A'
    AND a.musteri_no = pn_musteri_no
    AND b.teklif_satir_no = pn_kredi_teklif_satir_no;
    return ln_app_no;
END;
--EOM cq614 ErkinZu 25042017

--BOM aisuluud cq4883 TemirlanT cbs-119
procedure sp_Principal_Pastdue_Closing( pn_pd_account_no number,
                                        pd_value_date date,
                                        ps_collection_currency varchar2,
                                        pn_rate number,
                                        pn_related_account number,
                                        pn_collection_account number,
                                        pn_tahsedil_gecenyilfaiztutar number,
                                        pn_tahsedil_gecmis_aylar_faiz number,
                                        pn_tahsedil_birikmisfaiztutar number,
                                        pn_anapara_tahsilat_tutar number,
                                        ps_aciklama varchar2,
                                        ps_choice varchar2,
                                        ps_durum_kodu varchar2,
                                        ps_pd_branch_cd varchar2,
                                        ps_modul_tur_kod varchar2, 
                                        ps_urun_tur_kod varchar2,
                                        ps_urun_sinif_kod varchar2,
                                        ps_past_due_currency varchar2,
                                        pn_musteri_no number) is

 ln_islem_kod number;
 ln_islem_no number; 
 ln_toplam_tahsiledilecek_tutar number;
 
begin

    ln_islem_kod := 1306;
    ln_islem_no:=CBS.pkg_tx.islem_no_al;    
    
    pkg_Kredi.sp_kredihesap_isleme_at(pn_pd_account_no,ln_islem_no,ln_islem_kod);
    ln_toplam_tahsiledilecek_tutar := pn_anapara_tahsilat_tutar + pn_tahsedil_gecenyilfaiztutar + pn_tahsedil_gecmis_aylar_faiz + pn_tahsedil_birikmisfaiztutar;
    
    update CBS_HESAP_KREDI_ISLEM
    set VALOR_TARIHI = pd_value_date, 
    TAHSIL_HESAP_DOVIZ = ps_collection_currency, 
    KUR = pn_rate, 
    ILISKILI_HESAP_NO = pn_related_account, 
    TAHSIL_HESAP_NO = pn_collection_account, 
    TAHSEDIL_GECENYIL_FAIZ_TUTARI = pn_tahsedil_gecenyilfaiztutar,
    TAHSEDIL_GECMIS_AYLAR_FAIZ = pn_tahsedil_gecmis_aylar_faiz,
    TAHSEDIL_BIRIKMIS_FAIZ_TUTARI = pn_tahsedil_birikmisfaiztutar,
    ANAPARA_TAHSILAT_TUTAR = pn_anapara_tahsilat_tutar,
    ACIKLAMA = ps_aciklama,
    GERIODEME_KAPAMA_SECIMI = ps_choice,
    DURUM_KODU = ps_durum_kodu,
    TOPLAM_TAHSILEDILECEK_TUTAR = ln_toplam_tahsiledilecek_tutar
    where TX_NO = ln_islem_no;
    
    cbs.PKG_BAGLAM.YARAT(ps_pd_branch_cd, '0');
    
     begin                     
    Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                          KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                          KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                          MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                          MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                  values (ln_islem_no,ln_islem_kod,'N',pkg_baglam.bolum_kodu,
                          pkg_baglam.kullanici_kodu,pkg_baglam.rol_numara,pkg_baglam.bolum_kodu,
                          pkg_muhasebe.banka_tarihi_bul,sysdate,
                          ps_modul_tur_kod,ps_urun_tur_kod,ps_urun_sinif_kod,
                          pn_musteri_no,pn_pd_account_no,ln_toplam_tahsiledilecek_tutar,null,ps_past_due_currency
                      );              
    update cbs_islem_gecici
           set durum = 'C'
         where numara=ln_islem_no;
    Exception
           When Others Then
            Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);     
    end ;          
    
    Giris_Kontrol(ln_islem_no);     
    
    begin
    PKG_TX1306.KONTROL_SONRASI(ln_islem_no);
    Exception

                When Others then
                log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
                   Rollback;
                   Raise_application_error(-20100,SQLERRM);
    end;  
    begin
    PKG_TX1306.ONAY_SONRASI(ln_islem_no);

                Exception

                When Others then
                log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
                   Rollback;
                   Raise_application_error(-20100,SQLERRM);
    end;     
    begin
    PKG_TX1306.MUHASEBELESME(ln_islem_no);
    update cbs_islem
                set durum = 'P',
                tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
                where numara=ln_islem_no;

                Exception

                When Others then
                log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
                   Rollback;
                   Raise_application_error(-20100,SQLERRM);
    end;         
                          
  
 
 exception
 when others then
 log_at('pkg_kredi_pd_closing','anapara_pd', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); 
 rollback;
 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4670' ||  Pkg_Hata.getdelimiter|| pn_related_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 
end;

procedure sp_penalty_Pastdue_Closing( ps_cash_account varchar2,
                                        ps_currency_code varchar2,
                                        pn_customer_no number,
                                        ps_residency_code varchar2,
                                        ps_citizen_code varchar2,
                                        ps_customer_type varchar2, 
                                        ps_income_type varchar2, 
                                        pn_related_account number,
                                        pn_amount number,
                                        ps_vat varchar2,
                                        ps_service_tax varchar2,
                                        pn_service_tax_rate number,
                                        ps_tax_coll_type varchar2,
                                        pn_paid_tax_amount number,
                                        pn_total_collection_amount number,
                                        ps_collection_currency varchar2,
                                        pn_rate number,
                                        pn_collection_account number,
                                        ps_income_gl varchar2,
                                        ps_explanation varchar2,
                                        ps_pd_branch_cd varchar2,
                                        ps_modul_tur_kod varchar2,
                                        ps_urun_tur_kod varchar2,
                                        ps_urun_sinif_kod varchar2,
                                        pn_current_account number) is

 ln_islem_kod number;
 ln_islem_no number; 
 
begin

    ln_islem_kod := 3400;
    ln_islem_no:=CBS.pkg_tx.islem_no_al;
    
    insert into CBS_MASRAF_KOM_TAHSIL_ISL
            (tx_no, 
            cash_account, 
            dvz, 
            musteri_no, 
            residency_code, 
            citizen_code, 
            customer_type, 
            gelir_aciklama, 
            iliskili_hesap_no, 
            tahsil_tutari, 
            vat, 
            service_tax, 
            service_tax_rate, 
            tax_coll_type, 
            paid_tax_amount, 
            tahsil_toplam_tutar, 
            tahsil_dvz_kod, 
            kur,
            tahsil_hesap_no, 
            income_gl, 
            aciklama )
    values
            (ln_islem_no, 
            ps_cash_account ,
            ps_currency_code ,
            pn_customer_no ,
            ps_residency_code ,
            ps_citizen_code ,
            ps_customer_type , 
            ps_income_type , 
            pn_related_account ,
            pn_amount ,
            ps_vat ,
            ps_service_tax ,
            pn_service_tax_rate ,
            ps_tax_coll_type ,
            pn_paid_tax_amount ,
            pn_total_collection_amount ,
            ps_collection_currency ,
            pn_rate ,
            pn_collection_account ,
            ps_income_gl ,
            ps_explanation);
    
    cbs.PKG_BAGLAM.YARAT(ps_pd_branch_cd, '0');
    
    
    
    begin                     
    Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                          KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                          KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                          MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                          MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                  values (ln_islem_no,ln_islem_kod,'N',pkg_baglam.bolum_kodu,
                          pkg_baglam.kullanici_kodu,pkg_baglam.rol_numara,pkg_baglam.bolum_kodu,
                          pkg_muhasebe.banka_tarihi_bul,sysdate,
                          ps_modul_tur_kod,ps_urun_tur_kod,ps_urun_sinif_kod,
                          pn_customer_no,pn_current_account,pn_total_collection_amount,null,ps_currency_code
                      );              
                      
    update cbs_islem_gecici
           set durum = 'C'
         where numara=ln_islem_no;
    Exception
           When Others Then
            Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);     
    end ;          
    
    Giris_Kontrol(ln_islem_no);     
    
    begin
    PKG_TX3400.KONTROL_SONRASI(ln_islem_no);
    Exception

                When Others then
                log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
                   Rollback;
                   Raise_application_error(-20100,SQLERRM);
    end;  
    begin
    PKG_TX3400.ONAY_SONRASI(ln_islem_no);

                Exception

                When Others then
                log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
                   Rollback;
                   Raise_application_error(-20100,SQLERRM);
    end;     
    begin
    PKG_TX3400.MUHASEBELESME(ln_islem_no);
    update cbs_islem
                set durum = 'P',
                tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
                where numara=ln_islem_no;

                Exception

                When Others then
                log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
                   Rollback;
                   Raise_application_error(-20100,SQLERRM);
    end;                      
    
    UPDATE CBS_HESAP_KREDI k
    SET K.PENALTY_AMOUNT =NVL(PENALTY_AMOUNT,0)-ABS(pn_amount)
    WHERE hesap_no=pn_related_account;

 
 exception
 when others then
 log_at('pkg_kredi_pd_closing','penalty_pd', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); 
 rollback;
 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4666' ||  Pkg_Hata.getdelimiter|| pn_related_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 
end;


procedure sp_convert_for_pd_closing_arb(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number,pn_alis_tutari out number) is
 
 ln_musteri_no number; 
 ln_available_balance number;
 ls_account_currency cbs_hesap.doviz_kodu%type;
 ls_account_branch cbs_hesap.sube_kodu%type;
 ln_block_sum number;  --TemirlanT
 ln_bakiye number;  --TemirlanT
 ln_difference_amount number; --TemirlanT
 
 ln_islem_kod number;
 ln_islem_no number; 
 
 ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
 ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
 ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
 ls_loan_currency cbs_hesap_kredi.doviz_kodu%type;
 
 ls_kur_tipi CBS_ARBITRAJ_ISLEM.KUR_TIPI%type;
 ls_alis_doviz_kodu CBS_ARBITRAJ_ISLEM.ALIS_DOVIZ_KODU%type;
 ls_SATIS_DOVIZ_KODU CBS_ARBITRAJ_ISLEM.SATIS_DOVIZ_KODU%type;
 ls_RESIDENCY_CODE CBS_ARBITRAJ_ISLEM.RESIDENCY_CODE%type;
 ls_CITIZEN_CODE CBS_ARBITRAJ_ISLEM.CITIZEN_CODE%type;
 ls_TAX_NUMBER CBS_ARBITRAJ_ISLEM.TAX_NUMBER%type;
 ls_KUR_PARITE_SECIM CBS_ARBITRAJ_ISLEM.KUR_PARITE_SECIM%type;
 ln_ALIS_KURU CBS_ARBITRAJ_ISLEM.ALIS_KURU%type;
 ln_SATIS_KURU CBS_ARBITRAJ_ISLEM.SATIS_KURU%type;
 ln_ALIS_TUTARI CBS_ARBITRAJ_ISLEM.ALIS_TUTARI%type;
 ln_SATIS_TUTARI CBS_ARBITRAJ_ISLEM.SATIS_TUTARI%type;
 ln_ALIS_HESAP_NO CBS_ARBITRAJ_ISLEM.ALIS_HESAP_NO%type;
 ln_SATIS_HESAP_NO CBS_ARBITRAJ_ISLEM.SATIS_HESAP_NO%type;
 ls_NAME_SURNAME CBS_ARBITRAJ_ISLEM.NAME_SURNAME%type;
 ls_ACIKLAMA CBS_ARBITRAJ_ISLEM.ACIKLAMA%type;
 ls_ISTATISTIK_KODU_ALIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_ALIS%type;
 ls_ISTATISTIK_KODU_SATIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_SATIS%type;
 
 ln_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 ls_related_acc_curr CBS_HESAP.DOVIZ_KODU%type;
 ln_related_acc_count number;
 
 ln_account_no CBS_HESAP.HESAP_NO%type;
 ln_currency CBS_HESAP.DOVIZ_KODU%type;
 ln_account_count number;   
 
 ln_parity CBS_ARBITRAJ_ISLEM.PARITE%type;
 ls_carp_bol_secimi CBS_ARBITRAJ_ISLEM.CARP_BOL_SECIMI%type;
 lb_buy_loan_currency boolean := false;
 lb_bought_amount boolean := false;
 ln_satis_hesap_avail_bal number;
    
    
begin
    ls_account_currency := pkg_hesap.HesaptanDovizKoduAl(pn_current_account);
    ln_musteri_no :=  pkg_hesap.HesaptanMusteriNoAl(pn_current_account);
    ls_account_branch := pkg_hesap.HesapSubeAl(pn_current_account);
    ls_loan_currency := pkg_hesap.HesaptanDovizKoduAl(pn_loan_account);
    ls_related_acc_curr := pkg_hesap.HesaptanDovizKoduAl(pn_alter_current_account);
    
   -- lb_bought_amount := pb_bought_amount;

    ln_islem_kod := 1208;
    ln_islem_no:=CBS.pkg_tx.islem_no_al;
    --ln_amount := pn_amount; --TemirlanT
    ln_related_account := pn_alter_current_account;

    if ln_related_account is not null  then
         ls_modul_tur_kod := 'CURR.OPS.';
         ls_urun_tur_kod := 'ACC-ACC';
         if ls_loan_currency = PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'FC-LC';
                ls_alis_doviz_kodu := ls_account_currency;
                ln_satis_tutari := pn_amount; --TemirlanT
                ln_alis_hesap_no := pn_current_account;
                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_related_acc_curr;
                end if;  
                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);
                ln_alis_tutari := round((ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2) ;
                
          elsif ls_loan_currency <> PKG_GENEL.LC_AL and ls_account_currency = PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'LC-FC';
                ls_alis_doviz_kodu := ls_account_currency;
                ln_satis_tutari := pn_amount; --TemirlanT
                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_related_acc_curr;
                end if;    
                ln_alis_hesap_no := pn_current_account;
                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);
                ln_alis_tutari := round((ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2) ;
                
            elsif ls_loan_currency <> PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'FC-FC';
                ls_alis_doviz_kodu := ls_account_currency;

                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_related_acc_curr;
                end if;    
                ln_alis_hesap_no := pn_current_account;
                        
                lb_buy_loan_currency := false;
            
                ln_satis_tutari := pn_amount; --TemirlanT
                ln_alis_tutari := pkg_kredi.arbitraj_kur(ls_alis_doviz_kodu, ls_satis_doviz_kodu, ln_satis_tutari, ls_account_branch, lb_buy_loan_currency, lb_bought_amount);
            end if;  
         
         pn_alis_tutari := ln_alis_tutari;
         ls_kur_tipi := 'COMMERCIAL';
         ls_residency_code := pkg_musteri.sf_get_residency_code (ln_musteri_no);
         ls_citizen_code := pkg_musteri.sf_get_citizenship_country(ln_musteri_no);
         ls_tax_number := pkg_musteri.Sf_VergiNo_Al(ln_musteri_no);
         ls_kur_parite_secim := 'K'; --RATE
         
         ls_name_surname := pkg_musteri.sf_musteri_adi(ln_musteri_no);
      
         ls_aciklama := '??????????? ??? ????????? ????????? ('|| pn_loan_account || ') - ?? ????? ' || ln_alis_kuru || ' ' || ls_name_surname;         
         ls_istatistik_kodu_alis := '040202';
         ls_istatistik_kodu_satis := '040202';
          
        insert into CBS_ARBITRAJ_ISLEM a 
        (tx_no,urun_tur_kod, urun_sinif_kod, kur_tipi, alis_doviz_kodu, satis_doviz_kodu, residency_code, citizen_code, tax_number, 
         kur_parite_secim, alis_kuru, satis_kuru, alis_tutari, satis_tutari, alis_hesap_no, satis_hesap_no, name_surname, aciklama, istatistik_kodu_alis, istatistik_kodu_satis) values
        (ln_islem_no,
         ls_urun_tur_kod, 
         ls_urun_sinif_kod ,
         ls_kur_tipi ,
         ls_alis_doviz_kodu ,
         ls_SATIS_DOVIZ_KODU ,
         ls_RESIDENCY_CODE ,
         ls_CITIZEN_CODE ,
         ls_TAX_NUMBER ,
         ls_KUR_PARITE_SECIM ,
         ln_ALIS_KURU ,
         ln_SATIS_KURU ,
         ln_ALIS_TUTARI ,
         ln_SATIS_TUTARI ,
         ln_ALIS_HESAP_NO ,
         ln_SATIS_HESAP_NO ,
         ls_NAME_SURNAME ,
         ls_ACIKLAMA ,
         ls_ISTATISTIK_KODU_ALIS ,
         ls_ISTATISTIK_KODU_SATIS );
               
              -- 1.  Create user session
          cbs.PKG_BAGLAM.YARAT(
                ls_account_branch,    --branch code of the CBS user (refers to the table CBS_BOLUM column KODU)
                '0' --role of the CBS user (refers to the table CBS_ROL column NUMARA)
          );
            begin                     
            Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                                  KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                                  KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                                  MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                                  MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                          values (ln_islem_no,ln_islem_kod,'N',pkg_baglam.bolum_kodu,
                                  pkg_baglam.kullanici_kodu,pkg_baglam.rol_numara,pkg_baglam.bolum_kodu,
                                  pkg_muhasebe.banka_tarihi_bul,sysdate,
                                  ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,
                                  ln_musteri_no,ln_alis_hesap_no,ln_ALIS_TUTARI,null,ls_alis_doviz_kodu
                              );                 
            update cbs_islem_gecici
                   set durum = 'C'
                 where numara=ln_islem_no;
            Exception
                   When Others Then
                    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);     
            end ;          
            
        --if ln_alis_tutari != 0 then --TemirlanT
            Giris_Kontrol(ln_islem_no);     
            begin 
            PKG_TX1207.KONTROL_SONRASI(ln_islem_no); 
            Exception

                        When Others then
                        log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;  
            begin
            PKG_TX1207.ONAY_SONRASI(ln_islem_no);

                        Exception

                        When Others then
                        log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;      
            begin
            PKG_TX1207.MUHASEBELESME(ln_islem_no); 
            update cbs_islem
                        set durum = 'P',
                        tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
                        where numara=ln_islem_no; 
                        Exception

                        When Others then
                        log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;
        
          
    end if;           
 
 exception
 when others then
 log_at('pkg_kredi_pd_closing','1207', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); 
 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4669' ||  Pkg_Hata.getdelimiter|| pn_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 
end;

procedure sp_transfer_for_pd_closing(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number, pn_alis_tutari out number) is
 
 ln_musteri_no number; 
 ln_available_balance number;
 ls_account_currency cbs_hesap.doviz_kodu%type;
 ls_account_branch cbs_hesap.sube_kodu%type;
 ln_block_sum number;  --TemirlanT
 ln_bakiye number;  --TemirlanT
 ln_difference_amount number; --TemirlanT
 
 ln_islem_kod number;
 ln_islem_no number; 
 
 ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
 ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
 ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
 ls_loan_currency cbs_hesap_kredi.doviz_kodu%type;
 
 ls_kur_tipi CBS_ARBITRAJ_ISLEM.KUR_TIPI%type;
 ls_alis_doviz_kodu CBS_ARBITRAJ_ISLEM.ALIS_DOVIZ_KODU%type;
 ls_SATIS_DOVIZ_KODU CBS_ARBITRAJ_ISLEM.SATIS_DOVIZ_KODU%type;
 ls_RESIDENCY_CODE CBS_ARBITRAJ_ISLEM.RESIDENCY_CODE%type;
 ls_CITIZEN_CODE CBS_ARBITRAJ_ISLEM.CITIZEN_CODE%type;
 ls_TAX_NUMBER CBS_ARBITRAJ_ISLEM.TAX_NUMBER%type;
 ls_KUR_PARITE_SECIM CBS_ARBITRAJ_ISLEM.KUR_PARITE_SECIM%type;
 ln_ALIS_KURU CBS_ARBITRAJ_ISLEM.ALIS_KURU%type;
 ln_SATIS_KURU CBS_ARBITRAJ_ISLEM.SATIS_KURU%type;
 ln_ALIS_TUTARI CBS_ARBITRAJ_ISLEM.ALIS_TUTARI%type;
 ln_SATIS_TUTARI CBS_ARBITRAJ_ISLEM.SATIS_TUTARI%type;
 ln_ALIS_HESAP_NO CBS_ARBITRAJ_ISLEM.ALIS_HESAP_NO%type;
 ln_SATIS_HESAP_NO CBS_ARBITRAJ_ISLEM.SATIS_HESAP_NO%type;
 ls_NAME_SURNAME CBS_ARBITRAJ_ISLEM.NAME_SURNAME%type;
 ls_ACIKLAMA CBS_ARBITRAJ_ISLEM.ACIKLAMA%type;
 ls_ISTATISTIK_KODU_ALIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_ALIS%type;
 ls_ISTATISTIK_KODU_SATIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_SATIS%type;
 
 ln_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 --ls_related_acc_curr CBS_HESAP.DOVIZ_KODU%type;
 ln_related_acc_count number;
 
 ln_account_no CBS_HESAP.HESAP_NO%type;
 ln_currency CBS_HESAP.DOVIZ_KODU%type;
 ln_account_count number;   
 
 ln_parity CBS_ARBITRAJ_ISLEM.PARITE%type;
 ls_carp_bol_secimi CBS_ARBITRAJ_ISLEM.CARP_BOL_SECIMI%type;
 lb_buy_loan_currency boolean := false;
 lb_bought_amount boolean := false;
 ln_satis_hesap_avail_bal number;
 
 ls_explanation varchar2(100) := '3199 transaction pd closing';
 ls_bos_referans varchar2(100) := '';
 
 ln_lc_amount number;
 incorrect_related_account exception;
 ls_ISTATISTIK_KODU CBS_VIRMAN_ISLEM.ISTATISTIK_KODU%type;

begin
    ls_account_currency := pkg_hesap.HesaptanDovizKoduAl(pn_current_account);
    ln_musteri_no :=  pkg_hesap.HesaptanMusteriNoAl(pn_current_account);
    ls_account_branch := pkg_hesap.HesapSubeAl(pn_current_account);
    ls_loan_currency := pkg_hesap.HesaptanDovizKoduAl(pn_loan_account);
    
    

    ln_islem_kod := 1208;
    ln_islem_no:=CBS.pkg_tx.islem_no_al;
     
    ls_explanation := '??????? ? ' || pn_current_account || ' ?? ' || pn_alter_current_account || ' ??? ????????? ??????? (' || pn_loan_account || ')';
    
    
    ln_related_account := pn_alter_current_account;  
    -- BOM TemirlanT cbs-119
    begin         
        select bloke_tutari
        into ln_block_sum
        from cbs_bloke b
        where b.bloke_neden_kodu ='70'
        and b.durum_kodu = 'A' 
        and B.BLOKE_TUTARI > 0
        and hesap_no = pn_current_account;
    exception when no_data_found then
        ln_block_sum := 0; 
    end;
    ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(pn_current_account),2);
    ln_alis_tutari := pn_amount;
    if ln_block_sum > 0 then  
        if ln_block_sum > (ln_bakiye - ln_alis_tutari) then
            ln_difference_amount := ln_block_sum - (ln_bakiye - ln_alis_tutari);
            if ln_alis_tutari > ln_difference_amount then
                ln_alis_tutari := ln_alis_tutari - ln_difference_amount;
            else
                ln_alis_tutari := 0;
            end if;
        end if;
    end if;
    pn_alis_tutari := ln_alis_tutari;
    if pn_amount > 0 then
    -- EOM TemirlanT cbs-119
        if ln_related_account is not null and ln_related_account <> pn_current_account then
    
            pkg_tx1203.sp_urun_tur_sinif_al(pn_current_account, ln_related_account, ls_account_currency, null, ls_modul_tur_kod,ls_urun_tur_kod, ls_urun_sinif_kod);
            pkg_parametre.deger('ISTAT_KODU_B2B_FOR_PD_CLOSING', ls_ISTATISTIK_KODU );
            insert into CBS_VIRMAN_ISLEM (TX_NO                   ,
                                      BORC_HESAP_NO           ,
                                      DOVIZ_KODU              ,
                                      TUTAR                   ,
                                      ALACAK_HESAP_NO         ,
                                      ACIKLAMA                ,
                                      BORC_EXTERNAL_HESAP     ,
                                      BORC_VERGI_NO           ,
                                      ALACAK_EXTERNAL_HESAP   ,
                                      ALACAK_VERGI_NO         ,
                                      ISTATISTIK_KODU         ,
                                      CHARGE_AMOUNT           )
            values (ln_islem_no, 
                 pn_current_account,
                 ls_account_currency,
                 ln_alis_tutari,
                 ln_related_account,
                 ls_explanation,
                 pkg_hesap.External_HesapNo_Al(pn_current_account),
                 PKG_MUSTERI.Sf_VergiNo_Al(ln_musteri_no),
                 pkg_hesap.External_HesapNo_Al(ln_related_account),
                 PKG_MUSTERI.Sf_VergiNo_Al(ln_musteri_no),
                 ls_ISTATISTIK_KODU,
                 0); 
                       
               -- 1.  Create user session
                cbs.PKG_BAGLAM.YARAT(
                ls_account_branch,    --branch code of the CBS user (refers to the table CBS_BOLUM column KODU)
                '0' --role of the CBS user (refers to the table CBS_ROL column NUMARA)
                );
          
            begin                     
            Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                                  KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                                  KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                                  MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                                  MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                          values (ln_islem_no,ln_islem_kod,'N',pkg_baglam.bolum_kodu,
                                  pkg_baglam.kullanici_kodu,pkg_baglam.rol_numara,pkg_baglam.bolum_kodu,
                                  pkg_muhasebe.banka_tarihi_bul,sysdate,
                                  ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,
                                  ln_musteri_no,ln_alis_hesap_no,ln_ALIS_TUTARI,null,ls_alis_doviz_kodu
                              );              
                              
            update cbs_islem_gecici
                   set durum = 'C'
                 where numara=ln_islem_no;
            Exception
                   When Others Then
                    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);     
            end ;          
            
            Giris_Kontrol(ln_islem_no);     
            
            begin
            PKG_TX1203.KONTROL_SONRASI(ln_islem_no);
            Exception

                        When Others then
                        log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;  
            begin
            PKG_TX1203.ONAY_SONRASI(ln_islem_no);

                        Exception

                        When Others then
                        log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;     
            begin
            PKG_TX1203.MUHASEBELESME(ln_islem_no);
            update cbs_islem
                        set durum = 'P',
                        tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
                        where numara=ln_islem_no;

                        Exception

                        When Others then
                        log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;
    /*else
       raise incorrect_related_account; */  
        end if;
    end if;   --TemirlanT cbs-119       

 
 exception
 when incorrect_related_account then
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4671' ||  Pkg_Hata.getdelimiter|| pn_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 when others then
     log_at('pkg_kredi_pd_closing','1203', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); 
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4672' ||  Pkg_Hata.getdelimiter|| pn_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 
end;



    function arbitraj_kur( ps_account_currency varchar2, 
                            ps_past_due_currency varchar2, 
                            pn_available_amount number, 
                            ps_account_branch varchar2, 
                            pb_buy_loan_currency boolean default false,
                            pb_bought_amount boolean default false) return number
                            
    is
    
    ls_alis_doviz_kodu CBS_ARBITRAJ_ISLEM.ALIS_DOVIZ_KODU%type;
    ls_SATIS_DOVIZ_KODU CBS_ARBITRAJ_ISLEM.SATIS_DOVIZ_KODU%type;
    ln_ALIS_TUTARI CBS_ARBITRAJ_ISLEM.ALIS_TUTARI%type;
    ln_SATIS_TUTARI CBS_ARBITRAJ_ISLEM.SATIS_TUTARI%type;
    ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
    ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
    ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
    ls_account_branch cbs_hesap.sube_kodu%type;
    ln_ALIS_KURU CBS_ARBITRAJ_ISLEM.ALIS_KURU%type;
    ln_SATIS_KURU CBS_ARBITRAJ_ISLEM.SATIS_KURU%type;
    ln_parity CBS_ARBITRAJ_ISLEM.PARITE%type;
    ls_carp_bol_secimi CBS_ARBITRAJ_ISLEM.CARP_BOL_SECIMI%type;
    ls_KUR_PARITE_SECIM CBS_ARBITRAJ_ISLEM.KUR_PARITE_SECIM%type;
    exception_not_arbitraj exception;
 
    begin

    if pb_buy_loan_currency = true then 
        ls_alis_doviz_kodu := ps_past_due_currency;
        ls_satis_doviz_kodu := ps_account_currency; 
    elsif pb_buy_loan_currency = false then
        ls_alis_doviz_kodu := ps_account_currency;
        ls_satis_doviz_kodu := ps_past_due_currency;   
    end if;        
    
    if ls_alis_doviz_kodu <> pkg_genel.lc_al and ls_satis_doviz_kodu <> pkg_genel.lc_al then
        ls_urun_sinif_kod  := 'FC-FC';
    end if;

    if pb_bought_amount = false then
        ln_ALIS_TUTARI := 0;
        ln_satis_TUTARI := pn_available_amount;
    elsif pb_bought_amount = true then
        ln_ALIS_TUTARI := pn_available_amount;
        ln_satis_TUTARI := 0;
    end if;

    ls_account_branch := ps_account_branch;

    ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
    ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);   

    if ls_urun_sinif_kod  = 'FC-FC' and ln_alis_kuru is not null and ln_satis_kuru is not null then
        if pb_bought_amount = false then
            ls_KUR_PARITE_SECIM := 'P';
            --USD---------------------------------
            if ls_alis_doviz_kodu = 'USD' then
                if ls_satis_doviz_kodu in ('TRY','CHF','CAD','CNY') then 
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('EUR','GBP','AUD') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);   
                    ls_carp_bol_secimi := 'CARP'; 
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);            
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                        ls_carp_bol_secimi := 'CARP';  
                    end if;    
                end if;
            end if;
                            
            --EUR---------------------------------
            if ls_alis_doviz_kodu = 'EUR' then
                if ls_satis_doviz_kodu in ('USD','GBP','TRY','CHF','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);  
                    ls_carp_bol_secimi := 'BOL'; 
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);  
                    ls_carp_bol_secimi := 'BOL';          
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';    
                    end if;    
                end if;
            end if;
                            
            --RUB---------------------------------
            if ls_alis_doviz_kodu = 'RUB' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','TRY','CHF','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'CARP'; 
                elsif ls_satis_doviz_kodu in ('KZT') then    
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);    
                        ls_carp_bol_secimi := 'CARP';
                    end if;    
                end if;
            end if;
                            
            --KZT---------------------------------
            if ls_alis_doviz_kodu = 'KZT' then
                if ls_satis_doviz_kodu in ('USD','EUR','RUB','GBP','TRY','CHF','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2); 
                    ls_carp_bol_secimi := 'CARP';
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';    
                    end if;    
                end if;
            end if;
                            
            --GBP---------------------------------
            if ls_alis_doviz_kodu = 'GBP' then
                if ls_satis_doviz_kodu in ('TRY','CHF','AUD','CNY','USD','CAD') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('EUR') then                            
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4); 
                    ls_carp_bol_secimi := 'CARP';   
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';          
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';    
                    end if;    
                end if;
            end if;
                                    
            --TRY---------------------------------
            if ls_alis_doviz_kodu = 'TRY' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD','CNY') then 
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';            
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                        ls_carp_bol_secimi := 'CARP';  
                    end if;    
                end if;
            end if;
                            
            --CHF---------------------------------
            if ls_alis_doviz_kodu = 'CHF' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('TRY','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';  
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';               
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';    
                    end if;    
                end if;
            end if;
                            
            --AUD---------------------------------
            if ls_alis_doviz_kodu = 'AUD' then
                if ls_satis_doviz_kodu in ('EUR','GBP','CHF') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('USD','TRY','CAD','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';  
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';               
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';    
                    end if;    
                end if;
            end if;
                            
            --CAD---------------------------------
            if ls_alis_doviz_kodu = 'CAD' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4); 
                    ls_carp_bol_secimi := 'CARP'; 
                elsif ls_satis_doviz_kodu in ('TRY','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';  
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';               
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';    
                    end if;    
                end if;
            end if;
                            
            --CNY---------------------------------
            if ls_alis_doviz_kodu = 'CNY' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('TRY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';  
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';               
                else 
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else     
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';    
                    end if;    
                end if;
            end if;
            
            if ls_carp_bol_secimi = 'CARP' then
               ln_ALIS_TUTARI := round((nvl(ln_SATIS_TUTARI,0) * ln_parity),2) ;
            else
               ln_ALIS_TUTARI := round((nvl(ln_SATIS_TUTARI,0) / ln_parity),2);
            end if;
            
            return ln_ALIS_TUTARI; 
            
        elsif pb_bought_amount = true then
        
            ls_KUR_PARITE_SECIM := 'P';
                --USD---------------------------------
                if ls_alis_doviz_kodu = 'USD' then
                    if ls_satis_doviz_kodu in ('TRY','CHF','CAD','CNY') then 
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('EUR','GBP','AUD') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);   
                        ls_carp_bol_secimi := 'BOL'; 
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);            
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                            ls_carp_bol_secimi := 'CARP';  
                        end if;    
                    end if;
                end if;
                                
                --EUR---------------------------------
                if ls_alis_doviz_kodu = 'EUR' then
                    if ls_satis_doviz_kodu in ('USD','GBP','TRY','CHF','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);  
                        ls_carp_bol_secimi := 'CARP'; 
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);  
                        ls_carp_bol_secimi := 'CARP';          
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';    
                        end if;    
                    end if;
                end if;
                                
                --RUB---------------------------------
                if ls_alis_doviz_kodu = 'RUB' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','TRY','CHF','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'BOL'; 
                    elsif ls_satis_doviz_kodu in ('KZT') then    
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);    
                            ls_carp_bol_secimi := 'CARP';
                        end if;    
                    end if;
                end if;
                                
                --KZT---------------------------------
                if ls_alis_doviz_kodu = 'KZT' then
                    if ls_satis_doviz_kodu in ('USD','EUR','RUB','GBP','TRY','CHF','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2); 
                        ls_carp_bol_secimi := 'BOL';
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                            ls_carp_bol_secimi := 'CARP';    
                        end if;    
                    end if;
                end if;
                                
                --GBP---------------------------------
                if ls_alis_doviz_kodu = 'GBP' then
                    if ls_satis_doviz_kodu in ('TRY','CHF','AUD','CNY','USD','CAD') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('EUR') then                            
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4); 
                        ls_carp_bol_secimi := 'BOL';   
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';          
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';    
                        end if;    
                    end if;
                end if;
                                        
                --TRY---------------------------------
                if ls_alis_doviz_kodu = 'TRY' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD','CNY') then 
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';            
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                            ls_carp_bol_secimi := 'CARP';  
                        end if;    
                    end if;
                end if;
                                
                --CHF---------------------------------
                if ls_alis_doviz_kodu = 'CHF' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('TRY','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';  
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';               
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';    
                        end if;    
                    end if;
                end if;
                                
                --AUD---------------------------------
                if ls_alis_doviz_kodu = 'AUD' then
                    if ls_satis_doviz_kodu in ('EUR','GBP','CHF') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('USD','TRY','CAD','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';  
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';               
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';    
                        end if;    
                    end if;
                end if;
                                
                --CAD---------------------------------
                if ls_alis_doviz_kodu = 'CAD' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4); 
                        ls_carp_bol_secimi := 'BOL'; 
                    elsif ls_satis_doviz_kodu in ('TRY','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';  
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';               
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';    
                        end if;    
                    end if;
                end if;
                                
                --CNY---------------------------------
                if ls_alis_doviz_kodu = 'CNY' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);  
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('TRY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';  
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';               
                    else 
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else     
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';    
                        end if;    
                    end if;
                end if;
                
                if ls_carp_bol_secimi = 'CARP' then
                   ln_SATIS_TUTARI := round((nvl(ln_ALIS_TUTARI,0) * ln_parity),2) ;
                else
                   ln_SATIS_TUTARI := round((nvl(ln_ALIS_TUTARI,0) / ln_parity),2);
                end if;
                
                return ln_SATIS_TUTARI; 
        
        end if;
        
    else
    
    raise exception_not_arbitraj;    
        
    end if;
       
    exception when exception_not_arbitraj then
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1001' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);        
    
    when others then 
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1004' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

    end;
    
Procedure Giris_Kontrol(pn_islem_no number) is

   lc_dogrulama                varchar2(1);
   lc_onay                     varchar2(1);
   lc_iptal_onay            varchar2(1);
   lc_dogrula_guncelle  varchar2(1);
   lc_onay_guncelle     varchar2(1);

   cursor c1 is
    select rui.dogrulama,rui.onay,rui.dogrula_guncelle,rui.onayla_guncelle,rui.iptal_onay
      from cbs_rol_urun_islem rui,cbs_islem,cbs_zaman,cbs_limit
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum IN ('N')
       and cbs_islem.islem_kod      = rui.islem_tanim_kod
       and cbs_islem.modul_tur_kod  = rui.modul_tur_kod
       and cbs_islem.urun_tur_kod   = rui.urun_tur_kod
       and cbs_islem.urun_sinif_kod = rui.urun_sinif_kod
       and rui.rol_numara       = 0
       and rui.zaman_numara     = cbs_zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = cbs_limit.numara
       and ( ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'S' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between alt and ust)  or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'F' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,ust) ) or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'L' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,ust) ) or
               ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'F'
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'L'
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( cbs_limit.karsilik = 'N' )
             );

   Begin
        Begin
       open c1;
       loop
          fetch c1 into lc_dogrulama,lc_onay,lc_dogrula_guncelle,lc_onay_guncelle,lc_iptal_onay;
          exit when c1%notfound;
          pkg_tx.Kilit_Test(pn_islem_no);

          update cbs_islem
            set durum           = 'C' ,
                dogrulanmali_mi = lc_dogrulama,
                onaylanmali_mi  = lc_onay,
                iptal_onaylanmali_mi=lc_iptal_onay,
                dogrula_guncelle = lc_dogrula_guncelle,
                onay_guncelle = lc_onay_guncelle
          where numara=pn_islem_no;

        return;
       end loop;
       close c1;
     Exception
          When Others Then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'62'|| pkg_hata.getDELIMITER ||TO_CHAR(SQLCODE)|| ' ' || replace(SQLERRM,'***','')||pkg_hata.getDELIMITER ||pkg_hata.getUCPOINTER);
     End;
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'61'|| pkg_hata.getDELIMITER ||TO_CHAR(SQLCODE)|| ' ' || replace(SQLERRM,'***','')||pkg_hata.getDELIMITER ||pkg_hata.getUCPOINTER);
   End;

  FUNCTION what_month(pd_date date) RETURN varchar2
  IS 
    ls_month varchar2(20);
    ls_G_PD_WHAT_MONTH_EXPLANATION varchar2(200);
    begin
        Pkg_Parametre.deger('G_PD_WHAT_MONTH_EXPLANATION',ls_G_PD_WHAT_MONTH_EXPLANATION);
        --?????? ??????? ???? ?????? ??? ???? ???? ?????? ???????? ??????? ?????? ???????
        if to_number(to_char(pd_date, 'MM'))=1 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 1, 6);
        elsif to_number(to_char(pd_date, 'MM'))=2 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 8, 7);
        elsif to_number(to_char(pd_date, 'MM'))=3 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 16, 4);
        elsif to_number(to_char(pd_date, 'MM'))=4 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 21, 6);
        elsif to_number(to_char(pd_date, 'MM'))=5 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 28, 3);
        elsif to_number(to_char(pd_date, 'MM'))=6 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 32, 4);
        elsif to_number(to_char(pd_date, 'MM'))=7 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 37, 4);
        elsif to_number(to_char(pd_date, 'MM'))=8 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 42, 6);
        elsif to_number(to_char(pd_date, 'MM'))=9 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 49, 8);
        elsif to_number(to_char(pd_date, 'MM'))=10 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 58, 7);
        elsif to_number(to_char(pd_date, 'MM'))=11 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 66, 6);
        elsif to_number(to_char(pd_date, 'MM'))=12 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 73, 7);
        end if;
        return ls_month;
    end;

--EOM aisuluud cq4883
-- B-O-M seval.colak 09052021 
 function sf_dk_grup_kod_al ( pn_musteri_no cbs_musteri.musteri_no%type ) return cbs_musteri.dk_grup_kod%type
  is
    ls_kod cbs_musteri.dk_grup_kod%type;
  begin
      select dk_grup_kod
    into   ls_kod
    from   cbs_musteri
    where  musteri_no  = pn_musteri_no ;

    return ls_kod;
  exception
       when others then return null;
  END;
-- E-O-M seval.colak 09052021
 -----------------------------------------------------------------------------------------------
 -- seval.colak 23082021
   FUNCTION SF_FAIZ_TAHAKKUK_HESAP_NO_AL(pn_hesap_no  NUMBER) RETURN NUMBER IS
    ln_FAIZ_TAHAKKUK_HESAP_NO NUMBER ;
  BEGIN

		SELECT ACCRUAL_INT_ACCOUNT_NO
		INTO   ln_FAIZ_TAHAKKUK_HESAP_NO
		FROM   CBS_HESAP_KREDI
		WHERE  hesap_no = pn_hesap_no ;


        RETURN  ln_FAIZ_TAHAKKUK_HESAP_NO ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     RETURN NULL;
  END;
-----------------------------------------------------------------------------------------------  
  FUNCTION SF_VERGI_TAHAKKUK_HESAP_NO_AL(pn_hesap_no  NUMBER) RETURN NUMBER IS
    ln_VERGI_TAHAKKUK_HESAP_NO NUMBER ;
  BEGIN

		SELECT ACCRUAL_TAX_ACCOUNT_NO
		INTO   ln_VERGI_TAHAKKUK_HESAP_NO
		FROM   CBS_HESAP_KREDI
		WHERE  hesap_no = pn_hesap_no ;


        RETURN  ln_VERGI_TAHAKKUK_HESAP_NO ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     RETURN NULL;
  END;
  
  -----------------------------------------------------------------------------------------------------
  --B-o-m seval.colak 05102022
     procedure sp_hesap_iptaloncetaksitkntr(pn_islem_no number)
   is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
    ln_sira_no                number := 0;
    ls_durum                varchar2(2000);
    ls_taksit_durum            varchar2(2000);
    ls_geriodeme             varchar2(2000);
    ln_taksit                number := 0;
    hesap_durum_uygundegil    exception;
    taksitdurum_uygundegil  exception;

     cursor cur_hesap is
      select *
        from cbs_hesap_kredi_islem
       where tx_no=pn_islem_no;

        cursor cursor_taksit is
        select *
        from cbs_hesap_kredi_taksit_islem
        where     tx_no = pn_islem_no and
                taksit_secildi = 'E'
        order by sira_no desc    ;

    Begin
           for c_hesap in cur_hesap loop
            ln_hesap_no := c_hesap.hesap_no ;
            ls_geriodeme := c_hesap.geriodeme_kapama_secimi;
        end loop;

        if ls_geriodeme !=  'KAPAMA' then
               ls_durum := pkg_kredi.sf_kredi_hesap_durumu_al(ln_hesap_no);
            if ls_durum != 'A' then
               raise  hesap_durum_uygundegil;
            end if;
        end if;
/* taksitlerin durum kodu uygun mu */
--  b-o-m seval.colak 30052022 kismi tahsilatda soruna yol aciyor. kapatildi.
      /*   for cur_taksit in cursor_taksit loop
              ln_sira_no := cur_taksit.sira_no;
           ln_taksit  := 0;
           ls_taksit_durum:= pkg_bireysel_kredi.sf_taksit_durumu_al( cur_taksit.hesap_no,cur_taksit.sira_no);
              if  ls_taksit_durum not in( 'T','O','K') Then
                 raise taksitdurum_uygundegil; 
            end if;
      end loop;
    */
   Exception
       When hesap_durum_uygundegil then
        raise_application_error(-20100,pkg_hata.getucpointer || '906' || pkg_hata.getDelimiter || ls_durum ||  pkg_hata.getDelimiter || pkg_hata.getucpointer);
       When    taksitdurum_uygundegil then
       raise_application_error(-20100,pkg_hata.getucpointer || '907' ||  pkg_hata.getDelimiter || to_char(ln_sira_no) || pkg_hata.getDelimiter ||  ls_taksit_durum  || pkg_hata.getDelimiter|| pkg_hata.getucpointer);
       When others then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '908' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' ||to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
   End;

  Function sf_iptal_edilebilirmi(pn_islem_no number ,pn_hesap_no number) return number
 is
  ln_tx_no number := 0 ;
  iptaledilemez            exception;
 Begin

       select max(numara)
      into   ln_tx_no
      from  cbs_islem
      where   durum  not in ('R','2') and
               islem_kod in( 3251,1323,1306,3252) and
             numara > pn_islem_no and
             hesap_numara = pn_hesap_no;

      if nvl(ln_tx_no,0) <> 0 then
        raise iptaledilemez;
      end if;

   return ln_tx_no ;

   Exception
    When iptaledilemez then
        raise_application_error(-20100,pkg_hata.getucpointer || '905' || pkg_hata.getDelimiter || to_char( ln_tx_no ) ||  pkg_hata.getDelimiter || pkg_hata.getucpointer);
        return ln_tx_no ;
     when others   then return 0;
 End;
 
   Procedure Iptal_Onay_Sonrasi(pn_islem_no number)
  is
     cursor cur_hesap is
      select *
        from cbs_hesap_kredi_islem
       where tx_no=pn_islem_no;

/* sadece secilmis degil isleme giren tum taksitleri alinir. kredi vade guncellemesi yapilir*/
    cursor cursor_taksit is
    select *
    from cbs_hesap_kredi_taksit_islem
    where     tx_no = pn_islem_no;

    r_hesap      cur_hesap%rowtype;
    ln_numara     number := 0;
    ln_txno         number := 0;
  Begin

 /* islem bilgisi detaylari alinir */
          open cur_hesap;
         fetch cur_hesap into r_hesap;
        close cur_hesap;

   ln_numara := sf_iptal_edilebilirmi(pn_islem_no , r_hesap.hesap_no) ;
   sp_hesap_iptaloncetaksitkntr(pn_islem_no);

    ln_txno := Pkg_Kredi.sf_islemvarsa_uyar(pn_islem_no,
                                 r_hesap.hesap_no      );
                                 
    
  -- B-O-M   seval.colak 04022022   
    if nvl(r_hesap.odeme_plan_no,0) <> 0 then 
        update cbs_odeme_plan
        set  durum_kodu ='A',
             kapanis_tarihi = NULL
        where odeme_plan_No = r_hesap.odeme_plan_no;
     end if;
     --E-O-M   seval.colak 04022022 
     
        update cbs_hesap_kredi
       set (    DURUM_KODU,  
                KREDI_VADE	,
                KREDI_KULLANDIRIM_KODU	,
                ENDEKS_DOVIZ_KODU	,
                KULLANDIRIM_DOVIZ_KODU	,
                SON_GUN_FAIZI	,
                ACILIS_KURU	,
                FAIZ_ORANI	,
                FAIZ_SIKLIK	,
                FAIZ_SIKLIK_TIPI	,
                FAIZ_TAHAKKUK_TARIHI	,
                KOMISYON_ORANI	,
                KOMISYON_TUTARI	,
                KOMISYON_TAHSILAT_DONEMI	,
                FON_ORANI	,
                BSMV_ORANI	,
                ALACAK_HESAP_NO	,
                ILISKILI_HESAP_NO	,
                KUR_FARKI	,
                EXTRE_MASRAFI	,
                SINIRLAMA_KODU	,
                KAYNAK_KODU	,
                ISTATISTIK_KODU	,
                URUN_GRUP_NO	,
                REFERANS	,
                FAIZ_TAHAKKUK_HESAP_NO	,
                VERGI_TAHAKKUK_HESAP_NO	,
                BIRIKMIS_FAIZ_TUTARI	,
                BIRIKMIS_KOMISYON_TUTARI	,
                ESAS_GUN_SAYISI	,
                ACILIS_TARIHI	,
                KAPANIS_TARIHI	,
                BSMV_ALINSIN	,
                KKDF_ALINSIN	,
                ENDEKS_DOVIZ_TUTARI	,
                GECENYIL_FAIZ_TUTARI	,
                TAHSILEDILEN_FAIZ_TUTARI	,
                TAHSILEDILEN_KOMISYON_TUTARI	,
                GECENYIL_KOMISYON_TUTARI	,
                BIRIKMIS_SCH_FAIZI	,
                GECENYIL_SCH_FAIZI	,
                SON_ISLEM_KURU	,
                GECENYIL_ANAPARAKURFARK_GELIR	,
                GECENYIL_ANAPARAKURFARK_ZARAR	,
                GECENYIL_FAIZKURFARK_GELIR	,
                GECENYIL_FAIZKURFARK_ZARAR	,
                GECENYIL_KOMISKURFARK_GELIR	,
                GECENYIL_KOMISKURFARK_ZARAR	,
                FAIZ_BASLANGIC_TARIHI	,
                SCH_FAIZ_ORANI	,
                ESKI_HESAP_NO	,
                ESKI_HESAP_EKNO	,
                ESKI_FAIZHESAP_EKNO	,
                ESKI_KOMHESAP_EKNO	,
                BIRIKMIS_FAIZ_TUTARI_ROUND	,
                BIRIKMIS_KOMISYON_TUTARI_ROUND	,
                AYS_BIRIKMIS_FAIZ_TUTARI_ROUND	,
                AYS_BIRIKMIS_KOMISYON_TUTARI_R	,
                KREDI_TURU	,
                TAKSIT_SAYISI	,
                TAKSIT_ONCE_SONRA	,
                ARTIS_SIKLIK	,
                ARTIS_ORAN	,
                ARA_ODEME_SIKLIK	,
                ARA_ODEME_TUTAR	,
                DONEM_SIKLIK	,
                ODEME_TURU	,
                SCH_FAIZ_TUR	,
                TEMDIT_TARIHI	,
                TAHAKKUK_SCH_FAIZ_TUTARI	,
                REPAYMENT_TYPE	,
                PREFIX_ISTATISTIK_KODU	,
                PREFIX_ISTATISTIK_KODU_FAIZ	,
                ISTATISTIK_KODU_FAIZ	,
                PREFIX_ISTATISTIK_KODU_KAPAMA	,
                ISTATISTIK_KODU_KAPAMA	,
                TAHSILEDILEN_FAIZ_TUTARI_LC	,
                TAHSILEDILEN_KOMIS_TUTARI_LC	,
                ANA_KREDI_HESAP_NO	,
                PASTDUE_FAIZ_ANAPARA_SEC	,
                ACILIS_KREDI_VADE	,
                PASTDUE_FAIZ_ORANI	,
                ESKI_HESAP_REFNO	,
                YEARLY_INT_RATE	,
                ESKI_DK_NO	,
                ALACAK_SECIMI	,
                ALACAK_DK_NO	,
                DISBURSEMENT_COMMISSION	,
                COMMISSION_ACCOUNT_NO	,
                GECMISYIL_TAHSIL_KOM_TOPLAMI	,
                GECMISYIL_TAHSIL_FAIZ_TOPLAMI	,
                GECMISYIL_TAHAKKUK_SCH_FAIZ	,
                CONTRACT_STATUS	,
                GECMIS_AYLARIN_FAIZI	,
                GECMIS_AYLARIN_KOMISYONU	,
                TAKSIT_BASLANGIC_TARIHI	,
                EK_TAKSIT_FAIZ	,
                REPORT_CUSTOMER_TYPE	,
                ACCRUED_INTEREST_TAX	,
                ACCRUED_COMMISSION_TAX	,
                APP_NO	,
                LOAN_NUMARA	,
                AGREEMENT_DATE	,
                AGREEMENT_NO	,               
                TRANSACTION_TYPE	,
                YEARLY_EFFECTIVE_INT_RATE	,
                PENALTY_AMOUNT	,
                NON_ACCRUAL_STATUS	,
                ODEME_PLAN_NO	,
                ODEME_GUNU	,
                TAKSIT_SIKLIK	,
                ODEMESIZ_AY_SAYISI	,
                FAIZ_YONTEMI_METHODU	,
                FAIZ_HESAPLAMA_TIPI	,
                PENALTY_RATE	,
                BIRIKMIS_GECIKME_FAIZ_TUTARI	,
                TAHSIL_GECIKME_FAIZ_TUTARI	,
                PAID_PENALTY_AMOUNT	,
                ADVANCED_COMMISSION_TYPE	,
                ADVANCED_COMMISSION_RATE	,
                ADVANCED_COMMISSION_AMOUNT	,
                GECENYIL_GECIKME_FAIZ	,
                GECENAY_GECIKME_FAIZ	,
                GECIKME_FAIZ_ACCRUEDTAX	,
                ACCRUAL_INT_ACCOUNT_NO	,
                ACCRUAL_TAX_ACCOUNT_NO	,
                ACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                NONACCRUAL_INT_ACCOUNT_NO	,
                NONACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                AP_GECIKME_GUN_SAYISI	,
                FAIZ_GECIKME_GUN_SAYISI	,
                LLP_RATE	,
                FAIZ_ORANI_TIPI	,
                MONTHLY_INT_RATE	,
                NON_ACCRUAL_STATUS_UPD_DATE	,
                accrual_status_upd_date -- seval.colak 02112022
                 )
                           = 
                (select DURUM_KODU,
                KREDI_VADE	,
                KREDI_KULLANDIRIM_KODU	,
                ENDEKS_DOVIZ_KODU	,
                KULLANDIRIM_DOVIZ_KODU	,
                SON_GUN_FAIZI	,
                ACILIS_KURU	,
                FAIZ_ORANI	,
                FAIZ_SIKLIK	,
                FAIZ_SIKLIK_TIPI	,
                FAIZ_TAHAKKUK_TARIHI	,
                KOMISYON_ORANI	,
                KOMISYON_TUTARI	,
                KOMISYON_TAHSILAT_DONEMI	,
                FON_ORANI	,
                BSMV_ORANI	,
                ALACAK_HESAP_NO	,
                ILISKILI_HESAP_NO	,
                KUR_FARKI	,
                EXTRE_MASRAFI	,
                SINIRLAMA_KODU	,
                KAYNAK_KODU	,
                ISTATISTIK_KODU	,
                URUN_GRUP_NO	,
                REFERANS	,
                FAIZ_TAHAKKUK_HESAP_NO	,
                VERGI_TAHAKKUK_HESAP_NO	,
                BIRIKMIS_FAIZ_TUTARI	,
                BIRIKMIS_KOMISYON_TUTARI	,
                ESAS_GUN_SAYISI	,
                ACILIS_TARIHI	,
                KAPANIS_TARIHI	,
                BSMV_ALINSIN	,
                KKDF_ALINSIN	,
                ENDEKS_DOVIZ_TUTARI	,
                GECENYIL_FAIZ_TUTARI	,
                TAHSILEDILEN_FAIZ_TUTARI	,
                TAHSILEDILEN_KOMISYON_TUTARI	,
                GECENYIL_KOMISYON_TUTARI	,
                BIRIKMIS_SCH_FAIZI	,
                GECENYIL_SCH_FAIZI	,
                SON_ISLEM_KURU	,
                GECENYIL_ANAPARAKURFARK_GELIR	,
                GECENYIL_ANAPARAKURFARK_ZARAR	,
                GECENYIL_FAIZKURFARK_GELIR	,
                GECENYIL_FAIZKURFARK_ZARAR	,
                GECENYIL_KOMISKURFARK_GELIR	,
                GECENYIL_KOMISKURFARK_ZARAR	,
                FAIZ_BASLANGIC_TARIHI	,
                SCH_FAIZ_ORANI	,
                ESKI_HESAP_NO	,
                ESKI_HESAP_EKNO	,
                ESKI_FAIZHESAP_EKNO	,
                ESKI_KOMHESAP_EKNO	,
                BIRIKMIS_FAIZ_TUTARI_ROUND	,
                BIRIKMIS_KOMISYON_TUTARI_ROUND	,
                AYS_BIRIKMIS_FAIZ_TUTARI_ROUND	,
                AYS_BIRIKMIS_KOMISYON_TUTARI_R	,
                KREDI_TURU	,
                TAKSIT_SAYISI	,
                TAKSIT_ONCE_SONRA	,
                ARTIS_SIKLIK	,
                ARTIS_ORAN	,
                ARA_ODEME_SIKLIK	,
                ARA_ODEME_TUTAR	,
                DONEM_SIKLIK	,
                ODEME_TURU	,
                SCH_FAIZ_TUR	,
                TEMDIT_TARIHI	,
                TAHAKKUK_SCH_FAIZ_TUTARI	,
                REPAYMENT_TYPE	,
                PREFIX_ISTATISTIK_KODU	,
                PREFIX_ISTATISTIK_KODU_FAIZ	,
                ISTATISTIK_KODU_FAIZ	,
                PREFIX_ISTATISTIK_KODU_KAPAMA	,
                ISTATISTIK_KODU_KAPAMA	,
                TAHSILEDILEN_FAIZ_TUTARI_LC	,
                TAHSILEDILEN_KOMIS_TUTARI_LC	,
                ANA_KREDI_HESAP_NO	,
                PASTDUE_FAIZ_ANAPARA_SEC	,
                ACILIS_KREDI_VADE	,
                PASTDUE_FAIZ_ORANI	,
                ESKI_HESAP_REFNO	,
                YEARLY_INT_RATE	,
                ESKI_DK_NO	,
                ALACAK_SECIMI	,
                ALACAK_DK_NO	,
                DISBURSEMENT_COMMISSION	,
                COMMISSION_ACCOUNT_NO	,
                GECMISYIL_TAHSIL_KOM_TOPLAMI	,
                GECMISYIL_TAHSIL_FAIZ_TOPLAMI	,
                GECMISYIL_TAHAKKUK_SCH_FAIZ	,
                CONTRACT_STATUS	,
                GECMIS_AYLARIN_FAIZI	,
                GECMIS_AYLARIN_KOMISYONU	,
                TAKSIT_BASLANGIC_TARIHI	,
                EK_TAKSIT_FAIZ	,
                REPORT_CUSTOMER_TYPE	,
                ACCRUED_INTEREST_TAX	,
                ACCRUED_COMMISSION_TAX	,
                APP_NO	,
                LOAN_NUMARA	,
                AGREEMENT_DATE	,
                AGREEMENT_NO	,
                TRANSACTION_TYPE	,
                YEARLY_EFFECTIVE_INT_RATE	,
                PENALTY_AMOUNT	,
                NON_ACCRUAL_STATUS	,
                ODEME_PLAN_NO	,
                ODEME_GUNU	,
                TAKSIT_SIKLIK	,
                ODEMESIZ_AY_SAYISI	,
                FAIZ_YONTEMI_METHODU	,
                FAIZ_HESAPLAMA_TIPI	,
                PENALTY_RATE	,
                BIRIKMIS_GECIKME_FAIZ_TUTARI	,
                TAHSIL_GECIKME_FAIZ_TUTARI	,
                PAID_PENALTY_AMOUNT	,
                ADVANCED_COMMISSION_TYPE	,
                ADVANCED_COMMISSION_RATE	,
                ADVANCED_COMMISSION_AMOUNT	,
                GECENYIL_GECIKME_FAIZ	,
                GECENAY_GECIKME_FAIZ	,
                GECIKME_FAIZ_ACCRUEDTAX	,
                ACCRUAL_INT_ACCOUNT_NO	,
                ACCRUAL_TAX_ACCOUNT_NO	,
                ACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                NONACCRUAL_INT_ACCOUNT_NO	,
                NONACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                AP_GECIKME_GUN_SAYISI	,
                FAIZ_GECIKME_GUN_SAYISI	,
                LLP_RATE	,
                FAIZ_ORANI_TIPI	,
                MONTHLY_INT_RATE	,
                NON_ACCRUAL_STATUS_UPD_DATE	,
                accrual_status_upd_date -- seval.colak 02112022
                from cbs_hesap_kredi_onayonce_isl
                where tx_no = pn_islem_no)
       where hesap_no = r_hesap.hesap_no  ;

     BEGIN
           DELETE  FROM CBS_HESAP_KREDI_TAKSIT
          WHERE hesap_no =  r_hesap.hesap_no ;

          insert into cbs_hesap_kredi_taksit( yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
                            taksit_gun_sayisi	,hesaplama_gun_sayisi	,taksit_baz_anapara	,taksit_faiz_orani	,taksit_bsmv_orani	,taksit_kkdf_orani	,ozel_odeme_tutari	,orj_vergi_tutari	,orj_faiz_tutari	,ek_faiz_tutari	,
                             deferred_interest	,deferred_tax	,paid_deferred_interest	,paid_deferred_tax	,tahsil_taksit	,tahsil_anapara	,tahsil_faiz	,tahsil_kkdf	,tahsil_bsmv	,tahsil_gecikme_faiz_tutari	,deferred_tax2	,paid_deferred_tax2	,tahakkuk_eh	,
                            penalty_amount	,paid_penalty_amount	,deferred_penalty_amount	,paid_deferred_penalty_amount	,ap_gecikme_gun_sayisi	,faiz_gecikme_gun_sayisi	,deferred_delayed_interest	,paid_deferred_delayed_interest	,paid_deferred_penalty_tax	,paid_nonaccrual_deferred_tax	,paid_nonaccrual_deferred_delay_tax	)
          select    nvl(yaratan_tx_no,pn_islem_no), hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
                      taksit_gun_sayisi	,hesaplama_gun_sayisi	,taksit_baz_anapara	,taksit_faiz_orani	,taksit_bsmv_orani	,taksit_kkdf_orani	,ozel_odeme_tutari	,orj_vergi_tutari	,orj_faiz_tutari	,ek_faiz_tutari	,
                      deferred_interest	,deferred_tax	,paid_deferred_interest	,paid_deferred_tax	,tahsil_taksit	,tahsil_anapara	,tahsil_faiz	,tahsil_kkdf	,tahsil_bsmv	,tahsil_gecikme_faiz_tutari	,deferred_tax2	,paid_deferred_tax2	,tahakkuk_eh	,
                      penalty_amount	,paid_penalty_amount	,deferred_penalty_amount	,paid_deferred_penalty_amount	,ap_gecikme_gun_sayisi	,faiz_gecikme_gun_sayisi	,deferred_delayed_interest	,paid_deferred_delayed_interest	,paid_deferred_penalty_tax	,paid_nonaccrual_deferred_tax	,paid_nonaccrual_deferred_delay_tax
          from cbs_hesap_kredi_taks_onay_isl
             where tx_no = pn_islem_no;
             
         EXCEPTION WHEN OTHERS THEN NULL;
     END;

          begin
             delete from CBS_HESAP_KREDI_OZEL_TKST
            where hesap_no =r_hesap.hesap_no;

            insert into  CBS_HESAP_KREDI_OZEL_TKST (YARATAN_TX_NO, HESAP_NO, TAKSIT_SIRA_NO, ODEME, YARATILDIGI_TARIH, YARATAN_KULLANICI,TAKSIT_TIPI)  --seval.colak 20012022
            select  YARATAN_TX_NO, HESAP_NO, TAKSIT_SIRA_NO, ODEME, YARATILDIGI_TARIH, YARATAN_KULLANICI,TAKSIT_TIPI--seval.colak 20012022
            from   CBS_HESAP_KREDI_OZLTKSTONAYISL
            where tx_no = pn_islem_no ;

       exception when others then null;
       end ;
   -- B-O-M seval.colak 30052022
   BEGIN 
   
   delete from cbs_kredi_tahakkuk
   where kredi_hesap_no = r_hesap.hesap_no ;
   
     insert into cbs_kredi_tahakkuk(
        banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	)
        select 
         banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	
        from cbs_kredi_tahakkuk_onay_on_isl
        where islem_no = pn_islem_no and kredi_hesap_no=r_hesap.hesap_no;
        
        exception when others then null;
       end ;
     -- E-O-M seval.colak 30052022
     
     --b-o-m seval.colak 23062022 
   if r_hesap.GERIODEME_KAPAMA_SECIMI in ( 'KAPAMA') THEN   
      update cbs_hesap_kredi
      set     durum_kodu = 'A',
              kapanis_tarihi =NULL
      where hesap_no in ( r_hesap.accrual_int_account_no,
                         r_hesap.accrual_tax_account_no ,
                         r_hesap.accrual_delayed_int_account_no,
                         r_hesap.nonaccrual_int_account_no,
                         r_hesap.nonaccrual_delayed_int_account_no );
    end if;                     
     --e-o-m seval.colak 23062022  
       
                  
    begin
       Pkg_Kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
              exception when others then null;
       end ;
/* teminat islem Durum guncellenir */
    begin
    pkg_teminat.sp_teminat_iptalonaysonrasi(pn_islem_no,r_hesap.geriodeme_kapama_secimi);
       exception when others then null;
       end ;
   Exception
       When others then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '909' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' ||to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;
  --e-o-m seval.colak 05102022
  ------------------------------------------------------------------------------------
end;
/

