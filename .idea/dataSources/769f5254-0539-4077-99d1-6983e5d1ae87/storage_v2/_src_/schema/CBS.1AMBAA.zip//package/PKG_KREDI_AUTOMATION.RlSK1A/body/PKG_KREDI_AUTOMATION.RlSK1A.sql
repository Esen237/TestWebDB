create PACKAGE BODY     pkg_kredi_automation IS

PROCEDURE pastdue_closing_payment_main (pn_islem_numara number) IS

    ln_count_pastdue number;
    ln_job number;

 BEGIN
    SELECT COUNT(*)
        INTO ln_count_pastdue
        FROM cbs_hesap_kredi k
            RIGHT JOIN cbs_satir s
            ON k.musteri_no = pkg_hesap.hesaptanmusterinoal(s.hesap_numara) AND pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(s.hesap_numara)) IN (1, 2)
            AND s.fis_islem_numara = pn_islem_numara AND s.hesap_tur_kodu = 'VS' AND s.tur = 'A'
        WHERE k.durum_kodu = 'A' AND k.urun_tur_kod != 'PD-CARD' AND k.urun_sinif_kod NOT IN ('CRD.CARD-LC') AND k.pastdue_faiz_anapara_sec IS NOT NULL;

    IF (ln_count_pastdue > 0) THEN
        --log_at('timka_block', 1);
        PKG_KREDI_AUTOMATION.PASTDUE_BLOCKING(pn_islem_numara);
        --log_at('timka_block', 2);
        --dbms_job.submit (ln_job,'PKG_KREDI_AUTOMATION.pastdue_closing_payment('||pn_islem_numara||');', SYSDATE ,'sysdate+7', FALSE);
        --INSERT INTO CBS_PASTDUE_CLOSING_PAYMENT(TX_NO, JOB_NO) VALUES(pn_islem_numara, ln_job);
        --PKG_KREDI_AUTOMATION.pastdue_closing_payment(pn_islem_numara);
    END IF;
 END;

PROCEDURE pastdue_blocking (pn_islem_numara number) IS
    --PRAGMA autonomous_transaction;

    ln_islem_no number;
    ln_islem_kod number;
    ln_current_account number;
    lc_hesap_numara number;
    ls_account_currency varchar2(3);
    ls_account_branch varchar2(3);
    ln_customer_no number;
    ln_tx_amount number;
    ln_available_amount number;
    lb_masraf boolean;
    ld_blocking_date date;
    lc_kasa_kod varchar2(100);
    lc_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
    lc_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
    lc_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
    ln_related_account CBS_HESAP_KREDI.iliskili_hesap_no%type;
    ls_past_due_currency varchar2(3);
    ls_name_surname CBS_MUSTERI.ARAMA_ISIM%type;                   --TemirlanT
    ls_day  cbs_hesap_kredi_islem.aciklama%type;                   --TemirlanT
    ln_loan_account CBS_HESAP_KREDI.HESAP_NO%type;                 --TemirlanT
    ls_dk_explanation CBS_DKHESAP.ACIKLAMA%type;                   --TemirlanT
    ls_sector_explanation CBS_DKHESAP.ACIKLAMA%type;               --TemirlanT
    ls_month_explanation varchar2(20);                             --TemirlanT
    ln_count_related_account_pd number;                            --TemirlanT
    ln_general_balance number := 0;                                --TemirlanT
    ln_general_balance_1 number;                                   --TemirlanT
    ln_general_balance_2 number;                                   --TemirlanT
    ls_part varchar2(10);                                          --TemirlanT
    ln_count_a boolean := false;                                   --TemirlanT
    ln_count_b boolean := false;                                   --TemirlanT
    lb_block boolean;
    ln_overdraft_mi CBS_HESAP.OVERDRAFT%type;                      --TemirlanT
    ln_toplam_faiz_tim number;                                     --TemirlanT
    ln_available_amount_after number;                              --TemirlanT
    ln_job_no number;                                              --TemirlanT
    ln_gecenyil_faiz_tutari number;
    ln_gecmis_aylarin_faizi number;
    ln_birikmis_faiz_tutari number;
    ln_amount_penalty number;
    ln_tax_rate number;
    ln_tax_rate_last_year number;
    ln_service_tax_rate number;
    ln_toplam_tax number;
    ln_paid_tax_amount number;
    ln_block_sum  number := 0;
    ln_block_sum_fc  number := 0;
    ln_bakiye number;
    ln_anapara_tahsilat_tutar number;
    ln_alter_current_account number;
    ln_converted_acc_amount number;
    ln_current_account_2 number;
    ln_non_gon_block number;
    ln_gon_block_count number;
    ln_alis_kuru number;
    ln_satis_kuru number;
    ln_alis_tutari number;
    ln_pastdue_block_sum number;
    ln_block_account number;
    ln_block_currency varchar2(3);
    ln_block_amount number;
    ln_pastdue_block number := 0;

    CURSOR c_credited_cust IS
        SELECT s.hesap_numara,  -- list of accounts with balance inflow
            s.hesap_bolum_kodu,
            s.dv_tutar,
            h.urun_tur_kod,
            h.urun_sinif_kod,
            h.modul_tur_kod,
            h.doviz_kodu,
            h.sube_kodu,
            h.musteri_no,
            trunc(pkg_hesap.kullanilabilir_bakiye_al(h.hesap_no),2) available_balance,
            pkg_kur.doviz_doviz_karsilik(h.doviz_kodu,pkg_genel.lc_al,null,trunc(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),2),1,null,null,'O','A', h.sube_kodu ) buying_amount,
            pkg_kur.doviz_doviz_karsilik(h.doviz_kodu,pkg_genel.lc_al,null,trunc(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),2),1,null,null,'O','S',  h.sube_kodu) selling_amount
        FROM cbs_satir s, cbs_hesap h
        WHERE s.fis_islem_numara = pn_islem_numara
            and s.hesap_tur_kodu = 'VS'
            and s.tur = 'A'
            and h.hesap_no=to_number(s.hesap_numara)
            and pkg_musteri.sf_musteri_tipi_al(h.musteri_no) in (1, 2) --retail, sme
            --and S.DOVIZ_KOD in ('KGS','USD')
            --and trunc(pkg_hesap.kullanilabilir_bakiye_al(h.hesap_no),2) > 0
            and (pkg_muhasebe.banka_tarihi_bul - (select min(k.acilis_tarihi) from   cbs_hesap_kredi k
                where K.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)
                and K.durum_kodu='A'
                and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                and k.urun_sinif_kod not in ('CRD.CARD-LC')
                and K.pastdue_faiz_anapara_sec is not null)) < 90
            and ((select count(*) from   cbs_hesap_kredi k
                where K.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)
                and K.durum_kodu='A'
                and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                and k.urun_sinif_kod not in ('CRD.CARD-LC')
                and K.pastdue_faiz_anapara_sec is not null) > 0
            or (select count(*)
                from cbs_hesap_kredi k
                where  k.penalty_amount > 0
                and k.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)) > 0);
    r_credited_cust  c_credited_cust%ROWTYPE;

    CURSOR c_credited_count IS
        select hesap_no,iliskili_hesap_no, doviz_kodu
                from cbs_hesap_kredi k1
                where k1.ana_kredi_hesap_no is null
                and k1.musteri_no = ln_customer_no
                --and k1.durum_kodu='A'
                and k1.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                and pkg_hesap.HesaptanDurumAl(k1.iliskili_hesap_no) = 'A'
                and (select count(*) from cbs_hesap_kredi where ana_kredi_hesap_no=k1.hesap_no and durum_kodu='A')>0;
    r_credited_count  c_credited_count%ROWTYPE;

    cursor c_pastdue_block is
        select B.HESAP_NO,
               B.DOVIZ_KODU,
               B.BLOKE_TUTARI
        from cbs_bloke b
        where b.bloke_neden_kodu in ('11') and b.durum_kodu = 'A' and B.BLOKE_TUTARI > 0
        and B.musteri_no = ln_customer_no;
    r_pastdue_block c_pastdue_block%ROWTYPE;

 BEGIN
    OPEN c_credited_cust;
    LOOP
        FETCH c_credited_cust INTO r_credited_cust;
        EXIT WHEN c_credited_cust%NOTFOUND;
        --log_at('timka_block', 2,1);
        ln_current_account := r_credited_cust.hesap_numara;
        ls_account_currency := r_credited_cust.doviz_kodu;
        ls_account_branch := r_credited_cust.sube_kodu;
        ln_customer_no := r_credited_cust.musteri_no;
        ln_tx_amount := r_credited_cust.dv_tutar;

        ln_islem_no:=pkg_tx.islem_no_al;
        ln_islem_kod:='1200';
        lc_hesap_numara:= ln_current_account;
        pkg_hesap.UrunBilgiAl( lc_hesap_numara,lc_modul_tur_kod,lc_urun_tur_kod,lc_urun_sinif_kod);
        lb_masraf:= pkg_masraf.masraf_yaratilmali(ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod);
        --ls_account_currency:=pkg_hesap.HesaptanDovizKoduAl(ps_account);
        --ln_musteri_numara:= pkg_hesap.HesaptanMusteriNoAl(lc_hesap_numara);
        ld_blocking_date := pkg_muhasebe.banka_tarihi_bul;
        lc_kasa_kod:=NULL;

            begin
                select nvl(sum(bloke_tutari),0) into ln_block_sum
                from cbs_bloke b
                where b.bloke_neden_kodu not in ('10', '7') and b.durum_kodu = 'A' and B.BLOKE_TUTARI > 0 and hesap_no = ln_current_account;
            exception when no_data_found then
                ln_block_sum := 0;
            end;
        log_at('cbs-timka_pd',1,0,'ln_available_amount='||ln_available_amount||' ln_current_account='||ln_current_account||'ln_block_sum='||ln_block_sum);
        ln_available_amount := pkg_hesap.HesapBakiyeAl(ln_current_account) - ln_block_sum;
        Begin
            OPEN c_pastdue_block;
            LOOP
                FETCH c_pastdue_block INTO r_pastdue_block;
                EXIT WHEN c_pastdue_block%NOTFOUND;

                /*
                SELECT DOVIZ_KODU INTO ls_past_due_currency
                FROM cbs_hesap_kredi k
                WHERE k.durum_kodu='A' AND k.musteri_no=ln_customer_no AND k.urun_tur_kod NOT IN ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                AND k.urun_sinif_kod NOT IN ('CRD.CARD-LC') AND k.pastdue_faiz_anapara_sec IS NULL;
                 */--CBS-689 Andreid 07.07.2022

                ln_block_account := r_pastdue_block.hesap_no;
                ln_block_currency := r_pastdue_block.doviz_kodu;
                ln_block_amount := r_pastdue_block.bloke_tutari;

                IF ln_block_currency = PKG_GENEL.LC_AL THEN
                    ln_pastdue_block_sum := ln_block_amount;
                    log_at('cbs-timka_pd',1,'bloke','ln_pastdue_block_sum='||ln_available_amount||' ln_block_amount='||ln_block_amount||' ln_block_currency='||ln_block_currency||' ln_block_account='||ln_block_account);
                ELSIF ln_block_currency <> PKG_GENEL.LC_AL THEN
                    log_at('cbs-timka_pd',1,'bloke2','ln_pastdue_block_sum='||ln_pastdue_block_sum||' ln_block_amount='||ln_block_amount||' ln_block_currency='||ln_block_currency||' ln_block_account='||ln_block_account);
                    ln_pastdue_block_sum := pkg_kur.doviz_doviz_karsilik(ln_block_currency,pkg_genel.lc_al,null,ln_block_amount,1,null,null,'O','A', ls_account_branch );
                    log_at('cbs-timka_pd',1,'bloke8','ln_pastdue_block_sum='||ln_pastdue_block_sum||' ln_block_amount='||ln_block_amount||' ln_block_currency='||ln_block_currency||' ln_general_balance='||ln_general_balance);
                END IF;

                ln_pastdue_block := ln_pastdue_block + ln_pastdue_block_sum;

            END LOOP;
            CLOSE c_pastdue_block;
        End;
        log_at('cbs-timka_pd',1,1,'ln_pastdue_block='||ln_pastdue_block||' ln_pastdue_block_sum='||ln_pastdue_block_sum||' ln_block_sum='||ln_block_sum);
        begin
            log_at('cbs-timka_pd',1,2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
            if ln_available_amount>0 then
                OPEN c_credited_count;
                LOOP
                    FETCH c_credited_count INTO r_credited_count;
                    EXIT WHEN c_credited_count%NOTFOUND;
                    --c_credited_count
                    --WHILE ln_count_a < ln_count_related_account_pd LOOP
                    ln_loan_account := r_credited_count.hesap_no;
                    ln_related_account := r_credited_count.iliskili_hesap_no;
                    ls_past_due_currency := r_credited_count.doviz_kodu;
                    if ln_current_account <> ln_related_account then
                        ln_count_a := true;
                    end if;
                    select sum(nvl(abs(pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)),0))
                    into ln_general_balance_1
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90;
                    log_at('cbs-timka_pd',1,5,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    select sum(nvl(abs(GECENYIL_FAIZ_TUTARI), 0)), sum(nvl(abs(GECMIS_AYLARIN_FAIZI), 0)), sum(nvl(abs(BIRIKMIS_FAIZ_TUTARI), 0))
                    into ln_gecenyil_faiz_tutari, ln_gecmis_aylarin_faizi, ln_birikmis_faiz_tutari
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90
                    and pastdue_faiz_anapara_sec = 'ANAPARA';
                    log_at('cbs-timka_pd',1,6,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    select sum(nvl(abs(penalty_amount), 0))
                    into ln_amount_penalty
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90
                    and pastdue_faiz_anapara_sec = 'FAIZ';
                    log_at('cbs-timka_pd',1,7,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_tax_rate);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_tax_rate_last_year);
                    Pkg_Parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);
                    log_at('cbs-timka_pd',1,8,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    ln_toplam_tax := round((((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))))*ln_tax_rate_last_year+
                                         (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))))*ln_tax_rate)/100),2)
                                + round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);

                    ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);

                    ln_general_balance_2 := round((ln_general_balance_1 + ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari + ln_toplam_tax),2);

                    ln_general_balance_1 := round((ln_general_balance_1 + ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari + ln_toplam_tax + ln_amount_penalty + ln_paid_tax_amount),2);
                    log_at('cbs-timka_pd',1,9,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);

                    ln_general_balance := ln_general_balance + ln_general_balance_1;
                    log_at('cbs-timka_pd',1,10,'ln_general_balance='||ln_general_balance||' ln_general_balance_1='||ln_general_balance_1);
                    --ln_count_a := ln_count_a + 1;
                    ln_general_balance_1 := 0;

                    if ln_current_account = ln_related_account then
                        lb_block := false;
                    else
                        begin
                            log_at('cbs-timka_pd','general',1,'ln_general_balance='||ln_general_balance||' ln_block_sum_fc='||ln_block_sum_fc||' ln_bakiye='||ln_bakiye);
                            select nvl(sum(bloke_tutari), 0)
                            into ln_block_sum_fc
                            from cbs_bloke b
                            where b.bloke_neden_kodu not in ('7', '10')
                            and b.durum_kodu = 'A'
                            and B.BLOKE_TUTARI > 0
                            and hesap_no = ln_related_account;
                            log_at('cbs-timka_pd','general',2,'ln_general_balance='||ln_general_balance||' ln_block_sum_fc='||ln_block_sum_fc||' ln_bakiye='||ln_bakiye);
                        exception when no_data_found then
                            log_at('cbs-timka_pd','general',3,'ln_general_balance='||ln_general_balance||' ln_block_sum_fc='||ln_block_sum_fc||' ln_bakiye='||ln_bakiye);
                            ln_block_sum_fc := 0;
                        end;

                        ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
                        log_at('cbs-timka_pd','general',4,'ln_general_balance='||ln_general_balance||' ln_block_sum_fc='||ln_block_sum_fc||' ln_bakiye='||ln_bakiye);
                        ln_general_balance := ln_general_balance + ln_block_sum_fc - ln_bakiye;
                        log_at('cbs-timka_pd','general',5,'ln_general_balance='||ln_general_balance||' ln_block_sum_fc='||ln_block_sum_fc||' ln_bakiye='||ln_bakiye);
                        --ln_general_balance_2 := ln_general_balance_2 + ln_block_sum - ln_bakiye;
                    end if;
                    log_at('cbs-timka_pd',1,11,'ln_available_amount='||ln_available_amount);
                    if trunc(ln_available_amount,2) > 0 then
                        if ls_account_currency <> ls_past_due_currency then
                            if ls_past_due_currency = PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-LC
                                ln_available_amount := pkg_kur.doviz_doviz_karsilik(ls_account_currency,pkg_genel.lc_al,null,ln_available_amount,1,null,null,'O','A', ls_account_branch );
                                log_at('cbs-timka_pd',1,3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency = PKG_GENEL.LC_AL then -- LC-FC
                                ln_available_amount := pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,ls_past_due_currency,null,ln_available_amount,1,null,null,'O','S', ls_account_branch );
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-FC
                                ln_available_amount := pkg_kredi.arbitraj_kur(ls_account_currency, ls_past_due_currency, ln_available_amount, ls_account_branch, false, true);
                            end if;
                        end if;
                        if (ln_general_balance - ln_pastdue_block) > 0 then
                            if ln_available_amount > (ln_general_balance - ln_pastdue_block) then    --TemirlanT cbs-119
                                ln_available_amount := ln_general_balance - ln_pastdue_block;
                            end if;
                        end if;
                        log_at('cbs-timka_pd',1,12,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance||' ln_pastdue_block='||ln_pastdue_block);
                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);

                        if ls_account_currency <> ls_past_due_currency then
                            if ls_past_due_currency = PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-LC
                                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_account_currency,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch); --FC --> LC
                                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);
                                ln_alis_tutari := round((ln_anapara_tahsilat_tutar * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2) ;
                                ln_available_amount := ln_alis_tutari;
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency = PKG_GENEL.LC_AL then -- LC-FC
                                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_account_currency,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
                                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);  --LC --> FC
                                ln_alis_tutari := round((ln_anapara_tahsilat_tutar * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2);
                                ln_available_amount := ln_alis_tutari;
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-FC
                                ln_alis_tutari := pkg_kredi.arbitraj_kur(ls_account_currency, ls_past_due_currency, ln_anapara_tahsilat_tutar, ls_account_branch, false, true); --FC --> FC
                                ln_available_amount := ln_alis_tutari;
                            end if;
                            lb_block := false;
                        else
                            lb_block := false;
                        end if;
                        log_at('cbs-timka_pd',1,13,'ln_available_amount='||ln_available_amount);


                        /*ln_alter_current_account := ln_related_account;

                        ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch); --FC --> LC
                        ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);
                        ln_alis_tutari := round((ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2) ;

                        ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
                        ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);  --LC --> FC
                        ln_alis_tutari := round((ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2) ;

                        ln_alis_tutari := pkg_kredi.arbitraj_kur(ls_alis_doviz_kodu, ls_satis_doviz_kodu, ln_satis_tutari, ls_account_branch, lb_buy_loan_currency, lb_bought_amount); --FC --> FC

                        /*if ln_current_account != ln_related_account then
                            if ls_account_currency <> ls_past_due_currency then
                                pkg_kredi.sp_convert_for_pd_closing_arb(ln_loan_account, ln_current_account, ln_anapara_tahsilat_tutar, ln_alter_current_account,ln_converted_acc_amount);
                                ls_account_currency := ls_past_due_currency;        --TemirlanT
                                ln_current_account := ln_related_account;        --TemirlanT
                                log_at('cbs-timka_pd',1,6,'ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar||' ln_general_balance='||ln_general_balance);
                            else
                                pkg_kredi.sp_transfer_for_pd_closing(ln_loan_account, ln_current_account, ln_anapara_tahsilat_tutar, ln_alter_current_account, ln_converted_acc_amount); --TemirlanT cbs-119
                                ls_account_currency := ls_past_due_currency;        --TemirlanT
                                ln_current_account := ln_related_account;        --TemirlanT
                            end if;
                        end if;*/
                        --ln_current_account_2 := ln_alter_current_account;      --TemirlanT
                    end if;

                END LOOP;
                CLOSE c_credited_count;

                log_at('cbs-timka_pd',1,11,'ln_general_balance='||ln_general_balance||' ln_general_balance_1='||ln_general_balance_1);
            end if;
        exception when others then
            log_at('cbs-timka_pd',1,10,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
        --ln_related_account := null;
        end;
        if ln_pastdue_block >= ln_general_balance then    --TemirlanT cbs-119
            lb_block := true;
        end if;
        IF lb_block = false THEN
            if ln_available_amount>0 then
                log_at('cbs-timka_pd',1,14,'ln_available_amount='||ln_available_amount);
                pkg_tx1200.save_rows(ln_islem_no, ln_customer_no, lc_hesap_numara, ls_account_currency, ln_available_amount, 11, 'Past Due Block', ld_blocking_date, NULL);
        --log_at('timka_block', 3);
                IF pkg_tx.islem_yaratilmis_mi(ln_islem_no) <> 1 then  --islem yaratilmamis, yarat
                    CBS.PKG_BAGLAM.YARAT(ls_account_branch, '0');
                    Begin
                        Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                              KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                              KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                              MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                              MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                        values (ln_islem_no,ln_islem_kod,'N',ls_account_branch,
                              'CBS','0',ls_account_branch,
                              pkg_muhasebe.banka_tarihi_bul,sysdate,
                              lc_modul_tur_kod,lc_urun_tur_kod,lc_urun_sinif_kod,
                              ln_customer_no,lc_hesap_numara,ln_available_amount,NULL,ls_account_currency);
                        --gecici islemden geliyorsa gecici islem durumunun set edilmesi gerekli
                        --TDL: gecici islem no wait
                        update cbs_islem_gecici set durum = 'C'
                        where numara=ln_islem_no;
                        commit;
                    Exception
                        When Others Then
                        log_at('webp', SQLERRM);
                        Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
                    End;
                    PKG_KREDI_AUTOMATION.Giris_Kontrol(ln_islem_no);
                    --log_at('2300', 'Giris_Kontrol');
                    PKG_TX.Harici_Kod_Cagir(ln_islem_no,'Kontrol_Sonrasi');

                    IF pkg_tx.Dogrula_Kontrol(ln_islem_no) THEN
                        NULL;
                    ELSIF pkg_tx.Onay_Kontrol(ln_islem_no) THEN
                        NULL;
                    ELSE
                        pkg_tx.Muhasebelestir(ln_islem_no);
                    END IF;

                    IF lb_masraf THEN
                        pkg_masraf.validate_masraf(ln_islem_no);
                    END IF;
                    --log_at('timka_block', 4);
                END IF;
            end if;
        END IF;

    END LOOP;
    CLOSE c_credited_cust;

 EXCEPTION
    WHEN others THEN
    log_at('pkg_kredi_pd_closing','anapara_pd', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4660' ||  Pkg_Hata.getdelimiter|| ln_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 END;

PROCEDURE sp_Principal_Pastdue_Closing (pn_pd_account_no number,
                                        pd_value_date date,
                                        ps_collection_currency varchar2,
                                        pn_rate number,
                                        pn_related_account number,
                                        pn_collection_account number,
                                        pn_tahsedil_gecenyilfaiztutar number,
                                        pn_tahsedil_gecmis_aylar_faiz number,
                                        pn_tahsedil_birikmisfaiztutar number,
                                        pn_anapara_tahsilat_tutar number,
                                        ps_aciklama varchar2,
                                        ps_choice varchar2,
                                        ps_durum_kodu varchar2,
                                        ps_pd_branch_cd varchar2,
                                        ps_modul_tur_kod varchar2,
                                        ps_urun_tur_kod varchar2,
                                        ps_urun_sinif_kod varchar2,
                                        ps_past_due_currency varchar2,
                                        pn_musteri_no number) IS

    ln_islem_kod number;
    ln_islem_no number;
    ln_toplam_tahsiledilecek_tutar number;

 BEGIN
    log_at('timka_eod', 2);
    ln_islem_kod := 1306;
    ln_islem_no:=CBS.PKG_TX.ISLEM_NO_AL;
    PKG_KREDI.SP_KREDIHESAP_ISLEME_AT(pn_pd_account_no,ln_islem_no,ln_islem_kod);
    ln_toplam_tahsiledilecek_tutar := pn_anapara_tahsilat_tutar + pn_tahsedil_gecenyilfaiztutar + pn_tahsedil_gecmis_aylar_faiz + pn_tahsedil_birikmisfaiztutar;
    log_at('timka_eod', 2, 1);
    UPDATE CBS_HESAP_KREDI_ISLEM
    SET VALOR_TARIHI = pd_value_date,
    TAHSIL_HESAP_DOVIZ = ps_collection_currency,
    KUR = pn_rate,
    ILISKILI_HESAP_NO = pn_related_account,
    TAHSIL_HESAP_NO = pn_collection_account,
    TAHSEDIL_GECENYIL_FAIZ_TUTARI = pn_tahsedil_gecenyilfaiztutar,
    TAHSEDIL_GECMIS_AYLAR_FAIZ = pn_tahsedil_gecmis_aylar_faiz,
    TAHSEDIL_BIRIKMIS_FAIZ_TUTARI = pn_tahsedil_birikmisfaiztutar,
    ANAPARA_TAHSILAT_TUTAR = pn_anapara_tahsilat_tutar,
    ACIKLAMA = ps_aciklama,
    GERIODEME_KAPAMA_SECIMI = ps_choice,
    DURUM_KODU = ps_durum_kodu,
    TOPLAM_TAHSILEDILECEK_TUTAR = ln_toplam_tahsiledilecek_tutar
    WHERE TX_NO = ln_islem_no;
    log_at('timka_eod', 3);
    CBS.PKG_BAGLAM.YARAT(ps_pd_branch_cd, '0');
    log_at('timka_eod', 4);
    Begin
        INSERT INTO CBS_ISLEM(NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                              KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                              KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                              MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                              MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                       VALUES(ln_islem_no,ln_islem_kod,'N',ps_pd_branch_cd,
                              'CBS','0',ps_pd_branch_cd,
                              PKG_MUHASEBE.BANKA_TARIHI_BUL,SYSDATE,
                              ps_modul_tur_kod,ps_urun_tur_kod,ps_urun_sinif_kod,
                              pn_musteri_no,pn_pd_account_no,ln_toplam_tahsiledilecek_tutar,NULL,ps_past_due_currency);

        UPDATE CBS_ISLEM_GECICI SET durum = 'C'
        WHERE numara=ln_islem_no;

    Exception
        When Others Then
            Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
    End ;
    log_at('timka_eod', 5);
    PKG_KREDI_AUTOMATION.GIRIS_KONTROL(ln_islem_no);
    log_at('timka_eod', 6);
    Begin
        PKG_TX1306.KONTROL_SONRASI(ln_islem_no);
    Exception
        When Others Then
            log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
            Rollback;
            Raise_application_error(-20100,SQLERRM);
    End;
    log_at('timka_eod', 7);
    Begin
        PKG_TX1306.ONAY_SONRASI(ln_islem_no);
    Exception
        When Others Then
            log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
            Rollback;
            Raise_application_error(-20100,SQLERRM);
    End;
    log_at('timka_eod', 8);
    Begin
        PKG_TX1306.MUHASEBELESME(ln_islem_no);
        UPDATE CBS_ISLEM SET durum = 'P', tamamlanma_tarihi=PKG_MUHASEBE.BANKA_TARIHI_BUL
        WHERE numara=ln_islem_no;
    Exception
        When Others Then
            log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
            Rollback;
            Raise_application_error(-20100,SQLERRM);
    End;
    log_at('timka_eod', 9);
 EXCEPTION
    WHEN others THEN
    log_at('pkg_kredi_pd_closing','anapara_pd', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4670' ||  Pkg_Hata.getdelimiter|| pn_related_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 END;

PROCEDURE sp_penalty_Pastdue_Closing (ps_cash_account varchar2,
                                      ps_currency_code varchar2,
                                      pn_customer_no number,
                                      ps_residency_code varchar2,
                                      ps_citizen_code varchar2,
                                      ps_customer_type varchar2,
                                      ps_income_type varchar2,
                                      pn_related_account number,
                                      pn_amount number,
                                      ps_vat varchar2,
                                      ps_service_tax varchar2,
                                      pn_service_tax_rate number,
                                      ps_tax_coll_type varchar2,
                                      pn_paid_tax_amount number,
                                      pn_total_collection_amount number,
                                      ps_collection_currency varchar2,
                                      pn_rate number,
                                      pn_collection_account number,
                                      ps_income_gl varchar2,
                                      ps_explanation varchar2,
                                      ps_pd_branch_cd varchar2,
                                      ps_modul_tur_kod varchar2,
                                      ps_urun_tur_kod varchar2,
                                      ps_urun_sinif_kod varchar2,
                                      pn_current_account number) IS

    ln_islem_kod number;
    ln_islem_no number;

 BEGIN
    log_at('cbs-timka_pd','tim',1);
    ln_islem_kod := 3400;
    ln_islem_no:=CBS.pkg_tx.islem_no_al;
    log_at('cbs-timka_pd','tim',2,'ln_islem_no='||ln_islem_no);
    INSERT INTO CBS_MASRAF_KOM_TAHSIL_ISL (tx_no,
                                           cash_account,
                                           dvz,
                                           musteri_no,
                                           residency_code,
                                           citizen_code,
                                           customer_type,
                                           gelir_aciklama,
                                           iliskili_hesap_no,
                                           tahsil_tutari,
                                           vat,
                                           service_tax,
                                           service_tax_rate,
                                           tax_coll_type,
                                           paid_tax_amount,
                                           tahsil_toplam_tutar,
                                           tahsil_dvz_kod,
                                           kur,
                                           tahsil_hesap_no,
                                           income_gl,
                                           aciklama )
                                   VALUES (ln_islem_no,
                                           ps_cash_account ,
                                           ps_currency_code ,
                                           pn_customer_no ,
                                           ps_residency_code ,
                                           ps_citizen_code ,
                                           ps_customer_type ,
                                           ps_income_type ,
                                           pn_related_account ,
                                           pn_amount ,
                                           ps_vat ,
                                           ps_service_tax ,
                                           pn_service_tax_rate ,
                                           ps_tax_coll_type ,
                                           pn_paid_tax_amount ,
                                           pn_total_collection_amount ,
                                           ps_collection_currency ,
                                           pn_rate ,
                                           pn_collection_account ,
                                           ps_income_gl ,
                                           ps_explanation);
    log_at('cbs-timka_pd','tim',3,'ln_islem_no='||ln_islem_no|| ' ' ||
    'ps_cash_account='||ps_cash_account || ' '||
            'ps_currency_code='||ps_currency_code || ' '||
           'pn_customer_no='|| pn_customer_no || ' '||
           'ps_residency_code='|| ps_residency_code || ' '||
           'ps_citizen_code='|| ps_citizen_code || ' '||
          'ps_customer_type='||  ps_customer_type || ' '||
          'ps_income_type='||  ps_income_type || ' '||
          'pn_related_account='||  pn_related_account || ' '||
          'pn_amount='||  pn_amount || ' '||
          'ps_vat='||  ps_vat || ' '||
          'ps_service_tax='||  ps_service_tax || ' '||
          'pn_service_tax_rate='||  pn_service_tax_rate || ' '||
          'ps_tax_coll_type='||  ps_tax_coll_type || ' '||
          'pn_paid_tax_amount='||  pn_paid_tax_amount || ' '||
          'pn_total_collection_amount='||  pn_total_collection_amount || ' '||
          'ps_collection_currency='||  ps_collection_currency || ' '||
           'pn_rate='|| pn_rate || ' '||
           'pn_collection_account='|| pn_collection_account || ' '||
          'ps_income_gl='||  ps_income_gl || ' '||
          'ps_explanation='||  ps_explanation);
    CBS.PKG_BAGLAM.YARAT(ps_pd_branch_cd, '0');
    log_at('cbs-timka_pd','tim',4,'ln_islem_no='||ln_islem_no);
    Begin
        INSERT INTO CBS_ISLEM (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                               KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                               KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                               MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                               MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                       VALUES (ln_islem_no,ln_islem_kod,'N',ps_pd_branch_cd,
                               'CBS','0',ps_pd_branch_cd,
                               PKG_MUHASEBE.BANKA_TARIHI_BUL,SYSDATE,
                               ps_modul_tur_kod,ps_urun_tur_kod,ps_urun_sinif_kod,
                               pn_customer_no,pn_current_account,pn_total_collection_amount,null,ps_currency_code);

        UPDATE CBS_ISLEM_GECICI SET durum = 'C'
        WHERE numara=ln_islem_no;

    Exception
        When Others Then
            Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
    End ;
    log_at('cbs-timka_pd','tim',5,'ln_islem_no='||ln_islem_no);
    PKG_TX.GIRIS_KONTROL(ln_islem_no);
    log_at('cbs-timka_pd','tim',6,'ln_islem_no='||ln_islem_no);
    Begin
        PKG_TX3400.KONTROL_SONRASI(ln_islem_no);
    Exception
        When Others then
            log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
            Rollback;
            Raise_application_error(-20100,SQLERRM);
    End;
    log_at('cbs-timka_pd','tim',7,'ln_islem_no='||ln_islem_no);
    Begin
        PKG_TX3400.ONAY_SONRASI(ln_islem_no);
    Exception
        When Others Then
            log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
            Rollback;
            Raise_application_error(-20100,SQLERRM);
    End;
    log_at('cbs-timka_pd','tim',8,'ln_islem_no='||ln_islem_no);
    begin
    PKG_TX3400.MUHASEBELESME(ln_islem_no);
    update cbs_islem
                set durum = 'P',
                tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
                where numara=ln_islem_no;

                Exception

                When Others then
                log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
                   Rollback;
                   Raise_application_error(-20100,SQLERRM);
    end;
    log_at('cbs-timka_pd','tim',9,'ln_islem_no='||ln_islem_no);
    UPDATE CBS_HESAP_KREDI k
    SET K.PENALTY_AMOUNT =NVL(PENALTY_AMOUNT,0)-ABS(pn_amount)
    WHERE hesap_no=pn_related_account;


 EXCEPTION
    WHEN others THEN
        log_at('pkg_kredi_pd_closing','penalty_pd', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        --rollback;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4666' ||  Pkg_Hata.getdelimiter|| pn_related_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 END;


procedure sp_convert_for_pd_closing_arb(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number,pn_alis_tutari out number) is

 ln_musteri_no number;
 ln_available_balance number;
 ls_account_currency cbs_hesap.doviz_kodu%type;
 ls_account_branch cbs_hesap.sube_kodu%type;
 ln_block_sum number;  --TemirlanT
 ln_bakiye number;  --TemirlanT
 ln_difference_amount number; --TemirlanT

 ln_islem_kod number;
 ln_islem_no number;

 ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
 ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
 ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
 ls_loan_currency cbs_hesap_kredi.doviz_kodu%type;

 ls_kur_tipi CBS_ARBITRAJ_ISLEM.KUR_TIPI%type;
 ls_alis_doviz_kodu CBS_ARBITRAJ_ISLEM.ALIS_DOVIZ_KODU%type;
 ls_SATIS_DOVIZ_KODU CBS_ARBITRAJ_ISLEM.SATIS_DOVIZ_KODU%type;
 ls_RESIDENCY_CODE CBS_ARBITRAJ_ISLEM.RESIDENCY_CODE%type;
 ls_CITIZEN_CODE CBS_ARBITRAJ_ISLEM.CITIZEN_CODE%type;
 ls_TAX_NUMBER CBS_ARBITRAJ_ISLEM.TAX_NUMBER%type;
 ls_KUR_PARITE_SECIM CBS_ARBITRAJ_ISLEM.KUR_PARITE_SECIM%type;
 ln_ALIS_KURU CBS_ARBITRAJ_ISLEM.ALIS_KURU%type;
 ln_SATIS_KURU CBS_ARBITRAJ_ISLEM.SATIS_KURU%type;
 ln_ALIS_TUTARI CBS_ARBITRAJ_ISLEM.ALIS_TUTARI%type;
 ln_SATIS_TUTARI CBS_ARBITRAJ_ISLEM.SATIS_TUTARI%type;
 ln_ALIS_HESAP_NO CBS_ARBITRAJ_ISLEM.ALIS_HESAP_NO%type;
 ln_SATIS_HESAP_NO CBS_ARBITRAJ_ISLEM.SATIS_HESAP_NO%type;
 ls_NAME_SURNAME CBS_ARBITRAJ_ISLEM.NAME_SURNAME%type;
 ls_ACIKLAMA CBS_ARBITRAJ_ISLEM.ACIKLAMA%type;
 ls_ISTATISTIK_KODU_ALIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_ALIS%type;
 ls_ISTATISTIK_KODU_SATIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_SATIS%type;

 ln_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 ls_related_acc_curr CBS_HESAP.DOVIZ_KODU%type;
 ln_related_acc_count number;

 ln_account_no CBS_HESAP.HESAP_NO%type;
 ln_currency CBS_HESAP.DOVIZ_KODU%type;
 ln_account_count number;

 ln_parity CBS_ARBITRAJ_ISLEM.PARITE%type;
 ls_carp_bol_secimi CBS_ARBITRAJ_ISLEM.CARP_BOL_SECIMI%type;
 lb_buy_loan_currency boolean := false;
 lb_bought_amount boolean := false;
 ln_satis_hesap_avail_bal number;


begin
    ls_account_currency := pkg_hesap.HesaptanDovizKoduAl(pn_current_account);
    ln_musteri_no :=  pkg_hesap.HesaptanMusteriNoAl(pn_current_account);
    ls_account_branch := pkg_hesap.HesapSubeAl(pn_current_account);
    ls_loan_currency := pkg_hesap.HesaptanDovizKoduAl(pn_loan_account);
    ls_related_acc_curr := pkg_hesap.HesaptanDovizKoduAl(pn_alter_current_account);

   -- lb_bought_amount := pb_bought_amount;

    ln_islem_kod := 1208;
    ln_islem_no:=CBS.pkg_tx.islem_no_al;
    --ln_amount := pn_amount; --TemirlanT
    ln_related_account := pn_alter_current_account;

    if ln_related_account is not null  then
         ls_modul_tur_kod := 'CURR.OPS.';
         ls_urun_tur_kod := 'ACC-ACC';
         if ls_loan_currency = PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'FC-LC';
                ls_alis_doviz_kodu := ls_account_currency;
                ln_satis_tutari := pn_amount; --TemirlanT
                ln_alis_hesap_no := pn_current_account;
                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_related_acc_curr;
                end if;
                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);
                ln_alis_tutari := round((ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2) ;

          elsif ls_loan_currency <> PKG_GENEL.LC_AL and ls_account_currency = PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'LC-FC';
                ls_alis_doviz_kodu := ls_account_currency;
                ln_satis_tutari := pn_amount; --TemirlanT
                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_related_acc_curr;
                end if;
                ln_alis_hesap_no := pn_current_account;
                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);
                ln_alis_tutari := round((ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2) ;

            elsif ls_loan_currency <> PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'FC-FC';
                ls_alis_doviz_kodu := ls_account_currency;

                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_related_acc_curr;
                end if;
                ln_alis_hesap_no := pn_current_account;

                lb_buy_loan_currency := false;

                ln_satis_tutari := pn_amount; --TemirlanT
                ln_alis_tutari := pkg_kredi.arbitraj_kur(ls_alis_doviz_kodu, ls_satis_doviz_kodu, ln_satis_tutari, ls_account_branch, lb_buy_loan_currency, lb_bought_amount);
            end if;

         pn_alis_tutari := ln_alis_tutari;
         ls_kur_tipi := 'COMMERCIAL';
         ls_residency_code := pkg_musteri.sf_get_residency_code (ln_musteri_no);
         ls_citizen_code := pkg_musteri.sf_get_citizenship_country(ln_musteri_no);
         ls_tax_number := pkg_musteri.Sf_VergiNo_Al(ln_musteri_no);
         ls_kur_parite_secim := 'K'; --RATE

         ls_name_surname := pkg_musteri.sf_musteri_adi(ln_musteri_no);
         ls_aciklama := 'КОНВЕРТАЦИЯ ДЛЯ ПОГАШЕНИЯ ПРОСРОЧКИ ('|| pn_loan_account || ') - ПО КУРСУ ' || ln_alis_kuru || ' ' || ls_name_surname;
         ls_istatistik_kodu_alis := '040202';
         ls_istatistik_kodu_satis := '040202';

        insert into CBS_ARBITRAJ_ISLEM a
        (tx_no,urun_tur_kod, urun_sinif_kod, kur_tipi, alis_doviz_kodu, satis_doviz_kodu, residency_code, citizen_code, tax_number,
         kur_parite_secim, alis_kuru, satis_kuru, alis_tutari, satis_tutari, alis_hesap_no, satis_hesap_no, name_surname, aciklama, istatistik_kodu_alis, istatistik_kodu_satis) values
        (ln_islem_no,
         ls_urun_tur_kod,
         ls_urun_sinif_kod ,
         ls_kur_tipi ,
         ls_alis_doviz_kodu ,
         ls_SATIS_DOVIZ_KODU ,
         ls_RESIDENCY_CODE ,
         ls_CITIZEN_CODE ,
         ls_TAX_NUMBER ,
         ls_KUR_PARITE_SECIM ,
         ln_ALIS_KURU ,
         ln_SATIS_KURU ,
         ln_ALIS_TUTARI ,
         ln_SATIS_TUTARI ,
         ln_ALIS_HESAP_NO ,
         ln_SATIS_HESAP_NO ,
         ls_NAME_SURNAME ,
         ls_ACIKLAMA ,
         ls_ISTATISTIK_KODU_ALIS ,
         ls_ISTATISTIK_KODU_SATIS );

              -- 1.  Create user session
          cbs.PKG_BAGLAM.YARAT(
                ls_account_branch,    --branch code of the CBS user (refers to the table CBS_BOLUM column KODU)
                '0' --role of the CBS user (refers to the table CBS_ROL column NUMARA)
          );
            begin
            Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                                  KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                                  KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                                  MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                                  MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                          values (ln_islem_no,ln_islem_kod,'N',ls_account_branch,
                                  'CBS','0',ls_account_branch,
                                  pkg_muhasebe.banka_tarihi_bul,sysdate,
                                  ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,
                                  ln_musteri_no,ln_alis_hesap_no,ln_ALIS_TUTARI,null,ls_alis_doviz_kodu
                              );
            update cbs_islem_gecici
                   set durum = 'C'
                 where numara=ln_islem_no;
            Exception
                   When Others Then
                    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
            end ;

        --if ln_alis_tutari != 0 then --TemirlanT
            Giris_Kontrol(ln_islem_no);
            begin
            PKG_TX1207.KONTROL_SONRASI(ln_islem_no);
            Exception

                        When Others then
                        log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;
            begin
            PKG_TX1207.ONAY_SONRASI(ln_islem_no);

                        Exception

                        When Others then
                        log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;
            begin
            PKG_TX1207.MUHASEBELESME(ln_islem_no);
            update cbs_islem
                        set durum = 'P',
                        tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
                        where numara=ln_islem_no;
                        Exception

                        When Others then
                        log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;


    end if;

 exception
 when others then
 log_at('pkg_kredi_pd_closing','1207', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4669' ||  Pkg_Hata.getdelimiter|| pn_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);


end;

procedure sp_transfer_for_pd_closing(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number, pn_alis_tutari out number) is

 ln_musteri_no number;
 ln_available_balance number;
 ls_account_currency cbs_hesap.doviz_kodu%type;
 ls_account_branch cbs_hesap.sube_kodu%type;
 ln_block_sum number;  --TemirlanT
 ln_bakiye number;  --TemirlanT
 ln_difference_amount number; --TemirlanT

 ln_islem_kod number;
 ln_islem_no number;

 ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
 ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
 ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
 ls_loan_currency cbs_hesap_kredi.doviz_kodu%type;

 ls_kur_tipi CBS_ARBITRAJ_ISLEM.KUR_TIPI%type;
 ls_alis_doviz_kodu CBS_ARBITRAJ_ISLEM.ALIS_DOVIZ_KODU%type;
 ls_SATIS_DOVIZ_KODU CBS_ARBITRAJ_ISLEM.SATIS_DOVIZ_KODU%type;
 ls_RESIDENCY_CODE CBS_ARBITRAJ_ISLEM.RESIDENCY_CODE%type;
 ls_CITIZEN_CODE CBS_ARBITRAJ_ISLEM.CITIZEN_CODE%type;
 ls_TAX_NUMBER CBS_ARBITRAJ_ISLEM.TAX_NUMBER%type;
 ls_KUR_PARITE_SECIM CBS_ARBITRAJ_ISLEM.KUR_PARITE_SECIM%type;
 ln_ALIS_KURU CBS_ARBITRAJ_ISLEM.ALIS_KURU%type;
 ln_SATIS_KURU CBS_ARBITRAJ_ISLEM.SATIS_KURU%type;
 ln_ALIS_TUTARI CBS_ARBITRAJ_ISLEM.ALIS_TUTARI%type;
 ln_SATIS_TUTARI CBS_ARBITRAJ_ISLEM.SATIS_TUTARI%type;
 ln_ALIS_HESAP_NO CBS_ARBITRAJ_ISLEM.ALIS_HESAP_NO%type;
 ln_SATIS_HESAP_NO CBS_ARBITRAJ_ISLEM.SATIS_HESAP_NO%type;
 ls_NAME_SURNAME CBS_ARBITRAJ_ISLEM.NAME_SURNAME%type;
 ls_ACIKLAMA CBS_ARBITRAJ_ISLEM.ACIKLAMA%type;
 ls_ISTATISTIK_KODU_ALIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_ALIS%type;
 ls_ISTATISTIK_KODU_SATIS CBS_ARBITRAJ_ISLEM.ISTATISTIK_KODU_SATIS%type;

 ln_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 --ls_related_acc_curr CBS_HESAP.DOVIZ_KODU%type;
 ln_related_acc_count number;

 ln_account_no CBS_HESAP.HESAP_NO%type;
 ln_currency CBS_HESAP.DOVIZ_KODU%type;
 ln_account_count number;

 ln_parity CBS_ARBITRAJ_ISLEM.PARITE%type;
 ls_carp_bol_secimi CBS_ARBITRAJ_ISLEM.CARP_BOL_SECIMI%type;
 lb_buy_loan_currency boolean := false;
 lb_bought_amount boolean := false;
 ln_satis_hesap_avail_bal number;

 ls_explanation varchar2(100) := '3199 transaction pd closing';
 ls_bos_referans varchar2(100) := '';

 ln_lc_amount number;
 incorrect_related_account exception;
 ls_ISTATISTIK_KODU CBS_VIRMAN_ISLEM.ISTATISTIK_KODU%type;

begin
    ls_account_currency := pkg_hesap.HesaptanDovizKoduAl(pn_current_account);
    ln_musteri_no :=  pkg_hesap.HesaptanMusteriNoAl(pn_current_account);
    ls_account_branch := pkg_hesap.HesapSubeAl(pn_current_account);
    ls_loan_currency := pkg_hesap.HesaptanDovizKoduAl(pn_loan_account);



    ln_islem_kod := 1208;
    ln_islem_no:=CBS.pkg_tx.islem_no_al;
    ls_explanation := 'ПЕРЕВОД С ' || pn_current_account || ' НА ' || pn_alter_current_account || ' ДЛЯ ПОГАШЕНИЯ КРЕДИТА (' || pn_loan_account || ')';


    ln_related_account := pn_alter_current_account;
    -- BOM TemirlanT cbs-119
    begin
        select bloke_tutari
        into ln_block_sum
        from cbs_bloke b
        where b.bloke_neden_kodu ='70'
        and b.durum_kodu = 'A'
        and B.BLOKE_TUTARI > 0
        and hesap_no = pn_current_account;
    exception when no_data_found then
        ln_block_sum := 0;
    end;
    ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(pn_current_account),2);
    ln_alis_tutari := pn_amount;
    if ln_block_sum > 0 then
        if ln_block_sum > (ln_bakiye - ln_alis_tutari) then
            ln_difference_amount := ln_block_sum - (ln_bakiye - ln_alis_tutari);
            if ln_alis_tutari > ln_difference_amount then
                ln_alis_tutari := ln_alis_tutari - ln_difference_amount;
            else
                ln_alis_tutari := 0;
            end if;
        end if;
    end if;
    pn_alis_tutari := ln_alis_tutari;
    if pn_amount > 0 then
    -- EOM TemirlanT cbs-119
        if ln_related_account is not null and ln_related_account <> pn_current_account then

            pkg_tx1203.sp_urun_tur_sinif_al(pn_current_account, ln_related_account, ls_account_currency, null, ls_modul_tur_kod,ls_urun_tur_kod, ls_urun_sinif_kod);
            pkg_parametre.deger('ISTAT_KODU_B2B_FOR_PD_CLOSING', ls_ISTATISTIK_KODU );
            insert into CBS_VIRMAN_ISLEM (TX_NO                   ,
                                      BORC_HESAP_NO           ,
                                      DOVIZ_KODU              ,
                                      TUTAR                   ,
                                      ALACAK_HESAP_NO         ,
                                      ACIKLAMA                ,
                                      BORC_EXTERNAL_HESAP     ,
                                      BORC_VERGI_NO           ,
                                      ALACAK_EXTERNAL_HESAP   ,
                                      ALACAK_VERGI_NO         ,
                                      ISTATISTIK_KODU         ,
                                      CHARGE_AMOUNT           )
            values (ln_islem_no,
                 pn_current_account,
                 ls_account_currency,
                 ln_alis_tutari,
                 ln_related_account,
                 ls_explanation,
                 pkg_hesap.External_HesapNo_Al(pn_current_account),
                 PKG_MUSTERI.Sf_VergiNo_Al(ln_musteri_no),
                 pkg_hesap.External_HesapNo_Al(ln_related_account),
                 PKG_MUSTERI.Sf_VergiNo_Al(ln_musteri_no),
                 ls_ISTATISTIK_KODU,
                 0);

               -- 1.  Create user session
                cbs.PKG_BAGLAM.YARAT(
                ls_account_branch,    --branch code of the CBS user (refers to the table CBS_BOLUM column KODU)
                '0' --role of the CBS user (refers to the table CBS_ROL column NUMARA)
                );

            begin
            Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                                  KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                                  KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                                  MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                                  MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                          values (ln_islem_no,ln_islem_kod,'N',ls_account_branch,
                                  'CBS','0',ls_account_branch,
                                  pkg_muhasebe.banka_tarihi_bul,sysdate,
                                  ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,
                                  ln_musteri_no,ln_alis_hesap_no,ln_ALIS_TUTARI,null,ls_alis_doviz_kodu
                              );

            update cbs_islem_gecici
                   set durum = 'C'
                 where numara=ln_islem_no;
            Exception
                   When Others Then
                    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
            end ;

            Giris_Kontrol(ln_islem_no);

            begin
            PKG_TX1203.KONTROL_SONRASI(ln_islem_no);
            Exception

                        When Others then
                        log_at('tx_error_ais_kontrol',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;
            begin
            PKG_TX1203.ONAY_SONRASI(ln_islem_no);

                        Exception

                        When Others then
                        log_at('tx_error_ais_onay',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;
            begin
            PKG_TX1203.MUHASEBELESME(ln_islem_no);
            update cbs_islem
                        set durum = 'P',
                        tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
                        where numara=ln_islem_no;

                        Exception

                        When Others then
                        log_at('tx_error_ais_muh',sqlerrm, dbms_utility.format_error_backtrace);
                           Rollback;
                           Raise_application_error(-20100,SQLERRM);
            end;
    /*else
       raise incorrect_related_account; */
        end if;
    end if;   --TemirlanT cbs-119


 exception
 when incorrect_related_account then
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4671' ||  Pkg_Hata.getdelimiter|| pn_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 when others then
     log_at('pkg_kredi_pd_closing','1203', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4672' ||  Pkg_Hata.getdelimiter|| pn_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);


end;



    function arbitraj_kur( ps_account_currency varchar2,
                            ps_past_due_currency varchar2,
                            pn_available_amount number,
                            ps_account_branch varchar2,
                            pb_buy_loan_currency boolean default false,
                            pb_bought_amount boolean default false) return number

    is

    ls_alis_doviz_kodu CBS_ARBITRAJ_ISLEM.ALIS_DOVIZ_KODU%type;
    ls_SATIS_DOVIZ_KODU CBS_ARBITRAJ_ISLEM.SATIS_DOVIZ_KODU%type;
    ln_ALIS_TUTARI CBS_ARBITRAJ_ISLEM.ALIS_TUTARI%type;
    ln_SATIS_TUTARI CBS_ARBITRAJ_ISLEM.SATIS_TUTARI%type;
    ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
    ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
    ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
    ls_account_branch cbs_hesap.sube_kodu%type;
    ln_ALIS_KURU CBS_ARBITRAJ_ISLEM.ALIS_KURU%type;
    ln_SATIS_KURU CBS_ARBITRAJ_ISLEM.SATIS_KURU%type;
    ln_parity CBS_ARBITRAJ_ISLEM.PARITE%type;
    ls_carp_bol_secimi CBS_ARBITRAJ_ISLEM.CARP_BOL_SECIMI%type;
    ls_KUR_PARITE_SECIM CBS_ARBITRAJ_ISLEM.KUR_PARITE_SECIM%type;
    exception_not_arbitraj exception;

    begin

    if pb_buy_loan_currency = true then
        ls_alis_doviz_kodu := ps_past_due_currency;
        ls_satis_doviz_kodu := ps_account_currency;
    elsif pb_buy_loan_currency = false then
        ls_alis_doviz_kodu := ps_account_currency;
        ls_satis_doviz_kodu := ps_past_due_currency;
    end if;

    if ls_alis_doviz_kodu <> pkg_genel.lc_al and ls_satis_doviz_kodu <> pkg_genel.lc_al then
        ls_urun_sinif_kod  := 'FC-FC';
    end if;

    if pb_bought_amount = false then
        ln_ALIS_TUTARI := 0;
        ln_satis_TUTARI := pn_available_amount;
    elsif pb_bought_amount = true then
        ln_ALIS_TUTARI := pn_available_amount;
        ln_satis_TUTARI := 0;
    end if;

    ls_account_branch := ps_account_branch;

    ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_account_branch);
    ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_account_branch);

    if ls_urun_sinif_kod  = 'FC-FC' and ln_alis_kuru is not null and ln_satis_kuru is not null then
        if pb_bought_amount = false then
            ls_KUR_PARITE_SECIM := 'P';
            --USD---------------------------------
            if ls_alis_doviz_kodu = 'USD' then
                if ls_satis_doviz_kodu in ('TRY','CHF','CAD','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('EUR','GBP','AUD') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --EUR---------------------------------
            if ls_alis_doviz_kodu = 'EUR' then
                if ls_satis_doviz_kodu in ('USD','GBP','TRY','CHF','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --RUB---------------------------------
            if ls_alis_doviz_kodu = 'RUB' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','TRY','CHF','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --KZT---------------------------------
            if ls_alis_doviz_kodu = 'KZT' then
                if ls_satis_doviz_kodu in ('USD','EUR','RUB','GBP','TRY','CHF','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'CARP';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --GBP---------------------------------
            if ls_alis_doviz_kodu = 'GBP' then
                if ls_satis_doviz_kodu in ('TRY','CHF','AUD','CNY','USD','CAD') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('EUR') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --TRY---------------------------------
            if ls_alis_doviz_kodu = 'TRY' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --CHF---------------------------------
            if ls_alis_doviz_kodu = 'CHF' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('TRY','AUD','CAD','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --AUD---------------------------------
            if ls_alis_doviz_kodu = 'AUD' then
                if ls_satis_doviz_kodu in ('EUR','GBP','CHF') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('USD','TRY','CAD','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --CAD---------------------------------
            if ls_alis_doviz_kodu = 'CAD' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('TRY','CNY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            --CNY---------------------------------
            if ls_alis_doviz_kodu = 'CNY' then
                if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD') then
                    ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'CARP';
                elsif ls_satis_doviz_kodu in ('TRY') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                    ls_carp_bol_secimi := 'BOL';
                elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                    ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    ls_carp_bol_secimi := 'BOL';
                else
                    if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    end if;
                end if;
            end if;

            if ls_carp_bol_secimi = 'CARP' then
               ln_ALIS_TUTARI := round((nvl(ln_SATIS_TUTARI,0) * ln_parity),2) ;
            else
               ln_ALIS_TUTARI := round((nvl(ln_SATIS_TUTARI,0) / ln_parity),2);
            end if;

            return ln_ALIS_TUTARI;

        elsif pb_bought_amount = true then

            ls_KUR_PARITE_SECIM := 'P';
                --USD---------------------------------
                if ls_alis_doviz_kodu = 'USD' then
                    if ls_satis_doviz_kodu in ('TRY','CHF','CAD','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('EUR','GBP','AUD') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --EUR---------------------------------
                if ls_alis_doviz_kodu = 'EUR' then
                    if ls_satis_doviz_kodu in ('USD','GBP','TRY','CHF','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --RUB---------------------------------
                if ls_alis_doviz_kodu = 'RUB' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','TRY','CHF','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --KZT---------------------------------
                if ls_alis_doviz_kodu = 'KZT' then
                    if ls_satis_doviz_kodu in ('USD','EUR','RUB','GBP','TRY','CHF','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'BOL';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),2);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --GBP---------------------------------
                if ls_alis_doviz_kodu = 'GBP' then
                    if ls_satis_doviz_kodu in ('TRY','CHF','AUD','CNY','USD','CAD') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('EUR') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --TRY---------------------------------
                if ls_alis_doviz_kodu = 'TRY' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --CHF---------------------------------
                if ls_alis_doviz_kodu = 'CHF' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('TRY','AUD','CAD','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --AUD---------------------------------
                if ls_alis_doviz_kodu = 'AUD' then
                    if ls_satis_doviz_kodu in ('EUR','GBP','CHF') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('USD','TRY','CAD','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --CAD---------------------------------
                if ls_alis_doviz_kodu = 'CAD' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('TRY','CNY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                --CNY---------------------------------
                if ls_alis_doviz_kodu = 'CNY' then
                    if ls_satis_doviz_kodu in ('USD','EUR','GBP','CHF','AUD','CAD') then
                        ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'BOL';
                    elsif ls_satis_doviz_kodu in ('TRY') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                        ls_carp_bol_secimi := 'CARP';
                    elsif ls_satis_doviz_kodu in ('RUB','KZT') then
                        ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),2);
                        ls_carp_bol_secimi := 'CARP';
                    else
                        if nvl(ln_SATIS_KURU,0) < nvl(ln_ALIS_KURU,0) then
                            ln_parity := round((nvl(ln_ALIS_KURU,0) / nvl(ln_SATIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'BOL';
                        else
                            ln_parity := round((nvl(ln_SATIS_KURU,0) / nvl(ln_ALIS_KURU,0)),4);
                            ls_carp_bol_secimi := 'CARP';
                        end if;
                    end if;
                end if;

                if ls_carp_bol_secimi = 'CARP' then
                   ln_SATIS_TUTARI := round((nvl(ln_ALIS_TUTARI,0) * ln_parity),2) ;
                else
                   ln_SATIS_TUTARI := round((nvl(ln_ALIS_TUTARI,0) / ln_parity),2);
                end if;

                return ln_SATIS_TUTARI;

        end if;

    else

    raise exception_not_arbitraj;

    end if;

    exception when exception_not_arbitraj then
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1001' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

    when others then
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1004' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

    end;

Procedure Giris_Kontrol(pn_islem_no number) is

   lc_dogrulama                varchar2(1);
   lc_onay                     varchar2(1);
   lc_iptal_onay            varchar2(1);
   lc_dogrula_guncelle  varchar2(1);
   lc_onay_guncelle     varchar2(1);

   cursor c1 is
    select rui.dogrulama,rui.onay,rui.dogrula_guncelle,rui.onayla_guncelle,rui.iptal_onay
      from cbs_rol_urun_islem rui,cbs_islem,cbs_zaman,cbs_limit
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum IN ('N')
       and cbs_islem.islem_kod      = rui.islem_tanim_kod
       and cbs_islem.modul_tur_kod  = rui.modul_tur_kod
       and cbs_islem.urun_tur_kod   = rui.urun_tur_kod
       and cbs_islem.urun_sinif_kod = rui.urun_sinif_kod
       and rui.rol_numara       = 0
       and rui.zaman_numara     = cbs_zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = cbs_limit.numara
       and ( ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'S' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between alt and ust)  or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'F' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,ust) ) or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'L' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,ust) ) or
               ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'F'
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'L'
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( cbs_limit.karsilik = 'N' )
             );

   Begin
        Begin
       open c1;
       loop
          fetch c1 into lc_dogrulama,lc_onay,lc_dogrula_guncelle,lc_onay_guncelle,lc_iptal_onay;
          exit when c1%notfound;
          pkg_tx.Kilit_Test(pn_islem_no);

          update cbs_islem
            set durum           = 'C' ,
                dogrulanmali_mi = lc_dogrulama,
                onaylanmali_mi  = lc_onay,
                iptal_onaylanmali_mi=lc_iptal_onay,
                dogrula_guncelle = lc_dogrula_guncelle,
                onay_guncelle = lc_onay_guncelle
          where numara=pn_islem_no;

        return;
       end loop;
       close c1;
     Exception
          When Others Then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'62'|| pkg_hata.getDELIMITER ||TO_CHAR(SQLCODE)|| ' ' || replace(SQLERRM,'***','')||pkg_hata.getDELIMITER ||pkg_hata.getUCPOINTER);
     End;
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'61'|| pkg_hata.getDELIMITER ||TO_CHAR(SQLCODE)|| ' ' || replace(SQLERRM,'***','')||pkg_hata.getDELIMITER ||pkg_hata.getUCPOINTER);
   End;

  FUNCTION what_month(pd_date date) RETURN varchar2
  IS
    ls_month varchar2(20);
    ls_G_PD_WHAT_MONTH_EXPLANATION varchar2(200);
    begin
        Pkg_Parametre.deger('G_PD_WHAT_MONTH_EXPLANATION',ls_G_PD_WHAT_MONTH_EXPLANATION);
        --ЯНВАРЬ ФЕВРАЛЬ МАРТ АПРЕЛЬ МАЙ ИЮНЬ ИЮЛЬ АВГУСТ СЕНТЯБРЬ ОКТЯБРЬ НОЯБРЬ ДЕКАБРЬ
        if to_number(to_char(pd_date, 'MM'))=1 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 1, 6);
        elsif to_number(to_char(pd_date, 'MM'))=2 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 8, 7);
        elsif to_number(to_char(pd_date, 'MM'))=3 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 16, 4);
        elsif to_number(to_char(pd_date, 'MM'))=4 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 21, 6);
        elsif to_number(to_char(pd_date, 'MM'))=5 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 28, 3);
        elsif to_number(to_char(pd_date, 'MM'))=6 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 32, 4);
        elsif to_number(to_char(pd_date, 'MM'))=7 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 37, 4);
        elsif to_number(to_char(pd_date, 'MM'))=8 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 42, 6);
        elsif to_number(to_char(pd_date, 'MM'))=9 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 49, 8);
        elsif to_number(to_char(pd_date, 'MM'))=10 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 58, 7);
        elsif to_number(to_char(pd_date, 'MM'))=11 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 66, 6);
        elsif to_number(to_char(pd_date, 'MM'))=12 then
            ls_month := SUBSTR (ls_G_PD_WHAT_MONTH_EXPLANATION, 73, 7);
        end if;
        return ls_month;
    end;
  FUNCTION payment_anapara_pd_before_2013(pn_available_amount number) RETURN number
  IS
    begin
        return 0;
    end;
  FUNCTION payment_faiz_pd_before_2013(pn_available_amount number) RETURN number
  IS
    begin
        return 0;
    end;
  FUNCTION payment_def_int_before_2013_pd(pn_available_amount number) RETURN number
  IS
    begin
        return 0;
    end;
  FUNCTION payment_penalty_pd_before_2013(pn_available_amount number) RETURN number
  IS
    begin
        return 0;
    end;
  PROCEDURE payment_anapara_pd_after_2013(pn_available_amount number, pn_musteri_no number, ps_name_surname varchar2, pn_available_amount_after out number)
  IS
    ln_available_amount number;
    ls_collection_currency CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
    ln_collection_account number;
    ln_acc_amount_before number;
    ln_pd_account_no number;
    ln_pd_balance number;
    ln_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%TYPE;
    ln_loan_account CBS_HESAP_KREDI.HESAP_NO%TYPE;
    ls_month_explanation varchar2(20);

    ls_modul_tur_kod CBS_ISLEM.MODUL_TUR_KOD%TYPE;
    ls_urun_tur_kod CBS_ISLEM.URUN_TUR_KOD%TYPE;
    ls_urun_sinif_kod CBS_ISLEM.URUN_SINIF_KOD%TYPE;
    ln_gecenyil_faiz_tutari number;
    ln_gecmis_aylarin_faizi number;
    ln_birikmis_faiz_tutari number;
    ln_toplam_faiz_tim number;
    ls_pd_branch_cd CBS_HESAP_KREDI.SUBE_KODU%TYPE;
    ls_son_gun_faizi CBS_HESAP_KREDI.SON_GUN_FAIZI%TYPE;

    ln_faiz_tutari number;
    ln_komisyon_tutari number;
    ln_toplam_faiz number;
    ld_value_date date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
    --ls_collection_currency CBS_HESAP;
    --ls_account_currency;
    ln_rate number;
    ls_durum_kodu CBS_HESAP_KREDI_ISLEM.DURUM_KODU%TYPE;
    ln_count_b boolean;
    ln_delayed_days number;
    ls_day varchar2(100);
    ls_part varchar2(10);
    ln_anapara_tahsilat_tutar number;
    ls_aciklama CBS_HESAP_KREDI_ISLEM.ACIKLAMA%TYPE;
    ls_choice CBS_HESAP_KREDI_ISLEM.GERIODEME_KAPAMA_SECIMI%TYPE;
    ln_tahsedil_gecenyilfaiztutar CBS_HESAP_KREDI_ISLEM.TAHSEDIL_GECENYIL_FAIZ_TUTARI%TYPE;
    ln_tahsedil_gecmis_aylar_faiz CBS_HESAP_KREDI_ISLEM.TAHSEDIL_GECMIS_AYLAR_FAIZ%TYPE;
    ln_tahsedil_birikmisfaiztutar CBS_HESAP_KREDI_ISLEM.TAHSEDIL_BIRIKMIS_FAIZ_TUTARI%TYPE;

     CURSOR cur_anapara_pd_after_2013 IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance ,
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=pn_musteri_no
        and abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) > 0
        --and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) >= ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and ld_value_date - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;
    r_anapara_pd_after_2013  cur_anapara_pd_after_2013%ROWTYPE;

    begin
        ln_available_amount := pn_available_amount;
        if trunc(ln_available_amount,2) > 0 then
            open cur_anapara_pd_after_2013;
            loop
                fetch cur_anapara_pd_after_2013 into r_anapara_pd_after_2013;
                exit when cur_anapara_pd_after_2013%notfound;
                if trunc(ln_available_amount,2) > 0 then
                    ls_collection_currency := r_anapara_pd_after_2013.doviz_kodu;
                    ln_acc_amount_before := ln_available_amount;
                    ln_pd_account_no := r_anapara_pd_after_2013.hesap_no;
                    ln_pd_balance := r_anapara_pd_after_2013.pd_balance;
                    ln_related_account := r_anapara_pd_after_2013.iliskili_hesap_no;
                    ln_loan_account := r_anapara_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                    ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_anapara_pd_after_2013.ACILIS_TARIHI); --TemirlanT cbs-119
                    log_at('cbs-timka_pd',1,2,'ln_available_amount='||ln_available_amount||' ln_general_balance=');

                    /*begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;*/

                    /*if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;*/

                    --if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                        log_at('cbs-timka_pd','anapara',2);

                        ls_modul_tur_kod := r_anapara_pd_after_2013.modul_tur_kod;
                        ls_urun_tur_kod := r_anapara_pd_after_2013.urun_tur_kod;
                        ls_urun_sinif_kod := r_anapara_pd_after_2013.urun_sinif_kod;
                        ln_gecenyil_faiz_tutari := nvl(r_anapara_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                        ln_gecmis_aylarin_faizi := nvl(r_anapara_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                        ln_birikmis_faiz_tutari := nvl(r_anapara_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                        ls_pd_branch_cd := r_anapara_pd_after_2013.sube_kodu;
                        ls_son_gun_faizi := r_anapara_pd_after_2013.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if;

                        ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                        --ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                        --ls_collection_currency := ls_account_currency;

                        /*if ls_collection_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_collection_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else*/
                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_collection_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        --end if;

                        if ln_toplam_faiz <> 0 then
                            ls_choice := 'GERI ODEME';
                        end if;

                        if ls_choice = 'KAPAMA' then
                            ls_durum_kodu := 'K';
                        else
                            ls_durum_kodu := 'A';
                        end if;


                        if ln_count_b then
                            ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_anapara_pd_after_2013.acilis_tarihi;
                            --BOM TemirlanT
                            pkg_parametre.deger('G_PD_DAY_EXPLANATION',ls_day);
                            if ln_delayed_days=1 then
                                ls_day := SUBSTR (ls_day, 1, 4);
                            elsif ln_delayed_days in (2,3,4) then
                                ls_day := SUBSTR (ls_day, 6, 3);
                            elsif ln_delayed_days >= 5 and ln_delayed_days <= 21 then
                                ls_day := SUBSTR (ls_day, 10, 4);
                            elsif ln_delayed_days >= 22 and (mod(ln_delayed_days,10)  in (2,3,4)) then
                                ls_day := SUBSTR (ls_day, 6, 3);
                            else
                                ls_day := SUBSTR (ls_day, 10, 4);
                            end if;
                            --EOM TemirlanT
                            pkg_parametre.deger('G_PD_MAIN_ELEVATED_EXPLANATION',ls_aciklama);
                            ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            ls_aciklama := REPLACE (ls_aciklama, '$$$', ln_delayed_days);
                            ls_aciklama := REPLACE (ls_aciklama, '@@@', ls_day);
                            ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                            ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                            ls_aciklama := REPLACE (ls_aciklama, '&&&', ps_name_surname); --TemirlanT timka
                            ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                            ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                            if ln_available_amount >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            else
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                ls_choice := 'GERI ODEME';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                            end if;
                            ls_durum_kodu := 'K';
                        else
                            pkg_parametre.deger('G_PD_MAIN_EXPLANATION',ls_aciklama);
                            ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                            ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                            ls_aciklama := REPLACE (ls_aciklama, '&&&', ps_name_surname); --TemirlanT timka
                            if ln_available_amount >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            else
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                ls_choice := 'GERI ODEME';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                            end if;
                            ln_tahsedil_gecenyilfaiztutar := 0;
                            ln_tahsedil_gecmis_aylar_faiz := 0;
                            ln_tahsedil_birikmisfaiztutar := 0;

                        end if;
                        ln_toplam_faiz_tim := ln_tahsedil_gecenyilfaiztutar + ln_tahsedil_gecmis_aylar_faiz + ln_tahsedil_birikmisfaiztutar;
                        --ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        --ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                        log_at('cbs-timka_pd','anapara',1,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                               ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                               ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                               ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                               ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                               ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                               ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                               ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                               ||' ls_past_due_currency='||' ln_musteri_no='||pn_musteri_no);
                        PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,--
                                                     ln_tahsedil_gecmis_aylar_faiz,--
                                                     ln_tahsedil_birikmisfaiztutar,--
                                                     ln_anapara_tahsilat_tutar,--
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_collection_currency,
                                                     pn_musteri_no
                                                     );

                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0) - nvl(ln_toplam_faiz_tim,0);
                    --end if;
                    log_at('cbs-timka_pd',1,7,'pn_available_amount='||pn_available_amount);
                end if;
            end loop;
            close cur_anapara_pd_after_2013;
        end if;
        pn_available_amount_after := nvl(ln_available_amount,0);
    end;
  PROCEDURE payment_faiz_pd_after_2013(pn_available_amount number, pn_musteri_no number, ps_name_surname varchar2, pn_available_amount_after out number)
  IS
    ln_available_amount number;
    ls_collection_currency CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
    ln_collection_account number;
    ln_acc_amount_before number;
    ln_pd_account_no number;
    ln_pd_balance number;
    ln_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%TYPE;
    ln_loan_account CBS_HESAP_KREDI.HESAP_NO%TYPE;
    ls_month_explanation varchar2(20);

    ls_modul_tur_kod CBS_ISLEM.MODUL_TUR_KOD%TYPE;
    ls_urun_tur_kod CBS_ISLEM.URUN_TUR_KOD%TYPE;
    ls_urun_sinif_kod CBS_ISLEM.URUN_SINIF_KOD%TYPE;
    ln_gecenyil_faiz_tutari number;
    ln_gecmis_aylarin_faizi number;
    ln_birikmis_faiz_tutari number;
    ln_toplam_faiz_tim number;
    ls_pd_branch_cd CBS_HESAP_KREDI.SUBE_KODU%TYPE;
    ls_son_gun_faizi CBS_HESAP_KREDI.SON_GUN_FAIZI%TYPE;

    ln_faiz_tutari number;
    ln_komisyon_tutari number;
    ln_toplam_faiz number;
    ld_value_date date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
    --ls_collection_currency CBS_HESAP;
    --ls_account_currency;
    ln_rate number;
    ls_durum_kodu CBS_HESAP_KREDI_ISLEM.DURUM_KODU%TYPE;
    ln_count_b boolean;
    ln_delayed_days number;
    ls_day varchar2(100);
    ls_part varchar2(10);
    ln_anapara_tahsilat_tutar number;
    ls_aciklama CBS_HESAP_KREDI_ISLEM.ACIKLAMA%TYPE;
    ls_choice CBS_HESAP_KREDI_ISLEM.GERIODEME_KAPAMA_SECIMI%TYPE;
    ln_tahsedil_gecenyilfaiztutar CBS_HESAP_KREDI_ISLEM.TAHSEDIL_GECENYIL_FAIZ_TUTARI%TYPE;
    ln_tahsedil_gecmis_aylar_faiz CBS_HESAP_KREDI_ISLEM.TAHSEDIL_GECMIS_AYLAR_FAIZ%TYPE;
    ln_tahsedil_birikmisfaiztutar CBS_HESAP_KREDI_ISLEM.TAHSEDIL_BIRIKMIS_FAIZ_TUTARI%TYPE;

    CURSOR cur_faiz_pd_after_2013 IS
        select * from (
            --only faiz
            select K.MUSTERI_NO,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount ,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')
            and KK.HESAP_NO is null
            union all
            --only tax
            select k.musteri_no, K.ACILIS_TARIHI, kk.doviz_kodu, kk.hesap_no, kk.modul_tur_kod, Kk.URUN_TUR_KOD, Kk.URUN_SINIF_KOD, kk.GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu, Kk.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_faiz_amount ,
            k.doviz_kodu tax_doviz_kodu, k.hesap_no tax_hesap_no, k.modul_tur_kod tax_modul_tur_kod, k.URUN_TUR_KOD tax_URUN_TUR_KOD, k.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    k.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, k.sube_kodu tax_sube_kodu, k.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')
            and KK.HESAP_NO is null
            union all
            --both faiz and tax
            select k.musteri_no,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC') ) k
            where k.musteri_no=pn_musteri_no
            --and k.ana_hesap_acilis >= ld_date
            --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
            and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
            order by K.ACILIS_TARIHI, k.ana_hesap_acilis;

    r_faiz_pd_after_2013  cur_faiz_pd_after_2013%ROWTYPE;

    begin
        ln_available_amount := pn_available_amount;
        /*if trunc(ln_available_amount,2) > 0 then
            open cur_faiz_pd_after_2013;
            loop
                fetch cur_faiz_pd_after_2013 into r_faiz_pd_after_2013;
                exit when cur_faiz_pd_after_2013%notfound;
                ln_loan_account := r_faiz_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_faiz_pd_after_2013.ACILIS_TARIHI); --TemirlanT cbs-119
                if trunc(nvl(ln_available_amount,0),2) > 0 then --end if
                    log_at('cbs-timka_pd','faiz-1',1, 'ln_available_amount='||ln_available_amount);
                    if nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) > 0 then --end if 0->12
                        --aisuluud
                        ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                        ln_acc_amount_before := ln_available_amount;
                        log_at('cbs-timka_pd','faiz-1',2,'ln_available_amount='||ln_available_amount||' ls_past_due_currency='||ls_past_due_currency);

                        if nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) + nvl(r_faiz_pd_after_2013.pd_tax_amount,0) <= trunc(ln_available_amount,2) then
                            log_at('cbs-timka_pd','faiz-1',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                            if trunc(ln_available_amount,2) > 0 then
                                -------------------------FAIZ--------------------------------------------------------------

                                ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account := null;
                                end;
                                ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));

                                log_at('cbs-timka_pd','faiz-1',8,'ln_available_amount='||ln_available_amount||' ln_current_account='||ln_current_account);
                                /*if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                --if lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита по faiz и tax
                                    log_at('cbs-timka_pd','faiz-1',9,'ln_available_amount='||ln_available_amount||' ln_current_account='||ln_current_account);
                                    if round(ln_available_amount,2) >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    log_at('cbs-timka_pd','faiz-1',10,'ln_available_amount='||ln_available_amount||' ls_choice='||ls_choice);
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    --ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;

                                    log_at('cbs-timka_pd','faiz-1',11,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);
                                    log_at('cbs-timka_pd','faiz-1',12,'ln_available_amount='||ln_available_amount||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar);
                                --end if;
                                    log_at('cbs-timka_pd','faiz-1',13,'ln_available_amount='||ln_available_amount||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar);
                                ----------------------------FAIZ--------------------------------------------------------------

                                -------------------------------TAX----------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                log_at('cbs-timka_pd','tax-1',1,'ln_available_amount='||ln_available_amount||' ls_past_due_currency='||ls_past_due_currency);
                                ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;

                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);

                                /*if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                --if lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредитa

                                    if ln_available_amount >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;

                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','tax-1',2,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);

                                --end if;
                                log_at('cbs-timka_pd','tax-1',3,'ln_available_amount='||ln_available_amount||' ls_account_currency='||ls_account_currency);
                            end if;
                            -------------------------TAX----------------------------------------------------------------
                        else
                            ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;

                            if trunc(ln_available_amount,2) > 0 then
                                ln_pd_tax_balance := round(ln_available_amount,2) * 2 / (100+2);
                                ln_pd_interest_balance := round(ln_available_amount,2) - ln_pd_tax_balance;
                                -------------------------FAIZ--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                                ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;
                                log_at('cbs-timka_pd','faiz_tax_faiz',1,'ln_available_amount='||ln_available_amount||' ln_pd_tax_balance='||ln_pd_tax_balance
                                                            ||' ln_pd_interest_balance='||ln_pd_interest_balance||' ln_pd_balance='||ln_pd_balance);

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);

                                log_at('cbs-timka_pd','faiz_tax_faiz',2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                                -------------------------------------------

                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредитa
                                    if ln_pd_interest_balance >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_interest_balance);
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);

                                    ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    log_at('cbs-timka_pd','faiz_tax_faiz',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','faiz_tax_faiz',4,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );

                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);

                                end if; --bloke
                                log_at('cbs-timka_pd','faiz_tax_faiz',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                                -------------------------FAIZ--------------------------------------------------------------

                                -------------------------TAX--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                log_at('cbs-timka_pd','faiz_tax_tax',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_past_due_currency='||ls_past_due_currency||' ln_acc_amount_before='||ln_acc_amount_before);

                                ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;

                                if ln_pd_tax_balance >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_tax_balance);
                                    ls_choice := 'GERI ODEME';
                                end if;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                log_at('cbs-timka_pd','faiz_tax_tax',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka

                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    log_at('cbs-timka_pd','faiz_tax_tax',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','faiz_tax_tax',8,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                    log_at('tahsilat_4883project4',9,'ln_pd_account_no: '||ln_pd_account_no||' ln_available_amount: '||ln_available_amount||' ln_anapara_tahsilat_tutar: '||ln_anapara_tahsilat_tutar );
                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                                    log_at('tahsilat_4883project4',10,'ln_pd_account_no: '||ln_pd_account_no||' ln_available_amount: '||ln_available_amount||' ln_anapara_tahsilat_tutar: '||ln_anapara_tahsilat_tutar );
                                end if; --bloke

                                -------------------------TAX--------------------------------------------------------------
                                log_at('cbs-timka_pd','faiz_tax_tax',9,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                            end if;

                        end if;
                        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                    elsif nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) = 0 then
                        log_at('cbs-timka_pd','faiz_1_tax_0',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                        -------------------------FAIZ--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                            ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;

                            log_at('cbs-timka_pd','faiz_1_tax_0',2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);

                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;
                            ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                            log_at('cbs-timka_pd','faiz_1_tax_0',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;

                            if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;

                                ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;

                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;

                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                ls_collection_currency := ls_account_currency;

                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;

                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                if ln_toplam_faiz <> 0 then
                                    ls_choice := 'GERI ODEME';
                                end if;

                                pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka

                                if ls_choice = 'KAPAMA' then
                                    ls_durum_kodu := 'K';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                else
                                    ls_durum_kodu := 'A';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                end if;
                                log_at('cbs-timka_pd','faiz_1_tax_0',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_durum_kodu='||ls_durum_kodu||' ls_choice='||ls_choice);
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                log_at('cbs-timka_pd','faiz_1_tax_0',5,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                            end if;--bloke
                            log_at('cbs-timka_pd','faiz_1_tax_0',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                        end if;

                        -------------------------FAIZ--------------------------------------------------------------
                    elsif nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) = 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) > 0 then
                        -------------------------TAX--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                            ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;
                            log_at('cbs-timka_pd','faiz_0_tax_1',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);

                            ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));

                            log_at('cbs-timka_pd','faiz_0_tax_1',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;

                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;

                            if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;

                                ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;

                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;

                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                ls_collection_currency := ls_account_currency;

                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;

                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                if ln_toplam_faiz <> 0 then
                                    ls_choice := 'GERI ODEME';
                                end if;
                                pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                if ls_choice = 'KAPAMA' then
                                    ls_durum_kodu := 'K';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                else
                                    ls_durum_kodu := 'A';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                end if;
                                log_at('cbs-timka_pd','faiz_0_tax_1',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_durum_kodu='||ls_durum_kodu||' ls_choice='||ls_choice);
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                log_at('cbs-timka_pd','faiz_0_tax_1',5,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                pkg_kredi.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod,
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );

                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                            end if;--bloke
                            log_at('cbs-timka_pd','faiz_0_tax_1',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                        end if;
                        -------------------------TAX--------------------------------------------------------------
                    end if; --check balance of tax and faiz

                end if;--main if after loop
            end loop;
            close cur_faiz_pd_after_2013;
        end if; --close faiz and tax condition
        pn_available_amount_after := ln_available_amount;*/
    end;
  FUNCTION payment_def_int_after_2013_pd(pn_available_amount number) RETURN number
  IS
    begin
        return 0;
    end;
  FUNCTION payment_penalty_pd_after_2013(pn_available_amount number) RETURN number
  IS
    begin
        return 0;
    end;
 PROCEDURE pastdue_closing_payment_after (pn_current_account number, ps_account_currency varchar2, pn_musteri_no number, pn_bloke_amount number) IS
--PRAGMA autonomous_transaction;
 ln_current_account number;
 ln_tx_amount number;
 ln_available_amount number;
 ln_remaining_avail_balance number;
 ln_amount number;

 ld_date DATE := to_date('04062013','DDMMYYYY');
 ls_past_due_currency cbs_hesap_kredi.doviz_kodu%type;
 ln_pd_account_no number;
 ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
 ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
 ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
 ln_gecenyil_faiz_tutari number;
 ln_gecmis_aylarin_faizi number;
 ln_birikmis_faiz_tutari number;
 ln_pd_balance number;
 ls_pd_branch_cd cbs_hesap_kredi_islem.sube_kodu%type;
 ls_son_gun_faizi cbs_hesap_kredi_islem.son_gun_faizi%type;
 ln_faiz_tutari number;
 ln_komisyon_tutari number;
 ln_toplam_faiz number;
 ld_value_date CBS_HESAP_KREDI_ISLEM.VALOR_TARIHI%TYPE;
 ls_collection_currency CBS_HESAP_KREDI_ISLEM.TAHSIL_HESAP_DOVIZ%TYPE;
 ln_rate number;
 ln_related_account number;
 ln_collection_account number;
 ln_anapara_tahsilat_tutar number;
 ls_choice cbs_hesap_kredi_islem.geriodeme_kapama_secimi%type;
 ls_durum_kodu cbs_hesap_kredi_islem.durum_kodu%type;
 ln_tahsedil_gecenyilfaiztutar cbs_hesap_kredi_islem.tahsedil_gecenyil_faiz_tutari%type;
 ln_tahsedil_gecmis_aylar_faiz cbs_hesap_kredi_islem.tahsedil_gecmis_aylar_faiz%type;
 ln_tahsedil_birikmisfaiztutar cbs_hesap_kredi_islem.tahsedil_birikmis_faiz_tutari%type;
 ls_aciklama cbs_hesap_kredi_islem.aciklama%type;
 ln_musteri_no number;
 ls_account_currency cbs_hesap.doviz_kodu%type;
 ln_pd_tax_balance number;
 ln_pd_interest_balance number;

 ln_tax_last_year number;
 ln_tax_last_month number;
 ln_tax_cumulated number;
 ln_tax_rate number;
 ln_tax_rate_last_year number;
 ln_toplam_tax number;

 ls_cash_account CBS_MASRAF_KOM_TAHSIL_ISL.CASH_ACCOUNT%type;
 ls_currency_code CBS_MASRAF_KOM_TAHSIL_ISL.DVZ%type;
 ln_customer_no CBS_MASRAF_KOM_TAHSIL_ISL.MUSTERI_NO%type;
 ls_residency_code CBS_MASRAF_KOM_TAHSIL_ISL.RESIDENCY_CODE%type;
 ls_citizen_code CBS_MASRAF_KOM_TAHSIL_ISL.CITIZEN_CODE%type;
 ls_customer_type CBS_MASRAF_KOM_TAHSIL_ISL.CUSTOMER_TYPE%type;
 ls_income_type CBS_MASRAF_KOM_TAHSIL_ISL.GELIR_ACIKLAMA%type;
 ln_related_account_penalty CBS_MASRAF_KOM_TAHSIL_ISL.ILISKILI_HESAP_NO%type;
 ln_amount_penalty CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_TUTARI%type;
 ls_vat CBS_MASRAF_KOM_TAHSIL_ISL.VAT%type;
 ls_service_tax CBS_MASRAF_KOM_TAHSIL_ISL.SERVICE_TAX%type;
 ln_service_tax_rate CBS_MASRAF_KOM_TAHSIL_ISL.SERVICE_TAX_RATE%type;
 ls_tax_coll_type CBS_MASRAF_KOM_TAHSIL_ISL.TAX_COLL_TYPE%type;
 ln_paid_tax_amount CBS_MASRAF_KOM_TAHSIL_ISL.PAID_TAX_AMOUNT%type;
 ln_total_collection_amount CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_TOPLAM_TUTAR%type;
 ls_collection_currency_penalty CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_DVZ_KOD%type;
 ln_rate_penalty CBS_MASRAF_KOM_TAHSIL_ISL.KUR%type;
 ln_collection_account_penalty CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_HESAP_NO%type;
 ls_income_gl CBS_MASRAF_KOM_TAHSIL_ISL.INCOME_GL%type;
 ls_explanation CBS_MASRAF_KOM_TAHSIL_ISL.ACIKLAMA%type;
 ls_name_surname CBS_MUSTERI.ARAMA_ISIM%type;                   --TemirlanT
 ls_day  cbs_hesap_kredi_islem.aciklama%type;                   --TemirlanT
 ln_loan_account CBS_HESAP_KREDI.HESAP_NO%type;                 --TemirlanT
 ls_dk_explanation CBS_DKHESAP.ACIKLAMA%type;                   --TemirlanT
 ls_sector_explanation CBS_DKHESAP.ACIKLAMA%type;               --TemirlanT
 ls_month_explanation varchar2(20);                             --TemirlanT
 ln_count_related_account_pd number;                            --TemirlanT
 ln_general_balance number := 0;                                --TemirlanT
 ln_general_balance_1 number;                                   --TemirlanT
 ln_general_balance_2 number;                                   --TemirlanT
 ls_part varchar2(10);                                          --TemirlanT
 ln_count_a boolean := false;                                   --TemirlanT
 ln_count_b boolean := false;                                   --TemirlanT
 ln_overdraft_mi CBS_HESAP.OVERDRAFT%type;                      --TemirlanT
 ln_toplam_faiz_tim number;                                     --TemirlanT
 ln_available_amount_after number;                              --TemirlanT
 ln_job_no number;                                              --TemirlanT
 ln_delayed_days number;
 ls_account_branch cbs_hesap.sube_kodu%type;
 ln_alis_tutari number;
 ln_current_account_2 cbs_hesap.hesap_no%type;

 ln_alter_current_account CBS_HESAP.HESAP_NO%type;

 ln_related_account_pen_curr number;
 lb_buy_loan_currency boolean := false;
 ln_faizler number;
 ln_arbitraj_account_amount number;
 lb_bought_amount boolean;
 ln_converted_acc_amount number;
 ln_acc_amount_before number;

 ln_loan_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 ln_gon_block_count number;
 ln_non_gon_block number;
 ln_any_block number;
 ln_related_account_pd CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 ----rahat
 lb_block boolean;
 ln_bloke_tutari_sum number;
 ln_bakiye CBS_HESAP_BAKIYE.bakiye%TYPE;
 ln_block_sum number;
 ln_difference_amount number;
 -------------------------------------------------------------

 /*CURSOR c_credited_cust IS
 SELECT s.hesap_numara,  -- list of accounts with balance inflow
        s.hesap_bolum_kodu,
        s.dv_tutar,
        h.urun_tur_kod,
        h.urun_sinif_kod,
        h.modul_tur_kod,
        h.doviz_kodu,
        h.sube_kodu,
        h.musteri_no,
        trunc(pkg_hesap.kullanilabilir_bakiye_al(h.hesap_no),2) available_balance,
        pkg_kur.doviz_doviz_karsilik(h.doviz_kodu,pkg_genel.lc_al,null,trunc(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),2),1,null,null,'O','A', h.sube_kodu ) buying_amount,
        pkg_kur.doviz_doviz_karsilik(h.doviz_kodu,pkg_genel.lc_al,null,trunc(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),2),1,null,null,'O','S',  h.sube_kodu) selling_amount
 FROM cbs_satir s, cbs_hesap h
 WHERE s.fis_islem_numara = 1
            and s.hesap_tur_kodu = 'VS'
            and s.tur = 'A'
            and s.hesap_numara = to_char(h.hesap_no)
            and pkg_musteri.Report_Customer_Type(h.musteri_no) in (1, 2) --retail, sme
            --and S.DOVIZ_KOD in ('KGS','USD')
            --and trunc(pkg_hesap.kullanilabilir_bakiye_al(h.hesap_no),2) > 0
            and (pkg_muhasebe.banka_tarihi_bul - (select min(k.acilis_tarihi) from   cbs_hesap_kredi k
                where K.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)
                and K.durum_kodu='A'
                and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                and k.urun_sinif_kod not in ('CRD.CARD-LC')
                and K.pastdue_faiz_anapara_sec is not null)) < 90
            and ((select count(*) from   cbs_hesap_kredi k
                where K.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)
                and K.durum_kodu='A'
                and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                and k.urun_sinif_kod not in ('CRD.CARD-LC')
                and K.pastdue_faiz_anapara_sec is not null) > 0
            or (select count(*)
                from cbs_hesap_kredi k
                where  k.penalty_amount > 0
                and k.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)) > 0);
 r_credited_cust  c_credited_cust%ROWTYPE;*/
 --BOM TemirlanT
 CURSOR c_credited_count IS
 select hesap_no,iliskili_hesap_no, doviz_kodu
                into ln_loan_account,ln_related_account, ls_past_due_currency
                from cbs_hesap_kredi k1
                where k1.ana_kredi_hesap_no is null
                and k1.musteri_no = ln_musteri_no
                --and k1.durum_kodu='A'
                and k1.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                and pkg_hesap.HesaptanDurumAl(k1.iliskili_hesap_no) = 'A'
                and (select count(*) from cbs_hesap_kredi where ana_kredi_hesap_no=k1.hesap_no and durum_kodu='A')>0;
 r_credited_count  c_credited_count%ROWTYPE;
 --EOM TemirlanT
 CURSOR cur_anapara_pd_before_2013 IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance ,
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no
        and abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) < ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;
 r_anapara_pd_before_2013  cur_anapara_pd_before_2013%ROWTYPE;

 CURSOR cur_faiz_pd_before_2013 IS
        select * from (
            --only faiz
            select K.MUSTERI_NO,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount ,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount,
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')
            and KK.HESAP_NO is null
            union all
            --only tax
            select k.musteri_no, K.ACILIS_TARIHI, kk.doviz_kodu, kk.hesap_no, kk.modul_tur_kod, Kk.URUN_TUR_KOD, Kk.URUN_SINIF_KOD, kk.GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu, Kk.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_faiz_amount ,
            k.doviz_kodu tax_doviz_kodu, k.hesap_no tax_hesap_no, k.modul_tur_kod tax_modul_tur_kod, k.URUN_TUR_KOD tax_URUN_TUR_KOD, k.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    k.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, k.sube_kodu tax_sube_kodu, k.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_tax_amount ,
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')
            and KK.HESAP_NO is null
            union all
            --both faiz and tax
            select k.musteri_no,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount ,
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC') ) k
            where k.musteri_no=ln_musteri_no
            and k.ana_hesap_acilis < ld_date
            --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
            and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
            order by K.ACILIS_TARIHI, k.ana_hesap_acilis;

 r_faiz_pd_before_2013  cur_faiz_pd_before_2013%ROWTYPE;

 CURSOR cur_def_int_before_2013_pd IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance ,
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no
        and (abs(nvl(K.GECENYIL_FAIZ_TUTARI,0)) >0 or abs(nvl(K.GECMIS_AYLARIN_FAIZI,0)) > 0 or abs(nvl(K.BIRIKMIS_FAIZ_TUTARI,0)) > 0)
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) < ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;
 r_def_int_before_2013_pd  cur_def_int_before_2013_pd%ROWTYPE;

 CURSOR cur_penalty_pd_before_2013 IS
        select k.*,
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from cbs_hesap_kredi k
        where K.MUSTERI_NO = ln_musteri_no
        and K.PENALTY_AMOUNT > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) < ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;
 r_penalty_pd_before_2013  cur_penalty_pd_before_2013%ROWTYPE;


 CURSOR cur_anapara_pd_after_2013 IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance ,
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no
        and abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) >= ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;
 r_anapara_pd_after_2013  cur_anapara_pd_after_2013%ROWTYPE;

 CURSOR cur_faiz_pd_after_2013 IS
        select * from (
            --only faiz
            select K.MUSTERI_NO,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount ,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')
            and KK.HESAP_NO is null
            union all
            --only tax
            select k.musteri_no, K.ACILIS_TARIHI, kk.doviz_kodu, kk.hesap_no, kk.modul_tur_kod, Kk.URUN_TUR_KOD, Kk.URUN_SINIF_KOD, kk.GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu, Kk.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_faiz_amount ,
            k.doviz_kodu tax_doviz_kodu, k.hesap_no tax_hesap_no, k.modul_tur_kod tax_modul_tur_kod, k.URUN_TUR_KOD tax_URUN_TUR_KOD, k.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    k.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, k.sube_kodu tax_sube_kodu, k.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')
            and KK.HESAP_NO is null
            union all
            --both faiz and tax
            select k.musteri_no,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD,
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k
            join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC') ) k
            where k.musteri_no=ln_musteri_no
            and k.ana_hesap_acilis >= ld_date
            --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
            and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
            order by K.ACILIS_TARIHI, k.ana_hesap_acilis;

 r_faiz_pd_after_2013  cur_faiz_pd_after_2013%ROWTYPE;

 CURSOR cur_def_int_after_2013_pd IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance ,
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no
        and (abs(nvl(K.GECENYIL_FAIZ_TUTARI,0)) >0 or abs(nvl(K.GECMIS_AYLARIN_FAIZI,0)) > 0 or abs(nvl(K.BIRIKMIS_FAIZ_TUTARI,0)) > 0)
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) >= ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;
 r_def_int_after_2013_pd  cur_def_int_after_2013_pd%ROWTYPE;

 CURSOR cur_penalty_pd_after_2013 IS
        select k.*,
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis,
        (select K1.MUSTERI_DK_NO from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_dk_no
        from cbs_hesap_kredi k
        where K.MUSTERI_NO = ln_musteri_no
        and K.PENALTY_AMOUNT > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) >= ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;
 r_penalty_pd_after_2013  cur_penalty_pd_after_2013%ROWTYPE;

 cursor c_block is
    select b.* from cbs_bloke b
    where b.bloke_neden_kodu in ('7','10') and b.durum_kodu = 'A' and B.BLOKE_TUTARI > 0
    and hesap_no = ln_current_account;

 r_block c_block%ROWTYPE;

 cursor rel_acc_block is
    select b.* from cbs_bloke b
    where b.bloke_neden_kodu in ('7','10') and b.durum_kodu = 'A' and B.BLOKE_TUTARI > 0
    and hesap_no = ln_related_account;

    r_acc_block rel_acc_block%ROWTYPE;

 cursor c_pastdue_block is
    select b.* from cbs_bloke b
    where b.bloke_neden_kodu in ('11') and b.durum_kodu = 'A' and B.BLOKE_TUTARI > 0
    and hesap_no = ln_current_account;

    r_pastdue_block c_pastdue_block%ROWTYPE;


BEGIN
    log_at('timka_eod', 1,1);
    pkg_parametre.deger('BAT_1_NEW_LOGIC_PAST_DUE',ld_date);
    pkg_parametre.deger('G_PD_PART_EXPLANATION',ls_part);  -- cbs-119 TemirlanT

    --OPEN c_credited_cust;
 --LOOP
    --FETCH c_credited_cust INTO r_credited_cust;
    --EXIT WHEN c_credited_cust%NOTFOUND;

    ln_current_account := pn_current_account;
    ls_account_currency := ps_account_currency;
    ls_account_branch := PKG_HESAP.HESAPSUBEAL(ln_current_account);
    ln_musteri_no := pn_musteri_no;
    ln_tx_amount := pn_bloke_amount;
    ls_name_surname := pkg_musteri.sf_musteri_adi(ln_musteri_no);

    --dbms_lock.SLEEP(200);
    log_at('timka_eod', 1,2);
    OPEN c_pastdue_block;
    LOOP
        FETCH c_pastdue_block INTO r_pastdue_block;
        EXIT WHEN c_pastdue_block%NOTFOUND;
        Begin
            Pkg_Bloke.sp_bloke_yarat(r_pastdue_block.bloke_referans,
                                     r_pastdue_block.musteri_no,
                                     r_pastdue_block.hesap_no,
                                     r_pastdue_block.doviz_kodu,
                                     pn_BLOKE_TUTARI=>0,
                                     ps_BLOKE_NEDEN_KODU=>'11',
                                     ps_ACIKLAMA=>'Releasing Past Due Block for past due closing',
                                     pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                     pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                     p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                     p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                     p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                     PS_KAPAMA   => 'KAPAMA');

            COMMIT;
        Exception
            When others Then
            log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_current_account: ' || ln_current_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        end;
    END LOOP;
    CLOSE c_pastdue_block;
    log_at('timka_eod', 1,3);
    --select overdraft into ln_overdraft_mi from cbs_hesap where hesap_no=ln_current_account;
    --if ln_overdraft_mi='H' then
        begin
            begin
                select count(*)
                into ln_non_gon_block
                from cbs_bloke b
                where b.bloke_neden_kodu not in('7','10')
                and b.durum_kodu = 'A'
                and B.BLOKE_TUTARI > 0
                and hesap_no = ln_current_account;
            exception when no_data_found then
                ln_non_gon_block := 0;
            end;

            begin
                select count(*)
                into ln_gon_block_count
                from cbs_bloke b
                where b.bloke_neden_kodu in('7','10')
                and b.durum_kodu = 'A'
                and B.BLOKE_TUTARI > 0
                and hesap_no = ln_current_account;
            exception when no_data_found then
                ln_gon_block_count := 0;
            end;

            if ln_non_gon_block > 0 then

                ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2);
                begin
                    select nvl(sum(bloke_tutari), 0)
                    into ln_block_sum
                    from cbs_bloke b
                    where b.bloke_neden_kodu not in ('10', '7')
                    and b.durum_kodu = 'A'
                    and B.BLOKE_TUTARI > 0
                    and hesap_no = ln_current_account;
                exception when no_data_found then
                    ln_block_sum := 0;
                end;
                if ln_bakiye > ln_block_sum then
                    if ln_gon_block_count > 0 then
                        OPEN c_block;
                        LOOP
                            FETCH c_block INTO r_block;
                            EXIT WHEN c_block%NOTFOUND;
                            begin
                                if r_block.bloke_neden_kodu = '7' then
                                    Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                          r_block.musteri_no,
                                                          r_block.hesap_no,
                                                          r_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'7',
                                                          ps_ACIKLAMA=>'Releasing GON file Blocking for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');

                                elsif r_block.bloke_neden_kodu = '10' then

                                    Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                          r_block.musteri_no,
                                                          r_block.hesap_no,
                                                          r_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'10',
                                                          ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');
                                end if;

                                commit;
                            exception
                                when others then
                                log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_current_account: ' || ln_current_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                            end;
                        END LOOP;
                        CLOSE c_block;
                    end if;
                end if;
                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2) - ln_block_sum; --TemirlanT

            elsif ln_gon_block_count > 0 then
                OPEN c_block;
                LOOP
                    FETCH c_block INTO r_block;
                    EXIT WHEN c_block%NOTFOUND;
                    begin
                        if r_block.bloke_neden_kodu = '7' then
                            Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                      r_block.musteri_no,
                                                      r_block.hesap_no,
                                                      r_block.doviz_kodu,
                                                      pn_BLOKE_TUTARI=>0,
                                                      ps_BLOKE_NEDEN_KODU=>'7',
                                                      ps_ACIKLAMA=>'Releasing GON file Blocking for past due closing',
                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                      PS_KAPAMA   => 'KAPAMA');
                        elsif r_block.bloke_neden_kodu = '10' then
                            Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                      r_block.musteri_no,
                                                      r_block.hesap_no,
                                                      r_block.doviz_kodu,
                                                      pn_BLOKE_TUTARI=>0,
                                                      ps_BLOKE_NEDEN_KODU=>'10',
                                                      ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                      PS_KAPAMA   => 'KAPAMA');
                        end if;

                        commit;
                    exception
                        when others then
                        log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_current_account: ' || ln_current_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                    end;
                END LOOP;
                CLOSE c_block;
                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2);
            else
                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2);

            end if;

        end;


        log_at('cbs-timka_pd',1,1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
        --BOM TemirlanT timka
        begin
            log_at('cbs-timka_pd',1,2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
            if ln_available_amount>0 then
                OPEN c_credited_count;
                LOOP
                    FETCH c_credited_count INTO r_credited_count;
                    EXIT WHEN c_credited_count%NOTFOUND;
                    --c_credited_count
                    --WHILE ln_count_a < ln_count_related_account_pd LOOP
                    log_at('timka_eod', 1,4);
                    ln_loan_account := r_credited_count.hesap_no;
                    ln_related_account := r_credited_count.iliskili_hesap_no;
                    ls_past_due_currency := r_credited_count.doviz_kodu;
                    if ln_current_account <> ln_related_account then
                        ln_count_a := true;
                    end if;
                    select sum(abs(pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)))
                    into ln_general_balance_1
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90;
                    log_at('cbs-timka_pd',1,5,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    select sum(nvl(abs(GECENYIL_FAIZ_TUTARI), 0)), sum(nvl(abs(GECMIS_AYLARIN_FAIZI), 0)), sum(nvl(abs(BIRIKMIS_FAIZ_TUTARI), 0))
                    into ln_gecenyil_faiz_tutari, ln_gecmis_aylarin_faizi, ln_birikmis_faiz_tutari
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90
                    and pastdue_faiz_anapara_sec = 'ANAPARA';
                    log_at('cbs-timka_pd',1,6,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    select sum(nvl(abs(penalty_amount), 0))
                    into ln_amount_penalty
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90
                    and pastdue_faiz_anapara_sec = 'FAIZ';
                    log_at('cbs-timka_pd',1,7,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_tax_rate);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_tax_rate_last_year);
                    Pkg_Parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);
                    log_at('cbs-timka_pd',1,8,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    ln_toplam_tax := round((((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))))*ln_tax_rate_last_year+
                                         (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))))*ln_tax_rate)/100),2)
                                + round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);

                    ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);

                    ln_general_balance_2 := round((ln_general_balance_1 + ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari + ln_toplam_tax),2);

                    ln_general_balance_1 := round((ln_general_balance_1 + ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari + ln_toplam_tax + ln_amount_penalty + ln_paid_tax_amount),2);
                    log_at('cbs-timka_pd',1,9,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);

                    ln_general_balance := ln_general_balance + ln_general_balance_1;
                    log_at('cbs-timka_pd',1,10,'ln_general_balance='||ln_general_balance||' ln_general_balance_1='||ln_general_balance_1);
                    --ln_count_a := ln_count_a + 1;
                    ln_general_balance_1 := 0;

                    if ln_current_account = ln_related_account then
                        lb_block := false;
                    else
                        begin
                            select nvl(sum(bloke_tutari), 0)
                            into ln_block_sum
                            from cbs_bloke b
                            where b.bloke_neden_kodu not in ('7', '10')
                            and b.durum_kodu = 'A'
                            and B.BLOKE_TUTARI > 0
                            and hesap_no = ln_related_account;
                        exception when no_data_found then
                            ln_block_sum := 0;
                        end;

                        ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);

                        ln_general_balance := ln_general_balance + ln_block_sum - ln_bakiye;
                        ln_general_balance_2 := ln_general_balance_2 + ln_block_sum - ln_bakiye;
                    end if;

                    if trunc(ln_available_amount,2) > 0 then
                        if ls_account_currency <> ls_past_due_currency then
                            if ls_past_due_currency = PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-LC
                                ln_available_amount := pkg_kur.doviz_doviz_karsilik(ls_account_currency,pkg_genel.lc_al,null,ln_available_amount,1,null,null,'O','A', ls_account_branch );
                                log_at('cbs-timka_pd',1,3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency = PKG_GENEL.LC_AL then -- LC-FC
                                ln_available_amount := pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,ls_past_due_currency,null,ln_available_amount,1,null,null,'O','S', ls_account_branch );
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-FC
                                ln_available_amount := pkg_kredi.arbitraj_kur(ls_account_currency, ls_past_due_currency, ln_available_amount, ls_account_branch, false, true);
                            end if;
                        end if;

                        if ln_available_amount > ln_general_balance then    --TemirlanT cbs-119
                            ln_available_amount := ln_general_balance;
                        end if;

                        if ln_available_amount >= ln_general_balance_2 then    --TemirlanT cbs-119
                            log_at('cbs-timka_pd',1,3,1||' ln_available_amount='||ln_available_amount||' ln_general_balance_2='||ln_general_balance_2);
                            ln_count_b := true;
                        end if;

                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);

                        ln_alter_current_account := ln_related_account;
                        if ln_current_account != ln_related_account then
                            if ls_account_currency <> ls_past_due_currency then
                                PKG_KREDI_AUTOMATION.sp_convert_for_pd_closing_arb(ln_loan_account, ln_current_account, ln_anapara_tahsilat_tutar, ln_alter_current_account,ln_converted_acc_amount);
                                ls_account_currency := ls_past_due_currency;        --TemirlanT
                                ln_current_account := ln_related_account;        --TemirlanT
                                log_at('cbs-timka_pd',1,6,'ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar||' ln_general_balance='||ln_general_balance);
                            else
                                PKG_KREDI_AUTOMATION.sp_transfer_for_pd_closing(ln_loan_account, ln_current_account, ln_anapara_tahsilat_tutar, ln_alter_current_account, ln_converted_acc_amount); --TemirlanT cbs-119
                                ls_account_currency := ls_past_due_currency;        --TemirlanT
                                ln_current_account := ln_related_account;        --TemirlanT
                            end if;
                        end if;
                        ln_current_account_2 := ln_alter_current_account;      --TemirlanT
                    end if;

                    if ln_count_a = true then
                        log_at('cbs-timka_pd','block',1,'ln_current_account='||ln_current_account||' ln_related_account='||ln_related_account);
                        begin
                            select count(*)
                            into ln_non_gon_block
                            from cbs_bloke b
                            where b.bloke_neden_kodu not in ('7','10')
                            and b.durum_kodu = 'A'
                            and B.BLOKE_TUTARI > 0
                            and hesap_no = ln_related_account;
                        exception when no_data_found then
                            ln_non_gon_block := 0;
                        end;

                        begin
                            select count(*)
                            into ln_gon_block_count
                            from cbs_bloke b
                            where b.bloke_neden_kodu in ('7','10')
                            and b.durum_kodu = 'A'
                            and B.BLOKE_TUTARI > 0
                            and hesap_no = ln_related_account;
                        exception when no_data_found then
                            ln_gon_block_count := 0;
                        end;
                        log_at('cbs-timka_pd','block',2,'ln_non_gon_block='||ln_non_gon_block||' ln_gon_block_count='||ln_gon_block_count);
                        if  ln_non_gon_block > 0 then

                            ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
                            begin
                                select sum(bloke_tutari)
                                into ln_block_sum
                                from cbs_bloke b
                                where b.bloke_neden_kodu not in ('7', '10')
                                and b.durum_kodu = 'A'
                                and B.BLOKE_TUTARI > 0
                                and hesap_no = ln_related_account;
                            exception when no_data_found then
                                ln_block_sum := 0;
                            end;
                            if ln_bakiye > ln_block_sum then
                                log_at('cbs-timka_pd','block',3,'ln_bakiye='||ln_bakiye||' ln_block_sum='||ln_block_sum);
                                if ln_gon_block_count > 0 then
                                    log_at('cbs-timka_pd','block',4,'ln_non_gon_block='||ln_non_gon_block||' ln_gon_block_count='||ln_gon_block_count);
                                    OPEN rel_acc_block;
                                    LOOP
                                        FETCH rel_acc_block INTO r_acc_block;
                                        EXIT WHEN rel_acc_block%NOTFOUND;
                                        begin
                                            if r_acc_block.bloke_neden_kodu = '7' then
                                                log_at('cbs-timka_pd','block',5,'ln_non_gon_block='||ln_non_gon_block||' ln_gon_block_count='||ln_gon_block_count);
                                                Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                                      r_acc_block.musteri_no,
                                                                      r_acc_block.hesap_no,
                                                                      r_acc_block.doviz_kodu,
                                                                      pn_BLOKE_TUTARI=>0,
                                                                      ps_BLOKE_NEDEN_KODU=>'7',
                                                                      ps_ACIKLAMA=>'Releasing Blocking for past due closing',
                                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                                      PS_KAPAMA   => 'KAPAMA');

                                            elsif r_acc_block.bloke_neden_kodu = '10' then
                                                Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                                      r_acc_block.musteri_no,
                                                                      r_acc_block.hesap_no,
                                                                      r_acc_block.doviz_kodu,
                                                                      pn_BLOKE_TUTARI=>0,
                                                                      ps_BLOKE_NEDEN_KODU=>'10',
                                                                      ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                                      PS_KAPAMA   => 'KAPAMA');
                                            end if;
                                            commit;
                                        exception
                                            when others then
                                        log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_related_account: ' || ln_related_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                                        end;
                                    END LOOP;
                                    CLOSE rel_acc_block;
                                    ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2) - ln_block_sum;
                                    lb_block := false;
                                    log_at('cbs-timka_pd','block',6,'ln_available_amount='||ln_available_amount||' lb_block='||'false');
                                else
                                    ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2) - ln_block_sum;
                                    lb_block := false;
                                    log_at('cbs-timka_pd','block',7,'ln_available_amount='||ln_available_amount||' lb_block='||'false');
                                end if;
                            else
                                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2) - ln_block_sum;
                                lb_block := true;
                                log_at('cbs-timka_pd','block',8,'ln_available_amount='||ln_available_amount||' lb_block='||'true');
                            end if;

                        elsif ln_gon_block_count > 0  then

                            OPEN rel_acc_block;
                            LOOP
                                FETCH rel_acc_block INTO r_acc_block;
                                EXIT WHEN rel_acc_block%NOTFOUND;

                                --if (rel_acc_block%FOUND) then
                                begin
                                    if r_acc_block.bloke_neden_kodu = '7' then
                                        Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                          r_acc_block.musteri_no,
                                                          r_acc_block.hesap_no,
                                                          r_acc_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'7',
                                                          ps_ACIKLAMA=>'Releasing GON file Blocking for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');
                                    elsif r_acc_block.bloke_neden_kodu = '10' then
                                        Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                          r_acc_block.musteri_no,
                                                          r_acc_block.hesap_no,
                                                          r_acc_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'10',
                                                          ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');

                                    end if;
                                    commit;
                                exception
                                    when others then
                                    log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_current_account: ' || ln_current_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                                end;
                            END LOOP;
                            CLOSE rel_acc_block;
                            ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
                            lb_block := false;
                        else
                            ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
                            lb_block := false;
                        end if;
                    end if;

                    if ln_current_account = ln_related_account then
                        lb_block := false;
                    end if;
                END LOOP;
                CLOSE c_credited_count;

                log_at('cbs-timka_pd',1,11,'ln_general_balance='||ln_general_balance||' ln_general_balance_1='||ln_general_balance_1);
            end if;
        exception when others then
            log_at('cbs-timka_pd',1,10,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
        --ln_related_account := null;
        end;

        /*if ln_available_amount > ln_general_balance then    --TemirlanT cbs-119
            ln_available_amount := ln_general_balance;
        end if;*/
        --EOM TemirlanT
    -----------------------before-----------------------------------------

        if trunc(ln_available_amount,2) > 0 then
            open cur_penalty_pd_before_2013;
            loop
            fetch cur_penalty_pd_before_2013 into r_penalty_pd_before_2013;
            exit when cur_penalty_pd_before_2013%notfound;
                ls_past_due_currency := r_penalty_pd_before_2013.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;



                if trunc(ln_available_amount,2) > 0 then

                    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);

                    ln_related_account_penalty := r_penalty_pd_before_2013.hesap_no;
                    ln_amount_penalty := r_penalty_pd_before_2013.penalty_amount;
                    ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);

                    if round(ln_available_amount,2) < nvl(r_penalty_pd_before_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                    elsif round(ln_available_amount,2) = nvl(r_penalty_pd_before_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                    elsif round(ln_available_amount,2) > nvl(r_penalty_pd_before_2013.penalty_amount,0) then
                        if round(ln_available_amount,2) >= nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := r_penalty_pd_before_2013.penalty_amount;
                            ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);
                        elsif round(ln_available_amount,2) < nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                            ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                        end if;
                    end if;

                    ln_total_collection_amount := nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0);

                    lb_bought_amount := false;

                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_related_account_penalty
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;

                    -----------------------------------------------------------
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;


                    if lb_block = false then

                        ls_cash_account := 'ACCOUNT';
                        ls_currency_code := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account_pd);
                        ln_customer_no := ln_musteri_no;
                        ls_residency_code := pkg_musteri.sf_get_residency_code (ln_customer_no);
                        ls_citizen_code := pkg_musteri.sf_get_citizenship_country(ln_customer_no);
                        ls_customer_type := pkg_musteri.sf_musteri_tipi_al(ln_customer_no);
                        ls_income_type := 'LOANCOMM';

                        ls_vat := 'N';
                        ls_service_tax := 'Y';
                        ls_tax_coll_type := 'PS';--PAID SEPERATELY
                        ln_rate_penalty := pkg_kur.doviz_doviz_karsilik(ls_currency_code,pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        ln_collection_account_penalty := ln_related_account_pd;
                        ls_collection_currency_penalty := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_collection_account_penalty);
                        pkg_parametre.deger('G_PD_PENALTY',ls_income_gl);
                        ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_penalty_pd_before_2013.acilis_tarihi;
                        ls_explanation := 'Penalty for ' || ln_delayed_days || ' days delay of int+sales tax of ' || PKG_MUSTERI.SF_MUSTERI_ADI(ln_customer_no);

                        ls_modul_tur_kod := 'CURR.OPS.';
                        ls_urun_tur_kod := 'CHARGE';
                        ls_urun_sinif_kod := 'GENERAL';
                        ls_pd_branch_cd := r_penalty_pd_before_2013.sube_kodu;
                        PKG_KREDI_AUTOMATION.sp_penalty_Pastdue_Closing(
                                                            ls_cash_account ,
                                                            ls_currency_code ,
                                                            ln_customer_no ,
                                                            ls_residency_code,
                                                            ls_citizen_code,
                                                            ls_customer_type,
                                                            ls_income_type,
                                                            ln_related_account_penalty,
                                                            ln_amount_penalty,
                                                            ls_vat,
                                                            ls_service_tax,
                                                            ln_service_tax_rate,
                                                            ls_tax_coll_type,
                                                            ln_paid_tax_amount,
                                                            ln_total_collection_amount,
                                                            ls_collection_currency_penalty,
                                                            ln_rate_penalty,
                                                            ln_collection_account_penalty,
                                                            ls_income_gl,
                                                            ls_explanation,
                                                            ls_pd_branch_cd,
                                                            ls_modul_tur_kod,
                                                            ls_urun_tur_kod,
                                                            ls_urun_sinif_kod,
                                                            ln_current_account
                                                            );

                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_total_collection_amount,0);
                    end if;

                end if;

            end loop;
            close cur_penalty_pd_before_2013;
        end if;

        if trunc(ln_available_amount,2) > 0 then
            OPEN cur_def_int_before_2013_pd;
            loop
                fetch cur_def_int_before_2013_pd into r_def_int_before_2013_pd;
                exit when cur_def_int_before_2013_pd%notfound;
                ls_past_due_currency := r_def_int_before_2013_pd.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;

                if trunc(ln_available_amount,2) > 0 then

                    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_tax_rate);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_tax_rate_last_year);
                    ln_pd_account_no := r_def_int_before_2013_pd.hesap_no;
                    ln_gecenyil_faiz_tutari := abs(nvl(r_def_int_before_2013_pd.GECENYIL_FAIZ_TUTARI,0));
                    ln_gecmis_aylarin_faizi := abs(nvl(r_def_int_before_2013_pd.GECMIS_AYLARIN_FAIZI,0));
                    ln_birikmis_faiz_tutari := abs(nvl(r_def_int_before_2013_pd.BIRIKMIS_FAIZ_TUTARI,0));
                    ln_tahsedil_gecenyilfaiztutar := 0;
                    ln_tahsedil_gecmis_aylar_faiz := 0;
                    ln_tahsedil_birikmisfaiztutar := 0;
                    ln_tax_last_year := 0;
                    ln_tax_last_month := 0;
                    ln_tax_cumulated := 0;

                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;

                    ln_toplam_tax := round((((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))))*ln_tax_rate_last_year+
                                         (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))))*ln_tax_rate )/100 ),2)+
                                         round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);

                    if round(nvl(ln_available_amount,0),2) > 0 then
                        if ln_available_amount >= nvl(ln_toplam_faiz,0) + nvl(ln_toplam_tax,0) then
                            ls_choice := 'KAPAMA';
                            ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                            ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                            ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                            ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                            ln_available_amount := nvl(ln_available_amount,0) - (abs(ln_toplam_faiz) + ln_toplam_tax);
                        else
                            ls_choice := 'GERI ODEME';
                            if round(nvl(ln_available_amount,0),2) > 0 then
                                if round(nvl(ln_gecenyil_faiz_tutari,0),2) > 0 then
                                    if ln_available_amount >= ln_gecenyil_faiz_tutari + (round((((nvl(ln_gecenyil_faiz_tutari,0))*ln_tax_rate_last_year )/100),2)) then
                                        ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecenyilfaiztutar,0) + ln_tax_last_year);
                                    else
                                        ln_tahsedil_gecenyilfaiztutar := round(ln_available_amount / (1 + ln_tax_rate_last_year / 100),2);
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecenyilfaiztutar,0)))*ln_tax_rate_last_year )/100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecenyilfaiztutar + ln_tax_last_year);
                                    end if;
                                end if;
                            end if;

                            if trunc(nvl(ln_available_amount,0),2) > 0 then
                                if round(nvl(ln_gecmis_aylarin_faizi,0),2) > 0 then
                                    if ln_available_amount >= ln_gecmis_aylarin_faizi + (round((((nvl(ln_gecmis_aylarin_faizi,0))*ln_tax_rate )/100),2)) then
                                        ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecmis_aylar_faiz,0) + ln_tax_last_month);
                                    else
                                        ln_tahsedil_gecmis_aylar_faiz := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecmis_aylar_faiz,0))) * ln_tax_rate ) / 100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecmis_aylar_faiz + ln_tax_last_month);
                                    end if;
                                end if;

                                if trunc(nvl(ln_available_amount,0),2) > 0 then
                                    if round(nvl(ln_birikmis_faiz_tutari,0),2) > 0 then
                                        if ln_available_amount >= ln_birikmis_faiz_tutari + (round(((nvl(ln_birikmis_faiz_tutari,0)*ln_tax_rate)/100),2)) then
                                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                                            ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_birikmisfaiztutar,0) + ln_tax_cumulated);
                                        else
                                            ln_tahsedil_birikmisfaiztutar := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_birikmisfaiztutar,0))) * ln_tax_rate ) / 100),2);
                                            ln_available_amount := ln_available_amount - (ln_tahsedil_birikmisfaiztutar + ln_tax_cumulated);
                                        end if;
                                    end if;
                                end if;

                            end if;
                        end if;

                    end if;

                    ln_faizler := ln_tahsedil_gecenyilfaiztutar + ln_tahsedil_gecmis_aylar_faiz + ln_tahsedil_birikmisfaiztutar + ln_tax_last_year + ln_tax_last_month + ln_tax_cumulated;

                    lb_bought_amount := false;

                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;

                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;


                    if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                        ls_modul_tur_kod := r_def_int_before_2013_pd.modul_tur_kod;
                        ls_urun_tur_kod := r_def_int_before_2013_pd.urun_tur_kod;
                        ls_urun_sinif_kod := r_def_int_before_2013_pd.urun_sinif_kod;
                        ln_pd_balance := r_def_int_before_2013_pd.pd_balance;
                        ls_pd_branch_cd := r_def_int_before_2013_pd.sube_kodu;
                        ls_son_gun_faizi := r_def_int_before_2013_pd.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if;

                        ld_value_date := null;
                        ls_collection_currency := ls_account_currency;

                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;

                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                        if ln_pd_balance <> 0 then
                            ls_choice := 'GERI ODEME';
                        end if;

                        ln_anapara_tahsilat_tutar := 0;

                        if ls_choice = 'KAPAMA' then
                            ls_durum_kodu := 'K';
                        else
                            ls_durum_kodu := 'A';
                        end if;

                        ls_aciklama := 'Close PDPA, c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                        PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod,
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );
                    end if;

                end if;

            end loop;
        close cur_def_int_before_2013_pd;
        end if;

        if trunc(ln_available_amount,2) > 0 then
            open cur_faiz_pd_before_2013;
            loop
                fetch cur_faiz_pd_before_2013 into r_faiz_pd_before_2013;
                exit when cur_faiz_pd_before_2013%notfound;
                if trunc(nvl(ln_available_amount,0),2) > 0 then
                    if nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_before_2013.pd_tax_amount,0) > 0 then
                        ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                        ln_acc_amount_before := ln_available_amount;
                        if nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) + nvl(r_faiz_pd_before_2013.pd_tax_amount,0) <= trunc(ln_available_amount,2) then

                            if trunc(ln_available_amount,2) > 0 then

                            -------------------------FAIZ--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                ln_pd_balance := r_faiz_pd_before_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_before_2013.hesap_no;

                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;

                                lb_bought_amount := false;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;

                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита по faiz и tax

                                    ls_modul_tur_kod := r_faiz_pd_before_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;

                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due interests of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod,
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );

                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);
                                end if;
                                --aisuluud
                                -------------------------FAIZ--------------------------------------------------------------

                                -------------------------TAX----------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                ln_pd_balance := r_faiz_pd_before_2013.pd_tax_amount;--aisuluud
                                ln_pd_account_no := r_faiz_pd_before_2013.tax_hesap_no;

                                if ln_available_amount >= ln_pd_balance then--aisuluud
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                    ls_choice := 'GERI ODEME';
                                end if;

                                lb_bought_amount := false;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;

                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                                    ls_modul_tur_kod := r_faiz_pd_before_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.tax_son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;

                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due tax of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);
                                end if;
                                -------------------------TAX----------------------------------------------------------------
                            end if;
                        else
                            ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            if trunc(ln_available_amount,2) > 0 then
                                ln_pd_tax_balance := round(ln_available_amount,2) * 2 / (100+2);
                                ln_pd_interest_balance := round(ln_available_amount,2) - ln_pd_tax_balance;
                                -------------------------FAIZ--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                                ln_pd_balance := r_faiz_pd_before_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_before_2013.hesap_no;
                                if ln_pd_interest_balance >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_interest_balance);
                                    ls_choice := 'GERI ODEME';
                                end if;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;

                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита
                                    ls_modul_tur_kod := r_faiz_pd_before_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;

                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due interests of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );

                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                                end if;

                                -------------------------FAIZ--------------------------------------------------------------

                                -------------------------TAX--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                ln_pd_balance := r_faiz_pd_before_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_before_2013.tax_hesap_no;

                                if ln_pd_tax_balance >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_tax_balance);
                                    ls_choice := 'GERI ODEME';
                                end if;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;

                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредит
                                    ls_modul_tur_kod := r_faiz_pd_before_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.tax_son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;

                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due tax of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );

                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                                end if;
                                -------------------------TAX--------------------------------------------------------------
                            end if;

                        end if;

                    elsif nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_before_2013.pd_tax_amount,0) = 0 then

                        -------------------------FAIZ--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_before_2013.pd_faiz_amount;
                            ln_pd_account_no := r_faiz_pd_before_2013.hesap_no;

                            if round(ln_available_amount,2) >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                            else
                                ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                ls_choice := 'GERI ODEME';
                            end if;

                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;

                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;

                            if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредитa

                                ls_modul_tur_kod := r_faiz_pd_before_2013.modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_before_2013.urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_before_2013.urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.GECENYIL_FAIZ_TUTARI,0);
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.GECMIS_AYLARIN_FAIZI,0);
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_before_2013.sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_before_2013.son_gun_faizi;

                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;

                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                ls_collection_currency := ls_account_currency;

                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;

                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                if ln_toplam_faiz <> 0 then
                                    ls_choice := 'GERI ODEME';
                                end if;

                                if ls_choice = 'KAPAMA' then
                                    ls_durum_kodu := 'K';
                                else
                                    ls_durum_kodu := 'A';
                                end if;

                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                ls_aciklama := 'Close past due interests of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                                PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                            end if;

                        end if;

                        -------------------------FAIZ--------------------------------------------------------------
                    elsif nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) = 0 and nvl(r_faiz_pd_before_2013.pd_tax_amount,0) > 0 then

                        -------------------------TAX--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_before_2013.tax_doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_before_2013.pd_tax_amount;
                            ln_pd_account_no := r_faiz_pd_before_2013.tax_hesap_no;

                            if round(ln_available_amount,2) >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                            else
                                ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                ls_choice := 'GERI ODEME';
                            end if;

                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;

                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;

                            if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита
                                ls_modul_tur_kod := r_faiz_pd_before_2013.tax_modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_before_2013.tax_urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_before_2013.tax_urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_before_2013.tax_sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_before_2013.tax_son_gun_faizi;

                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;

                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                ls_collection_currency := ls_account_currency;

                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;

                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                if ln_toplam_faiz <> 0 then
                                    ls_choice := 'GERI ODEME';
                                end if;

                                if ls_choice = 'KAPAMA' then
                                    ls_durum_kodu := 'K';
                                else
                                    ls_durum_kodu := 'A';
                                end if;

                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                ls_aciklama := 'Close past due tax of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                                PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod,
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );

                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                            end if;

                        end if;
                        -------------------------TAX--------------------------------------------------------------
                    end if;

                end if;

            end loop;
            close cur_faiz_pd_before_2013;
        end if;


        if trunc(ln_available_amount,2) > 0 then
            open cur_anapara_pd_before_2013;
            loop
                fetch cur_anapara_pd_before_2013 into r_anapara_pd_before_2013;
                exit when cur_anapara_pd_before_2013%notfound;
                if trunc(ln_available_amount,2) > 0 then
                    ls_past_due_currency := r_anapara_pd_before_2013.doviz_kodu;
                    ln_acc_amount_before := ln_available_amount;
                    ln_pd_account_no := r_anapara_pd_before_2013.hesap_no;
                    ln_pd_balance := r_anapara_pd_before_2013.pd_balance;

                    if ln_available_amount >= ln_pd_balance then
                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                        ls_choice := 'KAPAMA';
                    else
                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                        ls_choice := 'GERI ODEME';
                    end if;

                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;

                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;

                    if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита
                        ls_modul_tur_kod := r_anapara_pd_before_2013.modul_tur_kod;
                        ls_urun_tur_kod := r_anapara_pd_before_2013.urun_tur_kod;
                        ls_urun_sinif_kod := r_anapara_pd_before_2013.urun_sinif_kod;
                        ln_gecenyil_faiz_tutari := nvl(r_anapara_pd_before_2013.GECENYIL_FAIZ_TUTARI,0);
                        ln_gecmis_aylarin_faizi := nvl(r_anapara_pd_before_2013.GECMIS_AYLARIN_FAIZI,0);
                        ln_birikmis_faiz_tutari := nvl(r_anapara_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                        ls_pd_branch_cd := r_anapara_pd_before_2013.sube_kodu;
                        ls_son_gun_faizi := r_anapara_pd_before_2013.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if;

                        ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                        ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                        ls_collection_currency := ls_account_currency;

                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;

                        if ln_toplam_faiz <> 0 then
                            ls_choice := 'GERI ODEME';
                        end if;

                        if ls_choice = 'KAPAMA' then
                            ls_durum_kodu := 'K';
                        else
                            ls_durum_kodu := 'A';
                        end if;

                        ln_tahsedil_gecenyilfaiztutar := 0;
                        ln_tahsedil_gecmis_aylar_faiz := 0;
                        ln_tahsedil_birikmisfaiztutar := 0;
                        ls_aciklama := 'Close PDPA, c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;
                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                        PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);
                    end if;

                end if;
            end loop;
            close cur_anapara_pd_before_2013;
        end if;

        ------------------------------------------before-------------------------------------------------
        log_at('cbs-timka_pd','anapara',222,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);

        ------------------------------------------after-------------------------------------------------
        log_at('timka_eod', 1,5);
        if trunc(ln_available_amount,2) > 0 then
            --PKG_KREDI_AUTOMATION.PAYMENT_ANAPARA_PD_AFTER_2013(ln_available_amount, ln_musteri_no, ls_name_surname, ln_available_amount_after);
            --ln_available_amount := ln_available_amount_after;
            open cur_anapara_pd_after_2013;
            loop
                fetch cur_anapara_pd_after_2013 into r_anapara_pd_after_2013;
                exit when cur_anapara_pd_after_2013%notfound;
                if trunc(ln_available_amount,2) > 0 then
                log_at('timka_eod', 1,6);
                    ls_past_due_currency := r_anapara_pd_after_2013.doviz_kodu;
                    ln_acc_amount_before := ln_available_amount;
                    ln_pd_account_no := r_anapara_pd_after_2013.hesap_no;
                    ln_pd_balance := r_anapara_pd_after_2013.pd_balance;
                    ln_loan_related_account := r_anapara_pd_after_2013.iliskili_hesap_no;
                    ln_loan_account := r_anapara_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                    ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_anapara_pd_after_2013.ACILIS_TARIHI); --TemirlanT cbs-119
                    log_at('cbs-timka_pd',1,2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);

                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;

                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;

                    if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                        log_at('cbs-timka_pd','anapara',2);

                        ls_modul_tur_kod := r_anapara_pd_after_2013.modul_tur_kod;
                        ls_urun_tur_kod := r_anapara_pd_after_2013.urun_tur_kod;
                        ls_urun_sinif_kod := r_anapara_pd_after_2013.urun_sinif_kod;
                        ln_gecenyil_faiz_tutari := nvl(r_anapara_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                        ln_gecmis_aylarin_faizi := nvl(r_anapara_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                        ln_birikmis_faiz_tutari := nvl(r_anapara_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                        ls_pd_branch_cd := r_anapara_pd_after_2013.sube_kodu;
                        ls_son_gun_faizi := r_anapara_pd_after_2013.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if;

                        ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                        ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                        ls_collection_currency := ls_account_currency;

                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;

                        if ln_toplam_faiz <> 0 then
                            ls_choice := 'GERI ODEME';
                        end if;

                        if ls_choice = 'KAPAMA' then
                            ls_durum_kodu := 'K';
                        else
                            ls_durum_kodu := 'A';
                        end if;


                        if ln_count_b then
                            log_at('cbs-timka_pd',1,3,2||' ln_available_amount='||ln_available_amount||' ln_general_balance_2='||ln_general_balance_2);
                            ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_anapara_pd_after_2013.acilis_tarihi;
                            --BOM TemirlanT
                            pkg_parametre.deger('G_PD_DAY_EXPLANATION',ls_day);
                            if ln_delayed_days=1 then
                                ls_day := SUBSTR (ls_day, 1, 4);
                            elsif ln_delayed_days in (2,3,4) then
                                ls_day := SUBSTR (ls_day, 6, 3);
                            elsif ln_delayed_days >= 5 and ln_delayed_days <= 21 then
                                ls_day := SUBSTR (ls_day, 10, 4);
                            elsif ln_delayed_days >= 22 and (mod(ln_delayed_days,10)  in (2,3,4)) then
                                ls_day := SUBSTR (ls_day, 6, 3);
                            else
                                ls_day := SUBSTR (ls_day, 10, 4);
                            end if;
                            --EOM TemirlanT
                            pkg_parametre.deger('G_PD_MAIN_ELEVATED_EXPLANATION',ls_aciklama);
                            ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            ls_aciklama := REPLACE (ls_aciklama, '$$$', ln_delayed_days);
                            ls_aciklama := REPLACE (ls_aciklama, '@@@', ls_day);
                            ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                            ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                            ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                            ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                            ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                            if ln_available_amount >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            else
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                ls_choice := 'GERI ODEME';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                            end if;
                            ls_durum_kodu := 'K';
                        else
                            log_at('cbs-timka_pd',1,3,3||' ln_available_amount='||ln_available_amount||' ln_general_balance_2='||ln_general_balance_2);
                            pkg_parametre.deger('G_PD_MAIN_EXPLANATION',ls_aciklama);
                            ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                            ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                            ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                            if ln_available_amount >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            else
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                ls_choice := 'GERI ODEME';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                            end if;
                            ln_tahsedil_gecenyilfaiztutar := 0;
                            ln_tahsedil_gecmis_aylar_faiz := 0;
                            ln_tahsedil_birikmisfaiztutar := 0;

                        end if;
                        ln_toplam_faiz_tim := ln_tahsedil_gecenyilfaiztutar + ln_tahsedil_gecmis_aylar_faiz + ln_tahsedil_birikmisfaiztutar;
                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                        log_at('cbs-timka_pd','anapara',1,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                               ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                               ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                               ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                               ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                               ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                               ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                               ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                               ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                               log_at('timka_eod', 1,7);
                        pkg_kredi_automation.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,--
                                                     ln_tahsedil_gecmis_aylar_faiz,--
                                                     ln_tahsedil_birikmisfaiztutar,--
                                                     ln_anapara_tahsilat_tutar,--
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0) - nvl(ln_toplam_faiz_tim,0);
                    end if;
                    log_at('cbs-timka_pd',1,7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                end if;
            end loop;
            close cur_anapara_pd_after_2013;
        end if;

        -----------------------------------------------------------------------------------FAIZ<->TAX---------------------------------------------------------------------------------------------------------------------
        if trunc(ln_available_amount,2) > 0 then
            open cur_faiz_pd_after_2013;
            loop
                fetch cur_faiz_pd_after_2013 into r_faiz_pd_after_2013;
                exit when cur_faiz_pd_after_2013%notfound;
                ln_loan_account := r_faiz_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_faiz_pd_after_2013.ACILIS_TARIHI); --TemirlanT cbs-119
                if trunc(nvl(ln_available_amount,0),2) > 0 then --end if
                    log_at('cbs-timka_pd','faiz-1',1, 'ln_available_amount='||ln_available_amount);
                    if nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) > 0 then --end if 0->12
                        --aisuluud
                        ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                        ln_acc_amount_before := ln_available_amount;
                        log_at('cbs-timka_pd','faiz-1',2,'ln_available_amount='||ln_available_amount||' ls_past_due_currency='||ls_past_due_currency);

                        if nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) + nvl(r_faiz_pd_after_2013.pd_tax_amount,0) <= trunc(ln_available_amount,2) then
                            log_at('cbs-timka_pd','faiz-1',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                            if trunc(ln_available_amount,2) > 0 then
                                -------------------------FAIZ--------------------------------------------------------------
                                  log_at('timka_eod', 1,8);
                                ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));

                                log_at('cbs-timka_pd','faiz-1',8,'ln_available_amount='||ln_available_amount||' ln_current_account='||ln_current_account);
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита по faiz и tax
                                    log_at('cbs-timka_pd','faiz-1',9,'ln_available_amount='||ln_available_amount||' ln_current_account='||ln_current_account);
                                    if round(ln_available_amount,2) >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    log_at('cbs-timka_pd','faiz-1',10,'ln_available_amount='||ln_available_amount||' ls_choice='||ls_choice);
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;

                                    log_at('cbs-timka_pd','faiz-1',11,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);
                                    log_at('cbs-timka_pd','faiz-1',12,'ln_available_amount='||ln_available_amount||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar);
                                end if;
                                    log_at('cbs-timka_pd','faiz-1',13,'ln_available_amount='||ln_available_amount||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar);
                                ----------------------------FAIZ--------------------------------------------------------------

                                -------------------------------TAX----------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                log_at('cbs-timka_pd','tax-1',1,'ln_available_amount='||ln_available_amount||' ls_past_due_currency='||ls_past_due_currency);
                                ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;

                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);

                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредитa

                                    if ln_available_amount >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;

                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','tax-1',2,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);

                                end if;
                                log_at('cbs-timka_pd','tax-1',3,'ln_available_amount='||ln_available_amount||' ls_account_currency='||ls_account_currency);
                            end if;
                            -------------------------TAX----------------------------------------------------------------
                        else
                            ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;

                            if trunc(ln_available_amount,2) > 0 then
                                ln_pd_tax_balance := round(ln_available_amount,2) * 2 / (100+2);
                                ln_pd_interest_balance := round(ln_available_amount,2) - ln_pd_tax_balance;
                                -------------------------FAIZ--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                                ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;
                                log_at('cbs-timka_pd','faiz_tax_faiz',1,'ln_available_amount='||ln_available_amount||' ln_pd_tax_balance='||ln_pd_tax_balance
                                                            ||' ln_pd_interest_balance='||ln_pd_interest_balance||' ln_pd_balance='||ln_pd_balance);

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);

                                log_at('cbs-timka_pd','faiz_tax_faiz',2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                                -------------------------------------------

                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредитa
                                    if ln_pd_interest_balance >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_interest_balance);
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);

                                    ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    log_at('cbs-timka_pd','faiz_tax_faiz',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','faiz_tax_faiz',4,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );

                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);

                                end if; --bloke
                                log_at('cbs-timka_pd','faiz_tax_faiz',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                                -------------------------FAIZ--------------------------------------------------------------

                                -------------------------TAX--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                log_at('cbs-timka_pd','faiz_tax_tax',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_past_due_currency='||ls_past_due_currency||' ln_acc_amount_before='||ln_acc_amount_before);

                                ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;

                                if ln_pd_tax_balance >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_tax_balance);
                                    ls_choice := 'GERI ODEME';
                                end if;

                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                log_at('cbs-timka_pd','faiz_tax_tax',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;

                                if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;

                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;

                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                    ls_collection_currency := ls_account_currency;

                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;

                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                    if ln_toplam_faiz <> 0 then
                                        ls_choice := 'GERI ODEME';
                                    end if;

                                    pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka

                                    if ls_choice = 'KAPAMA' then
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    log_at('cbs-timka_pd','faiz_tax_tax',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','faiz_tax_tax',8,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                    PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod,
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                    log_at('tahsilat_4883project4',9,'ln_pd_account_no: '||ln_pd_account_no||' ln_available_amount: '||ln_available_amount||' ln_anapara_tahsilat_tutar: '||ln_anapara_tahsilat_tutar );
                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                                    log_at('tahsilat_4883project4',10,'ln_pd_account_no: '||ln_pd_account_no||' ln_available_amount: '||ln_available_amount||' ln_anapara_tahsilat_tutar: '||ln_anapara_tahsilat_tutar );
                                end if; --bloke

                                -------------------------TAX--------------------------------------------------------------
                                log_at('cbs-timka_pd','faiz_tax_tax',9,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                            end if;

                        end if;
                        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                    elsif nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) = 0 then
                        log_at('cbs-timka_pd','faiz_1_tax_0',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                -------------------------FAIZ--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                            ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;

                            log_at('cbs-timka_pd','faiz_1_tax_0',2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);

                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;
                            ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                            log_at('cbs-timka_pd','faiz_1_tax_0',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;

                            if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;

                                ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0);
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0);
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;

                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;

                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                ls_collection_currency := ls_account_currency;

                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;

                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                if ln_toplam_faiz <> 0 then
                                    ls_choice := 'GERI ODEME';
                                end if;

                                pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka

                                if ls_choice = 'KAPAMA' then
                                    ls_durum_kodu := 'K';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                else
                                    ls_durum_kodu := 'A';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                end if;
                                log_at('cbs-timka_pd','faiz_1_tax_0',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_durum_kodu='||ls_durum_kodu||' ls_choice='||ls_choice);
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                log_at('cbs-timka_pd','faiz_1_tax_0',5,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                            end if;--bloke
                            log_at('cbs-timka_pd','faiz_1_tax_0',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                        end if;

                        -------------------------FAIZ--------------------------------------------------------------
                    elsif nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) = 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) > 0 then
                        -------------------------TAX--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                            ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;
                            log_at('cbs-timka_pd','faiz_0_tax_1',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);

                            ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));

                            log_at('cbs-timka_pd','faiz_0_tax_1',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;

                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;

                            if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;

                                ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0);
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0);
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;

                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;

                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
                                ls_collection_currency := ls_account_currency;

                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;

                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                                if ln_toplam_faiz <> 0 then
                                    ls_choice := 'GERI ODEME';
                                end if;
                                pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                                if ls_choice = 'KAPAMA' then
                                    ls_durum_kodu := 'K';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                else
                                    ls_durum_kodu := 'A';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                end if;
                                log_at('cbs-timka_pd','faiz_0_tax_1',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_durum_kodu='||ls_durum_kodu||' ls_choice='||ls_choice);
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                log_at('cbs-timka_pd','faiz_0_tax_1',5,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                                PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod,
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );

                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                            end if;--bloke
                            log_at('cbs-timka_pd','faiz_0_tax_1',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                        end if;
                        -------------------------TAX--------------------------------------------------------------
                    end if; --check balance of tax and faiz

                end if;--main if after loop
            end loop;
            close cur_faiz_pd_after_2013;
        end if; --close faiz and tax condition

        if trunc(ln_available_amount,2) > 0 then
            OPEN cur_def_int_after_2013_pd;
            loop
                fetch cur_def_int_after_2013_pd into r_def_int_after_2013_pd;
                exit when cur_def_int_after_2013_pd%notfound;
                ls_past_due_currency := r_def_int_after_2013_pd.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;
                ln_loan_account := r_def_int_after_2013_pd.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_def_int_after_2013_pd.ACILIS_TARIHI); --TemirlanT cbs-119
                log_at('cbs-timka_pd','after',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ln_loan_account='||ln_loan_account||' ls_month_explanation='||ls_month_explanation);

                if trunc(ln_available_amount,2) > 0 then

                    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_tax_rate);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_tax_rate_last_year);
                    ln_pd_account_no := r_def_int_after_2013_pd.hesap_no;
                    ln_gecenyil_faiz_tutari := abs(nvl(r_def_int_after_2013_pd.GECENYIL_FAIZ_TUTARI,0));
                    ln_gecmis_aylarin_faizi := abs(nvl(r_def_int_after_2013_pd.GECMIS_AYLARIN_FAIZI,0));
                    ln_birikmis_faiz_tutari := abs(nvl(r_def_int_after_2013_pd.BIRIKMIS_FAIZ_TUTARI,0));
                    ln_tahsedil_gecenyilfaiztutar := 0;
                    ln_tahsedil_gecmis_aylar_faiz := 0;
                    ln_tahsedil_birikmisfaiztutar := 0;
                    ln_tax_last_year := 0;
                    ln_tax_last_month := 0;
                    ln_tax_cumulated := 0;
                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;

                    ln_toplam_tax :=      round(
                             (
                               (
                               (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))))*ln_tax_rate_last_year+
                               (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))))*ln_tax_rate
                             )
                             /100
                            ),2
                            )
                            + round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);

                        log_at('cbs-timka_pd','after',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ln_gecenyil_faiz_tutari='||ln_gecenyil_faiz_tutari||' ln_birikmis_faiz_tutari='||ln_birikmis_faiz_tutari
                                                ||' ln_tax_rate='||ln_tax_rate||' ln_tax_rate_last_year='||ln_tax_rate_last_year
                                                ||' ln_gecmis_aylarin_faizi='||ln_gecmis_aylarin_faizi||' ls_past_due_currency='||ls_past_due_currency
                                                ||' ln_toplam_faiz='||ln_toplam_faiz||' ln_toplam_tax='||ln_toplam_tax);
                    if round(nvl(ln_available_amount,0),2) > 0 then

                        if ln_available_amount >= nvl(ln_toplam_faiz,0) + nvl(ln_toplam_tax,0) then
                            ls_choice := 'KAPAMA';
                            ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                            ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                            ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                            ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                            ln_available_amount := nvl(ln_available_amount,0) - (abs(ln_toplam_faiz) + ln_toplam_tax);
                        else
                            ls_choice := 'GERI ODEME';
                            if round(nvl(ln_available_amount,0),2) > 0 then
                                if round(nvl(ln_gecenyil_faiz_tutari,0),2) > 0 then
                                    if ln_available_amount >= ln_gecenyil_faiz_tutari + (round((((nvl(ln_gecenyil_faiz_tutari,0))*ln_tax_rate_last_year )/100),2)) then
                                        ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecenyilfaiztutar,0) + ln_tax_last_year);

                                    else
                                        ln_tahsedil_gecenyilfaiztutar := round(ln_available_amount / (1 + ln_tax_rate_last_year / 100),2);
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecenyilfaiztutar,0)))*ln_tax_rate_last_year )/100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecenyilfaiztutar + ln_tax_last_year);
                                    end if;
                                end if;
                            end if;

                            if trunc(nvl(ln_available_amount,0),2) > 0 then

                                if round(nvl(ln_gecmis_aylarin_faizi,0),2) > 0 then
                                    if ln_available_amount >= ln_gecmis_aylarin_faizi + (round((((nvl(ln_gecmis_aylarin_faizi,0))*ln_tax_rate )/100),2)) then
                                        ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecmis_aylar_faiz,0) + ln_tax_last_month);
                                    else
                                        ln_tahsedil_gecmis_aylar_faiz := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecmis_aylar_faiz,0))) * ln_tax_rate ) / 100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecmis_aylar_faiz + ln_tax_last_month);
                                    end if;
                                end if;

                                if trunc(nvl(ln_available_amount,0),2) > 0 then
                                    if round(nvl(ln_birikmis_faiz_tutari,0),2) > 0 then
                                        if ln_available_amount >= ln_birikmis_faiz_tutari + (round(((nvl(ln_birikmis_faiz_tutari,0)*ln_tax_rate)/100),2)) then
                                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                                            ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_birikmisfaiztutar,0) + ln_tax_cumulated);
                                        else
                                            ln_tahsedil_birikmisfaiztutar := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_birikmisfaiztutar,0))) * ln_tax_rate ) / 100),2);
                                            ln_available_amount := ln_available_amount - (ln_tahsedil_birikmisfaiztutar + ln_tax_cumulated);
                                        end if;
                                    end if;
                                end if;

                            end if;
                        end if;

                    end if;
                    -----------------------------------
                    ln_faizler := ln_tahsedil_gecenyilfaiztutar + ln_tahsedil_gecmis_aylar_faiz + ln_tahsedil_birikmisfaiztutar + ln_tax_last_year + ln_tax_last_month + ln_tax_cumulated;
                    log_at('cbs-timka_pd','after',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ln_gecenyil_faiz_tutari='||ln_gecenyil_faiz_tutari||' ln_birikmis_faiz_tutari='||ln_birikmis_faiz_tutari
                                                ||' ln_tax_rate='||ln_tax_rate||' ln_tax_rate_last_year='||ln_tax_rate_last_year
                                                ||' ln_gecmis_aylarin_faizi='||ln_gecmis_aylarin_faizi||' ls_past_due_currency='||ls_past_due_currency
                                                ||' ln_tax_cumulated='||ln_tax_cumulated||' ln_tax_last_month='||ln_tax_last_month);

                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;

                    log_at('cbs-timka_pd','after',5,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;

                    if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                        ls_modul_tur_kod := r_def_int_after_2013_pd.modul_tur_kod;
                        ls_urun_tur_kod := r_def_int_after_2013_pd.urun_tur_kod;
                        ls_urun_sinif_kod := r_def_int_after_2013_pd.urun_sinif_kod;
                        ln_pd_balance := r_def_int_after_2013_pd.pd_balance;
                        ls_pd_branch_cd := r_def_int_after_2013_pd.sube_kodu;
                        ls_son_gun_faizi := r_def_int_after_2013_pd.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ;
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if;

                        ld_value_date := null;
                        ls_collection_currency := ls_account_currency;

                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;

                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);

                        if ln_pd_balance <> 0 then
                            ls_choice := 'GERI ODEME';
                        end if;
                        log_at('cbs-timka_pd','after',5,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ls_choice='||ls_choice||' ls_collection_currency='||ls_collection_currency);
                        ln_anapara_tahsilat_tutar := 0;
                        ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_def_int_after_2013_pd.acilis_tarihi;
                        --BOM TemirlanT
                        pkg_parametre.deger('G_PD_DAY_EXPLANATION',ls_day);
                        if ln_delayed_days=1 then
                            ls_day := SUBSTR (ls_day, 1, 4);
                        elsif ln_delayed_days in (2,3,4) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        elsif ln_delayed_days >= 5 and ln_delayed_days <= 21 then
                            ls_day := SUBSTR (ls_day, 10, 4);
                        elsif ln_delayed_days >= 22 and (mod(ln_delayed_days,10)  in (2,3,4)) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        else
                            ls_day := SUBSTR (ls_day, 10, 4);
                        end if;
                        --EOM TemirlanT
                        pkg_parametre.deger('G_PD_ELEVATED_EXPLANATION',ls_aciklama);
                        ls_aciklama := REPLACE (ls_aciklama, '$$$', ln_delayed_days);
                        ls_aciklama := REPLACE (ls_aciklama, '@@@', ls_day);
                        ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                        ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                        ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                        if ls_choice = 'KAPAMA' then
                            ls_durum_kodu := 'K';
                            ls_aciklama := REPLACE (ls_aciklama, '%%%');
                        else
                            ls_durum_kodu := 'A';
                            ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);--TemirlanT
                        end if;


                        log_at('cbs-timka_pd','after',6,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                               ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                               ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                               ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                               ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                               ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                               ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                               ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                               ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);
                        PKG_KREDI_AUTOMATION.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod,
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );

                    end if; --bloke
                    log_at('cbs-timka_pd','after',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                end if;

            end loop;
            close cur_def_int_after_2013_pd;
        end if;

        if trunc(ln_available_amount,2) > 0 then
            open cur_penalty_pd_after_2013;
            loop
                fetch cur_penalty_pd_after_2013 into r_penalty_pd_after_2013;
                exit when cur_penalty_pd_after_2013%notfound;
                log_at('check_in','cur_penalty_pd_after_2013','ln_available_amount '||ln_available_amount);
                ls_past_due_currency := r_penalty_pd_after_2013.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;
                ln_loan_account := r_penalty_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                log_at('cbs-timka_pd','penalty',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                if trunc(ln_available_amount,2) > 0 then

                    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);

                    ln_related_account_penalty := r_penalty_pd_after_2013.hesap_no;
                    ln_amount_penalty := r_penalty_pd_after_2013.penalty_amount;
                    ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);

                    if round(ln_available_amount,2) < nvl(r_penalty_pd_after_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                    elsif round(ln_available_amount,2) = nvl(r_penalty_pd_after_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                    elsif round(ln_available_amount,2) > nvl(r_penalty_pd_after_2013.penalty_amount,0) then
                        if round(ln_available_amount,2) >= nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := r_penalty_pd_after_2013.penalty_amount;
                            ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);
                        elsif round(ln_available_amount,2) < nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                            ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                        end if;
                    end if;

                    ln_total_collection_amount := nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0);
                   log_at('cbs-timka_pd','penalty',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                    ||' ln_amount_penalty='||ln_amount_penalty||' ln_paid_tax_amount='||ln_paid_tax_amount);

                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_related_account_penalty
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A'
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;

                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;

                    if  lb_block = false then --если все блоки по счету сняты, то производится дальнейшее погашение кредита

                        log_at('cbs-timka_pd','penalty',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                    ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                        ls_cash_account := 'ACCOUNT';
                        ls_currency_code := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_current_account_2);
                        ln_customer_no := ln_musteri_no;
                        ls_residency_code := pkg_musteri.sf_get_residency_code (ln_customer_no);
                        ls_citizen_code := pkg_musteri.sf_get_citizenship_country(ln_customer_no);
                        ls_customer_type := pkg_musteri.sf_musteri_tipi_al(ln_customer_no );
                        ls_income_type := 'LOANCOMM';

                        ls_vat := 'N';
                        ls_service_tax := 'Y';
                        ls_tax_coll_type := 'PS';--PAID SEPERATELY
                        ln_rate_penalty := pkg_kur.doviz_doviz_karsilik(ls_currency_code,pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        ln_collection_account_penalty := ln_related_account_pd;
                        ls_collection_currency_penalty := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_collection_account_penalty);
                        pkg_parametre.deger('G_PD_PENALTY',ls_income_gl);
                        ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_penalty_pd_after_2013.acilis_tarihi;
                        --BOM TemirlanT
                        select ACIKLAMA into ls_dk_explanation from CBS_DKHESAP
                            where numara=r_penalty_pd_after_2013.ana_dk_no and bolum_kodu=r_penalty_pd_after_2013.sube_kodu and doviz_kod=r_penalty_pd_after_2013.doviz_kodu;
                        pkg_parametre.deger('G_PD_SECTOR_EXPLANATION',ls_sector_explanation);
                        if (instr(ls_dk_explanation,'Mortgage') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 1, 4);
                        elsif (instr(ls_dk_explanation,'Agriculture') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 6, 3);
                        elsif (instr(ls_dk_explanation,'Industry') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 10, 4);
                        elsif (instr(ls_dk_explanation,'construction') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 15, 6);
                        elsif (instr(ls_dk_explanation,'individual') > 0) or (instr(ls_dk_explanation,'Consumer') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 22, 4);
                        else
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 27, 4);
                        end if;

                        pkg_parametre.deger('G_PD_DAY_EXPLANATION',ls_day);
                        if ln_delayed_days=1 then
                            ls_day := SUBSTR (ls_day, 1, 4);
                        elsif ln_delayed_days in (2,3,4) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        elsif ln_delayed_days >= 5 and ln_delayed_days <= 21 then
                            ls_day := SUBSTR (ls_day, 10, 4);
                        elsif ln_delayed_days >= 22 and (mod(ln_delayed_days,10)  in (2,3,4)) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        else
                            ls_day := SUBSTR (ls_day, 10, 4);
                        end if;
                        pkg_parametre.deger('G_PD_PENALTY_EXPLANATION',ls_explanation);
                        ls_explanation := REPLACE (ls_explanation, '$$$', ln_delayed_days);
                        ls_explanation := REPLACE (ls_explanation, '@@@', ls_day);
                        ls_explanation := REPLACE (ls_explanation, '***', ln_loan_account);
                        ls_explanation := REPLACE (ls_explanation, '&&&', ls_name_surname);
                        ls_explanation := REPLACE (ls_explanation, '###', ls_sector_explanation); --TemirlanT timka
                        --ls_explanation := 'ПЕНИ ЗА ' || ln_delayed_days || ' ' || ls_day || ' НА ПРОСР. ПРОЦЕНТЫ+НСП (' || ln_loan_account || ') - ' || ls_name_surname || ls_sector_explanation;  --TemirlanT
                        --EOM TemirlanT
                        ls_modul_tur_kod := 'CURR.OPS.';
                        ls_urun_tur_kod := 'CHARGE';
                        ls_urun_sinif_kod := 'GENERAL';
                        ls_pd_branch_cd := r_penalty_pd_after_2013.sube_kodu;
                        log_at('cbs-timka_pd','penalty',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                    ||' ls_cash_account='||ls_cash_account||' ls_currency_code='||ls_currency_code
                                                    ||' ln_customer_no='||ln_customer_no||' ls_residency_code='||ls_residency_code
                                                    ||' ls_citizen_code='||ls_citizen_code||' ls_customer_type='||ls_customer_type
                                                    ||' ls_income_type='||ls_income_type||' ln_related_account_penalty='||ln_related_account_penalty
                                                    ||' ln_amount_penalty='||ln_amount_penalty||' ls_vat='||ls_vat
                                                    ||' ls_service_tax='||ls_service_tax||' ln_service_tax_rate='||ln_service_tax_rate
                                                    ||' ls_tax_coll_type='||ls_tax_coll_type||' ln_paid_tax_amount='||ln_paid_tax_amount
                                                    ||' ln_total_collection_amount='||ln_total_collection_amount||' ls_collection_currency_penalty='||ls_collection_currency_penalty
                                                    ||' ln_rate_penalty='||ln_rate_penalty||' ln_collection_account_penalty='||ln_collection_account_penalty
                                                    ||' ls_income_gl='||ls_income_gl||' ls_explanation='||ls_explanation
                                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                                    ||' ln_current_account='||ln_current_account);
                        PKG_KREDI_AUTOMATION.sp_penalty_Pastdue_Closing(
                                                            ls_cash_account ,
                                                            ls_currency_code ,
                                                            ln_customer_no ,
                                                            ls_residency_code,
                                                            ls_citizen_code,
                                                            ls_customer_type,
                                                            ls_income_type,
                                                            ln_related_account_penalty,
                                                            ln_amount_penalty,
                                                            ls_vat,
                                                            ls_service_tax,
                                                            ln_service_tax_rate,
                                                            ls_tax_coll_type,
                                                            ln_paid_tax_amount,
                                                            ln_total_collection_amount,
                                                            ls_collection_currency_penalty,
                                                            ln_rate_penalty,
                                                            ln_collection_account_penalty,
                                                            ls_income_gl,
                                                            ls_explanation,
                                                            ls_pd_branch_cd,
                                                            ls_modul_tur_kod,
                                                            ls_urun_tur_kod,
                                                            ls_urun_sinif_kod,
                                                            ln_current_account
                                                            );

                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_total_collection_amount,0);
                    end if; -- bloke

                end if;
            log_at('cbs-timka_pd','penalty',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
            end loop;
            close cur_penalty_pd_after_2013;
        end if;
    --end if;
 --END LOOP;
 --CLOSE c_credited_cust;

 --select job_no into ln_job_no from CBS_PASTDUE_CLOSING_PAYMENT where tx_no=pn_islem_no;
 --dbms_job.remove(ln_job_no);

 exception
 when others then
 log_at('pkg_kredi_pd_closing','tahsilat', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 rollback;
 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4668' ||  Pkg_Hata.getdelimiter|| ln_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);


end;
--EOM aisuluud cq4883
end;
/

