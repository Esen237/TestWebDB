create PACKAGE     PKG_MUSTERI IS
/******************************************************************************
    Name       : PKG_MUSTERI
    Created By : Seval Balci
    Date       : 20.06.03
    Purpose    : Musteri giris ,izleme ve guncelleme ilgili procedure ve fonksiyonlari icerir
******************************************************************************/
    PROCEDURE Sp_Log_Musteri_Guncel_Alan(ps_table_name                   VARCHAR2,
                                         p_new_musteri_no                CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_NO%TYPE,
                                         p_new_musteri_tipi_kod          CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_TIPI_KOD%TYPE,
                                         p_new_dk_grup_kod               CBS.CBS_MUSTERI_GUNCELLENEN.DK_GRUP_KOD%TYPE,
                                         p_new_isim                      CBS.CBS_MUSTERI_GUNCELLENEN.ISIM%TYPE,
                                         p_new_ikinci_isim               CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM%TYPE,
                                         p_new_soyadi                    CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI%TYPE,
                                         p_new_dogum_tarihi              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_TARIHI%TYPE,
                                         p_new_dogum_yeri                CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_YERI%TYPE,
                                         p_new_dogum_il_kod              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_IL_KOD%TYPE,
                                         p_new_cinsiyet_kod              CBS.CBS_MUSTERI_GUNCELLENEN.CINSIYET_KOD%TYPE,
                                         p_new_baba_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.BABA_ADI%TYPE,
                                         p_new_anne_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_ADI%TYPE,
                                         p_new_anne_kizlik_soyadi        CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_KIZLIK_SOYADI%TYPE,
                                         p_new_meslek_kod                CBS.CBS_MUSTERI_GUNCELLENEN.MESLEK_KOD%TYPE,
                                         p_new_egitim_kod                CBS.CBS_MUSTERI_GUNCELLENEN.EGITIM_KOD%TYPE,
                                         p_new_medeni_hal_kod            CBS.CBS_MUSTERI_GUNCELLENEN.MEDENI_HAL_KOD%TYPE,
                                         p_new_ticari_unvan              CBS.CBS_MUSTERI_GUNCELLENEN.ticari_unvan%TYPE,
                                         p_new_hesap_ucreti_f            CBS.CBS_MUSTERI_GUNCELLENEN.HESAP_UCRETI_F%TYPE,
                                         p_new_cek_karnesi_f             CBS.CBS_MUSTERI_GUNCELLENEN.CEK_KARNESI_F%TYPE,
                                         p_new_personel_sicil_no         CBS.CBS_MUSTERI_GUNCELLENEN.PERSONEL_SICIL_NO%TYPE,
                                         p_new_yerlesim_kod              CBS.CBS_MUSTERI_GUNCELLENEN.YERLESIM_KOD%TYPE,
                                         p_new_ozel_kategori_kod         CBS.CBS_MUSTERI_GUNCELLENEN.OZEL_KATEGORI_KOD%TYPE,
                                         p_new_vergi_muaf_kod            CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_MUAF_KOD%TYPE,
                                         p_new_vergi_dairesi_adi         CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_DAIRESI_ADI%TYPE,
                                         p_new_vergi_no                  CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_NO%TYPE,
                                         p_new_tesvik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.TESVIK_KOD%TYPE,
                                         p_new_uyruk_kod                 CBS.CBS_MUSTERI_GUNCELLENEN.UYRUK_KOD%TYPE,
                                         p_new_kimlik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.KIMLIK_KOD%TYPE,
                                         p_new_tc_kimlik_no              CBS.CBS_MUSTERI_GUNCELLENEN.TC_KIMLIK_NO%TYPE,
                                         p_new_nufus_cuzdani_seri_no     CBS.CBS_MUSTERI_GUNCELLENEN.NUFUS_CUZDANI_SERI_NO%TYPE,
                                         p_new_pasaport_no               CBS.CBS_MUSTERI_GUNCELLENEN.PASAPORT_NO%TYPE,
                                         p_new_ehliyet_belge_no          CBS.CBS_MUSTERI_GUNCELLENEN.EHLIYET_BELGE_NO%TYPE,
                                         p_new_il_kod                    CBS.CBS_MUSTERI_GUNCELLENEN.IL_KOD%TYPE,
                                         p_new_ilce_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.ILCE_KOD%TYPE,
                                         p_new_mahalle_koy               CBS.CBS_MUSTERI_GUNCELLENEN.MAHALLE_KOY%TYPE,
                                         p_new_cilt_no                   CBS.CBS_MUSTERI_GUNCELLENEN.CILT_NO%TYPE,
                                         p_new_aile_sira_no              CBS.CBS_MUSTERI_GUNCELLENEN.AILE_SIRA_NO%TYPE,
                                         p_new_sira_no                   CBS.CBS_MUSTERI_GUNCELLENEN.SIRA_NO%TYPE,
                                         p_new_verildigi_yer             CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_YER%TYPE,
                                         p_new_verildigi_tarih           CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_TARIH%TYPE,
                                         p_new_sektor_kod                CBS.CBS_MUSTERI_GUNCELLENEN.SEKTOR_KOD%TYPE,
                                         p_new_finans_kod                CBS.CBS_MUSTERI_GUNCELLENEN.FINANS_KOD%TYPE,
                                         p_new_ticari_sicil_no           CBS.CBS_MUSTERI_GUNCELLENEN.TICARI_SICIL_NO%TYPE,
                                         p_new_extre_adres_kod           CBS.CBS_MUSTERI_GUNCELLENEN.EXTRE_ADRES_KOD%TYPE,
                                         p_new_serbest_bolge_izin_tar    CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_TARIHI%TYPE,
                                         p_new_serbest_bolge_izin_no     CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_NO%TYPE,
                                         p_new_pazar_sorum_sicil_no_1    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_1%TYPE,
                                         p_new_pazar_sorum_sicil_no_2    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_2%TYPE,
                                         p_new_grup_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.GRUP_KOD%TYPE,
                                         p_new_bic_kod                   CBS.CBS_MUSTERI_GUNCELLENEN.BIC_KOD%TYPE,
                                         p_new_swift_mesaj_kod           CBS.CBS_MUSTERI_GUNCELLENEN.SWIFT_MESAJ_KOD%TYPE,
                                         p_new_reuters_info_page         CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_INFO_PAGE%TYPE,
                                         p_new_reuters_dealing_kod       CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_DEALING_KOD%TYPE,
                                         p_new_sektor_alt1_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt1_kodu%TYPE,
                                         p_new_sektor_alt2_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt2_kodu%TYPE,
                                         p_new_rating_kodu               CBS.CBS_MUSTERI_GUNCELLENEN.rating_kodu%TYPE,
                                         p_new_bolum_kodu                CBS.CBS_MUSTERI_GUNCELLENEN.bolum_kodu%TYPE,
                                         p_new_GECERLILIK_TARIHI         DATE,
                                         p_new_VERGI_DAIRE_KODU          CBS.CBS_MUSTERI_GUNCELLENEN.vergi_daire_kodu%TYPE,
                                         p_new_vat_seri_no               CBS.cbs_musteri_guncellenen.vat_seri_no%TYPE,
                                         p_new_vat_sira_no               CBS.cbs_musteri_guncellenen.vat_sira_no%TYPE,
                                         p_new_okpo_code                 CBS.cbs_musteri_guncellenen.okpo_code%TYPE,
                                         p_new_manager_name              CBS.cbs_musteri_guncellenen.manager_name%TYPE,
                                         p_new_manager_surname           CBS.cbs_musteri_guncellenen.manager_surname%TYPE,
                                         p_new_manager_patronymic_name   CBS.cbs_musteri_guncellenen.manager_patronymic_name%TYPE,
                                         p_new_manager_country_code      CBS.cbs_musteri_guncellenen.manager_country_code%TYPE,
                                         p_new_manager_resident_code     CBS.cbs_musteri_guncellenen.manager_resident_code%TYPE,
                                         p_new_second_manager_name       CBS.cbs_musteri_guncellenen.second_manager_name%TYPE,
                                         p_new_vergi_zorunlumu           CBS.cbs_musteri_guncellenen.vergi_zorunlumu%TYPE,
                                         p_new_sosyal_fon_no             CBS.cbs_musteri_guncellenen.sosyal_fon_no%TYPE,
                                         p_new_ekstre_ucreti_alinsin     CBS.cbs_musteri_guncellenen.ekstre_ucreti_alinsin%TYPE,
                                         p_new_WORKING_BASIS             CBS.cbs_musteri_guncellenen.WORKING_BASIS%TYPE,
                                         P_new_PATENT_NO                 CBS.cbs_musteri_guncellenen.PATENT_NO%TYPE,
                                         P_new_PATENT_EXPIRY_DATE        CBS.cbs_musteri_guncellenen.PATENT_EXPIRY_DATE%TYPE,
                                         P_new_LEGAL_FORM_CODE           CBS.cbs_musteri_guncellenen.LEGAL_FORM_CODE%TYPE,
                                         p_new_isim_eng                  CBS.CBS_MUSTERI_GUNCELLENEN.ISIM_ENG%TYPE,
                                         p_new_ikinci_isim_eng           CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM_ENG%TYPE,
                                         p_new_soyadi_eng                CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI_ENG%TYPE,
                                         p_new_MANAGER_ID_TYPE           CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_ID_TYPE%TYPE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                         p_new_MANAGER_PASSPORT_NUMBER   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_NUMBER%TYPE,
                                         p_new_MANAGER_PASS_ISSUE_D      CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_DATE%TYPE,
                                         p_new_MANAGER_PASS_EXPIRING_D   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_EXPIRING_DATE%TYPE,
                                         p_new_MANAGER_PASS_ISSUE_PLACE  CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_PLACE%TYPE,
                                         p_new_MANAGER_PASSPORT_SERIES   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_SERIES%TYPE, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                                      --BOM CBS-395 AntonPa 271022
                                         P_NEW_MILITARY_CARD              CBS.CBS_MUSTERI_GUNCELLENEN.MILITARY_CARD%TYPE,
                                         P_NEW_RESIDENCE_PERMIT           CBS.CBS_MUSTERI_GUNCELLENEN.RESIDENCE_PERMIT%TYPE,    
                                         P_NEW_ECONOMY_SECTOR_CODE        CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMY_SECTOR_CODE%TYPE,      
                                         P_NEW_BANK_RELATION_CODE         CBS.CBS_MUSTERI_GUNCELLENEN.BANK_RELATION_CODE%TYPE,        
                                         P_NEW_CIVIL_STATUS_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CIVIL_STATUS_CODE%TYPE,  
                                         P_NEW_CAPITAL_PARTICIPATION_CODE CBS.CBS_MUSTERI_GUNCELLENEN.CAPITAL_PARTICIPATION_CODE%TYPE,                
                                         P_NEW_CONTROL_FORM_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CONTROL_FORM_CODE%TYPE,   
                                         P_NEW_ECONOMIC_ACTIVITY_SUB      CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_SUB%TYPE,        
                                         P_NEW_ECONOMIC_ACTIVITY_CODE     CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_CODE%TYPE,            
                                         P_NEW_TAX_INITIAL_REG_DATE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_INITIAL_REG_DATE%TYPE,        
                                         P_NEW_TAX_REG_AUTHORITY          CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_AUTHORITY%TYPE,    
                                         P_NEW_TAX_RE_REG_DATE            CBS.CBS_MUSTERI_GUNCELLENEN.TAX_RE_REG_DATE%TYPE,    
                                         P_NEW_TAX_REG_COUNTRY_CODE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_COUNTRY_CODE%TYPE,       
                                         P_NEW_IS_LICENSED                CBS.CBS_MUSTERI_GUNCELLENEN.IS_LICENSED%TYPE,
                                         P_NEW_MANAGER_GENDER             CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_GENDER%TYPE,
                                         P_NEW_DECLARED_SHARE_CAPITAL     CBS.CBS_MUSTERI_GUNCELLENEN.DECLARED_SHARE_CAPITAL%TYPE, 
                                         P_NEW_SHARE_CAPITAL_CURRENCY     CBS.CBS_MUSTERI_GUNCELLENEN.SHARE_CAPITAL_CURRENCY%TYPE,
                                         P_NEW_PAID_SHARE_CAPITAL         CBS.CBS_MUSTERI_GUNCELLENEN.PAID_SHARE_CAPITAL%TYPE,
                                         P_NEW_PDL_CODE                   CBS.CBS_MUSTERI_GUNCELLENEN.PDL_CODE%TYPE,
                                         P_NEW_BIRTH_CERTIFICATE          CBS.CBS_MUSTERI_GUNCELLENEN.BIRTH_CERTIFICATE%TYPE,
                                         P_NEW_COMPANY_NAME_KYR           CBS.CBS_MUSTERI_GUNCELLENEN.COMPANY_NAME_KYR%TYPE,
                                         P_NEW_OPF_ID_CODE                CBS.CBS_MUSTERI_GUNCELLENEN.OPF_ID_CODE%TYPE,
                                      --EOM CBS-395 AntonPa 271022
                                         p_old_musteri_no                CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_NO%TYPE,
                                         p_old_musteri_tipi_kod          CBS.CBS_MUSTERI_GUNCELLENEN.MUSTERI_TIPI_KOD%TYPE,
                                         p_old_dk_grup_kod               CBS.CBS_MUSTERI_GUNCELLENEN.DK_GRUP_KOD%TYPE,
                                         p_old_isim                      CBS.CBS_MUSTERI_GUNCELLENEN.ISIM%TYPE,
                                         p_old_ikinci_isim               CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM%TYPE,
                                         p_old_soyadi                    CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI%TYPE,
                                         p_old_dogum_tarihi              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_TARIHI%TYPE,
                                         p_old_dogum_yeri                CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_YERI%TYPE,
                                         p_old_dogum_il_kod              CBS.CBS_MUSTERI_GUNCELLENEN.DOGUM_IL_KOD%TYPE,
                                         p_old_cinsiyet_kod              CBS.CBS_MUSTERI_GUNCELLENEN.CINSIYET_KOD%TYPE,
                                         p_old_baba_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.BABA_ADI%TYPE,
                                         p_old_anne_adi                  CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_ADI%TYPE,
                                         p_old_anne_kizlik_soyadi        CBS.CBS_MUSTERI_GUNCELLENEN.ANNE_KIZLIK_SOYADI%TYPE,
                                         p_old_meslek_kod                CBS.CBS_MUSTERI_GUNCELLENEN.MESLEK_KOD%TYPE,
                                         p_old_egitim_kod                CBS.CBS_MUSTERI_GUNCELLENEN.EGITIM_KOD%TYPE,
                                         p_old_medeni_hal_kod            CBS.CBS_MUSTERI_GUNCELLENEN.MEDENI_HAL_KOD%TYPE,
                                         p_old_ticari_unvan              CBS.CBS_MUSTERI_GUNCELLENEN.ticari_unvan%TYPE,
                                         p_old_hesap_ucreti_f            CBS.CBS_MUSTERI_GUNCELLENEN.HESAP_UCRETI_F%TYPE,
                                         p_old_cek_karnesi_f             CBS.CBS_MUSTERI_GUNCELLENEN.CEK_KARNESI_F%TYPE,
                                         p_old_personel_sicil_no         CBS.CBS_MUSTERI_GUNCELLENEN.PERSONEL_SICIL_NO%TYPE,
                                         p_old_yerlesim_kod              CBS.CBS_MUSTERI_GUNCELLENEN.YERLESIM_KOD%TYPE,
                                         p_old_ozel_kategori_kod         CBS.CBS_MUSTERI_GUNCELLENEN.OZEL_KATEGORI_KOD%TYPE,
                                         p_old_vergi_muaf_kod            CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_MUAF_KOD%TYPE,
                                         p_old_vergi_dairesi_adi         CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_DAIRESI_ADI%TYPE,
                                         p_old_vergi_no                  CBS.CBS_MUSTERI_GUNCELLENEN.VERGI_NO%TYPE,
                                         p_old_tesvik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.TESVIK_KOD%TYPE,
                                         p_old_uyruk_kod                 CBS.CBS_MUSTERI_GUNCELLENEN.UYRUK_KOD%TYPE,
                                         p_old_kimlik_kod                CBS.CBS_MUSTERI_GUNCELLENEN.KIMLIK_KOD%TYPE,
                                         p_old_tc_kimlik_no              CBS.CBS_MUSTERI_GUNCELLENEN.TC_KIMLIK_NO%TYPE,
                                         p_old_nufus_cuzdani_seri_no     CBS.CBS_MUSTERI_GUNCELLENEN.NUFUS_CUZDANI_SERI_NO%TYPE,
                                         p_old_pasaport_no               CBS.CBS_MUSTERI_GUNCELLENEN.PASAPORT_NO%TYPE,
                                         p_old_ehliyet_belge_no          CBS.CBS_MUSTERI_GUNCELLENEN.EHLIYET_BELGE_NO%TYPE,
                                         p_old_il_kod                    CBS.CBS_MUSTERI_GUNCELLENEN.IL_KOD%TYPE,
                                         p_old_ilce_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.ILCE_KOD%TYPE,
                                         p_old_mahalle_koy               CBS.CBS_MUSTERI_GUNCELLENEN.MAHALLE_KOY%TYPE,
                                         p_old_cilt_no                   CBS.CBS_MUSTERI_GUNCELLENEN.CILT_NO%TYPE,
                                         p_old_aile_sira_no              CBS.CBS_MUSTERI_GUNCELLENEN.AILE_SIRA_NO%TYPE,
                                         p_old_sira_no                   CBS.CBS_MUSTERI_GUNCELLENEN.SIRA_NO%TYPE,
                                         p_old_verildigi_yer             CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_YER%TYPE,
                                         p_old_verildigi_tarih           CBS.CBS_MUSTERI_GUNCELLENEN.VERILDIGI_TARIH%TYPE,
                                         p_old_sektor_kod                CBS.CBS_MUSTERI_GUNCELLENEN.SEKTOR_KOD%TYPE,
                                         p_old_finans_kod                CBS.CBS_MUSTERI_GUNCELLENEN.FINANS_KOD%TYPE,
                                         p_old_ticari_sicil_no           CBS.CBS_MUSTERI_GUNCELLENEN.TICARI_SICIL_NO%TYPE,
                                         p_old_extre_adres_kod           CBS.CBS_MUSTERI_GUNCELLENEN.EXTRE_ADRES_KOD%TYPE,
                                         p_old_serbest_bolge_izin_tar    CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_TARIHI%TYPE,
                                         p_old_serbest_bolge_izin_no     CBS.CBS_MUSTERI_GUNCELLENEN.SERBEST_BOLGE_IZIN_NO%TYPE,
                                         p_old_pazar_sorum_sicil_no_1    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_1%TYPE,
                                         p_old_pazar_sorum_sicil_no_2    CBS.CBS_MUSTERI_GUNCELLENEN.PAZARLAMA_SORUMLUSU_SICIL_NO_2%TYPE,
                                         p_old_grup_kod                  CBS.CBS_MUSTERI_GUNCELLENEN.GRUP_KOD%TYPE,
                                         p_old_bic_kod                   CBS.CBS_MUSTERI_GUNCELLENEN.BIC_KOD%TYPE,
                                         p_old_swift_mesaj_kod           CBS.CBS_MUSTERI_GUNCELLENEN.SWIFT_MESAJ_KOD%TYPE,
                                         p_old_reuters_info_page         CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_INFO_PAGE%TYPE,
                                         p_old_reuters_dealing_kod       CBS.CBS_MUSTERI_GUNCELLENEN.REUTERS_DEALING_KOD%TYPE,
                                         p_old_sektor_alt1_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt1_kodu%TYPE,
                                         p_old_sektor_alt2_kodu          CBS.CBS_MUSTERI_GUNCELLENEN.sektor_alt2_kodu%TYPE,
                                         p_old_rating_kodu               CBS.CBS_MUSTERI_GUNCELLENEN.rating_kodu%TYPE,
                                         p_old_bolum_kodu                CBS.CBS_MUSTERI_GUNCELLENEN.bolum_kodu%TYPE,
                                         p_old_GECERLILIK_TARIHI         DATE,
                                         p_old_VERGI_DAIRE_KODU          CBS.CBS_MUSTERI_GUNCELLENEN.vergi_daire_kodu%TYPE,
                                         p_old_vat_seri_no               CBS.cbs_musteri_guncellenen.vat_seri_no%TYPE,
                                         p_old_vat_sira_no               CBS.cbs_musteri_guncellenen.vat_sira_no%TYPE,
                                         p_old_okpo_code                 CBS.cbs_musteri_guncellenen.okpo_code%TYPE,
                                         p_old_manager_name              CBS.cbs_musteri_guncellenen.manager_name%TYPE,
                                         p_old_manager_surname           CBS.cbs_musteri_guncellenen.manager_surname%TYPE,
                                         p_old_manager_patronymic_name   CBS.cbs_musteri_guncellenen.manager_patronymic_name%TYPE,
                                         p_old_manager_country_code      CBS.cbs_musteri_guncellenen.manager_country_code%TYPE,
                                         p_old_manager_resident_code     CBS.cbs_musteri_guncellenen.manager_resident_code%TYPE,
                                         p_old_second_manager_name       CBS.cbs_musteri_guncellenen.second_manager_name%TYPE,
                                         p_old_vergi_zorunlumu           CBS.cbs_musteri_guncellenen.vergi_zorunlumu%TYPE,
                                         p_old_sosyal_fon_no             CBS.cbs_musteri_guncellenen.sosyal_fon_no%TYPE,
                                         p_old_ekstre_ucreti_alinsin     CBS.cbs_musteri_guncellenen.ekstre_ucreti_alinsin%TYPE,
                                         p_old_WORKING_BASIS             CBS.cbs_musteri_guncellenen.WORKING_BASIS%TYPE,
                                         P_old_PATENT_NO                 CBS.cbs_musteri_guncellenen.PATENT_NO%TYPE,
                                         P_old_PATENT_EXPIRY_DATE        CBS.cbs_musteri_guncellenen.PATENT_EXPIRY_DATE%TYPE,
                                         P_old_LEGAL_FORM_CODE           CBS.cbs_musteri_guncellenen.LEGAL_FORM_CODE%TYPE,
                                         p_old_isim_eng                  CBS.CBS_MUSTERI_GUNCELLENEN.ISIM_ENG%TYPE,
                                         p_old_ikinci_isim_eng           CBS.CBS_MUSTERI_GUNCELLENEN.IKINCI_ISIM_ENG%TYPE,
                                         p_old_soyadi_eng                CBS.CBS_MUSTERI_GUNCELLENEN.SOYADI_ENG%TYPE,
                                         pn_tx_no                        CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE,
                                         p_old_MANAGER_ID_TYPE           CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_ID_TYPE%TYPE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                         p_old_MANAGER_PASSPORT_NUMBER   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_NUMBER%TYPE,
                                         p_old_MANAGER_PASS_ISSUE_D      CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_DATE%TYPE,
                                         p_old_MANAGER_PASS_EXPIRING_D   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_EXPIRING_DATE%TYPE,
                                         p_old_MANAGER_PASS_ISSUE_PLACE  CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASS_ISSUE_PLACE%TYPE,
                                         p_old_MANAGER_PASSPORT_SERIES   CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_PASSPORT_SERIES%TYPE, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                                      --BOM AntonPa CBS-395 271022
                                         P_OLD_MILITARY_CARD              CBS.CBS_MUSTERI_GUNCELLENEN.MILITARY_CARD%TYPE,
                                         P_OLD_RESIDENCE_PERMIT           CBS.CBS_MUSTERI_GUNCELLENEN.RESIDENCE_PERMIT%TYPE,    
                                         P_OLD_ECONOMY_SECTOR_CODE        CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMY_SECTOR_CODE%TYPE,      
                                         P_OLD_BANK_RELATION_CODE         CBS.CBS_MUSTERI_GUNCELLENEN.BANK_RELATION_CODE%TYPE,        
                                         P_OLD_CIVIL_STATUS_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CIVIL_STATUS_CODE%TYPE,  
                                         P_OLD_CAPITAL_PARTICIPATION_CODE CBS.CBS_MUSTERI_GUNCELLENEN.CAPITAL_PARTICIPATION_CODE%TYPE,                
                                         P_OLD_CONTROL_FORM_CODE          CBS.CBS_MUSTERI_GUNCELLENEN.CONTROL_FORM_CODE%TYPE,   
                                         P_OLD_ECONOMIC_ACTIVITY_SUB      CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_SUB%TYPE,        
                                         P_OLD_ECONOMIC_ACTIVITY_CODE     CBS.CBS_MUSTERI_GUNCELLENEN.ECONOMIC_ACTIVITY_CODE%TYPE,            
                                         P_OLD_TAX_INITIAL_REG_DATE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_INITIAL_REG_DATE%TYPE,        
                                         P_OLD_TAX_REG_AUTHORITY          CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_AUTHORITY%TYPE,    
                                         P_OLD_TAX_RE_REG_DATE            CBS.CBS_MUSTERI_GUNCELLENEN.TAX_RE_REG_DATE%TYPE,    
                                         P_OLD_TAX_REG_COUNTRY_CODE       CBS.CBS_MUSTERI_GUNCELLENEN.TAX_REG_COUNTRY_CODE%TYPE,       
                                         P_OLD_IS_LICENSED                CBS.CBS_MUSTERI_GUNCELLENEN.IS_LICENSED%TYPE,
                                         P_OLD_MANAGER_GENDER             CBS.CBS_MUSTERI_GUNCELLENEN.MANAGER_GENDER%TYPE,
                                         P_OLD_DECLARED_SHARE_CAPITAL     CBS.CBS_MUSTERI_GUNCELLENEN.DECLARED_SHARE_CAPITAL%TYPE, 
                                         P_OLD_SHARE_CAPITAL_CURRENCY     CBS.CBS_MUSTERI_GUNCELLENEN.SHARE_CAPITAL_CURRENCY%TYPE,
                                         P_OLD_PAID_SHARE_CAPITAL         CBS.CBS_MUSTERI_GUNCELLENEN.PAID_SHARE_CAPITAL%TYPE,
                                         P_OLD_PDL_CODE                   CBS.CBS_MUSTERI_GUNCELLENEN.PDL_CODE%TYPE,
                                         P_OLD_BIRTH_CERTIFICATE          CBS.CBS_MUSTERI_GUNCELLENEN.BIRTH_CERTIFICATE%TYPE,
                                         P_OLD_COMPANY_NAME_KYR           CBS.CBS_MUSTERI_GUNCELLENEN.COMPANY_NAME_KYR%TYPE,
                                         P_OLD_OPF_ID_CODE                CBS.CBS_MUSTERI_GUNCELLENEN.OPF_ID_CODE%TYPE);
                                      --EOM AntonPa CBS-395 271022

    PROCEDURE Sp_Log_Musteri_Adres_Guncel(ps_table_name                VARCHAR2,
                                          p_new_adres_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.adres_kod%TYPE,
                                          --p_new_adres                  CBS.CBS_MUSTERI_GUNCEL_ADRES.adres%TYPE
                                          p_new_semt                   CBS.CBS_MUSTERI_GUNCEL_ADRES.semt%TYPE,
                                          p_new_il_kod                 CBS.CBS_MUSTERI_GUNCEL_ADRES.il_kod%TYPE,
                                          p_new_posta_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.posta_kod%TYPE,
                                          p_new_ulke_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ulke_kod%TYPE,
                                          p_new_email                  CBS.CBS_MUSTERI_GUNCEL_ADRES.email%TYPE,
                                          p_new_tel_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_alan_kod%TYPE,
                                          p_new_tel_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_no%TYPE,
                                          p_new_gsm_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_alan_kod%TYPE,
                                          p_new_gsm_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_no%TYPE,
                                          p_new_fax_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_alan_kod%TYPE,
                                          p_new_fax_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_no%TYPE,
                                          p_new_ilk_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.ilk_gecerlilik_tarihi%TYPE,
                                          p_new_son_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.son_gecerlilik_tarihi%TYPE,
                                          p_new_ilce_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ilce_kod%TYPE,
                                          p_new_isyeri_unvani          CBS.CBS_MUSTERI_GUNCEL_ADRES.ISYERI_UNVANI%TYPE,
                                        --BOM AntonPa CBS-395 271022
                                          P_NEW_REGION_CODE            CBS.CBS_MUSTERI_GUNCEL_ADRES.REGION_CODE%TYPE,
                                          P_NEW_DISTRICT_CODE          CBS.CBS_MUSTERI_GUNCEL_ADRES.DISTRICT_CODE%TYPE,
                                          P_NEW_SETTLEMENT_CODE        CBS.CBS_MUSTERI_GUNCEL_ADRES.SETTLEMENT_CODE%TYPE,
                                          P_NEW_VILLAGE_CODE           CBS.CBS_MUSTERI_GUNCEL_ADRES.VILLAGE_CODE%TYPE,
                                          P_NEW_DIGITAL_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.DIGITAL_ADDRESS%TYPE,
                                          P_NEW_IS_SAME_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.IS_SAME_ADDRESS%TYPE,
                                          P_NEW_ADDRESS_STREET         CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_STREET%TYPE,
                                          P_NEW_ADDRESS_HOUSE_NO       CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_HOUSE_NO%TYPE,
                                          P_NEW_ADDRESS_APARTMENT_NO   CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_APARTMENT_NO%TYPE,
                                          P_NEW_WEBSITE                CBS.CBS_MUSTERI_GUNCEL_ADRES.WEBSITE%TYPE,
                                        --EOM AntonPa CBS-395 271022
                                          p_old_adres_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.adres_kod%TYPE,
                                          --p_old_adres                  CBS.CBS_MUSTERI_GUNCEL_ADRES.adres%TYPE,
                                          p_old_semt                   CBS.CBS_MUSTERI_GUNCEL_ADRES.semt%TYPE,
                                          p_old_il_kod                 CBS.CBS_MUSTERI_GUNCEL_ADRES.il_kod%TYPE,
                                          p_old_posta_kod              CBS.CBS_MUSTERI_GUNCEL_ADRES.posta_kod%TYPE,
                                          p_old_ulke_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ulke_kod%TYPE,
                                          p_old_email                  CBS.CBS_MUSTERI_GUNCEL_ADRES.email%TYPE,
                                          p_old_tel_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_alan_kod%TYPE,
                                          p_old_tel_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.tel_no%TYPE,
                                          p_old_gsm_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_alan_kod%TYPE,
                                          p_old_gsm_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.gsm_no%TYPE,
                                          p_old_fax_alan_kod           CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_alan_kod%TYPE,
                                          p_old_fax_no                 CBS.CBS_MUSTERI_GUNCEL_ADRES.fax_no%TYPE,
                                          p_old_ilk_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.ilk_gecerlilik_tarihi%TYPE,
                                          p_old_son_gecerlilik_tarihi  CBS.CBS_MUSTERI_GUNCEL_ADRES.son_gecerlilik_tarihi%TYPE,
                                          p_old_ilce_kod               CBS.CBS_MUSTERI_GUNCEL_ADRES.ilce_kod%TYPE,
                                          p_old_isyeri_unvani          CBS.CBS_MUSTERI_GUNCEL_ADRES.ISYERI_UNVANI%TYPE,
                                        --BOM AntonPa CBS-395 271022
                                          P_OLD_REGION_CODE            CBS.CBS_MUSTERI_GUNCEL_ADRES.REGION_CODE%TYPE,
                                          P_OLD_DISTRICT_CODE          CBS.CBS_MUSTERI_GUNCEL_ADRES.DISTRICT_CODE%TYPE,
                                          P_OLD_SETTLEMENT_CODE        CBS.CBS_MUSTERI_GUNCEL_ADRES.SETTLEMENT_CODE%TYPE,
                                          P_OLD_VILLAGE_CODE           CBS.CBS_MUSTERI_GUNCEL_ADRES.VILLAGE_CODE%TYPE,
                                          P_OLD_DIGITAL_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.DIGITAL_ADDRESS%TYPE,
                                          P_OLD_IS_SAME_ADDRESS        CBS.CBS_MUSTERI_GUNCEL_ADRES.IS_SAME_ADDRESS%TYPE,
                                          P_OLD_ADDRESS_STREET         CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_STREET%TYPE,
                                          P_OLD_ADDRESS_HOUSE_NO       CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_HOUSE_NO%TYPE,
                                          P_OLD_ADDRESS_APARTMENT_NO   CBS.CBS_MUSTERI_GUNCEL_ADRES.ADDRESS_APARTMENT_NO%TYPE,
                                          P_OLD_WEBSITE                CBS.CBS_MUSTERI_GUNCEL_ADRES.WEBSITE%TYPE,
                                        --EOM AntonPa CBS-395 271022
                                          pn_tx_no                     CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE);

    PROCEDURE Sp_Log_Musteri_Notlar_Guncel(ps_table_name           VARCHAR2,
                                           p_new_not_tipi          CBS.CBS_MUSTERI_GUNCEL_NOTLAR.not_tipi%TYPE,
                                           p_new_ALINAN_NOTLAR     CBS.CBS_MUSTERI_GUNCEL_NOTLAR.ALINAN_NOTLAR%TYPE,
                                           p_new_GIRIS_TARIHI      CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GIRIS_TARIHI%TYPE,
                                           p_new_KULLANICI_KODU    CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KULLANICI_KODU%TYPE,
                                           p_new_GORUSME_BILGILERI CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_BILGILERI%TYPE,
                                           p_new_GORUSME_NOTU      CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_NOTU%TYPE,
                                           p_new_KATILANLAR        CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KATILANLAR%TYPE,
                                           p_new_GORUSME_TARIHI    CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_TARIHI%TYPE,
                                           p_new_BASLANGIC_SAATI   CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BASLANGIC_SAATI%TYPE,
                                           p_new_BITIS_SAATI       CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BITIS_SAATI%TYPE,
                                           p_old_not_tipi          CBS.CBS_MUSTERI_GUNCEL_NOTLAR.not_tipi%TYPE,
                                           p_old_ALINAN_NOTLAR     CBS.CBS_MUSTERI_GUNCEL_NOTLAR.ALINAN_NOTLAR%TYPE,
                                           p_old_GIRIS_TARIHI      CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GIRIS_TARIHI%TYPE,
                                           p_old_KULLANICI_KODU    CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KULLANICI_KODU%TYPE,
                                           p_old_GORUSME_BILGILERI CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_BILGILERI%TYPE,
                                           p_old_GORUSME_NOTU      CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_NOTU%TYPE,
                                           p_old_KATILANLAR        CBS.CBS_MUSTERI_GUNCEL_NOTLAR.KATILANLAR%TYPE,
                                           p_old_GORUSME_TARIHI    CBS.CBS_MUSTERI_GUNCEL_NOTLAR.GORUSME_TARIHI%TYPE,
                                           p_old_BASLANGIC_SAATI   CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BASLANGIC_SAATI%TYPE,
                                           p_old_BITIS_SAATI       CBS.CBS_MUSTERI_GUNCEL_NOTLAR.BITIS_SAATI%TYPE,
                                           pn_tx_no                CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE,
                                           pn_sira_no              CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.sira_no%TYPE);

    PROCEDURE Sp_Log_Musteri_Dokuman_Guncel(ps_table_name           VARCHAR2,
                                            p_new_DOKUMAN_ADI       CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DOKUMAN_ADI%TYPE,
                                            p_new_ALINDI_KUTUSU_F   CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.ALINDI_KUTUSU_F%TYPE,
                                            p_new_DUZENLENME_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DUZENLENME_TARIHI%TYPE,
                                            p_new_GECERLILIK_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.GECERLILIK_TARIHI%TYPE,
                                            p_old_DOKUMAN_ADI       CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DOKUMAN_ADI%TYPE,
                                            p_old_ALINDI_KUTUSU_F   CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.ALINDI_KUTUSU_F%TYPE,
                                            p_old_DUZENLENME_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.DUZENLENME_TARIHI%TYPE,
                                            p_old_GECERLILIK_TARIHI CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.GECERLILIK_TARIHI%TYPE,
                                            pn_tx_no                CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE,
                                            pn_sira_no              CBS.CBS_MUSTERI_GUNCEL_DOKUMAN.sira_no%TYPE);

    PROCEDURE Sp_Log_Musteri_Ortaklik_Guncel(ps_table_name    VARCHAR2,
                                             P_NEW_FIRST_NAME                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.FIRST_NAME%TYPE,
                                             P_NEW_OWNERSHIP                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OWNERSHIP%TYPE,
                                             P_NEW_BIRTH_DATE                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BIRTH_DATE%TYPE,
                                             P_NEW_CITIZEN_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CITIZEN_CODE%TYPE,
                                             P_NEW_BENEFICIARY_TYPE           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_TYPE%TYPE,
                                             P_NEW_CUSTOMER_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_CUSTOMER_NO%TYPE,
                                             P_NEW_COMPANY_INN                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_INN%TYPE,
                                             P_NEW_BENEFICIARY_INN            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_INN%TYPE,
                                             P_NEW_SURNAME                    CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SURNAME%TYPE,
                                             P_NEW_SECOND_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SECOND_NAME%TYPE,
                                             P_NEW_GENDER_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.GENDER_CODE%TYPE,
                                             P_NEW_PASSPORT_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PASSPORT_NO%TYPE,
                                             P_NEW_VALIDITY_DATE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VALIDITY_DATE%TYPE,
                                             P_NEW_ISSUED_BY                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ISSUED_BY%TYPE,
                                             P_NEW_STREET_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.STREET_NAME%TYPE,
                                             P_NEW_HOUSE_NO                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.HOUSE_NO%TYPE,
                                             P_NEW_APARTMENT_NO               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.APARTMENT_NO%TYPE,
                                             P_NEW_REGION_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.REGION_CODE%TYPE,
                                             P_NEW_DISTRICT_CODE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.DISTRICT_CODE%TYPE,
                                             P_NEW_SETTLEMENT_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SETTLEMENT_CODE%TYPE,
                                             P_NEW_VILLAGE_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VILLAGE_CODE%TYPE,
                                             P_NEW_ADDRESS_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ADDRESS_CODE%TYPE,
                                             P_NEW_RISK_LEVEL_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.RISK_LEVEL_CODE%TYPE,
                                             P_NEW_PDL_CODE                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PDL_CODE%TYPE,
                                             P_NEW_COMPANY_NAME_RUS           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_RUS%TYPE,
                                             P_NEW_COMPANY_NAME_ENG           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_ENG%TYPE,
                                             P_NEW_COMPANY_NAME_KYR           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_KYR%TYPE,
                                             P_NEW_TAX_REG_DATE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_DATE%TYPE,
                                             P_NEW_TAX_REG_AUTHORITY          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_AUTHORITY%TYPE,
                                             P_NEW_TAX_REG_COUNTRY_CODE       CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_COUNTRY_CODE%TYPE,
                                             P_NEW_TAX_REG_STATE_NO           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_STATE_NO%TYPE,
                                             P_NEW_LEGAL_FORM_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.LEGAL_FORM_CODE%TYPE,
                                             P_NEW_CIVIL_STATUS_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CIVIL_STATUS_CODE%TYPE,
                                             P_NEW_CAPITAL_PARTICIPATION_CODE CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CAPITAL_PARTICIPATION_CODE%TYPE,
                                             P_NEW_CONTROL_FORM_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CONTROL_FORM_CODE%TYPE,
                                             P_NEW_TAX_RE_REG_DATE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_RE_REG_DATE%TYPE,
                                             P_NEW_OPF_ID_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OPF_ID_CODE%TYPE,              
                                             P_OLD_FIRST_NAME                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.FIRST_NAME%TYPE,
                                             P_OLD_OWNERSHIP                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OWNERSHIP%TYPE,
                                             P_OLD_BIRTH_DATE                 CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BIRTH_DATE%TYPE,
                                             P_OLD_CITIZEN_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CITIZEN_CODE%TYPE,
                                             P_OLD_BENEFICIARY_TYPE           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_TYPE%TYPE,
                                             P_OLD_CUSTOMER_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_CUSTOMER_NO%TYPE,
                                             P_OLD_COMPANY_INN                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_INN%TYPE,
                                             P_OLD_BENEFICIARY_INN            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.BENEFICIARY_INN%TYPE,
                                             P_OLD_SURNAME                    CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SURNAME%TYPE,
                                             P_OLD_SECOND_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SECOND_NAME%TYPE,
                                             P_OLD_GENDER_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.GENDER_CODE%TYPE,
                                             P_OLD_PASSPORT_NO                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PASSPORT_NO%TYPE,
                                             P_OLD_VALIDITY_DATE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VALIDITY_DATE%TYPE,
                                             P_OLD_ISSUED_BY                  CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ISSUED_BY%TYPE,
                                             P_OLD_STREET_NAME                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.STREET_NAME%TYPE,
                                             P_OLD_HOUSE_NO                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.HOUSE_NO%TYPE,
                                             P_OLD_APARTMENT_NO               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.APARTMENT_NO%TYPE,
                                             P_OLD_REGION_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.REGION_CODE%TYPE,
                                             P_OLD_DISTRICT_CODE              CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.DISTRICT_CODE%TYPE,
                                             P_OLD_SETTLEMENT_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.SETTLEMENT_CODE%TYPE,
                                             P_OLD_VILLAGE_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.VILLAGE_CODE%TYPE,
                                             P_OLD_ADDRESS_CODE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.ADDRESS_CODE%TYPE,
                                             P_OLD_RISK_LEVEL_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.RISK_LEVEL_CODE%TYPE,
                                             P_OLD_PDL_CODE                   CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.PDL_CODE%TYPE,
                                             P_OLD_COMPANY_NAME_RUS           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_RUS%TYPE,
                                             P_OLD_COMPANY_NAME_ENG           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_ENG%TYPE,
                                             P_OLD_COMPANY_NAME_KYR           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.COMPANY_NAME_KYR%TYPE,
                                             P_OLD_TAX_REG_DATE               CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_DATE%TYPE,
                                             P_OLD_TAX_REG_AUTHORITY          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_AUTHORITY%TYPE,
                                             P_OLD_TAX_REG_COUNTRY_CODE       CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_COUNTRY_CODE%TYPE,
                                             P_OLD_TAX_REG_STATE_NO           CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_REG_STATE_NO%TYPE,
                                             P_OLD_LEGAL_FORM_CODE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.LEGAL_FORM_CODE%TYPE,
                                             P_OLD_CIVIL_STATUS_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CIVIL_STATUS_CODE%TYPE,
                                             P_OLD_CAPITAL_PARTICIPATION_CODE CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CAPITAL_PARTICIPATION_CODE%TYPE,
                                             P_OLD_CONTROL_FORM_CODE          CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.CONTROL_FORM_CODE%TYPE,
                                             P_OLD_TAX_RE_REG_DATE            CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.TAX_RE_REG_DATE%TYPE,
                                             P_OLD_OPF_ID_CODE                CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS.OPF_ID_CODE%TYPE,
                                             pn_tx_no                         CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE);  --CBS-395 AntonPa 271022

    PROCEDURE Sp_Musteri_Kaydi_Olustur(pn_tx_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE, pn_musteri_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE);

    PROCEDURE Sp_Musteri_Guncel_Kaydi_Olus(pn_musteri_no     CBS.CBS_MUSTERI_GUNCELLENEN.musteri_no%TYPE,
                                           pn_tx_no      OUT CBS.CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE,
                                           ps_durum          VARCHAR2 DEFAULT 'A');

    PROCEDURE Sp_Musteriyi_Guncelle(pn_tx_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE, pn_musteri_no CBS.CBS_MUSTERI_BASVURU.musteri_no%TYPE);

    PROCEDURE Sp_Musteri_No_Bul(ps_full_isim     VARCHAR2,
                                ps_unvan         VARCHAR2,
                                ps_musteri_tipi  VARCHAR2,
                                ps_yerlesim_kod  VARCHAR2,
                                ps_baba_adi      CBS.CBS_MUSTERI.baba_adi%TYPE,
                                pd_dogum_tarihi  CBS.CBS_MUSTERI.dogum_tarihi%TYPE,
                                ps_dogum_yeri    CBS.CBS_MUSTERI.dogum_yeri%TYPE,
                                pn_musteri_no    OUT CBS.CBS_MUSTERI.musteri_no%TYPE,
                                ps_kimlik_id     CBS.CBS_MUSTERI.KIMLIK_KOD%TYPE,
                                ps_kimlik_no     VARCHAR2,
                                ps_vergi_no      VARCHAR2,
                                ps_vergi_daire   VARCHAR2,
                                ps_full_isim_eng VARCHAR2 DEFAULT NULL);

    PROCEDURE Sp_Musteri_Adres(pn_musteri_no     CBS.CBS_MUSTERI.musteri_no%TYPE,
                               ps_adres      OUT CBS.CBS_MUSTERI_ADRES.adres%TYPE,
                               ps_semt       OUT CBS.CBS_MUSTERI_ADRES.semt%TYPE,
                               ps_il_kod     OUT CBS.CBS_MUSTERI_ADRES.il_kod%TYPE,
                               pn_posta_kod  OUT CBS.CBS_MUSTERI_ADRES.posta_kod%TYPE,
                               ps_ulke_kod   OUT CBS.CBS_MUSTERI_ADRES.ulke_kod%TYPE);

    FUNCTION Sf_Personel_Adi(pn_personel_no CBS.CBS_PERSONEL.personel_numara%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Musteri_Adi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Dk_Grup_Adi(pn_dk_grup_kodu CBS.CBS_MUSTERI.dk_grup_kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Musteri_Tipi_Adi(ps_musteri_tipi_kodu CBS.CBS_MUSTERI.musteri_tipi_kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Yerlesim_Adi(ps_yerlesim_kodu CBS.CBS_MUSTERI.yerlesim_kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Meslek_Adi(ps_meslek_kodu CBS.CBS_MUSTERI.meslek_kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Egitim_Adi(ps_egitim_kodu CBS.CBS_MUSTERI.egitim_kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Ozel_Kategori_Adi(ps_ozel_kategori_kodu CBS.CBS_MUSTERI.ozel_kategori_kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Tesvik_Adi(ps_tesvik_kodu CBS.CBS_MUSTERI.tesvik_kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Cek_Karnesi_Istiyormu(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_PersonelSicilNoAl(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN NUMBER;

    FUNCTION Sf_Medeni_Hal_Adi(ps_medeni_hal_kodu CBS.CBS_MEDENI_HAL_KODLARI.medeni_hal_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Sektor_Adi(pn_sektor_kod CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Kimlik_Adi(ps_kimlik_kod CBS.CBS_KIMLIK_KODLARI.kimlik_tipi%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Adres_Tip_Adi(ps_adres_tipi CBS.CBS_ADRES_KODLARI.adres_tipi%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Vergi_Muaf_Adi(pn_vergi_muaf_kodu CBS.CBS_VERGI_MUAF_KODLARI.vergi_muaf_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Grup_Adi(ps_grup_kodu CBS.CBS_GRUP_KODLARI.grup_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Finans_Adi(ps_finans_kodu CBS.CBS_FINANS_KODLARI.finans_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Reuters_Dealing_Adi(pn_reuters_dealing_kodu CBS.CBS_REUTERS_DEALING_KODLARI.kod%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Cinsiyet_Adi(ps_cinsiyet_kodu CBS.CBS_CINSIYET_KODLARI.cinsiyet_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Musterinin_Hesabi_Varmi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN NUMBER;

    FUNCTION Sf_Adresi_Varmi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE, ps_adres_kod CBS.CBS_MUSTERI_ADRES.adres_kod%TYPE) RETURN NUMBER;

    FUNCTION Sf_Guncel_Girilen_Adresi_Varmi(pn_tx_no CBS.CBS_MUSTERI_GUNCEL_ADRES.adres_kod%TYPE, ps_adres_kod CBS.CBS_MUSTERI_ADRES.adres_kod%TYPE) RETURN NUMBER;

    FUNCTION Sf_Musteri_Kodu_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.durum_kodu%TYPE;

    FUNCTION Sf_DkGrupKodunun_YerlesiTipiAl(ps_dk_grup_kodu CBS.CBS_DK_GRUP_KODLARI.dk_grup_kodu%TYPE) RETURN CBS.CBS_DK_GRUP_KODLARI.yerlesim_tipi%TYPE;

    FUNCTION Sf_Personel_mi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2;

    PROCEDURE sp_musteri_urun_sinif_al(pn_musteri_no         CBS.CBS_MUSTERI.musteri_no%TYPE, 
                                       ps_modul_tur_kod  OUT CBS.CBS_MUSTERI.modul_tur_kod%TYPE, 
                                       ps_urun_tur_kod   OUT CBS.CBS_MUSTERI.urun_tur_kod%TYPE, 
                                       ps_urun_sinif_kod OUT CBS.CBS_MUSTERI.urun_sinif_kod%TYPE);

    FUNCTION sf_musteri_urun_sinif_al(ps_modul_tur_kod   CBS.CBS_MUSTERI.modul_tur_kod%TYPE,
                                      ps_urun_tur_kod    CBS.CBS_MUSTERI.urun_tur_kod%TYPE,
                                      ps_sinif_param_kod VARCHAR2 DEFAULT NULL) RETURN CBS.CBS_MUSTERI.urun_sinif_kod%TYPE;

    FUNCTION sf_personel_tanimlimi(pn_personel_no CBS.CBS_MUSTERI.personel_sicil_no%TYPE) RETURN VARCHAR2;

    FUNCTION sf_kullanicinin_musterino_al(ps_kullanici_kodu CBS.CBS_KULLANICI.kodu%TYPE) RETURN CBS.CBS_MUSTERI.musteri_no%TYPE;

    FUNCTION sf_personel_musterino_al(ps_personel_numara CBS.CBS_PERSONEL.personel_numara%TYPE) RETURN CBS.CBS_MUSTERI.musteri_no%TYPE;

    PROCEDURE sp_personel_musterino_guncelle(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE, pn_sicil_no CBS.CBS_MUSTERI.personel_sicil_no%TYPE DEFAULT NULL);

    FUNCTION Sf_VergiNo_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.vergi_no%TYPE;

    FUNCTION Sf_UyrukKod_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.uyruk_kod%TYPE;

    PROCEDURE sp_musteri_sektor_grup_al(pn_musteri_no     CBS.CBS_MUSTERI.musteri_no%TYPE,
                                        pn_sektor_kod OUT CBS.CBS_MUSTERI.sektor_kod%TYPE,
                                        ps_grup_kod   OUT CBS.CBS_MUSTERI.grup_kod%TYPE);

    PROCEDURE sp_musteri_grubu_guncelle(pn_musteri_no NUMBER, ps_grup_kodu CBS.CBS_GRUP_KODLARI.grup_kodu%TYPE);

    PROCEDURE Sp_Musteri_DkGrup_Yerlesim_Al(pn_musteri_no       CBS.CBS_MUSTERI.musteri_no%TYPE,
                                            ps_dk_grup_kod  OUT CBS.CBS_MUSTERI.dk_grup_kod%TYPE,
                                            ps_yerlesim_kod OUT CBS.CBS_MUSTERI.yerlesim_kod%TYPE);

    FUNCTION sf_musteri_dk_grup_kod_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.dk_grup_kod%TYPE;

    FUNCTION sf_musteri_tipi_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.musteri_tipi_kod%TYPE;

    FUNCTION Sf_Sektor_Alt1_Kod_Adi(pn_sektor_kod CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE, ps_sektor_alt1_kodu  CBS.CBS_SEKTOR_ALT1_KODLARI.SEKTOR_ALT1_KODU%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Sektor_Alt2_Kod_Adi(pn_sektor_kod        CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE,
                                    ps_sektor_alt1_kodu  CBS.CBS_SEKTOR_ALT1_KODLARI.SEKTOR_ALT1_KODU%TYPE,
                                    ps_sektor_alt2_kodu  CBS.CBS_SEKTOR_ALT2_KODLARI.SEKTOR_ALT2_KODU%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Sektor_Alt1_Kod_Varmi(pn_sektor_kod CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_Sektor_Alt2_Kod_Varmi(pn_sektor_kod CBS.CBS_SEKTOR_KODLARI.sektor_kodu%TYPE, ps_sektor_alt1_kodu CBS.CBS_SEKTOR_ALT1_KODLARI.SEKTOR_ALT1_KODU%TYPE) RETURN VARCHAR2;

    FUNCTION sf_rating_kod_aciklama_al(ps_rating_kodu CBS.CBS_MUSTERI.rating_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION sf_yerlesim_kod_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.yerlesim_kod%TYPE;

    FUNCTION sf_adres_al(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION Sf_Bagli_Musteri_Grup_Adi(ps_grup_kodu CBS.CBS_BAGLI_MUSTERI_GRUPLARI.grup_kodu%TYPE) RETURN VARCHAR2;

    FUNCTION Sf_VergiDairesi_Al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.VERGI_DAIRESI_ADI%TYPE;

    FUNCTION resident_kod(pn_residency_code NUMBER) RETURN NUMBER;

    FUNCTION TaxNumberControl(ps_taxnumber VARCHAR2) RETURN NUMBER;

    FUNCTION sf_telefon_al(pn_musteri_no NUMBER) RETURN NUMBER;

    FUNCTION sf_kimlik_veren_yer(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION sf_kimlik_verildigi_tarih(pn_musteri_no NUMBER) RETURN DATE;

    FUNCTION sf_bolum_kodu_al(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN CBS.CBS_MUSTERI.bolum_kodu%TYPE;

    --CLEARING ICIN KEREKLI :Levent Aysan
    FUNCTION sf_OKPO_al(pn_musteri_no NUMBER) RETURN CBS.CBS_MUSTERI.OKPO_CODE%TYPE;

    FUNCTION sf_SOSYAL_FON_NO_al(pn_musteri_no NUMBER) RETURN CBS.CBS_MUSTERI.SOSYAL_FON_NO%TYPE;

    FUNCTION musteri_vergiden_muafmi(pn_musteri NUMBER) RETURN VARCHAR2;

    FUNCTION musteri_kimlik_kodu_al(pn_musteri NUMBER) RETURN VARCHAR2;

    FUNCTION sf_musteri_urun_tur_al(ps_musteri_tipi_kod VARCHAR2) RETURN VARCHAR2;

    FUNCTION sf_legal_form_code_Ad_al(pn_legal_Form_code NUMBER) RETURN VARCHAR2;

    FUNCTION sf_lokal_ad_al(pn_musteri_no NUMBER) RETURN VARCHAR2;

    --------------------------------------------------------------
    -- payment kod ile igili fonk. ilaveleridir. 260507
    FUNCTION branch_of_economy_kod_al(pn_musteri_no NUMBER) RETURN NUMBER;

    FUNCTION paymentkod_formatli_al(pn_musteri_no NUMBER, ps_istatistik_kod VARCHAR2) RETURN VARCHAR2;

    FUNCTION old_bic_Account_no(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION Report_Customer_Type(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION Sf_Risk_Level_Desc(ps_risk_level_code CBS.CBS_MUSTERI.RISK_LEVEL_CODE%TYPE) RETURN VARCHAR2;

    --B-O-M sevalb 11122012 6270_Automatic loading of customer information from CBS to Card system
    FUNCTION sf_finans_kod_al(pn_musteri_no NUMBER) RETURN VARCHAR2;

    PROCEDURE sp_lokal_isim_parse_et(pn_musteri_no NUMBER, ps_isim_eng OUT VARCHAR2, ps_ikinci_isim_eng OUT VARCHAR2, ps_soyadi_Eng OUT VARCHAR2);

    FUNCTION sf_parse_isim_eng_from_lokal(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION sf_parse_isim2_eng_from_lokal(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION sf_parse_soyadi_eng_from_lokal(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION sf_isim_eng_al(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION sf_ikinci_isim_eng_al(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION sf_soyadi_eng_al(pn_musteri_no NUMBER) RETURN VARCHAR2;

    FUNCTION Sf_Musteri_Eng_Adi(pn_musteri_no CBS.CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2;

    --E-O-M sevalb 11122012 6270_Automatic loading of customer information from CBS to Card system
    --BOM CQ5273 MederT 23122015
    FUNCTION Sf_count_campus_id(pn_musteri_no NUMBER, pn_university_code NUMBER, pn_campus_id_no VARCHAR2) RETURN NUMBER;

    --EOM CQ5273 MederT 23122015
    --BOM CQ5516 aisuluud 21112016
    FUNCTION sf_document_type_name(ps_document_type_code VARCHAR2, ps_customer_type VARCHAR2) RETURN VARCHAR2;

    --EOM CQ5516 aisuluud 21112016

    PROCEDURE sp_Get_NameSurname_Separately(pn_customer_no NUMBER, ps_name IN OUT VARCHAR2, ps_midname IN OUT VARCHAR2, ps_last_name IN OUT VARCHAR2); --CQ5627 KonstantinZ 28102016

    PROCEDURE sp_Get_EngName_Separately(pn_customer_no IN NUMBER, ps_name IN OUT VARCHAR2, ps_midname IN OUT VARCHAR2, ps_last_name IN OUT VARCHAR2); --CQ5627 KonstantinZ 28102016

    FUNCTION sf_get_residency_code(pn_musteri_no NUMBER) RETURN VARCHAR2; --KonstantinJ CQ5514

    FUNCTION sf_get_citizenship_country(pn_musteri_no NUMBER) RETURN VARCHAR2; -- KonstantinJ CQ5514

    -- CBS.cbs_tx1000, 1001 begimai CQ6006
    FUNCTION sf_get_musteri_no(lc_isim VARCHAR2, lc_soyadi VARCHAR2, ld_dogum_tarihi DATE, ln_vergi_no VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER) RETURN VARCHAR2;

    FUNCTION sf_get_musteri_no_1(lc_isim VARCHAR2, lc_soyadi VARCHAR2, ld_dogum_tarihi DATE, ln_pasaport_no VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER) RETURN VARCHAR2;

    FUNCTION sf_get_musteri_no_2(ln_okpo_code VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER) RETURN VARCHAR2;

    FUNCTION sf_get_musteri_no_3(lc_ticari_unvan VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER) RETURN VARCHAR2;

    FUNCTION sf_string_matches(lc_ticari_unvan VARCHAR2, ln_musteri_tipi_kod VARCHAR2, ln_dk_grup_kod NUMBER) RETURN NUMBER;

    -- CBS.cbs_tx1000, 1001 begimai CQ6006
    FUNCTION getCheckTaxId(p_tax_id VARCHAR2, p_customer_type_code VARCHAR2 DEFAULT NULL, p_customer_gender VARCHAR2 DEFAULT NULL) RETURN VARCHAR2; -- MaratM CBS-258

    PROCEDURE issue_date_control(pn_issue_date DATE); -- NurmilaZ CBS-307

    PROCEDURE validity_date_control(pn_validity_date DATE); -- NurmilaZ CBS-307

    FUNCTION SF_MUSTERI_ADI_FOR_FORMS(ps_musteri_tipi_kod CBS.cbs_musteri.musteri_tipi_kod%TYPE, 
                                      ps_isim             CBS.cbs_musteri.isim%TYPE, 
                                      ps_ikinci_isim      CBS.cbs_musteri.ikinci_isim%TYPE, 
                                      ps_soyadi           CBS.cbs_musteri.soyadi%TYPE, 
                                      ps_ticari_unvan     VARCHAR2) RETURN VARCHAR2; -- VITEK DBA

    FUNCTION getTranslit(p_text IN VARCHAR2) RETURN VARCHAR2; -- MaratM CBS-258

    PROCEDURE checkDuplicateTaxId(p_customer_type_code IN VARCHAR2, p_dk_group_code IN NUMBER, p_tax_id IN VARCHAR2, p_yerlesim_kod VARCHAR2); -- MaratM CBS-258 --YadgarB CBS-258 added p_yerlesim_kod

    PROCEDURE checkDuplicateOKPO(p_okpo_code VARCHAR2, p_musteri_tipi_kod VARCHAR2); -- MaratM CBS-258 --YadgarB CBS-258 added p_musteri_tipi_kod

    PROCEDURE check_duplicate_corp_nonres(p_nation_code VARCHAR2, p_company_name VARCHAR2, p_reg_no VARCHAR2 DEFAULT NULL, p_musteri_no NUMBER DEFAULT NULL); -- MaratM CBS-258

    FUNCTION check_duplicate_reg_no(p_musteri_tipi_kod     VARCHAR2, 
                                    p_vat_seri_no       IN VARCHAR2, 
                                    p_sosyal_fon_no     IN VARCHAR2, 
                                    p_old_vat_seri_no      VARCHAR2 DEFAULT NULL, 
                                    p_old_sosyal_fon_no    VARCHAR2 DEFAULT NULL, 
                                    p_yerlesim_kod         VARCHAR2) RETURN NUMBER; -- MaratM CBS-258 --YadgarB CBS-258 added p_yerlesim_kod

    FUNCTION getDuplicateCustomer(p_musteri_tipi_kod IN CBS.CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE, 
                                  name               IN CBS.CBS_MUSTERI.isim%TYPE, 
                                  surname            IN CBS.CBS_MUSTERI.soyadi%TYPE, 
                                  birth_day          IN CBS.CBS_MUSTERI.dogum_tarihi%TYPE, 
                                  p_uyruk_kod        IN CBS.CBS_MUSTERI.uyruk_kod%TYPE, 
                                  p_second_name      IN CBS.CBS_MUSTERI.IKINCI_ISIM%TYPE,
                                  p_sex_code         IN CBS.CBS_MUSTERI.CINSIYET_KOD%TYPE) RETURN SYS_REFCURSOR;

    PROCEDURE checkDuplicateCustomer(p_musteri_tipi_kod IN CBS.CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE,
                                     p_name                CBS.CBS_MUSTERI.isim%TYPE,
                                     surname            IN CBS.CBS_MUSTERI.SOYADI%TYPE,
                                     birth_day          IN CBS.CBS_MUSTERI.DOGUM_TARIHI%TYPE,
                                     p_uyruk_kod        IN CBS.CBS_MUSTERI.UYRUK_KOD%TYPE,
                                     p_second_name      IN CBS.CBS_MUSTERI.IKINCI_ISIM%TYPE DEFAULT NULL,
                                     p_sex_code         IN CBS.CBS_MUSTERI.CINSIYET_KOD%TYPE DEFAULT NULL,
                                     p_musteri_no          NUMBER DEFAULT NULL); --MaratM CBS-258

    FUNCTION get_number_not_zero_accounts(p_customer_no NUMBER) RETURN NUMBER; -- MaratM CBS-258

    FUNCTION get_customer_by_taxid(p_tax_id IN CBS.CBS_MUSTERI.VERGI_NO%TYPE) RETURN VARCHAR2; --YadgarB CBS-258
    
    FUNCTION GET_NAME_BY_CODE(PN_CODE NUMBER, PN_TABLE_NO NUMBER) RETURN VARCHAR2; --CBS-395 AntonPa 27102022
    
    PROCEDURE GET_ECONOMIC_ACTIVITY_EXPL(PS_CODE VARCHAR2,
                                         PS_EXPL OUT VARCHAR2,
                                         PS_SUB_EXPL OUT VARCHAR2);  --CBS-395 AntonPa 27102022
                                            
    PROCEDURE GET_INFO_FROM_DIGITAL_ADDRESS(PS_CODE IN VARCHAR2,
                                            PS_REGION_NAME OUT VARCHAR2,
                                            PS_DISTRICT_NAME OUT VARCHAR2,
                                            PS_SETTLEMENT_NAME OUT VARCHAR2,
                                            PS_VILLAGE_NAME OUT VARCHAR2); --CBS-395 AntonPa 27102022
                                            
    FUNCTION GET_ACTIVITY_TYPE_BY_CODE(PS_CODE VARCHAR2) RETURN VARCHAR2; --CBS-395 AntonPa 27102022
    
    FUNCTION GET_ECONOMY_SECTOR_BY_CODE(PN_GL_GRUP NUMBER, PN_CODE NUMBER) RETURN VARCHAR2; --CBS-395 AntonPa 27102022
    
    PROCEDURE SP_LOG_CUSTOMER_UPD_LICENSES(PS_TABLE_NAME       VARCHAR2, 
                                           P_NEW_ACTIVITY_CODE CBS.CBS_CUSTOMER_LICENSES.ACTIVITY_CODE%TYPE,
                                           P_NEW_LICENSE_NO    CBS.CBS_CUSTOMER_LICENSES.LICENSE_NO%TYPE,
                                           P_NEW_ISSUE_DATE    CBS.CBS_CUSTOMER_LICENSES.ISSUE_DATE%TYPE,
                                           P_NEW_ISSUED_BY     CBS.CBS_CUSTOMER_LICENSES.ISSUED_BY%TYPE,
                                           P_NEW_VALIDITY_DATE CBS.CBS_CUSTOMER_LICENSES.VALIDITY_DATE%TYPE,
                                           P_OLD_ACTIVITY_CODE CBS.CBS_CUSTOMER_LICENSES.ACTIVITY_CODE%TYPE,
                                           P_OLD_LICENSE_NO    CBS.CBS_CUSTOMER_LICENSES.LICENSE_NO%TYPE,
                                           P_OLD_ISSUE_DATE    CBS.CBS_CUSTOMER_LICENSES.ISSUE_DATE%TYPE,
                                           P_OLD_ISSUED_BY     CBS.CBS_CUSTOMER_LICENSES.ISSUED_BY%TYPE,
                                           P_OLD_VALIDITY_DATE CBS.CBS_CUSTOMER_LICENSES.VALIDITY_DATE%TYPE, 
                                           PN_TX_NO            CBS.CBS_MUSTERI_GUNCELLENEN.TX_NO%TYPE); --CBS-395 AntonPa 27102022
    
END PKG_MUSTERI;
/

