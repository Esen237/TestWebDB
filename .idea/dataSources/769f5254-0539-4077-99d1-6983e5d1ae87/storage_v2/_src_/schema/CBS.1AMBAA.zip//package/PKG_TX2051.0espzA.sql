create PACKAGE     Pkg_Tx2051 IS

  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54
  -- Purpose : Hesap G?ncelleme kullan?lacakt?r.

  PROCEDURE Yaratma_Oncesi(pn_islem_no NUMBER);         -- Islem giris kontrolden once cagrilir
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);         -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);        -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);            -- Islem iptal edildikten sonra cagrilir
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);            -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);        -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);            -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);          -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);            -- Islemin muhasebelesmesi icin cagrilir

  FUNCTION  sf_hesap_tur(ps_hesap_tur CBS_HESAP.MODUL_TUR_KOD%TYPE) RETURN VARCHAR2 ;
  FUNCTION  sf_modul_tur_kod(ps_modul_tur_kod CBS_URUN_TUR.modul_tur_kod%TYPE) RETURN VARCHAR2 ;
  FUNCTION sf_kod(ps_kod CBS_URUN_TUR.kod%TYPE) RETURN VARCHAR2 ;
  FUNCTION Referans_Uret (ps_bolum_kodu VARCHAR2 ) RETURN VARCHAR2 ;
  FUNCTION  sf_urun_sinif_al(ps_urun_sinif_kod CBS_URUN_SINIF.MODUL_TUR_KOD%TYPE) RETURN VARCHAR2 ;
  FUNCTION  sf_musteri_tipi_al(ps_musteri_tipi_kod CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE) RETURN VARCHAR2 ;
  FUNCTION  sf_durum_kodu_al(ps_durum_kodu CBS_HESAP.DURUM_KODU%TYPE) RETURN VARCHAR2;

END Pkg_Tx2051;

/

