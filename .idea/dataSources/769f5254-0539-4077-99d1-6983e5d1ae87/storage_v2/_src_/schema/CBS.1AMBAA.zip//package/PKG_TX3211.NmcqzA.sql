create PACKAGE Pkg_Tx3211 IS

  -- TX Event Listesi
  --?THALAT REFERANS ALIM

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		-- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		-- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);-- Islem iptal edildikten sonra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			-- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		-- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			-- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		-- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edilirse

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			-- Islemin muhasebelesmesi icin cagrilir

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip

END;


/

