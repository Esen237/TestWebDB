create package body     pkg_nbkr_xml_report 
is 
    function get_customer_list return varchar2_nt
    is 
        type customer_rt is record (
            BranchCode varchar2(10),
            CustomerNo number,
            ClientType varchar2(1),
            ClientNationality varchar2(100),
            ClientName varchar2(500),
            ClientSurname varchar2(500),
            ClientFathersName varchar2(500),
            ClientDateBirth date,
            ClientPlaceBirth varchar2(500),
            ClientIdType varchar2(1),
            ClientIdSerial varchar2(500),
            ClientIdNumber varchar2(500),
            ClientIdCertificate varchar2(500),
            ClientIdPin varchar2(500),
            ClientIdIssueDate date,
            ClientIdIssuePlace varchar2(500),
            ClientIdAdress varchar2(500),
            ClientIdAdressReal varchar2(500),
            ClientPhone varchar2(500),
            ClientEmail varchar2(500)
        ); 
        
        l_cust_rec customer_rt;
        
        retval varchar2_nt := varchar2_nt();
        refcur sys_refcursor;
        
        procedure add_value (ps_val_in in varchar2)
        is 
        begin
            retval.extend;
            retval(retval.last) := ps_val_in;
        end;
    begin
        open refcur for 
           select 
            -- tag Bank
            --'BankCode' BankCode,
            --'ЗАО "Демир Кыргыз Интернэшнл Банк"' BankName, 
            -- tag Customers
            --u tag customer 
            M.BOLUM_KODU  BranchCode,
            M.MUSTERI_NO  CustomerNo,
            M.MUSTERI_TIPI_KOD ClientType, 
            decode(M.YERLESIM_KOD,'1','RES','NRES') ClientNationality,
            --M.ISIM 
            '***' ClientName, 
            --M.SOYADI
            '***' ClientSurname,
            '***' ClientFathersName,
            M.DOGUM_TARIHI ClientDateBirth,
            M.DOGUM_YERI ClientPlaceBirth,
            decode(M.KIMLIK_KOD,1,'1',3,'2') ClientIdType, 
            --nvl (regexp_substr(PASAPORT_NO,'[[:alpha:]]+', 1, 1),regexp_substr(NUFUS_CUZDANI_SERI_NO,'[[:alpha:]]+', 1, 1))  ClientIdSerial,
            '**' ClientIdSerial,
            substr(regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace( regexp_replace(nvl (PASAPORT_NO,NUFUS_CUZDANI_SERI_NO), '1','F'),'2','M'),'0','X'),'9','0'),'7','Y'),' ',''),3,9)   ClientIdNumber,
--            '***' ClientIdNumber,
            --m.PATENT_NO 
            '***' ClientIdCertificate,
            --M.VERGI_NO
            regexp_replace(regexp_replace(regexp_replace(regexp_replace( regexp_replace(vergi_no, '1','F'),'2','M'),'0','X'),'9','0'),'7','Y') ClientIdPin,
            M.VERILDIGI_TARIH ClientIdIssueDate,
            M.VERILDIGI_YER ClientIdIssuePlace,
            decode (ma.ADRES_KOD,'1',ADRES) ClientIdAdress,
            decode (ma.ADRES_KOD,'2',ADRES,'3', ADRES) ClientIdAdressReal,
            nvl(MA.ULKE_GSM_KOD,'996')||MA.GSM_ALAN_KOD||MA.GSM_NO  ClientPhone,
            ma.email  ClientEmail
            from CBS_MUSTERI m, CBS_MUSTERI_ADRES ma 
            where M.MUSTERI_NO=MA.MUSTERI_NO
            and M.MUSTERI_NO in (98142,61664,13626,98816,217431,68367,157618,194109,102686,224079,177964 );

        add_value('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
        add_value('<Customers xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">');
        add_value(chr(9) || '<Bank>');
        add_value(chr(9) || chr(9) || '<BankCode>118001</BankCode>');
        add_value(chr(9) || chr(9) || '<BankName>ЗАО «Демир Кыргыз Интернэшнл Банк»</BankName>');
        add_value(chr(9) || '</Bank>');
        
        loop
            fetch refcur into l_cust_rec;
            exit when refcur%notfound;
            
            add_value(chr(9) || '<Customer>');
            add_value(chr(9) || chr(9) || '<BranchCode>'||l_cust_rec.BranchCode||'</BranchCode>');
            add_value(chr(9) || chr(9) || '<CustomerNo>'||l_cust_rec.CustomerNo||'</CustomerNo>');
            add_value(chr(9) || chr(9) || '<ClientType>'||l_cust_rec.ClientType||'</ClientType>');
            add_value(chr(9) || chr(9) || '<ClientNationality>'||l_cust_rec.ClientNationality||'</ClientNationality>');
            add_value(chr(9) || chr(9) || '<ClientName>'||l_cust_rec.ClientName||'</ClientName>');
            add_value(chr(9) || chr(9) || '<ClientSurname>'||l_cust_rec.ClientSurname||'</ClientSurname>');
            add_value(chr(9) || chr(9) || '<ClientFathersName>'||l_cust_rec.ClientFathersName||'</ClientFathersName>');
            add_value(chr(9) || chr(9) || '<ClientDateBirth>'||to_char(l_cust_rec.ClientDateBirth,'yyyy-mm-dd')||'</ClientDateBirth>');
            add_value(chr(9) || chr(9) || '<ClientPlaceBirth>'||l_cust_rec.ClientPlaceBirth||'</ClientPlaceBirth>');
            add_value(chr(9) || chr(9) || '<ClientIdType>'||l_cust_rec.ClientIdType||'</ClientIdType>');
            add_value(chr(9) || chr(9) || '<ClientIdSerial>'||l_cust_rec.ClientIdSerial||'</ClientIdSerial>');
            add_value(chr(9) || chr(9) || '<ClientIdNumber>'||l_cust_rec.ClientIdNumber||'</ClientIdNumber>');
            add_value(chr(9) || chr(9) || '<ClientIdCertificate>'||l_cust_rec.ClientIdCertificate||'</ClientIdCertificate>');
            add_value(chr(9) || chr(9) || '<ClientIdPin>'||l_cust_rec.ClientIdPin||'</ClientIdPin>');
            add_value(chr(9) || chr(9) || '<ClientIdIssueDate>'||to_char(l_cust_rec.ClientIdIssueDate,'yyyy-mm-dd')||'</ClientIdIssueDate>');
            add_value(chr(9) || chr(9) || '<ClientIdIssuePlace>'||l_cust_rec.ClientIdIssuePlace||'</ClientIdIssuePlace>');
            add_value(chr(9) || chr(9) || '<ClientIdAdress>'||l_cust_rec.ClientIdAdress||'</ClientIdAdress>');
            add_value(chr(9) || chr(9) || '<ClientIdAdressReal>'||l_cust_rec.ClientIdAdressReal||'</ClientIdAdressReal>');
            add_value(chr(9) || chr(9) || '<ClientPhone>'||l_cust_rec.ClientPhone||'</ClientPhone>');
            add_value(chr(9) || chr(9) || '<ClientEmail>'||l_cust_rec.ClientEmail||'</ClientEmail>');
            add_value(chr(9) || '</Customer>');            
        end loop;

        add_value('</Customers>');
        
        close refcur;
        
        return retval;
    exception 
        when others then
            if refcur%isopen then close refcur; end if;
            log_at('NursultanSa_log XML report', 'Customers error', sqlerrm, dbms_utility.format_error_backtrace);
    end get_customer_list;    
    
    
    function get_bank_info return varchar2_nt
    is 
        type branch_rt is record (
            BranchCode varchar2(10),
            BranchLisenceCode varchar2(200),
            BranchName varchar2(200),
            BranchCity varchar2(200),
            BranchAdress varchar2(200),
            BranchZipCode varchar2(200),
            BranchPhone varchar2(200),
            BranchEmail varchar2(200),
            BranchDirectorCN varchar2(200),
            BranchDirectorName varchar2(200),
            BranchDirectorSurname varchar2(200),
            BranchDirectorFathersName varchar2(200)
        );
        
        l_branch_rec branch_rt;
        
        retval varchar2_nt := varchar2_nt();
        refcur sys_refcursor;
        
        procedure add_value (ps_val_in in varchar2)
        is 
        begin
            retval.extend;
            retval(retval.last) := ps_val_in;
        end;
    begin
        add_value('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
        add_value('<Bank xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">');
        add_value(chr(9) || '<BankCode>118001</BankCode>');
        add_value(chr(9) || '<BankName>ЗАО «Демир Кыргыз Интернэшнл Банк»</BankName>');
        add_value(chr(9) || '<BankCity>Бишкек</BankCity>');
        add_value(chr(9) || '<BankAdress>Кыргызская Республика, г. Бишкек, пр.Чуй, 245</BankAdress>');
        add_value(chr(9) || '<BankZipCode>720001</BankZipCode>');
        add_value(chr(9) || '<BankLisenceNo>№035</BankLisenceNo>');
        add_value(chr(9) || '<BankPhone>+996 (312) 610 610</BankPhone>');
        add_value(chr(9) || '<BankFax>+996 (312) 610-444</BankFax>');
        add_value(chr(9) || '<BankEmail>customercare@demirbank.kg</BankEmail>');
        add_value(chr(9) || '<BankWebsite>www.demirbank.kg</BankWebsite>');
        add_value(chr(9) || '<Branches>');

        open refcur for             
                select * from(
                select '110' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Бейшеналиева» ЗАО «ДКИБ»' BranchName,
                ' Бишкек' BranchCity,
                'Кыргызская Республика, г. Бишкек, ул. Бейшеналиева, 33' BranchAdress,
                '720010' BranchZipCode,
                '+996 (312) 905 688' BranchPhone,
                'BEISHENALIEVA@demirbank.kg' BranchEmail,
                '121801' BranchDirectorCN,
                'Кубанычбек' BranchDirectorName,
                'Жабиев' BranchDirectorSurname,
                'Тилешович' BranchDirectorFathersName
                from dual
                union select '10' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Главный» ЗАО «ДКИБ»' BranchName,
                ' Бишкек' BranchCity,
                'Кыргызская Республика, г. Бишкек, пр. Чуй, 245' BranchAdress,
                '720001' BranchZipCode,
                '+996 (312) 610 610' BranchPhone,
                'B-MAIN@demirbank.kg' BranchEmail,
                '13948' BranchDirectorCN,
                'Кенже' BranchDirectorName,
                'Примова' BranchDirectorSurname,
                'Бозулановна' BranchDirectorFathersName
                from dual
                union select '60' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-М.Горький» ЗАО «ДКИБ»' BranchName,
                ' Бишкек' BranchCity,
                'Кыргызская Республика, г. Бишкек, ул. Тыныстанова, 105-ул. Горького, 134' BranchAdress,
                '720031' BranchZipCode,
                '+996 (312) 592 412' BranchPhone,
                'B-GORKIY@demirnak.kg' BranchEmail,
                '6027' BranchDirectorCN,
                'Зульфия' BranchDirectorName,
                'Акчурина' BranchDirectorSurname,
                'Фаритовна' BranchDirectorFathersName
                from dual
                union select '70' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Жалал-Абад» ЗАО «ДКИБ»' BranchName,
                ' Жалал-Абад' BranchCity,
                'Кыргызская Республика, Жалал-Абадская обл., г. Жалал-Абад, ул. Эркиндик, 17 «б»' BranchAdress,
                '720908' BranchZipCode,
                '+996 (3722) 2-03-04, 2-03-06' BranchPhone,
                'B-JALALABAD@demirbank.kg' BranchEmail,
                '119012' BranchDirectorCN,
                'Батырбек' BranchDirectorName,
                'Джаныбеков' BranchDirectorSurname,
                'Аманбаевич' BranchDirectorFathersName
                from dual
                union select '90' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Каракол» ЗАО «ДКИБ»' BranchName,
                ' Каракол' BranchCity,
                'Кыргызская Республика, г. Каракол, Иссык-Кульская область, г. Каракол, ул. Гебзе, д.124' BranchAdress,
                '722360' BranchZipCode,
                '+996 (3922) 5 63 68, 5 63 68, 5 63 03, 5 63 05' BranchPhone,
                'B-KARAKOL@demirbank.kg' BranchEmail,
                '175554' BranchDirectorCN,
                'Руслан' BranchDirectorName,
                'Кыргызбаев' BranchDirectorSurname,
                'Жекшенбекович' BranchDirectorFathersName
                from dual
                union select '140' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Кызыл-Кия» ЗАО «ДКИБ»' BranchName,
                ' Кызыл-Кия' BranchCity,
                'Кыргызская Республика, Баткенская обл., г. Кызыл-Кия, ул. Асаналиева б/н' BranchAdress,
                '720300' BranchZipCode,
                '+996 (3657) 5 42 66, 5 42 93' BranchPhone,
                'B-KYZYL-KIYA@demirbank.kg' BranchEmail,
                '211141' BranchDirectorCN,
                'Айбек' BranchDirectorName,
                'Сатимбаев' BranchDirectorSurname,
                'Абдылабекович' BranchDirectorFathersName
                from dual
                union select '40' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Манас» ЗАО «ДКИБ»' BranchName,
                ' Бишкек' BranchCity,
                'Кыргызская Республика, г. Бишкек, ул. Ахунбаева,187' BranchAdress,
                '720064' BranchZipCode,
                '+996 (312) 901 918, 901 937, 901 960, 901 963' BranchPhone,
                'B-MANAS@demirbank.kg' BranchEmail,
                '20067' BranchDirectorCN,
                'Линара' BranchDirectorName,
                'Биккулова' BranchDirectorSurname,
                'Тауфиковна' BranchDirectorFathersName
                from dual
                union select '100' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Нарын» ЗАО «ДКИБ»' BranchName,
                ' Нарын' BranchCity,
                'Кыргызская Республика, г. Нарын, ул. Токтосунова, д. 24' BranchAdress,
                '722900' BranchZipCode,
                '+996 (3522) 5 69 52, 5 69 50' BranchPhone,
                'B-NARYN@demirbank.kg' BranchEmail,
                '242336' BranchDirectorCN,
                'Анарбубу' BranchDirectorName,
                'Тологонова' BranchDirectorSurname,
                '-' BranchDirectorFathersName
                from dual
                union select '80' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Ош-Датка» ЗАО «ДКИБ»' BranchName,
                ' Ош' BranchCity,
                'Кыргызская Республика, г. Ош, пр. Раззакова 44 «б»' BranchAdress,
                '723506' BranchZipCode,
                '+996 (3222) 8 15 25, 8 15 35' BranchPhone,
                'B-OSH2@demirbank.kg' BranchEmail,
                '34503' BranchDirectorCN,
                'Сагынбек' BranchDirectorName,
                'Камбаров' BranchDirectorSurname,
                'Абдишович' BranchDirectorFathersName
                from dual
                union select '120' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ–Талас» ЗАО «ДКИБ»' BranchName,
                ' Талас' BranchCity,
                'Кыргызская Республика, Таласская обл., г. Талас, ул. Койчукулова, 187' BranchAdress,
                '724200' BranchZipCode,
                '+996 (3422) 5 70 53, 5 70 52' BranchPhone,
                'B-TALAS@demirbank.kg' BranchEmail,
                '24409' BranchDirectorCN,
                'Ашыр' BranchDirectorName,
                'Болоткан уулу' BranchDirectorSurname,
                '' BranchDirectorFathersName
                from dual
                union select '30' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Центр» ЗАО «ДКИБ»' BranchName,
                ' Бишкек' BranchCity,
                'Кыргызская Республика, г. Бишкек, ул. Боконбаева 104 «а»' BranchAdress,
                '720040' BranchZipCode,
                '+996 (312) 302235, 302183, 901194, 901193' BranchPhone,
                'B-CNT@demirbank.kg' BranchEmail,
                '22667' BranchDirectorCN,
                'Улан' BranchDirectorName,
                'Джанболотов' BranchDirectorSurname,
                'Эркинбекович' BranchDirectorFathersName
                from dual
                union select '130' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-ЦУМ» ЗАО «ДКИБ»' BranchName,
                ' Бишкек' BranchCity,
                'Кыргызская Республика, г. Бишкек, пр. Чуй 96, ул.Киевская 39' BranchAdress,
                '720000' BranchZipCode,
                '+996 (312) 66 36 45, 66 36 47' BranchPhone,
                'B-TSUM@demirbank.kg' BranchEmail,
                '13026' BranchDirectorCN,
                'Асель' BranchDirectorName,
                'Дордоева' BranchDirectorSurname,
                'Эшмуратовна' BranchDirectorFathersName
                from dual
                union select '150' BranchCode,
                'Н/П' BranchLisenceCode,
                '«ДКИБ-Южный» ЗАО «ДКИБ»' BranchName,
                ' Бишкек' BranchCity,
                'Кыргызская Республика, г. Бишкек, пр. Чынгыза Айтматова 299/В' BranchAdress,
                '720001' BranchZipCode,
                '+996 (312) 986 521, касса 986 293,83' BranchPhone,
                'BRANCH_YUJNYI@demirbank.kg' BranchEmail,
                '62409' BranchDirectorCN,
                'Александра' BranchDirectorName,
                'Мамырова' BranchDirectorSurname,
                'Эрнесовна' BranchDirectorFathersName
                from dual);
        
        loop
            fetch refcur into l_branch_rec;
            exit when refcur%notfound;
            
            add_value(chr(9) || '<Branch>');
            add_value(chr(9) || chr(9) || '<BranchCode>'|| l_branch_rec.BranchCode ||'</BranchCode>');
            add_value(chr(9) || chr(9) || '<BranchLisenceCode>'|| l_branch_rec.BranchLisenceCode ||'</BranchLisenceCode>');
            add_value(chr(9) || chr(9) || '<BranchName>'|| l_branch_rec.BranchName ||'</BranchName>');
            add_value(chr(9) || chr(9) || '<BranchCity>'|| l_branch_rec.BranchCity ||'</BranchCity>');
            add_value(chr(9) || chr(9) || '<BranchAdress>'|| l_branch_rec.BranchAdress ||'</BranchAdress>');
            add_value(chr(9) || chr(9) || '<BranchZipCode>'|| l_branch_rec.BranchZipCode ||'</BranchZipCode>');
            add_value(chr(9) || chr(9) || '<BranchPhone>'|| l_branch_rec.BranchPhone ||'</BranchPhone>');
            add_value(chr(9) || chr(9) || '<BranchEmail>'|| l_branch_rec.BranchEmail ||'</BranchEmail>');
            add_value(chr(9) || chr(9) || '<BranchDirectorCN>'|| l_branch_rec.BranchDirectorCN ||'</BranchDirectorCN>');
            add_value(chr(9) || chr(9) || '<BranchDirectorName>'|| l_branch_rec.BranchDirectorName ||'</BranchDirectorName>');
            add_value(chr(9) || chr(9) || '<BranchDirectorSurname>'|| l_branch_rec.BranchDirectorSurname ||'</BranchDirectorSurname>');
            add_value(chr(9) || chr(9) || '<BranchDirectorFathersName>'|| l_branch_rec.BranchDirectorFathersName ||'</BranchDirectorFathersName>');
            add_value(chr(9) || '</Branch>');
        end loop;

        add_value(chr(9) || '</Branches>');
        add_value('</Bank>');

        close refcur;
        
        return retval;
    exception 
        when others then
            if refcur%isopen then close refcur; end if;
    end get_bank_info;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------







    function get_credit_card_list(pd_date in date) return varchar2_nt
    is 
        type credit_rt is record (
            BranchCode varchar2(10),
            CustomerNo number,
            CreditAccountNumber number,
            IbanNumber number,
            CurrencyCode varchar2(10),
            Rate NUMBER(30,8),
            AmountCurrency number,
            AmountKGS number,
            InterestAmountCurrency number,
            InterestAmountKGS number,
            TotalAmountCurrency number,
            TotalAmountKGS number,
            OpenDate date,
            CloseDate date,
            Percent number
        ); 
        
        l_credit_rec credit_rt;
        
        retval varchar2_nt := varchar2_nt();
        refcur sys_refcursor;
        
        procedure add_value (ps_val_in in varchar2)
        is 
        begin
            retval.extend;
            retval(retval.last) := ps_val_in;
        end;
    begin
        open refcur for 
            q'!select
            KR.SUBE_KODU  BranchCode,
            kr.MUSTERI_NO  CustomerNo,
            kr.HESAP_NO CreditAccountNumber,
            kr.HESAP_NO IbanNumber,
            kr.DOVIZ_KODU  CurrencyCode,
            M.DVZALIS rate ,
            KR.BAKIYE  AmountCurrency,
            round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (kr.doviz_kodu, 'KGS',KR.BANKA_TARIHI,KR.BAKIYE,3, NULL, NULL, 'N'),2)AmountKGS,
            kr.BIRIKMIS_FAIZ_TUTARI InterestAmountCurrency,
            round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(kr.doviz_kodu, 'KGS',KR.BANKA_TARIHI,KR.BIRIKMIS_FAIZ_TUTARI,3, NULL, NULL, 'N'),2)InterestAmountKGS,
            (kr.BAKIYE*(-1) + kr.BIRIKMIS_FAIZ_TUTARI )TotalAmountCurrency,
            round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (kr.doviz_kodu, 'KGS',KR.BANKA_TARIHI,(kr.BAKIYE*(-1) + kr.BIRIKMIS_FAIZ_TUTARI),3, NULL, NULL, 'N'),2)TotalAmountKGS,
            kr.ACILIS_TARIHI OpenDate,
            kr.KREDI_VADE  CloseDate,
            kr.YEARLY_INT_RATE Percent
            from 
            CBS_RPT_KREDI_GUNSONU_FAIZ kr, CBS_MBKURLOG m 
            where KR.BANKA_TARIHI=trunc(M.TARIH) and KR.DOVIZ_KODU=M.DVZ
            and  KR.BANKA_TARIHI=to_date(:pdate,'ddmmyyyy')
            and kr.MUSTERI_NO in (98142,61664,13626,98816,217431,68367,157618,194109,102686,224079,177964 )
            !' using to_char(pd_date,'ddmmyyyy');

        add_value('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
        add_value('<Credits xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">');
        add_value(chr(9) || '<Bank>');
        add_value(chr(9) || chr(9) || '<BankCode>118001</BankCode>');
        add_value(chr(9) || chr(9) || '<BankName>ЗАО «Демир Кыргыз Интернэшнл Банк»</BankName> ');
        add_value(chr(9) || '</Bank>');
        
        loop
            fetch refcur into l_credit_rec;
            exit when refcur%notfound;

            add_value(chr(9) || '<Credit>');
            add_value(chr(9) || chr(9) || '<BranchCode>'||l_credit_rec.BranchCode||'</BranchCode>');
            add_value(chr(9) || chr(9) || '<CustomerNo>'||l_credit_rec.CustomerNo||'</CustomerNo>');
            add_value(chr(9) || chr(9) || '<CreditAccountNumber>'||l_credit_rec.CreditAccountNumber||'</CreditAccountNumber>');
            add_value(chr(9) || chr(9) || '<IbanNumber>'||rpad(l_credit_rec.IbanNumber,28,'0')||'</IbanNumber>');
            add_value(chr(9) || chr(9) || '<CurrencyCode>'||l_credit_rec.CurrencyCode||'</CurrencyCode>');
            add_value(chr(9) || chr(9) || '<Rate>'||l_credit_rec.Rate||'</Rate>');
            add_value(chr(9) || chr(9) || '<AmountCurrency>'||l_credit_rec.AmountCurrency||'</AmountCurrency>');
            add_value(chr(9) || chr(9) || '<AmountKGS>'||l_credit_rec.AmountKGS||'</AmountKGS>');
            add_value(chr(9) || chr(9) || '<InterestAmountCurrency>'||l_credit_rec.InterestAmountCurrency||'</InterestAmountCurrency>');
            add_value(chr(9) || chr(9) || '<InterestAmountKGS>'||l_credit_rec.InterestAmountKGS||'</InterestAmountKGS>');
            add_value(chr(9) || chr(9) || '<TotalAmountCurrency>'||l_credit_rec.TotalAmountCurrency||'</TotalAmountCurrency>');
            add_value(chr(9) || chr(9) || '<TotalAmountKGS>'||l_credit_rec.TotalAmountKGS||'</TotalAmountKGS>');
            add_value(chr(9) || chr(9) || '<OpenDate>'||to_char(l_credit_rec.OpenDate,'yyyy-mm-dd')||'</OpenDate>');
            add_value(chr(9) || chr(9) || '<CloseDate>'||to_char(l_credit_rec.CloseDate,'yyyy-mm-dd')||'</CloseDate>');
            add_value(chr(9) || chr(9) || '<Percent>'||l_credit_rec.Percent||'</Percent>');
            add_value(chr(9) || '</Credit>');
        
        end loop;

        add_value('</Credits>');
        
        close refcur;
        
        return retval;
    exception 
        when others then
            if refcur%isopen then close refcur; end if;
            log_at('NursultanSa_log XML report', 'Credit error', sqlerrm, dbms_utility.format_error_backtrace);
    end;
    
    --function get_deposit_list return varchar2_nt;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    function get_deposit_list(pd_date in date) return varchar2_nt
    is 
        type deposit_rt is record (
            BranchCode varchar2(10),
            CustomerNo number,
            BookNumber varchar2(30),
            DepositAccountNumber number,
            AccountType varchar2(10),
            IbanNumber number,
            CurrencyCode varchar2(10),
            Rate number,
            AmountCurrency number,
            AmountKGS number,
            InterestAmountCurrency number,
            InterestAmountKGS number,
            TotalAmountCurrency number,
            TotalAmountKGS number,
            OpenDate date,
            CloseDate date,
            Percent number,
            BanksLiability  number,
            ConfiscatedStatus varchar2(500),
            ConfiscatedAmount number
        ); 
        
        l_deposit_rec deposit_rt;
        
        retval varchar2_nt := varchar2_nt();
        refcur sys_refcursor;
        
        procedure add_value (ps_val_in in varchar2)
        is 
        begin
            retval.extend;
            retval(retval.last) := ps_val_in;
        end;
    begin
        open refcur for 
            q'!
               select 
distinct a.*, (B.ORDER_DATE ||' ' || B.EXPLANATION) ConfiscatedStatus,
b.AMOUNT  ConfiscatedAmount
 from (select 
--tag Bank 
--'118001' BankCode,
--'ЗАО «Демир Кыргыз Интернэшнл Банк»' BankName,
--close tag Bank
--Open tag Deposits 
--open u tag Deposit
V.SUBE_KODU  BranchCode,
V.MUSTERI_NO CustomerNo,
v.MUSTERI_DK_NO  BookNumber, 
v.HESAP_NO DepositAccountNumber,
'1' AccountType ,
v.HESAP_NO IbanNumber,
v.doviz_kodu CurrencyCode,
M.DVZALIS Rate,
V.bakiye  AmountCurrency,
round (PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,v.bakiye,3, NULL, NULL, 'N'),2) AmountKGS,
(v.BIRIKMIS_FAIZ_TUTARI+v.GECENYIL_FAIZ_TUTARI)   InterestAmountCurrency, 
round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,(v.BIRIKMIS_FAIZ_TUTARI+v.GECENYIL_FAIZ_TUTARI) ,3, NULL, NULL, 'N'),2) InterestAmountKGS,
(V.bakiye +v.BIRIKMIS_FAIZ_TUTARI+GECENYIL_FAIZ_TUTARI) TotalAmountCurrency ,
round (PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,(V.bakiye +v.BIRIKMIS_FAIZ_TUTARI+v.GECENYIL_FAIZ_TUTARI),3, NULL, NULL, 'N'),2) TotalAmountKGS,
V.ACILIS_TARIHI  OpenDate,
V.VADE_TARIHI  CloseDate,
V.FAIZ_ORANI Percent,
round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,(V.bakiye +v.BIRIKMIS_FAIZ_TUTARI+v.GECENYIL_FAIZ_TUTARI),3, NULL, NULL, 'N'),2)BanksLiability
from  CBS_RPT_VADELI_GUNSONU_FAIZ v  ,CBS_MBKURLOG M  WHERE  v.banka_tarihi=TRUNC(m.TARIH) and v.doviz_kodu=M.DVZ and v.banka_tarihi=to_date(:pdate,'ddmmyyyy') 
and v.musteri_no in (98142)--,61664,13626,98816,217431,68367,157618,194109,102686,224079,177964 )
)a
left join 
CBS_BAD_LIST  b
on B.CUSTOMER_NO=a.CustomerNo
union all
select 
distinct a.*, (B.ORDER_DATE ||' ' || B.EXPLANATION) ConfiscatedStatus,
b.AMOUNT  ConfiscatedAmount
 from (select 
--tag Bank 
--'118001' BankCode,
--'ЗАО «Демир Кыргыз Интернэшнл Банк»' BankName,
--close tag Bank
--Open tag Deposits 
--open u tag Deposit
V.SUBE_KODU  BranchCode,
V.MUSTERI_NO CustomerNo,
v.MUSTERI_DK_NO  BookNumber, 
v.HESAP_NO DepositAccountNumber,
'2' AccountType ,
v.HESAP_NO IbanNumber,
v.doviz_kodu CurrencyCode,
M.DVZALIS Rate,
V.bakiye  AmountCurrency,
round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,v.bakiye,3, NULL, NULL, 'N'),2) AmountKGS,
(v.BIRIKMIS_FAIZ_TUTARI)    InterestAmountCurrency, 
round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,(v.BIRIKMIS_FAIZ_TUTARI) ,3, NULL, NULL, 'N'),2) InterestAmountKGS,
(V.bakiye +v.BIRIKMIS_FAIZ_TUTARI) TotalAmountCurrency ,
round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,(V.bakiye +v.BIRIKMIS_FAIZ_TUTARI),3, NULL, NULL, 'N'),2)TotalAmountKGS,
V.ACILIS_TARIHI  OpenDate,
V.VADE_TARIHI  CloseDate,
V.FAIZ_ORANI Percent,
round(PKG_KUR.DOVIZ_DOVIZ_KARSILIK (v.doviz_kodu, 'KGS', V.banka_tarihi,(V.bakiye +v.BIRIKMIS_FAIZ_TUTARI),3, NULL, NULL, 'N'),2)BanksLiability
from  CBS_RPT_VADESIZ_GUNSONU_FAIZ v  ,CBS_MBKURLOG M  WHERE  v.banka_tarihi=TRUNC(m.TARIH) and v.doviz_kodu=M.DVZ and v.banka_tarihi=to_date(:pdate,'ddmmyyyy') 
and v.musteri_no in (98142)--,61664,13626,98816,217431,68367,157618,194109,102686,224079,177964) 
)a
left join 
CBS_BAD_LIST  b
on B.CUSTOMER_NO=a.CustomerNo
order by 4,6 asc

            !' using to_char(pd_date,'ddmmyyyy'), to_char(pd_date,'ddmmyyyy');

        add_value('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
        add_value('<Deposits xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">');
        add_value(chr(9) || '<Bank>');
        add_value(chr(9) || chr(9) || '<BankCode>118001</BankCode>');
        add_value(chr(9) || chr(9) || '<BankName>ЗАО «Демир Кыргыз Интернэшнл Банк»</BankName> ');
        add_value(chr(9) || '</Bank>');
        
        loop
            fetch refcur into l_deposit_rec;
            exit when refcur%notfound;

            add_value(chr(9) || '<Deposit>');
            add_value(chr(9) || chr(9) || '<BranchCode>'||l_deposit_rec.BranchCode||'</BranchCode>');
            add_value(chr(9) || chr(9) || '<CustomerNo>'||l_deposit_rec.CustomerNo||'</CustomerNo>');
            add_value(chr(9) || chr(9) || '<BookNumber>'||l_deposit_rec.BookNumber||'</BookNumber>');
            add_value(chr(9) || chr(9) || '<DepositAccountNumber>'||l_deposit_rec.DepositAccountNumber||'</DepositAccountNumber>');
            add_value(chr(9) || chr(9) || '<AccountType>'||l_deposit_rec.AccountType||'</AccountType>');
            add_value(chr(9) || chr(9) || '<IbanNumber>'||rpad(l_deposit_rec.IbanNumber,28,'0')||'</IbanNumber>');
            add_value(chr(9) || chr(9) || '<CurrencyCode>'||l_deposit_rec.CurrencyCode||'</CurrencyCode>');
            add_value(chr(9) || chr(9) || '<Rate>'||l_deposit_rec.Rate||'</Rate>');
            add_value(chr(9) || chr(9) || '<AmountCurrency>'||l_deposit_rec.AmountCurrency||'</AmountCurrency>');
            add_value(chr(9) || chr(9) || '<AmountKGS>'||l_deposit_rec.AmountKGS||'</AmountKGS>');
            add_value(chr(9) || chr(9) || '<InterestAmountCurrency>'||l_deposit_rec.InterestAmountCurrency||'</InterestAmountCurrency>');
            add_value(chr(9) || chr(9) || '<InterestAmountKGS>'||l_deposit_rec.InterestAmountKGS||'</InterestAmountKGS>');
            add_value(chr(9) || chr(9) || '<TotalAmountCurrency>'||l_deposit_rec.TotalAmountCurrency||'</TotalAmountCurrency>');
            add_value(chr(9) || chr(9) || '<TotalAmountKGS>'||l_deposit_rec.TotalAmountKGS||'</TotalAmountKGS>');
            add_value(chr(9) || chr(9) || '<OpenDate>'||to_char(l_deposit_rec.OpenDate,'yyyy-mm-dd')||'</OpenDate>');
            add_value(chr(9) || chr(9) || '<CloseDate>'||to_char(l_deposit_rec.CloseDate,'yyyy-mm-dd')||'</CloseDate>');
            add_value(chr(9) || chr(9) || '<Percent>'||l_deposit_rec.Percent||'</Percent>');
            add_value(chr(9) || chr(9) || '<BanksLiability>'||l_deposit_rec.BanksLiability||'</BanksLiability>');
            add_value(chr(9) || chr(9) || '<ConfiscatedStatus>'||l_deposit_rec.ConfiscatedStatus||'</ConfiscatedStatus>');
            add_value(chr(9) || chr(9) || '<ConfiscatedAmount>'||l_deposit_rec.ConfiscatedAmount||'</ConfiscatedAmount>');
            add_value(chr(9) || '</Deposit>');
        
        end loop;

        add_value('</Deposits>');
        
        close refcur;
        
        return retval;
    exception 
        when others then
            if refcur%isopen then close refcur; end if;
            log_at('NursultanSa_log XML report', 'Deposit error', sqlerrm, dbms_utility.format_error_backtrace);
    end;
end;
/

