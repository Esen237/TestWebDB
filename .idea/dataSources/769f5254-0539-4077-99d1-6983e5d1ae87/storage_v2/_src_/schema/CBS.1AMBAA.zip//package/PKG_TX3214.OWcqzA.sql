create PACKAGE PKG_TX3214 IS

  -- TX Event Listesi
  --?THALAT PROVIZYON ONAY

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		-- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);-- Islem iptal edildikten sonra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		-- Isleme iliskin formlar basildiktan sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);		-- Islem iptal edilirse

  Procedure Muhasebelesme(pn_islem_no number);			-- Islemin muhasebelesmesi icin cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  Procedure Iptal_Sonrasi(pn_islem_no number); -- Islem iptal edilip
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number); -- Islem iptal edilip

END;


/

