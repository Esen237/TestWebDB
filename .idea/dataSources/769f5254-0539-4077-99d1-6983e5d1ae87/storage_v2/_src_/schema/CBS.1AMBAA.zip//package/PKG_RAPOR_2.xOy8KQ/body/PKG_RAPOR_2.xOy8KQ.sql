create PACKAGE BODY     Pkg_Rapor_2 IS

 FUNCTION  gunluk_dk_onceki_bakiye_al(ps_tarih VARCHAR2) RETURN NUMBER
   IS
    ln_dk_onceki_bakiye      NUMBER;
  BEGIN

    SELECT NVL(a.bakiye,0)
    INTO   ln_dk_onceki_bakiye
    FROM   CBS_DKHESAP_GUNLUK_BAKIYE a
    WHERE  a.yil = TO_NUMBER(TO_CHAR(TO_DATE(ps_tarih,'DD/MM/YYYY'),'YYYY'))
    AND    a.ay = TO_NUMBER(TO_CHAR(TO_DATE(ps_tarih,'DD/MM/YYYY'),'MM'))
    AND    a.gun = TO_NUMBER(TO_CHAR(TO_DATE(ps_tarih,'DD/MM/YYYY'),'DD'));

    RETURN ln_dk_onceki_bakiye ;

  EXCEPTION
      WHEN NO_DATA_FOUND THEN
           RETURN 0  ;
      WHEN OTHERS THEN
        RETURN 0  ;
  END;
  --**************************************************
  FUNCTION  modul_adi_al(ps_modul_tur_kod IN CBS_MODUL_TUR.kod%TYPE) RETURN VARCHAR2
   IS
    ls_aciklama      CBS_MODUL_TUR.aciklama%TYPE;
  BEGIN
      SELECT ACIKLAMA
           INTO   ls_aciklama
           FROM   CBS_MODUL_TUR
           WHERE  kod = ps_modul_tur_kod;

    RETURN ls_aciklama;

  EXCEPTION
      WHEN OTHERS THEN
      RETURN NULL;
  END;
  --**************************************************
  PROCEDURE Limit_Bilgi_Getir(pn_kod IN CBS_LIMIT.numara%TYPE,
                                pn_alt OUT NUMBER,pn_ust OUT NUMBER ,
                              ps_doviz_kod OUT VARCHAR2,ps_karsilik OUT VARCHAR2) IS
  BEGIN
    -- Bu fonksiyon M??teri grubu limitlerini g?ncelleme program?nda kullan?lmaktad?r.


    SELECT alt,ust,DECODE(tum_dovizler,'H',doviz_kod,'E','ALL'),
           DECODE(karsilik,'S','-->','F',Pkg_Genel.fc_al,'L',Pkg_Genel.lc_al,'N','None')
      INTO pn_alt,
           pn_ust,
           ps_doviz_kod,
           ps_karsilik
      FROM CBS_LIMIT
     WHERE numara=pn_kod;


    EXCEPTION
           WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 /***********************************/
  PROCEDURE Zaman_Bilgi_Getir(pn_kod IN CBS_ZAMAN.numara%TYPE,
                                pn_bas OUT NUMBER,pn_bit OUT NUMBER ) IS
  BEGIN
    -- Bu fonksiyon M??teri grubu limitlerini g?ncelleme program?nda kullan?lmaktad?r.


    SELECT BASLANGIC, BITIS
      INTO pn_bas,
           pn_bit
      FROM CBS_ZAMAN
     WHERE numara=pn_kod;



    EXCEPTION
           WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 /***********************************/
 FUNCTION program_adi_al(ps_program_kod IN CBS_PROGRAM.kod%TYPE) RETURN VARCHAR2
   IS
    ls_aciklama      CBS_PROGRAM.adi%TYPE;
  BEGIN
      SELECT adi
           INTO   ls_aciklama
           FROM   CBS_PROGRAM
           WHERE  kod = ps_program_kod;

    RETURN ls_aciklama;

  EXCEPTION
      WHEN OTHERS THEN
      RETURN NULL;
  END;
  --**************************************************
 FUNCTION Neg_Bakiyeli_Urun_Tur_Uygun_mu(ps_urun_tur_kod CBS_URUN_TUR.KOD%TYPE) RETURN VARCHAR2
   IS
  BEGIN

    IF ps_urun_tur_kod NOT IN ('NOSTRO-LC','NOSTRO-FC','SPOT','FORWARD','SWAP','SWAP-FW') THEN
       RETURN 'E';
    ELSE
       RETURN 'H';
    END IF;

  END;
  --**************************************************
 FUNCTION  dosya_bakiyesi_al(ps_referans VARCHAR2) RETURN NUMBER
   IS
    ln_bakiye      NUMBER;
  BEGIN
    if substr(ps_referans,8,3) = 'LGI' then
       select nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0)
       into   ln_bakiye
       from   cbs_tm_hg_acilis
       where  referans = ps_referans ;
    else
       select nvl(AKREDITIF_BAKIYE,0)
       into   ln_bakiye
       from   cbs_ith_akreditif
       where  referans = ps_referans ;
    end if;

    RETURN ln_bakiye ;

  EXCEPTION
      WHEN NO_DATA_FOUND THEN
           RETURN 0  ;
      WHEN OTHERS THEN
        RETURN 0  ;
  END;
  --**************************************************
 FUNCTION  dk_adi_al(ps_numara VARCHAR2,ps_doviz varchar2) RETURN varchar2
   IS
    ls_aciklama   varchar2(2000);
  BEGIN

     select distinct min(aciklama)
     into   ls_aciklama
     from   cbs_dkhesap
     where  numara = ps_numara
     and    doviz_kod = ps_doviz;

    RETURN ls_aciklama ;

  EXCEPTION
      WHEN NO_DATA_FOUND THEN
           RETURN ' '  ;
      WHEN OTHERS THEN
        RETURN ' '  ;
  END;
  --**************************************************
--B-O-M sevalb 21032011 
 Function DK_BUL_GETIR( pn_musteri_no in number 
                           ,ps_modul_tur_kod     IN VARCHAR2
                           ,ps_urun_tur_kod      IN VARCHAR2
                           ,ps_urun_sinif_kod    IN VARCHAR2
                           ,pn_gl_index          IN NUMBER) return varchar2
 is 
 lv_musteri_dkno varchar2(200);
 ls_dkgrup_kodu CBS_MUSTERI.DK_GRUP_KOD%type;
 Begin                           
    select dk_grup_kod
    into  ls_dkgrup_kodu 
    from  cbs_musteri
    where musteri_no=pn_musteri_no;
    
    Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, ps_modul_tur_kod, ps_urun_tur_kod,ps_urun_sinif_kod, pn_gl_index, NULL, NULL, NULL, lv_musteri_dkno);
   
  return lv_musteri_dkno;
   Exception when others then return null;   
 End;    
--E-O-M sevalb 21032011  
END Pkg_Rapor_2 ;
/

