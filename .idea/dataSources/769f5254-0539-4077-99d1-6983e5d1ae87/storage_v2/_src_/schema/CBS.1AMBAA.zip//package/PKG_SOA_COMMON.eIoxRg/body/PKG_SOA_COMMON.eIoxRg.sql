create PACKAGE BODY     "PKG_SOA_COMMON" IS

/******************************************************************************
 NAME : FUNCTION GetBankName
 Prepared By : Almas Nurhozhaev
 Date : 24.12.07
 Purpose : Get Banks Name
******************************************************************************/
FUNCTION GetBankName(ps_bankcode IN VARCHAR2) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(200);
BEGIN
 SELECT BANK_BIC_CODE||' - '||BANKNAME
 INTO ls_returncode
 FROM CBS_BANKCODES
 WHERE BANK_BIC_CODE=ps_bankcode
 ORDER BY BANK_BIC_CODE;

 RETURN ls_returncode;
END;

/******************************************************************************
 NAME : FUNCTION BakiyeYeterlimi
 Prepared By : Almas Nurhozhaev
 Date : 12.12.2007
 Purpose : Bakiye Yeterlimi
******************************************************************************/
FUNCTION BakiyeYeterlimi(pn_hesapNumarasi IN VARCHAR2,
 pn_miktar IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';
BEGIN
 OPEN pc_ref FOR SELECT SYSDATE FROM dual;

 IF (Pkg_Hesap.Kullanilabilir_Bakiye_Al(pn_hesapNumarasi) < TO_NUMBER(pn_miktar,'99999999999.9999999999999')) THEN
 RETURN '502';
 END IF;

 RETURN ls_returncode;
END;

/******************************************************************************
 NAME : FUNCTION HesapMusteriKontrol
 Prepared By : Almas Nurhozhaev
 Date : 06.12.07
 Purpose : Check Customer
******************************************************************************/
FUNCTION HesapMusteriKontrol(pn_accountNo IN VARCHAR2,
 pn_customerNo IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ls_count NUMBER:=0;
 ls_count1 NUMBER:=0;
 ls_count2 NUMBER:=0;
BEGIN

 
 
 
 OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 SELECT COUNT(*)
 INTO ls_count
 FROM CBS_vw_hesap_izleme a
 WHERE a.HESAP_NO = TO_NUMBER(pn_accountNo)
 AND a.MUSTERI_NO in(select trim(regexp_substr(pn_customerNo, '[^,]+', 1, level ) )from dual 
                     connect by trim(regexp_substr(pn_customerNo, '[^,]+', 1, level )) is not null) --added Esen Omurchiev 30.11.2021 for task ib-111
 AND a.DURUM_KODU = 'A';

 IF(ls_count = 0) THEN
 

 SELECT count(*) --added Esen Omurchiev 30.11.2021 for task ib-111
 INTO ls_count1
 FROM CBS_vw_hesap_izleme a
 WHERE a.HESAP_NO = TO_NUMBER(pn_accountNo)
 AND a.HESAP_NO in (select ANA_HESAP_NO from  CBS_HESAP_ORTAK_BILGI where ortak_musteri_no in (select trim(regexp_substr(pn_customerNo, '[^,]+', 1, level ) )from dual 
                                                                                               connect by trim(regexp_substr(pn_customerNo, '[^,]+', 1, level )) is not null) 
                                                                                               and STATUS = 'ACTIVE' and ORTAKLIK_TIPI = 'OY')
 AND a.DURUM_KODU = 'A';

 IF(ls_count1 = 0) THEN

 SELECT COUNT(*)
 INTO ls_count2
 FROM CBS_JOIN_ACCOUNT
 WHERE REL_ACCOUNT = TO_NUMBER(pn_accountNo)
 AND CUST_NO in(select trim(regexp_substr(pn_customerNo, '[^,]+', 1, level ) )from dual 
                connect by trim(regexp_substr(pn_customerNo, '[^,]+', 1, level )) is not null); --added Esen Omurchiev 30.11.2021 for task ib-111

 IF (ls_count2 = 0) THEN
 ls_returncode:='432';
 END IF;
 END IF;
 END IF;

 IF Pkg_Hesap.BadListFlag(pn_accountNo)='E' THEN
 ls_returncode:='431';
 END IF;

 RETURN ls_returncode;
END;

/******************************************************************************
 NAME : FUNCTION CheckRNNExternalAccount
 Prepared By : Almas Nurhozhaev
 Date : 06.12.07
 Purpose : Check customers external account, and RNN number
******************************************************************************/
FUNCTION CheckRNNExternalAccount(pn_bankcode IN VARCHAR2,
 pn_externalaccount IN VARCHAR2,
 pn_rnn IN VARCHAR2,
 pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2 (3) := '000';
BEGIN
 IF Pkg_Hesap.Check_External_HesapNo(pn_bankcode,pn_externalaccount)=0 THEN
 ls_returncode:='023';
 END IF;

 /*IF Pkg_Musteri.TaxNumberControl(pn_rnn)=0 THEN
 ls_returncode:='022';
 END IF;*/

 OPEN pc_ref FOR SELECT pn_bankcode,pn_externalaccount,pn_rnn,ls_returncode FROM DUAL;

 RETURN ls_returncode;
EXCEPTION
 WHEN OTHERS
 THEN
 ls_returncode := '288';
 Log_At('CheckRNNExternalAccount',pn_externalaccount,SQLERRM);
 RAISE_APPLICATION_ERROR(-20100,SQLERRM);
 RETURN ls_returncode;
END;

/******************************************************************************
 NAME : FUNCTION SaveCustElemSettings
 Created By : Almas Nurhozhaev
 Date : 06.06.08
 Purpose : Save Person Customization element settings
******************************************************************************/
FUNCTION SaveCustElemSettings(pn_personcd IN VARCHAR2,
 ps_elementids IN VARCHAR2,
 pn_visible IN VARCHAR2,
 pc_ref OUT CursorReferenceType,
 pc_ref2 OUT CursorReferenceType,
 pc_ref3 OUT CursorReferenceType,
 pc_ref4 OUT CursorReferenceType,
 pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';
 visible_str VARCHAR2 (10):='sENAB';
BEGIN
 if pn_visible = 0 then
 visible_str := 'sDISAB';
 end if;

 OPEN pc_ref FOR SELECT '-' FROM dual;
 OPEN pc_ref2 FOR SELECT '-' FROM dual;
 OPEN pc_ref3 FOR SELECT '-' FROM dual;
 OPEN pc_ref4 FOR SELECT '-' FROM dual;
 OPEN pc_ref5 FOR SELECT '-' FROM dual;

 UPDATE corpint.tbl_customize_person SET status_cd = visible_str
 WHERE element_id=ps_elementids
 AND person_id=pn_personcd;

 RETURN ls_returncode;
EXCEPTION
 WHEN OTHERS THEN
 ls_returncode:='999';
 LOG_AT('SaveCustomizationElement',ls_returncode,sqlerrm);
 RETURN ls_returncode;
END;

/******************************************************************************
 NAME : FUNCTION GetRateForLimit
 Created By : Almas Nurhozhaev
 Date : 07.07.08
 Purpose : Get rates for limit
******************************************************************************/
FUNCTION GetRateForLimit(ps_Currency IN VARCHAR2) RETURN NUMBER IS
 ln_rate NUMBER;
BEGIN
 SELECT DVZALIS
 INTO ln_rate
 FROM CBS_KUR
 WHERE DVZ=ps_Currency;
 RETURN ln_rate;
END;

/******************************************************************************
 NAME : IsRateDemandCustomer
 Prepared By : Almas Nurhozhaev
 Date : 07.07.2008
 Purpose : Can this customer make rezervation
 ******************************************************************************/
FUNCTION IsRateDemandCustomer(p_customerid IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ln_count NUMBER;
BEGIN
 SELECT COUNT(*)
 INTO ln_count
 FROM CBS_INT_RATEDEMAND_CUST
 WHERE MUSTERI_NO=TO_NUMBER(p_customerid)
 AND STATUS_CD='sVALID';

 OPEN pc_ref FOR
 SELECT ln_count FROM dual;

 IF ln_count=0 THEN
 RETURN '401';
 ELSE
 RETURN ls_returncode;
 END IF;

END;

/******************************************************************************
 NAME : FUNCTION ArbitrageControl
 Created By : Almas Nurhozhaev
 Date : 07.07.2008
 Purpose : Control Accounts for Arbitrage
******************************************************************************/
FUNCTION ArbitrageControl(pn_CustomerId IN VARCHAR2,
 pc_ref OUT CursorReferenceType,
 pc_ref2 OUT CursorReferenceType,
 pc_ref3 OUT CursorReferenceType,
 pc_ref4 OUT CursorReferenceType,
 pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ls_count NUMBER:=0;
BEGIN
 OPEN pc_ref FOR SELECT '-' FROM dual;
 OPEN pc_ref2 FOR SELECT '-' FROM dual;
 OPEN pc_ref3 FOR SELECT '-' FROM dual;
 OPEN pc_ref4 FOR SELECT '-' FROM dual;
 OPEN pc_ref5 FOR SELECT '-' FROM dual;

 SELECT COUNT(DISTINCT(a.DOVIZ_KODU))
 INTO ls_count
 FROM cbs_vw_hesap_izleme a,
 CBS_DOVIZ_KODLARI dk
 WHERE musteri_no = TO_NUMBER(pn_CustomerId)
 AND durum_kodu = 'A'
 AND modul_tur_kod= 'CURRENT'
 AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
 AND a.DOVIZ_KODU=DECODE('FC','LC',Pkg_Genel.LC_al,a.DOVIZ_KODU)
 AND a.DOVIZ_KODU<>DECODE('FC','FC',Pkg_Genel.LC_al,'ALL')
 AND dk.DOVIZ_KODU = a.DOVIZ_KODU;

 IF (ls_count < 2) THEN
 RETURN '350';
 END IF;
 RETURN ls_returncode;
END;

/******************************************************************************
 NAME : ParityControl
 Prepared By : Almas Nurhozhaev
 Date : 07.07.2008
 Purpose : Control Parity, of not OK raise error
 ******************************************************************************/
FUNCTION ParityControl(p_fromaccount IN VARCHAR2,
 p_toaccount IN VARCHAR2,
 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ls_amount VARCHAR2(100);
BEGIN
 OPEN pc_ref FOR SELECT SYSDATE FROM dual;

 IF ((p_fromaccount <> 'USD') AND (p_fromaccount <> 'EUR') AND (p_fromaccount <> 'GBP') AND (p_fromaccount <> 'CHF') AND (p_fromaccount <> 'RUB') AND (p_fromaccount <> 'KGS')) THEN
 RETURN '733';
 END IF;

 IF ((p_toaccount <> 'USD') AND (p_toaccount <> 'EUR') AND (p_toaccount <> 'GBP') AND (p_toaccount <> 'CHF') AND (p_toaccount <> 'RUB') AND (p_toaccount <> 'KGS')) THEN --ernestk 22052014 cqdb00001041 run and kgs check fix
 RETURN '733';
 END IF;

 SELECT Pkg_Soa_Common.IntCalculateParity(p_fromaccount,p_toaccount)
 INTO ls_amount
 FROM dual;

 OPEN pc_ref FOR SELECT ls_amount FROM dual;

 RETURN ls_returncode;
END;

/******************************************************************************
 NAME : IntCalculateParity
 Prepared By : Almas Nurhozhaev
 Date : 07.07.2008
 Purpose : Calculates the Parity
 ******************************************************************************/
FUNCTION IntCalculateParity(p_fromaccount IN VARCHAR2,
 p_toaccount IN VARCHAR2) RETURN NUMBER IS
BEGIN
 IF ( Pkg_Kur_Rezervasyon.sf_base_doviz_hangisi(p_fromaccount,p_toaccount) = p_fromaccount) THEN
    RETURN ROUND(Pkg_Kur_Rezervasyon.CalculateParity(p_fromaccount,p_toaccount,'S'),5);
 ELSE
    RETURN ROUND(Pkg_Kur_Rezervasyon.CalculateParity(p_fromaccount,p_toaccount,'A'),5);
 END IF;
END;
/******************************************************************************
 NAME : FUNCTION GetCustomerPrefixCode
 Prepared By : Muzaffar Khalyknazarov
 Date : 21.12.2007
 Purpose : Get Customer Prefix Code
******************************************************************************/
 FUNCTION GetCustomerPrefixCode(pn_customerno VARCHAR2) RETURN NUMBER
 IS
 ln_resident NUMBER;
 ln_returncode NUMBER;

 BEGIN
     SELECT YERLESIM_KOD
     INTO ln_resident
     FROM CBS_MUSTERI
     WHERE musteri_no = TO_NUMBER(pn_customerno);

     IF ln_resident=1 THEN
     ln_returncode:=1419;
     ELSE
     ln_returncode:=1429;
     END IF;

 RETURN ln_returncode;
 EXCEPTION
 WHEN OTHERS THEN
     Log_At('GetCustomerPrefixCode',SQLERRM);
     RAISE_APPLICATION_ERROR(ln_returncode,SQLERRM);
 RETURN '999';
 END;

/******************************************************************************
   NAME       : FUNCTION  ChangeCustomerInfo
   Created By : Almas Nurkhozhayev
   Date       : 18.12.09
   Purpose    : Change Address Info
******************************************************************************/
FUNCTION ChangeCustomerInfo(pn_person_id  IN VARCHAR2,
                            ps_address    IN VARCHAR2,
                            pn_telnumber IN VARCHAR2,
                            pn_mobnumber IN VARCHAR2,
                            ps_email IN VARCHAR2,
                            pn_tel_kod IN VARCHAR2,
                            pn_gsm_kod IN VARCHAR2,
                            ps_ekstre_adres_kod IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     pn_islem_kod NUMBER := 1001;
     pc_modul_tur_kod VARCHAR2(10) := 'CUSTOMER';
     pc_urun_tur_kod VARCHAR2(10) := 'CORPORATE';
     pc_urun_sinif_kod VARCHAR2(10) := 'GENERAL';
     ps_BOLUM_KODU VARCHAR2(3);
     pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_rol NUMBER:=7777;
     pc_kasa_kod NUMBER;
     pc_doviz_kod VARCHAR(10);
     pc_hesap_numara NUMBER;
     pn_tx_no CBS_MUSTERI_GUNCEL_ADRES.tx_no%TYPE;
     ls_returncode VARCHAR2(3):='000';
     ln_customer_id number;
     
     ln_count number;
BEGIN
     OPEN pc_ref FOR SELECT SYSDATE FROM dual;

     select customer_id into ln_customer_id
     from corpint.tbl_person
     where person_id=pn_person_id;

     pn_tx_no :=Pkg_Tx.islem_no_al;
     ps_BOLUM_KODU:=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(ln_customer_id));
     pc_bolum_kodu:=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(ln_customer_id));
     pc_amir_bolum_kodu:=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(ln_customer_id));

     Pkg_Musteri.sp_musteri_urun_sinif_al(TO_NUMBER(ln_customer_id),pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);

     UPDATE CBS_MUSTERI_GUNCEL_ADRES g
     SET
         g.TEL_ALAN_KOD = pn_tel_kod,
         g.TEL_NO = pn_telnumber,
         g.GSM_ALAN_KOD = pn_gsm_kod,
         g.GSM_NO = pn_mobnumber,
         g.EMAIL = ps_email,
         g.ADRES = ps_address
     WHERE g.TX_NO = pn_tx_no
     AND g.ADRES_KOD = ps_ekstre_adres_kod;

INSERT INTO CBS_MUSTERI_GUNCELLENEN(
      tx_no, musteri_no , musteri_tipi_kod , dk_grup_kod , isim
     , ikinci_isim , soyadi , dogum_tarihi , dogum_yeri , dogum_il_kod
     , cinsiyet_kod , baba_adi , anne_adi , anne_kizlik_soyadi , meslek_kod
     , egitim_kod , medeni_hal_kod , ticari_unvan , hesap_ucreti_f , cek_karnesi_f
     , personel_sicil_no , yerlesim_kod , ozel_kategori_kod , vergi_muaf_kod , vergi_dairesi_adi
     , vergi_no , tesvik_kod , uyruk_kod , kimlik_kod , tc_kimlik_no
     , nufus_cuzdani_seri_no , pasaport_no , ehliyet_belge_no , il_kod , ilce_kod
     , mahalle_koy , cilt_no , aile_sira_no , sira_no , verildigi_yer
     , verildigi_tarih , sektor_kod , finans_kod , ticari_sicil_no , extre_adres_kod
     , serbest_bolge_izin_tarihi , serbest_bolge_izin_no , pazarlama_sorumlusu_sicil_no_1
     , pazarlama_sorumlusu_sicil_no_2 , grup_kod
     , bic_kod , swift_mesaj_kod , reuters_info_page , reuters_dealing_kod ,yaratan_kullanici_kodu ,
       yaratildigi_tarih ,modul_tur_kod, urun_tur_kod, urun_sinif_kod, eski_musteri_no,
          sektor_alt1_kodu,sektor_alt2_kodu,rating_kodu,bolum_kodu,gecerlilik_tarihi, vergi_daire_kodu,
       durum_kodu,vat_seri_no,vat_sira_no,okpo_code,
       manager_name, manager_surname, manager_patronymic_name, manager_country_code,manager_resident_code,
       second_manager_name, vergi_zorunlumu, sosyal_fon_no,ekstre_ucreti_alinsin,
       working_basis, patent_no, patent_expiry_date,legal_form_code,external_acct_no,lokal_unvan,company_of_the_staff,
       report_customer_type,fx_convert, risk_level_code, risk_assesment_date,
       isim_eng,ikinci_isim_eng,soyadi_eng      --Sevalb 17102012 6270_Automatic loading of customer information from CBS to Card system
        )
    select
       pn_tx_no,musteri_no ,  musteri_tipi_kod , dk_grup_kod , isim
     , ikinci_isim , soyadi , dogum_tarihi , dogum_yeri , dogum_il_kod
     , cinsiyet_kod , baba_adi , anne_adi , anne_kizlik_soyadi , meslek_kod
     , egitim_kod , medeni_hal_kod , ticari_unvan , hesap_ucreti_f , cek_karnesi_f
     , personel_sicil_no , yerlesim_kod , ozel_kategori_kod , vergi_muaf_kod , vergi_dairesi_adi
     , vergi_no , tesvik_kod , uyruk_kod , kimlik_kod , tc_kimlik_no
     , nufus_cuzdani_seri_no , pasaport_no , ehliyet_belge_no , il_kod , ilce_kod
     , mahalle_koy , cilt_no , aile_sira_no , sira_no , verildigi_yer
     , verildigi_tarih , sektor_kod , finans_kod , ticari_sicil_no , extre_adres_kod
     , serbest_bolge_izin_tarihi , serbest_bolge_izin_no , pazarlama_sorumlusu_sicil_no_1
     , pazarlama_sorumlusu_sicil_no_2 , grup_kod
     , bic_kod , swift_mesaj_kod , reuters_info_page , reuters_dealing_kod,yaratan_kullanici_kodu ,
       sysdate ,modul_tur_kod, urun_tur_kod, urun_sinif_kod    , eski_musteri_no,
         sektor_alt1_kodu,sektor_alt2_kodu,rating_kodu,bolum_kodu,gecerlilik_tarihi, vergi_daire_kodu,
      'A' ,vat_seri_no,vat_sira_no,okpo_code,
      manager_name, manager_surname, manager_patronymic_name, manager_country_code, manager_resident_code,
      second_manager_name, vergi_zorunlumu, sosyal_fon_no,ekstre_ucreti_alinsin,
      working_basis, patent_no, patent_expiry_date,legal_form_code,external_acct_no,lokal_unvan,company_of_the_staff,
      report_customer_type,fx_convert, risk_level_code, risk_assesment_date,
       isim_eng,ikinci_isim_eng,soyadi_eng      --Sevalb 17102012 6270_Automatic loading of customer information from CBS to Card system
    from   cbs_musteri
    where musteri_no =ln_customer_id ;

/* Basvuru adres bilgilerinin musteri adres tablosuna aktarilmasi */
    INSERT INTO CBS_MUSTERI_GUNCEL_ADRES
     (  tx_no , adres_kod , adres , semt , il_kod
     , posta_kod , ulke_kod , email , tel_alan_kod , tel_no
     , gsm_alan_kod , gsm_no , fax_alan_kod , fax_no , ilk_gecerlilik_tarihi
     , son_gecerlilik_tarihi , ilce_kod ,yaratan_kullanici_kodu ,
       yaratildigi_tarih,extre_adres_kod_f ,ISYERI_UNVANI)
    SELECT
       pn_tx_no , adres_kod , ps_address , semt , il_kod
     , posta_kod , ulke_kod , ps_email , pn_tel_kod , pn_telnumber
     , pn_gsm_kod , pn_mobnumber , fax_alan_kod , fax_no , ilk_gecerlilik_tarihi
     , son_gecerlilik_tarihi , ilce_kod,yaratan_kullanici_kodu ,
       sysdate,extre_adres_kod_f,ISYERI_UNVANI
    FROM CBS_MUSTERI_ADRES
    WHERE musteri_no =ln_customer_id ;

/* Basvuru dokuman bilgilerinin musteri dokuman tablosuna aktarilmasi */

    INSERT INTO CBS_MUSTERI_GUNCEL_DOKUMAN(
      tx_no , sira_no , dokuman_adi , alindi_kutusu_f , duzenlenme_tarihi
    , gecerlilik_tarihi,yaratan_kullanici_kodu ,
      yaratildigi_tarih )
    SELECT
      pn_tx_no , sira_no , dokuman_adi , alindi_kutusu_f , duzenlenme_tarihi
      , gecerlilik_tarihi,yaratan_kullanici_kodu ,
       yaratildigi_tarih
    FROM  CBS_MUSTERI_DOKUMAN
    WHERE musteri_no =ln_customer_id ;

/* Basvuru not bilgilerinin musteri not tablosuna aktarilmasi */
    INSERT INTO CBS_MUSTERI_GUNCEL_NOTLAR(
      tx_no , sira_no , alinan_notlar , giris_tarihi , kullanici_kodu
    , gorusme_bilgileri , gorusme_notu , katilanlar , gorusme_tarihi , baslangic_saati
    , bitis_saati ,yaratan_kullanici_kodu ,
      yaratildigi_tarih,not_tipi )
    SELECT
      pn_tx_no , sira_no , alinan_notlar , giris_tarihi , kullanici_kodu
    , gorusme_bilgileri , gorusme_notu , katilanlar , gorusme_tarihi , baslangic_saati
    , bitis_saati ,yaratan_kullanici_kodu ,
      yaratildigi_tarih     ,not_tipi
    FROM  CBS_MUSTERI_NOTLAR
    WHERE musteri_no =ln_customer_id ;

/* Basvuru ortaklik bilgilerinin musteri ortak tablosuna aktarilmasi */

    /*INSERT INTO CBS_MUSTERI_GUNCEL_ORTAKLIK (
      tx_no , sira_no , isim , orani , tutari
    , doviz_kod , tarih , ulke_kod ,yaratan_kullanici_kodu ,
      yaratildigi_tarih )
    SELECT
      pn_tx_no , sira_no , isim , orani , tutari
    , doviz_kod , tarih , ulke_kod,yaratan_kullanici_kodu ,
      yaratildigi_tarih
    FROM
    CBS_MUSTERI_ORTAKLIK
    WHERE musteri_no =ln_customer_id ;*/

/* Contact bilgileri Sevalb 06022007 */
   insert into cbs_musteri_guncel_kontak(TX_NO, SIRA_NO, AD, SOYAD, EMAIL, WEB_SITE, TEL_ALAN_KOD, TEL_NO, GSM_ALAN_KOD, GSM_NO, FAX_ALAN_KOD, FAX_NO)
   select pn_tx_no, SIRA_NO, AD, SOYAD, EMAIL, WEB_SITE, TEL_ALAN_KOD, TEL_NO, GSM_ALAN_KOD, GSM_NO, FAX_ALAN_KOD, FAX_NO
   from  cbs_musteri_kontak
   WHERE musteri_no =ln_customer_id ;

     /*UPDATE CBS_MUSTERI_ADRES m
     SET
         m.TEL_ALAN_KOD = pn_tel_kod,
         m.TEL_NO = pn_telnumber,
         m.GSM_ALAN_KOD = pn_gsm_kod,
         m.GSM_NO = pn_mobnumber,
         m.EMAIL = ps_email,
         m.ADRES = ps_address
     WHERE  m.musteri_no = ln_customer_id
     AND m.ADRES_KOD = ps_ekstre_adres_kod;*/
     
     select count(*) into ln_count from CBS_MUSTERI_GUNCELLENEN where TX_NO=pn_tx_no;

     Pkg_Int_Api.create_transaction(pn_tx_no, pn_islem_kod,
                                     pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                     0, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                     pc_doviz_kod, ln_customer_id,pc_hesap_numara,
                                     pc_kasa_kod,1);

     Pkg_Int_Api.process_transaction(pn_tx_no);

     RETURN ls_returncode;
EXCEPTION
     WHEN OTHERS THEN
        ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        Log_At(SQLERRM,ls_returncode);
        ROLLBACK;
        OPEN pc_ref FOR SELECT SYSDATE FROM dual;
        RETURN ls_returncode;
END;

PROCEDURE NB_POSITION_REPORT(p_date in date)-- changed in parametre to date CQ001350 UrmatA 20141219
IS
     v_recipient varchar2(240);
     v_copy      varchar2(240);
     v_bcopy    varchar2(240);
     v_from     varchar2(240);
    CURSOR c1 IS
    select filial,
       DDATE,
       KODV,
       NBS, 
       sum(SUMAV1) SUMAV1,
       sum(SUMPV1) SUMPV1,
       sum(SUMAV2) SUMAV2,
       sum(SUMPV2) SUMPV2,
       (SELECT DECODE(DOVIZ_TIPI,'HARD',1,'SOFT',2) D_TYPE
           FROM CBS_DOVIZ_KODLARI
          WHERE DOVIZ_KODU = KODV) VALGR,
       null VALPOZ,
       pkg_apex.doviz_doviz_karsilik(KODV, 'KGS', p_date, 1,1,NULL,NULL,'N','A') KURS_V -- removed excess to date function  CQ001350 UrmatA 20141220
from 
(select '75' filial, 
        p_date DDATE, 
        DOVIZ_KOD KODV, 
        substr(NUMARA,1,5) NBS,
          decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), 0, abs(sum(BAKIYE_LC))) SUMAV1, 
        decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), sum(BAKIYE_LC), 0) SUMPV1, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), 0, abs(sum(BAKIYE))) SUMAV2, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), sum(BAKIYE), 0) SUMPV2 
   from cbs_dkhesap_gunluk_bakiye 
  where yil = to_char(p_date, 'yyyy') 
    and ay = to_char(p_date, 'mm') 
    and gun = to_char(p_date, 'dd')
    and substr(numara, 1, 5) in ('11519', '11523', '21115') AND length(numara)=8 AND numara NOT IN (11519001,11519101)
    AND p_date<>pkg_apex.Banka_Tarihi_Bul()
  GROUP BY  substr(NUMARA,1,5),  DOVIZ_KOD 
  UNION ALL
  select '75' filial, 
        p_date DDATE, 
        DOVIZ_KOD KODV, 
        substr(NUMARA,1,5) NBS, 
           decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), 0, abs(sum(BAKIYE_LC))) SUMAV1, 
        decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), sum(BAKIYE_LC), 0) SUMPV1, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), 0, abs(sum(BAKIYE))) SUMAV2, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), sum(BAKIYE), 0) SUMPV2 
   from CBS_DKHESAP 
  where substr(numara, 1, 5) in ('11519', '11523', '21115') AND length(numara)=8 AND numara NOT IN (11519001,11519101)
    AND length(numara)=8 
    AND p_date=pkg_apex.Banka_Tarihi_Bul()
  GROUP BY  substr(NUMARA,1,5),  DOVIZ_KOD 
  )
group by filial, DDATE, KODV, NBS;

    r1     c1%ROWTYPE;

    attach   CLOB;
    
    /*BOM SURMALII 05.06.2018*/
    ls_json CLOB;
    ls_ret varchar2(3);
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    /*EOM*/
BEGIN

   attach := 'FILIAL'||';'||
                 'DDATE'||';'||
                 'KODV'||';'||
                 'NBS'||';'||
                 'SUMAV1'||';'||
                 'SUMPV1'||';'||
                 'SUMAV2'||';'||
                 'SUMPV2'||';'||
                 'VALGR'||';'||
                 'VALPOZ'||';'||
                 'KURS_V'||CHR(13)||CHR(10);
    OPEN c1;
    LOOP
    FETCH c1 INTO r1  ;
    EXIT WHEN c1%NOTFOUND;
        IF ( (r1.sumav1+r1.sumpv1+r1.sumav2+r1.sumpv2) != 0) THEN
            attach := attach||r1.FILIAL||';'||
                                 r1.DDATE||';'||
                                 r1.KODV||';'||
                                 r1.NBS||';'||
                                 r1.SUMAV1||';'||
                                 r1.SUMPV1||';'||
                                 r1.SUMAV2||';'||
                                 r1.SUMPV2||';'||
                                 r1.VALGR||';'||
                                 r1.VALPOZ||';'||
                                 r1.KURS_V||CHR(13)||CHR(10);
        END IF;

    END LOOP;
    CLOSE c1;

            pkg_parametre.deger('REPORT_NBKR_TREASURY_EMAIL_TO', v_recipient);
            pkg_parametre.deger('REPORT_NBKR_TREASURY_FROM', v_from);
            begin
            select substr(t.deger,2,length(t.deger)-2)
                into v_copy
            from cbs_parametre t
                where t.kod = 'REPORT_NBKR_TREASURY_COPY';
            exception
            when no_data_found then null;
            end;
            
            begin
            select substr(t.deger,2,length(t.deger)-2)
                into v_bcopy
            from cbs_parametre t
                where t.kod = 'REPORT_NBKR_TREASURY_BCOPY';
            exception
            when no_data_found then null;
            end;
    /*
    Pkg_Email.AddToEmailQueue_Atc('SUBSCRIPTION',
                                   50,
                                   v_from,
                                   v_recipient ,
                                   'VAL75'||to_char(sysdate,'dd')||' - NB Position Report - '||TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'dd.mm.yyyy'),
                                   'NB Position Report of the date : '||pkg_muhasebe.Banka_Tarihi_Bul ,
                                   'NB_Position_Report_'||TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'yyyy.mm.dd')||'.csv',
                                   attach
                                   );
    pkg_email.SendAutoMessages('');
    */
    
    /*BOM SURMALII 05.06.2018*/
    ls_json := '{';
    ls_json := ls_json || '"##BODY##":"' || 'NB Position Report of the date : '||pkg_muhasebe.Banka_Tarihi_Bul || '"}';
    ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAILCLOBATTACH(v_recipient, 'VAL75'||to_char(sysdate,'dd')||' - NB Position Report - '||TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'dd.mm.yyyy'), to_char(ls_json), 'NB_Position_Report_'||TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'yyyy.mm.dd')||'.csv', to_char(attach), pc_ref);
    /*EOM*/

    COMMIT;
    
    EXCEPTION
    WHEN OTHERS THEN
       ROLLBACK;
END;

PROCEDURE Export_TO_DBF_mail(
  p_date in date
)-- changed in parametre to date CQ001350 UrmatA 20141219
AS
-----------------------
 
-----------------------
  valBLOB    BLOB;
  korBLOB   BLOB;
  ksCLOB    CLOB;
-----------------------
 cash number;
 c_a number;
 
 v_recipient varchar2(240);
 v_copy      varchar2(240);
 v_bcopy    varchar2(240);
 v_from     varchar2(240);

BEGIN
              
  create_blob_val75( 'DBF_VAL75',valBLOB, p_date);
  create_blob_kor75('DBF_KOR75',korBLOB,p_date);
  
    IF p_date = pkg_muhasebe.Banka_Tarihi_Bul THEN
      select  sum(BAKIYE) into cash from cbs_dkhesap 
                    where 
                    numara in (select deger from cbs_parametre where kod like  'REPORT_NBKR_CASH_ACC%')  
                    and bolum_kodu in (select deger from cbs_parametre where kod like  'REPORT_NBKR_BRANCH%') 
                    and doviz_kod = (select deger from cbs_parametre where kod =  'REPORT_NBKR_CASH_DOVIZ_KOD');
                    
        select sum(bakiye) into c_a from CBS_DKHESAP
            where numara in (select deger from cbs_parametre where kod like  'REPORT_NBKR_C_A_ACC_%')
            and bolum_kodu =  (select deger from cbs_parametre where kod like  'REPORT_NBKR_C_A_BRANCH_KOD%') 
            and doviz_kod = (select deger from cbs_parametre where kod =  'REPORT_NBKR_C_A_DOVIZ_KOD');
    ELSE
        select sum(bakiye) into cash
                    from CBS_DKHESAP_GUNLUK_BAKIYE
                    where yil = to_char(p_date, 'yyyy') 
                    and ay = to_char(p_date, 'mm') 
                    and gun = to_char(p_date, 'dd')
                    and doviz_kod = (select deger from cbs_parametre where kod =  'REPORT_NBKR_CASH_DOVIZ_KOD')
                    and numara in (select deger from cbs_parametre where kod like  'REPORT_NBKR_CASH_ACC%');
       
         select sum(bakiye) into c_a from CBS_DKHESAP_GUNLUK_BAKIYE
            where yil = to_char(p_date, 'yyyy') 
            and ay = to_char(p_date, 'mm') 
            and gun = to_char(p_date, 'dd')
            and numara in (select deger from cbs_parametre where kod like  'REPORT_NBKR_C_A_ACC_%')
            and bolum_kodu =  (select deger from cbs_parametre where kod like  'REPORT_NBKR_C_A_BRANCH_KOD%') 
            and doviz_kod = (select deger from cbs_parametre where kod =  'REPORT_NBKR_C_A_DOVIZ_KOD');
    END IF;
        
            
            ksCLOB := 'c/a'||CHR(9)||c_a||CHR(13)||CHR(10)||
                            'cash'||CHR(9)||cash||CHR(13)||CHR(10);
           
            pkg_parametre.deger('REPORT_NBKR_DBF_EMAIL_TO', v_recipient);
            pkg_parametre.deger('REPORT_NBKR_DBF_EMAIL_FROM', v_from);
            begin
            select substr(t.deger,2,length(t.deger)-2)
                into v_copy
            from cbs_parametre t
                where t.kod = 'REPORT_NBKR_DBF_EMAIL_COPY';
            exception
            when no_data_found then null;
            end;
            
            begin
            select substr(t.deger,2,length(t.deger)-2)
                into v_bcopy
            from cbs_parametre t
                where t.kod = 'REPORT_NBKR_DBF_EMAIL_BCOPY';
            exception
            when no_data_found then null;
            end;
            
     Pkg_Email.SendMultipleBlobAttachments(p_to          => v_recipient ,
                                                p_cc        =>nvl(v_copy,null),
                                                p_bcc      => nvl(v_bcopy,null),
                                                p_from        =>nvl(v_from,null),
                                                p_subject     =>  'val75'||to_char(p_date,'dd')||'.dbf'||', '||'kor'||to_char(p_date,'dd')||'75.dbf'||', '||'ks75'||to_char(p_date,'dd')||'.txt',
                                                p_text_msg    => null,
                                                p_attach_name =>  'val75'||to_char(p_date,'dd')||'.dbf',
                                                p_attach_name2 =>  'kor'||to_char(p_date,'dd')||'75.dbf',
                                                p_attach_name3 => 'ks75'||to_char(p_date,'dd')||'.txt',
                                                p_attach_mime => 'image/gif',
                                                p_attach_blob => valBLOB,
                                                p_attach_blob2 => korBLOB,
                                                p_attach_blob3 => ksCLOB); 
END;

 PROCEDURE Start_Reports(Param1 IN NUMBER DEFAULT NULL) is
 tr_rep varchar2(10); 
 nbkr_rep varchar2(10);
 v_date date;
 v_day varchar2(20);
  begin
   pkg_parametre.deger('REPORT_NBKR_START_TREASURY', tr_rep);
   pkg_parametre.deger('REPORT_NBKR_START', nbkr_rep);
   
    begin
        select p_char_val1
                into v_day
            from cbs_parametre t
                where t.kod = 'REPORT_NBKR_START';
    exception
        when no_data_found then null;
    end;
   
   IF v_day = 'YESTERDAY' THEN
    v_date := pkg_muhasebe.Onceki_Banka_Tarihi_Bul;
   ELSE
    v_date := pkg_muhasebe.Banka_Tarihi_Bul;
   END IF;
   
   
      
   IF (INSTR(tr_rep, to_char(sysdate, 'HH24'))>0) THEN   
    pkg_soa_common.NB_POSITION_REPORT(pkg_muhasebe.Banka_Tarihi_Bul);
   END IF;
   
   IF  (INSTR(nbkr_rep, to_char(sysdate, 'HH24'))>0) THEN
    pkg_soa_common.EXPORT_TO_DBF_MAIL(v_date);
   END IF;
      
  end;
  
  PROCEDURE create_blob_val75(
  pv_Table     in varchar2,
  p_blob in out blob,
  p_date in date
)-- changed in parametre to date CQ001350 UrmatA 20141219
AS
-----------------------
  bBLOB      BLOB;
  
-----------------------
  r_Header    raw(32);
  r_Columns   raw(32767) := '';
-----------------------
  n_Count     PLS_INTEGER := 0;
  v_String    varchar2(4000) := '';
 
 r_Records raw(32767);
 
     cursor c1 is
select filial,
       DDATE,
       KODV,
       NBS, 
       sum(SUMAV1) SUMAV1,
       sum(SUMPV1) SUMPV1,
       sum(SUMAV2) SUMAV2,
       sum(SUMPV2) SUMPV2,
       (SELECT DECODE(DOVIZ_TIPI,'HARD',1,'SOFT',2) D_TYPE
           FROM CBS_DOVIZ_KODLARI
          WHERE DOVIZ_KODU = KODV) VALGR,
       null VALPOZ,
       pkg_apex.doviz_doviz_karsilik(KODV, 'KGS', p_date, 1,1,NULL,NULL,'N','A') KURS_V -- removed excess to date function  CQ001350 UrmatA 20141220
from 
(select '75' filial, 
        p_date DDATE, 
        DOVIZ_KOD KODV, 
        substr(NUMARA,1,5) NBS,
          decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), 0, abs(sum(BAKIYE_LC))) SUMAV1, 
        decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), sum(BAKIYE_LC), 0) SUMPV1, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), 0, abs(sum(BAKIYE))) SUMAV2, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), sum(BAKIYE), 0) SUMPV2 
   from cbs_dkhesap_gunluk_bakiye 
  where yil = to_char(p_date, 'yyyy') 
    and ay = to_char(p_date, 'mm') 
    and gun = to_char(p_date, 'dd')
    and substr(numara, 1, 5) in ('11519', '11523', '21115') AND length(numara)=8 AND numara NOT IN (11519001,11519101)
    AND p_date<>pkg_apex.Banka_Tarihi_Bul()
  GROUP BY  substr(NUMARA,1,5),  DOVIZ_KOD 
  UNION ALL
  select '75' filial, 
        p_date DDATE, 
        DOVIZ_KOD KODV, 
        substr(NUMARA,1,5) NBS, 
           decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), 0, abs(sum(BAKIYE_LC))) SUMAV1, 
        decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), sum(BAKIYE_LC), 0) SUMPV1, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), 0, abs(sum(BAKIYE))) SUMAV2, 
        decode(abs(sum(BAKIYE)), sum(BAKIYE), sum(BAKIYE), 0) SUMPV2 
   from CBS_DKHESAP 
  where substr(numara, 1, 5) in ('11519', '11523', '21115') AND length(numara)=8 AND numara NOT IN (11519001,11519101)
    AND length(numara)=8 
    AND p_date = pkg_apex.Banka_Tarihi_Bul()
  GROUP BY  substr(NUMARA,1,5),  DOVIZ_KOD 
  )
group by filial, DDATE, KODV, NBS;

 r1                  c1%rowtype;
 r2                  c1%rowtype;
 v_count          number :=0;
------------------------------------------------------------------
BEGIN
------------------------------------------------------------------ Открываем файл DBF в созданной директории и создаем временный объект BLOB

  dbms_lob.createtemporary(bBLOB, True, dbms_lob.CALL);
                
                 OPEN c1;
    LOOP
    FETCH c1 INTO r2;
    EXIT WHEN c1%NOTFOUND;
       IF ( (r2.sumav1+r2.sumpv1+r2.sumav2+r2.sumpv2) != 0) THEN
            v_count:=v_count+1;
       END IF;
    END LOOP;
    
    CLOSE c1;
                 ------------------------------------------------------------------
                ------------------------------------------------------------------ ЗАГОЛОВОК ФАЙЛА DBF
                ------------------------------------------------------------------
                ----------------------- Сигнатура (48 - Visual FoxPro) (Длина 1, Смещение 0)
                  r_Header := to_char(/*48*/3, 'FM0X');
                ----------------------- Дата последнего изменения области данных таблицы в виде ГГММДД (Длина 3, Смещение 1-3)
                  r_Header := r_Header || to_char(to_char(SYSDATE, 'YY'), 'FM0X') ||
                                          to_char(to_char(SYSDATE, 'MM'), 'FM0X') ||
                                          to_char(to_char(SYSDATE, 'DD'), 'FM0X');
                ----------------------- Количество записей в таблице (Длина 4, Смещение 4-7)
                  
                  r_Header := r_Header || UTL_RAW.reverse(to_char(v_count, 'FM0000000X'));
                ----------------------- Позиция начала области данных (Полная длина заголовка с дескрипторами полей) (Длина 2, Смещение 8-9)
                 
                  n_Count := (2 + 11*2 + 16.5) * 16;  ------ 2+:Заголовок, *2:Две строки на поле, +16.5:CHR(13) + Область нулей в 263 байта
                  r_Header := r_Header || UTL_RAW.reverse(to_char(n_Count, 'FM000X'));
                ----------------------- Длина одной строки (записи) данных, включая флаг удаления (Длина 2, Смещение 10-11)
                  
                  r_Header := r_Header || UTL_RAW.reverse(to_char(113, 'FM000X'));
                ----------------------- Зарезервировано (Длина 16, Смещение 12-27) + Табличный флаг (Длина 1, Смещение 28)
                  r_Header := r_Header || RPAD('0', 17*2, '0');
                ----------------------- Идентификатор кодовой страницы файла (dBASE IV, Visual FoxPro, XBase) (201 - 1251 Russian Windows) (Длина 1, Смещение 29)
                  r_Header := r_Header || to_char(201, 'FM0X');
                ----------------------- Зарезервировано (всегда 0) (Длина 2, Смещение 30-31)
                  r_Header := r_Header || RPAD('0', 2*2, '0');
                ------------------------------------------------------------------ Пишем заголовок в BLOB
                  dbms_lob.writeappend(bBLOB, UTL_RAW.length(r_Header), r_Header);
                ------------------------------------------------------------------
                ------------------------------------------------------------------ ДЕСКРИПТОРЫ ПОЛЕЙ (Длина 32 каждого)
                ------------------------------------------------------------------
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('FILIAL'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(9 + 1, 'FM0X') || to_char(0, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('DAT'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('D') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(8, 'FM0X') || RPAD('0', 1*2, '0');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('KODV'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('C') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(9, 'FM0X') || RPAD('0', 1*2, '0');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('NBS'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(9 + 1, 'FM0X') || to_char(0, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('SUMAV1'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(11 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('SUMPV1'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(11 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('SUMAV2'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(10 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('SUMPV2'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(10 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('VALGR'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(9 + 1, 'FM0X') || to_char(0, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('VALPOZ'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('C') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(9, 'FM0X') || RPAD('0', 1*2, '0');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('KURSV'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(9 + 1, 'FM0X') || to_char(4, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  
                ----------------------- Терминальный байт CHR(13) (Длина 1) + Область нулей в 263 байта (Visual FoxPro) (Длина 263)
                  r_Columns := r_Columns || to_char(13, 'FM0X') || RPAD('0', 263*2, '0');
                ------------------------------------------------------------------ Пишем описание полей в BLOB
                  dbms_lob.writeappend(bBLOB, UTL_RAW.length(r_Columns), r_Columns);
                ------------------------------------------------------------------
                ------------------------------------------------------------------ ЗАПИСЬ ДАННЫХ
                ------------------------------------------------------------------
 OPEN c1;
    LOOP
    FETCH c1 INTO r1;
    EXIT WHEN c1%NOTFOUND;
        IF ( (r1.sumav1+r1.sumpv1+r1.sumav2+r1.sumpv2) != 0) THEN
                r_Records := to_char(32, 'FM0X');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.FILIAL,',','.')), '20'), 20, '20');
                r_Records := r_Records || nvl(UTL_RAW.cast_to_raw(to_char(r1.DDATE, 'YYYYMMDD' )), '2020202020202020');
                r_Records := r_Records || RPAD(nvl(UTL_RAW.cast_to_raw(r1.KODV), '20'), 18, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.NBS,',','.')), '20'), 20, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.SUMAV1,',','.')), '20'), 24, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.SUMPV1,',','.')), '20'), 24, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.SUMAV2,',','.')), '20'), 22, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.SUMPV2,',','.')), '20'), 22, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.VALGR,',','.')), '20'), 20, '20');
                r_Records := r_Records || RPAD(nvl(UTL_RAW.cast_to_raw(r1.VALPOZ), '20'), 18, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.KURS_V,',','.')), '20'), 20, '20');
                dbms_lob.writeappend(bBLOB, UTL_RAW.length(r_Records), r_Records);
        END IF;     
    END LOOP;
    dbms_lob.writeappend(bBLOB, utl_raw.length(to_char(26, 'FM0X')), to_char(26, 'FM0X'));
    CLOSE c1;
      p_blob := bBLOB;
END;

PROCEDURE create_blob_kor75(
  pv_Table     in varchar2,
  p_blob in out blob,
  p_date in date
)-- changed in parametre to date CQ001350 UrmatA 20141219
AS
-----------------------
  bBLOB      BLOB;
  
-----------------------
  r_Header    raw(32);
  r_Columns   raw(32767) := '';
-----------------------
  n_Count     PLS_INTEGER := 0;
  v_String    varchar2(4000) := '';
 
 r_Records raw(32767);
 
     cursor c1 is
SELECT filial, DDATE, SUM(NAL_V) NAL_V, SUM(NAL_D) NAL_D, SUM(BNAL_V) BNAL_V, SUM(BNAL_D) BNAL_D
FROM (
select '70075' filial, 
       p_date DDATE, 
      (select abs(sum(bakiye_lc))
       from cbs_dkhesap_gunluk_bakiye       
       where yil = to_char(p_date, 'yyyy') 
             and ay = to_char(p_date, 'mm') 
             and gun = to_char(p_date, 'dd') 
             and substr(numara, 1, 5) = '10001'
                and doviz_kod <> 'KGS') NAL_V, 
      (select abs(SUM(bakiye_lc))
       from cbs_dkhesap_gunluk_bakiye       
       where yil = to_char(p_date, 'yyyy') 
             and ay = to_char(p_date, 'mm') 
             and gun = to_char(p_date, 'dd') 
             and substr(numara, 1, 5) = '10001' 
                and doviz_kod = 'USD') NAL_D,
      (select abs(SUM(bakiye_lc))
       from cbs_dkhesap_gunluk_bakiye       
       where yil = to_char(p_date, 'yyyy') 
             and ay = to_char(p_date, 'mm') 
             and gun = to_char(p_date, 'dd') 
             and substr(numara, 1, 7) in ('1010200', '1010201')
                and doviz_kod <> 'KGS') BNAL_V, 
      (select abs(SUM(bakiye_lc))
       from cbs_dkhesap_gunluk_bakiye       
       where yil = to_char(p_date, 'yyyy') 
             and ay = to_char(p_date, 'mm') 
             and gun = to_char(p_date, 'dd') 
             and substr(numara, 1, 7) in ('1010200', '1010201')
                and doviz_kod = 'USD') BNAL_D
  from DUAL WHERE p_date<>pkg_apex.Banka_Tarihi_Bul
UNION ALL
select '70075' filial, 
       p_date DDATE, 
      (select abs(sum(bakiye_lc))
       from CBS_DKHESAP   
       WHERE substr(numara, 1, 5) = '10001'
                and doviz_kod <> 'KGS') NAL_V, 
      (select abs(SUM(bakiye_lc))
       from CBS_DKHESAP
       where substr(numara, 1, 5) = '10001' 
                and doviz_kod = 'USD') NAL_D,
      (select abs(SUM(bakiye_lc))
       from CBS_DKHESAP
       where substr(numara, 1, 7) in ('1010200', '1010201')
                and doviz_kod <> 'KGS') BNAL_V, 
      (select abs(SUM(bakiye_lc))
       from CBS_DKHESAP
       where substr(numara, 1, 7) in ('1010200', '1010201')
                and doviz_kod = 'USD') BNAL_D
  from DUAL WHERE p_date=pkg_apex.Banka_Tarihi_Bul)
GROUP BY filial,  DDATE;

 r1                  c1%rowtype;
 r2                  c1%rowtype;
 v_count          number :=0;
------------------------------------------------------------------
BEGIN
------------------------------------------------------------------ Открываем файл DBF в созданной директории и создаем временный объект BLOB

  dbms_lob.createtemporary(bBLOB, True, dbms_lob.CALL);
                
                 OPEN c1;
    LOOP
    FETCH c1 INTO r2;
    EXIT WHEN c1%NOTFOUND;
       v_count:=v_count+1;
   END LOOP;
    
    CLOSE c1;
                 ------------------------------------------------------------------
                ------------------------------------------------------------------ ЗАГОЛОВОК ФАЙЛА DBF
                ------------------------------------------------------------------
                ----------------------- Сигнатура (48 - Visual FoxPro) (Длина 1, Смещение 0)
                  r_Header := to_char(/*48*/3, 'FM0X');
                ----------------------- Дата последнего изменения области данных таблицы в виде ГГММДД (Длина 3, Смещение 1-3)
                  r_Header := r_Header || to_char(to_char(SYSDATE, 'YY'), 'FM0X') ||
                                          to_char(to_char(SYSDATE, 'MM'), 'FM0X') ||
                                          to_char(to_char(SYSDATE, 'DD'), 'FM0X');
                ----------------------- Количество записей в таблице (Длина 4, Смещение 4-7)
                  
                  r_Header := r_Header || UTL_RAW.reverse(to_char(v_count, 'FM0000000X'));
                ----------------------- Позиция начала области данных (Полная длина заголовка с дескрипторами полей) (Длина 2, Смещение 8-9)
                 
                  n_Count := (2 + 6*2 + 16.5) * 16;  ------ 2+:Заголовок, *2:Две строки на поле, +16.5:CHR(13) + Область нулей в 263 байта
                  r_Header := r_Header || UTL_RAW.reverse(to_char(n_Count, 'FM000X'));
                ----------------------- Длина одной строки (записи) данных, включая флаг удаления (Длина 2, Смещение 10-11)
                  
                  r_Header := r_Header || UTL_RAW.reverse(to_char(83, 'FM000X'));
                ----------------------- Зарезервировано (Длина 16, Смещение 12-27) + Табличный флаг (Длина 1, Смещение 28)
                  r_Header := r_Header || RPAD('0', 17*2, '0');
                ----------------------- Идентификатор кодовой страницы файла (dBASE IV, Visual FoxPro, XBase) (201 - 1251 Russian Windows) (Длина 1, Смещение 29)
                  r_Header := r_Header || to_char(201, 'FM0X');
                ----------------------- Зарезервировано (всегда 0) (Длина 2, Смещение 30-31)
                  r_Header := r_Header || RPAD('0', 2*2, '0');
                ------------------------------------------------------------------ Пишем заголовок в BLOB
                  dbms_lob.writeappend(bBLOB, UTL_RAW.length(r_Header), r_Header);
                ------------------------------------------------------------------
                ------------------------------------------------------------------ ДЕСКРИПТОРЫ ПОЛЕЙ (Длина 32 каждого)
                ------------------------------------------------------------------
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('FILIAL'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(9 + 1, 'FM0X') || to_char(0, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('DATD'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('D') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(8, 'FM0X') || RPAD('0', 1*2, '0');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                                                    
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('NAL_V'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(15 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('NAL_D'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(15 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('BNAL_V'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(15 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                  r_Columns := r_Columns || RPAD(UTL_RAW.cast_to_raw('BNAL_D'), 11*2, '0');
                  r_Columns := r_Columns || UTL_RAW.cast_to_raw('N') || RPAD('0', 4*2, '0');
                  r_Columns := r_Columns || to_char(15 + 1, 'FM0X') || to_char(2, 'FM0X');
                  r_Columns := r_Columns || RPAD('0', 14*2, '0');
                  
                           
                  
                ----------------------- Терминальный байт CHR(13) (Длина 1) + Область нулей в 263 байта (Visual FoxPro) (Длина 263)
                  r_Columns := r_Columns || to_char(13, 'FM0X') || RPAD('0', 263*2, '0');
                ------------------------------------------------------------------ Пишем описание полей в BLOB
                  dbms_lob.writeappend(bBLOB, UTL_RAW.length(r_Columns), r_Columns);
                ------------------------------------------------------------------
                ------------------------------------------------------------------ ЗАПИСЬ ДАННЫХ
                ------------------------------------------------------------------
 OPEN c1;
    LOOP
    FETCH c1 INTO r1;
    EXIT WHEN c1%NOTFOUND;
                r_Records := to_char(32, 'FM0X');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.FILIAL,',','.')), '20'), 20, '20');
                r_Records := r_Records || nvl(UTL_RAW.cast_to_raw(to_char(r1.DDATE, 'YYYYMMDD' )), '2020202020202020');
                --r_Records := r_Records || nvl(UTL_RAW.cast_to_raw(to_char(r1.DDATE, 'YYYYMMDD' )), '2020202020202020');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.NAL_V,',','.')), '20'), 32, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.NAL_D,',','.')), '20'), 32, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.BNAL_V,',','.')), '20'), 32, '20');
                r_Records := r_Records || LPAD(nvl(UTL_RAW.cast_to_raw(replace(r1.BNAL_D,',','.')), '20'), 32, '20');
                dbms_lob.writeappend(bBLOB, UTL_RAW.length(r_Records), r_Records);
            
    END LOOP;
    dbms_lob.writeappend(bBLOB, utl_raw.length(to_char(26, 'FM0X')), to_char(26, 'FM0X'));
    CLOSE c1;
      p_blob := bBLOB;
END;


/******************************************************************************
   NAME       : FUNCTION  text_translation
   Created By : Victor Kirsanov
   Date       : 11.12.14
   Purpose    : Translation
******************************************************************************/

FUNCTION text_translation (ps_string VARCHAR2, ps_lang VARCHAR2) RETURN VARCHAR2 IS
            ls_text VARCHAR2(2048);
            
             
BEGIN
SELECT b.translation
INTO ls_text
FROM CBS_LABELS a
LEFT JOIN CBS_LABELS_TRANSLATION b ON a.id = b.id
WHERE UPPER(TRIM(a.text)) = UPPER(TRIM(ps_string)) AND UPPER(TRIM(b.lang)) = UPPER(TRIM(ps_lang))
AND ROWNUM = 1;
RETURN NVL(ls_text, ps_string);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
    RETURN ps_string;
END;

/******************************************************************************
   NAME       : FUNCTION  ChangeNotificationInfo
   Created By : Adilet Kachkeev
   Date       : 10.03.15
   Purpose    : Change Notification settings
******************************************************************************/
FUNCTION ChangeNotificationInfo(ps_customer_id   IN VARCHAR2,
                            ps_status    IN VARCHAR2,
                            ps_frequency IN VARCHAR2,
                            ps_outflows IN VARCHAR2,
                            ps_inflows IN VARCHAR2,
                            ps_other IN VARCHAR2,
                            ps_ads IN VARCHAR2,
                            ps_email IN VARCHAR2,
                            ps_sms IN VARCHAR2,
                            ps_push IN VARCHAR2,
                            ps_lang IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     pn_islem_kod NUMBER := 7575;
     pc_modul_tur_kod VARCHAR2(10) := 'CUSTOMER';
     pc_urun_tur_kod VARCHAR2(10) := 'CORPORATE';
     pc_urun_sinif_kod VARCHAR2(10) := 'GENERAL';
     ps_BOLUM_KODU VARCHAR2(3);
     pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_rol NUMBER:=7777;
     pc_kasa_kod NUMBER;
     pc_doviz_kod VARCHAR(10);
     pc_hesap_numara NUMBER;
     pn_tx_no CBS_CUSTOMER_NOTIFICATION_TX.tx_no%TYPE;
     ls_returncode VARCHAR2(3):='000';
     
BEGIN
     OPEN pc_ref FOR SELECT SYSDATE FROM dual;

     pn_tx_no :=Pkg_Tx.islem_no_al;
     ps_BOLUM_KODU:=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(ps_customer_id));
     pc_bolum_kodu:=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(ps_customer_id));
     pc_amir_bolum_kodu:=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(ps_customer_id));

     Pkg_Musteri.sp_musteri_urun_sinif_al(TO_NUMBER(ps_customer_id),pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);

/* Creating updated list of notification settings */
    INSERT INTO CBS_CUSTOMER_NOTIFICATION_TX
     (  tx_no, customer_no, status, frequency, outflows, 
        inflows, other, ads, email, sms, push, lang)
    VALUES
     ( pn_tx_no, to_number(ps_customer_id), ps_status, 
        ps_frequency, ps_outflows, ps_inflows, ps_other, 
        ps_ads, ps_email, ps_sms, ps_push,ps_lang);

     Pkg_Int_Api.create_transaction(pn_tx_no, pn_islem_kod,
                                     pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                     0, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                     pc_doviz_kod, to_number(ps_customer_id), pc_hesap_numara,
                                     pc_kasa_kod,1);

     Pkg_Int_Api.process_transaction(pn_tx_no);

     RETURN ls_returncode;
EXCEPTION
     WHEN OTHERS THEN
        ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        Log_At('ChangeNotificationInfo', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        ROLLBACK;
        OPEN pc_ref FOR SELECT SYSDATE FROM dual;
        RETURN ls_returncode;
END;

/******************************************************************************
   NAME       : PROCEDURE CheckCountryLimits
   Created By : Urmat Aymambetov
   Date       : 05.11.2015
   Purpose    : Check Country Limits
******************************************************************************/
PROCEDURE CheckCountryLimits IS
    v_limit number;
    v_country varchar2(30);
    v_num number;
    v_dif number;
    v_recipient varchar2(240);
    v_recipient_copy varchar2(240);
    v_from varchar2(240);
    v_depoi number;
    v_curr varchar2(10);
    
    lc_message_body CBS_EMAIL_MESSAGES.BODY_CONTENT%TYPE;
    ls_message_subject CBS_EMAIL_MESSAGES.SUBJECT%TYPE;
    
    ls_json CLOB;
    ls_ret VARCHAR2(3);
    --recip corpint2.pkg_notification.RecipientList;
BEGIN
    pkg_parametre.deger('CN_LIMIT_EMAIL_TO', v_recipient);
    pkg_parametre.deger('CN_LIMIT_EMAIL_TO_COPY', v_recipient_copy);
    pkg_parametre.deger('CN_LIMIT_EMAIL_FROM', v_from);
    ls_message_subject := 'Country Limit Notification '||to_char(sysdate, 'dd/mm/yyyy');
    --recip := corpint2.pkg_notification.RecipientList(v_recipient,v_recipient_copy); 
    
FOR r IN
    (select m.uyruk_kod,  abs(sum(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(h.doviz_kodu,'USD',null,b.bakiye))) bakiye 
    from cbs_hesap h, cbs_hesap_bakiye b, cbs_musteri m
    where
    1=1
    and H.MUSTERI_NO = M.MUSTERI_NO
    and H.MUSTERI_DK_NO in ('10101000', '10102000', '10102010')
    and H.HESAP_NO = B.HESAP_NO
    group by m.uyruk_kod)
LOOP 
    v_limit:=0;
    v_num :=0;
    v_dif :=0;
    v_depoi :=0;
    v_country :='';
    v_curr :='';
    select count(*) into v_num from
                        cbs_parametre where kod like '%COUNTRY_LIMIT%'
                        and substr(kod,instr(kod,'_',-1)+1) = r.uyruk_kod;
    IF v_num >0 THEN
        select substr(kod,1,instr(kod,'_')-1) into v_curr from 
                        cbs_parametre where kod like '%COUNTRY_LIMIT%'
                        and substr(kod,instr(kod,'_',-1)+1) = r.uyruk_kod;
        pkg_parametre.deger(v_curr||'_COUNTRY_LIMIT_'||r.uyruk_kod, v_limit);
        v_limit := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(v_curr,'USD',null,v_limit);
    END IF;
         
                        
    select sum(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(d.doviz_kodu,'USD',null,d.tutar)) into v_depoi from cbs_vw_depo d, cbs_musteri m
        where D.BANKA_MUSTERI_NO = M.MUSTERI_NO
    and D.DURUM_KODU = 'A'
    and M.UYRUK_KOD = r.uyruk_kod
    and (0<INSTR(D.REFERANS,'LND'));
    
    IF (v_limit > 0 and v_limit + 1 < (r.bakiye + nvl(v_depoi,0))) THEN -- limit is increased by one value to avoid triggering a notification in excess of less 1 CQ005409 UrmatA 20160305
        v_dif:= round((r.bakiye + nvl(v_depoi,0)) - v_limit,2);
        select C.ACIKLAMA into v_country from  cbs_uyruk_kodlari c where
        C.UYRUK_KODU = r.uyruk_kod;
        -- new version of sending email  CQ005409 UrmatA 20160305           
            ls_json := '{';
            ls_json := ls_json || '"#V_COUNTRY#":"'|| v_country ||'",';           
            ls_json := ls_json || '"#V_DIF#":"'|| to_char(v_dif) ||'",';
            ls_json := ls_json || '"#V_LIQUIDITY_SUM#":"'|| trim(to_char(round(r.bakiye,2))) ||'",';  
                      
            ls_json := ls_json || '"#V_DEPOI#":"'||to_char(nvl(v_depoi,0)) ||'",';           
            ls_json := ls_json || '"#V_LIMIT#":"'|| to_char(round(v_limit,2)) ||'"';
            ls_json := ls_json ||  '}';
       
            --ls_ret := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUE(to_char(ls_json), ls_message_subject, v_from, recip, 'HTML', 'country_limit_email_tmpl', '', '');
    END IF;
END LOOP;

ls_message_subject := 'Bank Limit Notification '||to_char(sysdate, 'dd/mm/yyyy');

FOR r2 IN
    (select m.musteri_no, m.lokal_unvan, abs(sum(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(h.doviz_kodu,'USD',null,b.bakiye))) bakiye 
    from cbs_hesap h, cbs_hesap_bakiye b, cbs_musteri m
    where
    1=1
    and H.MUSTERI_NO = M.MUSTERI_NO
    and H.MUSTERI_DK_NO in ('10101000', '10102000', '10102010')
    and H.HESAP_NO = B.HESAP_NO
    group by M.MUSTERI_NO, m.lokal_unvan
)
LOOP 
    v_limit:=0;
    v_dif:=0;
    v_depoi:=0;
    v_curr :=0;
    begin
    select ul.fc_limit, fc_doviz_kodu into v_limit, v_curr from   -- get fc_limit instead lc_limit CQ005409 UrmatA 20160305
                        CBS_MUSTERI_URUN_LIMIT ul where ul.musteri_no = r2.musteri_no
                        and UL.URUN_GRUB_NO = 3;
    exception
        when no_data_found then
        null;
    end;
    
    select sum(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(d.doviz_kodu,v_curr,null,d.tutar)) into v_depoi from cbs_vw_depo d, cbs_musteri m -- get sum of deployment in limit currency CQ005409 UrmatA 20160305
        where D.BANKA_MUSTERI_NO = M.MUSTERI_NO
    and D.DURUM_KODU = 'A'
    and M.MUSTERI_NO = r2.musteri_no
    and (0<INSTR(D.REFERANS,'LND'));
   
    IF (v_limit > 0 and v_limit + 1 < (PKG_KUR.DOVIZ_DOVIZ_KARSILIK('USD',v_curr,null,r2.bakiye) + nvl(v_depoi,0))) THEN    -- limit is increased by one value to avoid triggering a notification in excess of less 1 CQ005409 UrmatA 20160305
        v_dif:= round((PKG_KUR.DOVIZ_DOVIZ_KARSILIK('USD',v_curr,null,r2.bakiye) + nvl(v_depoi,0)) - v_limit,2);
            -- new version of sending email  CQ005409 UrmatA 20160305                               
            ls_json := '{';
            ls_json := ls_json || '"#V_BANK#":"'|| r2.lokal_unvan ||'",';           
            ls_json := ls_json || '"#V_DIF#":"'|| to_char(v_dif) ||'",';
            ls_json := ls_json || '"#V_BANK_LIQUIDITY#":"'|| trim(to_char(round(r2.bakiye,2))) ||'",';  
                      
            ls_json := ls_json || '"#V_DEPOI#":"'||to_char(nvl(v_depoi,0)) ||'",';           
            ls_json := ls_json || '"#V_LIMIT#":"'|| to_char(round(v_limit,2)) ||'"';
            ls_json := ls_json ||  '}';
       
            --ls_ret := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUE(to_char(ls_json), ls_message_subject, v_from, recip, 'HTML', 'bank_limit_email_tmpl', '', '');
    END IF;
END LOOP;

ls_message_subject := 'Treasury operations limit Notification '||to_char(sysdate, 'dd/mm/yyyy');

FOR r3 IN
    (select sum(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(d.doviz_kodu,'USD',null,d.tutar)) bakiye, M.UYRUK_KOD
    from cbs_vw_depo d, cbs_musteri m
    where
    1=1
    and D.DURUM_KODU = 'A'
    and (0<INSTR(D.REFERANS,'LND'))
    and D.BANKA_MUSTERI_NO = M.MUSTERI_NO
    group by m.uyruk_kod
)
LOOP 
    v_limit:=0;
    v_num :=0;
    v_dif :=0;
    v_country :='';
    v_curr :='';
    select count(*) into v_num from
                        cbs_parametre where kod like '%COUNTRY_SUB_LIMIT%'
                        and substr(kod,instr(kod,'_',-1)+1) = r3.uyruk_kod;
    IF v_num >0 THEN
        select substr(kod,1,instr(kod,'_')-1) into v_curr from 
                        cbs_parametre where kod like '%COUNTRY_SUB_LIMIT%'
                        and substr(kod,instr(kod,'_',-1)+1) = r3.uyruk_kod;
        pkg_parametre.deger(v_curr||'_COUNTRY_SUB_LIMIT_'||r3.uyruk_kod, v_limit);
        v_limit := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(v_curr,'USD',null,v_limit);
    END IF;
            
    IF (v_limit > 0 and v_limit + 1 < r3.bakiye) THEN   -- limit is increased by one value to avoid triggering a notification in excess of less 1 CQ005409 UrmatA 20160305
        v_dif:= round(r3.bakiye - v_limit,2);
        select C.ACIKLAMA into v_country from  cbs_uyruk_kodlari c where
        C.UYRUK_KODU = r3.uyruk_kod;
            -- new version of sending email  CQ005409 UrmatA 20160305                               
            ls_json := '{';
            ls_json := ls_json || '"#V_COUNTRY#":"'|| v_country ||'",';           
            ls_json := ls_json || '"#V_DIF#":"'|| to_char(v_dif) ||'",';
            ls_json := ls_json || '"#V_LANDING_SUM#":"'||to_char(round(r3.bakiye,2)) ||'",';
            ls_json := ls_json || '"#V_LIMIT#":"'|| to_char(round(v_limit,2)) ||'"';
            ls_json := ls_json ||  '}';
                   
            --ls_ret := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUE(to_char(ls_json), ls_message_subject, v_from, recip, 'HTML', 'limit_of_treasury_email_tmpl', '', '');                         
    END IF;
END LOOP;

EXCEPTION
     WHEN OTHERS THEN
        Log_At('CheckCountryLimits', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/******************************************************************************
   NAME       : PROCEDURE GET_CORRECT_COMMISSION
   Created By : Panychev Anton
   Date       : 28.06.2021
   Purpose    : Correct commission in intervals
******************************************************************************/
PROCEDURE GET_CORRECT_COMMISSION(INSTITUTION IN VARCHAR2,
                                 AMOUNT IN NUMBER,
                                 AMOUNT_WITHOUT_COMMISSION IN NUMBER,
                                 USE_INTERVALS_BANK IN VARCHAR2,
                                 USE_INTERVALS_COMPANY IN VARCHAR2,                                                                  
                                 COMMISSION_TYPE_BANK IN VARCHAR2,
                                 COMMISSION_TYPE_COMPANY IN VARCHAR2,
                                 COMMISSION_AMOUNT_BANK IN OUT NUMBER,
                                 COMMISSION_AMOUNT_COMPANY IN OUT NUMBER,
                                 COMMISSION_RATE_BANK IN OUT NUMBER,
                                 COMMISSION_RATE_COMPANY IN OUT NUMBER) IS
    L_AMOUNT NUMBER := AMOUNT;
    L_COMMISSION_AMOUNT NUMBER;
    L_COMMISSION_RATE NUMBER;

    CURSOR CUR_COMMISSION(TYPE_FOR VARCHAR2, COMMISSION_CLASS VARCHAR2) IS
        SELECT COMMISSION_AMOUNT, COMMISSION_RATE
        FROM CBS_USIP_COMMISSION_AMOUNT UCA
        WHERE UCA.COMPANY_ID = INSTITUTION
        AND UCA.BEGINING_AMOUNT <= AMOUNT_WITHOUT_COMMISSION
        AND UCA.ENDING_AMOUNT >= AMOUNT_WITHOUT_COMMISSION
        AND UCA.COMMISSION_TYPE = COMMISSION_CLASS
        AND UCA.COMMISSION_TYPE_FOR = TYPE_FOR;
BEGIN
    IF USE_INTERVALS_BANK = 'E' THEN
        OPEN CUR_COMMISSION('BANK', COMMISSION_TYPE_BANK);
        FETCH CUR_COMMISSION INTO L_COMMISSION_AMOUNT, L_COMMISSION_RATE;
        CLOSE CUR_COMMISSION;
        IF COMMISSION_TYPE_BANK = 'AMOUNT' THEN
            IF L_COMMISSION_AMOUNT <> COMMISSION_AMOUNT_BANK THEN
                COMMISSION_AMOUNT_BANK := L_COMMISSION_AMOUNT;
            END IF;
        ELSE
            IF L_COMMISSION_RATE <> COMMISSION_RATE_BANK THEN
                COMMISSION_RATE_BANK := L_COMMISSION_RATE;
            END IF;
        END IF;     
    END IF;
    
    IF USE_INTERVALS_COMPANY = 'E' THEN
        OPEN CUR_COMMISSION('COMPANY', COMMISSION_TYPE_COMPANY);
        FETCH CUR_COMMISSION INTO L_COMMISSION_AMOUNT, L_COMMISSION_RATE;
        CLOSE CUR_COMMISSION;
        IF COMMISSION_TYPE_COMPANY = 'AMOUNT' THEN
            IF L_COMMISSION_AMOUNT <> COMMISSION_AMOUNT_COMPANY THEN
                COMMISSION_AMOUNT_COMPANY := L_COMMISSION_AMOUNT;
            END IF;
        ELSE
            IF L_COMMISSION_RATE <> COMMISSION_RATE_COMPANY THEN
                COMMISSION_RATE_COMPANY := L_COMMISSION_RATE;
            END IF;
        END IF;     
    END IF;    
    
    L_AMOUNT := L_AMOUNT - NVL(COMMISSION_AMOUNT_BANK, 0) - NVL(COMMISSION_AMOUNT_COMPANY, 0);
    IF COMMISSION_TYPE_BANK = 'RATE' AND COMMISSION_TYPE_COMPANY = 'RATE' THEN
        COMMISSION_AMOUNT_BANK := ROUND((L_AMOUNT * COMMISSION_RATE_BANK) / (100 + NVL(COMMISSION_RATE_BANK, 0) + NVL(COMMISSION_RATE_COMPANY, 0)),2);
        COMMISSION_AMOUNT_COMPANY := ROUND((L_AMOUNT * COMMISSION_RATE_COMPANY) / (100 + NVL(COMMISSION_RATE_BANK, 0) + NVL(COMMISSION_RATE_COMPANY, 0)),2);
    ELSIF COMMISSION_TYPE_BANK = 'RATE' THEN
        COMMISSION_AMOUNT_BANK := ROUND((L_AMOUNT * COMMISSION_RATE_BANK) / (100 + NVL(COMMISSION_RATE_BANK, 0)),2);
    ELSIF COMMISSION_TYPE_COMPANY = 'RATE' THEN
        COMMISSION_AMOUNT_COMPANY := ROUND((L_AMOUNT * COMMISSION_RATE_COMPANY) / (100 + NVL(COMMISSION_RATE_COMPANY, 0)),2);
    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        Log_At('GET_CORRECT_COMMISSION', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/*******************************************************************************
    Name        : FUNCTION getNotifPackInfoCustomer
    Prepared By : Omurchiev Esen
    Date:       : 25.02.2022 
    Base Project:  update notif pack by IB or MB
    Purpose     : Get notig packinfo
*******************************************************************************/
  FUNCTION  getNotifPackInfoCustomer(ps_customer_no in varchar2,
                                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
    ls_returncode varchar2(3):='000';
  BEGIN
  
    OPEN pc_ref FOR
    SELECT m.notif_pack FROM  CBS_MUSTERI m  WHERE  musteri_no = to_number(ps_customer_no);

    RETURN ls_returncode ;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
       log_at('ibservice','getNotifPackInfoCustomer', sqlerrm, dbms_utility.format_error_backtrace);
       raise_application_error(-20100,sqlerrm);
       open pc_ref for select sysdate from dual;
       return '999';
  END;  

END Pkg_Soa_Common;
/

