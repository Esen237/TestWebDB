create PACKAGE BODY     pkg_eft is

 gs_satir_sonu varchar2(2) := '@#'; --chr(13)||chr(10);
 gs_item_sonu  varchar2(1) := '|'; --chr(7);
/* *********************************************************************************** */
  Procedure sube_kontrol(pn_islem_no number) is
  ls_islem_tanim_kod cbs_bolum_urun_islem.islem_tanim_kod%type;
  begin
   begin
    select bui.islem_tanim_kod
      into ls_islem_tanim_kod
      from cbs_bolum_urun_islem bui, cbs_islem, cbs_zaman, cbs_limit
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum IN ('C', 'N')
	   and bui.islem_tanim_kod = cbs_islem.islem_kod --3001
       and bui.modul_tur_kod   = cbs_islem.modul_tur_kod --MODUL_TUR_KOD'EFT'
       and bui.urun_tur_kod    = cbs_islem.urun_tur_kod --URUN_TUR_KOD'EFTGL'
       and bui.urun_sinif_kod  = cbs_islem.urun_sinif_kod --URUN_SINIF_KOD'NORM'
       and bui.bolum_kodu      = pkg_baglam.bolum_kodu
       and bui.zaman_numara    = cbs_zaman.numara
		   and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
		   and bui.limit_numara = cbs_limit.numara
       and ( ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'S' and cbs_islem.doviz_kod = cbs_limit.doviz_kod
				                               and nvl(cbs_islem.tutar,0) between alt and ust)  or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'F' and cbs_islem.doviz_kod = cbs_limit.doviz_kod
				                               and nvl(cbs_islem.tutar,0) between
				                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,alt) and
					                                 pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,ust) ) or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'L' and cbs_islem.doviz_kod = cbs_limit.doviz_kod
				                               and nvl(cbs_islem.tutar,0) between
				                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,alt) and
					                                 pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,ust) ) or
	           ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'F'
				                               and nvl(cbs_islem.tutar,0) between
				                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_islem.doviz_kod,null,alt) and
					                                 pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_islem.doviz_kod,null,ust) ) or
	           ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'L'
				                               and nvl(cbs_islem.tutar,0) between
				                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_islem.doviz_kod,null,alt) and
					                                 pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_islem.doviz_kod,null,ust) ) or
	           ( cbs_limit.karsilik = 'N' )
	         );
        return;
     Exception
 	     When no_data_found Then
            Raise_application_error(-20100,pkg_hata.getUCPOINTER||'129'|| pkg_hata.getUCPOINTER);
 	     When Others Then
            Raise_application_error(-20100,pkg_hata.getUCPOINTER||'130'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
    End;

  end;
/* *********************************************************************************** */
 function oncelik_belirle(ps_mesaj_kod varchar2, pn_tutar number) return number is
 ln_oncelik cbs_eft_oncelik_belirle.oncelik%type;
 begin
   select oncelik
     into ln_oncelik
     from cbs_eft_oncelik_belirle
	where mesaj_kodu = ps_mesaj_kod
	  and pn_tutar >= min_tutar
	  and pn_tutar <= max_tutar;
  return(ln_oncelik);
    exception
	  when no_data_found then
   	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '218' || pkg_hata.getUCPOINTER);
	  when others then
   	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '219' || pkg_hata.getDELIMITER || SQLERRM  || pkg_hata.getUCPOINTER);
 end;
/* *********************************************************************************** */
  Function  eft_merkezi(ps_bolum_kodu varchar2) return boolean is
  begin
--  return true;
    if ps_bolum_kodu = '003' then
	  return true;
	else
	  return false;
    end if;
  end;
/* *********************************************************************************** */
  Function  is_eft_merkezi(ps_bolum_kodu varchar2) return number is
  begin
--  return 1;
    if ps_bolum_kodu = 'EFT' then
	  return 1;
	else
	  return 0;
    end if;
  end;
/* *********************************************************************************** */
  Function  bolum_eft_kodu(ps_bolum_kod in varchar2) return varchar2 is
  ls_eft_kodu  cbs_bolum.eft_kodu%type;

  Begin
    select eft_kodu
	  into ls_eft_kodu
	  from cbs_bolum
	 where kodu = ps_bolum_kod;
	return(ls_eft_kodu);
    exception
	  when no_data_found then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '132' || pkg_hata.getUCPOINTER);
	  when others then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '133' || pkg_hata.getDELIMITER || SQLERRM  || pkg_hata.getUCPOINTER);
  end;
/* *********************************************************************************** */
 Function mesaj_adi_al(pc_mesaj_kod in varchar2) return varchar2 is
 ls_mesaj_adi cbs_eft_mesaj_tanim.mesaj_adi%type;
 begin
   select mesaj_adi
     into ls_mesaj_adi
	 from cbs_eft_mesaj_tanim
	where mesaj_kodu = pc_mesaj_kod;
	return(ls_mesaj_adi);
   exception
	 when others then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '220' || pkg_hata.getDELIMITER || SQLERRM || pkg_hata.getUCPOINTER);

 end;
/* *********************************************************************************** */
 Function dk_hesap_kontrol(ps_bolum_kodu in varchar2, pc_dk_hesap in varchar2) return boolean is
 hesap_kullanilamaz_error exception; --211
 ust_hesap_error exception; --229
 hesap_yok_error exception; --230
 ln_cnt number;
 begin
   if length(pc_dk_hesap) < 8 then
      raise ust_hesap_error;
   end if;
   if pc_dk_hesap = '01000000' or substr(pc_dk_hesap,1,1) in ('5', '6', '7') then
      raise hesap_kullanilamaz_error;
   end if;
   select count(*)
     into ln_cnt
	 from cbs_dkhesap
    where bolum_kodu = ps_bolum_kodu
      and numara = pc_dk_hesap
 	  and althesap_mi = 'E'
	  and musterili_hesap_mi = 'H';
   if ln_cnt = 0 then
     raise hesap_yok_error;
   end if;
   return true;
   exception
	 when ust_hesap_error  then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '229' || pkg_hata.getDELIMITER || pc_dk_hesap || pkg_hata.getUCPOINTER);
	 when hesap_yok_error  then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '230' || pkg_hata.getDELIMITER || ps_bolum_kodu || pkg_hata.getDELIMITER || pc_dk_hesap || pkg_hata.getUCPOINTER);
	 when hesap_kullanilamaz_error then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '211' || pkg_hata.getDELIMITER || pc_dk_hesap || pkg_hata.getUCPOINTER);
	 when others then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '212' || pkg_hata.getDELIMITER || SQLERRM || pkg_hata.getUCPOINTER);

 end;
/* *********************************************************************************** */
 Procedure eft_tarih_kontrol(pd_tarih date) is
 my_error exception;
 begin
 	null;
 end;
/* *********************************************************************************** */
Procedure mesaj_gonder(pn_islem_no number) is
  ls_mtrn     varchar2(21);
  ls_mstype   varchar2(9);
  ls_status   varchar2(1);
  ls_stid     varchar2(3);
  ls_datetime varchar2(19);
  ln_msn      number(5);
  ls_text1    varchar2(250);
  ls_text2    varchar2(250);
  ls_text3    varchar2(30);

 begin
  ls_status   := 'N';
  ls_stid     := null;
  ls_datetime := null;
  ln_msn      := null;
  select    lpad(ltrim(rtrim(a.gonderen_banka)),4,'0')
         || lpad(ltrim(rtrim(a.gonderen_sube)),5,'0')
		 || lpad(ltrim(rtrim(to_char(a.sorgu_no))),7,'0'),
         rpad(a.mesaj_kodu,9),
		 substr(rpad(b.mesaj,530),1,250),
		 substr(rpad(b.mesaj,530),251,250),
		 substr(rpad(b.mesaj,530),501,30)
    into ls_mtrn, ls_mstype, ls_text1, ls_text2, ls_text3
	from cbs_eft a, cbs_eft_mesaj_log b
   where a.tx_no = pn_islem_no
	 and b.giris_islem_no = pn_islem_no
     and b.giris_islem_no = a.tx_no;

  insert into efthsrc (mtrn, mstype, status, stid, datetime, msn, text1, text2, text3)
               values (upper(ls_mtrn), upper(ls_mstype),  ls_status, ls_stid, ls_datetime, ln_msn,
			           upper(ls_text1), upper(ls_text2), upper(ls_text3));
 end;
/* *********************************************************************************** */
  Procedure olasi_bolum(ps_bol_kod out varchar2, ps_bol_ad out varchar2) is
   cursor c_0 is
   select b.kodu, d.eft_kodu, b.adi, b.il_kodu, c.il_adi
     from cbs_bolum_eft_bagimli a, cbs_bolum b,
          cbs_il_kodlari c, cbs_bolum d
    where a.bagli_bolum_kodu = pkg_baglam.bolum_kodu
      and b.kodu = a.bolum_kodu
      and b.il_kodu = c.il_kodu
      and d.kodu = a.bagli_bolum_kodu;
   r_0 c_0%rowtype;
   cursor c_1 is
   select count(*) as sayisi
     from cbs_bolum_eft_bagimli a, cbs_bolum b,
          cbs_il_kodlari c, cbs_bolum d
    where a.bagli_bolum_kodu = pkg_baglam.bolum_kodu
      and b.kodu = a.bolum_kodu
      and b.il_kodu = c.il_kodu
      and d.kodu = a.bagli_bolum_kodu;
   r_1 c_1%rowtype;
   begin
    open c_1;
	fetch c_1 into r_1;
	close c_1;
	ps_bol_kod := null;
	ps_bol_ad := null;
	if r_1.sayisi = 1 then
        open c_0;
    	fetch c_0 into r_0;
    	if c_0%found then
    	      ps_bol_kod := r_0.kodu;
    		  ps_bol_ad := r_0.adi;
    	else
    	  close c_0;
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '228' || pkg_hata.getUCPOINTER);
    	end if;
    	close c_0;
	end if;
   end;

/* *********************************************************************************** */
 Procedure dogrula_sonrasi_dogrula(pn_islem_no number) is
 ln_done   number;
 begin
	pkg_eft_mesaj.mesaj_olustur(pn_islem_no, ln_done);
	update cbs_eft
       set durum='2.ONAY'
	 where tx_no = pn_islem_no;
 end;
/* *********************************************************************************** */
 Procedure iptal_sonrasi_iptal_et(pn_islem_no number) is
 begin
	update cbs_eft
       set durum='IPTAL'
	 where tx_no = pn_islem_no;

  	update cbs_eft_mesaj_log
	   set durum = 'IPTAL'
	 where giris_islem_no = pn_islem_no;

 end;
/* *********************************************************************************** */
 Procedure onay_sonrasi_onayla(pn_islem_no number) is
 begin

	pkg_eft.mesaj_gonder(pn_islem_no);

  	update cbs_eft
	   set durum = 'TAMAM'
	 where tx_no = pn_islem_no;

  	update cbs_eft_mesaj_log
	   set durum = 'GONDERDIM'
	 where giris_islem_no = pn_islem_no;

 end;
/* *********************************************************************************** */
 Procedure reddetme_sonrasi_reddet(pn_islem_no number) is
   cursor c1 is
   select numara
     from cbs_fis
    where islem_numara = pn_islem_no;
    ln_fis_numara number;
 Begin
 --e?er do?rulama sonras? fi? kesildiyse iptal et
    open c1;
    loop
      fetch c1 into ln_fis_numara;
      if c1%notfound then
 	      exit;
  	   end if;
      pkg_muhasebe.fis_iptal(ln_fis_numara);
    end loop;
    close c1;

	update cbs_eft
       set durum='RED'
	 where tx_no = pn_islem_no;

  	update cbs_eft_mesaj_log
	   set durum = 'RED'
	 where giris_islem_no = pn_islem_no;

 end;
/* *********************************************************************************** */
 Procedure eft_tutar_kontrol(pn_islem_no number) is
 pn_tutar number;
 pn_masraf number;
 ln_kul_bak number;
 ln_hesap number;
 ls_b_kar varchar2(1);
 cursor c_0(pn_hesap number) is
   select bakiye_karakteri
     from cbs_hesap_bakiye
	where hesap_no = pn_hesap;

 begin
  select tutar, musteri_hesap_no
    into pn_tutar, ln_hesap
	from cbs_eft a
   where tx_no = pn_islem_no;

  if ln_hesap is not null then
   pn_masraf := pkg_masraf.toplam_masraf(pn_islem_no);
   ln_kul_bak := pkg_hesap.kullanilabilir_bakiye_al(ln_hesap);
   open c_0(ln_hesap);
   fetch c_0 into ls_b_kar;
   if c_0%notfound then
     close c_0;
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '209' || pkg_hata.getDELIMITER || to_char(ln_hesap) || pkg_hata.getUCPOINTER);
   end if;
   close c_0;
   if nvl(ls_b_kar,'P') = 'P' THEN
     if ln_kul_bak < pn_tutar + pn_masraf then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '209' || pkg_hata.getDELIMITER || to_char(ln_hesap) || pkg_hata.getUCPOINTER);
     end if;
   end if;
  end if;
 end;
/* *********************************************************************************** */
end;
/

