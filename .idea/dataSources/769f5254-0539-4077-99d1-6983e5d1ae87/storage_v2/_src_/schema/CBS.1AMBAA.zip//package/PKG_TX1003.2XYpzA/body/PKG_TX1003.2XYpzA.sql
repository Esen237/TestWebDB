create PACKAGE BODY     PKG_TX1003 IS --STEP1 Procedure Kontrol_Sonrasi(pn_islem_no number) is Begin Null; End;

    PROCEDURE KONTROL_SONRASI(PN_ISLEM_NO NUMBER)
    IS
    BEGIN
      NULL;
    END;

    PROCEDURE DOGRULAMA_SONRASI(PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN
        NULL; 
    END; 

    PROCEDURE IPTAL_SONRASI(PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN 
        NULL; 
    END; 

    PROCEDURE DOGRULAMA_IPTAL_SONRASI (PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN 
        NULL; 
    END; 

/*     FUNCTION sf_get_loan_name(pn_loan CBS_LOAN_TYPES_RAHAT.id_no%TYPE) RETURN VARCHAR2 
    IS 
        ls_loan_name VARCHAR2(20) := NULL; 
    BEGIN 
         SELECT type_name 
        INTO ls_loan_name 
        FROM CBS_LOAN_TYPES_RAHAT 
        WHERE id_no = pn_loan; 
        
        RETURN ls_loan_name ; 
        EXCEPTION 
            WHEN OTHERS THEN 
                RAISE_APPLICATI ON_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1568' || Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER); 
     return null; END;  */
        
    PROCEDURE IPTAL_ONAY_SONRASI(PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN 
        NULL; 
    END; 

    PROCEDURE IPTAL_REDDETME_SONRASI (PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN 
        NULL; 
    END; 

    PROCEDURE IPTAL_MUHASEBELESTIR_SONRASI(PN_ISLEM_NO NUMBER ) 
    IS 
    BEGIN 
        NULL; 
    END; 

    PROCEDURE BASIM_SONRASI(PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN 
        NULL; 
    END; 

    PROCEDURE ONAY_SONRASI(PN_ISLEM_NO NUMBER) 
    IS         
        ln_cust_no number;
        ls_status varchar2(15);        
    begin
    -------------------DELETE DATA---------------------------------------------------------------------------
        begin    
            select customer_no, status
            into ln_cust_no, ls_status  --GET CUSTOMER_NO AND STATUS
            from cbs_musteri_affiliates_tx
            where tx_no = pn_islem_no;
        exception
            when no_data_found then 
                ln_cust_no := null; 
                ls_status := null;   
        end;

        delete from cbs_musteri_affiliates where customer_no = ln_cust_no; --DELETE CUSTOMER

        for c_rec in (select mr.customer_no cust_no,  -- DELETE RELATED CUSTOMERS
                            ma.type type
                        from cbs_musteri_relations mr
                        left join cbs_musteri_affiliates ma
                            on mr.customer_no = ma.customer_no
                        where mr.for_customer_no = ln_cust_no)
        loop
            if c_rec.type <>'MAIN' and degree(c_rec.cust_no)=1 then --NOT DELETE OFFICIALS AND CUSTOMERS RELATED WITH OFFICALS 
                delete from cbs_musteri_affiliates where customer_no = c_rec.cust_no;
            end if;
        end loop;

        delete from cbs_musteri_relations where for_customer_no = ln_cust_no; -- DELETE RELATIONS

    -------------------INSERT CBS_MUSTERI_AFFILIATES---------------------------------------------------------------------------
        if ls_status = 'ACTIVE' then ---INSERT CUSTOMER
            insert into cbs_musteri_affiliates (customer_no, full_name, bank_relation_no, position, type)
            select customer_no, full_name, bank_relation_no, position, 'MAIN'
            from cbs_musteri_affiliates_tx
            where tx_no = pn_islem_no;
        elsif degree(ln_cust_no) > 0 then
            insert into cbs_musteri_affiliates (customer_no, full_name, bank_relation_no, position, type)
            select customer_no, full_name, 0, null, 'RELATED'
            from cbs_musteri_affiliates_tx
            where tx_no = pn_islem_no; 
        end if;

        Update_related_customers(pn_islem_no, ln_cust_no, ls_status);

-------------------INSERT CBS_MUSTERI_RELATIONS-------------------------------------
        if ls_status = 'ACTIVE' then
            insert into cbs_musteri_relations (customer_no, customer_name, bank_relation_no, for_customer_no, relation_no, tin, nationality_code, activity, bank_shares)
            select customer_no, customer_name, bank_relation_no, ln_cust_no, relation_no, tin, nationality_code,activity, bank_shares
            from cbs_family_relations_tx
            where tx_no = pn_islem_no
                and for_customer_no = ln_cust_no;

            insert into cbs_musteri_relations (customer_no, customer_name, bank_relation_no, for_customer_no, relation_no,
            english_company_name,--bom maksatt cbs-812 20.12.22
            kyrgyz_company_name,
            manager_full_name,
            tin,
            legal_form_cd,
            civil_status, 
            capital_participation,
            form_of_control, 
            economic_activity,
            reg_country,registration_no,
            paid_up_share,
            currency,
            date_of_purchase,
            date_of_sale)--eom maksatt cbs-812 20.12.22
            select customer_no, customer_name, bank_relation_no, ln_cust_no, 0, 
            english_company_name,--bom maksatt cbs-812 20.12.22
            kyrgyz_company_name,
            manager_full_name,
            tin,
            legal_form_cd,
            civil_status, 
            capital_participation,
            form_of_control, 
            economic_activity,
            reg_country,registration_no,
            paid_up_share,
            currency,
            date_of_purchase,
            date_of_sale--eom maksatt cbs-812 20.12.22
            from cbs_legal_relations_tx
            where tx_no = pn_islem_no
                and for_customer_no = ln_cust_no;
        end if; 

    END;

    PROCEDURE REDDETME_SONRASI(PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN 
        NULL; 
    END;

    PROCEDURE TAMAM_SONRASI(PN_ISLEM_NO NUMBER) 
    IS 
    BEGIN 
        NULL; 
    END; 

    PROCEDURE MUHASEBELESME(PN_ISLEM_NO NUMBER) 
    IS 
    --STEP3 
        VARCHAR_LIST PKG_MUHASEBE.VARCHAR_ARRAY; 
        NUMBER_LIST PKG_MUHASEBE.NUMBER_ARRAY; 
        DATE_LIST PKG_MUHASEBE.DATE_ARRAY; 
        BOOLEAN_LIST PKG_MUHASEBE.BOOLEAN_ARRAY; 
        LN_PLAN_NO NUMBER; 
        LN_FIS_NO NUMBER; 
        LN_TRAN_CODE NUMBER := 1003; 
        LN_ACCOUNT_NO NUMBER; 
        LN_AMOUNT NUMBER; 
        LS_EXPLANATION VARCHAR2(2000);
    BEGIN 
        NULL; 
    END; 

    FUNCTION GET_BANK_RELATION_DESCRIPTION(PN_RELATION_CODE number) RETURN VARCHAR2
    IS
        LS_RETVAL VARCHAR2(2000);
    BEGIN
        BEGIN
            SELECT DESCRIPTION_RUS --Maksatt cbs-812 29.12.2022 
            INTO LS_RETVAL 
            FROM CBS_BANK_RELATIONS
            WHERE ID = PN_RELATION_CODE;            
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                LS_RETVAL := NULL;
        END;

        RETURN LS_RETVAL;
    END;

    FUNCTION GET_CUSTOMER(PN_CUSTOMER_NO NUMBER) RETURN CBS_MUSTERI_AFFILIATES%ROWTYPE
    IS
        R_CUSTOMER CBS_MUSTERI_AFFILIATES%ROWTYPE;
    BEGIN
        BEGIN
            SELECT * 
            INTO R_CUSTOMER
            FROM CBS_MUSTERI_AFFILIATES
            WHERE CUSTOMER_NO = PN_CUSTOMER_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            R_CUSTOMER := NULL;
        END;

        RETURN R_CUSTOMER;
    END;

    Procedure Copy_Relations(pn_islem_no number, pn_cust_no number)
    is
    begin
        delete from cbs_family_relations_tx where tx_no = pn_islem_no;
        insert into cbs_family_relations_tx (TX_NO, CUSTOMER_NO, TIN, CUSTOMER_NAME, BANK_RELATION_NO, FOR_CUSTOMER_NO, RELATION_NO, NATIONALITY_CODE, ACTIVITY, BANK_SHARES)
        select pn_islem_no, CUSTOMER_NO, TIN, CUSTOMER_NAME, BANK_RELATION_NO, FOR_CUSTOMER_NO, RELATION_NO, NATIONALITY_CODE, ACTIVITY, BANK_SHARES
        from cbs_musteri_relations
        where for_customer_no = pn_cust_no
            and relation_no <> 0;

        delete from cbs_legal_relations_tx where tx_no = pn_islem_no;
        insert into cbs_legal_relations_tx(tx_no, customer_no,tin, customer_name, bank_relation_no, for_customer_no, 
        english_company_name, kyrgyz_company_name, manager_full_name, legal_form_cd, civil_status, capital_participation, form_of_control,--bom maksatt 27.12.2022 cbs-812
        economic_activity, reg_country, registration_no, paid_up_share, currency,date_of_purchase,date_of_sale)--eom maksatt 27.12.2022 cbs-812
        select pn_islem_no, CUSTOMER_NO,TIN, CUSTOMER_NAME, BANK_RELATION_NO, FOR_CUSTOMER_NO, 
        ENGLISH_COMPANY_NAME, KYRGYZ_COMPANY_NAME, MANAGER_FULL_NAME, LEGAL_FORM_CD, CIVIL_STATUS, CAPITAL_PARTICIPATION, FORM_OF_CONTROL,--bom maksatt 27.12.2022 cbs-812
        ECONOMIC_ACTIVITY, REG_COUNTRY, REGISTRATION_NO, PAID_UP_SHARE, CURRENCY,DATE_OF_PURCHASE,DATE_OF_SALE--eom maksatt 27.12.2022 cbs-812
        from cbs_musteri_relations
        where for_customer_no = pn_cust_no
            and relation_no = 0;
    end;

    FUNCTION GET_RELATION_DESCRIPTION(PN_RELATION_CODE number) RETURN VARCHAR2
    IS
        LS_RETVAL VARCHAR2(2000);
    BEGIN
        BEGIN
            SELECT DESCRIPTION 
            INTO LS_RETVAL 
            FROM CBS_RELATIONS
            WHERE ID = PN_RELATION_CODE;            
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                LS_RETVAL := NULL;
        END;

        RETURN LS_RETVAL;
    END;

    function degree(pn_cust_no number) return number
    is
        ln_input_degree number;
        ln_output_degree number;
    begin
        select count(*)
        into ln_output_degree 
        from cbs_musteri_relations
        where customer_no = pn_cust_no;

        select count(*)
        into ln_input_degree 
        from cbs_musteri_relations
        where for_customer_no = pn_cust_no;

        return ln_output_degree + ln_input_degree;
    end;
    ----------------------------------------------------------------------------------------
    function get_type(pn_cust_no number) return varchar2
    is
        ls_retval varchar2(20);
    begin
        select type 
        into ls_retval
        from cbs_musteri_affiliates
        where customer_no = pn_cust_no;

        return ls_retval;
    exception
        when no_data_found then
            return null;
    end;

    function get_position(pn_cust_no number) return varchar2
    is
        ls_retval varchar2(20);
    begin
        select position 
        into ls_retval
        from cbs_musteri_affiliates
        where customer_no = pn_cust_no;

        return ls_retval;
    exception
        when no_data_found then
            return null;
    end;

    procedure Update_related_customers(pn_islem_no number, pn_cust_no number, ps_status varchar2)
    is
        ls_type varchar2(20);
    begin
        for c_rec in (select customer_no, customer_name, bank_relation_no
                        from cbs_family_relations_tx
                        where tx_no = pn_islem_no   
                            and for_customer_no = pn_cust_no)
        loop
            ls_type := get_type(c_rec.customer_no);
            delete from cbs_musteri_affiliates where customer_no = c_rec.customer_no and type<>'MAIN';
            if c_rec.customer_no is not null and (ps_status='ACTIVE' or degree(c_rec.customer_no)>0) and nvl(ls_type, 'RELATED') <>'MAIN' then
                insert into cbs_musteri_affiliates (customer_no, full_name, bank_relation_no, position, type)
                values (c_rec.customer_no, c_rec.customer_name, c_rec.bank_relation_no, null, 'RELATED');
            end if;
        end loop;

        for c_rec in (select customer_no, customer_name, bank_relation_no
                        from cbs_legal_relations_tx
                        where tx_no = pn_islem_no   
                            and for_customer_no = pn_cust_no)
        loop
            ls_type := get_type(c_rec.customer_no);
            delete from cbs_musteri_affiliates where customer_no = c_rec.customer_no and type<>'MAIN';
            if c_rec.customer_no is not null and (ps_status='ACTIVE' or degree(c_rec.customer_no)>0) and nvl(ls_type, 'RELATED')<>'MAIN' then
                insert into cbs_musteri_affiliates (customer_no, full_name, bank_relation_no, position, type)
                values (c_rec.customer_no, c_rec.customer_name, c_rec.bank_relation_no, null, 'RELATED');
            end if;
        end loop;
    end;
    
    --BOM CBS-812 maksatt 20.12.2022
    procedure get_family_relations_by_tin(pc_tin in CBS_FAMILY_RELATIONS_TX.TIN%type,
                                          ps_customer out CBS_FAMILY_RELATIONS_TX.CUSTOMER_NO%type,
                                          ps_cutomer_name out CBS_FAMILY_RELATIONS_TX.CUSTOMER_NAME%type,
                                          ps_nationality out CBS_FAMILY_RELATIONS_TX.NATIONALITY_CODE%type,
                                          ps_activity out CBS_FAMILY_RELATIONS_TX.ACTIVITY%type)
                                           is
    lc_count number;                   
    begin
        select MUSTERI_NO, 
        UPPER(DECODE(musteri_tipi_kod, '1', isim ||
              DECODE(' ' || ikinci_isim || ' ', '  ',
              ' ', ' ' || ikinci_isim || ' ') || soyadi,
              '2', isim || DECODE(' ' || ikinci_isim || ' ', '  ',
              ' ', ' ' || ikinci_isim || ' ') || soyadi,ticari_unvan)) name,
              f.ACIKLAMA,
              UYRUK_KOD
              into ps_customer,ps_cutomer_name, ps_activity, ps_nationality
        from CBS_MUSTERI M left join CBS_MESLEK_KODLARI F on M.MESLEK_KOD=F.MESLEK_KODU
        where M.VERGI_NO=to_char(pc_tin) AND ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        NULL;
    END; --EOM CBS-812 maksatt 20.12.2022
    
        --BOM CBS-812 maksatt 20.12.2022
    procedure get_family_relations(pc_customer_no in CBS_FAMILY_RELATIONS_TX.CUSTOMER_NO%type,
                                          ps_tin out CBS_FAMILY_RELATIONS_TX.TIN%type,
                                          ps_cutomer_name out CBS_FAMILY_RELATIONS_TX.CUSTOMER_NAME%type,
                                          ps_nationality out CBS_FAMILY_RELATIONS_TX.NATIONALITY_CODE%type,
                                          ps_activity out CBS_FAMILY_RELATIONS_TX.ACTIVITY%type)
                                           is
    lc_count number;                   
    begin
        select VERGI_NO, 
        UPPER(DECODE(musteri_tipi_kod, '1', isim ||
              DECODE(' ' || ikinci_isim || ' ', '  ',
              ' ', ' ' || ikinci_isim || ' ') || soyadi,
              '2', isim || DECODE(' ' || ikinci_isim || ' ', '  ',
              ' ', ' ' || ikinci_isim || ' ') || soyadi,ticari_unvan)) name,
              f.ACIKLAMA,
              UYRUK_KOD
              into ps_tin,ps_cutomer_name, ps_activity, ps_nationality
        from CBS_MUSTERI M left join CBS_MESLEK_KODLARI F on M.MESLEK_KOD=F.MESLEK_KODU
        where M.MUSTERI_NO=to_char(pc_customer_no) AND ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        NULL;
    END; --EOM CBS-812 maksatt 20.12.2022
    
    --BOM CBS-812 maksatt 20.12.2022
    procedure get_legal_entities_by_tin(pc_tin in CBS_LEGAL_RELATIONS_TX.TIN%type,
                                          ps_customer out CBS_LEGAL_RELATIONS_TX.CUSTOMER_NO%type,
                                          ps_ru_name out CBS_LEGAL_RELATIONS_TX.CUSTOMER_NAME%type,
                                          ps_eng_name out CBS_LEGAL_RELATIONS_TX.ENGLISH_COMPANY_NAME%type,
                                          ps_kg_name out CBS_LEGAL_RELATIONS_TX.KYRGYZ_COMPANY_NAME%type,
                                          ps_manager_name out CBS_LEGAL_RELATIONS_TX.MANAGER_FULL_NAME%type,
                                          ps_paid_share out CBS_LEGAL_RELATIONS_TX.PAID_UP_SHARE%type,
                                          ps_registration_no out CBS_LEGAL_RELATIONS_TX.REGISTRATION_NO%type,
                                          ps_legal_from out CBS_LEGAL_RELATIONS_TX.LEGAL_FORM_CD%type,
                                          ps_civil_status out CBS_LEGAL_RELATIONS_TX.CIVIL_STATUS%type,
                                          ps_capital_part out CBS_LEGAL_RELATIONS_TX.CAPITAL_PARTICIPATION%type,
                                          ps_form_of_control out CBS_LEGAL_RELATIONS_TX.FORM_OF_CONTROL%type,
                                          ps_economic_activity out CBS_LEGAL_RELATIONS_TX.ECONOMIC_ACTIVITY%type,
                                          --ps_economic_activity_type out CBS_LEGAL_RELATIONS_TX.ECONOMIC_ACTIVITY_TYPE%type,
                                          ps_reg_country out CBS_LEGAL_RELATIONS_TX.REG_COUNTRY%type,
                                          ps_currency out CBS_LEGAL_RELATIONS_TX.CURRENCY%type)
                                           is
    lc_count number;                   
    begin
        select  MUSTERI_NO,
                TICARI_UNVAN,
                LOKAL_UNVAN,
                null as kg_name,
                MANAGER_NAME || ' ' || MANAGER_SURNAME || ' ' || MANAGER_PATRONYMIC_NAME,
                PAID_SHARE_CAPITAL,
                VAT_SERI_NO,
                FK.ACIKLAMA,
                CSC.NAME_RUS civil,
                PC.NAME_RUS participation,
                FC.NAME_RUS form_codes,
               -- SC.EXPLANATION activity_code_type,
                M.ECONOMIC_ACTIVITY_CODE economy_codes,
                TAX_REG_COUNTRY_CODE,
                SHARE_CAPITAL_CURRENCY
              into ps_customer,
                   ps_ru_name, 
                   ps_eng_name, 
                   ps_kg_name, 
                   ps_manager_name,
                   ps_paid_share,
                   ps_registration_no,
                   ps_legal_from,
                   ps_civil_status,
                   ps_capital_part, 
                   ps_form_of_control, 
                  -- ps_economic_activity_type,
                   ps_economic_activity,
                   ps_reg_country, 
                   ps_currency
        from CBS_MUSTERI M left join CBS_ECONOMIC_ACTIVITY_CODES AT on M.ECONOMIC_ACTIVITY_CODE=AT.CODE
        --left join CBS_ECONOMIC_ACTIVITY_SUBCODES SC on SC.SUBCODE=M.ECONOMIC_ACTIVITY_SUB
        left join CBS_CONTROL_FORM_CODES FC on M.CONTROL_FORM_CODE=FC.CODE
        left join CBS_CAPITAL_PARTICIPATION_CODE PC on M.CAPITAL_PARTICIPATION_CODE=PC.CODE
        left join CBS_CIVIL_STATUS_CODES CSC on M.CIVIL_STATUS_CODE=CSC.CODE
        left join CBS_LEGAL_FORM_KODLARI FK on M.LEGAL_FORM_CODE=FK.LEGAL_FORM_CODE
        where VERGI_NO=to_char(pc_tin) AND  M.musteri_tipi_kod = '3' AND ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        NULL;
    END; --EOM CBS-812 maksatt 20.12.2022
    
        --BOM CBS-812 maksatt 20.12.2022
    procedure get_legal_entities( pc_customer in CBS_LEGAL_RELATIONS_TX.TIN%type,
                                  ps_tin out CBS_LEGAL_RELATIONS_TX.CUSTOMER_NO%type,
                                  ps_ru_name out CBS_LEGAL_RELATIONS_TX.CUSTOMER_NAME%type,
                                  ps_eng_name out CBS_LEGAL_RELATIONS_TX.ENGLISH_COMPANY_NAME%type,
                                  ps_kg_name out CBS_LEGAL_RELATIONS_TX.KYRGYZ_COMPANY_NAME%type,
                                  ps_manager_name out CBS_LEGAL_RELATIONS_TX.MANAGER_FULL_NAME%type,
                                  ps_paid_share out CBS_LEGAL_RELATIONS_TX.PAID_UP_SHARE%type,
                                  ps_registration_no out CBS_LEGAL_RELATIONS_TX.REGISTRATION_NO%type,
                                  ps_legal_from out CBS_LEGAL_RELATIONS_TX.LEGAL_FORM_CD%type,
                                  ps_civil_status out CBS_LEGAL_RELATIONS_TX.CIVIL_STATUS%type,
                                  ps_capital_part out CBS_LEGAL_RELATIONS_TX.CAPITAL_PARTICIPATION%type,
                                  ps_form_of_control out CBS_LEGAL_RELATIONS_TX.FORM_OF_CONTROL%type,
                                  ps_economic_activity out CBS_LEGAL_RELATIONS_TX.ECONOMIC_ACTIVITY%type,
                                  --ps_economic_activity_type out CBS_LEGAL_RELATIONS_TX.ECONOMIC_ACTIVITY_TYPE%type,
                                  ps_reg_country out CBS_LEGAL_RELATIONS_TX.REG_COUNTRY%type,
                                  ps_currency out CBS_LEGAL_RELATIONS_TX.CURRENCY%type)
                                   is
    lc_count number;                   
    begin
        select  VERGI_NO,
                TICARI_UNVAN,
                LOKAL_UNVAN,
                null as kg_name,
                MANAGER_NAME || ' ' || MANAGER_SURNAME || ' ' || MANAGER_PATRONYMIC_NAME,
                PAID_SHARE_CAPITAL,
                VAT_SERI_NO,
                FK.ACIKLAMA,
                CSC.NAME_RUS civil,
                PC.NAME_RUS participation,
                FC.NAME_RUS form_codes,
                --SC.EXPLANATION activity_code_type,
                M.ECONOMIC_ACTIVITY_CODE economy_codes,
                TAX_REG_COUNTRY_CODE,
                SHARE_CAPITAL_CURRENCY
              into ps_tin,
                   ps_ru_name, 
                   ps_eng_name, 
                   ps_kg_name, 
                   ps_manager_name,
                   ps_paid_share,
                   ps_registration_no,
                   ps_legal_from,
                   ps_civil_status,
                   ps_capital_part, 
                   ps_form_of_control,
                  -- ps_economic_activity_type, 
                   ps_economic_activity,
                   ps_reg_country, 
                   ps_currency
        from CBS_MUSTERI M left join CBS_ECONOMIC_ACTIVITY_CODES AT on M.ECONOMIC_ACTIVITY_CODE=AT.CODE
        --left join CBS_ECONOMIC_ACTIVITY_SUBCODES SC on SC.SUBCODE=M.ECONOMIC_ACTIVITY_SUB
        left join CBS_CONTROL_FORM_CODES FC on M.CONTROL_FORM_CODE=FC.CODE
        left join CBS_CAPITAL_PARTICIPATION_CODE PC on M.CAPITAL_PARTICIPATION_CODE=PC.CODE
        left join CBS_CIVIL_STATUS_CODES CSC on M.CIVIL_STATUS_CODE=CSC.CODE
        left join CBS_LEGAL_FORM_KODLARI FK on M.LEGAL_FORM_CODE=FK.LEGAL_FORM_CODE
        where MUSTERI_NO=to_char(pc_customer) AND  M.musteri_tipi_kod = '3' AND ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        NULL;
    END; --EOM CBS-812 maksatt 20.12.2022
end;
--CREATE PUBLIC SYNONYM PKG_TX1003 FOR CBS.PKG_TX1003; 
--GRANT EXECUTE ON CBS.PKG_TX1003 TO CBS_ROL;
/

