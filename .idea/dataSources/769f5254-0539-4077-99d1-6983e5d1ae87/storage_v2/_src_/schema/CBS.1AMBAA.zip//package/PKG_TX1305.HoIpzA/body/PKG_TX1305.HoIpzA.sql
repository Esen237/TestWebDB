create PACKAGE BODY     Pkg_Tx1305 IS
	pn_1305_borclu_doviz_kod        NUMBER;
	pn_1305_fc_tutar        NUMBER;
	pn_1305_ekran_kurlu_tutar        NUMBER;
	pn_1305_banka_aciklama        NUMBER;
	pn_1305_borclu_hesap_sube_kodu        NUMBER;
	pn_1305_borclu_hesap_no        NUMBER;
	pn_1305_alacak_hesap_sube_kodu        NUMBER;
	pn_1305_alacak_hesap_no        NUMBER;
	pn_1305_musteri_aciklama        NUMBER;
	pn_1305_referans        NUMBER;
	pn_1305_fis_aciklama        NUMBER;
	pn_1305_istatistik_kod        NUMBER;
	pn_1305_tutar_bdak        NUMBER;
	pn_1305_islem_sube        NUMBER;
	pn_1305_alacak_doviz_kod        NUMBER;
	pn_1305_tl_tutar        NUMBER;
	pn_1305_kur        NUMBER;
	pn_1305_tl_ise        NUMBER;
	pn_1305_yp_ise        NUMBER;
	pn_1305_musteri_kuru_buyukse        NUMBER;
	pn_1305_musteri_kuru_kucukse        NUMBER;
	pn_1305_endeks_ise        NUMBER;
	pn_1305_kullandirim_tl        NUMBER;
	pn_1305_kullandirim_yp        NUMBER;
	pn_1305_bdak_kur        NUMBER;
	pn_1305_bdak_tutar        NUMBER;
	pn_1305_endeks_doviz        NUMBER;
	pn_1305_fark_tutar        NUMBER;
	pn_1305_musteri_tutar        NUMBER;
	pn_1305_maliyet_tutar        NUMBER;
	pn_1305_bdak_fc_tutar        NUMBER;
	pn_1305_borclu_teminat_hesap        NUMBER;
	pn_1305_alacak_teminat_hesap        NUMBER;
	pn_1305_teminat_doviz        NUMBER;
	pn_1305_kullan_teminattutar        NUMBER;
	pn_1305_kullan_tl_teminattutar     NUMBER;
	pn_1305_borclu_teminhesapsube        NUMBER;
	ps_fis_mesaj						 VARCHAR2(2000);
  PROCEDURE sp_tahakkuk_dk_tanimlimi(pn_islem_no NUMBER)
  IS
  ls_sube_kodu VARCHAR2(200);
  ls_doviz_kodu VARCHAR2(200);
  ls_faiz_dk_numara VARCHAR2(200);
  ls_vergi_dk_numara VARCHAR2(200);
  BEGIN
  	   SELECT sube_kodu ,doviz_kodu
	   INTO ls_sube_kodu,ls_doviz_kodu
	   FROM CBS_HESAP_KREDI_ISLEM
	   WHERE tx_no = pn_islem_no;

       Pkg_Kredi.SF_TAHAKKUK_DK_TANIMLIMI ( lS_SUBE_KODU, lS_DOVIZ_KODU, lS_FAIZ_DK_NUMARA, lS_VERGI_DK_NUMARA );
    END;

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
   ln_kredi_teklif_satir_numara			 NUMBER ;
   ln_kredi_hesap_tutar  				 NUMBER :=0 ;
   ls_kredi_hesap_doviz_kodu  			 CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
   ln_bakiye 							 NUMBER := 0;
   ln_hesap_no							 CBS_HESAP.hesap_no%TYPE;
   ls_endeks_doviz_kodu 			     CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
   ln_txno								 NUMBER;
  BEGIN

   SELECT kredi_teklif_satir_numara,
   		  ABS(NVL(tutar,0)),
		  doviz_kodu ,
		  hesap_no,
		  endeks_doviz_kodu
   INTO   ln_kredi_teklif_satir_numara,
   		  ln_kredi_hesap_tutar,
		  ls_kredi_hesap_doviz_kodu,
		  ln_hesap_no,
		  ls_endeks_doviz_kodu
   FROM CBS_HESAP_KREDI_ISLEM
   WHERE tx_no = pn_islem_no;

   ln_txno:=Pkg_Kredi.Sf_Bitmemis_HesapIslm_VarMi(NULL,
 		  					   pn_islem_no,
							   ln_hesap_no) ;
   SELECT ABS(NVL(bakiye,0))
   INTO ln_bakiye
   FROM CBS_HESAP_BAKIYE
   WHERE hesap_no =  ln_hesap_no;

   ln_kredi_hesap_tutar := ln_kredi_hesap_tutar +  ln_bakiye ;
   Pkg_Kredi.sp_taksit_vade_tutar_kontrol(pn_islem_no , ln_kredi_hesap_tutar);

   Pkg_Teminat.sp_teminat_kontrolsonra(pn_islem_no ,
  			 ln_kredi_teklif_satir_numara ,
			 ln_kredi_hesap_tutar,
             ls_kredi_hesap_doviz_kodu ,
			 ls_endeks_doviz_kodu);
  sp_kontrol_sonrasi_rezervasyon(pn_islem_no);

  END;

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
    UPDATE CBS_HESAP_KREDI_ISLEM
	SET durum_kodu = 'R'
	WHERE tx_no = pn_islem_no;

	Pkg_Teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_No);
	Pkg_Kur_Rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  END;

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
	/* teminat islem Durum guncellenir */
	Pkg_Teminat.sp_teminat_islem_durumguncelle(pn_islem_no,'ACIK');

  END;

  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	 NULL;
  END;

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER)
  IS
    ln_teklif_no    CBS_KREDI_TEKLIF.teklif_no%TYPE;
	ls_durum_kodu   CBS_KREDI_TEKLIF.durum_kodu%TYPE;
	ln_hesap_no    CBS_HESAP_KREDI.hesap_no%TYPE ;
	ls_doviz_kodu  CBS_HESAP_KREDI.doviz_kodu%TYPE;
	ls_faiz_siklik_tipi	  VARCHAR2(2000);
	ld_vade				  DATE;
	ln_txno NUMBER;
	ln_bakiye	   NUMBER;
	 ln_kredi_hesap_tutar NUMBER;
  BEGIN

	  SELECT hesap_no,
	  		 doviz_kodu,
			 faiz_siklik_tipi,
			 ABS(NVL(tutar,0))
	  INTO  ln_hesap_no,
	  	    ls_doviz_kodu,
			 ls_faiz_siklik_tipi,
			 ln_kredi_hesap_tutar
	  FROM CBS_HESAP_KREDI_ISLEM
	  WHERE tx_no = pn_islem_no;

	  ln_txno:=Pkg_Kredi.Sf_Bitmemis_HesapIslm_VarMi(NULL,
 		  					   pn_islem_no,
							   ln_hesap_no) ;

  SELECT ABS(NVL(bakiye,0))
   INTO ln_bakiye
   FROM CBS_HESAP_BAKIYE
   WHERE hesap_no =  ln_hesap_no;

   ln_kredi_hesap_tutar := ln_kredi_hesap_tutar +  ln_bakiye ;
   Pkg_Kredi.sp_taksit_vade_tutar_kontrol(pn_islem_no , ln_kredi_hesap_tutar);


	  Pkg_Kredi.sp_onayonce_taksit_sakla(    pn_islem_no ,ln_hesap_no);

	IF ls_faiz_siklik_tipi = 'INSTALLMENT DATE' THEN
	   SELECT MIN(vade_tarih)
	   INTO ld_vade
	   FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
	   WHERE tx_no = pn_islem_no and
   	  		NVL(durum_kodu,'A') = 'A';

	   UPDATE CBS_HESAP_KREDI
	   SET faiz_tahakkuk_tarihi =ld_vade
	   WHERE hesap_no= ln_hesap_no;
	END IF;

     Pkg_Kredi.sp_taksit_sira_guncelle(pn_islem_no);
     Pkg_Teminat.sp_teminat_onay_sonrasi(pn_islem_no ,ln_hesap_no,ls_doviz_kodu);

	 BEGIN
	 	  DELETE  FROM CBS_HESAP_KREDI_TAKSIT
		  WHERE hesap_no = ln_hesap_no ;

		  INSERT INTO CBS_HESAP_KREDI_TAKSIT(yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl)
		  SELECT  pn_islem_no,ln_hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl
		  FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
	  	   WHERE tx_no = pn_islem_no;
		 EXCEPTION WHEN OTHERS THEN NULL;
	 END;


  END;

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
    ln_hesap_no             CBS_HESAP_KREDI.hesap_no%TYPE;
	ln_faiz_tahakkuk  		CBS_HESAP_KREDI.hesap_no%TYPE;
	ln_vergi_tahakkuk		CBS_HESAP_KREDI.hesap_no%TYPE;
	ls_faiz_siklik_tipi	  VARCHAR2(2000);
	ld_faiz_tahak_tarihi				  DATE;
	ln_txno				  NUMBER;
  BEGIN

	   SELECT faiz_tahakkuk_tarihi,
	   		  hesap_no,
			  faiz_siklik_tipi
	   INTO ld_faiz_tahak_tarihi,
	   		ln_hesap_no,
			ls_faiz_siklik_tipi
	   FROM CBS_HESAP_KREDI_ISLEM
	   WHERE tx_no = pn_islem_no;

	  ln_txno := Pkg_Kredi.sf_islemvarsa_uyar(pn_islem_no,
 		  					  ln_hesap_no	  );
	 sp_iptalkontrol(pn_islem_no);

  	IF ls_faiz_siklik_tipi = 'INSTALLMENT DATE' THEN
	   UPDATE CBS_HESAP_KREDI
	   SET faiz_tahakkuk_tarihi =ld_faiz_tahak_tarihi
	   WHERE hesap_no= ln_hesap_no;
	END IF;

	UPDATE CBS_HESAP_KREDI_ISLEM
	SET  durum_kodu = 'I'
	WHERE tx_no = pn_islem_no ;

	 Pkg_Teminat.sp_teminat_iptalonaysonrasi(pn_islem_no);
	 Pkg_Kur_Rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);

	 	 BEGIN
	 	  DELETE  FROM CBS_HESAP_KREDI_TAKSIT
		  WHERE hesap_no = ln_hesap_no ;

		  INSERT INTO CBS_HESAP_KREDI_TAKSIT(yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl)
		  SELECT NVL(yaratan_tx_no, pn_islem_no), NVL(hesap_no,ln_hesap_no ), sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl
		  FROM CBS_HESAP_KREDI_TAKS_ONAY_ISL
	  	   WHERE tx_no = pn_islem_no;
		 EXCEPTION WHEN OTHERS THEN NULL;
	 END;
  END;


  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
    UPDATE CBS_HESAP_KREDI_ISLEM
	SET durum_kodu = 'R'
	WHERE tx_no = pn_islem_no;

	/* teminat islem Durum guncellenir */
	Pkg_Teminat.sp_teminat_reddetmesonrasi(pn_islem_no);
	Pkg_Kur_Rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  END;

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

 PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER ) IS
 BEGIN
  NULL;
 END;

 PROCEDURE Guncelleme_Kontrolu(pn_islem_no NUMBER,ps_block	VARCHAR2,ps_rowid   VARCHAR2,
  							   ps_column VARCHAR2,pd_column VARCHAR2,ps_oldvalue IN OUT VARCHAR2)
 IS
 BEGIN
    Pkg_Teminat.sp_TeminatGuncelleme_Kontrolu (pn_islem_no ,ps_block,ps_rowid,ps_column,pd_column ,ps_oldvalue ,'CBS_HESAP_KREDI_ISLEM' );

 END;

 PROCEDURE Muhasebelesme(pn_islem_no NUMBER)
 IS
    varchar_list	           Pkg_Muhasebe.varchar_array;
    number_list				   Pkg_Muhasebe.number_array;
    date_list				   Pkg_Muhasebe.date_array;
    boolean_list			   Pkg_Muhasebe.boolean_array;
	ln_fis_no				  CBS_FIS.numara%TYPE ;
	ls_islem_kod              CBS_ISLEM.islem_kod%TYPE :='1305';
	ls_banka_aciklama         VARCHAR2(2000);
	ls_fis_aciklama			  VARCHAR2(2000);
	ls_aciklama               VARCHAR2(2000);
	ls_musteri_aciklama       VARCHAR2(2000);
	ln_rezervasyon_no         NUMBER;
	ln_musteri_no			   CBS_MUSTERI.musteri_no%TYPE;
	ln_borc_hesap_no		   CBS_HESAP_KREDI.hesap_no%TYPE;
	ls_borc_hesap_sube_kodu	   CBS_HESAP_KREDI.sube_kodu%TYPE;
	ls_borc_doviz_kodu		  	   CBS_HESAP_KREDI.doviz_kodu%TYPE;
	ls_alacak_hesap_sube_kodu  CBS_HESAP_KREDI.sube_kodu%TYPE;
	ln_alacak_hesap_no		   CBS_HESAP_KREDI.hesap_no%TYPE;
	ls_alacak_doviz_kodu       CBS_HESAP_KREDI.doviz_kodu%TYPE;
	ln_tutar				   CBS_HESAP_KREDI.tutar%TYPE;
	ls_endeks_doviz_kodu	    CBS_HESAP_KREDI.doviz_kodu%TYPE;
	ls_kullandirim_doviz_kodu	CBS_HESAP_KREDI.doviz_kodu%TYPE;
	ln_kur  		NUMBER;
	ln_musteri_kur   NUMBER;
	ln_maliyet_kur   NUMBER;
	ls_istatistik_kod		VARCHAR2(2000);
    ls_modul_tur_kod		CBS_HESAP_KREDI.modul_tur_kod%TYPE;
    ls_urun_tur_kod			CBS_HESAP_KREDI.urun_tur_kod%TYPE;
	ls_urun_sinif_kod		CBS_HESAP_KREDI.urun_sinif_kod%TYPE;

	CURSOR islem_cursor (pn_islemno CBS_ISLEM.numara%TYPE) IS
		   	SELECT musteri_no,
				   sube_kodu,
				   hesap_no,
				   doviz_kodu,
				   Pkg_Hesap.HESAPSUBEAL(alacak_hesap_no),
				   alacak_hesap_no,
				   Pkg_Hesap.HESAPTANDOVIZKODUAL(alacak_hesap_no),
				   NVL(tutar,0),
				   rezervasyon_no,
				   endeks_doviz_kodu,
				   kullandirim_doviz_kodu,
				   acilis_kuru,
				   ISTATISTIK_KODU istatistik_kodu ,
				   modul_tur_kod,
				   urun_tur_kod,
				   urun_sinif_kod,
				   Pkg_Tx.Amir_BolumKodu_Al( tx_no),
   				   'Account No:'|| TO_CHAR(hesap_no)|| ' Value:' || TO_CHAR(kredi_vade,'DD/MM/YYYY') ||' Interest Rate:'|| TO_CHAR(faiz_orani)
			FROM CBS_HESAP_KREDI_ISLEM
			WHERE tx_no=pn_islemno;
  BEGIN
  ps_fis_mesaj  := NULL;
/* islem bilgisi detaylari alinir */
  	   OPEN islem_cursor(pn_islem_no);
		   FETCH islem_cursor INTO ln_musteri_no,
		   		 			  	   ls_borc_hesap_sube_kodu,
								   ln_borc_hesap_no,
								   ls_borc_doviz_kodu,
		   		 			  	   ls_alacak_hesap_sube_kodu,
								   ln_alacak_hesap_no,
								   ls_alacak_doviz_kodu,
								   ln_tutar,
								   ln_rezervasyon_no,
								   ls_endeks_doviz_kodu,
								   ls_kullandirim_doviz_kodu,
								   ln_kur,
								   ls_istatistik_kod,
								   ls_modul_tur_kod,
				   				   ls_urun_tur_kod,
				   				   ls_urun_sinif_kod,
								    varchar_list(pn_1305_islem_sube),
									ls_banka_aciklama  ;
		   IF islem_cursor%NOTFOUND THEN
	          CLOSE islem_cursor;
	       END IF;
		  CLOSE islem_cursor;

/*** Liste Deger Atama K?sm? **/

/**** varchar list ****/

  IF ln_rezervasyon_no IS NULL THEN
  /* o anki BDAK kuru ile guncelelnir*/
   IF    ls_endeks_doviz_kodu IS NOT NULL AND Pkg_Kredi.sf_dovize_endeksli_kredimi(ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod  ) = 'E' THEN
  	     ln_kur := Pkg_Kur.doviz_doviz_karsilik(ls_endeks_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A');
	ELSE
		  ln_kur := Pkg_Kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A');
    END IF;
	    UPDATE CBS_HESAP_KREDI_ISLEM
	    SET acilis_kuru =Pkg_Kur.doviz_doviz_karsilik(doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A')
		WHERE tx_no=pn_islem_no;
  END IF;
   ls_aciklama :=   Pkg_Genel.ISLEM_ADI_AL(1305) ;

   Pkg_Parametre.deger('1305_FIS_ACIKLAMA',ls_fis_aciklama);
   ls_musteri_aciklama := ls_banka_aciklama ;
--   pkg_parametre.deger('1305_BANKA_ACIKLAMA',ls_banka_aciklama);
--   pkg_parametre.deger('1305_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   varchar_list(pn_1305_fis_aciklama) 	 := ls_fis_aciklama ;
   varchar_list(pn_1305_banka_aciklama)  := NVL(ls_banka_aciklama,ls_aciklama);
   varchar_list(pn_1305_musteri_aciklama):= NVL(ls_musteri_aciklama,ls_aciklama);
   varchar_list(pn_1305_referans) 	     := TO_CHAR(ln_borc_hesap_no);
   varchar_list(pn_1305_istatistik_kod) 	 := ls_istatistik_kod;

   varchar_list(pn_1305_borclu_hesap_no) := TO_CHAR(ln_borc_hesap_no);
   varchar_list(pn_1305_borclu_hesap_sube_kodu):=ls_borc_hesap_sube_kodu;
   varchar_list(pn_1305_borclu_doviz_kod):=ls_borc_doviz_kodu;
   varchar_list(pn_1305_endeks_doviz)    :=ls_endeks_doviz_kodu;

   varchar_list(pn_1305_alacak_hesap_no) := TO_CHAR(ln_alacak_hesap_no);
   varchar_list(pn_1305_alacak_hesap_sube_kodu):=ls_alacak_hesap_sube_kodu;
   varchar_list(pn_1305_alacak_doviz_kod):=ls_alacak_doviz_kodu;


/**** boolean list ****/
    boolean_list(pn_1305_tl_ise ):=FALSE;
    boolean_list(pn_1305_yp_ise ):=FALSE;
	boolean_list(pn_1305_endeks_ise):=FALSE;
	boolean_list(pn_1305_musteri_kuru_buyukse ):=FALSE;
	boolean_list(pn_1305_musteri_kuru_kucukse):= FALSE;
	boolean_list(pn_1305_kullandirim_tl):=FALSE;
	boolean_list(pn_1305_kullandirim_yp):=FALSE;

/**** number list ****/

	 IF ls_endeks_doviz_kodu IS NOT NULL  AND Pkg_Kredi.sf_dovize_endeksli_kredimi(ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod  ) = 'E'  THEN
	 /* dovize endekli kredi */
	     boolean_list(pn_1305_endeks_ise ):=TRUE;
		 number_list(pn_1305_fc_tutar) :=  Pkg_Kur.doviz_doviz_karsilik(ls_endeks_doviz_kodu,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'O','A');
	 	 number_list(pn_1305_tl_tutar) :=  Pkg_Kur.doviz_doviz_karsilik(ls_endeks_doviz_kodu,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'O','A');
	 	 number_list(pn_1305_kur)	   :=  1;
		 number_list(pn_1305_bdak_tutar) := Pkg_Kur.doviz_doviz_karsilik(ls_endeks_doviz_kodu,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'O','A');
		 number_list(pn_1305_bdak_fc_tutar) := LN_TUTAR;
		 number_list(pn_1305_bdak_kur) := LN_KUR ; --TRL
	 ELSE
		 IF ls_borc_doviz_kodu =Pkg_Genel.lc_al THEN
		  /* trl kredi*/
		     boolean_list(pn_1305_tl_ise ):=TRUE;
	 		 number_list(pn_1305_fc_tutar) := ln_tutar;
		 	 number_list(pn_1305_tl_tutar) := Pkg_Kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'N','A') ;
		 	 number_list(pn_1305_kur)	   := ln_kur ;
		 ELSE
		  /* d?viz kredi*/
	   	      boolean_list(pn_1305_yp_ise ):=TRUE;
			    IF ls_kullandirim_doviz_kodu = Pkg_Genel.lc_al THEN
					/* kulland?r?m TRL ise */
		   			boolean_list(pn_1305_kullandirim_tl):=TRUE;

				    IF NVL(ln_rezervasyon_no,0) != 0 THEN
					/*rezervasyonlu */
						Pkg_Kur_Rezervasyon.rezervasyon_alis_bilgisi_al(ln_rezervasyon_no,ln_musteri_kur,ln_maliyet_kur);
					ELSE
						ln_musteri_kur := Pkg_Kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A'); --m??teri al??
						ln_maliyet_kur := Pkg_Kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,3,NULL,NULL,'O','A'); --maliyet esas al??
					END IF;

			    	IF NVL(ln_musteri_kur,0) > NVL(ln_maliyet_kur,0) THEN
						    boolean_list( pn_1305_musteri_kuru_buyukse):=TRUE;
					ELSE
						    boolean_list( pn_1305_musteri_kuru_kucukse):=TRUE;
					END IF;

			 	   number_list(pn_1305_fc_tutar) := ln_tutar;
				   number_list(pn_1305_tl_tutar) := Pkg_Kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'O','A') ;
				   number_list(pn_1305_kur)	     := ln_maliyet_kur;
				   number_list(pn_1305_musteri_tutar)  := ln_tutar* ln_musteri_kur;
				   number_list(pn_1305_maliyet_tutar)  := ln_tutar* ln_maliyet_kur;
				   number_list(pn_1305_fark_tutar) := ABS(	ln_musteri_kur -ln_maliyet_kur) * ln_tutar ;
			 	ELSE
				/* kulland?r?m YP ise */
				   boolean_list(pn_1305_kullandirim_yp):=TRUE;
				   number_list(pn_1305_fc_tutar) := ln_tutar;
		 	       number_list(pn_1305_tl_tutar) := Pkg_Kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'N','A') ;
		 	       number_list(pn_1305_kur)	   := Pkg_Kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A') ;
			    END IF;
	      END IF;

	 END IF;


/* kredi hesap acilis muhasebesi calistirilir. */
    ln_fis_no:=Pkg_Muhasebe.fis_kes(ls_islem_kod,
							NULL,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							NULL,
							FALSE,
							0,
							NULL);

	Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);

	Pkg_Teminat.sp_teminat_fiskessonrasi(pn_islem_no,ln_fis_no);

	 UPDATE CBS_HESAP_KREDI_ISLEM
 	 SET	kur = DECODE(NVL(rezervasyon_no,0),0,ln_kur,ln_musteri_kur)
	 WHERE tx_no = pn_islem_no;

  EXCEPTION
   WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '507' || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
 END;

 PROCEDURE sp_kontrol_sonrasi_rezervasyon(pn_islem_no NUMBER ) IS
 ln_doviz_tutari NUMBER;
	ln_bakiye NUMBER;

	CURSOR islem_cursor IS
	   	 	SELECT * FROM CBS_HESAP_KREDI_ISLEM
			WHERE TX_NO=pn_islem_no;

	row_islem islem_cursor%ROWTYPE;
   BEGIN

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

	IF row_islem.REZERVASYON_NO IS NOT NULL THEN

	   ln_bakiye:=Pkg_Kur_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

	   IF row_islem.TUTAR >ln_bakiye THEN --Bakiye Yetersiz..
	      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
	   ELSE
	      Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
	 		    										  pn_islem_no,
	     												  row_islem.TUTAR);
	   END IF;

	END IF;

 EXCEPTION WHEN OTHERS THEN NULL;
 END;
 Procedure sp_iptalkontrol(pn_islem_no number)
 is
 cursor cursor_islem is
 	  select max(distinct a.tx_no)   tx_no
	   from  cbs_hesap_kredi_islem a,cbs_islem b
	  where a.tx_no = b.numara and
	  		b.durum not in( '2','R') and
			a.tx_no > pn_islem_no and
			a.hesap_no in (select hesap_no
						 	from cbs_hesap_kredi_islem
							where tx_no = pn_islem_no );

  ln_tx_no 			 number;
  islemvar 		     exception;
  durumu_kapali	     exception;
  ln_teminat_no		 number;
  ls_durum			 varchar2(200);
  ls_geriodeme_kapama_secimi varchar2(200);
 Begin

 /* islemden sonra bitmis ve de?i?iklik yap?lm?? islem varsa iptale izin verilemez. */

	 select b.durum_kodu,
	 		geriodeme_kapama_secimi
	 into 	ls_durum,
	 		ls_geriodeme_kapama_secimi
	 from 	cbs_hesap_kredi_islem a, cbs_hesap_kredi b
	 where  a.tx_no = pn_islem_no and
	 	    a.hesap_no = b.hesap_no;

	  if ls_durum <> 'A' and ls_geriodeme_kapama_secimi  <> 'KAPAMA' then
	    raise durumu_kapali ;
	  end if;

	  for cur_islem in cursor_islem
	  loop
			ln_tx_no := cur_islem.tx_no;
	  end loop;

		if nvl(ln_tx_no,0) <> 0 then
		   raise islemvar ;
		end if;

  Exception
   When  durumu_kapali then
      	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '906' || pkg_hata.getDelimiter ||to_char(ls_durum)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When  islemvar then
   	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '725' || pkg_hata.getDelimiter ||to_char(ln_tx_no)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then null;

 End;

BEGIN
		pn_1305_borclu_doviz_kod :=Pkg_Muhasebe.parametre_index_bul('1305_BORCLU_DOVIZ_KOD');
		pn_1305_fc_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_FC_TUTAR');
		pn_1305_ekran_kurlu_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_EKRAN_KURLU_TUTAR');
		pn_1305_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('1305_BANKA_ACIKLAMA');
		pn_1305_borclu_hesap_sube_kodu :=Pkg_Muhasebe.parametre_index_bul('1305_BORCLU_HESAP_SUBE_KODU');
		pn_1305_borclu_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1305_BORCLU_HESAP_NO');
		pn_1305_alacak_hesap_sube_kodu :=Pkg_Muhasebe.parametre_index_bul('1305_ALACAK_HESAP_SUBE_KODU');
		pn_1305_alacak_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1305_ALACAK_HESAP_NO');
		pn_1305_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('1305_MUSTERI_ACIKLAMA');
		pn_1305_referans :=Pkg_Muhasebe.parametre_index_bul('1305_REFERANS');
		pn_1305_fis_aciklama :=Pkg_Muhasebe.parametre_index_bul('1305_FIS_ACIKLAMA');
		pn_1305_istatistik_kod :=Pkg_Muhasebe.parametre_index_bul('1305_ISTATISTIK_KOD');
		pn_1305_tutar_bdak :=Pkg_Muhasebe.parametre_index_bul('1305_TUTAR_BDAK');
		pn_1305_islem_sube :=Pkg_Muhasebe.parametre_index_bul('1305_ISLEM_SUBE');
		pn_1305_alacak_doviz_kod :=Pkg_Muhasebe.parametre_index_bul('1305_ALACAK_DOVIZ_KOD');
		pn_1305_tl_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_TL_TUTAR');
		pn_1305_kur :=Pkg_Muhasebe.parametre_index_bul('1305_KUR');
		pn_1305_tl_ise :=Pkg_Muhasebe.parametre_index_bul('1305_TL_ISE');
		pn_1305_yp_ise :=Pkg_Muhasebe.parametre_index_bul('1305_YP_ISE');
		pn_1305_musteri_kuru_buyukse :=Pkg_Muhasebe.parametre_index_bul('1305_MUSTERI_KURU_BUYUKSE');
		pn_1305_musteri_kuru_kucukse :=Pkg_Muhasebe.parametre_index_bul('1305_MUSTERI_KURU_KUCUKSE');
		pn_1305_endeks_ise :=Pkg_Muhasebe.parametre_index_bul('1305_ENDEKS_ISE');
		pn_1305_kullandirim_tl :=Pkg_Muhasebe.parametre_index_bul('1305_KULLANDIRIM_TL');
		pn_1305_kullandirim_yp :=Pkg_Muhasebe.parametre_index_bul('1305_KULLANDIRIM_YP');
		pn_1305_bdak_kur :=Pkg_Muhasebe.parametre_index_bul('1305_BDAK_KUR');
		pn_1305_bdak_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_BDAK_TUTAR');
		pn_1305_endeks_doviz :=Pkg_Muhasebe.parametre_index_bul('1305_ENDEKS_DOVIZ');
		pn_1305_fark_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_FARK_TUTAR');
		pn_1305_musteri_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_MUSTERI_TUTAR');
		pn_1305_maliyet_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_MALIYET_TUTAR');
		pn_1305_bdak_fc_tutar :=Pkg_Muhasebe.parametre_index_bul('1305_BDAK_FC_TUTAR');
		pn_1305_borclu_teminat_hesap :=Pkg_Muhasebe.parametre_index_bul('1305_BORCLU_TEMINAT_HESAP');
		pn_1305_alacak_teminat_hesap :=Pkg_Muhasebe.parametre_index_bul('1305_ALACAK_TEMINAT_HESAP');
		pn_1305_teminat_doviz :=Pkg_Muhasebe.parametre_index_bul('1305_TEMINAT_DOVIZ');
		pn_1305_kullan_teminattutar :=Pkg_Muhasebe.parametre_index_bul('1305_KULLANILAN_TEMINAT_TUTARI');
		pn_1305_kullan_tl_teminattutar :=Pkg_Muhasebe.parametre_index_bul('1305_KULLANILAN_TL_TEMINAT_TUT');
		pn_1305_borclu_teminhesapsube :=Pkg_Muhasebe.parametre_index_bul('1305_BORCLU_TEMINAT_HESAP_SUBE');



END ;
/

