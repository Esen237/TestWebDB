create PACKAGE     PKG_INT_LIMIT_TRX IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION PutTopicLimit(ps_lang varchar2,
                     ps_limit_type varchar2,
                     ps_code varchar2,
                     ps_period varchar2,
                     ps_min_limit varchar2,
                     ps_max_limit varchar2,
                     ps_currency_code varchar2 default 'KGS',
                     ps_description varchar2 default 'None',
                     ps_channel_code varchar2 default '1',
                     ps_user_code varchar2 default 'CINT_CALLER',       
                     pc_ref OUT CursorReferenceType) RETURN varchar2; 

FUNCTION PutCustomerLimit(ps_lang varchar2,
                     ps_customer_id varchar2,
                     ps_code varchar2,
                     ps_period varchar2,
                     ps_min_limit varchar2,
                     ps_max_limit varchar2,
                     ps_currency_code varchar2 default 'KGS',
                     ps_channel_code varchar2 default '1',
                     ps_user_code varchar2 default 'CINT_CALLER',       
                     pc_ref OUT CursorReferenceType) RETURN varchar2;    

FUNCTION PutCustomerUsedLimit(ps_lang varchar2,
                     ps_customer_id varchar2,
                     ps_code varchar2,
                     ps_amount varchar2,
                     ps_currency_code varchar2,
                     ps_channel_code varchar2 default '1',
                     ps_user_code varchar2 default 'CINT_CALLER',      
                     pc_ref OUT CursorReferenceType) RETURN varchar2;   

FUNCTION DeleteCustomerUsedLimit(ps_lang varchar2,
                     ps_customer_id varchar2,
                     ps_code varchar2,
                     ps_amount varchar2,
                     ps_currency_code varchar2,
                     ps_channel_code varchar2 default '1',
                     ps_user_code varchar2 default 'CINT_CALLER',       
                     pc_ref OUT CursorReferenceType) RETURN varchar2;  
                       
FUNCTION InitCustomerLimit(ps_code varchar2,
                     pn_customer_no number,
                     ps_limit_type varchar2) RETURN varchar2;   
                            
FUNCTION ResetCustomerLimit(pn_customer_no number,
                     ps_limit_type varchar2) RETURN varchar2;                                                                                                                                                                  
END;
/

