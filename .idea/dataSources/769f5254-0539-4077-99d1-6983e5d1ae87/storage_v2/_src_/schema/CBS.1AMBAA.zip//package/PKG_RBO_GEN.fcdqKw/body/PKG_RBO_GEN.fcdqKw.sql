create package body pkg_RBO_gen 
is
    function generate_rbo_4_15 (pc_ref_in in sys_refcursor, pn_num number) return varchar2_ntt
    is 
        type rbo_4_15_rec is record (
            id number,
            title varchar2(4000),
            gl varchar2(4000),
            c_level number,
            sign varchar2(1)
        );

        type rbo_4_15_ntt is table of rbo_4_15_rec;

        rbo_4_15_nt rbo_4_15_ntt;
        res varchar2_ntt := varchar2_ntt();
        l_rec rbo_4_15_rec;

        n number;

        procedure add_value(ps_str in varchar2)
        is 
        begin
            res.extend();
            res(res.last) := ps_str;
        end;

        function build_select(p_rec in rbo_4_15_rec) return varchar2 is 
        begin
            return 'select ' || p_rec.id || ' id, '''  || trim(p_rec.title) || ''' title, ''' || trim(p_rec.gl) || ''' gl, ''' || p_rec.sign || '''  sign from dual';
        end;

        procedure prepare_result
        is 
        begin
            for i in 1 .. res.count loop
                res(i) := res(i) || (case when i = res.last then '' else ' union all ' end);
            end loop;
        end;
    begin
        n := pn_num;
        fetch pc_ref_in bulk collect into rbo_4_15_nt;
        close pc_ref_in;

        for i in 1 .. rbo_4_15_nt.count 
        loop
            if rbo_4_15_nt(i).c_level = '1' then 
                add_value(build_select(rbo_4_15_nt(i)));
            else 
                for j in 1 .. res.count loop
                    execute immediate res(j) into l_rec.id, l_rec.title, l_rec.gl, l_rec.sign;
                    if l_rec.id = rbo_4_15_nt(i).gl then 
                        l_rec.id := rbo_4_15_nt(i).id;
                        l_rec.title := rbo_4_15_nt(i).title;
                        l_rec.sign := (case when (rbo_4_15_nt(i).sign || '1')*(l_rec.sign || '1') > 0 then '+' else '-' end);
                        add_value(
                            build_select(
                                l_rec
                            )
                        );
                    end if;
                end loop;
            end if;
        end loop;

        prepare_result;
        return res;
    end;
end;
/

