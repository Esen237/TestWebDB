create package     pkg_rbo
is
    function rbo_4 (p_section in number, p_subsection number, pd_date_in in date, ps_curr in varchar2) return cbs.rbo4_ntt;
     function get_time_deposit_type (pd_vade_date date,pd_bank_date date )  return number;
end pkg_rbo;
/

