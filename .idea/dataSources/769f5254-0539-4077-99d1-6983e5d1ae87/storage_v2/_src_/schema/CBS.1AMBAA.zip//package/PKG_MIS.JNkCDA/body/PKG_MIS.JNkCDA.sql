create PACKAGE BODY PKG_MIS is

------------------------------------------------------------------------------------------
FUNCTION GetITRRate(ps_DOVIZKODU varchar2,ps_INTERESTTYPE varchar2) RETURN NUMBER is
	ln_rate	number;
Begin
	 select decode(ps_INTERESTTYPE,'LOAN',LOAN_RATE,'DEPOSIT',DEPOSIT_RATE)
	 into ln_rate
	 from CBS_MIS_ITR_RATES
	 where DOVIZ_KODU=ps_DOVIZKODU;

	 return ln_rate;
End;
-------------------------------------------------------------------------------------------
FUNCTION CalculateDayDifference(pd_today date) RETURN NUMBER is
    ld_banka_tarihi				DATE;
    ld_sonraki_banka_tarihi		DATE;

	ln_bugun					NUMBER;
	ln_yarin					NUMBER;
	ln_songun					NUMBER;
	ln_gun_farki				NUMBER;
Begin
	ld_banka_tarihi:=pd_today;
	ld_sonraki_banka_tarihi:=pkg_tarih.ileri_is_gunu(pd_today);

	ln_bugun:=TO_NUMBER(TO_CHAR(ld_banka_tarihi,'DD'));
	ln_yarin:=TO_NUMBER(TO_CHAR(ld_sonraki_banka_tarihi,'DD'));
	ln_songun:=TO_NUMBER(TO_CHAR(LAST_DAY(ld_banka_tarihi),'DD'));

    IF ln_yarin > ln_bugun THEN	-- Aysonu de?il
	  IF ln_yarin > ln_bugun+1 THEN
	     ln_gun_farki:=ln_yarin-ln_bugun;
	  ELSE
		 ln_gun_farki:=1;
	  END IF;
	ELSE  -- Aysonu
	  IF ln_bugun=ln_songun AND ln_yarin = 1 THEN		-- Aysonu Haftasonu veya Tatil'e denk gelmiyor
	     ln_gun_farki:=1;
	  ELSE--aysonu haftasonunda
		 ln_gun_farki:=ln_songun-ln_bugun+ln_yarin;
      END IF;
	END IF;

	 return ln_gun_farki;
End;
---------------------------------------------------------------------------------------
FUNCTION GetAverageBalance(ps_type varchar2,pn_hesapno number,pd_today date) RETURN NUMBER is
CURSOR c1 IS
     SELECT NVL(ORTALAMA_BAKIYE,0) ORTALAMA_BAKIYE
       FROM CBS_HESAP_ORTALAMA_BAKIYE
      WHERE hesap_no=pn_hesapno
	  	AND	YIL=to_number(to_char(pd_today,'YYYY')) and AY=to_number(to_char(pd_today,'MM'));
    r_c1	 					c1%ROWTYPE;

	ln_average number:=0;
BEGIN

	OPEN c1;
	FETCH c1 INTO r_c1;
	CLOSE c1;

	ln_average:=r_c1.ORTALAMA_BAKIYE;

	return ln_average;
END;
---------------------------------------------------------------------------------------
FUNCTION SumOfCurrentDeposits(pn_MUSTERINO NUMBER,ps_DOVIZKODU varchar2,pd_today date ) RETURN NUMBER is
	ln_sum		number:=0;
Begin

	SELECT sum(NVL(chb.bakiye,0))
	into ln_sum
	FROM CBS_HESAP_GUNLUK_BAKIYE chb,CBS_HESAP ch
	WHERE chb.hesap_no=ch.hesap_no
	AND	durum_kodu='A'
	and ch.DOVIZ_KODU=ps_DOVIZKODU
	and ch.MUSTERI_NO=pn_MUSTERINO
	and YIL=to_number(to_char(pd_today,'YYYY')) and AY=to_number(to_char(pd_today,'MM')) and GUN=to_number(to_char(pd_today,'DD'));

	return nvl(ln_sum,0);

exception
	when no_data_found then
		 return 0;
End;
---------------------------------------------------------------------------------------
FUNCTION SumOfTimeDeposits(pn_MUSTERINO NUMBER,ps_DOVIZKODU varchar2,pd_today date ) RETURN NUMBER is
	ln_sum		number:=0;
Begin

	SELECT sum(nvl(chb.VALORLU_BAKIYE,0))
	into ln_sum
	FROM CBS_HESAP_GUNLUK_BAKIYE chb,CBS_HESAP_VADELI ch
	WHERE chb.HESAP_NO=ch.HESAP_NO
	AND	DURUM_KODU='A'
	AND ch.DOVIZ_KODU=ps_DOVIZKODU
	and ch.MUSTERI_NO=pn_MUSTERINO
	and YIL=to_number(to_char(pd_today,'YYYY')) and AY=to_number(to_char(pd_today,'MM')) and GUN=to_number(to_char(pd_today,'DD'));

	return nvl(ln_sum,0);

exception
	when no_data_found then
		 return 0;
End;
---------------------------------------------------------------------------------------
FUNCTION SumOfLoans(pn_MUSTERINO NUMBER,ps_DOVIZKODU varchar2,pd_today date ) RETURN NUMBER is
	ln_sum		number:=0;
Begin

	SELECT sum(nvl(chb.VALORLU_BAKIYE,0))
	into ln_sum
	FROM CBS_HESAP_GUNLUK_BAKIYE chb,CBS_HESAP_KREDI ch
	WHERE chb.HESAP_NO=ch.HESAP_NO
	AND	DURUM_KODU='A'
	AND ch.DOVIZ_KODU=ps_DOVIZKODU
	and ch.MUSTERI_NO=pn_MUSTERINO
	and YIL=to_number(to_char(pd_today,'YYYY')) and AY=to_number(to_char(pd_today,'MM')) and GUN=to_number(to_char(pd_today,'DD'));

	return abs(nvl(ln_sum,0));

exception
	when no_data_found then
		 return 0;
End;
-------------------------------------------------------------------------------------------
FUNCTION CalcCurrentDepositInterest(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER is
	 CURSOR c1 IS
     SELECT chb.hesap_no, NVL(chb.bakiye,0) bakiye, NVL(chb.valorlu_bakiye,0) valorlu_bakiye,
	        --NVL(chb.aylik_ortalama_bakiye,0) aylik_ortalama_bakiye,
			--NVL(chb.yillik_ortalama_bakiye,0) yillik_ortalama_bakiye,
	        ch.faiz_orani, ch.esas_gun_sayisi, NVL(ch.min_faiz_tutari,0) min_faiz_tutari,
	        ch.faiz_indikatoru, ch.next_interest_calc_date, ch.bakiye_turu,ch.DOVIZ_KODU
       FROM CBS_HESAP_GUNLUK_BAKIYE chb,CBS_HESAP ch
      WHERE chb.hesap_no=ch.hesap_no
	  	AND	durum_kodu='A'
		AND MUSTERI_NO=pn_MUSTERINO
		and YIL=to_number(to_char(pd_today,'YYYY')) and AY=to_number(to_char(pd_today,'MM')) and GUN=to_number(to_char(pd_today,'DD'));
    r_c1	 					c1%ROWTYPE;
    ln_tutar					NUMBER:=0;
    ld_banka_tarihi				DATE;
    ld_sonraki_banka_tarihi		DATE;

	ln_bugun					NUMBER;
	ln_yarin					NUMBER;
	ln_songun					NUMBER;
	ln_gun_farki				NUMBER;

	ln_durum_kodu				NUMBER:=0;
	ln_faiz						NUMBER;
	ln_faiz_orani				NUMBER ;
	ln_yil_gun					NUMBER;

	ln_sum_faiz					NUMBER:=0;

	ln_aylik_ortalama_bakiye	NUMBER:=0;
	ln_yillik_ortalama_bakiye		NUMBER:=0;
  BEGIN

	ln_gun_farki:=pkg_mis.CalculateDayDifference(pd_today);

	OPEN c1;
	LOOP
	  FETCH c1 INTO r_c1;
	  EXIT WHEN c1%NOTFOUND;
	  IF r_c1.esas_gun_sayisi IS NULL OR r_c1.esas_gun_sayisi = 0 THEN
	  	log_at(Pkg_Hata.getucpointer||'3123'||Pkg_Hata.getdelimiter||TO_CHAR(r_c1.hesap_no)||Pkg_Hata.getucpointer);
	  ELSE
  	   IF TRUNC(ld_banka_tarihi) >= NVL(TRUNC(r_c1.next_interest_calc_date),TRUNC(ld_banka_tarihi)) THEN
		 ln_tutar := 0;
	     IF r_c1.bakiye_turu = 1 THEN --value balance
		   IF NVL(r_c1.min_faiz_tutari,0) <= r_c1.valorlu_bakiye THEN
		      ln_tutar := r_c1.valorlu_bakiye;
		   END IF;
		 ELSIF r_c1.bakiye_turu = 2 THEN --book balance
		   IF NVL(r_c1.min_faiz_tutari,0) <= r_c1.bakiye THEN
		      ln_tutar := r_c1.bakiye;
		   END IF;
		 ELSIF r_c1.bakiye_turu = 3 THEN --monthly avarage
		   ln_aylik_ortalama_bakiye:=pkg_mis.GetAverageBalance('M',r_c1.hesap_no,pd_today);
		   IF NVL(r_c1.min_faiz_tutari,0) <= ln_aylik_ortalama_bakiye THEN
		      ln_tutar := ln_aylik_ortalama_bakiye;
		   END IF;
		 ELSIF r_c1.bakiye_turu = 4 THEN --yearly avarage
		   ln_yillik_ortalama_bakiye:=pkg_mis.GetAverageBalance('Y',r_c1.hesap_no,pd_today);
		   IF r_c1.min_faiz_tutari <= ln_yillik_ortalama_bakiye THEN
		      ln_tutar := ln_yillik_ortalama_bakiye;
		   END IF;
		 END IF;
		 IF r_c1.faiz_indikatoru IS NOT NULL THEN
		    BEGIN
		      SELECT ROUND(NVL(faiz_orani,0),10)
			    INTO ln_faiz_orani
  			    FROM CBS_FAIZ_INDIKATORU
			   WHERE indikator_no=r_c1.faiz_indikatoru;
		    EXCEPTION
		      WHEN NO_DATA_FOUND THEN
	            ln_faiz_orani:=0;
	  	        log_at(Pkg_Hata.getucpointer||'3280'||Pkg_Hata.getdelimiter||TO_CHAR(r_c1.hesap_no)||Pkg_Hata.getdelimiter||TO_CHAR(r_c1.faiz_indikatoru)||Pkg_Hata.getucpointer);
		    END;
		  ELSE
		    ln_faiz_orani:=ROUND(NVL(r_c1.faiz_orani,0),10);
		  END IF;
          IF ln_tutar > 0 THEN
			IF r_c1.bakiye_turu = 1 THEN --value balance
	  	       ln_faiz:=ln_gun_farki*ln_tutar*ln_faiz_orani/(r_c1.esas_gun_sayisi*100);
    		ELSIF r_c1.bakiye_turu = 2 THEN --book balance
	  	       ln_faiz:=ln_gun_farki*ln_tutar*ln_faiz_orani/(r_c1.esas_gun_sayisi*100);
			ELSIF r_c1.bakiye_turu = 3 THEN --monthly avarage
			   IF Pkg_Batch.ay_sonu_mu THEN   --aysonu ise
			     ln_faiz:=ln_songun*ln_tutar*ln_faiz_orani/(r_c1.esas_gun_sayisi*100);
			   END IF;
		    ELSIF r_c1.bakiye_turu = 4 THEN   --yearly avarage
			   IF Pkg_Batch.yil_sonu_mu THEN  --yilsonu ise
			     ln_faiz:=ln_yil_gun*ln_tutar*ln_faiz_orani/(r_c1.esas_gun_sayisi*100);
			   END IF;
		    END IF;
          END IF;
        END IF; -- faiz_baslangic_tarihi
	  END IF;
	  ln_sum_faiz:=ln_sum_faiz+Pkg_Kur.doviz_doviz_karsilik(r_c1.DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,ln_faiz,1,NULL,NULL,'N','A');
	END LOOP;
	CLOSE c1;

	return ln_sum_faiz;

End;
---------------------------------------------------------------------------------------
FUNCTION CalcTimeDepositInterest(pn_MUSTERINO NUMBER, pd_today date ) RETURN NUMBER is
    CURSOR c1 IS
     SELECT chb.HESAP_NO,chb.VALORLU_BAKIYE,ch.FAIZ_ORANI,ch.ESAS_GUN_SAYISI,ch.DOVIZ_KODU
       FROM CBS_HESAP_GUNLUK_BAKIYE chb,CBS_HESAP_VADELI ch
      WHERE chb.HESAP_NO=ch.HESAP_NO
	  	AND	DURUM_KODU='A'
		AND ch.MUSTERI_NO=pn_MUSTERINO
		and YIL=to_number(to_char(pd_today,'YYYY')) and AY=to_number(to_char(pd_today,'MM')) and GUN=to_number(to_char(pd_today,'DD'));

    r_c1	 					c1%ROWTYPE;
    ln_commit_counter			NUMBER:=0;
    ld_banka_tarihi				DATE;
    ld_sonraki_banka_tarihi		DATE;

	ln_bugun					NUMBER;
	ln_yarin					NUMBER;
	ln_songun					NUMBER;
	ln_gun_farki				NUMBER;

	ln_durum_kodu				NUMBER:=0;
	ln_faiz						NUMBER ; --(20,10);  -- mutluo 190104
	ln_sum_faiz				    NUMBER:=0 ;

BEGIN

	ln_gun_farki:=pkg_mis.CalculateDayDifference(pd_today);

	OPEN c1;
	LOOP
	  FETCH c1 INTO r_c1;
	  EXIT WHEN c1%NOTFOUND;

	  IF r_c1.esas_gun_sayisi IS NULL OR r_c1.esas_gun_sayisi = 0 THEN
	  	log_at(Pkg_Hata.GetUCPOINTER||'3123'||Pkg_Hata.GetDelimiter||TO_CHAR(r_c1.hesap_no)||Pkg_Hata.GetUCPOINTER);
	  ELSE
	  	ln_faiz:=  ROUND((ln_gun_farki*NVL(r_c1.valorlu_bakiye,0)*NVL(r_c1.faiz_orani,0))/(r_c1.esas_gun_sayisi*100),10);
	  END IF;

	  ln_sum_faiz:=ln_sum_faiz+Pkg_Kur.doviz_doviz_karsilik(r_c1.DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,ln_faiz,1,NULL,NULL,'N','A');
	END LOOP;
	CLOSE c1;

	return ln_sum_faiz;
End;

---------------------------------------------------------------------------------------
FUNCTION CalcLoanInterest(pn_MUSTERINO NUMBER, pd_today date ) RETURN NUMBER is
    CURSOR c1 IS
     SELECT chb.HESAP_NO,chb.VALORLU_BAKIYE,ch.FAIZ_ORANI,ch.ESAS_GUN_SAYISI,ch.KOMISYON_ORANI,ch.faiz_baslangic_tarihi,ch.sch_faiz_orani,
			Pkg_Parametre.DEGER(MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,'TAKODEME') lc_takodeme,
			ch.DOVIZ_KODU
       FROM CBS_HESAP_GUNLUK_BAKIYE chb,CBS_HESAP_KREDI ch
      WHERE chb.HESAP_NO=ch.HESAP_NO
	  	AND	DURUM_KODU='A'
		AND ch.MUSTERI_NO=pn_MUSTERINO
		and YIL=to_number(to_char(pd_today,'YYYY')) and AY=to_number(to_char(pd_today,'MM')) and GUN=to_number(to_char(pd_today,'DD'));

    r_c1	 					c1%ROWTYPE;

    ln_commit_counter			NUMBER:=0;
    ld_banka_tarihi				DATE;
    ld_sonraki_banka_tarihi		DATE;

	ln_bugun					NUMBER;
	ln_yarin					NUMBER;
	ln_songun					NUMBER;
	ln_gun_farki				NUMBER;

	ln_durum_kodu			    NUMBER:=0;
	ln_faiz						NUMBER;
	ln_komisyon					NUMBER;
	ln_sc_faiz					NUMBER;

	ln_sum_faiz					NUMBER:=0;
  BEGIN

  	ln_gun_farki:=pkg_mis.CalculateDayDifference(pd_today);

	OPEN c1;
	LOOP
	  FETCH c1 INTO r_c1;
	  EXIT WHEN c1%NOTFOUND;

	  IF r_c1.esas_gun_sayisi IS NULL OR r_c1.esas_gun_sayisi = 0 THEN
	  	 log_at(Pkg_Hata.GetUCPOINTER||'3123'||Pkg_Hata.GetDelimiter||TO_CHAR(r_c1.hesap_no)||Pkg_Hata.GetUCPOINTER);
	  ELSE
		ln_faiz:= ROUND(ln_gun_farki*NVL(r_c1.valorlu_bakiye,0)*NVL(r_c1.faiz_orani,0)/(r_c1.esas_gun_sayisi*100),10);
		ln_komisyon:=ROUND(ln_gun_farki*NVL(r_c1.valorlu_bakiye,0)*NVL(r_c1.komisyon_orani,0)/(r_c1.esas_gun_sayisi*100),10);
		ln_sc_faiz:=ROUND(ln_gun_farki*NVL(r_c1.valorlu_bakiye,0)*NVL(r_c1.sch_faiz_orani,0)/(r_c1.esas_gun_sayisi*100),10);
	  END IF;

	  ln_sum_faiz:=ln_sum_faiz+Pkg_Kur.doviz_doviz_karsilik(r_c1.DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,ln_faiz,1,NULL,NULL,'N','A');

	END LOOP;
	CLOSE c1;

	return abs(ln_sum_faiz);
End;
---------------------------------------------------------------------------------------
FUNCTION CalcITRInterest(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER is
    CURSOR c1 IS
     SELECT distinct DOVIZ_KODU
       FROM cbs_vw_hesap_izleme
      WHERE MUSTERI_NO=pn_MUSTERINO
	  	AND	DURUM_KODU='A';

    r_c1	 		c1%ROWTYPE;

	ln_current 		number:=0;
	ln_timedep 		number:=0;
	ln_loan 		number:=0;
	ln_rate			number:=0;

	ln_faiz			number:=0;
	ln_faiz_current	number:=0;
	ln_faiz_time	number:=0;
	ln_faiz_loan	number:=0;

	ln_sum_faiz		number:=0;
	ln_gun_farki	number;
	ln_yeardays		number:=365;
Begin
	ln_gun_farki:=pkg_mis.CalculateDayDifference(pd_today);
	ln_yeardays:=365;

	OPEN c1;
	LOOP
	FETCH c1 INTO r_c1;
	EXIT WHEN c1%NOTFOUND;
		ln_current:=pkg_mis.SumOfCurrentDeposits(pn_MUSTERINO,r_c1.DOVIZ_KODU,pd_today);
		ln_rate:=pkg_mis.GetITRRate(r_c1.DOVIZ_KODU,'DEPOSIT');
		ln_faiz_current:= ROUND(ln_gun_farki*NVL(ln_current,0)*NVL(ln_rate,0)/(ln_yeardays*100),10);

		ln_timedep:=pkg_mis.SumOfTimeDeposits(pn_MUSTERINO,r_c1.DOVIZ_KODU,pd_today);
		ln_rate:=pkg_mis.GetITRRate(r_c1.DOVIZ_KODU,'DEPOSIT');
		ln_faiz_time:= ROUND(ln_gun_farki*NVL(ln_timedep,0)*NVL(ln_rate,0)/(ln_yeardays*100),10);

		ln_loan:=pkg_mis.SumOfLoans(pn_MUSTERINO,r_c1.DOVIZ_KODU,pd_today);
		ln_rate:=pkg_mis.GetITRRate(r_c1.DOVIZ_KODU,'LOAN');
		ln_faiz_loan:= ROUND(ln_gun_farki*NVL(ln_loan,0)*NVL(ln_rate,0)/(ln_yeardays*100),10);

		ln_faiz:=ln_faiz_current+ln_faiz_time-ln_faiz_loan;
		ln_sum_faiz:=ln_sum_faiz+Pkg_Kur.doviz_doviz_karsilik(r_c1.DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,ln_faiz,1,NULL,NULL,'N','A');

	END LOOP;
	CLOSE c1;

	return ln_sum_faiz;
End;
---------------------------------------------------------------------------------------
FUNCTION CalcCustFXProfit(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER is
	ln_profit_buy					   number;
	ln_profit_sell					   number;
	ln_profit_abj					   number;
	ln_profit						   number;
	ln_profit_bs					   number;

Begin
	begin
		select nvl(sum(i.TUTAR*(i.kur-Pkg_Kur.doviz_doviz_karsilik(i.DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,1,1,NULL,NULL,'N','A'))),0)
		into ln_profit_buy
		from CBS_DTH_TL_ODEME_ISLEM i, cbs_islem t
		where i.tx_no=t.numara
		and i.ISLEM_TARIHI=pd_today
		and i.MUSTERI_NO=pn_MUSTERINO
		and t.durum='P';
	exception
		when no_data_found then
			 log_at(1,pn_MUSTERINO,ln_profit_buy);
			 ln_profit_buy:=0;
	end;

	begin
		select sum(TAHSIL_ADILEN_TOPLAM_TUTAR-Pkg_Kur.doviz_doviz_karsilik(i.DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,i.doviz_tutari,1,NULL,NULL,'N','A')) nb_rate
		into ln_profit_sell
		from CBS_DTH_DOVIZ_SATIS_ISLEM i, cbs_islem t
		where i.tx_no=t.numara
		and islem_tarihi=pd_today
		and i.musteri_no=pn_MUSTERINO
		and t.durum='P';
	exception
		when no_data_found then
			 ln_profit_sell:=0;
	end;

	begin
		select sum(Pkg_Kur.doviz_doviz_karsilik(pkg_kur_rezervasyon.sf_base_doviz_hangisi(ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU),Pkg_Genel.lc_al,pd_today,
			decode(pkg_kur_rezervasyon.sf_base_doviz_hangisi(ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU),ALIS_DOVIZ_KODU,ALIS_TUTARI, SATIS_TUTARI)*
			decode(pkg_kur_rezervasyon.sf_base_doviz_hangisi(ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU),ALIS_DOVIZ_KODU,-1,1)*
			(PARITE-(decode(pkg_kur_rezervasyon.sf_base_doviz_hangisi(ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU),ALIS_DOVIZ_KODU,ALIS_KURU,SATIS_KURU)/decode(pkg_kur_rezervasyon.sf_base_doviz_hangisi(ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU),ALIS_DOVIZ_KODU,SATIS_KURU,ALIS_KURU)))
			,1,NULL,NULL,'N','A')) a
		into ln_profit_abj
		from CBS_ARBITRAJ_ISLEM i, cbs_islem t
		where i.tx_no=t.numara
		and t.islem_kod=1204
		and trunc(i.ISLEM_TARIHI)=pd_today
		and i.musteri_no=pn_MUSTERINO
		and i.KUR_PARITE_SECIM='P'
		and t.durum='P';
	exception
		when no_data_found then
			 ln_profit_abj:=0;
	end;

	begin
		select sum(decode(pkg_kur_rezervasyon.sf_base_doviz_hangisi(ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU),ALIS_DOVIZ_KODU,ALIS_TUTARI, SATIS_TUTARI)*
	   		   decode(pkg_kur_rezervasyon.sf_base_doviz_hangisi(ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU),ALIS_DOVIZ_KODU,ALIS_KURU-Pkg_Kur.doviz_doviz_karsilik(ALIS_DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,1,1,NULL,NULL,'N','A'),
	   																	                                   SATIS_KURU-Pkg_Kur.doviz_doviz_karsilik(SATIS_DOVIZ_KODU,Pkg_Genel.lc_al,pd_today,1,1,NULL,NULL,'N','A')))
		into ln_profit_bs
		from CBS_ARBITRAJ_ISLEM i, cbs_islem t
		where i.tx_no=t.numara
		and t.islem_kod=1207
		and trunc(i.ISLEM_TARIHI)=pd_today
		and i.musteri_no=pn_MUSTERINO
		and i.KUR_PARITE_SECIM='K'
		and i.URUN_TUR_KOD in ('ACC-ACC','ACC-GL')
		and t.durum='P';
	exception
		when no_data_found then
			 ln_profit_bs:=0;
	end;

	ln_profit:=nvl(ln_profit_buy,0)+nvl(ln_profit_sell,0)+nvl(ln_profit_abj,0)+nvl(ln_profit_bs,0);

	return ln_profit;

End;
-------------------------------------------------------------------------------------------
Procedure CreateMISReport(pd_today date ) is
	 ld_BANK_DATE date;
	 ln_MUSTERI_NO number;
	 ln_FX_PROFIT number;
	 ln_INTEREST_REAL number;
	 ln_INTEREST_ITR number;
	 ln_INTEREST_TOTAL number;
	 ln_COMM_PROFIT number;

	 CURSOR c1 IS
		SELECT distinct MUSTERI_NO
		FROM cbs_vw_hesap_izleme
		WHERE DURUM_KODU='A';

    r_c1	 		c1%ROWTYPE;
begin
	ld_BANK_DATE:=pd_today;
    OPEN c1;
	LOOP
	FETCH c1 INTO r_c1;
	EXIT WHEN c1%NOTFOUND;
		ln_MUSTERI_NO:=r_c1.MUSTERI_NO;
		ln_FX_PROFIT:=pkg_mis.CalcCustFXProfit(ln_MUSTERI_NO,ld_BANK_DATE);
		ln_INTEREST_REAL:=pkg_mis.CalcLoanInterest(ln_MUSTERI_NO,ld_BANK_DATE)-pkg_mis.CalcTimeDepositInterest(ln_MUSTERI_NO,ld_BANK_DATE)-pkg_mis.CalcCurrentDepositInterest(ln_MUSTERI_NO,ld_BANK_DATE);
		--log_at(ln_MUSTERI_NO,ld_BANK_DATE,ln_INTEREST_REAL);
		ln_INTEREST_ITR:=pkg_mis.CalcITRInterest(ln_MUSTERI_NO,ld_BANK_DATE);
		ln_INTEREST_TOTAL:=ln_INTEREST_REAL+ln_INTEREST_ITR;
		ln_COMM_PROFIT:=0;

		insert into CBS_MIS_CUSTOMER_PROFIT
		(BANK_DATE, MUSTERI_NO, FX_PROFIT, INTEREST_REAL, INTEREST_ITR, INTEREST_TOTAL, COMM_PROFIT)
		values
		(ld_BANK_DATE, ln_MUSTERI_NO, ln_FX_PROFIT, ln_INTEREST_REAL, ln_INTEREST_ITR, ln_INTEREST_TOTAL, ln_COMM_PROFIT);

	END LOOP;
	CLOSE c1;

end;
----------------------------------------------------------------------------------------------------------------
end PKG_MIS;
/

