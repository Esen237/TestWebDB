create PACKAGE BODY     Pkg_Genel IS
   PROCEDURE sp_pathli_gonder_dosya_adi_al(ps_pathli_dosya VARCHAR2 , ps_dosya_adi OUT VARCHAR2,ps_path_adi OUT VARCHAR2 )
   IS
    BEGIN
    SELECT REVERSE(SUBSTR(REVERSE(ps_pathli_dosya),1,INSTR(REVERSE(ps_pathli_dosya),'\') - 1) ),
             REVERSE(SUBSTR(REVERSE(ps_pathli_dosya),INSTR(REVERSE(ps_pathli_dosya),'\') ))
    INTO  ps_dosya_adi ,ps_path_adi
    FROM dual ;

   END sp_pathli_gonder_dosya_adi_al ;

  PROCEDURE pro_exec_dinamik_sql(sql_str IN   VARCHAR2, durum IN OUT BOOLEAN,err_mes OUT   VARCHAR2      ) IS
    cursor_ad  INTEGER;
    ret  INTEGER;
    BEGIN
      durum := TRUE;
      cursor_ad := dbms_sql.open_cursor;
      dbms_sql.parse(cursor_ad, sql_str, dbms_sql.native);
      ret := dbms_sql.EXECUTE(cursor_ad);
      dbms_sql.close_cursor(cursor_ad);
  EXCEPTION
   WHEN OTHERS THEN
     durum := FALSE ;
     err_mes := SUBSTR(SQLERRM(SQLCODE),1,100);
  END;

   FUNCTION  rol_adi_getir(pn_rol_numara NUMBER) RETURN VARCHAR2 IS
     ps_rol_tanim CBS_ROL.tanim%TYPE;
   BEGIN
         SELECT tanim
        INTO ps_rol_tanim
        FROM CBS_ROL
       WHERE numara=pn_rol_numara;
     RETURN ps_rol_tanim;
   EXCEPTION
       WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,'37;'||SQLERRM);
   END;

  /*****************************************************************************************************************/
  /*   Procedure  Sp_Sql_Gonder_Ref_Cursor_Al                                                                          */
  /*   Created By :Seval Balci
  /*   Date          :06.08.03
  /*   Purpose    : Gonderilen sql statement sonucunu referans cursor olarak geri d?nd?r?r.                                       */
  /*   Kullan?m yerleri d?viz kodu baz?nda k?r?l?m toplam? al?nmak istenen formlar olabilir.                        */
  /*   Orn: karsiliksiz cek izleme                                                                                          */
  /*****************************************************************************************************************/

   PROCEDURE Sp_Sql_Gonder_Ref_Cursor_Al( ps_sql IN VARCHAR2, pc_return_cursor IN OUT t_refcur )
   IS
   BEGIN
   OPEN pc_return_cursor FOR ps_sql;

   EXCEPTION
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '188' || Pkg_Hata.getDelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM  || Pkg_Hata.getUCPOINTER);
   END Sp_Sql_Gonder_Ref_Cursor_Al;

  FUNCTION LC_al(p_currency OUT VARCHAR2) RETURN NUMBER IS
  BEGIN
    p_currency:=Pkg_Genel.lc_al;
        RETURN 1;
  END;

  FUNCTION FC_al(p_currency OUT VARCHAR2) RETURN NUMBER IS
  BEGIN
    p_currency:='USD';
        RETURN 1;
  END;

  FUNCTION LC_al RETURN VARCHAR2 IS
  BEGIN
    RETURN 'KGS';
  END;

  FUNCTION FC_al RETURN VARCHAR2 IS
  BEGIN
    RETURN 'USD';
  END;

  FUNCTION  genel_kod_al(ps_kod_adi IN VARCHAR2) RETURN NUMBER IS
  PRAGMA AUTONOMOUS_TRANSACTION;

  ln_ret_val NUMBER;

  CURSOR cur_genel_kod IS
    SELECT * FROM CBS_GENEL_KOD
     WHERE kod_adi = ps_kod_adi FOR UPDATE;

  row_genel_kod CBS_GENEL_KOD%ROWTYPE;

  BEGIN
    IF cur_genel_kod%ISOPEN THEN
       CLOSE cur_genel_kod;
    END IF;

      OPEN cur_genel_kod;
    FETCH cur_genel_kod INTO row_genel_kod;

    IF  cur_genel_kod%NOTFOUND THEN
      CLOSE cur_genel_kod;
      INSERT INTO CBS_GENEL_KOD
                  (kod_adi, kod_deger, son_kod_alan, son_tarih, yaratan_kullanici, yaratildigi_tarih)
           VALUES (ps_kod_adi, 1, USER, SYSDATE, USER, SYSDATE);
      ln_ret_val := 1;
     ELSE
       ln_ret_val := row_genel_kod.kod_deger + 1;
       UPDATE CBS_GENEL_KOD
         SET kod_deger=kod_deger + 1,
             son_kod_alan = USER,
             son_tarih = SYSDATE
        WHERE CURRENT OF cur_genel_kod;
     END IF;
     COMMIT;
     RETURN(ln_ret_val );
  END;

  FUNCTION Sf_Sira_No_Getir(ps_table_name VARCHAR2,pn_txno NUMBER) RETURN NUMBER IS
   ln_sirano NUMBER := 1 ;
   ls_sql VARCHAR2(200)  :='SELECT max(sira_no) + 1 FROM ' || ps_table_name  || ' Where tx_no = ' || pn_txno;
   BEGIN
       EXECUTE IMMEDIATE ls_sql INTO ln_sirano;
   RETURN NVL(ln_sirano,1);
   EXCEPTION
     WHEN OTHERS  THEN
         dbms_output.put_line(  'Hata :' || TO_CHAR(SQLCODE)||' '||SQLERRM );
         RETURN 1 ;
  END Sf_Sira_No_Getir;

  FUNCTION  bankamiz_adi_al RETURN VARCHAR2 IS
  BEGIN
    RETURN('Demir Kyrgyz Bank');
  END;

  FUNCTION  bankamiz_kodu_al RETURN VARCHAR2 IS
  BEGIN
    RETURN('118');
  END;

  FUNCTION  sehir_adi_al(ps_sehir_kod IN VARCHAR2) RETURN VARCHAR2 IS

  CURSOR cur_sehir IS
    SELECT il_adi
      FROM CBS_IL_KODLARI
     WHERE il_kodu = ps_sehir_kod;
  ls_adi  CBS_IL_KODLARI.il_adi%TYPE;

  BEGIN
    IF cur_sehir%isopen THEN
       CLOSE cur_sehir;
    END IF;

    OPEN cur_sehir;
    FETCH cur_sehir INTO ls_adi;
     IF cur_sehir%NOTFOUND THEN
         CLOSE cur_sehir;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '110' || Pkg_Hata.getUCPOINTER);
--        ls_adi := '?ehir Bulunamad?';
     END IF;
    CLOSE cur_sehir;

    RETURN(ls_adi);

  END;

   FUNCTION  ilce_adi_al(ps_il_kod CBS_IL_KODLARI.il_kodu%TYPE,ps_ilce_kod IN CBS_ILCE_KODLARI.ilce_kodu%TYPE) RETURN VARCHAR2
 IS
  CURSOR cur_ilce IS
    SELECT ilce_adi
      FROM CBS_ILCE_KODLARI
     WHERE il_kodu = ps_il_kod AND
            ilce_kodu = ps_ilce_kod;

  ls_adi  CBS_ILCE_KODLARI.ilce_adi%TYPE;

  BEGIN
    IF cur_ilce%isopen THEN
       CLOSE cur_ilce;
    END IF;

    OPEN cur_ilce;
    FETCH cur_ilce INTO ls_adi;
     IF cur_ilce%NOTFOUND THEN
         CLOSE cur_ilce;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '86' || Pkg_Hata.getUCPOINTER);
     END IF;
    CLOSE cur_ilce;

    RETURN(ls_adi);

  END;

  FUNCTION  bolum_adi_al(ps_bolum_kod IN VARCHAR2) RETURN VARCHAR2 IS
  CURSOR cur_bolum IS
    SELECT adi
      FROM CBS_BOLUM
     WHERE kodu = ps_bolum_kod;
  ls_adi  CBS_BOLUM.adi%TYPE;

  BEGIN
    IF cur_bolum%isopen THEN
       CLOSE cur_bolum;
    END IF;

    OPEN cur_bolum;
    FETCH cur_bolum INTO ls_adi;
     IF cur_bolum%NOTFOUND THEN
        CLOSE cur_bolum;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '109' || Pkg_Hata.getUCPOINTER);
     END IF;
    CLOSE cur_bolum;

    RETURN(ls_adi);

  END;

  FUNCTION  sf_sil_turkce_char(ps_string VARCHAR2) RETURN  VARCHAR2
  IS
    ls_string VARCHAR2(100) := ps_string;
  BEGIN
       IF ls_string  IS NOT NULL THEN
          ls_string := REPLACE(REPLACE(REPLACE(REPLACE(UPPER(trim(ps_string)),'.'),'/'),'-'),' ');
          ls_string := TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(ls_string,'?','S'),'?','G'),'?','U'),'?','I'),'?','O'),'?','C');
        END IF;
     RETURN ls_string;
   END;

  FUNCTION  banka_adi_al_eft(ps_eft_kodu IN VARCHAR2) RETURN VARCHAR2 IS
  CURSOR cur_banka IS
    SELECT banka_adi
      FROM CBS_BANKA_KODLARI
     WHERE SUBSTR('0000'||banka_tcmb_kodu,-6) = SUBSTR('0000'||ps_eft_kodu,-6);
  ls_adi  CBS_BANKA_KODLARI.banka_adi%TYPE;

  BEGIN
    IF cur_banka%isopen THEN
       CLOSE cur_banka;
    END IF;
    OPEN cur_banka;
    FETCH cur_banka INTO ls_adi;
     IF cur_banka%NOTFOUND THEN
        CLOSE cur_banka;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '108' || Pkg_Hata.getUCPOINTER);
     END IF;
    CLOSE cur_banka;

    RETURN(ls_adi);

  END;

  FUNCTION  sube_adi_al_eft(ps_banka_eft_kodu IN VARCHAR2, ps_sube_eft_kodu IN VARCHAR2) RETURN VARCHAR2  IS
  CURSOR cur_sube IS
    SELECT s.sube_adi
      FROM CBS_BANKA_SUBE_KODLARI s, CBS_BANKA_KODLARI b
     WHERE SUBSTR('0000'||b.banka_tcmb_kodu,-4) = SUBSTR('0000'||ps_banka_eft_kodu,-4)
       AND s.banka_kodu = b.banka_kodu
       AND SUBSTR('0000'||s.sube_kodu,-5) = SUBSTR('0000'||ps_sube_eft_kodu,-5);
  ls_adi  CBS_BANKA_SUBE_KODLARI.sube_adi%TYPE;

  BEGIN
    IF cur_sube%isopen THEN
       CLOSE cur_sube;
    END IF;

    OPEN cur_sube;
    FETCH cur_sube INTO ls_adi;
     IF cur_sube%NOTFOUND THEN
        CLOSE cur_sube;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '107' ||Pkg_Hata.getDelimiter || ps_banka_eft_kodu || Pkg_Hata.getDelimiter || ps_sube_eft_kodu || Pkg_Hata.getUCPOINTER);
     END IF;
    CLOSE cur_sube;
    RETURN(ls_adi);
  END;

   FUNCTION  bolum_adi_al_eft(ps_bolum_kod IN VARCHAR2) RETURN VARCHAR2 IS
  CURSOR cur_bolum IS
    SELECT adi
      FROM CBS_BOLUM
     WHERE eft_kodu = ps_bolum_kod;
  ls_adi  CBS_BOLUM.adi%TYPE;

  BEGIN
    IF cur_bolum%isopen THEN
       CLOSE cur_bolum;
    END IF;

    OPEN cur_bolum;
    FETCH cur_bolum INTO ls_adi;
     IF cur_bolum%NOTFOUND THEN
        CLOSE cur_bolum;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '109' || Pkg_Hata.getUCPOINTER);
     END IF;
    CLOSE cur_bolum;

    RETURN(ls_adi);
  END;

  FUNCTION  bolum_sehir_kodu(ps_bolum_kod IN VARCHAR2) RETURN VARCHAR2 IS
  ls_il_kodu  CBS_BOLUM.il_kodu%TYPE;

  BEGIN
    SELECT il_kodu
      INTO ls_il_kodu
      FROM CBS_BOLUM
     WHERE kodu = ps_bolum_kod;
    RETURN(ls_il_kodu);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '135' || Pkg_Hata.getUCPOINTER);
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '136' || Pkg_Hata.getDELIMITER || SQLERRM  || Pkg_Hata.getUCPOINTER);
  END;


  FUNCTION  ulke_adi_al(ps_ulke_kod IN CBS_ULKE_KODLARI.ulke_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_ulke_adi      CBS_ULKE_KODLARI.ulke_adi%TYPE;
  BEGIN
      SELECT ulke_adi
    INTO   ls_ulke_adi
    FROM   CBS_ULKE_KODLARI
    WHERE  ulke_kodu = ps_ulke_kod  ;

    RETURN ls_ulke_adi ;

  EXCEPTION
     WHEN NO_DATA_FOUND THEN RETURN NULL ;
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '87' || Pkg_Hata.getUCPOINTER);
  END;

   FUNCTION   Islem_Adi_Al(ps_islem_kod IN CBS_ISLEM_TANIM.kod%TYPE) RETURN VARCHAR2
  IS
    ls_islem_adi       CBS_ISLEM_TANIM.aciklama%TYPE;
  BEGIN
      SELECT aciklama
    INTO   ls_islem_adi
    FROM   CBS_ISLEM_TANIM
    WHERE  kod = ps_islem_kod ;

    RETURN ls_islem_adi ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '59' || Pkg_Hata.getUCPOINTER);
  END;


    FUNCTION  bolum_sube_mi(ps_bolum_kod IN VARCHAR2) RETURN VARCHAR2 IS
  CURSOR cur_bolum IS
    SELECT sube_f
      FROM CBS_BOLUM
     WHERE kodu = ps_bolum_kod;
  ls_sube_f  CBS_BOLUM.sube_f%TYPE;

  BEGIN
    IF cur_bolum%isopen THEN
       CLOSE cur_bolum;
    END IF;

    OPEN cur_bolum;
    FETCH cur_bolum INTO ls_sube_f;
     IF cur_bolum%NOTFOUND THEN
        CLOSE cur_bolum;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1143' || Pkg_Hata.getUCPOINTER);
     END IF;
    CLOSE cur_bolum;

    RETURN(ls_sube_f);

  END;

   FUNCTION  Istatistik_kodu_al(ps_islem_kod IN CBS_ISLEM_TANIM.kod%TYPE,ps_modul_tur_kod IN CBS_MODUL_TUR.kod%TYPE,ps_urun_tur_kod IN CBS_URUN_TUR.kod%TYPE,ps_urun_sinif_kod IN CBS_URUN_SINIF.kod%TYPE, pn_index NUMBER) RETURN VARCHAR2 IS
     ls_istatistik_kodu_1 CBS_ISTATISTIK_ESLEME.istatistik_kodu_1%TYPE;
     ls_istatistik_kodu_2 CBS_ISTATISTIK_ESLEME.istatistik_kodu_1%TYPE;
     ls_istatistik_kodu_3 CBS_ISTATISTIK_ESLEME.istatistik_kodu_1%TYPE;
   BEGIN
     SELECT istatistik_kodu_1,istatistik_kodu_2,istatistik_kodu_3
       INTO ls_istatistik_kodu_1,ls_istatistik_kodu_2,ls_istatistik_kodu_3
       FROM CBS_ISTATISTIK_ESLEME
      WHERE islem_tanim_kod = ps_islem_kod
        AND modul_tur_kod = ps_modul_tur_kod
        AND urun_tur_kod = ps_urun_tur_kod
        AND urun_sinif_kod = ps_urun_sinif_kod;
     IF pn_index = 1 THEN
          RETURN ls_istatistik_kodu_1;
     ELSIF pn_index = 2 THEN
          RETURN ls_istatistik_kodu_2;
     ELSIF pn_index = 3 THEN
          RETURN ls_istatistik_kodu_3;
     END IF;
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1224' || Pkg_Hata.getUCPOINTER);
   EXCEPTION
        WHEN NO_DATA_FOUND THEN
           RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1222' || Pkg_Hata.getUCPOINTER);
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1223' || Pkg_Hata.getDELIMITER || SQLERRM  || Pkg_Hata.getUCPOINTER);
   END;
---Tutar yuvarla
   FUNCTION     TutarYuvarla(pn_tutar IN NUMBER,ps_doviz_kodu    IN VARCHAR2) RETURN NUMBER IS
           ln_tutar                       NUMBER;
        ls_kuruslu_mu                   VARCHAR2(1);
   BEGIN
           SELECT kuruslu_mu INTO ls_kuruslu_mu
        FROM CBS_DOVIZ_KODLARI
        WHERE doviz_kodu=ps_doviz_kodu;

        IF ls_kuruslu_mu='E' THEN
           RETURN ROUND(pn_tutar,2);
        ELSE
           RETURN ROUND(pn_tutar,0);
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER ||'1230'|| Pkg_Hata.getDELIMITER || ps_doviz_kodu || Pkg_Hata.getUCPOINTER);
   END;
--------LAST


FUNCTION  ulke_durum(ps_ulke_kod IN CBS_ULKE_KODLARI.ulke_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_ulke_supheli      CBS_ULKE_KODLARI.supheli%TYPE;
    ls_ulke_yasakli      CBS_ULKE_KODLARI.yasakli%TYPE;
  BEGIN
      SELECT supheli,yasakli
    INTO   ls_ulke_supheli,ls_ulke_yasakli
    FROM   CBS_ULKE_KODLARI
    WHERE  ulke_kodu = ps_ulke_kod  ;

    IF ls_ulke_yasakli='E' THEN RETURN('Y');--YASAKLI
     ELSE
       IF ls_ulke_supheli='E' THEN RETURN ('S');--S?PHEL?
        ELSE
          IF ls_ulke_yasakli<>'E' AND ls_ulke_supheli<>'E' THEN --FREE
             RETURN('F');
          END IF;
       END IF;
    END IF;


  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '87' || Pkg_Hata.getUCPOINTER);
  END;

FUNCTION  doviz_kuruslu_mu(ps_dvz_kod IN CBS_DOVIZ_KODLARI.doviz_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_doviz_kuruslu     CBS_DOVIZ_KODLARI.kuruslu_mu%TYPE;
  BEGIN
      SELECT kuruslu_mu
    INTO   ls_doviz_kuruslu
    FROM   CBS_DOVIZ_KODLARI
    WHERE  doviz_kodu = ps_dvz_kod  ;

    RETURN ls_doviz_kuruslu ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1230' || Pkg_Hata.getUCPOINTER);
  END;

   FUNCTION     sistem_zamani RETURN DATE IS
     ln_tarih_zaman DATE;
   BEGIN
     SELECT SYSDATE
       INTO ln_tarih_zaman
       FROM dual;
     RETURN ln_tarih_zaman;
   END;

   FUNCTION  form_aciklamasi (ps_adi VARCHAR2) RETURN VARCHAR2 IS
     ls_form_adi VARCHAR2(2000);
     ls_tanim    VARCHAR2(2000);
   BEGIN
       ls_form_adi:= NVL(SUBSTR(ps_adi,INSTR(ps_adi,'\',-1)+1,INSTR(ps_adi,'.',-1)-INSTR(ps_adi,'\',-1)-1),ps_adi) ;
    BEGIN
      SELECT adi
        INTO ls_tanim
        FROM CBS_PROGRAM
       WHERE UPPER(kod)=trim(UPPER(ls_form_adi));

    RETURN ls_tanim;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
       BEGIN
        SELECT aciklama
          INTO ls_tanim
          FROM CBS_ISLEM_TANIM
         WHERE 'CBS_TX'||UPPER(kod)=UPPER(ls_form_adi);
      RETURN ls_tanim;
       EXCEPTION
           WHEN NO_DATA_FOUND THEN
          RETURN 'CBS';
        END;
    END;

    END;

   FUNCTION doviz_adi_al(ps_dvz VARCHAR2) RETURN VARCHAR2 IS
   ls_dvz VARCHAR2(50);
   BEGIN
     SELECT aciklama
       INTO ls_dvz
       FROM CBS_DOVIZ_KODLARI
      WHERE doviz_kodu = ps_dvz;
     RETURN ls_dvz;
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '242' || Pkg_Hata.getDelimiter || ps_dvz || Pkg_Hata.getUCPOINTER);
       WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '243' || Pkg_Hata.getDelimiter || ps_dvz || Pkg_Hata.getDelimiter || SQLERRM || Pkg_Hata.getUCPOINTER);
   END;


  FUNCTION  urun_adi_al(ps_modul_tur_kod IN CBS_URUN_SINIF.modul_tur_kod%TYPE,ps_urun_tur_kod IN CBS_URUN_SINIF.urun_tur_kod%TYPE,ps_kod IN CBS_URUN_SINIF.kod%TYPE) RETURN VARCHAR2
   IS
    ls_urun_aciklama      CBS_URUN_SINIF.aciklama%TYPE;
  BEGIN
      SELECT aciklama
           INTO   ls_urun_aciklama
           FROM   CBS_URUN_SINIF
           WHERE  modul_tur_kod = ps_modul_tur_kod
                  AND urun_tur_kod=ps_urun_tur_kod
                  AND kod=ps_kod;

    RETURN ls_urun_aciklama;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2012' || Pkg_Hata.getUCPOINTER);
  END;


  FUNCTION  istatistik_adi_al(ps_istatistik_kodu IN CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_istatistik_adi     CBS_ISTATISTIK_KODLARI.aciklama%TYPE;
  BEGIN
  if  ps_istatistik_kodu is not null then
      SELECT aciklama
    INTO   ls_istatistik_adi
    FROM   CBS_ISTATISTIK_KODLARI
    WHERE  istatistik_kodu = ps_istatistik_kodu  ;
 end if;

    RETURN ls_istatistik_adi ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1222' || Pkg_Hata.getUCPOINTER);
  END;


  FUNCTION  kurus_format_al(ps_doviz IN CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE) RETURN VARCHAR2 IS
    ls_money_format VARCHAR2(40);
  BEGIN

    IF Pkg_Genel.doviz_kuruslu_mu(ps_doviz)='H' THEN
         ls_money_format:='FM999G999G999G999G999G999G999G999G999';
      ELSE
         ls_money_format:='FM999G999G999G999G999G999G999G999G999D00';
    END IF;

    RETURN ls_money_format;

  END;
/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  sehir_adi_al_hatasiz(ps_sehir_kod IN VARCHAR2) RETURN VARCHAR2  IS

  CURSOR cur_sehir IS
    SELECT il_adi
      FROM CBS_IL_KODLARI
     WHERE il_kodu = SUBSTR('000' || ps_sehir_kod, -3);
  ls_adi  CBS_IL_KODLARI.il_adi%TYPE;

  BEGIN
    IF cur_sehir%isopen THEN
       CLOSE cur_sehir;
    END IF;

    OPEN cur_sehir;
    FETCH cur_sehir INTO ls_adi;
     IF cur_sehir%NOTFOUND THEN
        ls_adi := '';
     END IF;
    CLOSE cur_sehir;
    RETURN(ls_adi);
  END;
/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  bolum_adi_al_hatasiz(ps_bolum_kod IN VARCHAR2) RETURN VARCHAR2  IS
  CURSOR cur_bolum IS
    SELECT adi
      FROM CBS_BOLUM
     WHERE kodu = ps_bolum_kod;
  ls_adi  CBS_BOLUM.adi%TYPE;

  BEGIN
    IF cur_bolum%isopen THEN
       CLOSE cur_bolum;
    END IF;

    OPEN cur_bolum;
    FETCH cur_bolum INTO ls_adi;
     IF cur_bolum%NOTFOUND THEN
        ls_adi:= 'Branch not found.';
     END IF;
    CLOSE cur_bolum;
    RETURN(ls_adi);
  END;
/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  banka_adi_al_eft_hatasiz(ps_eft_kodu IN VARCHAR2) RETURN VARCHAR2  IS
  CURSOR cur_banka IS
    SELECT banka_adi
      FROM CBS_BANKA_KODLARI
     WHERE SUBSTR('0000'||banka_tcmb_kodu,-6) = SUBSTR('0000'||ps_eft_kodu,-6);
  ls_adi  CBS_BANKA_KODLARI.banka_adi%TYPE;

  BEGIN
    IF cur_banka%isopen THEN
       CLOSE cur_banka;
    END IF;
    OPEN cur_banka;
    FETCH cur_banka INTO ls_adi;
     IF cur_banka%NOTFOUND THEN
        ls_adi := 'Bank not found.';
     END IF;
    CLOSE cur_banka;
    RETURN(ls_adi);
  END;
/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  bolum_adi_al_eft_hatasiz(ps_bolum_kod IN VARCHAR2) RETURN VARCHAR2  IS
  CURSOR cur_bolum IS
    SELECT adi
      FROM CBS_BOLUM
     WHERE eft_kodu = ps_bolum_kod;
  ls_adi  CBS_BOLUM.adi%TYPE;
  BEGIN
    IF cur_bolum%isopen THEN
       CLOSE cur_bolum;
    END IF;
    OPEN cur_bolum;
    FETCH cur_bolum INTO ls_adi;
     IF cur_bolum%NOTFOUND THEN
        ls_adi := 'Branch not found.';
     END IF;
    CLOSE cur_bolum;
    RETURN(ls_adi);
  END;
/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  sube_adi_al_eft_hatasiz(ps_banka_eft_kodu IN VARCHAR2, ps_sube_eft_kodu IN VARCHAR2) RETURN VARCHAR2   IS
  CURSOR cur_sube IS
    SELECT s.sube_adi
      FROM CBS_BANKA_SUBE_KODLARI s, CBS_BANKA_KODLARI b
     WHERE SUBSTR('0000'||b.banka_tcmb_kodu,-4) = SUBSTR('0000'||ps_banka_eft_kodu,-4)
       AND s.banka_kodu = b.banka_kodu
       AND SUBSTR('0000'||s.sube_kodu,-5) = SUBSTR('0000'||ps_sube_eft_kodu,-5);
  ls_adi  CBS_BANKA_SUBE_KODLARI.sube_adi%TYPE;

  BEGIN
    IF cur_sube%isopen THEN
       CLOSE cur_sube;
    END IF;
    OPEN cur_sube;
    FETCH cur_sube INTO ls_adi;
     IF cur_sube%NOTFOUND THEN
        ls_adi := 'Branch not found.';
     END IF;
    CLOSE cur_sube;
    RETURN(ls_adi);
  END;
/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  bolum_sehir_kodu_hatasiz(ps_bolum_kod IN VARCHAR2) RETURN VARCHAR2  IS
  ls_il_kodu  CBS_BOLUM.il_kodu%TYPE;
  BEGIN
    SELECT il_kodu
      INTO ls_il_kodu
      FROM CBS_BOLUM
     WHERE kodu = ps_bolum_kod;
    RETURN(ls_il_kodu);
    EXCEPTION
      WHEN OTHERS THEN
       RETURN('City of branch could not be found.');
  END;
/*---------------------------------------------------------------------------------------------------*/
   FUNCTION  banka_adi_al_takas(ps_takas_kodu IN VARCHAR2) RETURN VARCHAR2 IS
  CURSOR cur_banka IS
    SELECT banka_adi
      FROM CBS_TAKAS_BANKA_KODLARI
     WHERE SUBSTR('0000'||takas_banka_kodu,-4) = SUBSTR('0000'||ps_takas_kodu ,-4);
  ls_adi  CBS_TAKAS_BANKA_KODLARI.banka_adi%TYPE;

  BEGIN
    IF cur_banka%isopen THEN
       CLOSE cur_banka;
    END IF;
    OPEN cur_banka;
    FETCH cur_banka INTO ls_adi;
     IF cur_banka%NOTFOUND THEN
        ls_adi := 'Bank not found.';
     END IF;
    CLOSE cur_banka;
    RETURN(ls_adi);
  END;
/*---------------------------------------------------------------------------------------------------*/
   FUNCTION  sube_adi_al_takas(ps_takas_banka_kodu IN VARCHAR2, ps_takas_sube_kodu IN VARCHAR2) RETURN VARCHAR2 IS
  CURSOR cur_sube IS
    SELECT s.sube_adi
      FROM CBS_TAKAS_BANKA_SUBE_KODLARI s
     WHERE SUBSTR('0000'||s.takas_banka_kodu,-4) = SUBSTR('0000'||ps_takas_banka_kodu,-4)
       AND s.takas_sube_kodu = ps_takas_sube_kodu;
  ls_adi  CBS_TAKAS_BANKA_SUBE_KODLARI.sube_adi%TYPE;

  BEGIN
    IF cur_sube%isopen THEN
       CLOSE cur_sube;
    END IF;
    OPEN cur_sube;
    FETCH cur_sube INTO ls_adi;
     IF cur_sube%NOTFOUND THEN
        ls_adi := 'Branch not found.';
     END IF;
    CLOSE cur_sube;
    RETURN(ls_adi);
  END;
/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  uyruk_adi_al(pn_uyruk_kodu CBS_UYRUK_KODLARI.uyruk_kodu%TYPE) RETURN CBS_UYRUK_KODLARI.aciklama%TYPE
   IS
    ls_uyruk_adi      CBS_UYRUK_KODLARI.aciklama%TYPE;
  BEGIN
      SELECT aciklama
    INTO   ls_uyruk_adi
    FROM   CBS_UYRUK_KODLARI
    WHERE  uyruk_kodu = pn_uyruk_kodu  ;

    RETURN ls_uyruk_adi ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1568' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
  END;

/*---------------------------------------------------------------------------------------------------*/
  FUNCTION  CikisKapisi_adi_al(pn_kod CBS_CIKIS_KAPILARI.kod%TYPE) RETURN CBS_CIKIS_KAPILARI.aciklama%TYPE
   IS
    ls_cikis_kapisi_adi      CBS_CIKIS_KAPILARI.aciklama%TYPE;
  BEGIN
      SELECT aciklama
    INTO   ls_cikis_kapisi_adi
    FROM   CBS_CIKIS_KAPILARI
    WHERE  kod = pn_kod  ;

    RETURN ls_cikis_kapisi_adi ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1569' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;

/*---------------------------------------------------------------------------------------------------*/
FUNCTION  urun_tur_adi_al(ps_modul_tur_kod IN CBS_URUN_TUR.modul_tur_kod%TYPE, ps_urun_tur_kod IN CBS_URUN_TUR.kod%TYPE) RETURN VARCHAR2
   IS
    ls_urun_aciklama      CBS_URUN_TUR.aciklama%TYPE;
  BEGIN
        SELECT aciklama
           INTO ls_urun_aciklama
           FROM CBS_URUN_TUR
       WHERE modul_tur_kod = ps_modul_tur_kod
         AND kod=ps_urun_tur_kod;

    RETURN ls_urun_aciklama;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2016' || Pkg_Hata.getUCPOINTER);
  END;

/*---------------------------------------------------------------------------------------------------*/
FUNCTION  Istatistik_Kodu_Bul(pn_islem_kodu IN VARCHAR2, ps_dk_kodu IN VARCHAR2, pn_istatistik_no NUMBER DEFAULT 1) RETURN VARCHAR2 IS
    CURSOR cursor_istatistik IS
      SELECT *
      FROM CBS_ISTATISTIK_ESLEME i
      WHERE i.ISLEM_TANIM_KOD= pn_islem_kodu
      AND i.DK_GRUP_KOD=ps_dk_kodu;

    row_istatistik        cursor_istatistik%ROWTYPE;

  ls_istatistik_kodu  CBS_ISTATISTIK_ESLEME.ISTATISTIK_KODU_1%TYPE;
BEGIN

    OPEN cursor_istatistik;
    FETCH cursor_istatistik INTO row_istatistik;
    IF cursor_istatistik%NOTFOUND THEN
      ls_istatistik_kodu:='';
    ELSE
        IF pn_istatistik_no=1 THEN
          ls_istatistik_kodu:=row_istatistik.ISTATISTIK_KODU_1;
        ELSIF pn_istatistik_no=2 THEN
           ls_istatistik_kodu:=row_istatistik.ISTATISTIK_KODU_2;
        ELSIF pn_istatistik_no=3 THEN
          ls_istatistik_kodu:=row_istatistik.ISTATISTIK_KODU_3;
        ELSIF pn_istatistik_no=4 THEN
          ls_istatistik_kodu:=row_istatistik.ISTATISTIK_KODU_4;
        ELSE
            ls_istatistik_kodu:='';
        END IF;
    END IF;
    CLOSE cursor_istatistik;

    RETURN(ls_istatistik_kodu);
END;
--------------------------------------------------------------------------------------------------
FUNCTION  Doviz_Getirme_Suresi_Bul(ps_ulke_kodu IN VARCHAR2) RETURN NUMBER IS
    ln_dgs                                        NUMBER;
BEGIN
     SELECT doviz_getirme_suresi
     INTO ln_dgs
     FROM CBS_ULKE_KODLARI
     WHERE ulke_kodu=ps_ulke_kodu;

     RETURN ln_dgs;
END;
--------------------------------------------------------------------------------------------------
FUNCTION Urun_sinif_doviz_cinsi(ps_modul_kod  CBS_URUN_SINIF.modul_tur_kod%TYPE,
                                       ps_urun_tur   CBS_MENKUL.urun_tur_kod%TYPE,
                                       ps_urun_sinif CBS_MENKUL.urun_sinif_kod%TYPE) RETURN VARCHAR2
  IS

  ls_doviz_cinsi  CBS_URUN_SINIF.lc%TYPE;

  BEGIN
    -- ?r?n s?n?f TL mi YP mi bilgisini doner

   SELECT lc
   INTO   ls_doviz_cinsi
   FROM   CBS_URUN_SINIF
   WHERE  modul_tur_kod = ps_modul_kod
   AND    urun_tur_kod  = ps_urun_tur
   AND       kod             = ps_urun_sinif ;

   RETURN  ls_doviz_cinsi ;

   EXCEPTION
           WHEN NO_DATA_FOUND THEN RETURN NULL;
           WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2126' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
--------------------------------------------------------------------------------------------------
 FUNCTION ulke_doviz_gelis_gun_al(ps_ulke VARCHAR2) RETURN NUMBER IS
 ln_gun NUMBER;
 BEGIN
   SELECT NVL(doviz_getirme_suresi,0)
     INTO ln_gun
     FROM CBS_ULKE_KODLARI
    WHERE ulke_kodu = ps_ulke;

    RETURN ln_gun;

   EXCEPTION
           WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1932' ||Pkg_Hata.getdelimiter || ps_ulke || Pkg_Hata.getUCPOINTER);
           WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1933' || Pkg_Hata.getdelimiter|| ps_ulke ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM  || Pkg_Hata.getUCPOINTER);

  END;

--------------------------------------------------------------------------------------------------
FUNCTION  ilce_adi_al_hatasiz(ps_il_kod CBS_IL_KODLARI.il_kodu%TYPE,ps_ilce_kod IN CBS_ILCE_KODLARI.ilce_kodu%TYPE) RETURN VARCHAR2
 IS
  CURSOR cur_ilce IS
    SELECT UPPER(ilce_adi)
      FROM CBS_ILCE_KODLARI
     WHERE il_kodu = ps_il_kod AND
            ilce_kodu = ps_ilce_kod;

  ls_adi  CBS_ILCE_KODLARI.ilce_adi%TYPE;

  BEGIN
    IF cur_ilce%isopen THEN
       CLOSE cur_ilce;
    END IF;

    OPEN cur_ilce;
    FETCH cur_ilce INTO ls_adi;
     IF cur_ilce%NOTFOUND THEN
         CLOSE cur_ilce;
        RETURN NULL;
     END IF;
    CLOSE cur_ilce;

    RETURN(ls_adi);

  END;
--------------------------------------------------------------------------------------------------
  FUNCTION  ulke_adi_al_hatasiz(ps_ulke_kod IN CBS_ULKE_KODLARI.ulke_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_ulke_adi      CBS_ULKE_KODLARI.ulke_adi%TYPE;
  BEGIN
      SELECT UPPER(ulke_adi)
    INTO   ls_ulke_adi
    FROM   CBS_ULKE_KODLARI
    WHERE  ulke_kodu = ps_ulke_kod  ;

    RETURN ls_ulke_adi ;

  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '87' || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------
FUNCTION teslim_sekli_aciklama_al(ps_kod IN CBS_TESLIM_SEKILLERI.kod%TYPE) RETURN VARCHAR2
 IS
  ls_aciklama      CBS_TESLIM_SEKILLERI.aciklama%TYPE;
BEGIN
    SELECT aciklama
      INTO   ls_aciklama
      FROM   CBS_TESLIM_SEKILLERI
     WHERE  kod = ps_kod;

RETURN ls_aciklama;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
   RETURN NULL;
 WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1945' || Pkg_Hata.getdelimiter|| ps_kod || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM  || Pkg_Hata.getUCPOINTER);
END;

--------------------------------------------------------------------------------------------------
FUNCTION ihracat_sekli_aciklama_al(ps_kod IN CBS_IHRACAT_SEKLI.kod%TYPE) RETURN VARCHAR2 IS
  ls_aciklama      CBS_TESLIM_SEKILLERI.aciklama%TYPE;
BEGIN
    SELECT aciklama
      INTO ls_aciklama
      FROM CBS_IHRACAT_SEKLI
     WHERE kod = ps_kod;

RETURN ls_aciklama;

EXCEPTION
 WHEN NO_DATA_FOUND THEN
   RETURN NULL;
 WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '614' || Pkg_Hata.getdelimiter|| ps_kod || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM  || Pkg_Hata.getUCPOINTER);
END;
--------------------------------------------------------------------------------------------------
FUNCTION odeme_sekli_aciklama_al(ps_kod IN CBS_ODEME_SEKLI.kod%TYPE) RETURN VARCHAR2 IS
  ls_aciklama      CBS_TESLIM_SEKILLERI.aciklama%TYPE;
BEGIN
    SELECT aciklama
      INTO ls_aciklama
      FROM CBS_ODEME_SEKLI
     WHERE kod = ps_kod;

   RETURN ls_aciklama;

EXCEPTION
 WHEN NO_DATA_FOUND THEN
   RETURN NULL;
 WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '615' || Pkg_Hata.getdelimiter|| ps_kod || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM  || Pkg_Hata.getUCPOINTER);
END;
--------------------------------------------------------------------------------------------------
  /****************************************************************************************************************/
  /*   Function     subemi_genel_mudurluk_mu                                                                            */
  /*   bolum kodu sube ise 'S' genel mudurluk ise 'G' dondurulur                                                  */
  /****************************************************************************************************************/
FUNCTION subemi_genel_mudurluk_mu(ps_bolum_kodu CBS_BOLUM.kodu%TYPE) RETURN VARCHAR2
  IS
    ls_sonuc VARCHAR2(1) ;
    BEGIN
       SELECT DECODE(sube_f,'E','S','G')
       INTO   ls_sonuc
       FROM   CBS_BOLUM
       WHERE  kodu = ps_bolum_kodu;

       RETURN ls_sonuc;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
END;
--------------------------------------------------------------------------------------------------

FUNCTION  bankamiz_uyruk_al RETURN VARCHAR2 IS
  BEGIN
    RETURN('TC');
END;

--------------------------------------------------------------------------------------------------

FUNCTION  bankamiz_vergi_no_al RETURN NUMBER IS
  BEGIN
    RETURN(123);
END;

--------------------------------------------------------------------------------------------------
FUNCTION  gelen_islem_sayisi RETURN NUMBER IS
         ln_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO ln_count
    FROM CBS_VW_ISLEM
    WHERE durum IN ('C','V','1') AND
    (Pkg_Tx.dogrulanabilir_mi(numara)=1
          OR Pkg_Tx.onaylanabilir_mi(numara)=1
          OR Pkg_Tx.iptal_onaylanabilir_mi(numara)=1);

    RETURN ln_count;
END;
--------------------------------------------------------------------------------------------------
   FUNCTION veritabani_al RETURN VARCHAR2 IS
     pc_terminal VARCHAR2(2000);
   BEGIN
     SELECT db_sid
       INTO pc_terminal
       FROM CBS_SYSTEM;
     RETURN pc_terminal;
   END;
-------------------------------------------------------------------------------------------------
   FUNCTION terminal_al RETURN VARCHAR2 IS
     pc_terminal VARCHAR2(2000);
   BEGIN

   select substr(RAPOR_SUNUCUSU,5,100)
     into pc_terminal
     from cbs_kullanici where kodu=user;

--     08-12-2007 Ergun'e sor bu de?i?ikli?i

/*     SELECT sys_context('USERENV','TERMINAL')
       INTO pc_terminal
       FROM CBS_SYSTEM;
*/
     RETURN pc_terminal;
   END;
--------------------------------------------------------------------------------------------------
   FUNCTION rapor_adi_al(pc_rapor_kod VARCHAR2) RETURN VARCHAR2 IS
     pc_rapor_adi VARCHAR2(2000);
   BEGIN
     SELECT adi
       INTO pc_rapor_adi
       FROM CBS_PROGRAM
      WHERE --tur='R' and
              kod=pc_rapor_kod;
      RETURN pc_rapor_adi;
   END;

--------------------------------------------------------------------------------------------------
FUNCTION  urun_sinif_nakdimi(ps_modul_tur_kod IN CBS_URUN_SINIF.modul_tur_kod%TYPE,ps_urun_tur_kod IN CBS_URUN_SINIF.urun_tur_kod%TYPE,ps_kod IN CBS_URUN_SINIF.kod%TYPE) RETURN CBS_URUN_SINIF.nakdi%TYPE
   IS
    ls_urun_aciklama      CBS_URUN_SINIF.nakdi%TYPE := 'H';
  BEGIN
      SELECT nakdi
           INTO   ls_urun_aciklama
           FROM   CBS_URUN_SINIF
           WHERE  modul_tur_kod = ps_modul_tur_kod
                  AND urun_tur_kod=ps_urun_tur_kod
                  AND kod=ps_kod;

    RETURN ls_urun_aciklama;

  EXCEPTION
     WHEN NO_DATA_FOUND THEN RETURN 'H';
      WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1190' || Pkg_Hata.getdelimiter|| ps_kod || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM  || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------
  FUNCTION amir_bolum_no_al(pn_islem_numara NUMBER) RETURN VARCHAR2 IS
    ls_bolum_kodu CBS_ISLEM.amir_bolum_kodu%TYPE;
  BEGIN
    SELECT amir_bolum_kodu
      INTO ls_bolum_kodu
      FROM CBS_ISLEM
     WHERE numara=pn_islem_numara;
    RETURN  ls_bolum_kodu;
  END;
--------------------------------------------------------------------------------------------------
   FUNCTION sf_Bankamiz_adres_al RETURN VARCHAR2
   IS
   BEGIN
        RETURN  '61"A", Kurmangazy Str. Almaty, Kazakhstan';
   END;
--------------------------------------------------------------------------------------------------
   FUNCTION risk_aciklama_al(pn_risk_kodu NUMBER) RETURN VARCHAR2 IS
   CURSOR c_0 IS
    SELECT aciklama FROM CBS_RISK_KODLARI
     WHERE risk_kodu = pn_risk_kodu;
   ls_aciklama CBS_RISK_KODLARI.aciklama%TYPE;
   BEGIN
     OPEN c_0;
       FETCH c_0 INTO ls_aciklama;
       IF c_0%NOTFOUND THEN
        ls_aciklama := NULL;
       END IF;
     CLOSE c_0;
     RETURN ls_aciklama;
    END;
-------------------------------------------------------------------------------------------------
  FUNCTION  Gecikme_Faiz_Grubu_adi_al(ps_grup_kodu IN CBS_GECIKME_FAIZI_URUN_GRUP.grup_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_aciklama     CBS_GECIKME_FAIZI_URUN_GRUP.aciklama%TYPE;
  BEGIN
      SELECT aciklama
    INTO   ls_aciklama
    FROM   CBS_GECIKME_FAIZI_URUN_GRUP
    WHERE  grup_kodu = ps_grup_kodu  ;

    RETURN ls_aciklama ;

  EXCEPTION
     WHEN NO_DATA_FOUND THEN RETURN NULL ;
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4548' || Pkg_Hata.getUCPOINTER);
  END;
------------------------------------------------------------------------------------
FUNCTION lokal_ulke_kod RETURN VARCHAR2 IS
 BEGIN
  RETURN 'KG';
 END;
-------------------------------------------------------------------------------------------------
 FUNCTION nakit_kod_uygunmu (ps_doviz varchar2 ,ps_kod cbs_nakit_kodlari.kod%type) RETURN VARCHAR2
 is
  ls_lc varchar2(1);
 Begin
       select LC
      into ls_lc
      from   cbs_nakit_kodlari
      where  kod = ps_kod ;

      if ls_lc = 'E' then
          if pkg_genel.lc_al = ps_doviz then
            return 'E';
        else
            return 'H';
        end if;
      else
          if pkg_genel.lc_al = ps_doviz then
            return 'H';
        else
            return 'E';
        end if;
      end if;

 End;
------------------------------------------------------------------------------------
  FUNCTION nakit_kod_lc_mi (ps_kod cbs_nakit_kodlari.kod%type) RETURN VARCHAR2
  is
  ls_lc varchar2(1);
  Begin
         select lc
       into ls_lc
       from cbs_nakit_kodlari
       where kod = ps_kod ;

       return ls_lc;
 EXCEPTION
     WHEN OTHERS THEN RETURN NULL ;

  End;
-------------------------------------------------------------------------------------------------
  FUNCTION nakit_kod_adi_al (ps_kod cbs_nakit_kodlari.kod%type) RETURN VARCHAR2
  is
  ls_aciklama cbs_nakit_kodlari.aciklama%type;
  begin
         select aciklama
       into ls_aciklama
       from cbs_nakit_kodlari
       where kod = ps_kod ;

       return ls_aciklama;

 EXCEPTION
     WHEN OTHERS THEN RETURN NULL ;

  End;
---------------
  FUNCTION vergi_daire_kod_adi_al (ps_kod cbs_vergi_daire_kodlari.VERGI_DAIRE_KODU%type) RETURN VARCHAR2
    is
  ls_aciklama cbs_vergi_daire_kodlari.VERGI_DAIRE_ADI%type;
  begin
         select VERGI_DAIRE_ADI
       into ls_aciklama
       from cbs_vergi_daire_kodlari
       where VERGI_DAIRE_KODU = ps_kod ;

       return ls_aciklama;
 EXCEPTION
     WHEN OTHERS THEN RETURN NULL ;

  End;
---------------


  Function BIC_banka_adi_al(ps_BIC VARCHAR2) return varchar2 is
         ls_bankad                  varchar2(2000);
  BEGIN
   SELECT  BANKA_ADI
   into ls_bankad
   FROM CBS_BIC_KODLARI
   where BIC_KODU =ps_BIC;

   return ls_bankad;
 EXCEPTION
     WHEN OTHERS THEN RETURN NULL ;

  END;
-------------------------------------------
FUNCTION dekont_yazici_al( p_user VARCHAR2 DEFAULT USER) RETURN VARCHAR2 IS
  ls_ret VARCHAR2(2000);
BEGIN
  SELECT aciklama yazici_path
    INTO ls_ret
    FROM CBS_YAZICI_TANIM
   WHERE  numara= (SELECT dekont_yazici
                     FROM CBS_KULLANICI
                    WHERE kodu=p_user);
   RETURN ls_ret;
   EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1662' || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getUCPOINTER);
END;
-------------------------------------------
FUNCTION rapor_yazici_al( p_user VARCHAR2 DEFAULT USER) RETURN VARCHAR2 IS
  ls_ret VARCHAR2(2000);
BEGIN
  SELECT aciklama yazici_path
    INTO ls_ret
    FROM CBS_YAZICI_TANIM
   WHERE  numara= (SELECT rapor_yazici
                     FROM CBS_KULLANICI
                    WHERE kodu=p_user);
   RETURN ls_ret;
   EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1662' || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getUCPOINTER);
END;
-------------------------------------------
PROCEDURE get_branch_director_data(ps_bolum_kodu varchar2, ps_director_email OUT varchar2)
IS
  
  CURSOR cur_branch_director IS
    SELECT director_email
      FROM cbs_bolum
     WHERE kodu = ps_bolum_kodu;

BEGIN
    IF cur_branch_director%isopen THEN
       CLOSE cur_branch_director;
    END IF;

    OPEN cur_branch_director;
    FETCH cur_branch_director INTO ps_director_email;
     IF cur_branch_director%NOTFOUND THEN
        CLOSE cur_branch_director;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '109' || Pkg_Hata.getUCPOINTER);
     END IF;
    CLOSE cur_branch_director;
END;


/******************************************************************************
   NAME        : FUNCTION Swift_Character_Control
   Prepared By : Chyngyz Omurov
   Date        :  02.03.2015, cq509
   Purpose     : to get rid off disallowed characters
******************************************************************************/
FUNCTION Swift_Character_Control(ps_string VARCHAR2) RETURN VARCHAR2
IS
   ls_special_chars VARCHAR2(50) := '!%^&=?_;><#$?[]\*';
   ls_return VARCHAR2(2000);
BEGIN
    
    ls_return := ps_string;
    
    FOR I IN 1..LENGTH(ls_special_chars) LOOP
        ls_return := REPLACE(ls_return, SUBSTR(ls_special_chars, I, 1));
    END LOOP;
    
    RETURN ls_return;
    
    EXCEPTION
        WHEN OTHERS THEN
            Log_At('swiftcib pkg_genel.Swift_Character_Control',SQLCODE||':'||SQLERRM, ps_string);
            return ps_string;
    
END;
/******************************************************************************
   NAME        : FUNCTION check_case
   Prepared By : Nurzalat Alimzhan uulu
   Date        :  17.10.2017, cq5919
   Purpose     : To check entered string if it doesn't contain Russian alphabet
******************************************************************************/
FUNCTION CHECK_CASE(PS_STRING VARCHAR2) RETURN VARCHAR2 IS
LS_STRING VARCHAR2(2000);
PS_RETURN_CODE VARCHAR2(3);
BEGIN
SELECT TRANSLATE(UPPER(PS_STRING), 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯ', '?????????????????????????????????') INTO LS_STRING FROM DUAL;
IF UPPER(PS_STRING) = LS_STRING THEN 
PS_RETURN_CODE := '000'; --When string does not contain Cyrillic alphabet.
ELSE PS_RETURN_CODE := '096'; --When string contains Cyrillic alphabet.
END IF;
RETURN PS_RETURN_CODE;
END;

function modul_tur_adi_al(ps_modul_tur_kod in cbs_modul_tur.kod%type) return varchar2
   IS
    ls_modul_aciklama      CBS_URUN_TUR.aciklama%TYPE;
  BEGIN
        SELECT aciklama
           INTO ls_modul_aciklama
           FROM CBS_MODUL_TUR
       WHERE  kod = ps_modul_tur_kod;

    RETURN ls_modul_aciklama;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5010' || Pkg_Hata.getUCPOINTER);
  END;
END;
/

