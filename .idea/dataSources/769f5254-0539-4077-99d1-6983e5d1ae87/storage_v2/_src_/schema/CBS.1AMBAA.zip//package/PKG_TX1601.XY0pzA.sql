create PACKAGE PKG_TX1601 IS

 /******************************************************************************
   Name       : PKG_TX1601
   Created By : Seval Balci
   Date    	  : 11.08.03
   Purpose	  : Kasa Islemleri - Kasa kupur kullanan islemler taraf?ndan ca?r?l?rlar.
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number, pn_islem_kod number,
  							pn_tutar1 number ,
  							ps_doviz1 varchar2,
  							ps_islem_1 varchar2,
  							pn_tutar2 number default null,
  							ps_doviz2 varchar2 default null,
  							ps_islem_2 varchar2 default null,
						    ps_bakiye_guncelle varchar2 default 'E', --1603 kasa kapama islemi icindir
							ps_sil varchar2 default 'E'); 		  -- Islem giris kontrolden gectikten sonra cagrilir
  Procedure Dogrulama_Sonrasi(pn_islem_no number ,pn_islem_kod number,
  							  pn_tutar1 number ,
  							  ps_doviz1 varchar2,
  							  ps_islem_1 varchar2,
  							  pn_tutar2 number default null,
  							  ps_doviz2 varchar2 default null,
  							  ps_islem_2 varchar2 default null,
						  ps_bakiye_guncelle varchar2 default 'E' --1603 kasa kapama islemi icindir
							  );		  -- Islem dogrulandiktan sonra cagrilir
  Procedure Onay_Sonrasi(pn_islem_no number,pn_islem_kod number,
  						  pn_tutar1 number ,
  						  ps_doviz1 varchar2,
  						  ps_islem_1 varchar2,
  						  pn_tutar2 number default null,
  						  ps_doviz2 varchar2 default null,
  						  ps_islem_2 varchar2 default null,
						  ps_bakiye_guncelle varchar2 default 'E' --1603 kasa kapama islemi icindir
						  );			  -- Islem onaylandiktan sonra cagrilir
  Procedure Muhasebelesme(pn_islem_no number,pn_islem_kod number,ps_bakiye_guncelle varchar2 default 'E'); --1603 kasa kapama islemi icindir);			  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number ,pn_islem_kod number);	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ,pn_islem_kod number);
  /*?sleme ozel procedure ve & fonks.*/
  Procedure Kasa_Bakiye_Guncelle(pn_islem_no number,
  			ps_islem_tipi varchar2,
			ps_bakiye_guncelle varchar2 default 'E',
			pn_islem_kod number default null
			 );
  Procedure kasa_kullaniciya_baglimi(pn_islem_no number );
  Procedure kasa_doviz_sifir_bakiye_yarat(ps_kasa_kodu varchar2, ps_sube_kodu varchar2,ps_doviz_kodu varchar2 );
  Procedure kupur_doviz_sifir_adet_yarat(ps_kasa_kodu varchar2, ps_sube_kodu varchar2,ps_doviz_kodu varchar2 ,pn_kupur_kodu number);
--  Procedure kasa_bakiye_islem_kayit_at(pn_islem_no number) ;
  Function kasa_kupur_kontrol_var(pn_islem_kod number) return varchar2;

  Procedure kasa_degerler_degistimi(pn_islem_no number,
  									pn_tutar1 number ,
  									ps_doviz1 varchar2,
  									ps_islem_1 varchar2,
  									pn_tutar2 number,
  									ps_doviz2 varchar2,
  									ps_islem_2 varchar2);

 Function kupur_karsilandimi(pn_tx_no number, pn_islem_kod number ,Pn_tutar1 number ,pn_tutar2 number ,ps_doviz1 varchar2 default null ,ps_doviz2 varchar2 default null) return varchar2;
 Procedure tx1601_isleme_at (pn_tx_no 		  number,
 		   				   pn_islem_kod	  cbs_islem.islem_kod%type,
						   ps_kasa_kodu       cbs_kasa_kodlari.kasa_kodu%type,
						   ps_sube_kodu		  varchar2,
						   ps_kullanici_kodu  varchar2,
						   pn_tanim_no number,
						   ps_urun_sinif_kod varchar2 default pkg_kasa.kasa_urun_sinif_kod,
   						   ps_origin_islem_kod varchar2 default null,
						   pn_tutar1 number default null,
  						   ps_doviz1 varchar2 default null,
  						   ps_islem_1 varchar2 default null,
  						   pn_tutar2 number default null,
  						   ps_doviz2 varchar2 default null,
  						   ps_islem_2 varchar2	default null	,
 						   ps_sil varchar2 default 'E'); 		  -- Islem giris kontrolden gectikten sonra cagrilir

Function islemden_kasa_kodu_al(pn_tx_no number) return varchar2;
Function lc_tutar_yuvarla(pn_tutar number ,ps_doviz varchar2 ) return number;
Function sf_kupur_validmi(ps_kupur_kodu number, ps_doviz varchar2) return varchar2;
Procedure Ana_Kasa_Bakiye_Guncelle(pn_islem_no number,ps_islem_tipi varchar2);
procedure sp_kupur_islem_yarat(pn_transfer_no  	    CBS_KASA_SUBE_TRANSFER_ISLEM.transfer_no%TYPE,
  			   			           pn_tx_no 	  		CBS_KASA_SUBE_TRANSFER_ISLEM.tx_no%TYPE,
								   pn_islem_tanim_kod   CBS_KASA_SUBE_TRANSFER.islem_kod%TYPE DEFAULT 1611,
								   ps_bolum_kodu varchar2 default pkg_baglam.bolum_kodu
								  ) ;
END;

/

