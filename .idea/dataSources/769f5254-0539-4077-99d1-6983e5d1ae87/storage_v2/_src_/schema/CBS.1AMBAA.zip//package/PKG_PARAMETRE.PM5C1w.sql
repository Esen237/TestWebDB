create PACKAGE     pkg_parametre IS


  FUNCTION COMPILE_TX(pnumber in number,perr out varchar2) return number;

  FUNCTION PARSE_BOOLEAN(p1 varchar2,psira number,pmuh_plan_numara number,
                       p_code out number,p_char_val1 out varchar2,p_char_val2 out varchar2,
                       p_char_val3 out varchar2,p_oper1 out number,p_oper2 out number,
                       p_oper3 out number,p_oper_type out number) RETURN NUMBER ;

  FUNCTION parse_date(p1 varchar2,psira number,pmuh_plan_numara number,
                       p_code out number,p_char_val1 out varchar2,
                       p_char_val2 out varchar2,p_char_val3 out varchar2,
                       p_oper1 out number,p_oper2 out number,p_oper3 out number) RETURN NUMBER;

  FUNCTION parse_number(p1 varchar2,psira number,pmuh_plan_numara number,
                       p_code out number,p_char_val1 out varchar2,
                       p_char_val2 out varchar2,p_char_val3 out varchar2,
                       p_oper1 out number,p_oper2 out number,p_oper3 out number) RETURN NUMBER;
  FUNCTION parse_varchar(p1 varchar2,psira number,pmuh_plan_numara number,
                       p_code out number,p_char_val1 out varchar2,p_char_val2 out varchar2,
                       p_char_val3 out varchar2,p_oper1 out number,p_oper2 out number,
                       p_oper3 out number) RETURN NUMBER;

  PROCEDURE deger ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
               ,pdeger          out number
              );
  PROCEDURE deger ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
               ,pdeger          out varchar2
              );

  FUNCTION deger ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
              ) return varchar2;

  PROCEDURE deger ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
               ,pdeger          out date
              );
  PROCEDURE deger ( pModul_Tur_Kod  in varchar2
               ,pUrun_Tur_Kod   in varchar2
               ,pUrun_Sinif_Kod in varchar2
               ,pKod            in varchar2
               ,pdeger          out boolean
              );

  PROCEDURE Deger (pKod in varchar2, pdeger out number);
  PROCEDURE Deger (pKod in varchar2, pdeger out date);
  PROCEDURE Deger (pKod in varchar2, pdeger out varchar2);
  PROCEDURE Deger (pKod in varchar2, pdeger out boolean);

-----------------------------------------------------------------
-- ASAGIDAKI PROSEDURLER BACKWARD COMP. AMACIYLA SAKLANMISTIR ---
-----------------------------------------------------------------

  -- Mod?l, ?r?n, S?n?f Parametresi omumak i?in
  FUNCTION Al (pModul_Tur_Kod in varchar2, pUrun_Tur_Kod in varchar2, pUrun_Sinif_Kod in varchar2, pKod in varchar2, pdeger out number) return number;
  FUNCTION Al (pModul_Tur_Kod in varchar2, pUrun_Tur_Kod in varchar2, pUrun_Sinif_Kod in varchar2, pKod in varchar2, pdeger out varchar2) return number;
  FUNCTION Al (pModul_Tur_Kod in varchar2, pUrun_Tur_Kod in varchar2, pUrun_Sinif_Kod in varchar2, pKod in varchar2, pdeger out date) return number;
  FUNCTION Al (pModul_Tur_Kod in varchar2, pUrun_Tur_Kod in varchar2, pUrun_Sinif_Kod in varchar2, pKod in varchar2, pdeger out boolean) return number;
  -- TX , GLOBAL Parametreleri omumak i?in
  FUNCTION Al (pKod in varchar2, pdeger out number)   return number;
  FUNCTION Al (pKod in varchar2, pdeger out varchar2) return number;
  FUNCTION Al (pKod in varchar2, pdeger out date)     return number;
  FUNCTION Al (pKod in varchar2, pdeger out boolean)  return number;

  FUNCTION Varchar_Al (pModul_Tur_Kod in varchar2, pUrun_Tur_Kod in varchar2, pUrun_Sinif_Kod in varchar2, pKod in varchar2 ) return varchar2;
    pragma restrict_references (Varchar_Al,trust);
  FUNCTION Number_Al (pModul_Tur_Kod in varchar2, pUrun_Tur_Kod in varchar2, pUrun_Sinif_Kod in varchar2, pKod in varchar2 ) return number;
    pragma restrict_references (Varchar_Al,trust);


  Procedure Parametre_Yaz(
                    pislem_numara in number,
                                      varchar_list  in pkg_muhasebe.varchar_array,
                                      number_list   in pkg_muhasebe.number_array,
                                      date_list     in pkg_muhasebe.date_array,
                                      boolean_list  in pkg_muhasebe.boolean_array
  );

  Function Parametre_Oku(
                    pislem_numara in number,
                                      varchar_list  in out pkg_muhasebe.varchar_array,
                                      number_list   in out pkg_muhasebe.number_array,
                                      date_list     in out pkg_muhasebe.date_array,
                                      boolean_list  in out pkg_muhasebe.boolean_array
  ) return number;

  function fun_get_prod_of_prm ( pn_tx_code        in  number
                                ,ps_parameter      in  varchar2
                                ,ps_value          in  varchar2
                                ,ps_modul_tur_kod  out varchar2
                                ,ps_urun_tur_kod   out varchar2
                                ,ps_urun_sinif_kod out varchar2
                                ) return number ;

  function fun_get_prod_of_prm ( pn_tx_code        in  number
                                ,ps_parameter      in  varchar2
                                ,pn_value          in  number
                                ,ps_modul_tur_kod  out varchar2
                                ,ps_urun_tur_kod   out varchar2
                                ,ps_urun_sinif_kod out varchar2
                                ) return number ;

  function fun_check_value ( ps_parameter      in  varchar2
                            ,ps_modul_tur_kod  in  varchar2
                            ,ps_value          in  varchar2
                            ) return boolean ;

  FUNCTION lc_mi ( ps_Modul_Tur_Kod    in varchar2
                       ,ps_Urun_Tur_Kod     in varchar2
                       ,ps_Urun_Sinif_Kod   in varchar2)
                       return varchar2;
                       
  FUNCTION get_aciklama(pKod in varchar2) return varchar2;

END;
/

