create PACKAGE     PKG_INT_TEMPLATE_TRX IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION PostTemplate(pn_id number, 
                      pn_customer_number number, 
                      pc_template nclob, 
                      ps_operation_type varchar2) RETURN varchar2;

FUNCTION DeleteTemplate(pn_id number, 
                     pn_customer_number number) RETURN varchar2;
                                              
END;
/

