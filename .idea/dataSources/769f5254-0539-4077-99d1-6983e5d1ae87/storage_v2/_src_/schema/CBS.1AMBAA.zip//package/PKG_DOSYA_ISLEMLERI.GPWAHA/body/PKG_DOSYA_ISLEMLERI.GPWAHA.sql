create PACKAGE BODY PKG_DOSYA_ISLEMLERI IS
Function sf_bitmemis_islem_varmi(pn_islem_no number,
 		  						  pn_islem_kod number default 1700,
								  ps_referans varchar2 default null)  return number
is
 ln_tx_no number :=0 ;
 ln_senet_no number :=0 ;
 ls_bolum_kodu varchar2(200);
 onayda_bekleyen_islem_var exception;

	cursor cur_islem is
	select numara tx_no from cbs_islem a
	where  numara <> pn_islem_no and
	   	   pkg_tx.islem_bitmis_mi(numara)= 0 and
		   islem_kod  = nvl(pn_islem_kod,1700) ;


Begin
     For c_islem in cur_islem loop
	 	 ln_tx_no := c_islem.tx_no ;
	 End loop;
	    if  nvl(ln_tx_no,0) <> 0 then
	   	   raise onayda_bekleyen_islem_var;
		end if;
		return nvl(ln_tx_no,0);
  Exception
  When onayda_bekleyen_islem_var then
  	   	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '780' ||pkg_hata.getdelimiter|| to_char(ln_tx_no)||  pkg_hata.getdelimiter ||  pkg_hata.getUCPOINTER);
  When others then return 0;
End;

--
   PROCEDURE sp_maas_odeme_dosya_yukle(ps_satir VARCHAR2,
 		   							 ps_dosya_adi varchar2 default 'CBS_MAAS',
									 pn_tx_no	  number,
									 Pn_sira_no  number,
									 ps_bolum_kodu VARCHAR2 default pkg_baglam.bolum_kodu,
									 ps_ayrac    varchar2 default ';'
 		   							 )
  is
  ln_tutar   						 number;
  ls_hesap_no   					 varchar2(20);
  ln_indx 							 number := 0;
  ls_satir 							 varchar2(4000);
  ls_unvan 							 varchar2(4000);
  ls_aciklama 						 varchar2(4000);
  ls_doviz_kodu 					 varchar2(200);
  ls_tutar 							 varchar2(4000);
  ls_mesaj 							 varchar2(4000);
  ls_hesap_doviz  					 cbs_hesap.doviz_kodu%type;
  ls_ucpointer						 varchar2(3):=pkg_hata.getUCPOINTER;
  ls_delimiter						 varchar2(3):=pkg_hata.getDELIMITER;
  hesap_doviz_farkli 				 exception;
  dosya_uygun_Degil 				 exception;
  hesap_yok							 exception;
  ln_adet							 number := 0;
BEGIN
	 ls_satir := ps_satir ;
     if ps_satir is null then raise no_data_found; end if;

	 if substr(ps_satir,length(ps_satir)) <> ps_ayrac then
	   ls_satir:=ps_satir||ps_ayrac  ;
	 end if;

	 ln_indx := INSTR(ls_satir, ps_ayrac  );
	 if nvl(ln_indx,0) <= 0 then
	  raise dosya_uygun_Degil;
	 end if;

	 if substr(upper(ls_satir),1,1) not in( 'A','H') then
	 	 ln_indx := PKG_DOSYA_ISLEMLERI.STR_AYRAC_YERI_BUL ( ls_satir,ls_hesap_no,PS_AYRAC );
		 ln_indx := PKG_DOSYA_ISLEMLERI.STR_AYRAC_YERI_BUL ( ls_satir,ls_doviz_kodu,PS_AYRAC );

		 select count(*)
		 into ln_adet
		 from cbs_hesap
		 where hesap_no = ls_hesap_no;
		 if nvl(ln_adet,0) = 0 then
		 	raise hesap_yok;
		 end if;

		 ls_hesap_doviz := pkg_hesap.HesaptanDovizKoduAl(ls_hesap_no);

		 if pkg_hesap.HesaptanDovizKoduAl(ls_hesap_no) <> ls_doviz_kodu then
		 	raise hesap_doviz_farkli;
		 end if;

		 ln_indx := PKG_DOSYA_ISLEMLERI.STR_AYRAC_YERI_BUL ( ls_satir,ls_tutar,PS_AYRAC );
		 ln_indx := PKG_DOSYA_ISLEMLERI.STR_AYRAC_YERI_BUL ( ls_satir,ls_unvan,PS_AYRAC );
		 ln_indx := PKG_DOSYA_ISLEMLERI.STR_AYRAC_YERI_BUL ( ls_satir,ls_aciklama,PS_AYRAC );

	 	 ln_tutar    := to_number(NVL( ls_tutar,'0')) ;
		 insert into cbs_maas_odeme_dosya_detay_isl
		  		(tx_no, dosya_adi,sira_no, banka_tarihi, durum_kodu, hesap_no, tutar, doviz_kodu, AD_SOYAD, aciklama)
		 values(pn_tx_no,ps_dosya_adi ,pn_sira_no, pkg_muhasebe.banka_tarihi_bul, 'A', ls_hesap_no, ln_tutar ,ls_doviz_kodu,ls_unvan,ls_aciklama);

		 Commit;
 	 end if;

	Exception
	  When dosya_uygun_Degil Then
  	     ls_mesaj :=Pkg_Hata.GenerateMessage(ls_ucpointer || '991' ||  ls_delimiter ||to_char(sqlcode)||' '|| substr(TO_CHAR(sqlerrm),1,200)|| ls_delimiter|| ls_ucpointer);
		  insert into  cbs_maas_odeme_dosya_hata
		  		(tx_no, sira_no, hata_mesaj, mesaj_text, dosya_adi, banka_tarihi, hesap_no, doviz_kodu, ad_soyad, aciklama, tutar)
		  values(pn_tx_no,pn_sira_no,ls_mesaj ,ps_satir,ps_dosya_adi,pkg_muhasebe.banka_tarihi_bul,ls_hesap_no,ls_doviz_kodu,ls_unvan,ls_aciklama,ls_tutar);
		  commit;
	  When hesap_doviz_farkli Then
  	     ls_mesaj :=Pkg_Hata.GenerateMessage(ls_ucpointer || '993' || ls_delimiter ||ls_hesap_doviz||  ls_delimiter ||ls_doviz_kodu||ls_delimiter|| ls_ucpointer);
		  insert into  cbs_maas_odeme_dosya_hata
		  		(tx_no, sira_no, hata_mesaj, mesaj_text, dosya_adi, banka_tarihi, hesap_no, doviz_kodu, ad_soyad, aciklama, tutar)
		  values(pn_tx_no,pn_sira_no,ls_mesaj ,ps_satir,ps_dosya_adi,pkg_muhasebe.banka_tarihi_bul,ls_hesap_no,ls_doviz_kodu,ls_unvan,ls_aciklama,ls_tutar);
		  commit;
	  When hesap_yok Then
  	     ls_mesaj :=Pkg_Hata.GenerateMessage(ls_ucpointer || '994' ||  ls_delimiter|| ls_hesap_no || ls_delimiter || ls_ucpointer);
		  insert into  cbs_maas_odeme_dosya_hata
		  		(tx_no, sira_no, hata_mesaj, mesaj_text, dosya_adi, banka_tarihi, hesap_no, doviz_kodu, ad_soyad, aciklama, tutar)
		  values(pn_tx_no,pn_sira_no,ls_mesaj ,ps_satir,ps_dosya_adi,pkg_muhasebe.banka_tarihi_bul,ls_hesap_no,ls_doviz_kodu,ls_unvan,ls_aciklama,ls_tutar);
		  commit;
	  When OTHERS Then
	  	  ls_mesaj :=Pkg_Hata.GenerateMessage(ls_ucpointer || '991' ||  ls_delimiter ||to_char(sqlcode)||' '|| substr(TO_CHAR(sqlerrm),1,200)|| ls_delimiter|| ls_ucpointer);
		  insert into  cbs_maas_odeme_dosya_hata
		  		(tx_no, sira_no, hata_mesaj, mesaj_text, dosya_adi, banka_tarihi, hesap_no, doviz_kodu, ad_soyad, aciklama, tutar)
		  values(pn_tx_no,pn_sira_no,ls_mesaj ,ps_satir,ps_dosya_adi,pkg_muhasebe.banka_tarihi_bul,ls_hesap_no,ls_doviz_kodu,ls_unvan,ls_aciklama,ls_tutar);
		  commit;

 END ;

 Function maas_modul_tur return varchar2
 is
 Begin
 	  return pkg_cari.Modul_Tur_CURROPS;
 End;

 Function maas_urun_tur return varchar2
 is
 Begin
 	  return 'SALARY';
 End;

  Function maas_urun_sinif return varchar2
  is
  Begin
    return  'PAYMENT';
  End;

 Function str_ayrac_yeri_bul(ps_str in out varchar2,ps_aranan_kisim in out varchar2 ,ps_ayrac    varchar2 default ';') return number
  is
    dosya_formati_uygun_Degil exception;
	ln_indx number := 0;
  Begin

	 ln_indx := nvl(INSTR(ps_str, ps_ayrac ),0);
	 ps_aranan_kisim := upper(trim( substr( ps_str,1,ln_indx -1)));
     ps_str  :=  upper(trim(substr( ps_str,ln_indx+1)));

	 return ln_indx ;

  End;
   Function maas_dosya_hatalimi(pn_tx_no number) return varchar2
    is
   ln_adet number := 0;
   ln_adet2 number := 0;
    Begin
	 	  select count(*)
		  into ln_adet
		  from 	cbs_maas_odeme_dosya_hata
		  where tx_no = pn_tx_no;
		if  nvl(ln_adet,0) = 0 then
		  return 'H';
		 else
		  return 'E';
		end if;
	  Exception when others then return 'H';
	  End;

 Procedure maas_dosya_detay_islem_sil (pn_tx_no number)
 is
 Begin
 	  begin
		  delete from cbs_maas_odeme_dosya_hata
		  where tx_no = pn_tx_no ;
	  exception when others then null;
	  end;
	  begin
		  delete from cbs_maas_odeme_dosya_detay_isl
		  where tx_no = pn_tx_no ;
  	  exception when others then null;
  	  end;
 Exception when others then null;
 End;

  Function maas_dosya_adi_al return varchar2
  is
   ls_dosya_adi varchar2(2000) ;
  Begin

	ls_dosya_adi :='CBS_SALARY'||'_' || to_char(pkg_muhasebe.banka_tarihi_bul,'DDMMYYYY') ||'.CSV';

    return ls_dosya_adi;
  End ;
END;
/

