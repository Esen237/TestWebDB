create PACKAGE BODY     PKG_TX1300
IS
   PROCEDURE Kontrol_Sonrasi (pn_islem_no NUMBER)
   IS
      ls_nakdi_var               VARCHAR2 (1);
      ls_gayrinakdi_var          VARCHAR2 (1);
      ln_bekleyen_txno           NUMBER;
      ln_musteri_no              NUMBER;
      ln_kredi_kart_urun_adet    NUMBER;
      ln_installment_urun        NUMBER  :=0; --CBS-683 AdilK 11.08.2022
      installment_kredi_check    Number  :=0; --CBS-683 AdilK 11.08.2022
      installment_kredi_line     Number;      --CBS-683 AdilK 11.08.2022
      ln_overdraft_urun_adet     NUMBER;
      ln_existing_teklif         CBS_KREDI_TEKLIF.teklif_no%TYPE;
      lb_new_satir               BOOLEAN;

      -- B-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction

      -- overdraft_urun_mukerrer EXCEPTION;
      ln_ovd_cnt                 NUMBER;
      ln_hesap_no                NUMBER;
      account_not_conn           EXCEPTION;
      -- E-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
      kredi_kart_urun_mukerrer   EXCEPTION;
      installment_urun_exception     EXCEPTION; --CBS-683 AdilK 11.08.2022
      installment_kredi_exception     EXCEPTION; --CBS-683 AdilK 11.08.2022
      ln_total_sum               NUMBER; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      ln_count_curr              NUMBER; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      ln_count_record            NUMBER; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      total_sum_error            EXCEPTION; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      duplicated_currency        EXCEPTION; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      no_curr_structure_entry    EXCEPTION; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      app_no_exception           EXCEPTION;
      ln_satir_no                NUMBER;


      --BOM ErkinZu cq614 20.04.17
      CURSOR teklif_satir_isl_cur
      IS
         SELECT *
           FROM cbs_kredi_teklif_satir_islem
          WHERE tx_no = pn_islem_no;

      CURSOR old_satirs_cur (pn_teklif_no NUMBER, pn_satir_no NUMBER)
      IS
         SELECT *
           FROM cbs_kredi_teklif_satir
          WHERE teklif_no = pn_teklif_no AND teklif_satir_no = pn_satir_no;

      old_satir_row              old_satirs_cur%ROWTYPE;
   --EOM ErkinZu cq614 20.04.17
      CURSOR kredi_teklif
      IS
         SELECT *
           FROM cbs_kredi_teklif_satir_islem
          WHERE tx_no = pn_islem_no
          and KREDI_TURU in (32,13);

   BEGIN
      SELECT musteri_no
        INTO ln_musteri_no
        FROM cbs_kredi_teklif_islem
       WHERE tx_no = pn_islem_no;

      ln_bekleyen_txno :=
         pkg_kredi.sf_bitmemis_teklifislem_var_mi (ln_musteri_no,
                                                   pn_islem_no);
      ln_existing_teklif := pkg_kredi.sf_onayli_teklifi_varmi (ln_musteri_no);

      -- B-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
      SELECT COUNT (*)
        INTO ln_overdraft_urun_adet
        FROM cbs_kredi_teklif_satir_islem
       WHERE     tx_no = pn_islem_no
             AND pkg_tx1300.sf_teklif_overdraft_urun_mu (kredi_turu) = 'E';

      /*
      if nvl(ln_overdraft_urun_adet,0) > 1 then
      raise overdraft_urun_mukerrer;
      end if;
      */

      IF ln_overdraft_urun_adet > 1
      THEN
         SELECT COUNT (*)
           INTO ln_ovd_cnt       --number of accounts with old overdraft logic
           FROM cbs_hesap
          WHERE     musteri_no = ln_musteri_no
                AND overdraft = 'E'
                AND durum_kodu = 'A'
                AND ovd_proposal_line_no IS NULL;

         IF ln_ovd_cnt > 0
         THEN
            SELECT MAX (hesap_no) -- get account with old logic and ask user to change its overdraft logic to new one
              INTO ln_hesap_no
              FROM cbs_hesap
             WHERE     musteri_no = ln_musteri_no
                   AND overdraft = 'E'
                   AND durum_kodu = 'A'
                   AND ovd_proposal_line_no IS NULL;

            RAISE account_not_conn;
         END IF;
      END IF;

      -- E-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
        
      SELECT COUNT (*)
        INTO ln_kredi_kart_urun_adet
        FROM cbs_kredi_teklif_satir_islem
       WHERE     tx_no = pn_islem_no
             AND CBS.pkg_tx1300.sf_kredi_kart_urun_mu (kredi_turu) = 'E';

      IF NVL (ln_kredi_kart_urun_adet, 0) > 1
      THEN
         RAISE kredi_kart_urun_mukerrer;
      END IF;
      
      -- BOM CBS-683 AdilK 11.08.2022
      FOR rec_row IN kredi_teklif LOOP
        if rec_row.kredi_turu=32 then
            ln_installment_urun:=ln_installment_urun+1;
            
            if installment_kredi_line != rec_row.REF_TEKLIF_SATIR_NO or installment_kredi_line=null 
            then
                 RAISE installment_kredi_exception;
            end if;
            installment_kredi_line := rec_row.REF_TEKLIF_SATIR_NO;
            
        end if;
        if rec_row.kredi_turu=13 then
            installment_kredi_check:=installment_kredi_check+1;
        end if;
      END LOOP;


      IF ln_installment_urun > 1
      THEN
         RAISE installment_urun_exception;
      END IF;
          

      IF ln_installment_urun=1 and installment_kredi_check =0 then
         RAISE installment_kredi_exception;
      end if;    
      
      --EOB CBS-683 AdilK 11.08.2022
      pkg_kredi.sp_teklif_gayrinakdilimit_var (pn_islem_no,
                                               ls_nakdi_var,
                                               ls_gayrinakdi_var);

      --BOM aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      SELECT SUM (share_percent)
        INTO ln_total_sum
        FROM CBS_CURR_STRUCT_OF_INCOME_TX
       WHERE tx_no = pn_islem_no;

      IF ln_total_sum <> 100
      THEN
         RAISE total_sum_error;
      END IF;

      ---------------------
      BEGIN
         SELECT COUNT (1)
           INTO ln_count_curr
           FROM (  SELECT COUNT (*) ln_count
                     FROM CBS_CURR_STRUCT_OF_INCOME_TX
                    WHERE tx_no = pn_islem_no
                 GROUP BY currency) a
          WHERE a.ln_count > 1;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            ln_count_curr := 0;
      END;

      ------------------------------
        
      IF ln_count_curr >= 1
      THEN
         RAISE duplicated_currency;
      END IF;

      SELECT COUNT (*)
        INTO ln_count_record
        FROM CBS_CURR_STRUCT_OF_INCOME_TX
       WHERE tx_no = pn_islem_no;

      IF ln_count_record = 0
      THEN
         RAISE no_curr_structure_entry;
      END IF;
   --EOM aisuluud cqdb 5568 "incoming currency structure" 10.01.2017

   --BOM ErkinZu cq614 20.04.17
   --if Product Group equals 16 (consumer loans), then AppNo must be filled
   --if this is an old proposal which was created without application then AppNo can be null


   /******************************************************************************
   Name       :  cbs-233 ????????? ???????? ???????? ?????? ? ??? (deleted app_no)
   Created By : GulkaiyrK
   Date          : 22.06.2020
  ******************************************************************************/
   /* FOR satir_row IN teklif_satir_isl_cur LOOP
      IF satir_row.kredi_turu IN (16, 24) THEN --ErkinZ, CQ5988, 30012018, make credit type 24's behaviour same as 16's
        IF satir_row.app_no IS NULL THEN
          lb_new_satir := TRUE;

          IF (NVL (ln_existing_teklif, 0) <> 0) THEN
            OPEN old_satirs_cur (ln_existing_teklif, satir_row.teklif_satir_no);
            FETCH old_satirs_cur INTO old_satir_row;

            IF old_satirs_cur%FOUND THEN
              lb_new_satir := FALSE;
              IF old_satir_row.app_no IS NOT NULL THEN
                lb_new_satir := TRUE;
              END IF;
            END IF;

            CLOSE old_satirs_cur;             --ErkinZ, defect CQDB5937
          END IF;

          IF lb_new_satir THEN
            ln_satir_no := satir_row.teklif_satir_no;
            RAISE app_no_exception;
          END IF;
        END IF;
      END IF;
    END LOOP;
    *****************************************************************************/
   --EOM ErkinZu cq614 20.04.17
   EXCEPTION
      -- B-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
      -- when overdraft_urun_mukerrer then
      -- raise_application_error(-20100,pkg_hata.getucpointer || '1847' ||  pkg_hata.getucpointer);
      WHEN account_not_conn
      THEN
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '4633'
            || pkg_hata.getdelimiter
            || ln_hesap_no
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer);
      -- E-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
      WHEN kredi_kart_urun_mukerrer
      THEN
         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '1955' || pkg_hata.getucpointer);
      WHEN installment_urun_exception  -- CBS-683 AdilK 11.08.2022
      THEN 
      raise_application_error (
            -20100,
            pkg_hata.getucpointer || '1956' || pkg_hata.getucpointer); -- CBS-683 AdilK 11.08.2022
      WHEN installment_kredi_exception
      THEN
      raise_application_error (
            -20100,
            pkg_hata.getucpointer || '1957' || pkg_hata.getucpointer);
      WHEN total_sum_error
      THEN
         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '6903' || pkg_hata.getucpointer); --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      WHEN app_no_exception
      THEN
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '8027'
            || pkg_hata.getdelimiter
            || ln_satir_no
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer);              --ErkinZu, cq614, 20.04.17
      WHEN duplicated_currency
      THEN
         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '6908' || pkg_hata.getucpointer); --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      WHEN no_curr_structure_entry
      THEN
         raise_application_error (
            -20100,
            pkg_hata.getucpointer || '6909' || pkg_hata.getucpointer); --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      WHEN OTHERS
      THEN
         log_at ('pkg_tx1300.Kontrol_Sonrasi',
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '62'
            || pkg_hata.getdelimiter
            || TO_CHAR (SQLERRM)
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer);
   END;

   ----------------------------------------------------------
   PROCEDURE Dogrulama_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      NULL;
   END;

   ----------------------------------------------------------
   PROCEDURE Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      NULL;
   END;

   ----------------------------------------------------------
   PROCEDURE Iptal_Reddetme_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      NULL;
   END;

   ----------------------------------------------------------
   PROCEDURE Iptal_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      --NULL;
      RAISE_APPLICATION_ERROR (
         -20100,
            Pkg_Hata.getUCPOINTER
         || '699'
         || Pkg_Hata.getDelimiter
         || Pkg_Hata.getUCPOINTER);
   END;

   ----------------------------------------------------------
   PROCEDURE Onay_Sonrasi (pn_islem_no NUMBER)
   IS
      ln_musteri_no              NUMBER := 0;
      ln_count                   NUMBER := 0;                 --CQ6147 IadgarB
      credit_exist               NUMBER;                      --CBS-46 IadgarB
      installment_exist          NUMBER;                      --CBS-46 IadgarB
      ln_teklif_satir_no         NUMBER;                      --CQ6147 IadgarB
      ln_req_limit               NUMBER;                      --CQ6147 IadgarB
      ln_app_limit               NUMBER;                      --CQ6147 IadgarB
      ps_response_code           VARCHAR2 (200);              --CQ6147 IadgarB
      ps_response_desc           VARCHAR2 (200);              --CQ6147 IadgarB
      WEBSERVICE_GENERAL_ERROR   EXCEPTION;                   --CQ6147 IadgarB
      ls_run_webservices         VARCHAR2 (1);                --CBS-46 IadgarB
      ln_kredi_acc_bolum         VARCHAR2 (10) := pkg_baglam.bolum_kodu; --CBS-373 KalysbekA
      ln_inst_acc_bolum          VARCHAR2 (10) := pkg_baglam.bolum_kodu; --CBS-373 KalysbekA
      ln_kredi_turu              VARCHAR2 (10) := 0;       --CBS-373 KalysbekA

      --BOM CQ6147 IadgarB
      CURSOR cur_cr_card
      IS
         SELECT UNIQUE BANKSOFT_CUSTOMER_NO
           FROM CBS_CREDIT_CARD
          WHERE    --STATUS = 'A'  AND ---CBS-366 GulkaiyrK
                 PRIMARY_CARD_FLAG = 'A'
                AND CUSTOMER_NO = ln_musteri_no
                AND SUBSTR (card_no, 1, 6) NOT IN (458818); --cbs288 GulkaiyrK;

      r_cur                      cur_cr_card%ROWTYPE;
   --EOM CQ6147 IadgarB
   BEGIN
      SELECT musteri_no
        INTO ln_musteri_no
        FROM CBS_KREDI_TEKLIF_ISLEM
       WHERE tx_no = pn_islem_no;

      UPDATE cbs_kredi_teklif_islem
         SET bolum_kodu = pkg_baglam.bolum_kodu              -- MaratM CBS-373
       WHERE tx_no = pn_islem_no;

      UPDATE CBS_KREDI_TEKLIF_SATIR_ISLEM
         SET musteri_no = ln_musteri_no
       WHERE tx_no = pn_islem_no;

      --BOM aisuluud CQ5568
      UPDATE CBS_CURR_STRUCT_OF_INCOME_TX
         SET customer_no = ln_musteri_no
       WHERE tx_no = pn_islem_no;

      --EOM aisuluud CQ5568

      --Insert new line line for installment limit if not exist
      --BOM CBS-46 IadgarB
      -- select count(*) into credit_exist from CBS_KREDI_TEKLIF_SATIR_ISLEM where KREDI_TURU = 13 and tx_no = pn_islem_no;
      -- if nvl(credit_exist, 0) <> 0 then
      --     select count(*) into installment_exist from CBS_KREDI_TEKLIF_SATIR_ISLEM where KREDI_TURU = 32 and tx_no = pn_islem_no;
      --      if nvl(installment_exist, 0) = 0 then
      --         --insert installment line
      --         INSERT INTO CBS_KREDI_TEKLIF_SATIR_ISLEM
      --         SELECT TX_NO, pkg_genel.genel_kod_al('TEKLIF_SATIR_NO'), 32, DOVIZ_KODU, VADE_SURESI, VADE_TIPI, MEVCUT_RISK_TL, MEVCUT_RISK_YP, MEVCUT_LIMIT_TL,
      --                MEVCUT_LIMIT_YP, ONERILEN_LIMIT_TL, ONERILEN_LIMIT_YP, ONERILEN_VADE_SURESI, ONERILEN_VADE_TIPI, KREDI_KULLANDIRIM_KODU, ACIKLAMA,
      --                SATIR_DURUM, TEKLIF_NO, REF_TEKLIF_NO, MUSTERI_NO, REF_TEKLIF_SATIR_NO, LINE, TRANCHES, MATURITY_DATE, REAL_LIMIT, APP_NO
      --         FROM CBS_KREDI_TEKLIF_SATIR_ISLEM
      --         WHERE TX_NO = pn_islem_no
      --         AND pkg_TX1300.sf_kredi_kart_urun_mu(KREDI_TURU) = 'E';
      --      end if;
      -- end if;
      --EOM CBS-46 IadgarB

      pkg_kredi.sp_krediteklifi_anatabloya_at (pn_islem_no);

      --BOM CQ6147 IadgarB
      SELECT COUNT (*)
        INTO ln_count
        FROM CBS_CREDIT_CARD
       WHERE     customer_no = ln_musteri_no
             AND SUBSTR (card_no, 1, 6) NOT IN (458818);   --cbs288 GulkaiyrK;

      IF NVL (ln_count, 0) <> 0
      THEN
         SELECT MAX (onerilen_limit_yp), MAX (REAL_LIMIT)
           INTO ln_req_limit, ln_app_limit
           FROM CBS_KREDI_TEKLIF_SATIR_ISLEM
          WHERE TX_NO = pn_islem_no AND KREDI_TURU IN (13, 32);

         FOR r_cur IN cur_cr_card
         LOOP
            pkg_credit_card.SP_UPDATELIMITREQAPP_WS (
               pn_islem_no,
               1,
               r_cur.banksoft_customer_no,
               NVL (ln_req_limit, 0),                        --requested limit
               NVL (ln_app_limit, 0),                         --approved limit
               ps_response_code,
               ps_response_desc);

            IF ps_response_code <> '000'
            THEN
               RAISE WEBSERVICE_GENERAL_ERROR;
            END IF;
         END LOOP;
      END IF;
   EXCEPTION
      WHEN WEBSERVICE_GENERAL_ERROR
      THEN
         log_at ('PKG_TX1300_WEBSERVICE_GENERAL_ERROR',
                 pn_islem_no,
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      -- RAISE_APPLICATION_ERROR(-20100,PKG_HATA.GETUCPOINTER || '6701' || PKG_HATA.GETDELIMITER  || ps_response_code||' '|| ps_response_desc || PKG_HATA.GETDELIMITER ||  PKG_HATA.GETUCPOINTER );
      WHEN OTHERS
      THEN
         RAISE_APPLICATION_ERROR (
            -20100,
               PKG_HATA.GETUCPOINTER
            || '459'
            || PKG_HATA.GETDELIMITER
            || TO_CHAR (SQLCODE)
            || ' '
            || SQLERRM
            || PKG_HATA.GETDELIMITER
            || PKG_HATA.GETUCPOINTER);
   END;

   --EOM CQ6147 IadgarB
   ----------------------------------------------------------
   PROCEDURE IPTAL_ONAY_SONRASI (pn_islem_no NUMBER)
   IS
      ln_teklif_no   NUMBER;
   BEGIN
      RAISE_APPLICATION_ERROR (
         -20100,
            Pkg_Hata.getUCPOINTER
         || '699'
         || Pkg_Hata.getDelimiter
         || Pkg_Hata.getUCPOINTER);
   --pkg_tx1300.sp_teklifislem_durum_guncelle(pn_islem_no,'I');
   END;

   ----------------------------------------------------------
   PROCEDURE Reddetme_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      pkg_tx1300.sp_teklifislem_durum_guncelle (pn_islem_no, 'R');
   END;

   ----------------------------------------------------------
   PROCEDURE Tamam_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      NULL;
   END;

   ----------------------------------------------------------
   PROCEDURE Basim_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      NULL;
   END;

   ----------------------------------------------------------
   PROCEDURE Muhasebelesme (pn_islem_no NUMBER)
   IS
   BEGIN
      NULL;
   END;

   ----------------------------------------------------------
   PROCEDURE Iptal_Muhasebelestir_Sonrasi (pn_islem_no NUMBER)
   IS
   BEGIN
      NULL;
   END;

   ----------------------------------------------------------
   PROCEDURE Guncelleme_Kontrolu (pn_islem_no          NUMBER,
                                  ps_block             VARCHAR2,
                                  ps_rowid             VARCHAR2,
                                  ps_column            VARCHAR2,
                                  pd_column            VARCHAR2,
                                  ps_oldvalue   IN OUT VARCHAR2)
   IS
      guncellenmis_exception   EXCEPTION;
      ln_retval                NUMBER := 0;
      ls_sqlstr                VARCHAR2 (2000);
      ls_sql_template          VARCHAR2 (2000);
      ls_source_table          VARCHAR2 (2000);
      ls_dest_table            VARCHAR2 (2000);
   BEGIN
      IF ps_block = 'CBS_KREDI_TEKLIF_ISLEM'
      THEN
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_KREDI_TEKLIF_ISLEM';
         ls_dest_table := 'CBS_KREDI_TEKLIF';

         IF     ps_column <> 'TEKLIF_NO'
            AND ps_column <> 'TX_NO'
            AND ps_column <> 'REF_TEKLIF_NO'
            AND ps_column <> 'TEKLIF_REFERANS'
         THEN
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := pkg_guncel.DifferenceTemplateSingleRecord (1);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REF_TEKLIF_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      -- end if;
      ELSIF ps_block = 'CBS_KREDI_TEKLIF_SATIR_ISLEM'
      THEN
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_KREDI_TEKLIF_SATIR_ISLEM';
         ls_dest_table := 'CBS_KREDI_TEKLIF_SATIR';

         IF     ps_column <> 'TEKLIF_NO'
            AND ps_column <> 'TX_NO'
            AND ps_column <> 'REF_TEKLIF_NO'
            AND ps_column <> 'TEKLIF_SATIR_NO'
            AND ps_column <> 'REF_TEKLIF_SATIR_NO'
         THEN
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := pkg_guncel.DifferenceTemplateSingleRecord (2);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REF_TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template,
                        'DESTINATION_PK2',
                        'TEKLIF_SATIR_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK2', 'REF_TEKLIF_SATIR_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      ELSIF ps_block = 'CBS_KREDI_TEKLIF_LIMIT_ISLEM'
      THEN
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_KREDI_TEKLIF_LIMIT_ISLEM';
         ls_dest_table := 'CBS_KREDI_TEKLIF_LIMIT';

         IF     ps_column <> 'TEKLIF_NO'
            AND ps_column <> 'TX_NO'
            AND ps_column <> 'REF_TEKLIF_NO'
            AND ps_column <> 'SIRA_NO'
         THEN
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := pkg_guncel.DifferenceTemplateSingleRecord (1);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REF_TEKLIF_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      ELSIF ps_block = 'CBS_KREDI_TEKLIF_TEMINAT_ISLEM'
      THEN
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_KREDI_TEKLIF_TEMINAT_ISLEM';
         ls_dest_table := 'CBS_KREDI_TEKLIF_TEMINAT';

         IF     ps_column <> 'TEKLIF_NO'
            AND ps_column <> 'TX_NO'
            AND ps_column <> 'REF_TEKLIF_NO'
            AND ps_column <> 'SIRA_NO'
            AND ps_column <> 'REF_SIRA_NO'
         THEN
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := pkg_guncel.DifferenceTemplateSingleRecord (2);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REF_TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK2', 'SIRA_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK2', 'REF_SIRA_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      ELSIF ps_block = 'CBS_KREDI_TKLF_SATIR_TMN_ISLM'
      THEN
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_KREDI_TKLF_SATIR_TMN_ISLM';
         ls_dest_table := 'CBS_KREDI_TEKLIF_SATIR_TEMINAT';

         IF     ps_column <> 'TEKLIF_NO'
            AND ps_column <> 'TX_NO'
            AND ps_column <> 'REF_TEKLIF_NO'
            AND ps_column <> 'TEKLIF_SATIR_NO'
            AND ps_column <> 'REF_TEKLIF_SATIR_NO'
            AND ps_column <> 'SIRA_NO'
            AND ps_column <> 'REF_SIRA_NO'
         THEN
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := pkg_guncel.DifferenceTemplateSingleRecord (3);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK1', 'TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK1', 'REF_TEKLIF_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template,
                        'DESTINATION_PK2',
                        'TEKLIF_SATIR_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK2', 'REF_TEKLIF_SATIR_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'DESTINATION_PK3', 'SIRA_NO');
            ls_sql_template :=
               REPLACE (ls_sql_template, 'SOURCE_PK3', 'REF_SIRA_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            EXECUTE IMMEDIATE ls_sql_template INTO ln_retval, ps_oldvalue;
         END IF;
      END IF;

      IF ln_retval <> 1
      THEN
         RAISE guncellenmis_exception;
      END IF;
   EXCEPTION
      WHEN guncellenmis_exception
      THEN
         Raise_application_error (
            -20100,
               pkg_hata.getUCPOINTER
            || '449'
            || pkg_hata.getDelimiter
            || TO_CHAR ('SQLCODE')
            || SQLERRM
            || pkg_hata.getDelimiter
            || pkg_hata.getUCPOINTER);
      WHEN OTHERS
      THEN
         Raise_application_error (
            -20100,
               pkg_hata.getUCPOINTER
            || '449'
            || pkg_hata.getDelimiter
            || TO_CHAR ('SQLCODE')
            || SQLERRM
            || pkg_hata.getDelimiter
            || pkg_hata.getUCPOINTER);
   END;

   ----------------------------------------------------------
   PROCEDURE sp_teklifislem_durum_guncelle (
      pn_islem_no           NUMBER,
      ps_yeni_durum_kodu    cbs_kredi_teklif.durum_kodu%TYPE)
   IS
   BEGIN
      UPDATE cbs_kredi_teklif_islem
         SET durum_kodu = ps_yeni_durum_kodu
       WHERE tx_no = pn_islem_no;
   END;

   ----------------------------------------------------------
   FUNCTION Kullanici_Maas_Izleyebilir (pn_musteri      NUMBER,
                                        ps_kullanici    VARCHAR2)
      RETURN VARCHAR2
   IS
      ln_cnt           NUMBER;
      ln_cnt2          NUMBER;
      ln_personel_no   NUMBER;
      ls_ret           VARCHAR2 (1);
   BEGIN
      ls_ret := 'E';

      SELECT COUNT (*)
        INTO ln_cnt
        FROM cbs_musteri
       WHERE musteri_no = pn_musteri AND PERSONEL_SICIL_NO IS NOT NULL;

      IF ln_cnt = 1
      THEN
         ln_personel_no :=
            pkg_kullanici.kullanici_personel_kodu_al (ps_kullanici);

         SELECT COUNT (*)
           INTO ln_cnt2
           FROM cbs_maas_hesap_izle
          WHERE PERSONEL_NO = ln_personel_no;

         IF ln_cnt2 = 0
         THEN
            ls_ret := 'H';
         END IF;
      END IF;

      RETURN ls_ret;
   END;

   -----------------------------------------------------------------------------------------------
   FUNCTION sf_overdraft_urun_adet (pn_islem_no NUMBER)
      RETURN NUMBER
   IS
      ln_cek_urun_adet   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO ln_cek_urun_adet
        FROM cbs_kredi_teklif_satir_islem
       WHERE     tx_no = pn_islem_no
             AND pkg_tx1300.sf_teklif_overdraft_urun_mu (KREDI_TURU) = 'E';

      RETURN ln_cek_urun_adet;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END;

   ----------------------------------------------------------
   FUNCTION sf_teklif_overdraft_urun_mu (pn_urun_grup_no NUMBER)
      RETURN VARCHAR2
   IS
      ls_tanim   VARCHAR2 (200);
   BEGIN
      SELECT tanim
        INTO ls_tanim
        FROM CBS_URUN_GRUBU
       WHERE numara = pn_urun_grup_no AND UPPER (tanim) LIKE '%OVERDRAFT%';

      IF ls_tanim IS NOT NULL
      THEN
         RETURN 'E';
      ELSE
         RETURN 'H';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;

   ----------------------------------------------------------
   FUNCTION sf_kredi_kart_urun_mu (pn_urun_grup_no NUMBER)
      RETURN VARCHAR2
   IS
      ls_tanim   VARCHAR2 (200);
   BEGIN
      SELECT tanim
        INTO ls_tanim
        FROM CBS_URUN_GRUBU
       WHERE numara = pn_urun_grup_no AND UPPER (tanim) LIKE '%CREDIT CARD%';


      IF ls_tanim IS NOT NULL
      THEN
         RETURN 'E';
      ELSE
         RETURN 'H';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;

   ----------------------------------------------------------
   --BOM NurmilaZh CBS-197 15.07.19
   FUNCTION sf_cashcall_is_not_zero (pn_musteri_no NUMBER)
      RETURN BOOLEAN
   IS
      l_balance   NUMBER := 0;
   BEGIN
      SELECT SUM (ABS (bakiye))
        INTO l_balance
        FROM cbs_vw_hesap_izleme
       WHERE     modul_tur_kod = 'CURRENT'
             AND urun_tur_kod = 'CASH COLL.'
             AND urun_sinif_kod = 'LC'
             AND musteri_no = pn_musteri_no
             AND durum_kodu = 'A';

      IF l_balance <> 0
      THEN
         RETURN FALSE;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN TRUE;
   END;

   --EOM NurmilaZh CBS-197 15.07.19
   --------------------------------------------------------------
   --BOM NurmilaZh CBS-197 15.07.19
   FUNCTION sf_credit_accounts_is_not_zero (pn_musteri_no NUMBER)
      RETURN VARCHAR2
   IS
      ln_count                  NUMBER;
      ln_balance                NUMBER := 0;
      PS_CARDNO                 VARCHAR2 (200);
      PS_CUSTOMERNO             VARCHAR2 (200);
      PS_CRMNO                  VARCHAR2 (200);
      PS_CUSTOMERNAME           VARCHAR2 (200);
      PS_LASTSTATEMENTDATE      VARCHAR2 (200);
      PS_LASTPAYMENTDATE        VARCHAR2 (200);
      PS_NEARESTSTATEMENTDATE   VARCHAR2 (200);
      PS_STATEMENTCODE          VARCHAR2 (200);
      PS_MINPAYMENTAMOUNT       VARCHAR2 (200);
      PS_TOTALDEBT              VARCHAR2 (200);
      ln_TOTALDEBT              NUMBER := 0; --CBS-667 04072022
      PS_RESPONSE_CODE          VARCHAR2 (200);
      PS_RESPONSE_DESC          VARCHAR2 (200);
      PC_REF                    SYS_REFCURSOR;

      CURSOR cur_cr_card
      IS
         SELECT UNIQUE card_id_no, customer_no, created_date
           FROM cbs_credit_card
          WHERE     
--          status = 'A' --CBS-667 04072022
--                AND 
                primary_card_flag = 'A'
                AND customer_no = pn_musteri_no;

      r_cur                     cur_cr_card%ROWTYPE;
   BEGIN
      SELECT COUNT (*)
        INTO ln_count
        FROM cbs_credit_card
       WHERE customer_no = pn_musteri_no;

      SELECT SUM (ABS (bakiye))
        INTO ln_balance
        FROM cbs_vw_hesap_izleme
       WHERE     musteri_no = pn_musteri_no
             AND durum_kodu = 'A'
             AND hesap_no IN (PKG_ATM_HESAP.OVERLIMIT_HESAPNO_AL (
                                 pn_musteri_no,
                                 pkg_genel.lc_al),
                              PKG_ATM_HESAP.LOAN_HESAPNO_AL (pn_musteri_no,
                                                             pkg_genel.lc_al),
                              PKG_ATM_HESAP.PASTDUE_HESAPNO_AL (
                                 PKG_ATM_HESAP.LOAN_HESAPNO_AL (
                                    pn_musteri_no,
                                    pkg_genel.lc_al)),
                              PKG_ATM_HESAP.INSTALLMENT_HESAPNO_AL (
                                 pn_musteri_no,
                                 pkg_genel.lc_al),
                              PKG_ATM_HESAP.PASTDUE_HESAPNO_AL (
                                 PKG_ATM_HESAP.INSTALLMENT_HESAPNO_AL (
                                    pn_musteri_no,
                                    pkg_genel.lc_al)));

      IF ln_count <> 0
      THEN
         FOR r_cur IN cur_cr_card
         LOOP
            pkg_credit_card.SP_STATSIMREQ_WS (
               r_cur.CARD_ID_NO,
               LPAD (r_cur.CUSTOMER_NO, 13, '0'),
               TO_CHAR (SYSDATE, 'YYYYMMDD'),           --date format YYYYMMDD
               PS_CARDNO,
               PS_CUSTOMERNO,
               PS_CRMNO,
               PS_CUSTOMERNAME,
               PS_LASTSTATEMENTDATE,
               PS_LASTPAYMENTDATE,
               PS_NEARESTSTATEMENTDATE,
               PS_STATEMENTCODE,
               PS_MINPAYMENTAMOUNT,
               PS_TOTALDEBT,
               PS_RESPONSE_CODE,
               PS_RESPONSE_DESC,
               PC_REF);
--BOM CBS-667 04072022               
               ln_TOTALDEBT := ln_TOTALDEBT + to_number(PS_TOTALDEBT,'99999999999.99'); 
         END LOOP;
         
          IF NVL (ps_response_code, 0) = '000'
               AND ln_TOTALDEBT > 0
               AND ln_balance <> 0
            THEN
               RETURN '1';
          ELSIF  (NVL(ps_response_code, 0) = '000'
                      AND ln_TOTALDEBT > 0)
                  OR ln_balance <> 0
            THEN
               RETURN '2';
          END IF;
--EOM CBS-667 04072022 
      END IF;

      RETURN '0';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN '0';
      WHEN OTHERS
      THEN
         RETURN '0';
   END;

   --EOM NurmilaZh CBS-197 15.07.19
   ------------------------------------------------------
   --CBS-293 GulkaiyrK
   FUNCTION sf_kredi_kart_install (pn_urun_grup_no NUMBER)
      RETURN VARCHAR2
   IS
      ls_tanim   VARCHAR2 (200);
   BEGIN
      SELECT tanim
        INTO ls_tanim
        FROM CBS_URUN_GRUBU
       WHERE     numara = pn_urun_grup_no
             AND tanim IN ('CREDIT CARD', 'INSTALLMENT');


      IF ls_tanim IS NOT NULL
      THEN
         RETURN 'E';
      ELSE
         RETURN 'H';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;
--CBS-293 GulkaiyrK
END;
/

