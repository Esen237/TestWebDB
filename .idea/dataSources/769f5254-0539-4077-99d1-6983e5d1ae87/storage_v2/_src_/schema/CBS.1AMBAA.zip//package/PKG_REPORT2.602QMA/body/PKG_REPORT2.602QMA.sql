create PACKAGE BODY     pkg_report2
 is
  function GET_REZ_DATE_STRING(RPT_DATE DATE) return VARCHAR2
  is
    result VARCHAR2(50);
  begin
   SELECT to_char(cast(RPT_DATE as date) + (3-to_number(to_char(cast(RPT_DATE as date), 'd'))), 'dd.mm.yyyy')||'-'||
                to_char(cast(RPT_DATE as date) + (3-to_number(to_char(cast(RPT_DATE as date), 'd'))) + 15, 'dd.mm.yyyy') str
     into result
     FROM dual;

    return result;
  end;

  function GET_REZ_GROWING(DATE_BEGIN DATE, DATE_END DATE,  DATE_CUR DATE) return NUMBER
  is
    result NUMBER;
  begin
    if TRUNC(DATE_CUR) IN (TRUNC(DATE_BEGIN), TRUNC(DATE_BEGIN+1)) then
      return(cast (null as number));
    elsif TRUNC(DATE_END) = TRUNC(DATE_CUR) then
      begin
        select round(sum(bakiye)/count(*)/1000) bakyie
          into result
          from (select sum(round(a.BAKIYE_LC)) bakiye
                  from cbs_dkhesap_gunluk_bakiye a
                 where substr(a.numara, 1, 4) in ('2201', '2202', '2203', '2204', '2205', '2211', '2221', '9003', '9004', '9005', '9006', '9007', '9008', '9009') and
                          a.BOLUM_KODU = '010' and
                       a.DOVIZ_KOD = a.DOVIZ_KOD and
                             to_date(pkg_report.fill_field(to_char(a.gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(a.ay), 2, 'RIGHT', '0')||to_char(a.yil), 'ddmmyyyy') between DATE_BEGIN and (DATE_END-1)
                 union all
                select nvl(sum(b.BAKIYE_LC), 0) bakyie
                  from cbs_rapor_sn_par a,
                       cbs_dkhesap_gunluk_bakiye b
                 where b.numara in ('2201', '2202', '2203', '2204', '2205', '2211', '2221', '9003', '9004', '9005', '9006', '9007', '9008', '9009') and
                          b.BOLUM_KODU = 'and' and
                       b.DOVIZ_KOD = b.DOVIZ_KOD and
                                to_date(pkg_report.fill_field(to_char(b.gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(b.ay), 2, 'RIGHT', '0')||to_char(b.yil), 'ddmmyyyy') between DATE_BEGIN and (DATE_END-1) and
                       substr(b.NUMARA, 1, 4) = substr(a.dk_kode, 1, 4));
        return(result);
      exception
        when others then
          return(cast (null as number));
      end;
    else
      begin
        select round(sum(bakiye)/count(*)/1000) bakyie
          into result
          from (select sum(round(a.BAKIYE_LC)) bakiye
                  from cbs_dkhesap_gunluk_bakiye a
                 where substr(a.numara, 1, 4) in ('2201', '2202', '2203', '2204', '2205', '2211', '2221', '9003', '9004', '9005', '9006', '9007', '9008', '9009') and
                          a.BOLUM_KODU = '010' and
                       a.DOVIZ_KOD = a.DOVIZ_KOD and
                             to_date(pkg_report.fill_field(to_char(a.gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(a.ay), 2, 'RIGHT', '0')||to_char(a.yil), 'ddmmyyyy') between DATE_BEGIN and DATE_END
                 union all
                select nvl(sum(b.BAKIYE_LC), 0) bakyie
                  from cbs_rapor_sn_par a,
                       cbs_dkhesap_gunluk_bakiye b
                 where b.numara in ('2201', '2202', '2203', '2204', '2205', '2211', '2221', '9003', '9004', '9005', '9006', '9007', '9008', '9009') and
                          b.BOLUM_KODU = 'and' and
                       b.DOVIZ_KOD = b.DOVIZ_KOD and
                                to_date(pkg_report.fill_field(to_char(b.gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(b.ay), 2, 'RIGHT', '0')||to_char(b.yil), 'ddmmyyyy') between DATE_BEGIN and DATE_END and
                       substr(b.NUMARA, 1, 4) = substr(a.dk_kode, 1, 4));
        return(result);
      exception
        when others then
          return(cast (null as number));
      end;
    end if;
  end;


  function GET_WORD_DATE_BY_NUM(DATE_BEGIN DATE, DATE_END DATE, ID NUMBER) return DATE
  is
    result date;
  begin
    SELECT DATE_NO
      into result
      FROM (SELECT ROWNUM ID_NO,
                   A.COLUMN_VALUE DATE_NO
              FROM TABLE(CAST(PKG_REPORT.VIRTUAL_TABLE_DATE(DATE_BEGIN, DATE_END) AS VIRTUAL_TABLE_TYPE_DATE)) A
             WHERE A.COLUMN_VALUE NOT IN (SELECT GUN
                                            FROM CBS_TAKVIM
                                           WHERE GUN BETWEEN DATE_BEGIN AND DATE_END))
     WHERE ID_NO = ID;
     return result;
  exception
    when others then
      return cast(null as date);
  end;

  function FIRST_DAY(DATE_ DATE) return DATE
  is
  begin
    return to_date('01.' || to_char(date_, 'mm.yyyy'), 'dd.mm.yyyy');
  end;

  function GET_NUM_DATE_BY_DATE(DATE_NO_ DATE) return NUMBER
  is
    result number;
  begin
    SELECT ID_NO
      into result
      FROM (SELECT ROWNUM ID_NO,
                   A.COLUMN_VALUE DATE_NO
              FROM TABLE(CAST(PKG_REPORT.VIRTUAL_TABLE_DATE(PKG_REPORT2.FIRST_DAY(DATE_NO_), LAST_DAY(DATE_NO_)) AS VIRTUAL_TABLE_TYPE_DATE)) A
             WHERE A.COLUMN_VALUE NOT IN (SELECT GUN
                                            FROM CBS_TAKVIM
                                           WHERE GUN BETWEEN PKG_REPORT2.FIRST_DAY(DATE_NO_) AND LAST_DAY(DATE_NO_)))
     WHERE DATE_NO = DATE_NO_;
    return result;
  exception
    when others then
      return cast(null as number);
  end;

  function GET_DAY_WORK_COUNT(RPT_DATE DATE) return NUMBER
  is
    result number;
  begin
    SELECT COUNT(*) CTN
      into result
      FROM TABLE(CAST(PKG_REPORT.VIRTUAL_TABLE_DATE(PKG_REPORT2.FIRST_DAY(RPT_DATE), LAST_DAY(RPT_DATE)) AS VIRTUAL_TABLE_TYPE_DATE)) A
     WHERE A.COLUMN_VALUE NOT IN (SELECT GUN
                                    FROM CBS_TAKVIM);
     return result;
  end;


  function GET_GL_ACIKLAMA(DK_KODU_ CBS_DKHESAP.DK_KOD%TYPE, LANG_KODU_ CBS_DKHESAP_DEFINITION.LANG_KODU%TYPE) return VARCHAR2
  is
    result CBS_DKHESAP_DEFINITION.DESCRIPTION%TYPE;
    len    NUMBER;
  begin
    len := LENGTH(DK_KODU_);
    select MAX(A.DESCRIPTION)
      into result
      from cbs_dkhesap_definition a
     where a.DK_KODU = DK_KODU_ and
           a.LANG_KODU = 'RUS';
    return result;
  exception
    when others then
      begin
           select MAX(A.DESCRIPTION)
             into result
             from cbs_dkhesap_definition a
            where substr(a.DK_KODU, 1, len) = DK_KODU_ and
                  a.LANG_KODU = 'RUS';
        return result;
      exception
        when others then
          return '';
      end;

  end;


  function GET_AVERAGE_BAKIYE(DATE_ DATE, NUMARA_ VARCHAR2, DOVIZ_KOD_ VARCHAR2, TYPE_ VARCHAR2/*FC, LC*/) RETURN NUMBER
  is
    result number;
  begin
    if TYPE_ = 'LC' then
        select a.ortalama_bakiye*c.DVZALIS
          into result
          from CBS_DKHESAP_YILORTALAMA_BAKIYE a,
               CBS_MBKURLOG c
         where to_date(to_char(a.GUN, '00')||to_char(a.AY, '00')||to_char(a.YIL, '0000'), 'ddmmyyyy') = DATE_ and
               a.DOVIZ_KOD = DOVIZ_KOD_ and
               a.NUMARA = NUMARA_ and
               c.DVZ = a.DOVIZ_KOD and
               TRUNC(c.TARIH) = TRUNC(DATE_);
    else
        select a.ortalama_bakiye
          into result
          from CBS_DKHESAP_YILORTALAMA_BAKIYE a
         where to_date(to_char(a.GUN, '00')||to_char(a.AY, '00')||to_char(a.YIL, '0000'), 'ddmmyyyy') = DATE_ and
               a.DOVIZ_KOD = DOVIZ_KOD_ and
               a.NUMARA = NUMARA_;
    end if;
    return result;
  exception
    when others then
      return 0;
  end;

  function GET_BAKIYE(DATE_ DATE, BOLUM_KOD_ VARCHAR2, TUR_ VARCHAR2, NUMARA_ VARCHAR2, DOVIZ_KOD_ VARCHAR2, TYPE_ VARCHAR2/*FC, LC*/) RETURN NUMBER
  is
    result number;
  begin
    if TYPE_ = 'LC' then
      select sum(bakiye_lc) bakiye_lc
        into result
        from cbs_rpt_mizan
       where bolum_kodu=nvl(BOLUM_KOD_, bolum_kodu)
         and length(dk_numara) in (4,6,8)
         and trunc(tarih)= trunc(decode(TRIM(UPPER(TO_CHAR(DATE_, 'DAY'))), 'SUNDAY', DATE_-2, 'SATURDAY', DATE_ - 1, DATE_))
         --and trunc(tarih)=trunc(DATE_)
         and tur=nvl(tur_, tur)
         and ( borc_lc !=0  or alacak_lc  !=0  or borc_fc !=0  or alacak_fc !=0  or bakiye_lc !=0  or bakiye_fc !=0)
         and dk_numara = numara_
         and doviz_kod = doviz_kod_;
    else
      select sum(decode(length(dk_numara),8,bakiye_fc,0)) bakiye_fc
        into result
        from cbs_rpt_mizan
       where bolum_kodu=nvl(BOLUM_KOD_, bolum_kodu)
         and length(dk_numara) in (4,6,8)
         and trunc(tarih)= trunc(decode(TRIM(UPPER(TO_CHAR(DATE_, 'DAY'))), 'SUNDAY', DATE_-2, 'SATURDAY', DATE_ - 1, DATE_))
         --and trunc(tarih)=trunc(DATE_)
         and tur=tur_
         and ( borc_lc !=0  or alacak_lc  !=0  or borc_fc !=0  or alacak_fc !=0  or bakiye_lc !=0  or bakiye_fc !=0)
         and dk_numara = numara_
         and doviz_kod = doviz_kod_;
    end if;
    return result;
  exception
    when others then
      return 0;
  end;

  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ date) return number
  as
    p4703  NUMBER;
    p5703  NUMBER;
  begin
    if gl_ <> '4703' and gl_ <> '5703' then
        return bakiye_;
    else
        if gl_ = '4703' then
          p4703 := abs(bakiye_);
            select sum(round(abs(nvl(BAKIYE_LC, 0))/1000))  bakiye
              into p5703
              from cbs_dkhesap_gunluk_bakiye
             where to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_ and
                    substr(numara, 1, 4) = '5703';
          if p4703 > p5703 then
            return p4703-p5703;
          else
            return 0;
          end if;
        elsif gl_ = '5703' then
          p5703 := abs(bakiye_);
            select sum(round(abs(nvl(BAKIYE_LC, 0))/1000))  bakiye
              into p4703
              from cbs_dkhesap_gunluk_bakiye
             where to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_ and
                    substr(numara, 1, 4) = '4703';
          if p5703 > p4703 then
            return p5703-p4703;
          else
            return 0;
          end if;
        end if;
    end if;
  end;

  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ date, bolum_kodu_ varchar2) return number
  as
    p4703  NUMBER;
    p5703  NUMBER;
  begin
    if gl_ <> '4703' and gl_ <> '5703' then
        return bakiye_;
    else
        if gl_ = '4703' then
          p4703 := abs(bakiye_);
            select sum(round(abs(nvl(BAKIYE_LC, 0))/1000))  bakiye
              into p5703
              from cbs_dkhesap_gunluk_bakiye
             where to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_ and
                    substr(numara, 1, 4) = '5703' and
                   bolum_kodu = bolum_kodu_;
          if p4703 > p5703 then
            return p4703-p5703;
          else
            return 0;
          end if;
        elsif gl_ = '5703' then
          p5703 := abs(bakiye_);
            select sum(round(abs(nvl(BAKIYE_LC, 0))/1000))  bakiye
              into p4703
              from cbs_dkhesap_gunluk_bakiye
             where to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_ and
                    substr(numara, 1, 4) = '4703' and
                   bolum_kodu = bolum_kodu_;
          if p5703 > p4703 then
            return p5703-p4703;
          else
            return 0;
          end if;
        end if;
    end if;
  end;

  function val_pos(gl_ varchar2, date_ date) return number
  as
    result NUMBER;
    p1351  NUMBER;
    p1352  NUMBER;

    p2151  NUMBER;
    p2152  NUMBER;


    p1858  NUMBER;
    p1859  NUMBER;

    p2858  NUMBER;
    p2859  NUMBER;
  begin
    if gl_ not in ('1351', '1352', '1858', '1859', '2151', '2152', '2858', '2859') then
        return 0;
    else
        if gl_ in ('1351', '1352', '2151', '2152') then
                select count(*)
                  into result
                  from (select round(sum(f1351)/1000) f1351,
                               round(sum(f1352)/1000) f1352,
                               round(sum(f2151)/1000) f2151,
                               round(sum(f2152)/1000) f2152,
                               round(sum(f1351+f1352)/1000) f13,
                               round(sum(f2151+f2152)/1000) f21
                          from (select dk,
                                       decode(dk, '1351', bakiye, 0) f1351,
                                       decode(dk, '1352', bakiye, 0) f1352,
                                       decode(dk, '2151', bakiye, 0) f2151,
                                       decode(dk, '2152', bakiye, 0) f2152
                                  from (select substr(numara, 1, 4) dk,
                                                    abs(sum(nvl(BAKIYE_LC, 0)))  bakiye
                                          from cbs_dkhesap_gunluk_bakiye
                                         where to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') = DATE_ and
                                                substr(numara, 1, 4) in ('1351', '1352', '2151', '2152')
                                         group by substr(numara, 1, 4))))
                  where f13 = f21;--f1351+f1352 = f2151+f2152;
        else
                select count(*)
                  into result
                  from (select round(sum(f1858)/1000) f1858,
                               round(sum(f1859)/1000) f1859,
                               round(sum(f2858)/1000) f2858,
                               round(sum(f2859)/1000) f2859,
                               round(sum(f1858+f1859)/1000) f18,
                               round(sum(f2858+f2859)/1000) f28
                          from (select dk,
                                       decode(dk, '1858', bakiye, 0) f1858,
                                       decode(dk, '1859', bakiye, 0) f1859,
                                       decode(dk, '2858', bakiye, 0) f2858,
                                       decode(dk, '2859', bakiye, 0) f2859
                                  from (select substr(numara, 1, 4) dk,
                                                    abs(round(sum(nvl(BAKIYE_LC, 0))/1000))  bakiye
                                          from cbs_dkhesap_gunluk_bakiye
                                         where to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') = DATE_ and
                                                substr(numara, 1, 4) in ('1858', '1859', '2858', '2859')
                                         group by substr(numara, 1, 4))))
                  where f18=f28;--f1858+f1859 = f2858+f2859;
         end if;
      return result;
    end if;
  end;

  function CBS_SN_BALANCE(DATE_ in DATE, BOLUM_ in varchar2)
  return SN_BALANCE_TABLE pipelined
  as
    L_SN_BALANCE SN_BALANCE;
  begin
    for l_myrow in (
                   --begin select

        select '((190501788 ' || to_char(DATE_, 'dd.mm.yyyy') || ' 700-H' numara,
               null bakiye_a,
               null bakiye_p,
               null bakiye,
               1 order_no
          from dual
         union
        select to_char(DATE_, 'dd.mm.yyyy') numara,
               null bakiye_a,
               null bakiye_p,
               null bakiye,
               2 order_no
          from dual
         union
        select decode(grouping(numara), 1, '0', numara) numara,
               sum(bakiye_a) bakiye_a,
               sum(bakiye_p) bakiye_p,
               sum(bakiye) bakiye,
               decode(grouping(numara), 1, 11, 10) order_no /*data_group*/
          from (


                select '3599' numara,
                       0 bakiye_a,
                       sum(decode(substr(numara, 1, 1), '4', BAKIYE_LC)) - sum(decode(substr(numara, 1, 1), '5', BAKIYE_LC)) bakiye_p,
                       sum(decode(substr(numara, 1, 1), '4', BAKIYE_LC)) - sum(decode(substr(numara, 1, 1), '5', BAKIYE_LC)) bakiye
                  from (select substr(numara, 1, 4) numara,
                               sum(round(decode(substr(numara, 1, 4), '1205', -abs(nvl(BAKIYE_LC, 0)), '1428', -abs(nvl(BAKIYE_LC, 0)), '1453', -abs(nvl(BAKIYE_LC, 0)), '1465', -abs(nvl(BAKIYE_LC, 0)), '1692', -abs(nvl(BAKIYE_LC, 0)), '1693', -abs(nvl(BAKIYE_LC, 0)), '1694', -abs(nvl(BAKIYE_LC, 0)), '1698', -abs(nvl(BAKIYE_LC, 0)), '1699', -abs(nvl(BAKIYE_LC, 0)), '1878', -abs(nvl(BAKIYE_LC, 0)), '5455', -abs(nvl(BAKIYE_LC, 0)), abs(nvl(BAKIYE_LC, 0)))/1000))  bakiye_lc
                          from cbs_dkhesap_gunluk_bakiye
                         where to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_ and
                                substr(numara, 1, 1) in ('4', '5') and
                               ((bolum_ is not null and bolum_kodu = bolum_) or
                                (bolum_ is null and bolum_kodu = bolum_kodu))
                         group by substr(numara, 1, 4))
                 union
                select dk_kod,
                       sum(a_bakiye) a_bakiye,
                       sum(p_bakiye) p_bakiye,
                       sum(bakiye) bakiye
                  from (select c.DK_KOD,
                                  decode(substr(c.DK_KOD, 1, 1), '1', c.bakiye, '5', c.bakiye, '7', c.bakiye,
                                                                 '6', decode(substr(c.DK_KOD, 2, 1), '0', c.bakiye, '1', c.bakiye,
                                                                                                     '2', c.bakiye, '4', c.bakiye, 0), 0) a_bakiye,
                               decode(substr(c.DK_KOD, 1, 1), '2', c.bakiye, '3', c.bakiye, '4', c.bakiye,
                                                              '6', decode(substr(c.DK_KOD, 2, 1), '5', c.bakiye, '6', c.bakiye,
                                                                                                  '7', c.bakiye, '8', c.bakiye,
                                                                                                  '9', c.bakiye, 0), 0) p_bakiye,
                               c.bakiye
                          from (select dk_kod,
                                            PKG_REPORT2.difference_5703_4703(dk_kod, bakiye, DATE_) bakiye
                                  from (select substr(numara, 1, 4) dk_kod,
                                                    sum(round(decode(substr(numara, 1, 4), '1205', -abs(nvl(BAKIYE_LC, 0)), '1428', -abs(nvl(BAKIYE_LC, 0)), '1453', -abs(nvl(BAKIYE_LC, 0)), '1465', -abs(nvl(BAKIYE_LC, 0)), '1692', -abs(nvl(BAKIYE_LC, 0)), '1693', -abs(nvl(BAKIYE_LC, 0)), '1694', -abs(nvl(BAKIYE_LC, 0)), '1698', -abs(nvl(BAKIYE_LC, 0)), '1699', -abs(nvl(BAKIYE_LC, 0)), '1878', -abs(nvl(BAKIYE_LC, 0)), '5455', -abs(nvl(BAKIYE_LC, 0)), abs(nvl(BAKIYE_LC, 0)))/1000))  bakiye
                                          from cbs_dkhesap_gunluk_bakiye
                                         where to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_ and
                                                   ((bolum_ is not null and bolum_kodu = bolum_) or
                                               (bolum_ is null and bolum_kodu = bolum_kodu))
                                         group by substr(numara, 1, 4)))c )
                 group by dk_kod
                 union

                   select a.sn_dk_kode dk_kod,
                          abs(round(sum(nvl(b.BAKIYE_LC, 0))/1000)) a_bakiye,
                       0 p_bakiye,
                       abs(round(sum(nvl(b.BAKIYE_LC, 0))/1000)) bakiye
                     from cbs_rapor_sn_par a,
                           (select sum(bakiye_lc) bakiye_lc,
                                  numara
                             from cbs_dkhesap_gunluk_bakiye
                            where to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') = DATE_ and
                               ((bolum_ is not null and bolum_kodu = bolum_) or
                                (bolum_ is null and bolum_kodu = bolum_kodu))
                            group by numara) b
                    where substr(b.NUMARA, 1, length(a.DK_KODE)) = a.dk_kode
                    group by a.sn_dk_kode
                  union
              select '8050' dk_kod,
                       nvl(abs(round(sum(nvl(a.BAKIYE_LC, 0))/1000)), 0) a_bakiye,
                     0 p_bakiye,
                     nvl(abs(round(sum(nvl(a.BAKIYE_LC, 0))/1000)), 0) bakiye
                from cbs_dkhesap_gunluk_bakiye a
               where substr(a.NUMARA, 1, 4) in ('1001', '1002', '1003', '1005') and
                     to_number(a.NUMARA) <= '100599' and
                     to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') = DATE_ and
                     ((bolum_ is not null and bolum_kodu = bolum_) or
                     (bolum_ is null and bolum_kodu = bolum_kodu)) and
                          a.DOVIZ_KOD not in ('USD', 'EUR', 'KZT', 'CHF', 'GBP')
                  union
              select '8037' dk_kod,
                       nvl(abs(round(sum(nvl(a.BAKIYE_LC, 0))/1000)), 0) a_bakiye,
                     0 p_bakiye,
                     nvl(abs(round(sum(nvl(a.BAKIYE_LC, 0))/1000)), 0) bakiye
                from cbs_dkhesap_gunluk_bakiye a
               where substr(a.NUMARA, 1, 4) in ('1001', '1002', '1003', '1005') and
                        to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') = DATE_ and
                     to_number(a.NUMARA) <= '100599' and
                     ((bolum_ is not null and bolum_kodu = bolum_) or
                     (bolum_ is null and bolum_kodu = bolum_kodu)) and
                          a.DOVIZ_KOD in ('USD', 'EUR', 'CHF', 'GBP')
               union
              select '8134' dk_kod,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0 p_bakiye,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap b,
                          cbs_musteri c,
                          cbs_uyruk_kodlari d
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                          substr(b.MUSTERI_DK_NO, 1, 6) in ('105224', '125224', '105214', '125214') and
                          c.MUSTERI_NO = b.MUSTERI_NO and
                          d.UYRUK_KODU = c.UYRUK_KOD and
                          d.ACIKLAMA in ('GERMANY', 'UNITED STATES', 'JAPAN') and
                          c.TICARI_UNVAN in ('AMERICAN EXPRESS BANK', 'UNION BANK OF CALIFORNIA INTERNATIONAL', 'COMMERZBANK AG') and
                          --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
                     a.balance_date=TRUNC(date_)--CBS-475
               union
              select '8135' dk_kod,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0 p_bakiye,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap b,
                          cbs_musteri c,
                          cbs_uyruk_kodlari d
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                          substr(b.MUSTERI_DK_NO, 1, 6) in ('130124', '130114') and
                          c.MUSTERI_NO = b.MUSTERI_NO and
                          d.UYRUK_KODU = c.UYRUK_KOD and
                          d.ACIKLAMA in ('GERMANY', 'UNITED STATES', 'JAPAN') and
                          c.TICARI_UNVAN in ('AMERICAN EXPRESS BANK', 'UNION BANK OF CALIFORNIA INTERNATIONAL', 'COMMERZBANK AG') and
                          --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
                     a.balance_date=TRUNC(date_)--CBS-475
               union
              select '8059' dk_kod,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0 p_bakiye,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap b,
                          cbs_musteri c
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                          substr(b.MUSTERI_DK_NO, 1, 6) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                          c.MUSTERI_NO = b.MUSTERI_NO and
                          c.TICARI_UNVAN in ('CITIBANK NA') and
                         -- trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
                      a.balance_date=TRUNC(date_)--CBS-475
               union
              select '8076' dk_kod,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0 p_bakiye,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap b,
                          cbs_musteri c,
                          cbs_uyruk_kodlari d
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                          substr(b.MUSTERI_DK_NO, 1, 6) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                          c.MUSTERI_NO = b.MUSTERI_NO and
                          d.UYRUK_KODU = c.UYRUK_KOD and
                          d.ACIKLAMA in ('GERMANY', 'UNITED STATES', 'JAPAN') and
                          c.TICARI_UNVAN in ('AMERICAN EXPRESS BANK', 'UNION BANK OF CALIFORNIA INTERNATIONAL', 'COMMERZBANK AG') and
                          --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
                       a.balance_date=TRUNC(date_)--CBS-475
               union
              select '8091' dk_kod,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0 p_bakiye,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap b,
                          cbs_musteri c
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                          substr(b.MUSTERI_DK_NO, 1, 6) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                          c.MUSTERI_NO = b.MUSTERI_NO and
                          c.TICARI_UNVAN in ('HALYK SAVINGS BANK OF KAZAKHSTAN', 'SAUDI HOLLANDI BANK') and
                          --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
                       a.balance_date=TRUNC(date_)--CBS-475
               union
              select '8128' dk_kod,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0 p_bakiye,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap b,
                          cbs_musteri c
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                          c.MUSTERI_NO = b.MUSTERI_NO and
                     c.MUSTERI_NO in (select MUSTERI_NO
                                           from cbs_musteri_grup_bagli_musteri
                                       where GRUP_KODU='DEMIR') and
                          --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
                       a.balance_date=TRUNC(date_)--CBS-475
               union
              select '8129' dk_kod,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0 p_bakiye,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap b,
                          cbs_musteri c
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                          c.MUSTERI_NO = b.MUSTERI_NO and
                     c.MUSTERI_NO in (select MUSTERI_NO
                                           from cbs_musteri_grup_bagli_musteri
                                       where GRUP_KODU='DEMIR') and
                          --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
                       a.balance_date=TRUNC(date_)--CBS-475
               union
              select '9001',
                          round(abs(sum(a.BAKIYE_LC))/1000),
                          0,
                          round(abs(sum(a.BAKIYE_LC))/1000)
                from cbs_dkhesap_gunluk_bakiye a
               where substr(a.NUMARA, 1, 4) in ('1001', '1002', '1003', '1004', '1005', '1007', '1008') and
                        ((bolum_ is not null and a.bolum_kodu = bolum_) or
                     (bolum_ is null and a.bolum_kodu = a.bolum_kodu)) and
                     a.DOVIZ_KOD = 'KZT' and
                          trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(date_, 'ddmmyyyy')
               union
              select '9003',
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap_vadeli b
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                      substr(b.MUSTERI_DK_NO, 1, 4) = '2301' and
                     substr(b.MUSTERI_DK_NO, 1, 6) not in ('230113', '230114') and
                     --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(DATE_, 'ddmmyyyy') and
                       a.balance_date=TRUNC(date_) and--CBS-475
                     (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(DATE_, 'mmyyyy') or
                      to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(DATE_)+1, 'mmyyyy'))
               union
              select '9004',
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap_vadeli b
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                      substr(b.MUSTERI_DK_NO, 1, 4) = '2303' and
                     substr(b.MUSTERI_DK_NO, 1, 6) not in ('230313', '230314') and
                     --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(DATE_, 'ddmmyyyy') and
                       a.balance_date=TRUNC(date_) and--CBS-475
                     (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(DATE_, 'mmyyyy') or
                      to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(DATE_)+1, 'mmyyyy'))
               union
              select '9005',
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap_vadeli b
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                      substr(b.MUSTERI_DK_NO, 1, 4) = '2401' and
                     substr(b.MUSTERI_DK_NO, 1, 6) not in ('240113', '240114') and
                     --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(DATE_, 'ddmmyyyy') and
                       a.balance_date=TRUNC(date_) and--CBS-475
                     (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(DATE_, 'mmyyyy') or
                      to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(DATE_)+1, 'mmyyyy'))
               union
              select '9006',
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap_vadeli b
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                      substr(b.MUSTERI_DK_NO, 1, 4) = '2855' and
                     substr(b.MUSTERI_DK_NO, 1, 6) not in ('285513', '285514', '285524') and
                     --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(DATE_, 'ddmmyyyy') and
                       a.balance_date=TRUNC(date_) and--CBS-475
                     (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(DATE_, 'mmyyyy') or
                      to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(DATE_)+1, 'mmyyyy'))
               union
              select '9007',
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap_vadeli b
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                      substr(b.MUSTERI_DK_NO, 1, 4) = '2870' and
                     substr(b.MUSTERI_DK_NO, 1, 6) not in ('285502', '285511', '285513') and
                     --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(DATE_, 'ddmmyyyy') and
                       a.balance_date=TRUNC(date_) and--CBS-475
                     (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(DATE_, 'mmyyyy') or
                      to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(DATE_)+1, 'mmyyyy'))
               union
              select '9009',
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap_vadeli b
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                      substr(b.MUSTERI_DK_NO, 1, 4) in ('2206', '2207', '2208', '2215', '2217', '2219', '2222', '2223') and
                    -- trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(DATE_, 'ddmmyyyy') and
                      a.balance_date=TRUNC(date_) and--CBS-475
                     (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(DATE_, 'mmyyyy') or
                      to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(DATE_)+1, 'mmyyyy'))

               union
              select '8131',
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0),
                     0,
                     nvl(round(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, DATE_, a.BAKIYE, 1, null, null, 'N', 'B')))/1000), 0)
                from cbs_hesap_gunluk_bakiye a,
                     cbs_hesap_kredi b
               where b.HESAP_NO = a.HESAP_NO and
                        ((bolum_ is not null and b.sube_kodu = bolum_) or
                     (bolum_ is null and b.sube_kodu = b.sube_kodu)) and
                      substr(b.MUSTERI_DK_NO, 1, 6) in ('145111', '145113', '145115', '145121', '145122', '174411', '174511', '186004', '145311', '145313', '145315') and
                     --trim(to_char(a.GUN, '00'))||trim(to_char(a.AY, '00'))||trim(to_char(a.YIL, '0000'))=to_char(DATE_, 'ddmmyyyy') and
                       a.balance_date=TRUNC(date_) and--CBS-475
                     b.KREDI_VADE-b.ACILIS_TARIHI < 93

         ) group by     rollup(numara)
           union
             select '))' numara, null, null, null, 20 order_no
            from dual
           order by order_no, numara
                   --end select
                    ) loop
      L_SN_BALANCE := SN_BALANCE(l_myrow.NUMARA, l_myrow.bakiye_a, l_myrow.bakiye_p, l_myrow.bakiye, l_myrow.order_no);
      pipe row (L_SN_BALANCE);
    end loop;
    return;
  end;


end PKG_REPORT2;
/

