create PACKAGE BODY     PKG_INT_BYPHONE_INQ
AS
-- Package body

FUNCTION GetAccountsByPhone(ps_lang varchar2,
                                   ps_phone_number varchar2, pc_ref OUT CursorReferenceType,
                                   pc_ref2 OUT CursorReferenceType, pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS 
ln_customer_number number;
ln_customer_number_second number;
ln_count_customer number;
ls_tax_number_1 varchar2(20 byte);
ls_passport_1 varchar2(20 byte);
ls_identity_serial_no_1 varchar2(20 byte);
ls_tax_number_2 varchar2(20 byte);
ls_passport_2 varchar2(20 byte);
ls_identity_serial_no_2 varchar2(20 byte);
ls_owner varchar2(5 byte);
ls_owner_masked_full_name varchar2(150);
ls_returncode varchar2(3) := '000';
le_duplicate_phone_number exception;
le_phone_number_not_found exception;
BEGIN
 
   select count(*) into ln_count_customer
     from cbs_musteri a
       left join cbs_musteri_source b on a.musteri_no = b.musteri_no
       left join cbs_musteri_adres c on a.musteri_no = c.musteri_no
          where ((nvl(c.ulke_gsm_kod, '996') || c.gsm_alan_kod  || c.gsm_no) = ps_phone_number
                 or (nvl(c.ulke_gsm_kod_2, '996') || c.gsm_alan_kod_2  || c.gsm_no_2) = ps_phone_number
                 or (nvl(c.ulke_gsm_kod_3, '996') || c.gsm_alan_kod_3  || c.gsm_no_3) = ps_phone_number)
                 and a.durum_kodu = 'A';
                 
    if ln_count_customer > 2 then
       raise le_duplicate_phone_number;
    end if;
    
    
    if ln_count_customer = 0 then
       raise le_phone_number_not_found;
    end if;
    
    if ln_count_customer = 2 then
          
           begin
               select a.vergi_no, 
                      a.pasaport_no, 
                      a.nufus_cuzdani_seri_no,
                      a.musteri_no
               into ls_tax_number_1,
                    ls_passport_1,
                    ls_identity_serial_no_1,
                    ln_customer_number
                     from cbs_musteri a
                       left join cbs_musteri_source b on a.musteri_no = b.musteri_no
                       left join cbs_musteri_adres c on a.musteri_no = c.musteri_no
                          where ((nvl(c.ulke_gsm_kod, '996') || c.gsm_alan_kod  || c.gsm_no) = ps_phone_number
                                 or (nvl(c.ulke_gsm_kod_2, '996') || c.gsm_alan_kod_2  || c.gsm_no_2) = ps_phone_number
                                 or (nvl(c.ulke_gsm_kod_3, '996') || c.gsm_alan_kod_3  || c.gsm_no_3) = ps_phone_number)
                                 and a.musteri_tipi_kod in ('1') 
                                 and a.durum_kodu = 'A';
                                 
              select a.vergi_no, 
                     a.pasaport_no, 
                     a.nufus_cuzdani_seri_no,
                     a.musteri_no
               into ls_tax_number_2,
                    ls_passport_2,
                    ls_identity_serial_no_2,
                    ln_customer_number_second
                     from cbs_musteri a
                       left join cbs_musteri_source b on a.musteri_no = b.musteri_no
                       left join cbs_musteri_adres c on a.musteri_no = c.musteri_no
                          where ((nvl(c.ulke_gsm_kod, '996') || c.gsm_alan_kod  || c.gsm_no) = ps_phone_number
                                 or (nvl(c.ulke_gsm_kod_2, '996') || c.gsm_alan_kod_2  || c.gsm_no_2) = ps_phone_number
                                 or (nvl(c.ulke_gsm_kod_3, '996') || c.gsm_alan_kod_3  || c.gsm_no_3) = ps_phone_number)
                                 and a.musteri_tipi_kod in ('2') 
                                 and a.durum_kodu = 'A';
                                 
                if (ls_tax_number_1 != ls_tax_number_2 and ls_passport_1 != ls_passport_2) then
                    raise le_duplicate_phone_number;
                end if;
                             
                                 
           exception 
             when others then
               return '456';          
           end;
    
    else
          select a.vergi_no, 
                      a.pasaport_no, 
                      a.nufus_cuzdani_seri_no,
                      a.musteri_no
               into ls_tax_number_1,
                    ls_passport_1,
                    ls_identity_serial_no_1,
                    ln_customer_number
                     from cbs_musteri a
                       left join cbs_musteri_source b on a.musteri_no = b.musteri_no
                       left join cbs_musteri_adres c on a.musteri_no = c.musteri_no
                          where ((nvl(c.ulke_gsm_kod, '996') || c.gsm_alan_kod  || c.gsm_no) = ps_phone_number
                                 or (nvl(c.ulke_gsm_kod_2, '996') || c.gsm_alan_kod_2  || c.gsm_no_2) = ps_phone_number
                                 or (nvl(c.ulke_gsm_kod_3, '996') || c.gsm_alan_kod_3  || c.gsm_no_3) = ps_phone_number)
                                 and a.durum_kodu = 'A';   
    
    
   
    end if;
   
   ls_owner_masked_full_name := pkg_int_customer_inq.getcustomername(ps_lang, ln_customer_number);
   open pc_ref FOR select ls_owner_masked_full_name as owner_masked_full_name from dual;
               
   open pc_ref2 for
           select min(ch.external_account_no) as iban, 
                  ch.currency_code as currency_code
                             from cbs_vw_checking_account ch
                                       where customer_no in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                                            and status = 'A' 
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')
                                            group by currency_code;
                                           
    open pc_ref3 FOR select ln_customer_number as customer_number from dual;
   
    return ls_returncode;
    
EXCEPTION 
    when le_phone_number_not_found then
          return '454'; 
    when le_duplicate_phone_number then
          return '456'; 
    when others then
          raise;        
END;

END PKG_INT_BYPHONE_INQ;
/

