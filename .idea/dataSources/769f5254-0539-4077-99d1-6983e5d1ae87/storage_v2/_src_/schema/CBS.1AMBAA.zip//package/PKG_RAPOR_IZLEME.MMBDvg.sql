create PACKAGE PKG_RAPOR_IZLEME IS

/******************************************************************************
   Name       : PKG_RAPOR_IZLEME
   Created By : Seval Balci
   Date    	  : 26.02.04
   Purpose	  : Rapor izleme ekranlar?ndan ?a?r?lan proc. ve fonks. i?erir
******************************************************************************/
 Procedure sp_cbs_rapor_islem_kayit_ata (ps_rapor_kodu varchar2,
 		   								 pn_islem_no    number ,
 		   							     ps_1_alan_adi varchar2 default null,
										 ps_1_degeri   varchar2 default null,
										 ps_2_alan_adi varchar2 default null,
										 ps_2_degeri   varchar2 default null ,
										 ps_3_alan_adi varchar2 default null,
										 ps_3_degeri   varchar2 default null,
										 ps_4_alan_adi varchar2 default null,
										 ps_4_degeri   varchar2 default null,
										 ps_5_alan_adi varchar2 default null,
										 ps_5_degeri   varchar2 default null,
										 ps_6_alan_adi varchar2 default null,
										 ps_6_degeri   varchar2 default null,
										 ps_7_alan_adi varchar2 default null,
										 ps_7_degeri   varchar2 default null,
										 ps_8_alan_adi varchar2 default null,
										 ps_8_degeri   varchar2 default null,
										 ps_9_alan_adi varchar2 default null,
										 ps_9_degeri   varchar2 default null,
										 ps_10_alan_adi varchar2 default null,
										 ps_10_degeri   varchar2 default null,
										 ps_11_alan_adi varchar2 default null,
										 ps_11_degeri   varchar2 default null,
										 ps_12_alan_adi varchar2 default null,
										 ps_12_degeri   varchar2 default null ,
										 ps_13_alan_adi varchar2 default null,
										 ps_13_degeri   varchar2 default null,
										 ps_14_alan_adi varchar2 default null,
										 ps_14_degeri   varchar2 default null,
										 ps_15_alan_adi varchar2 default null,
										 ps_15_degeri   varchar2 default null,
										 ps_16_alan_adi varchar2 default null,
										 ps_16_degeri   varchar2 default null,
										 ps_17_alan_adi varchar2 default null,
										 ps_17_degeri   varchar2 default null,
										 ps_18_alan_adi varchar2 default null,
										 ps_18_degeri   varchar2 default null,
										 ps_19_alan_adi varchar2 default null,
										 ps_19_degeri   varchar2 default null,
										 ps_20_alan_adi varchar2 default null,
										 ps_20_degeri   varchar2 default null
										 ) ;

 procedure sp_rapor_degerlerini_al      (pn_islem_no number,
 		   								 ps_rapor_kodu out varchar2 ,
										 ps_rapor_adi out varchar2 ,
 		   							     ps_1_alan_adi out varchar2 ,
										 ps_1_degeri   out varchar2 ,
										 ps_2_alan_adi out varchar2 ,
										 ps_2_degeri   out varchar2  ,
										 ps_3_alan_adi out varchar2 ,
										 ps_3_degeri   out varchar2 ,
										 ps_4_alan_adi out varchar2 ,
										 ps_4_degeri   out varchar2 ,
										 ps_5_alan_adi out varchar2 ,
										 ps_5_degeri   out varchar2 ,
										 ps_6_alan_adi out varchar2 ,
										 ps_6_degeri   out varchar2 ,
										 ps_7_alan_adi out varchar2 ,
										 ps_7_degeri   out varchar2 ,
										 ps_8_alan_adi out varchar2 ,
										 ps_8_degeri   out varchar2 ,
										 ps_9_alan_adi out varchar2 ,
										 ps_9_degeri   out varchar2 ,
										 ps_10_alan_adi out varchar2,
										 ps_10_degeri   out varchar2,
										 ps_11_alan_adi out varchar2,
										 ps_11_degeri   out varchar2,
										 ps_12_alan_adi out varchar2,
										 ps_12_degeri   out varchar2,
										 ps_13_alan_adi out varchar2,
										 ps_13_degeri   out varchar2,
										 ps_14_alan_adi out varchar2,
										 ps_14_degeri   out varchar2,
										 ps_15_alan_adi out varchar2,
										 ps_15_degeri   out varchar2,
										 ps_16_alan_adi out varchar2,
										 ps_16_degeri   out varchar2,
										 ps_17_alan_adi out varchar2,
										 ps_17_degeri   out varchar2,
										 ps_18_alan_adi out varchar2,
										 ps_18_degeri   out varchar2,
										 ps_19_alan_adi out varchar2,
										 ps_19_degeri   out varchar2,
										 ps_20_alan_adi out varchar2,
										 ps_20_degeri   out varchar2
									    );

 Function sf_dil_al return varchar2;
 Function sf_dil_adi_al (ps_dil varchar2 ) return varchar2;
 Procedure Write2File(ps_dizin varchar2 default 'c:\cbs\dosya', ps_filename IN VARCHAR2, ps_inputtext IN VARCHAR2);
 Procedure tcmb_cek_karsiz_dosya_olustur (ps_filename  out varchar2);
 Procedure tcmb_cek_hesap_dosya_olustur (ps_filename  out varchar2);
END;


/

