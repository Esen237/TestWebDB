create PACKAGE body PKG_FDBCR IS

/******************************************************************************
   Name       : PKG_FDBCR
   Created By : Mutlu Ozdemir
   Date    	  : 11.10.04
   Purpose	  : Free Debit Credit Operations
******************************************************************************/
  Function modul_tur_al return varchar2 is
  begin
    return('ACCOUNTING');
  end;

  Function urun_tur_al return varchar2 is
  begin
    return('F-DBCR');
  end;

END;
/

