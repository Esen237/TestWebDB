create PACKAGE Pkg_Tx7007 IS

  /******************************************************************************
   Name       : PKG_TX7007
   Created By : Hakan SAMSA
   Purpose	  : POS Payments
  ******************************************************************************/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 	-- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edildikten sonra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);	-- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);		-- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  	-- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);		-- Islemin muhasebelesmesi icin cagrilir

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);

 FUNCTION TotCommBul( ps_code CBS_POS_PAYMENTS_TRAN.POS_CODE%TYPE,
 		  			  ps_cycode CBS_POS_PAYMENTS_TRAN.CURRENCY_CODE%TYPE,
 		   			  pn_tutar1 CBS_POS_PAYMENTS_TRAN.NET_WITHDRAWAL_AMOUNT%TYPE) RETURN NUMBER;
 FUNCTION PaidCommBul( ps_code CBS_POS_PAYMENTS_TRAN.POS_CODE%TYPE,
 		  			   ps_cycode CBS_POS_PAYMENTS_TRAN.CURRENCY_CODE%TYPE,
 		   			   pn_tutar1 CBS_POS_PAYMENTS_TRAN.NET_WITHDRAWAL_AMOUNT%TYPE) RETURN NUMBER;
END;


/

