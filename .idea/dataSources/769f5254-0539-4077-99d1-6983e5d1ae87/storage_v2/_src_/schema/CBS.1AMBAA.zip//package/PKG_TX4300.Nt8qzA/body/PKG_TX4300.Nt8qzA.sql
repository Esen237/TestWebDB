create package body     pkg_tx4300 is
p_4300_lc_cash_gl number;
p_4300_fc_cash_gl number;

p_4300_gon_hes_vadeli number;            --GINDEREN HESAP VADELI
p_4300_islem_sube number;                --ISLEM SUBE
p_4300_hesap_sube number;                --HESAP_SUBE
p_4300_alici_sube number;                --ALICI_SUBE
p_4300_tutar_fc number;                  --TUTAR FC
p_4300_tutar_lc number;                  --TUTAR LC
p_4300_musteri_hesap_no number;          --MUSTERI HESAP NO
p_4300_urun_tur_kasadan number;          --URUN TUR KASADAN
p_4300_urun_tur_hesaptan number;         --URUN TUR HESAPTAN
p_4300_havale_isme number;               -- HAVALE_ISME
p_4300_havale_hesabami number;           --HAVALE_HESABAMI

p_4300_havale_doviz number;               --HAVALE D?V?Z
p_4300_lc_havale number;                  --LC HAVALE
p_4300_fc_havale number;                  --FC HAVALE
p_4300_masraf_tutar_lc number;            --MASRAF TUTAR LC
p_4300_masraf_tutar_fc number;            --MASRAF TUTAR FC
p_4300_bsmv number;                       --BSMV
p_4300_masraf_tutar_fark_bsmv number;     --MASRAF_TUTAR - BSMV
p_4300_aciklama number;                   --ACIKLAMA
p_4300_gon_hes_vadesiz number;            --GONDEREN HESAP VADESIZ
p_4300_hav_dvz_kur number;                --HAVALE DOVUZ_KUR
p_4300_masraf_ths_kasadan number;         --MASRAF TAHS?L KASADAN
p_4300_masraf_ths_hesaptan number;        --MASRAF TAHS?L HESAPTAN
p_4300_msrf_thsl_dvz_lc number;           --MSRF THSL DVZ : LC
p_4300_msrf_thsl_dvz_fc number;           --MSRF THSL DVZ : FC
p_4300_msrf_thsl_dvz number;              --MASRAF THSL D?V?Z KODU
p_4300_msrf_thsl_dvz_kur number;          --MASRAF THSL D?V?Z KURU
p_4300_istatistik_kod number;
p_4300_istatistik_kod_2 number;
p_4300_cash_code number;
p_4300_referans number;
p_4300_alici_hesap  number;               --ALICI HESAP NUMARASI
p_4300_commission_gl number;
p_4300_tax_lc number;  
p_4300_tax_fc number; 
p_4300_charge_tax_lc number;  
p_4300_charge_tax_fc number; 
p_4300_round_error_d number; 
p_4300_round_error_c number;  
p_4300_round_error number; 
  procedure yaratma_oncesi(pn_islem_no number) is
  begin
    null;
  end;
--*************************************************************************************--
  procedure kontrol_sonrasi(pn_islem_no number) is
  ls_urun_tur varchar2(10);
  ls_masraf_tahsil_sekli varchar2(10);
  ls_doviz_kodu varchar2(3);
  ls_masraf_tahsil_doviz varchar2(3);
  ln_tutar number;
  ln_masraf_tutari number;
  ln_masraf_tahsildvzli_tutar number;
  ln_tax_amount number;
  ln_tax_currency_amount number ;
  ls_gonderen_isim_unvan    varchar2(2000);
  ls_aciklama     varchar2(2000);
  ls_istatistik_kodu      varchar2(2000);
  ln_prefix_istatistik_kodu      varchar2(2000);
  ld_havale_tarihi   date;
  ln_gonderen_hesap_no number;
  ln_alici_hesap_no      cbs_subelerarasi_hav_gir_isl.alici_hesap_no%type;
  ls_bolum_kodu          cbs_subelerarasi_hav_gir_isl.bolum_kodu%type;  --sevalb 05042013 31206-Problem with transaction 4310
  ln_gl_commission varchar2(200);
  ln_sender_residency_code cbs_subelerarasi_hav_gir_isl.sender_residency_code%type;
  ln_commission_amount number;
  ln_referans CBS_SUBELERARASI_HAV_GIR_ISL.REFERANS%type;

  begin
     update  cbs_subelerarasi_hav_gir_isl
        set referans =sf_referans_al(pn_islem_no)
        where tx_no=pn_islem_no;  
        
    select masraf_tahsil_sekli,urun_tur,  doviz_kodu, masraf_tahsil_doviz, nvl(tutar,0), nvl(masraf_tutari,0) ,nvl(masraf_tahsildvzli_tutar,0),
    nvl(tax_amount,0) ,nvl(tax_currency_amount,0),
    gonderen_isim_unvan, aciklama, istatistik_kodu, prefix_istatistik_kodu,havale_tarihi, gonderen_hesap_no,alici_hesap_no,
    bolum_kodu, sender_residency_code , referans    --sevalb 05042013 31206-Problem with transaction 4310
    into ls_masraf_tahsil_sekli,ls_urun_tur, ls_doviz_kodu, ls_masraf_tahsil_doviz, ln_tutar, ln_masraf_tutari,ln_masraf_tahsildvzli_tutar,
    ln_tax_amount,ln_tax_currency_amount,
    ls_gonderen_isim_unvan, ls_aciklama, ls_istatistik_kodu, ln_prefix_istatistik_kodu,ld_havale_tarihi, ln_gonderen_hesap_no,ln_alici_hesap_no,
    ls_bolum_kodu, ln_sender_residency_code, ln_referans--sevalb 05042013 31206-Problem with transaction 4310    
    from cbs_subelerarasi_hav_gir_isl
    where tx_no=pn_islem_no;
        
    --B-O-M sevalb 05042013 31206-Problem with transaction 4310   
    if ls_bolum_kodu is null then
        update  cbs_subelerarasi_hav_gir_isl
        set bolum_kodu = pkg_baglam.bolum_kodu
        where tx_no=pn_islem_no;  
    end if;
    --E-O-M sevalb 05042013 31206-Problem with transaction 4310

    if ls_urun_tur='CASH' or ls_masraf_tahsil_sekli='CASH' then

     if ls_masraf_tahsil_doviz is not null then

                 if ls_urun_tur='CASH' and ls_masraf_tahsil_sekli='CASH' and ls_doviz_kodu=ls_masraf_tahsil_doviz then
                         pkg_tx1601.kontrol_sonrasi(pn_islem_no,4300,ln_tutar + ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_doviz_kodu,'Y');
                         ln_commission_amount := ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount;
                 elsif ls_urun_tur='CASH' and ls_masraf_tahsil_sekli='CASH' and ls_doviz_kodu<>ls_masraf_tahsil_doviz then
                         pkg_tx1601.kontrol_sonrasi(pn_islem_no,4300,ln_tutar,ls_doviz_kodu,'Y',ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_masraf_tahsil_doviz,'Y');
                         ln_commission_amount := ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount;
                 elsif ls_urun_tur='ACCOUNT' and ls_masraf_tahsil_sekli='CASH' then
                         pkg_tx1601.kontrol_sonrasi(pn_islem_no,4300,ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_masraf_tahsil_doviz,'Y');
                         ln_commission_amount := ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount;
                  end if;

     else
          pkg_tx1601.kontrol_sonrasi(pn_islem_no,4300,ln_tutar,ls_doviz_kodu,'Y');
     end if;

    end if;

    if ls_urun_tur='CASH' then
        begin
               pkg_cash_slip.cash_slip( pn_tx_no                  => pn_islem_no,
                                        pn_islem_tipi             => 1, --deposit
                                        pd_islem_tarihi           => ld_havale_tarihi,
                                        ps_islem_tipi_doviz_kodu  => ls_doviz_kodu,
                                        pn_islem_tipi_tutari      => ln_tutar,
                                        ps_aciklama               => ls_aciklama,
                                        ps_gl_hesap_no            => '20001400',
                                        ps_musteri_adi            => ls_gonderen_isim_unvan,
                                        pn_prefix_istatistik_kodu => ln_prefix_istatistik_kodu,
                                        ps_istatistik_doviz_kodu  => ls_doviz_kodu,
                                        ps_istatistik_kodu        => ls_istatistik_kodu,
                                        ps_baglam_bolum           => pkg_baglam.bolum_kodu,
                                        pn_musteri_hesap_no       => null,
                                        pn_islem_kod              => 4300,
                                        pn_referans               => ln_referans
                                       );
                                
        exception
               when others then
               pkg_cash_slip.delete_cash_slip( pn_tx_no      => pn_islem_no);
        end;
    end if;

    if ls_masraf_tahsil_sekli='CASH' and ln_commission_amount > 0 then    
         begin       
                if ln_sender_residency_code = 2 then 
                    pkg_parametre.deger('GL_ACCOUNT_FOR_NONRESIDENT',ln_gl_commission);
                else
                    pkg_parametre.deger('GL_ACCOUNT_FOR_RESIDENT',ln_gl_commission);
                end if;     
                             
                 pkg_cash_slip.cash_slip( pn_tx_no                  => pn_islem_no,
                                        pn_islem_tipi             => 1, --commission
                                        pd_islem_tarihi           => ld_havale_tarihi,
                                        ps_islem_tipi_doviz_kodu  => ls_masraf_tahsil_doviz,
                                        pn_islem_tipi_tutari      => ln_commission_amount,
                                        ps_aciklama               => 'Комиссия+НСП за отправку перевода ДемирТрансфер ' || ls_gonderen_isim_unvan,
                                        ps_gl_hesap_no            => ln_gl_commission,
                                        ps_musteri_adi            => ls_gonderen_isim_unvan,
                                        pn_prefix_istatistik_kodu => ln_prefix_istatistik_kodu,
                                        ps_istatistik_doviz_kodu  => ls_masraf_tahsil_doviz,
                                        ps_istatistik_kodu        => ls_istatistik_kodu,
                                        ps_baglam_bolum           => pkg_baglam.bolum_kodu,
                                        pn_musteri_hesap_no       => null,
                                        pn_islem_kod              => 4300,
                                        pn_referans               => ln_referans
                                       );
         exception
               when others then
               pkg_cash_slip.delete_cash_slip( pn_tx_no      => pn_islem_no);    
         end;                                                
    end if;      
               
    if ln_gonderen_hesap_no is not null then
       -- pkg_personel.sp_log_personel_hesap_islem(pn_islem_no,'4300',ln_gonderen_hesap_no);
       null;
    end if;
    
    pkg_black_list.chek_update(pn_islem_no);
  end;
--*************************************************************************************--
  procedure dogrulama_sonrasi(pn_islem_no number) is
  ls_urun_tur varchar2(10);
  ls_masraf_tahsil_sekli varchar2(10);
  ls_doviz_kodu varchar2(3);
  ls_masraf_tahsil_doviz varchar2(3);
  ln_tutar number;
  ln_masraf_tutari number;
  ln_masraf_tahsildvzli_tutar number ;
  ln_tax_amount number;
  ln_tax_currency_amount number ;
  begin

    select masraf_tahsil_sekli,urun_tur,  doviz_kodu, masraf_tahsil_doviz, nvl(tutar,0), nvl(masraf_tutari,0) ,nvl(masraf_tahsildvzli_tutar,0),
    nvl(tax_amount,0) ,nvl(tax_currency_amount,0)
    into ls_masraf_tahsil_sekli,ls_urun_tur, ls_doviz_kodu, ls_masraf_tahsil_doviz, ln_tutar, ln_masraf_tutari, ln_masraf_tahsildvzli_tutar,
    ln_tax_amount,ln_tax_currency_amount
    from cbs_subelerarasi_hav_gir_isl
    where tx_no=pn_islem_no;


    if ls_urun_tur='CASH' or ls_masraf_tahsil_sekli='CASH' then

     if ls_masraf_tahsil_doviz is not null then

                 if ls_urun_tur='CASH' and ls_masraf_tahsil_sekli='CASH' and ls_doviz_kodu=ls_masraf_tahsil_doviz then
                     pkg_tx1601.dogrulama_sonrasi(pn_islem_no,4300,ln_tutar + ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_doviz_kodu,'Y');
                 elsif ls_urun_tur='CASH' and ls_masraf_tahsil_sekli='CASH' and ls_doviz_kodu<>ls_masraf_tahsil_doviz then
                     pkg_tx1601.dogrulama_sonrasi(pn_islem_no,4300,ln_tutar,ls_doviz_kodu,'Y',ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_masraf_tahsil_doviz,'Y');
                 elsif ls_urun_tur='ACCOUNT' and ls_masraf_tahsil_sekli='CASH' then
                     pkg_tx1601.dogrulama_sonrasi(pn_islem_no,4300,ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_masraf_tahsil_doviz,'Y');
                 end if;

     else
          pkg_tx1601.dogrulama_sonrasi(pn_islem_no,4300,ln_tutar,ls_doviz_kodu,'Y');
     end if;

    end if;

  end;
--*************************************************************************************--
  procedure iptal_sonrasi(pn_islem_no number) is
  begin
    null;
  end;
--*************************************************************************************--

  procedure iptal_onay_sonrasi(pn_islem_no number) is
  ls_urun_tur varchar2(10);
  ls_masraf_tahsil_sekli varchar2(10);
  ls_doviz_kodu varchar2(3);
  ls_masraf_tahsil_doviz varchar2(3);
  ln_tutar number;
  ln_masraf_tutari number;

  begin

   raise_application_error(-20100,pkg_hata.getucpointer || '1191' || pkg_hata.getdelimiter || pkg_hata.getucpointer);
    /*update CBS_SUBELERARASI_HAV_GIR
     Set DURUM_KODU = 'IP'
     where REFERANS=(SELECT REFERANS
                      FROM CBS_SUBELERARASI_HAV_GIR_ISL
                      WHERE TX_NO=pn_islem_no);

    update CBS_SUBELERARASI_HAV_GIR_ISL
     Set DURUM_KODU = 'IP'
     where TX_NO=pn_islem_no;

    select URUN_TUR,MASRAF_TAHSIL_SEKLI
    into LS_URUN_TUR,LS_MASRAF_TAHSIL_SEKLI
    from CBS_SUBELERARASI_HAV_GIR_ISL
    where tx_no=pn_islem_no;

    IF LS_URUN_TUR='CASH' OR LS_MASRAF_TAHSIL_SEKLI='CASH' THEN
      PKG_Tx1601.Iptal_Onay_Sonrasi(pn_islem_no,4300);
    END IF;
*/
  end;

--*************************************************************************************--

 procedure onay_sonrasi(pn_islem_no number) is
  ls_urun_tur varchar2(10);
  ls_masraf_tahsil_sekli varchar2(10);
  ls_doviz_kodu varchar2(3);
  ls_masraf_tahsil_doviz varchar2(3);
  ln_tutar number;
  ln_masraf_tutari number;
  ln_masraf_tahsildvzli_tutar number;
  ln_tax_amount number;
  ln_tax_currency_amount number ;
  ls_urun_sinif varchar2(20);
  ls_bolum_kodu 
  cbs_subelerarasi_hav_gir_isl.bolum_kodu%type;  --sevalb 05042013 31206-Problem with transaction 4310
  
  begin
 
    --B-O-M sevalb 05042013 31206-Problem with transaction 4310
    select bolum_kodu
    into  ls_bolum_kodu       
    from cbs_subelerarasi_hav_gir_isl
    where tx_no=pn_islem_no;
       
    if ls_bolum_kodu is null then
        ls_bolum_kodu:=nvl(pkg_tx.amir_bolumkodu_al(pn_islem_no),pkg_baglam.bolum_kodu);
        
        update  cbs_subelerarasi_hav_gir_isl
        set bolum_kodu = pkg_baglam.bolum_kodu
        where tx_no=pn_islem_no;         
    end if;
    --E-O-M sevalb 05042013 31206-Problem with transaction 4310
    
    update cbs_subelerarasi_hav_gir_isl
     set durum_kodu = decode(urun_sinif,'TO ACCOUNT','ODEME','ON') 
          --referans =sf_referans_al(pn_islem_no) --NurmilaZ
     where tx_no=pn_islem_no;

    insert into cbs_subelerarasi_hav_gir ( referans, urun_tur, urun_sinif, alici_sube,
                doviz_kodu, tutar, gonderen_musteri_no, gonderen_hesap_no,
                gonderen_isim_unvan, gonderen_adres, gonderen_tel_no, alici_musteri_no,
                alici_hesap_no, alici_isim_unvan, alici_adres, alici_tel_no, aciklama,
                gonderim_amaci, masraf_tahsil_doviz, masraf_tahsil_sekli, masraf_tutari,
                havale_tarihi, bolum_kodu, durum_kodu,
                istatistik_kodu, prefix_istatistik_kodu, istatistik_kodu_kom,
                prefix_istatistik_kodu_kom, masraf_doviz, masraf_tahsildvzli_tutar,
                tax_amount, tax_currency_amount, total_amount, total_charge_tax_amount,
                sender_tin, sender_document_type, sender_id_cardno, sender_passport,
                sender_driving_license, sender_issue_place, sender_issue_date,
                sender_validity_date, sender_residency_code, sender_citizen_code,
                beneficiary_tin, beneficiary_document_type,beneficiary_id_cardno, beneficiary_passport, --BOM rbo-395 maksatt 12.12.22 add new fields
                beneficiary_driving_license, beneficiary_issue_place, beneficiary_issue_date,
                beneficiary_validity_date, beneficiary_residency_code, beneficiary_citizen_code,
                beneficiary_resident_permit, beneficiary_military_card, beneficiary_middle_name,
                beneficiary_name, beneficiary_surname,
                sender_external_hesapno, beneficiary_external_hesapno, sender_name, sender_surname, sender_middle_name,
                sender_date_of_birth, sender_gender, sender_military_card, sender_resident_permit)--EOM rbo-395 maksatt 12.12.22 add new fields
    (select     referans, urun_tur, urun_sinif, alici_sube,
                doviz_kodu, tutar, gonderen_musteri_no, gonderen_hesap_no,
                gonderen_isim_unvan, gonderen_adres, gonderen_tel_no, alici_musteri_no,
                alici_hesap_no, alici_isim_unvan, alici_adres, alici_tel_no, aciklama,
                gonderim_amaci, masraf_tahsil_doviz, masraf_tahsil_sekli, masraf_tutari,
                havale_tarihi, bolum_kodu, durum_kodu,
                istatistik_kodu, prefix_istatistik_kodu, istatistik_kodu_kom,
                prefix_istatistik_kodu_kom, masraf_doviz, masraf_tahsildvzli_tutar,
                tax_amount, tax_currency_amount,total_amount, total_charge_tax_amount,
                sender_tin, sender_document_type, sender_id_cardno, sender_passport,
                sender_driving_license, sender_issue_place, sender_issue_date,
                sender_validity_date, sender_residency_code, sender_citizen_code,
                beneficiary_tin, beneficiary_document_type,beneficiary_id_cardno, beneficiary_passport, --BOM rbo-395 maksatt 12.12.22 add new fields
                beneficiary_driving_license, beneficiary_issue_place, beneficiary_issue_date,
                beneficiary_validity_date, beneficiary_residency_code, beneficiary_citizen_code,
                beneficiary_resident_permit, beneficiary_military_card, beneficiary_middle_name,
                beneficiary_name, beneficiary_surname,
                sender_external_hesapno, beneficiary_external_hesapno, sender_name, sender_surname, sender_middle_name,
                sender_date_of_birth, sender_gender, sender_military_card, sender_resident_permit--EOM rbo-395 maksatt 12.12.22 add new fields
     from cbs_subelerarasi_hav_gir_isl
     where tx_no=pn_islem_no);

    select masraf_tahsil_sekli,urun_tur,  doviz_kodu, masraf_tahsil_doviz, tutar, masraf_tutari,masraf_tahsildvzli_tutar,
    tax_amount, tax_currency_amount, urun_sinif
    into ls_masraf_tahsil_sekli,ls_urun_tur, ls_doviz_kodu, ls_masraf_tahsil_doviz, ln_tutar, ln_masraf_tutari ,ln_masraf_tahsildvzli_tutar,
    ln_tax_amount,ln_tax_currency_amount, ls_urun_sinif
    from cbs_subelerarasi_hav_gir_isl
    where tx_no=pn_islem_no;

    if ls_urun_tur='CASH' or ls_masraf_tahsil_sekli='CASH' then
       if ls_masraf_tahsil_doviz is not null then

                 if ls_urun_tur='CASH' and ls_masraf_tahsil_sekli='CASH' and ls_doviz_kodu=ls_masraf_tahsil_doviz then
                     pkg_tx1601.onay_sonrasi(pn_islem_no,4300,ln_tutar + ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_doviz_kodu,'Y');
                 elsif ls_urun_tur='CASH' and ls_masraf_tahsil_sekli='CASH' and ls_doviz_kodu<>ls_masraf_tahsil_doviz then
                     pkg_tx1601.onay_sonrasi(pn_islem_no,4300,ln_tutar,ls_doviz_kodu,'Y',ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_masraf_tahsil_doviz,'Y');
                 elsif ls_urun_tur='ACCOUNT' and ls_masraf_tahsil_sekli='CASH' then
                     pkg_tx1601.onay_sonrasi(pn_islem_no,4300,ln_masraf_tahsildvzli_tutar + ln_tax_currency_amount,ls_masraf_tahsil_doviz,'Y');
                 end if;

       else
          pkg_tx1601.onay_sonrasi(pn_islem_no,4300,ln_tutar,ls_doviz_kodu,'Y');
       end if;

    end if;

  /*
  exception
       when others then
               Raise_application_error(-20100,'200' || sqlerrm);
  */
  end;
--*************************************************************************************--

 procedure reddetme_sonrasi(pn_islem_no number) is
 begin
  null;
 end;

--*************************************************************************************--
 procedure tamam_sonrasi(pn_islem_no number) is
 begin
  null;
 end;
--*************************************************************************************--
 procedure basim_sonrasi(pn_islem_no number) is
 begin
  null;
 end;
--*************************************************************************************--
 procedure muhasebelesme(pn_islem_no number) is
    varchar_list pkg_muhasebe.varchar_array;
    number_list pkg_muhasebe.number_array;
    date_list pkg_muhasebe.date_array;
    boolean_list pkg_muhasebe.boolean_array;
    ln_fis_no number :=0 ;
    ls_modul_tur varchar2(10);
    ls_urun_tur varchar2(10);
    ls_urun_sinif varchar2(20);
    ls_urun_tur_isl varchar2(10);
    ls_masraf_tahsil_sekli varchar2(10);
    ls_doviz_kodu varchar2(3);
    ls_masraf_tahsil_doviz varchar2(3);
    ln_tutar number;
    ln_masraf_tutari number;

    ln_dk_grup_kod_gonderen number;
    ln_dk_grup_kod_alici number;
    
    pn_toglres varchar2(200);
    pn_toglnonres varchar2(200);


  cursor cur_subelerarasi_havale_islem is
      select a.*,
           trim(to_char(cash_code)) cashcode,
         istatistik_kodu istatistik_kod
      from cbs_subelerarasi_hav_gir_isl a
      where tx_no = pn_islem_no;
      row_subelerarasi_havale_islem cur_subelerarasi_havale_islem%rowtype;

begin

   open cur_subelerarasi_havale_islem;
   fetch cur_subelerarasi_havale_islem into row_subelerarasi_havale_islem;
   close cur_subelerarasi_havale_islem;

     boolean_list(p_4300_gon_hes_vadeli) := false;
     boolean_list(p_4300_urun_tur_kasadan) := false;
     boolean_list(p_4300_urun_tur_hesaptan) := false;
     boolean_list(p_4300_havale_isme) := false;
     boolean_list(p_4300_havale_hesabami) := false;
     boolean_list(p_4300_lc_havale) := false;
     boolean_list(p_4300_fc_havale) := false;
     boolean_list(p_4300_gon_hes_vadesiz) := false;
     boolean_list(p_4300_masraf_ths_kasadan) := false;
     boolean_list(p_4300_masraf_ths_hesaptan) := false;
     boolean_list(p_4300_msrf_thsl_dvz_lc) := false;
     boolean_list(p_4300_msrf_thsl_dvz_fc) := false;
     varchar_list(p_4300_hesap_sube) := null;
     number_list(p_4300_masraf_tutar_lc) := 0;
     number_list(p_4300_msrf_thsl_dvz_kur) := 0;
     varchar_list(p_4300_cash_code):= null;
     varchar_list(p_4300_alici_hesap) := null;
     boolean_list(p_4300_round_error) := false;

     varchar_list(p_4300_cash_code) := nvl(to_char(row_subelerarasi_havale_islem.cashcode),'1010');
     
     pkg_parametre.deger('GL_ACCOUNT_FOR_RESIDENT',pn_toglres);
     pkg_parametre.deger('GL_ACCOUNT_FOR_NONRESIDENT',pn_toglnonres);

    --pn_yerlesim_kodu  := pkg_musteri.sf_yerlesim_kod_al(ln_musteri_no)  ;

     if row_subelerarasi_havale_islem.sender_residency_code = 2 then 
           varchar_list(p_4300_commission_gl):= to_number(pn_toglnonres);
     else
           varchar_list(p_4300_commission_gl):= to_number(pn_toglres);
     end if;

     if row_subelerarasi_havale_islem.gonderen_hesap_no is not null then
      select dk_grup_kod
       into  ln_dk_grup_kod_gonderen
       from  cbs_musteri
       where musteri_no = pkg_hesap.hesaptanmusterinoal(row_subelerarasi_havale_islem.gonderen_hesap_no);
     end if;

     
      --CBS_SUBELERARASI_HAV_GIR_ISL
     if ln_dk_grup_kod_gonderen=1023 then
         varchar_list(p_4300_istatistik_kod) := pkg_musteri.paymentkod_formatli_al( pkg_hesap.hesaptanmusterinoal(row_subelerarasi_havale_islem.gonderen_hesap_no) ,row_subelerarasi_havale_islem.istatistik_kod) ;
     elsif row_subelerarasi_havale_islem.urun_tur = 'CASH' and row_subelerarasi_havale_islem.doviz_kodu<>pkg_genel.lc_al then

         if row_subelerarasi_havale_islem.urun_sinif ='TO PERSON' then
             varchar_list(p_4300_istatistik_kod) := row_subelerarasi_havale_islem.istatistik_kod||'10';
         elsif  row_subelerarasi_havale_islem.urun_sinif ='TO ACCOUNT' then
             varchar_list(p_4300_istatistik_kod) :=pkg_musteri.paymentkod_formatli_al( pkg_hesap.hesaptanmusterinoal(row_subelerarasi_havale_islem.alici_hesap_no) ,row_subelerarasi_havale_islem.istatistik_kod) ;
         end if;
     end if;




     if row_subelerarasi_havale_islem.alici_hesap_no is not null then
      select dk_grup_kod
       into  ln_dk_grup_kod_alici
       from  cbs_musteri
       where musteri_no = pkg_hesap.hesaptanmusterinoal(row_subelerarasi_havale_islem.alici_hesap_no);
     end if;

     if ln_dk_grup_kod_alici=1023 then
        varchar_list(p_4300_istatistik_kod_2) :=pkg_musteri.paymentkod_formatli_al( pkg_hesap.hesaptanmusterinoal(row_subelerarasi_havale_islem.alici_hesap_no) ,row_subelerarasi_havale_islem.istatistik_kod);
     end if;



     varchar_list(p_4300_referans) :=row_subelerarasi_havale_islem.referans;

     varchar_list(p_4300_islem_sube) := pkg_tx.amir_bolumkodu_al(pn_islem_no);

     if row_subelerarasi_havale_islem.gonderen_hesap_no is not null then
        varchar_list(p_4300_hesap_sube) := pkg_hesap.hesapsubeal(row_subelerarasi_havale_islem.gonderen_hesap_no);
     end if;

     varchar_list(p_4300_alici_sube) := row_subelerarasi_havale_islem.alici_sube;
     varchar_list(p_4300_alici_hesap) := row_subelerarasi_havale_islem.alici_hesap_no;

     number_list(p_4300_tutar_fc) := row_subelerarasi_havale_islem.tutar;
     number_list(p_4300_tutar_lc) := pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_subelerarasi_havale_islem.doviz_kodu,pkg_genel.lc_al,null,row_subelerarasi_havale_islem.tutar,1,null,null,'N','A'));
     varchar_list(p_4300_musteri_hesap_no) := row_subelerarasi_havale_islem.gonderen_hesap_no;
     varchar_list(p_4300_havale_doviz) := row_subelerarasi_havale_islem.doviz_kodu;
     varchar_list(p_4300_aciklama) := row_subelerarasi_havale_islem.aciklama;
     number_list(p_4300_hav_dvz_kur) := pkg_kur.doviz_doviz_karsilik(row_subelerarasi_havale_islem.doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A');


     if row_subelerarasi_havale_islem.gonderen_hesap_no is not null then
        pkg_hesap.urunbilgial(row_subelerarasi_havale_islem.gonderen_hesap_no,ls_modul_tur,ls_urun_tur,ls_urun_sinif);

        if ls_modul_tur=pkg_hesap.modul_tur_vadeli then
           boolean_list(p_4300_gon_hes_vadeli) := true;
        elsif ls_modul_tur=pkg_hesap.modul_tur_vadesiz  then
           boolean_list(p_4300_gon_hes_vadesiz) := true;
        end if;

     end if;

     if row_subelerarasi_havale_islem.urun_tur='CASH' then
        boolean_list(p_4300_urun_tur_kasadan) := true;
     elsif row_subelerarasi_havale_islem.urun_tur='ACCOUNT' then
        boolean_list(p_4300_urun_tur_hesaptan) := true;
     end if;

     if row_subelerarasi_havale_islem.urun_sinif='TO PERSON' then
        boolean_list(p_4300_havale_isme) := true;
     elsif row_subelerarasi_havale_islem.urun_sinif='TO ACCOUNT' then
        boolean_list(p_4300_havale_hesabami) := true;
     end if;


     if row_subelerarasi_havale_islem.doviz_kodu=pkg_genel.lc_al then
        boolean_list(p_4300_lc_havale) := true;
     else
        boolean_list(p_4300_fc_havale) := true;
     end if;

     if row_subelerarasi_havale_islem.masraf_tahsil_sekli ='CASH' then
        boolean_list(p_4300_masraf_ths_kasadan) := true;
      elsif row_subelerarasi_havale_islem.masraf_tahsil_sekli ='ACCOUNT' then
        boolean_list(p_4300_masraf_ths_hesaptan) := true;
     end if;

     if row_subelerarasi_havale_islem.masraf_tahsil_doviz is not null then
     
        varchar_list(p_4300_msrf_thsl_dvz) := row_subelerarasi_havale_islem.masraf_tahsil_doviz;
        
        number_list(p_4300_masraf_tutar_lc) := pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_subelerarasi_havale_islem.masraf_tahsil_doviz,pkg_genel.lc_al,null,row_subelerarasi_havale_islem.clear_comm_amount,1,null,null,'N','A'));
        number_list(p_4300_masraf_tutar_fc) := row_subelerarasi_havale_islem.clear_comm_amount;
        
        number_list(p_4300_tax_lc) := pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_subelerarasi_havale_islem.masraf_tahsil_doviz,pkg_genel.lc_al,null,row_subelerarasi_havale_islem.clear_tax_amount,1,null,null,'N','A'));
        number_list(p_4300_tax_fc) := row_subelerarasi_havale_islem.clear_tax_amount;
        
        number_list(p_4300_msrf_thsl_dvz_kur) := pkg_kur.doviz_doviz_karsilik(row_subelerarasi_havale_islem.masraf_tahsil_doviz,pkg_genel.lc_al,null,1,1,null,null,'N','A');
        number_list(p_4300_bsmv) := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(p_4300_masraf_tutar_lc)*5/100);
        number_list(p_4300_masraf_tutar_fark_bsmv) :=number_list(p_4300_masraf_tutar_lc)-number_list(p_4300_bsmv);
        
       if row_subelerarasi_havale_islem.masraf_tahsil_doviz=pkg_genel.lc_al and row_subelerarasi_havale_islem.masraf_tahsil_sekli ='CASH' then
           number_list(p_4300_charge_tax_lc) := pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_subelerarasi_havale_islem.masraf_tahsil_doviz,pkg_genel.lc_al,null,row_subelerarasi_havale_islem.round_comm_tax_amount,1,null,null,'N','A'));
           number_list(p_4300_charge_tax_fc) := row_subelerarasi_havale_islem.round_comm_tax_amount;
       else
           number_list(p_4300_charge_tax_lc) := pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_subelerarasi_havale_islem.masraf_tahsil_doviz,pkg_genel.lc_al,null,row_subelerarasi_havale_islem.total_charge_tax_amount,1,null,null,'N','A'));
           number_list(p_4300_charge_tax_fc) := row_subelerarasi_havale_islem.total_charge_tax_amount;
       end if;
       
       if (row_subelerarasi_havale_islem.round_error_comm_amount + row_subelerarasi_havale_islem.round_error_tax_amount) > 0 THEN
                number_list(p_4300_round_error_c) := ABS(row_subelerarasi_havale_islem.round_error_comm_amount + row_subelerarasi_havale_islem.round_error_tax_amount);
                number_list(p_4300_round_error_d) := 0;
       elsif (row_subelerarasi_havale_islem.round_error_comm_amount + row_subelerarasi_havale_islem.round_error_tax_amount) < 0 THEN
                number_list(p_4300_round_error_c) := 0;
                number_list(p_4300_round_error_d) := ABS(row_subelerarasi_havale_islem.round_error_comm_amount + row_subelerarasi_havale_islem.round_error_tax_amount);
       else 
                number_list(p_4300_round_error_d) := 0;
                number_list(p_4300_round_error_c) := 0;
       end if;
       
       if number_list(p_4300_round_error_d) <> 0 or number_list(p_4300_round_error_c) <> 0 then
              boolean_list(p_4300_round_error) := true;
       else
              boolean_list(p_4300_round_error) := false;
       end if;
       
       
       if row_subelerarasi_havale_islem.masraf_tahsil_doviz=pkg_genel.lc_al then
          boolean_list(p_4300_msrf_thsl_dvz_lc) := true;
       else
          boolean_list(p_4300_msrf_thsl_dvz_fc) := true;
       end if;
     end if;

    ln_fis_no:=0;

      if pkg_tx6200.sube_outlet_mi(varchar_list(p_4300_islem_sube)) = 'H' then
          pkg_parametre.deger('G_DK_LC_CASH_GL', varchar_list(p_4300_lc_cash_gl));
          pkg_parametre.deger('G_DK_FC_CASH_GL', varchar_list(p_4300_fc_cash_gl));
      else
          pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(p_4300_lc_cash_gl ));
          pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(p_4300_fc_cash_gl ));
      end if;
    --ISLEM MUHASEBELERI..
    if boolean_list(p_4300_lc_havale) = true then
      if boolean_list(p_4300_havale_isme) = true then
         ln_fis_no:=pkg_muhasebe.fis_kes (4300,
                                               4,
                                               pn_islem_no,
                                              varchar_list ,
                                              number_list  ,
                                              date_list    ,
                                              boolean_list ,
                                              null,
                                              false,
                                              ln_fis_no,
                                              'Transfers Between Branches');
      elsif boolean_list(p_4300_havale_hesabami) = true then
         ln_fis_no:=pkg_muhasebe.fis_kes (4300,
                                               17,
                                               pn_islem_no,
                                              varchar_list ,
                                              number_list  ,
                                              date_list    ,
                                              boolean_list ,
                                              null,
                                              false,
                                              ln_fis_no,
                                              'Transfers Between Branches');
      end if;
    elsif boolean_list(p_4300_fc_havale) = true then
      if boolean_list(p_4300_havale_isme) = true then

         ln_fis_no:=pkg_muhasebe.fis_kes (4300,
                                               8,
                                               pn_islem_no,
                                              varchar_list ,
                                              number_list  ,
                                              date_list    ,
                                              boolean_list ,
                                              null,
                                              false,
                                              ln_fis_no,
                                              'Transfers Between Branches');

      elsif boolean_list(p_4300_havale_hesabami) = true then
         ln_fis_no:=pkg_muhasebe.fis_kes (4300,
                                               17,
                                               pn_islem_no,
                                              varchar_list ,
                                              number_list  ,
                                              date_list    ,
                                              boolean_list ,
                                              null,
                                              false,
                                              ln_fis_no,
                                             'Transfers Between Branches');
      end if;
    end if;


    --MASRAF MUHASEBELER?...
    if boolean_list(p_4300_msrf_thsl_dvz_fc) = true and boolean_list(p_4300_masraf_ths_kasadan) = true then
     ln_fis_no:=pkg_muhasebe.fis_kes (4300,
                                           13,
                                           pn_islem_no,
                                          varchar_list ,
                                          number_list  ,
                                          date_list    ,
                                          boolean_list ,
                                          null,
                                          false,
                                          ln_fis_no,
                                          'Transfers Between Branches');
    elsif boolean_list(p_4300_msrf_thsl_dvz_lc) = true then
     ln_fis_no:=pkg_muhasebe.fis_kes (4300,
                                           12,
                                           pn_islem_no,
                                          varchar_list ,
                                          number_list  ,
                                          date_list    ,
                                          boolean_list ,
                                          null,
                                          false,
                                          ln_fis_no,
                                          'Transfers Between Branches');

    elsif boolean_list(p_4300_msrf_thsl_dvz_fc) = true  then

     ln_fis_no:=pkg_muhasebe.fis_kes (4300,
                                           16,
                                           pn_islem_no,
                                          varchar_list ,
                                          number_list  ,
                                          date_list    ,
                                          boolean_list ,
                                          null,
                                          false,
                                          ln_fis_no,
                                          'Transfers Between Branches');

    end if;
    


    pkg_muhasebe.muhasebelestir(ln_fis_no);

    select urun_tur,masraf_tahsil_sekli
    into ls_urun_tur,ls_masraf_tahsil_sekli
    from cbs_subelerarasi_hav_gir_isl
    where tx_no=pn_islem_no;

    if ls_urun_tur_isl='CASH' or ls_masraf_tahsil_sekli='CASH' then
     pkg_tx1601.muhasebelesme(pn_islem_no,4300);
    end if;
    
    
exception
   when others then
        log_at('MUHPL4300_1', pn_islem_no, sqlerrm, dbms_utility.format_error_backtrace);
        raise_application_error(-20100,pkg_hata.getucpointer || '4536'  || pkg_hata.getdelimiter ||substr(to_char(sqlcode)||' '||sqlerrm,1,2000) || pkg_hata.getdelimiter || pkg_hata.getucpointer);
end;
--****************************************************************************
procedure dogrulama_iptal_sonrasi(pn_islem_no number) is
begin
      null;
end;
--****************************************************************************
procedure iptal_muhasebelestir_sonrasi(pn_islem_no number) is
  ls_urun_tur varchar2(10);
  ls_masraf_tahsil_sekli varchar2(10);
  ls_doviz_kodu varchar2(3);
  ls_masraf_tahsil_doviz varchar2(3);
  ln_tutar number;
  ln_masraf_tutari number;

  begin

   select urun_tur,masraf_tahsil_sekli
    into ls_urun_tur,ls_masraf_tahsil_sekli
    from cbs_subelerarasi_hav_gir_isl
    where tx_no=pn_islem_no;

    if ls_urun_tur='CASH' or ls_masraf_tahsil_sekli='CASH' then
     pkg_tx1601.iptal_muhasebelestir_sonrasi(pn_islem_no,4300);
    end if;

  end;
--****************************************************************************
procedure iptal_reddetme_sonrasi(pn_islem_no number) is
begin
      null;
end;
--****************************************************************************

function sf_rg_gonderenhesapurunuygunmu( ps_urun_tur_kod cbs_hesap.urun_tur_kod%type ) return varchar2
is
  ls_uygun  varchar2(1) := 'H';
  begin
        if  ps_urun_tur_kod in ('CURRENT','DEMAND DEP')  then
             ls_uygun := 'E';
        else
            ls_uygun := 'H';
        end if;

        return ls_uygun;
    exception
      when others then return 'H';
  end ;
--********************************************************************************

function sf_rg_vadeligonhesurunuygunmu( ps_urun_tur_kod cbs_hesap_vadeli.urun_tur_kod%type ) return varchar2
is
  ls_uygun  varchar2(1) := 'H';
  begin
             ls_uygun := 'E';

        return ls_uygun;
    exception
      when others then return 'H';
  end ;
--********************************************************************************

function sf_rg_alicihesapurunuygunmu( ps_urun_tur_kod cbs_hesap.urun_tur_kod%type ) return varchar2
is
  ls_uygun  varchar2(1) := 'H';
  begin
        if  ps_urun_tur_kod in ('CURRENT','DEMAND DEP')   then
             ls_uygun := 'E';
        else
            ls_uygun := 'H';
        end if;

        return ls_uygun;
    exception
      when others then return 'H';
  end ;
--********************************************************************************
function sf_referans_al(pn_islem_no number) return varchar2
  is
  ls_referans varchar2(16);
  ls_yil varchar2(2);
  ls_sube_kodu varchar2(3);
  ls_islem_kodu varchar2(3);
  ls_islem_sira_no varchar2(5);

begin
        ls_yil:=to_char(pkg_muhasebe.banka_tarihi_bul,'YY');
        ls_islem_kodu:='BRT';
        ls_sube_kodu:=substr(rtrim(ltrim(nvl(pkg_tx.amir_bolumkodu_al(pn_islem_no),pkg_baglam.bolum_kodu))),1,3);
        ls_islem_sira_no:=pkg_genel.genel_kod_al('SBARASIHAV'||ls_yil||ls_islem_kodu||ls_sube_kodu);
        ls_islem_sira_no:=lpad(ls_islem_sira_no,5,'0');
        ls_referans:=ls_yil||'.'||ls_sube_kodu||'.'||ls_islem_kodu||'.'||ls_islem_sira_no;

        return ls_referans;

end;

--***************************
function sf_istatistikkod_zorunlumu(pn_gonderen_hesap_no number, pn_alici_hesap_no number, ps_product_type varchar2, ps_doviz_kodu varchar2 ) return varchar2
is
   ln_dk_grup_kod_gonderen        number;
   ln_dk_grup_kod_alici        number;
begin
      if pn_gonderen_hesap_no is not null then
        select dk_grup_kod
        into  ln_dk_grup_kod_gonderen
           from  cbs_musteri
            where musteri_no = pkg_hesap.hesaptanmusterinoal(pn_gonderen_hesap_no);
      end if;

      if pn_alici_hesap_no is not null then
        select dk_grup_kod
          into  ln_dk_grup_kod_alici
             from  cbs_musteri
        where musteri_no = pkg_hesap.hesaptanmusterinoal(pn_alici_hesap_no);
      end if;

      if (ps_product_type='CASH' and ps_doviz_kodu <> pkg_genel.lc_al ) or  ( ln_dk_grup_kod_gonderen = 1023 ) or ( ln_dk_grup_kod_alici=1023 ) then
             return 'E';
      else
             return 'H';
      end if;

exception
        when others then return 'H';
end;
procedure get_transfer_limit(ps_sender_tin cbs_subelerarasi_hav_gir.sender_tin%type, 
                              ps_sender_passport cbs_subelerarasi_hav_gir.sender_passport%type,
                              ps_sender_customer_no cbs_subelerarasi_hav_gir.gonderen_musteri_no%type, 
                              ps_amount cbs_subelerarasi_hav_gir.tutar%type, 
                              ps_currency cbs_subelerarasi_hav_gir.doviz_kodu%type) is
   ln_limit varchar2(200 byte);
   ln_sum_amount number := 0;
   ln_amount number := 0;
   ln_final_amount number := 0;
     
   limit_error exception;
   
   cursor cur_sum is
   select nvl(sum(pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(a.doviz_kodu,pkg_genel.lc_al,null,a.tutar,1,null,null,'N','A'))),0) as sum_amount
                            from cbs_subelerarasi_hav_gir a where durum_kodu in ('ON', 'IT', 'IADE', 'ODEME') and havale_tarihi=pkg_muhasebe.banka_tarihi_bul
                            and (a.sender_tin=ps_sender_tin or a.sender_passport=ps_sender_passport or a.gonderen_musteri_no=ps_sender_customer_no);
  
 row_cur_sum cur_sum%rowtype;
begin

   pkg_parametre.deger('DEMIRTRANSFER_LIMIT_PARAMETRE', ln_limit);

    for row_cur_sum in cur_sum loop 
     ln_sum_amount := row_cur_sum.sum_amount;
    end loop;
                             
   ln_amount := pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(ps_currency,pkg_genel.lc_al,null,ps_amount,1,null,null,'N','A'));

   ln_final_amount := ln_amount + ln_sum_amount;

   if ln_final_amount > to_number(ln_limit) then
     raise limit_error;
   end if;
   
exception
     when limit_error then
        raise_application_error(-20100,pkg_hata.getucpointer||'3103'|| pkg_hata.getdelimiter ||sqlerrm||pkg_hata.getucpointer);
     when others then
        log_at('get_transfer_limit', ps_sender_tin, sqlerrm, dbms_utility.format_error_backtrace);
end;
procedure get_tax_amount(ps_comm_amount number, 
                            ps_tax_amount out number)
is
ln_service_tax_rate number;
begin
    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);  
    ps_tax_amount := pkg_kur.yuvarla(pkg_genel.lc_al, ps_comm_amount * (ln_service_tax_rate / 100)); 
exception 
    when others then
        log_at('4300_get_tax_amount', ps_comm_amount);
end;

procedure get_customer_information(ps_sender_tin in cbs_subelerarasi_hav_gir.sender_tin%type, 
                               ps_gonderen_musteri_no out cbs_subelerarasi_hav_gir.gonderen_musteri_no%type,
                               ps_gonderen_hesap_no out cbs_subelerarasi_hav_gir.gonderen_hesap_no%type,
                               ps_gonderen_isim_unvan out cbs_subelerarasi_hav_gir.gonderen_isim_unvan%type,
                               ps_gonderen_adres out cbs_subelerarasi_hav_gir.gonderen_adres%type,
                               ps_gonderen_tel_no out cbs_subelerarasi_hav_gir.gonderen_tel_no%type,
                               ps_alici_musteri_no out cbs_subelerarasi_hav_gir.alici_musteri_no%type,
                               ps_alici_hesap_no out cbs_subelerarasi_hav_gir.alici_hesap_no%type,
                               ps_alici_isim_unvan out cbs_subelerarasi_hav_gir.alici_isim_unvan%type,
                               ps_alici_adres out cbs_subelerarasi_hav_gir.alici_adres%type,
                               ps_alici_tel_no out cbs_subelerarasi_hav_gir.alici_tel_no%type,
                               ps_sender_document_type out cbs_subelerarasi_hav_gir.sender_document_type%type, 
                               ps_sender_id_cardno out cbs_subelerarasi_hav_gir.sender_id_cardno%type, 
                               ps_sender_passport out cbs_subelerarasi_hav_gir.sender_passport%type,
                               ps_sender_driving_license out cbs_subelerarasi_hav_gir.sender_driving_license%type, 
                               ps_sender_resident_permit out cbs_subelerarasi_hav_gir.sender_resident_permit%type,  --BOM maksatt 13.10.2022 rbo-395
                               ps_sender_military_card out cbs_subelerarasi_hav_gir.sender_military_card%type, 
                               ps_sender_name out cbs_subelerarasi_hav_gir.sender_name%type,
                               ps_sender_middle_name out cbs_subelerarasi_hav_gir.sender_middle_name%type,
                               ps_sender_surname out cbs_subelerarasi_hav_gir.sender_surname%type,--EOM maksatt 13.10.22 rbo-395
                               ps_sender_issue_place out cbs_subelerarasi_hav_gir.sender_issue_place%type, 
                               ps_sender_issue_date out cbs_subelerarasi_hav_gir.sender_issue_date%type,
                               ps_sender_validity_date out cbs_subelerarasi_hav_gir.sender_validity_date%type, 
                               ps_beneficiary_tin out cbs_subelerarasi_hav_gir.beneficiary_tin%type, 
                               ps_beneficiary_document_type out cbs_subelerarasi_hav_gir.beneficiary_document_type%type,
                               ps_beneficiary_id_cardno out cbs_subelerarasi_hav_gir.beneficiary_id_cardno%type, 
                               ps_beneficiary_passport out cbs_subelerarasi_hav_gir.beneficiary_passport%type, 
                               ps_beneficiary_driving_license out cbs_subelerarasi_hav_gir.beneficiary_driving_license%type, 
                               ps_beneficiary_resident_permit out cbs_subelerarasi_hav_gir.beneficiary_resident_permit%type, --BOM maksatt 13.10.2022 rbo-395
                               ps_beneficiary_military_card out cbs_subelerarasi_hav_gir.beneficiary_military_card%type, 
                               ps_beneficiary_name out cbs_subelerarasi_hav_gir.beneficiary_name%type,
                               ps_beneficiary_middle_name out cbs_subelerarasi_hav_gir.beneficiary_middle_name%type,
                               ps_beneficiary_surname out cbs_subelerarasi_hav_gir.beneficiary_surname%type,--EOM maksatt 13.10.22 rbo-395
                               ps_beneficiary_issue_place out cbs_subelerarasi_hav_gir.beneficiary_issue_place%type, 
                               ps_beneficiary_issue_date out cbs_subelerarasi_hav_gir.beneficiary_issue_date%type,
                               ps_beneficiary_validity_date out cbs_subelerarasi_hav_gir.beneficiary_validity_date%type, 
                               ps_beneficiary_residency_code out cbs_subelerarasi_hav_gir.beneficiary_residency_code%type, 
                               ps_beneficiary_citizen_code out cbs_subelerarasi_hav_gir.beneficiary_citizen_code%type)
is
ln_count number;
begin

  select count(*)
              into
              ln_count
               from cbs_subelerarasi_hav_gir
                    where sender_tin=ps_sender_tin;
       
 if ln_count>0 then
  select  gonderen_musteri_no, 
            gonderen_hesap_no, 
            gonderen_isim_unvan, 
            gonderen_adres, 
            gonderen_tel_no, 
            alici_musteri_no, 
            alici_hesap_no, 
            alici_isim_unvan, 
            alici_adres, 
            alici_tel_no, 
            sender_document_type, 
            sender_id_cardno, 
            sender_passport,
            sender_driving_license,
            sender_resident_permit,--BOM maksatt 13.10.22 rbo-395
            sender_military_card,
            sender_name,
            sender_middle_name,
            sender_surname,--EOM maksatt 13.10.22 rbo-395
            sender_issue_place, 
            sender_issue_date,
            sender_validity_date, 
            beneficiary_tin, 
            beneficiary_document_type,
            beneficiary_id_cardno, 
            beneficiary_passport, 
            beneficiary_driving_license,
            beneficiary_resident_permit,--BOM maksatt 13.10.22 rbo-395
            beneficiary_military_card,
            beneficiary_name,
            beneficiary_middle_name,
            beneficiary_surname, --EOM maksatt 13.10.22 rbo-395
            beneficiary_issue_place, 
            beneficiary_issue_date,
            beneficiary_validity_date, 
            beneficiary_residency_code, 
            beneficiary_citizen_code
     into  
             ps_gonderen_musteri_no, 
             ps_gonderen_hesap_no, 
             ps_gonderen_isim_unvan, 
             ps_gonderen_adres, 
             ps_gonderen_tel_no, 
             ps_alici_musteri_no, 
             ps_alici_hesap_no, 
             ps_alici_isim_unvan, 
             ps_alici_adres, 
             ps_alici_tel_no,  
             ps_sender_document_type, 
             ps_sender_id_cardno, 
             ps_sender_passport,
             ps_sender_driving_license,
             ps_sender_resident_permit,--BOM maksatt 13.10.22 rbo-395
             ps_sender_military_card,--EOM maksatt 13.10.22 rbo-395
             ps_sender_issue_place, 
             ps_sender_issue_date,
             ps_sender_validity_date, 
             ps_beneficiary_tin, 
             ps_beneficiary_document_type,
             ps_beneficiary_id_cardno, 
             ps_beneficiary_passport, 
             ps_beneficiary_driving_license,
             ps_beneficiary_resident_permit,--BOM maksatt 13.10.22 rbo-395
             ps_beneficiary_military_card,
             ps_beneficiary_name,
             ps_beneficiary_middle_name,
             ps_beneficiary_surname,
             ps_sender_name,
             ps_sender_middle_name,
             ps_sender_surname,--EOM maksatt 13.10.22 rbo-395
             ps_beneficiary_issue_place, 
             ps_beneficiary_issue_date,
             ps_beneficiary_validity_date, 
             ps_beneficiary_residency_code, 
             ps_beneficiary_citizen_code
      from cbs_subelerarasi_hav_gir 
       where sender_tin=ps_sender_tin
       order by referans desc fetch first 1 rows only;
 else
   select a.musteri_no Customer_no,
          substr (
             decode (
                musteri_tipi_kod,
                '1',    isim
                     || decode (' ' || ikinci_isim || ' ',
                                '  ', ' ',
                                ' ' || ikinci_isim || ' ')
                     || soyadi,
                '2',    isim
                     || decode (' ' || ikinci_isim || ' ',
                                '  ', ' ',
                                ' ' || ikinci_isim || ' ')
                     || soyadi,
                ticari_unvan),
             1,
             200)
             Title,
          upper (
                trim (b.adres)
             || ' '
             || trim (b.semt)
             || ' '
             || b.ilce_kod
             || ' '
             || b.posta_kod
             || ' '
             || b.ulke_kod)
             address,
       b.tel_alan_kod || ' ' || b.tel_no Telefon,
       a.nufus_cuzdani_seri_no IdNo, 
       a.verildigi_yer IssuePlace, 
       a.verildigi_tarih IssueDate,
       a.gecerlilik_tarihi ValidityDate
   into
             ps_gonderen_musteri_no, 
             ps_gonderen_isim_unvan, 
             ps_gonderen_adres, 
             ps_gonderen_tel_no,
             ps_sender_id_cardno,  
             ps_sender_issue_place, 
             ps_sender_issue_date,
             ps_sender_validity_date
   from cbs_musteri a, cbs_musteri_adres b
              where  a.musteri_no = b.musteri_no
               and durum_kodu in ('A', 'G')
               and a.extre_adres_kod = b.adres_kod
               and a.musteri_tipi_kod<>'4'
               and a.vergi_no=ps_sender_tin
               order by a.musteri_no desc fetch first 1 rows only;
 end if;

exception
      when others then
        null;
end;      
--BOM maksatt 13.10.22 rbo-395
PROCEDURE GET_CUSTOMER_BY_PASSPORT(
                                   ps_sender_id_cardno in cbs_subelerarasi_hav_gir.sender_id_cardno%type, 
                                   ps_sender_passport in cbs_subelerarasi_hav_gir.sender_passport%type,
                                   ps_sender_driving_license in cbs_subelerarasi_hav_gir.sender_driving_license%type, 
                                   ps_sender_resident_permit in cbs_subelerarasi_hav_gir.sender_resident_permit%type,
                                   ps_sender_military_card in cbs_subelerarasi_hav_gir.sender_military_card%type,
                                   ps_sender_issue_place out cbs_subelerarasi_hav_gir.sender_issue_place%type, 
                                   ps_sender_issue_date out cbs_subelerarasi_hav_gir.sender_issue_date%type,
                                   ps_sender_validity_date out cbs_subelerarasi_hav_gir.sender_validity_date%type,
                                   ps_sender_name out cbs_subelerarasi_hav_gir.sender_name%type,
                                   ps_sender_middle_name out cbs_subelerarasi_hav_gir.sender_middle_name%type,
                                   ps_sender_surname out cbs_subelerarasi_hav_gir.sender_surname%type,
                                   ps_sender_customer_no out cbs_subelerarasi_hav_gir.GONDEREN_MUSTERI_NO%type,
                                   ps_sender_gender out cbs_subelerarasi_hav_gir.sender_gender%type,
                                   ps_sender_date_of_birth out cbs_subelerarasi_hav_gir.sender_date_of_birth%type,
                                   ps_sender_tin out cbs_subelerarasi_hav_gir.sender_tin%type)
    is
begin
    select a.isim, a.IKINCI_ISIM, a.SOYADI, a.GECERLILIK_TARIHI, a.DOGUM_TARIHI,
        a.CINSIYET_KOD, a.MUSTERI_NO, a.vergi_no, a.verildigi_tarih, a.verildigi_yer
    into
           ps_sender_name, ps_sender_middle_name, ps_sender_surname ,ps_sender_validity_date, ps_sender_date_of_birth,
           ps_sender_gender,ps_sender_customer_no, ps_sender_tin, ps_sender_issue_date, ps_sender_issue_place
	from cbs_musteri a
		where a.EHLIYET_BELGE_NO = case when ps_sender_driving_license is not null then ps_sender_driving_license end
		 or a.NUFUS_CUZDANI_SERI_NO= case when ps_sender_id_cardno is not null then ps_sender_id_cardno end
		 or a.RESIDENCE_PERMIT=case when ps_sender_resident_permit is not null then ps_sender_resident_permit end
		 or a.PASAPORT_NO=case when ps_sender_passport is not null then ps_sender_passport end
		 or a.MILITARY_CARD=case when ps_sender_military_card is not null then ps_sender_military_card end
		 order by a.musteri_no desc fetch first 1 rows only;
    exception when no_data_found then
        null;
end; --EOM maksatt 13.10.22 rbo-395

--BOM maksatt 13.10.22 rbo-395
PROCEDURE GET_BEN_CUSTOMER_BY_PASSPORT(
                                   ps_id_cardno in varchar2,
                                   ps_passport in varchar2,
                                   ps_driving_license in varchar2,
                                   ps_resident_permit in varchar2,
                                   ps_military_card in varchar2,
                                   ps_issue_place out varchar2,
                                   ps_issue_date out date,
                                   ps_validity_date out date,
                                   ps_name out varchar2,
                                   ps_middle_name out varchar2,
                                   ps_surname out varchar2,
                                   ps_customer_no out number,
                                   ps_gender out varchar2,
                                   ps_date_of_birth out date,
                                   ps_tin out varchar2,
                                   ps_address out varchar2)
    is
begin
    select a.isim, a.IKINCI_ISIM, a.SOYADI, a.GECERLILIK_TARIHI, a.DOGUM_TARIHI,
        a.CINSIYET_KOD, a.MUSTERI_NO, a.vergi_no, a.verildigi_tarih, a.verildigi_yer,
        upper (
                trim (b.adres)
             || ' '
             || trim (b.semt)
             || ' '
             || b.ilce_kod
             || ' '
             || b.posta_kod
             || ' '
             || b.ulke_kod) address
    into
           ps_name, ps_middle_name, ps_surname ,ps_validity_date, ps_date_of_birth,
           ps_gender,ps_customer_no, ps_tin, ps_issue_date, ps_issue_place,ps_address
	from cbs_musteri a inner join cbs_musteri_adres b on a.MUSTERI_NO = b.MUSTERI_NO
		where 
		 a.extre_adres_kod = b.adres_kod and
		 REPLACE(a.EHLIYET_BELGE_NO, ' ', '') = REPLACE(ps_driving_license , ' ', '')
		 or REPLACE(a.NUFUS_CUZDANI_SERI_NO, ' ', '')=REPLACE(ps_id_cardno, ' ', '')
		 or REPLACE(a.RESIDENCE_PERMIT, ' ', '')=REPLACE(ps_resident_permit , ' ', '')
		 or REPLACE(a.PASAPORT_NO, ' ', '')=REPLACE(ps_passport, ' ', '')
		 or REPLACE(a.MILITARY_CARD, ' ', '')=REPLACE(ps_military_card, ' ', '')
		 order by a.musteri_no desc fetch first 1 rows only;
    exception when no_data_found then
        null;
end;--EOM maksatt 13.10.22 rbo-395

--BOM maksatt 13.10.22 rbo-395
PROCEDURE GET_CUSTOMER_INFO_BY_TIN(
                                   ps_tin in varchar2,
                                   ps_document_type out varchar2,
                                   ps_id_cardno out varchar2,
                                   ps_passport out varchar2,
                                   ps_driving_license out varchar2,
                                   ps_resident_permit out varchar2,
                                   ps_military_card out varchar2,
                                   ps_issue_place out varchar2,
                                   ps_issue_date out date,
                                   ps_validity_date out date,
                                   ps_name out varchar2,
                                   ps_middle_name out varchar2,
                                   ps_surname out varchar2,
                                   ps_customer_no out number,
                                   ps_gender out varchar2,
                                   ps_date_of_birth out date,
                                   ps_title_name out varchar2,
                                   ps_address out varchar2)
    is
begin
    
    select a.isim, a.IKINCI_ISIM, a.SOYADI, a.GECERLILIK_TARIHI, a.DOGUM_TARIHI,
        a.CINSIYET_KOD, a.MUSTERI_NO, a.verildigi_tarih, a.verildigi_yer,
        a.NUFUS_CUZDANI_SERI_NO, a.RESIDENCE_PERMIT, a.EHLIYET_BELGE_NO, a.PASAPORT_NO,
        a.MILITARY_CARD,
        upper (
                trim (b.adres)
             || ' '
             || trim (b.semt)
             || ' '
             || b.ilce_kod
             || ' '
             || b.posta_kod
             || ' '
             || b.ulke_kod) address
    into
           ps_name, ps_middle_name, ps_surname ,ps_validity_date, ps_date_of_birth,
           ps_gender,ps_customer_no, ps_issue_date, ps_issue_place,
           ps_id_cardno, ps_resident_permit, ps_driving_license, ps_passport,
           ps_military_card, ps_address
	from cbs_musteri a, cbs_musteri_adres b
		where a.vergi_no = to_char(ps_tin) and a.musteri_no = b.musteri_no
		 order by a.musteri_no desc fetch first 1 rows only;
    if ps_name is not null then
		ps_title_name := SUBSTR(ps_surname || ' ' 
		|| ps_name || ' ' || ps_middle_name, 1);
	end if;
     
    case when ps_id_cardno is not null then ps_document_type:='1';
         when ps_resident_permit is not null then ps_document_type:='2';
         when ps_driving_license is not null then ps_document_type:='3';
         when ps_passport is not null then ps_document_type:='4';
         when ps_military_card is not null then ps_document_type:='5';
         else null;
    end case;
    exception when no_data_found then
        null;
end;--EOM maksatt 13.10.22 rbo-395
                           
begin
p_4300_gon_hes_vadeli := pkg_muhasebe.parametre_index_bul('4300_GON_HES_VADELI');
p_4300_islem_sube := pkg_muhasebe.parametre_index_bul('4300_ISLEM_SUBE');
p_4300_hesap_sube := pkg_muhasebe.parametre_index_bul('4300_HESAP_SUBE');
p_4300_alici_sube := pkg_muhasebe.parametre_index_bul('4300_ALICI_SUBE');
p_4300_tutar_fc := pkg_muhasebe.parametre_index_bul('4300_TUTAR_FC');
p_4300_tutar_lc := pkg_muhasebe.parametre_index_bul('4300_TUTAR_LC');
p_4300_musteri_hesap_no := pkg_muhasebe.parametre_index_bul('4300_MUSTERI_HESAP_NO');
p_4300_urun_tur_kasadan := pkg_muhasebe.parametre_index_bul('4300_URUN_TUR_KASADAN');
p_4300_urun_tur_hesaptan := pkg_muhasebe.parametre_index_bul('4300_URUN_TUR_HESAPTAN');
p_4300_havale_doviz := pkg_muhasebe.parametre_index_bul('4300_HAVALE_DOVIZ');
p_4300_lc_havale := pkg_muhasebe.parametre_index_bul('4300_LC_HAVALE');
p_4300_fc_havale := pkg_muhasebe.parametre_index_bul('4300_FC_HAVALE');
p_4300_masraf_tutar_lc := pkg_muhasebe.parametre_index_bul('4300_MASRAF_TUTAR_LC');
p_4300_masraf_tutar_fc := pkg_muhasebe.parametre_index_bul('4300_MASRAF_TUTAR_FC');
p_4300_bsmv := pkg_muhasebe.parametre_index_bul('4300_BSMV');
p_4300_masraf_tutar_fark_bsmv := pkg_muhasebe.parametre_index_bul('4300_MASRAF_TUTAR_FARK_BSMV');
p_4300_aciklama := pkg_muhasebe.parametre_index_bul('4300_ACIKLAMA');
p_4300_gon_hes_vadesiz := pkg_muhasebe.parametre_index_bul('4300_GON_HES_VADESIZ');
p_4300_hav_dvz_kur := pkg_muhasebe.parametre_index_bul('4300_HAV_DVZ_KUR');
p_4300_masraf_ths_kasadan := pkg_muhasebe.parametre_index_bul('4300_MASRAF_THS_KASADAN');
p_4300_masraf_ths_hesaptan := pkg_muhasebe.parametre_index_bul('4300_MASRAF_THS_HESAPTAN');
p_4300_msrf_thsl_dvz_lc := pkg_muhasebe.parametre_index_bul('4300_MSRF_THSL_DVZ_LC');
p_4300_msrf_thsl_dvz_fc := pkg_muhasebe.parametre_index_bul('4300_MSRF_THSL_DVZ_FC');
p_4300_msrf_thsl_dvz := pkg_muhasebe.parametre_index_bul('4300_MSRF_THSL_DVZ');
p_4300_msrf_thsl_dvz_kur := pkg_muhasebe.parametre_index_bul('4300_MSRF_THSL_DVZ_KUR');
p_4300_cash_code :=pkg_muhasebe.parametre_index_bul('4300_CASH_CODE');
p_4300_istatistik_kod :=pkg_muhasebe.parametre_index_bul('4300_ISTATISTIK_KOD');
p_4300_istatistik_kod_2 :=pkg_muhasebe.parametre_index_bul('4300_ISTATISTIK_KOD_2');
p_4300_referans:=pkg_muhasebe.parametre_index_bul('4300_REFERANS');
p_4300_havale_isme :=pkg_muhasebe.parametre_index_bul('4300_HAVALE_ISME');
p_4300_havale_hesabami:=pkg_muhasebe.parametre_index_bul('4300_HAVALE_HESABAMI');
p_4300_alici_hesap := pkg_muhasebe.parametre_index_bul('4300_ALICI_HESAP');
--Yerzhant
p_4300_lc_cash_gl := pkg_muhasebe.parametre_index_bul('4300_LC_CASH_GL');
p_4300_fc_cash_gl := pkg_muhasebe.parametre_index_bul('4300_FC_CASH_GL');

p_4300_commission_gl := pkg_muhasebe.parametre_index_bul('4300_COMMISSION_GL');
p_4300_tax_lc := pkg_muhasebe.parametre_index_bul('4300_TAX_LC');
p_4300_tax_fc := pkg_muhasebe.parametre_index_bul('4300_TAX_FC');
p_4300_charge_tax_lc := pkg_muhasebe.parametre_index_bul('4300_CHARGE_TAX_LC');
p_4300_charge_tax_fc := pkg_muhasebe.parametre_index_bul('4300_CHARGE_TAX_FC');
p_4300_round_error_d := pkg_muhasebe.parametre_index_bul('4300_ROUND_ERROR_D');
p_4300_round_error_c := pkg_muhasebe.parametre_index_bul('4300_ROUND_ERROR_C');
p_4300_round_error := pkg_muhasebe.parametre_index_bul('4300_ROUND_ERROR');
end;
/

