create PACKAGE PKG_TX3262 IS

/******************************************************************************
   Name       : PKG_TX3262
   Created By : Seval Balci
   Date    	  : 01.04.04
   Purpose	  : Leasing Kredi Tahsilat
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		  -- Islem dogrulandiktan sonra cagrilir
  Procedure	Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			  -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		  -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  Procedure sp_onayoncesi_kurtutarguncelle(pn_islem_no number);
  procedure sp_muhasebesonrasi_guncelle(pn_islem_no number);
  procedure sp_hesap_taksit_kontrol(pn_islem_no number);
  procedure sp_hesap_iptaloncetaksitkntr(pn_islem_no number);
  Function sf_hesap_taksit_durum(
  								  pn_hesap_no number,
  								  pn_taksit_no in  number,
  		   						  ps_kucuk_buyuk varchar2 ) return number;

 Function sf_min_acik_taksit_no_al(pn_islem_no number) return number;
 Function sf_iptal_edilebilirmi(pn_islem_no number ,pn_hesap_no number) return number;

 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block	varchar2,ps_rowid   varchar2,
  							   ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2);
 procedure sp_kontrol_sonrasi_rezervasyon(pn_islem_no number );
 Function sf_maxtaksitno_al(pn_islem_no number) return number;
 Function sf_kapama_islemi(pn_islem_no number) return varchar2;
END;


/

