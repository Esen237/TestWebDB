create PACKAGE PKG_KOMISYON_KUR IS

  FUNCTION KOM_DOVIZ_DOVIZ_KARSILIK( p_doviz_kod_1 varchar2,
                                     p_doviz_kod_2 varchar2,
                                     p_tarih date default null,
                                     p_tutar number,
	                                 p_kur_deger_1 number default null,
	                                 p_kur_deger_2 number default null
	                                ) RETURN NUMBER;

  -- Returns the eqivalent of p_tutar in p_doviz_kod_2.
  -- The original currency of p_tutar is p_doviz_kod_1.
  -- p_doviz_kod_1 : Source Currency
  -- p_doviz_kod_2 : Destination Currency


  FUNCTION KOM_DOVIZ_DOVIZ_KARSILIK( p_doviz_kod_1    varchar2,
	                                 p_doviz_kod_2    varchar2,
	                                 p_tarih          date default null,
	                                 p_tutar          number,
	                                 p_kur_deger_1    number default null,
	                                 p_kur_deger_2    number default null,
	                                 p_karsilik_tutar out number ) return number;
  Function KUR_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;

END;


/

