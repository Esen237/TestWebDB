create PACKAGE pkg_tim IS
  Procedure Muhasebelesme(pn_islem_no number);			-- Islemin muhasebelesmesi icin cagrilir
END;

/

