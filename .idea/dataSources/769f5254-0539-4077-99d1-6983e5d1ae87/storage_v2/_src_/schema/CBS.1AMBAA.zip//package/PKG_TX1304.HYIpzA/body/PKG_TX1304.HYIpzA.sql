create PACKAGE BODY     Pkg_Tx1304 IS
    pn_1304_reeskont_dk    NUMBER;
    pn_1304_faiz_dk    NUMBER;
    pn_1304_bolum_kodu    NUMBER;
    pn_1304_deduction_lc    NUMBER;
    pn_1304_decrease_last_month_lc    NUMBER;
    pn_1304_deduction_fc    NUMBER;
    pn_1304_decrease_last_month_fc    NUMBER;
    pn_1304_banka_aciklama    NUMBER;
    pn_1304_musteri_aciklama    NUMBER;
    pn_1304_doviz_kodu    NUMBER;
    pn_1304_mb_kur    NUMBER;
    pn_1304_kredi_hesap    NUMBER;
    pn_1304_birikmis_faiz_lc    NUMBER;
    pn_1304_birikmis_faiz_fc    NUMBER;
    pn_1304_accrued_int_tax_lc    NUMBER;
    pn_1304_accrued_int_tax_fc    NUMBER;
    pn_1304_accrued_delayed_int_lc    NUMBER;
    pn_1304_accrued_delayed_int_fc    NUMBER;
    pn_1304_penalty_amount_lc    NUMBER;
    pn_1304_penalty_amount_fc    NUMBER;
    pn_1304_nonaccrued_delayed_int_lc    NUMBER;
    pn_1304_nonaccrued_delayed_int_fc    NUMBER;
    pn_1304_accrued_int_lc    NUMBER;
    pn_1304_accrued_int_fc    NUMBER;
    pn_1304_nonaccrued_int_lc    NUMBER;
    pn_1304_nonaccrued_int_fc    NUMBER;
    pn_1304_accrued_delayed_int_tx_lc    NUMBER;
    pn_1304_accrued_delayed_int_tx_fc    NUMBER;
    pn_1304_delayed_int_lc    NUMBER;
    pn_1304_delayed_int_fc    NUMBER;
    pn_1304_accrual_int_acct_no    NUMBER;
    pn_1304_accrual_tax_acct_no    NUMBER;
    pn_1304_accrual_delay_int_acct_no    NUMBER;
    pn_1304_nonaccrual_int_acct_no    NUMBER;
    pn_1304_nonaccrual_delay_int_acct    NUMBER;
    pn_1304_birikmisfaiz_arti    NUMBER;
    pn_1304_birikmisfaiz_eksi    NUMBER;
    pn_1304_gekimis_faiz_arti    NUMBER;
    pn_1304_gekimis_faiz_eksi    NUMBER;
    pn_1304_penalty_amount_arti    NUMBER;
    pn_1304_penalty_amount_eksi    NUMBER;
    pn_1304_lc    NUMBER;
    pn_1304_fc    NUMBER;
    pn_1304_gecikme_faiz_dk    NUMBER;
    pn_1304_penalty_gl    NUMBER;   --seval.colak 01112022
   l_uc         							  varchar2(3):=pkg_hata.getucpointer;
   l_ara         							  varchar2(3):=pkg_hata.getdelimiter;

---------------------------------------------------------------------------
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
	ln_txno								 NUMBER;
	ln_hesap_no							 NUMBER;
	ln_bakiye								 NUMBER;
	ls_durum_kodu							 CBS_HESAP_KREDI_ISLEM.durum_kodu%TYPE;
BEGIN
	SELECT hesap_no,durum_kodu
	INTO ln_hesap_no,ls_durum_kodu
	FROM CBS_HESAP_KREDI_ISLEM
	WHERE tx_no = pn_islem_no;

	ln_txno:=Pkg_Kredi.Sf_Bitmemis_HesapIslm_VarMi(NULL,pn_islem_no,ln_hesap_no) ;
	SELECT ABS(NVL(bakiye,0))
	INTO ln_bakiye
	FROM CBS_HESAP_BAKIYE
	WHERE hesap_no =  ln_hesap_no;

	IF ls_durum_kodu = 'K' THEN
		Pkg_Kredi.sp_hesap_kapanabilir_mi( ln_hesap_no);
	END IF;

	Pkg_Kredi.sp_taksit_vade_tutar_kontrol(pn_islem_no , ln_bakiye);
	--  pkg_tx1303.sp_tahakkuk_dk_tanimlimi(pn_islem_no );

	Pkg_Kredi.sp_faizkom_dk_tanimlimi(pn_islem_no);
END;
---------------------------------------------------------------------------
PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
	NULL;
END;
---------------------------------------------------------------------------
PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
	NULL;
END;
---------------------------------------------------------------------------
PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
	NULL;
END;
---------------------------------------------------------------------------
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
null;
	--RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '699' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER); --seval.colak 17012023
END;
---------------------------------------------------------------------------
PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER)
IS
	ld_yeni_vade DATE := NULL;
	ld_eski_vade DATE := NULL;
	ld_temdit_tarihi DATE := NULL;
	ln_hesap_no			 NUMBER;
	ln_txno			 NUMBER;
	ls_durum_kodu		CBS_HESAP_KREDI_ISLEM.durum_kodu%TYPE;
	ls_faiz_siklik_tipi CBS_HESAP_KREDI_ISLEM.faiz_siklik_tipi%TYPE;
	ld_vade				DATE;
	ln_bakiye			NUMBER;
	ld_yeni_Faiz_tahakkuk DATE;
	ln_faiz_siklik		  NUMBER;	
	ln_nonaccrual_int_account_no    number;    
	ln_nonaccrual_delayed_int_account_no number;
	ls_tx_non_accrual_status     CBS_HESAP_KREDI_ISLEM.non_accrual_status%TYPE;  --seval.colak 02112022
    ls_hsp_non_accrual_status    CBS_HESAP_KREDI_ISLEM.non_accrual_status%TYPE;    --seval.colak 02112022	
    ld_tx_non_accrual_status_upd_date  date;       --b-o-m seval.colak 12122022 
    ld_tx_accrual_status_upd_date     date;          
    ld_hsp_non_accrual_status_upd_date date;       
    ld_hsp_accrual_status_upd_date    date;             --e-o-m seval.colak 12122022 
    ls_repayment_type               varchar2(100);  --seval.colak03022023 
    ln_taksit_adet                  number := 0;    --seval.colak03022023     
BEGIN

	SELECT a.hesap_no,
	a.kredi_vade ,
	b.kredi_vade ,
	b.temdit_tarihi,
	a.durum_kodu,
	a.faiz_siklik_tipi,
	a.faiz_siklik	,
	a.nonaccrual_int_account_no,    
	a.nonaccrual_delayed_int_account_no	,
	a.non_accrual_status  tx_non_accrual_status,  --seval.colak 02112022
    b.non_accrual_status  hsp_non_accrual_status, --seval.colak 02112022	
   case when a.non_accrual_status = 'Y' then  a.non_accrual_status_upd_date else null end    tx_non_accrual_status_upd_date,       --b-o-m seval.colak 12122022 
   case when NVL(a.non_accrual_status,'N') = 'N' then  a.accrual_status_upd_date else null end    tx_accrual_status_upd_date,          
    b.non_accrual_status_upd_date    hsp_non_accrual_status_upd_date,       
    b.accrual_status_upd_date        hsp_accrual_status_upd_date,
                                        --e-o-m seval.colak 12122022 
     a.repayment_type 
	INTO  ln_hesap_no,
	ld_yeni_vade,
	ld_eski_vade ,
	ld_temdit_tarihi,
	ls_durum_kodu,
	ls_faiz_siklik_tipi,
	ln_faiz_siklik,
	ln_nonaccrual_int_account_no,    
	ln_nonaccrual_delayed_int_account_no,
	ls_tx_non_accrual_status,  --seval.colak 02112022
    ls_hsp_non_accrual_status ,--seval.colak 02112022	
    ld_tx_non_accrual_status_upd_date ,       --b-o-m seval.colak 12122022 
    ld_tx_accrual_status_upd_date     ,          
    ld_hsp_non_accrual_status_upd_date ,       
    ld_hsp_accrual_status_upd_date  ,  --e-o-m seval.colak 12122022 
    ls_repayment_type
	FROM  CBS_HESAP_KREDI_ISLEM a ,
	CBS_HESAP_KREDI b
	WHERE tx_no = pn_islem_no AND
	a.hesap_no  = b.hesap_no ;

	ln_txno:=Pkg_Kredi.Sf_Bitmemis_HesapIslm_VarMi(NULL,
													pn_islem_no,
													ln_hesap_no) ;

	IF ls_durum_kodu = 'K' THEN
		Pkg_Kredi.sp_hesap_kapanabilir_mi( ln_hesap_no);
		UPDATE   CBS_HESAP_KREDI_ISLEM
		SET kapanis_tarihi = Pkg_Muhasebe.banka_tarihi_bul
		WHERE tx_no = pn_islem_no AND
		NVL(durum_kodu,'A') = 'A';
	END IF;
	
	Pkg_Kredi.sp_onayonce_taksit_sakla(    pn_islem_no ,ln_hesap_no);

	SELECT ABS(NVL(bakiye,0))
	INTO ln_bakiye
	FROM CBS_HESAP_BAKIYE
	WHERE hesap_no =  ln_hesap_no;

	Pkg_Kredi.sp_taksit_vade_tutar_kontrol(pn_islem_no , ln_bakiye);


 -- seval.colak 03022023 
   if ls_repayment_type is null  and ls_faiz_siklik_tipi is not null then 
      select count(*)
      into ln_taksit_adet 
      from cbs_hesap_kredi_taksit_islem f
      where f.tx_no = pn_islem_no ;
      
      if  nvl(ln_taksit_adet,0) > 0 then 
           ls_repayment_type :=  'INSTALLMENT DATE';
       else
           ls_repayment_type :=  'MATURITY DATE';
      end if;
   end if;
  -- seval.colak 03022023 
 
 --b-o-m seval.colak 12122022
    update cbs_hesap_kredi_islem
    set  non_accrual_status =ls_tx_non_accrual_status,
         non_accrual_status_upd_date = ld_tx_non_accrual_status_upd_date,
         accrual_status_upd_date =ld_tx_accrual_status_upd_date,
         repayment_type = ls_repayment_type -- seval.colak 03022023 
    where tx_no = pn_islem_no ;
     
    if  nvl(ls_tx_non_accrual_status,'X') <> nvl(ls_hsp_non_accrual_status,'X')  
        or  ld_tx_non_accrual_status_upd_date  <>  ld_hsp_non_accrual_status_upd_date 
        or  ld_tx_accrual_status_upd_date  <>  ld_hsp_accrual_status_upd_date  
    then
        insert into cbs_hesap_kredi_accr_status_tx( banka_tarihi,
                                                    hesap_no,
                                                    non_accrual_status,
                                                    non_accrual_status_upd_date,
                                                    accrual_status_upd_date,
                                                    yaratan_tx_no,
                                                    grup_no,
                                                    log_no  )
         select pkg_muhasebe.banka_tarihi_bul,
                    hesap_no,
                    non_accrual_status,
                    non_accrual_status_upd_date,
                    accrual_status_upd_date,
                    pn_islem_no,
                    0,
                    0
          from cbs_hesap_kredi_islem
         where tx_no = pn_islem_no;
 end if;
 
 --e-o-m seval.colak 12122022
 
/* temdit tarihi guncellemesi */
	IF  ld_yeni_vade != ld_eski_vade AND ld_eski_vade <= Pkg_Muhasebe.banka_Tarihi_bul THEN
		ld_temdit_tarihi := ld_eski_vade ;

		UPDATE CBS_HESAP_KREDI_ISLEM
		SET temdit_tarihi =ld_temdit_tarihi
		WHERE tx_no = pn_islem_no;
	
	END IF;

	IF ls_faiz_siklik_tipi = 'INSTALLMENT DATE' THEN
	
		SELECT MIN(vade_tarih)
		INTO ld_vade
		FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
		WHERE tx_no = pn_islem_no and
		NVL(durum_kodu,'A') = 'A';

		UPDATE CBS_HESAP_KREDI_ISLEM
		SET faiz_tahakkuk_tarihi =NVL(ld_vade,KREDI_VADE)--ld_vade:TA 31082006
		WHERE tx_no = pn_islem_no;
	
		--TA:31082006
	ELSIF ls_faiz_siklik_tipi  = 'MATURITY DATE' THEN
	
		UPDATE CBS_HESAP_KREDI_ISLEM
		SET faiz_tahakkuk_tarihi =ld_yeni_vade
		WHERE tx_no = pn_islem_no;

	--TA:31082006
	ELSIF ls_faiz_siklik_tipi  = 'EOQ' THEN
		ld_yeni_Faiz_tahakkuk  := Pkg_Kredi.sf_faiz_tahakkuk_tarihi_bul(ls_faiz_siklik_tipi,
																		ln_faiz_siklik,
																		Pkg_Muhasebe.banka_tarihi_bul,
																		ld_yeni_vade);

		IF  ld_yeni_Faiz_tahakkuk  >  ld_yeni_vade THEN
			ld_yeni_Faiz_tahakkuk  :=ld_yeni_vade;
		END IF;

		UPDATE CBS_HESAP_KREDI_ISLEM
		SET faiz_tahakkuk_tarihi =ld_yeni_Faiz_tahakkuk
		WHERE tx_no = pn_islem_no;
	END IF;

--- b-o-m seval.colak 06122022  taksitliler icin faiz_gecikme_gun_sayisi,ap_gecikme_gun_sayisi 
	update cbs_hesap_kredi_taksit h
	set (h.faiz_gecikme_gun_sayisi,h.ap_gecikme_gun_sayisi ) = (select faiz_gecikme_gun_sayisi,ap_gecikme_gun_sayisi 
                                                                from cbs_hesap_kredi_taksit_islem f
                                                                where f.tx_no = pn_islem_no and 
                                                                      f.SIRA_NO = h.sira_no and
                                                                      f.hesap_no = h.hesap_no  )
                                                                        
     WHERE  h.hesap_no = ln_hesap_no;
    --- b-o-m seval.colak 06122022                                                                      

	Pkg_Kredi.sp_taksit_sira_guncelle(pn_islem_no);

	if  nvl(ln_nonaccrual_int_account_no,0) = 0 and nvl(ln_nonaccrual_delayed_int_account_no,0) = 0 then  
	  pkg_kredi_tahsilat.sf_nonaccrual_accounts_opening(ln_hesap_no,pn_islem_no ); --seval.colak 29032022 aciyoruz. --seval.colak 21112021 sonra ekleyecegiz
	end if;
	


	
--- b-o-m seval.colak 06122022  taksitliler icin faiz_gecikme_gun_sayisi max ile guncelleyelim
-- faiz_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi_islem h
set faiz_gecikme_gun_sayisi = (   select nvl(max(nvl(f.faiz_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit_islem f
                                   where f.tx_no = pn_islem_no and 
                                         f.hesap_no = h.hesap_no and
                                         f.durum_kodu ='A' and f.vade_tarih <=pkg_muhasebe.banka_tarihi_bul
                                          and nvl(f.faiz,0) - nvl(f.tahsil_faiz,0)  > 0 ) --seval.colak 20012023
 WHERE h.tx_no = pn_islem_no and
       h.repayment_type = 'INSTALLMENT DATE' ;
       
-- ap_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi_islem h
set ap_gecikme_gun_sayisi = (   select nvl(max(nvl(f.ap_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit_islem f
                                   where  f.tx_no = pn_islem_no and 
                                          f.hesap_no = h.hesap_no and
                                          f.durum_kodu ='A' and f.vade_tarih <=pkg_muhasebe.banka_tarihi_bul 
                                           and nvl(f.anapara,0) - nvl(f.tahsil_anapara,0)  > 0 ) --seval.colak 20012023
 WHERE  h.tx_no = pn_islem_no and 
        h.repayment_type = 'INSTALLMENT DATE' ;   
 ---ana tablo
 -- faiz_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi h
set faiz_gecikme_gun_sayisi = (   select nvl(max(nvl(f.faiz_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit f
                                   where f.hesap_no = ln_hesap_no and 
                                         f.hesap_no = h.hesap_no and
                                         f.durum_kodu ='A' and f.vade_tarih <=pkg_muhasebe.banka_tarihi_bul )
 WHERE h.hesap_no = ln_hesap_no and 
       h.repayment_type = 'INSTALLMENT DATE' ;
       
-- ap_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi  h
set ap_gecikme_gun_sayisi = (   select nvl(max(nvl(f.ap_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit f
                                   where  f.hesap_no = ln_hesap_no and 
                                          f.hesap_no = h.hesap_no and
                                          f.durum_kodu ='A' and f.vade_tarih <=pkg_muhasebe.banka_tarihi_bul )
 WHERE  h.hesap_no = ln_hesap_no and 
        h.repayment_type = 'INSTALLMENT DATE' ;  
 --- e-o-m seval.colak 06122022 
 
 -- b-o-m seval.colak 03022023
 delete from cbs.cbs_hesap_kredi_accr_status_tx s
where s.hesap_no = ln_hesap_no and   s.non_accrual_status = 'Y' and ( s.hesap_no ,s.banka_tarihi ) in  ( select hesap_no , banka_tarihi   
                                                                           from cbs.cbs_hesap_kredi_accr_status_tx t
                                                                           where  exists (select 1 from cbs.cbs_hesap_kredi_islem a where  a.tx_no = pn_islem_no and a.hesap_no =  t.hesap_no  and non_accrual_status  ='N')
                                                                           group by hesap_no , banka_tarihi
                                                                           having count(*) > 1   );

  -- e-o-m seval.colak 03022023
END;
---------------------------------------------------------------------------
PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
 pkg_kredi.iptal_onay_sonrasi(pn_islem_no); --seval.colak 170120223
 
 delete from cbs_hesap_kredi_accr_status_tx --seval.colak 030220223
 where yaratan_tx_no = pn_islem_no ; 


	--RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '699' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER); --seval.colak 170120223
END;
---------------------------------------------------------------------------
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
	NULL;
END;
---------------------------------------------------------------------------
PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
	NULL;
END;
---------------------------------------------------------------------------
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
BEGIN
	NULL;
END;
---------------------------------------------------------------------------
PROCEDURE Muhasebelesme(pn_islem_no NUMBER) IS
	varchar_list       Pkg_Muhasebe.varchar_array;
	number_list        Pkg_Muhasebe.number_array;
	date_list        Pkg_Muhasebe.date_array;
	boolean_list       Pkg_Muhasebe.boolean_array;
	ln_fis_no        NUMBER;
	Islem_Bulunamadi_Exception          EXCEPTION;
	DK_Bulunamadi_Exception			    EXCEPTION;
	ln_plan_no        NUMBER:=0;
	lv_faiz_dk						            VARCHAR2(30);
	lv_reeskont_dk					            VARCHAR2(30);
 --b-0-m seval.colak 28062022
    ln_islem_kod                               number :=1304;
    ln_accrual_int_account_bakiye              number := 0 ;
    ln_nonaccrual_int_account_bakiye           number := 0 ;
    ln_accrual_delayed_int_bakiye              number := 0 ;
    ln_nonaccrual_delayed_int_bakiye           number := 0 ;
    ln_org_accrual_int_account_bakiye          number := 0 ;
    ln_org_nonaccrual_int_account_bakiye       number := 0 ;
    ln_org_accrual_delayed_int_bakiye          number := 0 ;
    ln_org_nonaccrual_delayed_int_bakiye       number := 0 ;
    ln_accrual_birikmisfaiz_arteksitutar       number := 0 ;
    ln_nonaccrual_birikmisfaiz_arteksitutar    number := 0 ;
    ln_accrual_birikmis_faiz_tax               number := 0 ;
    ln_nonaccrual_birikmis_faiz_tax            number := 0 ;
    ln_rate                                    number := 0;
    ln_accrual_birikmis_gecikme_faiz           number := 0 ;
    ln_nonaccrual_birikmis_gecikme_faiz        number := 0 ; 
    ln_accrual_gecikme_faiz_tax                number := 0 ;
    ln_nonaccrual_gecikme_faiz_tax             number := 0 ;
    ln_musteri_kur                             number := 0 ;  
    ln_hesap_no                                number;
    ln_kalan_tahsil_tutar                      number:= 0;
    ln_tahsil_tutar                            number := 0;
  
    iliskili_faiz_dk_yok                exception;
    iliskili_faizrees_dk_yok            exception;
    gecikme_faiz_dk_yok                 exception;

    --e-0-m seval.colak 28062022
    
	CURSOR c1 (p_islemno number) IS
	SELECT    musteri_no,
              modul_tur_kod,urun_tur_kod,urun_sinif_kod,
              Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no) dk_grup_kod ,
              nvl(GECENYILFAIZ_ARTIEKSITUTAR,0) gecenyil_azalis,
		      nvl(GECMISAYFAIZ_ARTIEKSITUTAR,0) gecenay_azalis,
              hesap_no,
		      doviz_kodu,
		      sube_kodu,
		      birikmis_faiz_tutari,                               --b-o-m seval.colak 28062022
              birikmis_gecikme_faiz_tutari,                     
              penalty_amount ,
		      birikmisfaiz_artieksi,                  
              abs(nvl(birikmisfaiz_arteksitutar,0)) birikmisfaiz_arteksitutar,
              birikmisgecfaiz_artieksi,
              abs( nvl(birikmisgecfaiz_arteksitutar,0))  birikmisgecfaiz_arteksitutar,   
              penaltyamount_artieksi ,
              abs(nvl(penaltyamount_arteksitutar,0))    penaltyamount_arteksitutar  ,
              non_accrual_status  ,
              iliskili_hesap_no,
              pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) iliskili_hesap_doviz ,
              NVL(accrual_int_account_no,0) accrual_int_account_no,
              NVL(accrual_tax_account_no,0) accrual_tax_account_no,
              NVL(accrual_delayed_int_account_no,0) accrual_delayed_int_account_no,
              NVL(nonaccrual_int_account_no,0)  nonaccrual_int_account_no,
              NVL(nonaccrual_delayed_int_account_no,0) nonaccrual_delayed_int_account_no ,
              DECODE( a.birikmisfaiz_artieksi,NULL,a.birikmis_faiz_tutari,
							  '+',ABS(NVL(a.birikmis_faiz_tutari,0)) + ABS(NVL(a.birikmisfaiz_arteksitutar,0)) ,
							  '-' ,ABS(NVL(a.birikmis_faiz_tutari,0)) - ABS(NVL(a.birikmisfaiz_arteksitutar,0))) yeni_birikmis_faiz_tutari,
            DECODE( a.birikmiskom_artieksi,NULL,a.birikmis_komisyon_tutari,
                                      '+',ABS(NVL(a.birikmis_komisyon_tutari,0)) + ABS(NVL(a.birikmiskom_arteksitutar,0)), 
                                      '-' ,ABS(NVL(a.birikmis_komisyon_tutari,0)) - ABS(NVL(a.birikmiskom_arteksitutar,0))) yeni_birikmis_komisyon_tutari,
            decode( birikmisgecfaiz_artieksi,null,a.birikmis_gecikme_faiz_tutari,
                                      '+',abs(nvl(a.birikmis_gecikme_faiz_tutari,0)) + abs(nvl(a.birikmisgecfaiz_arteksitutar,0)) ,
                                      '-' ,abs(nvl(a.birikmis_gecikme_faiz_tutari,0)) - abs(nvl(a.birikmisgecfaiz_arteksitutar,0))) yeni_birikmis_gecikme_faiz_tutari,
            decode( a.penaltyamount_artieksi,null,a.penalty_amount,
                                      '+',abs(nvl(a.penalty_amount,0)) + abs(nvl(a.penaltyamount_arteksitutar,0)) ,
                                      '-' ,abs(nvl(a.penalty_amount,0)) - abs(nvl(a.penaltyamount_arteksitutar,0))) yeni_penalty_amount,
                                      
             decode( birikmisgecfaiz_artieksi,null,0,
                                      '+',abs(nvl(a.birikmis_gecikme_faiz_tutari,0)) + abs(nvl(a.birikmisgecfaiz_arteksitutar,0)) ,
                                      '-' ,-1*abs(nvl(a.birikmisgecfaiz_arteksitutar,0))) birikmis_gecikme_faiz_isaretli,
            decode( a.penaltyamount_artieksi,null,0,
                                      '+',abs(nvl(a.penaltyamount_arteksitutar,0)) ,
                                      '-' ,-1*abs(nvl(a.penaltyamount_arteksitutar,0))) penalty_amount_isaretli                                             
                --e-o-m seval.colak 28062022      
	FROM cbs_hesap_kredi_islem a
	WHERE TX_NO=p_islemno;

	r1    c1%ROWTYPE;
	
  cursor cur_taksit is
  select hesap_no,
     sira_no,
     nvl(gecikme_faiz_tutari,0) gecikme_faiz_tutari,
     nvl(tahsil_gecikme_faiz_tutari,0)  tahsil_gecikme_faiz_tutari,
     nvl(gecikme_faiz_tutari,0) - nvl(tahsil_gecikme_faiz_tutari,0) unpaid_gecikme_faiz_tutari,
     nvl(penalty_amount,0) penalty_amount,
     nvl(paid_penalty_amount,0) paid_penalty_amount,
     nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) unpaid_penalty_amount
     from cbs_hesap_kredi_taksit_islem b
     where  tx_no = pn_islem_no and
            hesap_no =ln_hesap_no and 
            durum_kodu ='A'  
      order by sira_no ; 
      
      r_taksit  cur_taksit%ROWTYPE;
      
BEGIN
 --B-O-M seval.colak 28062022
   Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
   
    boolean_list(pn_1304_birikmisfaiz_arti)  := FALSE;
    boolean_list(pn_1304_birikmisfaiz_eksi)  := FALSE;
    boolean_list(pn_1304_gekimis_faiz_arti)  := FALSE;
    boolean_list(pn_1304_gekimis_faiz_eksi)  := FALSE;
    boolean_list(pn_1304_penalty_amount_arti)  := FALSE;
    boolean_list(pn_1304_penalty_amount_eksi)  := FALSE;
    boolean_list(pn_1304_lc)  := FALSE;
    boolean_list(pn_1304_fc)  := FALSE;
    number_list(pn_1304_deduction_lc)  := 0;
    number_list(pn_1304_decrease_last_month_lc)  := 0;
    number_list(pn_1304_deduction_fc)  := 0;
    number_list(pn_1304_decrease_last_month_fc)  := 0;
    number_list(pn_1304_mb_kur)  := 0;
    number_list(pn_1304_birikmis_faiz_lc)  := 0;
    number_list(pn_1304_birikmis_faiz_fc)  := 0;
    number_list(pn_1304_accrued_int_tax_lc)  := 0;
    number_list(pn_1304_accrued_int_tax_fc)  := 0;
    number_list(pn_1304_accrued_delayed_int_lc)  := 0;
    number_list(pn_1304_accrued_delayed_int_fc)  := 0;
    number_list(pn_1304_penalty_amount_lc)  := 0;
    number_list(pn_1304_penalty_amount_fc)  := 0;
    number_list(pn_1304_nonaccrued_delayed_int_lc)  := 0;
    number_list(pn_1304_nonaccrued_delayed_int_fc)  := 0;
    number_list(pn_1304_accrued_int_lc)  := 0;
    number_list(pn_1304_accrued_int_fc)  := 0;
    number_list(pn_1304_nonaccrued_int_lc)  := 0;
    number_list(pn_1304_nonaccrued_int_fc)  := 0;
    number_list(pn_1304_accrued_delayed_int_tx_lc)  := 0;
    number_list(pn_1304_accrued_delayed_int_tx_fc)  := 0;
    number_list(pn_1304_delayed_int_lc)  := 0;
    number_list(pn_1304_delayed_int_fc)  := 0;
    varchar_list(pn_1304_reeskont_dk)  := NULL; 
    varchar_list(pn_1304_faiz_dk)  := NULL; 
    varchar_list(pn_1304_bolum_kodu)  := NULL; 
    varchar_list(pn_1304_banka_aciklama)  := NULL; 
    varchar_list(pn_1304_musteri_aciklama)  := NULL; 
    varchar_list(pn_1304_doviz_kodu)  := NULL; 
    varchar_list(pn_1304_kredi_hesap)  := NULL; 
    varchar_list(pn_1304_accrual_int_acct_no)  := NULL; 
    varchar_list(pn_1304_accrual_tax_acct_no)  := NULL; 
    varchar_list(pn_1304_accrual_delay_int_acct_no)  := NULL; 
   varchar_list(pn_1304_nonaccrual_int_acct_no)  := NULL; 
    varchar_list(pn_1304_nonaccrual_delay_int_acct)  := NULL; 
   --E-O-M seval.colak 28062022
     varchar_list(pn_1304_penalty_gl)  := NULL;      --seval.colak 01112022

   
	OPEN c1(pn_islem_no);
	FETCH c1
	INTO r1;
	IF c1%NOTFOUND THEN
		CLOSE c1;
		RAISE Islem_Bulunamadi_Exception;
	END IF;
	CLOSE c1;
	
    ln_hesap_no :=r1.hesap_no;
    
	update cbs_hesap_kredi
	set	gecenyil_faiz_tutari = gecenyil_faiz_tutari-r1.gecenyil_azalis,
	    gecmis_aylarin_faizi = gecmis_aylarin_faizi-r1.gecenay_azalis    
	WHERE HESAP_NO = r1.HESAP_NO;

--ilgili faiz ve Reeskont DK'larini getir		
   if  r1.dk_grup_kod is not null and r1.modul_tur_kod is not null and r1.urun_tur_kod is not null and r1.urun_sinif_kod is not null then 
     pkg_muhasebe.dk_bul ( r1.dk_grup_kod,r1.modul_tur_kod, r1.urun_tur_kod, r1.urun_sinif_kod, 2,null,null, null,lv_faiz_dk);
     pkg_muhasebe.dk_bul ( r1.dk_grup_kod,r1.modul_tur_kod,r1.urun_tur_kod, r1.urun_sinif_kod, 10,null,null, null,varchar_list(pn_1304_gecikme_faiz_dk)); 
     pkg_muhasebe.dk_bul ( r1.dk_grup_kod,r1.modul_tur_kod,r1.urun_tur_kod, r1.urun_sinif_kod, 12,null,null, null,varchar_list(pn_1304_penalty_gl)); --seval.colak 01112022
   end if;
      if     lv_faiz_dk is null then
              raise iliskili_faiz_dk_yok;
      end if;
      if     varchar_list(pn_1304_gecikme_faiz_dk) is null and  nvl(r1.birikmisgecfaiz_arteksitutar,0) <> 0 then
              raise gecikme_faiz_dk_yok;
      end if;
         
/*faiz reeskont dk */
    pkg_muhasebe.dk_bul ( r1.dk_grup_kod,r1.modul_tur_kod,r1.urun_tur_kod, r1.urun_sinif_kod, 4, null,null, null,lv_reeskont_dk);
	  if     lv_reeskont_dk is null then
              raise iliskili_faizrees_dk_yok;
      end if;
 
  --B-O-M seval.colak 28062022
  	IF r1.doviz_kodu=Pkg_Genel.lc_al
		THEN
		    boolean_list(pn_1304_lc)  := TRUE;
		 else
		   boolean_list(pn_1304_fc)  := TRUE; 
     end if;
     		     
  if r1.BIRIKMISFAIZ_ARTIEKSI ='+' then 
     boolean_list(pn_1304_birikmisfaiz_arti)  := TRUE;
   end if;
   if r1.BIRIKMISFAIZ_ARTIEKSI ='-' then    
    boolean_list(pn_1304_birikmisfaiz_eksi)  := TRUE;
   end if;
   if r1.BIRIKMISGECFAIZ_ARTIEKSI ='+' then
    boolean_list(pn_1304_gekimis_faiz_arti)  := TRUE;
   end if;
   if r1.BIRIKMISGECFAIZ_ARTIEKSI ='-' then 
     boolean_list(pn_1304_gekimis_faiz_eksi)  := TRUE;
   end if;
   if r1.PENALTYAMOUNT_ARTIEKSI = '+' then 
     boolean_list(pn_1304_penalty_amount_arti)  := TRUE;
   end if;
   if r1.PENALTYAMOUNT_ARTIEKSI = '-' then   
    boolean_list(pn_1304_penalty_amount_eksi)  := TRUE;
   end if;
   
	ln_musteri_kur  := Pkg_Kur.doviz_doviz_karsilik(r1.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
	number_list(pn_1304_MB_KUR):=ln_musteri_kur;

    varchar_list(pn_1304_accrual_int_acct_no) := r1.accrual_int_account_no ;
    varchar_list(pn_1304_accrual_tax_acct_no)   := r1.accrual_tax_account_no;
    varchar_list(pn_1304_accrual_delay_int_acct_no ):= r1.accrual_delayed_int_account_no;
    varchar_list(pn_1304_nonaccrual_int_acct_no ):= r1.nonaccrual_int_account_no;
    varchar_list(pn_1304_nonaccrual_delay_int_acct ):= r1.nonaccrual_delayed_int_account_no;
    
     if nvl(r1.nonaccrual_int_account_no,0) <> 0 then 
        ln_nonaccrual_int_account_bakiye :=  nvl(pkg_hesap.hesapbakiyeal( r1.nonaccrual_int_account_no),0) ;
    end if;
    
    if nvl(r1.accrual_int_account_no,0) <> 0 then 
        ln_accrual_int_account_bakiye    :=  nvl(pkg_hesap.hesapbakiyeal(r1.accrual_int_account_no),0) ;
    end if;
    
     if nvl(r1.nonaccrual_delayed_int_account_no,0) <> 0 then 
        ln_nonaccrual_delayed_int_bakiye := nvl(pkg_hesap.hesapbakiyeal(r1.nonaccrual_delayed_int_account_no),0) ;
    end if;
    
    if nvl(r1.accrual_delayed_int_account_no,0) <> 0 then 
        ln_accrual_delayed_int_bakiye    :=  nvl(pkg_hesap.hesapbakiyeal(r1.accrual_delayed_int_account_no),0); 
     end if;
     
    
    ln_org_nonaccrual_int_account_bakiye := ln_nonaccrual_int_account_bakiye;
    ln_org_accrual_int_account_bakiye    := ln_accrual_int_account_bakiye;
    ln_org_nonaccrual_delayed_int_bakiye := ln_nonaccrual_delayed_int_bakiye;
    ln_org_accrual_delayed_int_bakiye    := ln_accrual_delayed_int_bakiye ;      

 -- b-o-m seval.colak 17012023 prod problem olarak bildirdiler tekrar oncelikli nonaccrualdan alinacak hale getirildi.eski hali geri alindi. alttaki kisim eklendi.
        if nvl(r1.birikmisfaiz_arteksitutar,0)  <> 0 then                              
            select    
                   case when nvl(r1.non_accrual_status,'N') ='N' then   abs(nvl(r1.birikmisfaiz_arteksitutar,0)) --1.Hesab?n nonaccrual statusu H ise tutar?n tamam? accrual amount.a atanacakt?r.
                        when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisfaiz_artieksi ='+' then  0   --2. nonaccrual statusu E ise ve artt?r?m ise tutar?n tamam? nonaccrual amount.a atanacakt?r 
       
                        else --  non_accrual_status Y ise nonaccrual bakiyeden kalan olacak
                                  nvl(r1.birikmisfaiz_arteksitutar,0)  -  (case when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisfaiz_artieksi ='+' then  abs(nvl(r1.birikmisfaiz_arteksitutar,0) )  --2. nonaccrual statusu E ise ve artt?r?m ise tutar?n tamam? nonaccrual amount.a atanacakt?r 
                                            when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisfaiz_artieksi = '-' and  ln_nonaccrual_int_account_bakiye <= 0  then  --azaltim
                                                  case when  abs(nvl(r1.birikmisfaiz_arteksitutar,0) ) >  abs(ln_nonaccrual_int_account_bakiye)  then
                                                                             abs(ln_nonaccrual_int_account_bakiye) 
                                                    else
                                                                            abs(nvl(r1.birikmisfaiz_arteksitutar,0) ) 
                                                end 
                                         else 0 
                                       end   ) --  kalan faiz - non accrual bakiye                   
                            end accrual_birikmisfaiz_arteksitutar , 
                
                  case when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisfaiz_artieksi ='+' then  abs(nvl(r1.birikmisfaiz_arteksitutar,0) )  --2. nonaccrual statusu E ise ve artt?r?m ise tutar?n tamam? nonaccrual amount.a atanacakt?r 
                            when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisfaiz_artieksi = '-' and  ln_nonaccrual_int_account_bakiye <= 0  then  --azaltim
                                  case when  abs(nvl(r1.birikmisfaiz_arteksitutar,0) ) >  abs(ln_nonaccrual_int_account_bakiye)  then
                                                             abs(ln_nonaccrual_int_account_bakiye) 
                                    else
                                                            abs(nvl(r1.birikmisfaiz_arteksitutar,0) ) 
                                end 
                         else 0 
                       end nonaccrual_birikmisfaiz_arteksitutar                                  
                           into 
                                        ln_accrual_birikmisfaiz_arteksitutar,
                                        ln_nonaccrual_birikmisfaiz_arteksitutar                                                                    
                   from dual;  
                        
                            ln_accrual_birikmis_faiz_tax :=   abs(round((  nvl(ln_accrual_birikmisfaiz_arteksitutar,0)  * nvl(ln_rate,0) /100),2 )) ;
                            ln_nonaccrual_birikmis_faiz_tax :=   abs(round((  nvl(ln_nonaccrual_birikmisfaiz_arteksitutar,0)  * nvl(ln_rate,0) /100),2 )) ;
                                                                  
           
                                ln_accrual_int_account_bakiye :=  abs(nvl(ln_accrual_int_account_bakiye,0)) -   abs(nvl(ln_accrual_birikmisfaiz_arteksitutar ,0)) ;            --seval.colak 28062022                   
                                ln_nonaccrual_int_account_bakiye :=  abs(nvl(ln_nonaccrual_int_account_bakiye,0)) -   abs(nvl(ln_nonaccrual_birikmisfaiz_arteksitutar ,0)) ;            --seval.colak 28062022
                        
                                if     nvl(ln_org_accrual_int_account_bakiye,0)  < 0  then 
                                        ln_accrual_int_account_bakiye :=  nvl(ln_accrual_int_account_bakiye,0) * -1;
                                 end if; 
                                  if     nvl(ln_org_nonaccrual_int_account_bakiye,0)  <0  then 
                                        ln_nonaccrual_int_account_bakiye :=  nvl(ln_nonaccrual_int_account_bakiye,0) * -1;
                                 end if;   
            end if; 

            if  nvl(r1.birikmisgecfaiz_arteksitutar,0) <> 0 then 
                select  
                 case when nvl(r1.non_accrual_status,'N') ='N' then   abs(nvl(r1.birikmisgecfaiz_arteksitutar,0)) --1.Hesab?n nonaccrual statusu H ise tutar?n tamam? accrual amount.a atanacakt?r.
                        when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisgecfaiz_artieksi ='+' then  0   --2. nonaccrual statusu E ise ve artt?r?m ise tutar?n tamam? nonaccrual amount.a atanacakt?r 
       
                        else --  non_accrual_status Y ise nonaccrual bakiyeden kalan olacak
                                  nvl(r1.birikmisgecfaiz_arteksitutar,0)  -  (case when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisgecfaiz_artieksi ='+' then  abs(nvl(r1.birikmisgecfaiz_arteksitutar,0) )  --2. nonaccrual statusu E ise ve artt?r?m ise tutar?n tamam? nonaccrual amount.a atanacakt?r 
                                            when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisgecfaiz_artieksi = '-' and  ln_nonaccrual_delayed_int_bakiye <= 0  then  --azaltim
                                                  case when  abs(nvl(r1.birikmisgecfaiz_arteksitutar,0) ) >  abs(ln_nonaccrual_delayed_int_bakiye)  then
                                                                             abs(ln_nonaccrual_delayed_int_bakiye) 
                                                    else
                                                                            abs(nvl(r1.birikmisgecfaiz_arteksitutar,0) ) 
                                                end 
                                         else 0 
                                       end   ) --  kalan faiz - non accrual bakiye                   
                            end accrual_birikmisgecfaiz_arteksitutar , 
                
                  case when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisgecfaiz_artieksi ='+' then  abs(nvl(r1.birikmisgecfaiz_arteksitutar,0) )  --2. nonaccrual statusu E ise ve artt?r?m ise tutar?n tamam? nonaccrual amount.a atanacakt?r 
                            when nvl(r1.non_accrual_status,'N') ='Y'  and  r1.birikmisgecfaiz_artieksi = '-' and  ln_nonaccrual_delayed_int_bakiye <= 0  then  --azaltim
                                  case when  abs(nvl(r1.birikmisgecfaiz_arteksitutar,0) ) >  abs(ln_nonaccrual_delayed_int_bakiye)  then
                                                             abs(ln_nonaccrual_delayed_int_bakiye) 
                                    else
                                                            abs(nvl(r1.birikmisgecfaiz_arteksitutar,0) ) 
                                end 
                         else 0 
                       end nonaccrual_birikmisgecfaiz_arteksitutar    
                       into 
                            ln_accrual_birikmis_gecikme_faiz,
                            ln_nonaccrual_birikmis_gecikme_faiz
                       from dual;   
                       
                       ln_accrual_gecikme_faiz_tax    :=  abs(round(( nvl(ln_accrual_birikmis_gecikme_faiz,0)  * nvl(ln_rate,0) /100),2 )) ;
                       ln_nonaccrual_gecikme_faiz_tax :=  abs(round(( nvl(ln_nonaccrual_birikmis_gecikme_faiz,0)  * nvl(ln_rate,0) /100),2 ));    
                
                 ln_accrual_delayed_int_bakiye :=  abs(nvl(ln_accrual_delayed_int_bakiye,0)) -   abs(nvl(ln_accrual_birikmis_gecikme_faiz ,0)) ;            --seval.colak 28062022                   
                 ln_nonaccrual_delayed_int_bakiye :=  abs(nvl(ln_nonaccrual_delayed_int_bakiye,0)) -   abs(nvl(ln_nonaccrual_birikmis_gecikme_faiz ,0)) ;            --seval.colak 28062022            
               
                 if   nvl(ln_org_accrual_delayed_int_bakiye,0)  < 0  then 
                        ln_accrual_delayed_int_bakiye :=  nvl(ln_accrual_delayed_int_bakiye,0) * -1;
                 end if; 
                  if     nvl(ln_org_nonaccrual_delayed_int_bakiye,0)  <0  then 
                        ln_nonaccrual_delayed_int_bakiye :=  nvl(ln_nonaccrual_delayed_int_bakiye,0) * -1;
                 end if;  
            end if;
      -- e-o-m seval.colak 17012023 prod problem olarak bildirdiler tekrar oncelikli nonaccrualdan alinacak hale getirildi.eski hali geri alindi. bu kisim eklendi.       
        number_list(pn_1304_accrued_int_fc)        := abs(NVL(ln_accrual_birikmisfaiz_arteksitutar,0));      
        number_list(pn_1304_accrued_int_tax_fc)    := abs(round(( number_list(pn_1304_accrued_int_fc)  * nvl(ln_rate,0) /100),2 ));
        number_list(pn_1304_nonaccrued_int_fc)     := abs(NVL(ln_nonaccrual_birikmisfaiz_arteksitutar,0));
        number_list(pn_1304_birikmis_faiz_fc)      :=  number_list(pn_1304_accrued_int_fc)  +   number_list(pn_1304_nonaccrued_int_fc) ;
        
        number_list(pn_1304_accrued_delayed_int_fc)     := nvl(ln_accrual_birikmis_gecikme_faiz,0);
        number_list(pn_1304_accrued_delayed_int_tx_fc)  := abs(round(( number_list(pn_1304_accrued_delayed_int_fc)  * nvl(ln_rate,0) /100),2 ));
        number_list(pn_1304_nonaccrued_delayed_int_fc)  := abs( nvl(ln_nonaccrual_birikmis_gecikme_faiz,0));
        number_list(pn_1304_delayed_int_fc)               := number_list(pn_1304_accrued_delayed_int_fc)  +   number_list(pn_1304_nonaccrued_delayed_int_fc) ;
        
        number_list(pn_1304_penalty_amount_fc)  := abs( nvl(r1.penaltyamount_arteksitutar,0));
     -- e-o-m seval.colak 28062022	
	
		IF r1.doviz_kodu=Pkg_Genel.lc_al
		THEN
		   -- boolean_list(pn_1304_lc)  := TRUE;
    
			number_list(pn_1304_DEDUCTION_LC) := r1.gecenyil_azalis;
			number_list(pn_1304_DEDUCTION_FC) := r1.gecenyil_azalis;

			number_list(pn_1304_DECREASE_LAST_MONTH_LC) := r1.gecenay_azalis;
			number_list(pn_1304_DECREASE_LAST_MONTH_FC) := r1.gecenay_azalis;
			
			-- B-O-M seval.colak 28062022					
			number_list(pn_1304_accrued_int_lc)  := number_list(pn_1304_accrued_int_fc);
            number_list(pn_1304_nonaccrued_int_lc)  :=   number_list(pn_1304_nonaccrued_int_fc);           
			number_list(pn_1304_accrued_int_tax_lc) := number_list(pn_1304_accrued_int_tax_fc);             
           
            number_list(pn_1304_accrued_delayed_int_lc)  := number_list(pn_1304_accrued_delayed_int_fc) ;
            number_list(pn_1304_accrued_delayed_int_tx_lc)  := number_list(pn_1304_accrued_delayed_int_tx_fc);   
            number_list(pn_1304_nonaccrued_delayed_int_lc) := number_list(pn_1304_nonaccrued_delayed_int_fc);    
              
            number_list(pn_1304_penalty_amount_lc)       :=  number_list(pn_1304_penalty_amount_fc);       
       		-- E-O-M seval.colak 28062022  
		ELSE
          --   boolean_list(pn_1304_fc)  := TRUE;
             
			number_list(pn_1304_DEDUCTION_LC) := Pkg_Kur.doviz_doviz_karsilik(r1.doviz_kodu,Pkg_Genel.lc_al,NULL,r1.gecenyil_azalis,1,NULL,NULL,'N','A');
			number_list(pn_1304_DEDUCTION_FC) := r1.gecenyil_azalis;

			number_list(pn_1304_DECREASE_LAST_MONTH_LC) := Pkg_Kur.doviz_doviz_karsilik(r1.doviz_kodu,Pkg_Genel.lc_al,NULL,r1.gecenay_azalis,1,NULL,NULL,'N','A');
			number_list(pn_1304_DECREASE_LAST_MONTH_FC) := r1.gecenay_azalis;
			
            -- B-O-M seval.colak 28062022           
			number_list(pn_1304_accrued_int_lc)     :=  pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_1304_accrued_int_fc)  * ln_musteri_kur); 
            number_list(pn_1304_nonaccrued_int_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_1304_nonaccrued_int_fc)  * ln_musteri_kur);    
			number_list(pn_1304_accrued_int_tax_lc) :=  pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_1304_accrued_int_tax_fc)  * ln_musteri_kur);       
           
            number_list(pn_1304_accrued_delayed_int_lc)    := pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_1304_accrued_delayed_int_fc)  * ln_musteri_kur);
            number_list(pn_1304_accrued_delayed_int_tx_lc) := pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_1304_accrued_delayed_int_tx_fc)  * ln_musteri_kur); 
            number_list(pn_1304_nonaccrued_delayed_int_lc) := pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_1304_nonaccrued_delayed_int_fc)  * ln_musteri_kur); 
             
            number_list(pn_1304_penalty_amount_lc)       :=   pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_1304_penalty_amount_fc)  * ln_musteri_kur);                   
			-- E-O-M seval.colak 28062022  
		END IF;
		  number_list(pn_1304_birikmis_faiz_lc)  := number_list(pn_1304_accrued_int_lc) +   number_list(pn_1304_nonaccrued_int_lc) ;
		  number_list(pn_1304_delayed_int_lc)    := number_list(pn_1304_accrued_delayed_int_lc)  +   number_list(pn_1304_nonaccrued_delayed_int_lc) ;   
           
		varchar_list(pn_1304_FAIZ_DK):=lv_faiz_dk;
		varchar_list(pn_1304_REESKONT_DK):=lv_reeskont_dk;
		varchar_list(pn_1304_BOLUM_KODU) := r1.SUBE_KODU;
		varchar_list(pn_1304_DOVIZ_KODU) := r1.doviz_kodu;
		varchar_list(pn_1304_KREDI_HESAP) := r1.HESAP_NO;
		varchar_list(pn_1304_MUSTERI_ACIKLAMA) := r1.HESAP_NO||' Decrease/Increase of Interest';
		varchar_list(pn_1304_BANKA_ACIKLAMA) := r1.HESAP_NO||'  Decrease/Increase of Interest';
  
    if  nvl( number_list(pn_1304_DEDUCTION_FC),0)  +  nvl(number_list(pn_1304_DECREASE_LAST_MONTH_FC) ,0) + nvl(number_list(pn_1304_ACCRUED_INT_FC),0) + nvl(number_list(pn_1304_NONACCRUED_INT_FC),0) +  nvl(number_list(pn_1304_ACCRUED_INT_TAX_FC),0) + nvl(number_list(pn_1304_ACCRUED_DELAYED_INT_FC),0) + nvl(number_list(pn_1304_NONACCRUED_DELAYED_INT_FC),0) + nvl(number_list(pn_1304_ACCRUED_DELAYED_INT_TX_FC),0) <> 0   -- seval.colak 06122022 normal guncelleme islemi yapildiginda bos fis kesmesini engelleyelim.
        or
        nvl( number_list(pn_1304_DEDUCTION_LC),0)  +  nvl(number_list(pn_1304_DECREASE_LAST_MONTH_LC) ,0) + nvl(number_list(pn_1304_ACCRUED_INT_LC),0) + nvl(number_list(pn_1304_NONACCRUED_INT_LC),0) +  nvl(number_list(pn_1304_ACCRUED_INT_TAX_LC),0) + nvl(number_list(pn_1304_ACCRUED_DELAYED_INT_LC),0) + nvl(number_list(pn_1304_NONACCRUED_DELAYED_INT_LC),0) + nvl(number_list(pn_1304_ACCRUED_DELAYED_INT_TX_LC),0) <> 0  then   
        ln_fis_no:=pkg_muhasebe.fis_kes(ln_islem_kod,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            null);

    pkg_muhasebe.muhasebelestir(ln_fis_no);
    end if;
-- b-o-m seval.colak 28062022
    Pkg_Kredi.sp_kredihesap_bilgisi_guncelle(pn_islem_no);
	
  	UPDATE CBS_HESAP_KREDI
	SET birikmis_faiz_tutari =  r1.yeni_birikmis_faiz_tutari,
		birikmis_komisyon_tutari = r1.yeni_birikmis_komisyon_tutari,
        birikmis_gecikme_faiz_tutari = r1.yeni_birikmis_gecikme_faiz_tutari,
		penalty_amount = r1.yeni_penalty_amount					  
	WHERE hesap_No =r1.hesap_no;
 

-- taksit gecikmis faiz artt?r?m azalt?m 
  ln_kalan_tahsil_tutar := 0;
  ln_tahsil_tutar       := 0;
  
   if nvl(r1.birikmisgecfaiz_arteksitutar,0) <> 0  and   r1.birikmisgecfaiz_artieksi is not null then     
    ln_kalan_tahsil_tutar := r1.birikmisgecfaiz_arteksitutar;    
   
    for c_taksit in cur_taksit
       loop  
          r_taksit := c_taksit;    
          if  nvl(c_taksit.unpaid_gecikme_faiz_tutari,0) >= 0  and nvl(ln_kalan_tahsil_tutar,0)  >= 0 then  
         
                if  nvl(c_taksit.unpaid_gecikme_faiz_tutari,0) > nvl(ln_kalan_tahsil_tutar,0) then
                    ln_tahsil_tutar  :=  nvl(ln_kalan_tahsil_tutar,0) ;
                 else
                     ln_tahsil_tutar := nvl(c_taksit.unpaid_gecikme_faiz_tutari,0) ;
                 end if;   
                 
                 if nvl(ln_tahsil_tutar,0) <0 then 
                    ln_tahsil_tutar := 0;
                 end if;
           
                if   r1.birikmisgecfaiz_artieksi ='-' then         
                   update cbs_hesap_kredi_taksit
                   set   gecikme_faiz_tutari = case when nvl(gecikme_faiz_tutari,0)  - nvl(ln_tahsil_tutar,0)  >0 then  nvl(gecikme_faiz_tutari,0)  - nvl(ln_tahsil_tutar,0) else 0 end           	
                   where hesap_No = r1.hesap_no and sira_no = c_taksit.sira_no;
                else
                   update cbs_hesap_kredi_taksit
                   set   gecikme_faiz_tutari = case when nvl(gecikme_faiz_tutari,0)  + nvl(ln_tahsil_tutar,0)  >0 then  nvl(gecikme_faiz_tutari,0) +  nvl(ln_tahsil_tutar,0) else 0 end           	
                   where hesap_No = r1.hesap_no and sira_no = c_taksit.sira_no;            
                end if;
                
              ln_kalan_tahsil_tutar  :=nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_tutar,0);
          end if;                    
     end loop;     
       
       -- ln_kalan_tahsil_tutar >0 ise son taksit uzerine guncelleyelim 
         if nvl(ln_kalan_tahsil_tutar,0)  > 0 then 
             if   r1.birikmisgecfaiz_artieksi ='-' then      
              
                   update cbs_hesap_kredi_taksit
                   set   gecikme_faiz_tutari = case when nvl(gecikme_faiz_tutari,0)  - nvl(ln_kalan_tahsil_tutar,0)  >0 then  nvl(gecikme_faiz_tutari,0)  - nvl(ln_kalan_tahsil_tutar,0) else nvl(gecikme_faiz_tutari,0) end           	
                   where hesap_No = r1.hesap_no and sira_no = r_taksit.sira_no;
                else
                
                   update cbs_hesap_kredi_taksit
                   set   gecikme_faiz_tutari = case when nvl(gecikme_faiz_tutari,0)  + nvl(ln_kalan_tahsil_tutar,0)  >0 then  nvl(gecikme_faiz_tutari,0) +  nvl(ln_kalan_tahsil_tutar,0) else nvl(gecikme_faiz_tutari,0) end           	
                   where hesap_No = r1.hesap_no and sira_no = r_taksit.sira_no;            
                end if;
         end if;      
   end if;
 
-- taksit penaltyamount artt?r?m azalt?m 
  ln_kalan_tahsil_tutar := 0;
  ln_tahsil_tutar       := 0;
    
   if nvl(r1.penaltyamount_arteksitutar,0) <> 0  and   r1.penaltyamount_artieksi is not null then     
    ln_kalan_tahsil_tutar := r1.penaltyamount_arteksitutar;    
    for c_taksit in cur_taksit
       loop        
         r_taksit := c_taksit;    
          if  nvl(c_taksit.unpaid_penalty_amount,0) >= 0  and nvl(ln_kalan_tahsil_tutar,0)  >= 0 then         
                if  nvl(c_taksit.unpaid_penalty_amount,0) > nvl(ln_kalan_tahsil_tutar,0) then
                    ln_tahsil_tutar  :=  nvl(ln_kalan_tahsil_tutar,0) ;
                 else
                     ln_tahsil_tutar := nvl(c_taksit.unpaid_penalty_amount,0) ;
                 end if;   
                 
                 if nvl(ln_tahsil_tutar,0) <0 then 
                    ln_tahsil_tutar := 0;
                 end if;
           
                if   r1.penaltyamount_artieksi ='-' then         
                   update cbs_hesap_kredi_taksit
                   set   penalty_amount = case when nvl(penalty_amount,0)  - nvl(ln_tahsil_tutar,0)  >0 then  nvl(penalty_amount,0)  - nvl(ln_tahsil_tutar,0) else 0 end           	
                   where hesap_No = r1.hesap_no and sira_no = c_taksit.sira_no;
                else
                   update cbs_hesap_kredi_taksit
                   set   penalty_amount = case when nvl(penalty_amount,0)  + nvl(ln_tahsil_tutar,0)  >0 then  nvl(penalty_amount,0) +  nvl(ln_tahsil_tutar,0) else 0 end           	
                   where hesap_No = r1.hesap_no and sira_no = c_taksit.sira_no;            
                end if;
            ln_kalan_tahsil_tutar  :=nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_tutar,0);
          end if;                    
      end loop;    
         -- ln_kalan_tahsil_tutar >0 ise son taksit uzerine guncelleyelim 
         if nvl(ln_kalan_tahsil_tutar,0)  > 0 then 
             if   r1.penaltyamount_artieksi ='-' then         
                   update cbs_hesap_kredi_taksit
                   set   penalty_amount = case when nvl(penalty_amount,0)  - nvl(ln_kalan_tahsil_tutar,0)  >0 then  nvl(penalty_amount,0)  - nvl(ln_kalan_tahsil_tutar,0) else penalty_amount end           	
                   where hesap_No = r1.hesap_no and sira_no = r_taksit.sira_no;
                else
                   update cbs_hesap_kredi_taksit
                   set   penalty_amount = case when nvl(penalty_amount,0)  + nvl(ln_kalan_tahsil_tutar,0)  >0 then  nvl(penalty_amount,0) +  nvl(ln_kalan_tahsil_tutar,0) else penalty_amount end           	
                   where hesap_No = r1.hesap_no and sira_no = r_taksit.sira_no;            
                end if;
         end if;
                
   end if;
 
 
  -- e-o-m seval.colak 28062022   
	exception
	when islem_bulunamadi_exception then
		raise_application_error(-20100,l_uc || '1389'|| l_ara || pn_islem_no || l_uc);
    when dk_bulunamadi_exception then
  		raise_application_error(-20100,l_uc || '1163'|| l_uc);
  	when iliskili_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '700' || pkg_hata.getdelimiter ||r1.iliskili_hesap_no || pkg_hata.getdelimiter ||r1.dk_grup_kod || pkg_hata.getdelimiter || r1.modul_tur_kod  || pkg_hata.getdelimiter ||  r1.urun_tur_kod  || pkg_hata.getdelimiter || r1.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   when iliskili_faizrees_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '701' || pkg_hata.getdelimiter || r1.iliskili_hesap_no || pkg_hata.getdelimiter ||r1.dk_grup_kod || pkg_hata.getdelimiter || r1.modul_tur_kod  || pkg_hata.getdelimiter ||  r1.urun_tur_kod  || pkg_hata.getdelimiter || r1.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   when gecikme_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6863' || pkg_hata.getdelimiter ||  r1.hesap_no || pkg_hata.getdelimiter ||r1.dk_grup_kod || pkg_hata.getdelimiter || r1.modul_tur_kod  || pkg_hata.getdelimiter ||   r1.urun_tur_kod  || pkg_hata.getdelimiter || r1.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   when others then
    raise_application_error(-20100,pkg_hata.getucpointer || '507' || pkg_hata.getdelimiter || to_char(sqlcode) ||'-'||to_char(sqlerrm) || pkg_hata.getdelimiter || pkg_hata.getucpointer); 

END;
---------------------------------------------------------------------------
PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER ) IS
BEGIN
null;
	--RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '699' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER); --seval.colak 170120223
END;
---------------------------------------------------------------------------
PROCEDURE Guncelleme_Kontrolu(pn_islem_no NUMBER,ps_block	VARCHAR2,ps_rowid   VARCHAR2,
  							   ps_column VARCHAR2,pd_column VARCHAR2,ps_oldvalue IN OUT VARCHAR2)
IS
	guncellenmis_exception			   EXCEPTION;
	ln_retval			  NUMBER:=0;
	ls_sqlstr			  VARCHAR2(2000);
	ls_sql_template		  VARCHAR2(2000);
	ls_source_table		  VARCHAR2(2000);
	ls_dest_table		  VARCHAR2(2000);
BEGIN
	IF ps_block='CBS_HESAP_KREDI_ISLEM' THEN
		--TODO 1: Set the source and destination table names
		ls_source_table:='CBS_HESAP_KREDI_ISLEM';
		ls_dest_table:='CBS_HESAP_KREDI';
		IF ps_column<>'HESAP_NO' AND ps_column<>'TX_NO'  THEN
			--TODO 2: Set the Primary Key Count (Default 1)
			ls_sql_template:=Pkg_Guncel.DifferenceTemplateSingleRecord(1);
			--TODO 3: Do not alter until next TODO :)
			ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
			ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_COLUMN',pd_column);
			ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_TABLE',ls_source_table);
			ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_COLUMN',ps_column);
			ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_ROWID',ps_rowid);
			--TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

			ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_PK1','HESAP_NO');
			ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_PK1','HESAP_NO');
			--insert into cbs_yphavale_test values(ls_sql_template);
			EXECUTE IMMEDIATE ls_sql_template INTO ln_retval,ps_oldvalue;
		END IF;
	END IF;
	IF ln_retval<>1 THEN
		RAISE  guncellenmis_exception;
	END IF;
	EXCEPTION
		WHEN  guncellenmis_exception THEN
			RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '449' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
		WHEN OTHERS THEN
			RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '449' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
END;
---------------------------------------------------------------------------
FUNCTION Sf_rowid_al(pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE ) RETURN VARCHAR2
IS
	ls_ret VARCHAR2(2000);
BEGIN
	SELECT ROWID
	INTO ls_ret
	FROM CBS_HESAP_KREDI
	WHERE hesap_no = pn_hesap_no;

	RETURN ls_ret;

	EXCEPTION
	WHEN OTHERS THEN
	RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '450' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
---------------------------------------------------------------------------
PROCEDURE sf_sch_faizorani_guncelle(pn_islem_no NUMBER)
IS
 CURSOR c_0 IS
  SELECT *
    FROM CBS_HESAP_KREDI_ISLEM
   WHERE  tx_no = pn_islem_no
   FOR UPDATE ;

  ln_yeni_oran  NUMBER;
  ld_start DATE;
BEGIN
  FOR r_0 IN c_0 LOOP
    IF r_0.temdit_tarihi IS NULL THEN
	  ld_start := r_0.acilis_tarihi;
	ELSE
	  ld_start := r_0.temdit_tarihi;
	END IF;
    ln_yeni_oran := Pkg_Scf.Vadeli_sch_faiz_orani(r_0.musteri_no,
        						  NVL(r_0.endeks_doviz_kodu,r_0.doviz_kodu),
								  r_0.modul_tur_kod, r_0.urun_tur_kod, r_0.urun_sinif_kod,
								  r_0.kredi_vade - ld_start,  r_0.sch_faiz_tur,'E',r_0.kredi_vade );
    UPDATE CBS_HESAP_KREDI_ISLEM
	   SET sch_faiz_orani = ln_yeni_oran
	 WHERE CURRENT OF c_0;
   END LOOP;
END;
---------------------------------------------------------------------------
PROCEDURE sp_faiz_komisyondk(pn_hesap_no NUMBER ,pn_faiz_oran NUMBER DEFAULT NULL,pn_komisyon_oran NUMBER DEFAULT NULL )
IS
   ls_kredi_hesap_doviz_kodu  			 CBS_HESAP_KREDI.doviz_kodu%TYPE;
   iliskili_faiz_dk_yok  			 	 EXCEPTION;
   iliskili_kom_dk_yok   	   			 EXCEPTION;
   iliskili_komrees_dk_yok    			 EXCEPTION;
   iliskili_faizrees_dk_yok				 EXCEPTION;
   faizdovizyok							 EXCEPTION;
   ls_dk_grup_kod			CBS_MUSTERI.DK_GRUP_KOD%TYPE;
   ls_modul_tur_kod			CBS_HESAP.modul_tur_kod%TYPE;
   ls_urun_tur_kod			CBS_HESAP.urun_tur_kod%TYPE;
   ls_urun_sinif_kod		CBS_HESAP.urun_sinif_kod%TYPE;
   ls_komreesdk  			VARCHAR2(2000);
   ls_faizreesdk      		VARCHAR2(2000);
   ls_komdk  			    VARCHAR2(2000);
   ls_faizdk      		    VARCHAR2(2000);
   ls_hesap_no				CBS_HESAP_KREDI.hesap_no%TYPE;
   ls_bolum_kodu			CBS_HESAP_KREDI.sube_kodu%TYPE;
   ls_var					VARCHAR2(1) := NULL;
   ls_dk					VARCHAR2(2000);
   ls_doviz					CBS_HESAP_KREDI.doviz_kodu%TYPE;
BEGIN
	SELECT doviz_kodu,
		  Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no),
	      modul_tur_kod,
 		  urun_tur_kod,
		  urun_sinif_kod,
		  SUBE_KODU
	INTO   ls_kredi_hesap_doviz_kodu,
		  ls_dk_grup_kod,
	      ls_modul_tur_kod,
 		  ls_urun_tur_kod,
		  ls_urun_sinif_kod,
		  ls_bolum_kodu
	FROM CBS_HESAP_KREDI
	WHERE hesap_no = pn_hesap_no;

	IF NVL(pn_faiz_oran,0) <> 0 THEN
		/*faiz gelir dk */
	    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
	 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 2,
	 					   NULL,NULL, NULL,ls_faizdk);
		  IF ls_faizdk IS NULL THEN
		  	 RAISE iliskili_faiz_dk_yok;
		  END IF;

	/*faiz reeskont dk */
	 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
	 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 4,
	 					   NULL,NULL, NULL,ls_faizreesdk);
		  IF 	ls_faizreesdk IS NULL  THEN
		  		RAISE iliskili_faizrees_dk_yok;
		  END IF;
	/*faizrees*/
	  	 ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_faizreesdk,ls_kredi_hesap_doviz_kodu);
		 IF ls_var <> 'E' THEN
		 	ls_dk := ls_faizreesdk;
			ls_doviz:= ls_kredi_hesap_doviz_kodu;
		    RAISE faizdovizyok;
		 END IF;

	/*faiz tl */
		 ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_faizdk,Pkg_Genel.lc_al);
		 IF ls_var <> 'E' THEN
		 	ls_dk := ls_faizdk;
			ls_doviz:= Pkg_Genel.lc_al;
		   RAISE faizdovizyok;
		 END IF;
	 END IF;
	 IF NVL(pn_komisyon_oran,0) <>0  THEN
	/*komisyon dk */

	 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
	 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 5,
	 					   NULL,NULL, NULL,ls_komdk);

		  IF ls_komdk IS NULL THEN
		  		RAISE iliskili_kom_dk_yok;
		  END IF;

	/*komisyon reeskont dk */
	 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
	 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 6,
	 					   NULL,NULL, NULL,ls_komreesdk);

		  IF 	ls_komreesdk IS NULL   THEN
		  		RAISE iliskili_komrees_dk_yok;
		  END IF;

	/*komrees*/
	  	 ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_komreesdk,ls_kredi_hesap_doviz_kodu);
		 IF ls_var <> 'E' THEN
		 	ls_dk := ls_komreesdk;
			ls_doviz:= ls_kredi_hesap_doviz_kodu;
		    RAISE faizdovizyok;
		 END IF;

	/*komis tl */
		 ls_var:= Pkg_Muhasebe.DK_VARMI(ls_bolum_kodu,ls_komdk,Pkg_Genel.lc_al);
		 IF ls_var <> 'E' THEN
		 	ls_dk := ls_komdk;
			ls_doviz:= Pkg_Genel.lc_al;
		   RAISE faizdovizyok;
		 END IF;

	END IF;
	 EXCEPTION
	   WHEN iliskili_faiz_dk_yok THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '700' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
	   WHEN iliskili_faizrees_dk_yok THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '701' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
	   WHEN iliskili_kom_dk_yok THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '702' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
	   WHEN iliskili_komrees_dk_yok THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '703' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
	   WHEN faizdovizyok THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '704' || Pkg_Hata.getdelimiter || ls_dk||  Pkg_Hata.getdelimiter || ls_bolum_kodu|| Pkg_Hata.getdelimiter ||ls_doviz|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
END;

 FUNCTION sme_adi(ps_tip VARCHAR2) RETURN VARCHAR2 IS
      ls_ret VARCHAR2(20);
   BEGIN
      SELECT aciklama
        INTO ls_ret
        FROM CBS.cbs_musteri_sme_kodlari
       WHERE musteri_tipi = ps_tip;

      RETURN ls_ret;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN NULL;
   END;

--*************************************************************************************--
begin
	pn_1304_reeskont_dk    := Pkg_Muhasebe.parametre_index_bul('1304_REESKONT_DK');
    pn_1304_faiz_dk        := Pkg_Muhasebe.parametre_index_bul('1304_FAIZ_DK');
    pn_1304_gecikme_faiz_dk := Pkg_Muhasebe.parametre_index_bul('1304_GECIKME_FAIZ_DK');
    pn_1304_bolum_kodu    := Pkg_Muhasebe.parametre_index_bul('1304_BOLUM_KODU');
    pn_1304_deduction_lc    := Pkg_Muhasebe.parametre_index_bul('1304_DEDUCTION_LC');
    pn_1304_decrease_last_month_lc    := Pkg_Muhasebe.parametre_index_bul('1304_DECREASE_LAST_MONTH_LC');
    pn_1304_deduction_fc    := Pkg_Muhasebe.parametre_index_bul('1304_DEDUCTION_FC');
    pn_1304_decrease_last_month_fc    := Pkg_Muhasebe.parametre_index_bul('1304_DECREASE_LAST_MONTH_FC');
    pn_1304_banka_aciklama    := Pkg_Muhasebe.parametre_index_bul('1304_BANKA_ACIKLAMA');
    pn_1304_musteri_aciklama    := Pkg_Muhasebe.parametre_index_bul('1304_MUSTERI_ACIKLAMA');
    pn_1304_doviz_kodu    := Pkg_Muhasebe.parametre_index_bul('1304_DOVIZ_KODU');
    pn_1304_mb_kur    := Pkg_Muhasebe.parametre_index_bul('1304_MB_KUR');
    pn_1304_kredi_hesap    := Pkg_Muhasebe.parametre_index_bul('1304_KREDI_HESAP');
    pn_1304_birikmis_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('1304_BIRIKMIS_FAIZ_LC');
    pn_1304_birikmis_faiz_fc    := Pkg_Muhasebe.parametre_index_bul('1304_BIRIKMIS_FAIZ_FC');
    pn_1304_accrued_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_INT_TAX_LC');
    pn_1304_accrued_int_tax_fc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_INT_TAX_FC');
    pn_1304_accrued_delayed_int_lc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_DELAYED_INT_LC');
    pn_1304_accrued_delayed_int_fc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_DELAYED_INT_FC');
    pn_1304_penalty_amount_lc    := Pkg_Muhasebe.parametre_index_bul('1304_PENALTY_AMOUNT_LC');
    pn_1304_penalty_amount_fc    := Pkg_Muhasebe.parametre_index_bul('1304_PENALTY_AMOUNT_FC');
    pn_1304_nonaccrued_delayed_int_lc    := Pkg_Muhasebe.parametre_index_bul('1304_NONACCRUED_DELAYED_INT_LC');
    pn_1304_nonaccrued_delayed_int_fc    := Pkg_Muhasebe.parametre_index_bul('1304_NONACCRUED_DELAYED_INT_FC');
    pn_1304_accrued_int_lc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_INT_LC');
    pn_1304_accrued_int_fc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_INT_FC');
    pn_1304_nonaccrued_int_lc    := Pkg_Muhasebe.parametre_index_bul('1304_NONACCRUED_INT_LC');
    pn_1304_nonaccrued_int_fc    := Pkg_Muhasebe.parametre_index_bul('1304_NONACCRUED_INT_FC');
    pn_1304_accrued_delayed_int_tx_lc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_DELAYED_INT_TX_LC');
    pn_1304_accrued_delayed_int_tx_fc    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUED_DELAYED_INT_TX_FC');
    pn_1304_delayed_int_lc    := Pkg_Muhasebe.parametre_index_bul('1304_DELAYED_INT_LC');
    pn_1304_delayed_int_fc    := Pkg_Muhasebe.parametre_index_bul('1304_DELAYED_INT_FC');
    pn_1304_accrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUAL_INT_ACCT_NO');
    pn_1304_accrual_tax_acct_no    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUAL_TAX_ACCT_NO');
    pn_1304_accrual_delay_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('1304_ACCRUAL_DELAY_INT_ACCT_NO');
    pn_1304_nonaccrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('1304_NONACCRUAL_INT_ACCT_NO');
    pn_1304_nonaccrual_delay_int_acct    := Pkg_Muhasebe.parametre_index_bul('1304_NONACCRUAL_DELAY_INT_ACCT');
    pn_1304_birikmisfaiz_arti    := Pkg_Muhasebe.parametre_index_bul('1304_BIRIKMISFAIZ_ARTI');
    pn_1304_birikmisfaiz_eksi    := Pkg_Muhasebe.parametre_index_bul('1304_BIRIKMISFAIZ_EKSI');
    pn_1304_gekimis_faiz_arti    := Pkg_Muhasebe.parametre_index_bul('1304_GEKIMIS_FAIZ_ARTI');
    pn_1304_gekimis_faiz_eksi    := Pkg_Muhasebe.parametre_index_bul('1304_GEKIMIS_FAIZ_EKSI');
    pn_1304_penalty_amount_arti    := Pkg_Muhasebe.parametre_index_bul('1304_PENALTY_AMOUNT_ARTI');
    pn_1304_penalty_amount_eksi    := Pkg_Muhasebe.parametre_index_bul('1304_PENALTY_AMOUNT_EKSI');
    pn_1304_lc    := Pkg_Muhasebe.parametre_index_bul('1304_LC');
    pn_1304_fc    := Pkg_Muhasebe.parametre_index_bul('1304_FC');
    pn_1304_penalty_gl    := Pkg_Muhasebe.parametre_index_bul('1304_PENALTY_GL');   --seval.colak 01112022

END;
/

