create PACKAGE BODY     PKG_INT_PAYMENT_TRX IS

FUNCTION PostInstantInstitutionPayment(ps_lang varchar2,
                                       ps_iban varchar2,
                                       ps_institution_code varchar2,
                                       ps_ins_number_extension_code varchar2,
                                       ps_institution_account_number varchar2,
                                       ps_amount varchar2,
                                       ps_description varchar2,
                                       ps_channel_code varchar2 default '1',
                                       ps_user_code varchar2 default 'CINT_CALLER',  
                                       pc_ref OUT CursorReferenceType,
                                       pc_ref2 OUT CursorReferenceType,
                                       pc_ref3 OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2 (20);
ls_product_type_code varchar2 (20);
ls_product_class_code varchar2 (20);
ln_role number := 7777;     
ln_channel_code number; 
ln_source_account number;
ln_toaccno number;
ln_amount number;
ls_branch_code varchar2 (3);
ls_currency_code varchar2 (10);
ln_source_customer number;
ln_cash_code number;
exacc_b varchar2 (16);
exacc_a varchar2 (16);
ls_target_iban varchar2(16 byte);
ls_istatistik_kodu varchar2 (10);
ls_prefix_stat varchar2 (4);


ps_phone_area_code varchar2(10 byte);
ps_phone_no varchar2(50 byte);
ps_service_code varchar2(10 byte);
ps_service_no varchar2(50 byte);   

ls_commission_type_bank varchar2 (10);
ls_commission_type_company varchar2 (10);
ln_commission_amount_bank number;
ln_commission_amount_company number;
ln_commission_rate_bank number;
ln_commission_rate_company number;

ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_initial_balance number;
ln_final_balance number;
 
ln_min_digit_number number;
ln_max_digit_number number;
ln_min_payment_amount number;
ln_max_payment_amount number;

ln_count_mobile number := 0;
ln_count_service number := 0;

ls_returncode varchar2 (3) := '000';
ls_returncodepay24 varchar2(100 char);

notenoughbalance  exception;
error_number_extension exception;
error_not_found exception;
BEGIN

    ln_transaction_number := pkg_tx.islem_no_al;
    ln_transaction_code := 6330;
    ln_channel_code := to_number(ps_channel_code); 
    
    select hesap_no, musteri_no, doviz_kodu, sube_kodu
        into ln_source_account, ln_source_customer, ls_currency_code, ls_branch_code
           from cbs_hesap where external_hesap_no = ps_iban;
    
    pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
    
      select min_digit_number, 
            max_digit_number, 
            min_payment_amount, 
            max_payment_amount
          into 
            ln_min_digit_number,
            ln_max_digit_number,
            ln_min_payment_amount,
            ln_max_payment_amount
          from cbs_tahsilat_kurum_tanim 
                   where durum_kodu = 'AKTIF' 
                                and ib_visible = 'Y' 
                                and kurum_kodu = ps_institution_code;
                                
     
    if length(ps_institution_account_number) < ln_min_digit_number or length(ps_institution_account_number) > ln_max_digit_number then 
        return '459';
    end if;
           
    ln_amount := to_number(ps_amount,'999999999999999.9999');
    
    if ln_amount < ln_min_payment_amount or ln_amount > ln_max_payment_amount then
        return '460';
    end if;
    
    if ps_institution_code in ('INTAL LLC FOR RENT', 'INTAL LLC FOR SECURITY', 'INTAL LLC FOR ELECTRICITY', 'ПОМОГАТЬ ЛЕГКО', 'ПОМОЩЬ ПОСТРАДАВШИМ В ТУРЦИИ', 'ПОМОЩЬ') then
    
     ls_target_iban := PKG_INT_PAYMENT_INQ.GetIntalLlcIban(ps_institution_code);
     
     if ls_target_iban is null then
         raise error_not_found;
     end if;
     
     ls_returncode := PKG_INT_TRANSFER_TRX.PostBookToBookTransfer(ps_lang => ps_lang,
                                ps_source_iban => ps_iban,
                                ps_target_iban => ls_target_iban,
                                ps_amount => ps_amount,
                                ps_description => ps_description,
                                ps_transafer_type => 'b2ob',
                                ps_channel_code => ps_channel_code,
                                ps_user_code => ps_user_code,            
                                pc_ref => pc_ref,
                                pc_ref2 => pc_ref2,
                                pc_ref3 => pc_ref3);
                                
       return ls_returncode;  
                             
    end if;
    
    exacc_b := to_char(pkg_hesap.external_hesapno_al(ln_source_account));
    
    ln_toaccno := to_number('1180000029223680');
    exacc_a := lpad(ln_toaccno,16,'0');
    ln_toaccno := pkg_hesap.gethesapnofromexternal(exacc_a, ls_currency_code);

    ls_prefix_stat := null;

    ls_istatistik_kodu:='022902';

    ls_module_type_code := pkg_tahsilat_islemleri.modul_tur_tahsilat ;
    ls_product_type_code := pkg_tahsilat_islemleri.urun_tur_kod(2); -- ONLINE
    ls_product_class_code := 'ACCOUNT';


     if ps_ins_number_extension_code is not null then
         select count(*) into ln_count_mobile from cbs_tahsilat_kurum_telalan_kod where kurum_kodu = ps_institution_code
                      and alan_kodu = ps_ins_number_extension_code;
                      
         select count(*) into ln_count_service from cbs_tahsilat_kurum_service_kod where kurum_kodu = ps_institution_code
                      and service_kodu = ps_ins_number_extension_code;
     
         if ln_count_mobile > 0 then
           ps_phone_area_code := ps_ins_number_extension_code;
           ps_phone_no := ps_institution_account_number; 
         elsif ln_count_service > 0 then
           ps_service_code := ps_ins_number_extension_code;
           ps_service_no := ps_institution_account_number; 
         else
           raise error_number_extension;
         end if;
     else
       ps_service_no := ps_institution_account_number; 
     end if;
                                    
    
   
    
    ls_returncode := PKG_INT_PAYMENT_INQ.GetPayInstCommission(ps_institution_code => ps_institution_code,
                               ps_amount => ps_amount, 
                               ps_commission_type_bank => ls_commission_type_bank,
                               ps_commission_type_company => ls_commission_type_company,
                               pn_commission_amount_bank => ln_commission_amount_bank,
                               pn_commission_amount_company => ln_commission_amount_company,
                               pn_commission_rate_bank => ln_commission_rate_bank,
                               pn_commission_rate_company => ln_commission_rate_company);
                               

                               
   ln_commission_amount := ln_commission_amount_bank + ln_commission_amount_company;
   
   ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
                                                                      
   ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
   
     if ln_final_balance < 0 then
        raise notenoughbalance;
     end if;

   insert into cbs_tahsilat_ana_islem(islem_no, 
                                       tahsilat_tarihi, 
                                       tahsil_sekli, 
                                       musteri_no, 
                                       hesap_no, 
                                       isim_unvan, 
                                       doviz_kodu, 
                                       odeme_sekli, 
                                       tahsilat_kanali)
                                values (ln_transaction_number, 
                                        pkg_muhasebe.banka_tarihi_bul, 
                                        ls_product_class_code,
                                        ln_source_customer, 
                                        ln_source_account, 
                                        pkg_musteri.sf_musteri_adi(ln_source_customer), 
                                        ls_currency_code, 
                                        6, 
                                        1) ; 

   insert into cbs_tahsilat_detay_islem(islem_no,
                                            kurum_kodu,
                                            tutar,
                                            telefon_alan_kod,
                                            telefon_no,
                                            service_kodu,
                                            kurum_ozel_no,
                                            sira_no,
                                            abone_adi,
                                            payment_id,
                                            commission_type_bank,
                                            commission_type_company,
                                            commission_amount_bank,
                                            commission_amount_company,
                                            commission_rate_bank,
                                            commission_rate_company)
                                       values (ln_transaction_number,
                                               ps_institution_code,
                                               ln_amount,
                                               ps_phone_area_code,
                                               ps_phone_no,
                                               ps_service_code,
                                               ps_service_no,
                                               1,
                                               ps_description,
                                               pkg_genel.genel_kod_al ('INVOICE_PAYMENT_ID'),
                                               ls_commission_type_bank,
                                               ls_commission_type_company,
                                               ln_commission_amount_bank,
                                               ln_commission_amount_company,
                                               ln_commission_rate_bank,
                                               ln_commission_rate_company);
                                               
    
    pkg_int_api.create_transaction(ln_transaction_number,
                                   ln_transaction_code,
                                   ls_module_type_code,
                                   ls_product_type_code,
                                   ls_product_class_code,
                                   ln_amount,
                                   ls_branch_code,
                                   ls_branch_code,
                                   ln_role,
                                   ls_currency_code,
                                   ln_source_customer,
                                   ln_source_account,
                                   ln_cash_code,
                                   ln_channel_code,
                                   ps_user_code);

      pkg_int_api.process_transaction(ln_transaction_number);
     
      if ln_commission_amount_bank > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount_bank * ln_tax_rate / 100;
     else
       ln_tax_rate := 0;
       ln_tax := 0;   
     end if;  
     
     
   open pc_ref for 
           select ln_transaction_number as transaction_number,
                  ln_amount as amount,
                  ls_currency_code as currency_code, 
                  ln_initial_balance as initial_balance,
                  ln_final_balance as final_balance,
                  sysdate as transaction_date from dual;
     
    open pc_ref2 for
          select 
               'commission' as name, 
               'bank' as client, 
               ln_commission_amount_bank + ln_commission_amount_company - ln_tax as amount, 
               pkg_genel.lc_al as currency_code from dual
--          union
--           select 
--               'commission' as name, 
--               'dealer' as client, 
--               ln_commission_amount_company as amount, 
--               pkg_genel.lc_al as currency_code from dual
         union
           select 
               'tax' as name, 
               'bank' as client, 
               ln_tax as amount, 
               pkg_genel.lc_al as currency_code from dual;
               
    open pc_ref3 for
        select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;        


   return ls_returncode;
   
EXCEPTION
     when notenoughbalance then
         rollback;
         return '456';
    when error_number_extension then
         rollback;
         return '455';
    when error_not_found then
         rollback;
         return '454';
    when no_data_found then
         rollback;
         return '454';    
    when others then
        log_at('PostInstantInstitutionPayment', ps_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;

         ls_returncodepay24 := pkg_int_payment_inq.getpay24errorcode(to_char(ln_transaction_number));
          
         if ls_returncodepay24 is not null then
            return ls_returncodepay24;
         end if;
         
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         
         return ls_returncode;            
END;

FUNCTION PostTaxPayment(ps_lang varchar2,
                        ps_iban varchar2,
                        ps_tax_number varchar2, 
                        ps_type_code varchar2,
                        ps_region_code varchar2,
                        ps_district_code varchar2,
                        ps_sub_district_code varchar2,
                        ps_vehicle_plate varchar2,
                        ps_amount varchar2,
                        ps_channel_code varchar2 default '1',
                        ps_user_code varchar2 default 'CINT_CALLER',  
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_role number := 7777;
ls_prv_txn varchar2(100);
ls_res varchar2(100);

ls_eftdate varchar2(10);
ls_makedatetime varchar2(20) := to_char(sysdate, 'yyyymmddhh24miss');

ls_param_val corpint.tbl_int_parametre.param_val%type;
ls_parent_code corpint.tbl_int_parametre.parent_code%type;
ls_explanation corpint.tbl_int_parametre.explanation%type;
ls_param_option corpint.tbl_int_parametre.param_option%type;
ls_sub_district corpint.tbl_int_parametre.explanation%type;
ls_description corpint.tbl_txtodo.field10%type;

ln_txid number;
ln_amount number;
ls_vehicle_plate varchar2(50); 

ln_source_account number;
ln_source_customer number;
ls_source_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);

ls_sur_name varchar2(200);
ln_initial_balance number;

ls_ws_osmp_txn_id varchar2(100);
ls_ws_result varchar2(100);
ls_ws_comment varchar2(100);
ls_ws_field1 varchar2(100);
ls_ws_field2 varchar2(100);   

ls_description_payment varchar2(200);

pc_result1 CursorReferenceType;
pc_result2 CursorReferenceType;
pc_ref_local CursorReferenceType;

ls_returncode varchar2(3):='000';
notenoughbalance exception;
daterror exception;
no_data_found_from_ws exception;
begin
 

    ls_returncode := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', pc_result1);

    if (ls_returncode <> '000') then
        raise daterror;
    end if;
    
    ls_description_payment := pkg_int_payment_inq.gettaxtypename(ps_lang, ps_type_code) || ' '  ||  pkg_int_payment_inq.gettaxregionname(ps_lang, ps_region_code) || ' '  ||  pkg_int_payment_inq.gettaxdistrictname(ps_lang, ps_district_code) || ' '  ||  pkg_int_payment_inq.gettaxsubdistrictname(ps_lang, ps_sub_district_code) || ' ' || ps_vehicle_plate;
    

    fetch pc_result1 into ls_eftdate, ls_res, ls_res, ls_res, ls_res;
    close pc_result1;

    -- get treasury account info
    select param_val, parent_code, explanation, param_option
    into ls_param_val, ls_parent_code, ls_explanation, ls_param_option
    from corpint.tbl_int_parametre t
    where param_code='TAX_ROK'
    and (parent_code = ps_district_code or parent_code is null)
    and (param_option = nvl(ps_sub_district_code, param_option) or param_option is null or param_option = 'DEFAULT')
    and lang_cd='RUS'
    and rownum = 1;

    -- get tax type explanation
    select explanation into ls_description
    from corpint.tbl_int_parametre t
    where param_code='TAX_TYPE'
    and (parent_code = '' or parent_code is null)
    and (param_option = nvl('', param_option) or param_option is null or param_option = 'DEFAULT')
    and lang_cd='RUS'
    and param_val = ps_type_code
    and rownum = 1;

    -- get subdistrict explanation
    if (length(ps_sub_district_code) > 0) then
        select explanation into ls_sub_district
        from corpint.tbl_int_parametre t
        where param_code='TAX_SUB_DISTRICT'
        and (parent_code = ps_district_code or parent_code is null)
        and (param_option = nvl('', param_option) or param_option is null or param_option = 'DEFAULT')
        and lang_cd='RUS'
        and param_val = ps_sub_district_code
        and rownum = 1;
    else
        ls_sub_district := '';
    end if;

 
    if ps_vehicle_plate is not null and ps_vehicle_plate != '' then
        ls_vehicle_plate := ', гос. № ' || ps_vehicle_plate;
    end if;
  
    select hesap_no, musteri_no, doviz_kodu, sube_kodu
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code
          from cbs_hesap where external_hesap_no = ps_iban;
       
    pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
          
    ls_returncode := PKG_INT_PAYMENT_INQ.GetWsTaxInfo(ps_tax_number, pc_ref_local);
    
    if ls_returncode <> '000' then
        raise no_data_found_from_ws;
    end if; 
      
                                              
    loop
        fetch pc_ref_local into 
                ls_ws_osmp_txn_id,
                ls_ws_result,
                ls_ws_comment,
                ls_ws_field1,
                ls_ws_field2;
        exit when pc_ref_local%notfound;  
    end loop;
    close pc_ref_local;  
     
    if ls_ws_field1 is not null then
        ls_sur_name := ls_ws_field1;
    else
        raise no_data_found_from_ws;
    end if;


    ls_returncode := corpint2.pkg_todo.createtaxpayments('TAXPAYMENT',
                                                       ps_tax_number,
                                                       'sAPPROVE' ,
                                                       ln_source_account,
                                                       ps_tax_number  ,
                                                       ps_type_code || ';' || ps_region_code || ';' || ps_district_code || ';' || ps_sub_district_code,
                                                       ln_amount  ,
                                                       'KGS'   ,
                                                       pkg_message.split(ls_param_val, ';',1) ,
                                                       ls_description || ', ' || ps_sub_district_code || ' ' || ls_sub_district || ls_vehicle_plate,
                                                       pc_result2);


    if (ls_returncode <> '000') then

        open pc_ref for
            select sysdate from dual;
            log_at('PostTaxPayment', 1, sqlerrm, dbms_utility.format_error_backtrace);
            
        return ls_returncode;

    end if;

    fetch pc_result2 into ln_txid;
    close pc_result2;

  

    select to_char(makedate, 'yyyymmddhh24miss') into ls_makedatetime
      from corpint2.tbl_tax_payments_todo
        where tx_no = ln_txid;

 
    ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
    ln_amount := to_number(ps_amount, '999999999.99');

  
    ls_returncode := pkg_int_transfer_trx.postclearingtransfer(ps_lang => ps_lang,
                              ps_source_iban => ps_iban,
                              ps_target_full_name => pkg_message.split(ls_explanation, ';',1),
                              ps_target_iban => pkg_message.split(ls_param_val, ';',1),
                              ps_bic_code => pkg_message.split(ls_param_val, ';',0) || ';' || pkg_message.split(ls_explanation, ';',0),
                              ps_payment_code => pkg_message.split(ps_type_code, ';',1),
                              ps_amount => ln_amount,
                              ps_description => ls_description_payment,
                              ps_transfer_type => 'taxPayment',
                              ps_tax_number => ps_tax_number,
                              ps_source_name => ls_sur_name,
                              ps_channel_code => ps_channel_code,
                              ps_user_code => ps_user_code, 
                              pc_ref => pc_ref, 
                              pc_ref2 => pc_ref2,
                              pc_ref3 => pc_ref3);

    if (ls_returncode <> '000') then

        open pc_ref for
            select sysdate from dual;
            log_at('PostTaxPayment', 2, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;   
        return ls_returncode;

    end if;


    update corpint2.tbl_tax_payments_todo
        set status='sEXECUTED',
            tax_tx_no = ln_transaction_number,
            tax_prv_tx_no = ls_prv_txn
            where tx_no = ln_txid;
    
    commit;
    return ls_returncode;
    
EXCEPTION
      when notenoughbalance then
            rollback;
            return '456';
      when no_data_found_from_ws then
            rollback;
            return '460';
      when daterror then
            rollback;
            return '461';
      when no_data_found then
            rollback;
            return '454';
      when others then 
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PostTaxPayment', ps_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         return ls_returncode;
END;
END;
/

