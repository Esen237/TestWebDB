create PACKAGE BODY PKG_TX1104 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

    Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
   ln_adet number := 0;
   ln_cek_no	  	   		    cbs_cek.cek_no%type;
   ld_keside_tarihi			    cbs_cek.keside_tarihi%type;
   ld_ibraz_tarihi			    cbs_cek.ibraz_tarihi%type;
   ln_ibraz_edilen_sube			cbs_cek.ibraz_edilen_sube%type;
   ln_cek_tutari				cbs_cek.cek_tutari%type;
   ls_cek_hamili_unvan		    cbs_cek.cek_hamili_unvan%type;
   ls_cek_hamili_adres		    cbs_cek.cek_hamili_adres%type;
   ls_cek_hamili_semt			cbs_cek.cek_hamili_semt%type;
   ls_cek_hamili_il_kod			cbs_cek.cek_hamili_il_kod%type;
   ln_cek_hamili_posta_kod	    cbs_cek.cek_hamili_posta_kod%type;
   ls_cek_hamili_ulke_kod		cbs_cek.cek_hamili_ulke_kod%type;

   cursor cur_cek_islem is
     select cek_no ,
	 		keside_tarihi,
			ibraz_tarihi,
			ibraz_edilen_sube,
			cek_tutari,
			cek_hamili_unvan,
			cek_hamili_adres,
			cek_hamili_semt,
			cek_hamili_il_kod,
			cek_hamili_posta_kod,
			cek_hamili_ulke_kod
	  from cbs_cek_islem
	  where tx_no = pn_islem_no ;


  Begin

/* islem bilgisi guncellenir */
    update cbs_cek_islem
	set   durum_kodu = 'A'
	where tx_no = pn_islem_no ;


/* ilgili cek numarasinin durum kodu karsiliksiz  = 'K' olarak guncellenir. */

	if cur_cek_islem%isopen then
		   close cur_cek_islem;
	 end if;

 open cur_cek_islem ;
  loop
  	  fetch cur_cek_islem into	ln_cek_no ,
						 		ld_keside_tarihi,
								ld_ibraz_tarihi,
								ln_ibraz_edilen_sube,
								ln_cek_tutari,
								ls_cek_hamili_unvan,
								ls_cek_hamili_adres,
								ls_cek_hamili_semt,
								ls_cek_hamili_il_kod,
								ln_cek_hamili_posta_kod,
								ls_cek_hamili_ulke_kod ;
    	exit when cur_cek_islem%notfound;

	    update cbs_cek
		set durum_kodu = 'K' ,
			keside_tarihi = ld_keside_tarihi ,
			ibraz_tarihi  = ld_ibraz_tarihi ,
			ibraz_edilen_sube = ln_ibraz_edilen_sube,
			cek_tutari 		  = ln_cek_tutari,
			cek_hamili_unvan  = ls_cek_hamili_unvan,
			cek_hamili_adres  = ls_cek_hamili_adres,
			cek_hamili_semt   = ls_cek_hamili_semt ,
			cek_hamili_il_kod = ls_cek_hamili_il_kod ,
			cek_hamili_posta_kod = ln_cek_hamili_posta_kod,
			cek_hamili_ulke_kod  = ls_cek_hamili_ulke_kod
		where  cek_no = ln_cek_no ;

  end loop;
  	 close 	 cur_cek_islem ;


  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '146' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	/* Red edildi */
    update cbs_cek_karne_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   Null;
  End;
END;
/

