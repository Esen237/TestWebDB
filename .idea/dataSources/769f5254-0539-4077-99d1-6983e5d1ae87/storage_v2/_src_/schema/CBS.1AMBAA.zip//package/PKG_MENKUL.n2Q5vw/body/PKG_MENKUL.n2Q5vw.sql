create PACKAGE BODY Pkg_Menkul IS
  FUNCTION Modul_Tur_Menkul RETURN VARCHAR2
  IS
  BEGIN
	 RETURN 'SECURITIES';
  END;

  FUNCTION  menkul_adi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_menkul_kiymet_adi 	 			CBS_MENKUL.adi%TYPE;
  BEGIN

  SELECT adi
  INTO   ls_menkul_kiymet_adi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod
  AND    durum_kodu = 'A'
  AND    referans_no IN (SELECT MAX(referans_no) FROM CBS_MENKUL
  		 			 	 WHERE  menkul_kiymet_kodu = ps_kod
  		 			 	 AND    durum_kodu = 'A') ;

	RETURN ls_menkul_kiymet_adi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
		  SELECT adi
		  INTO   ls_menkul_kiymet_adi
		  FROM   CBS_MENKUL
		  WHERE  menkul_kiymet_kodu = ps_kod
		  AND    durum_kodu = 'K'
		  AND    referans_no IN (SELECT MAX(referans_no) FROM CBS_MENKUL
		  		 			 	 WHERE  menkul_kiymet_kodu = ps_kod
		  		 			 	 AND    durum_kodu = 'K') ;

		  RETURN ls_menkul_kiymet_adi ;

	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2029' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION  menkul_kiymet_tipi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE ) RETURN NUMBER

   IS
    ls_tip						  	 	NUMBER;
  	ls_yatirimfon_TL 					VARCHAR2(10);
  	ls_yatirimfon_YP 					VARCHAR2(10);
  	ls_hissesenedi_TL 					VARCHAR2(10);
  	ls_hissesenedi_YP 					VARCHAR2(10);
  	ls_kiymaden_YP 						VARCHAR2(10);
	ls_urun_tur_kod   					CBS_MENKUL.urun_tur_kod%TYPE;
	ln_kote_oldugu_borsa_kodu  			CBS_MENKUL.kote_oldugu_borsa_kodu%TYPE;
	ls_kupon							CBS_MENKUL.kupon%TYPE;
  BEGIN
   --Aciklamalar;
	--ls_tip := 1; --Hissesenedi
	--ls_tip := 2; --Yatirimfonu
	--ls_tip := 3; --Kiymetlimaden
	--ls_tip := 4 ;--'Kuponlu'
	--ls_tip := 5 ;--'Kuponsuz

  /* Parametreden ilgili degerler alinir*/
	Pkg_Parametre.deger('SISTEM','TEKNIK',NULL,'G_YATIRIMFON_TL',ls_yatirimfon_TL);
	Pkg_Parametre.deger('SISTEM','TEKNIK',NULL,'G_YATIRIMFON_YP',ls_yatirimfon_YP);
	Pkg_Parametre.deger('SISTEM','TEKNIK',NULL,'G_HISSESENEDI_TL',ls_hissesenedi_TL);
	Pkg_Parametre.deger('SISTEM','TEKNIK',NULL,'G_HISSESENEDI_YP',ls_hissesenedi_YP);
	Pkg_Parametre.deger('SISTEM','TEKNIK',NULL,'G_KIYMADEN_YP',ls_kiymaden_YP);

    SELECT urun_tur_kod	,kote_oldugu_borsa_kodu,kupon
  	INTO   ls_urun_tur_kod	,ln_kote_oldugu_borsa_kodu,ls_Kupon
    FROM   CBS_MENKUL
    WHERE  menkul_kiymet_kodu = trim(ps_kod)
	AND    durum_kodu='A';

	IF ln_kote_oldugu_borsa_kodu  <> 0 THEN
	  	IF  ls_urun_tur_kod IN( ls_hissesenedi_TL  , ls_hissesenedi_YP) THEN
			 ls_tip := 1; --Hissesenedi
	  	ELSIF  ls_urun_tur_kod IN ( ls_yatirimfon_TL , ls_yatirimfon_YP) THEN
			 ls_tip := 2; --Yatirimfonu
	  	ELSIF  ls_urun_tur_kod  = ls_kiymaden_YP  THEN
			 ls_tip := 3; --Kiymetlimaden
		ELSIF ls_Kupon='E' THEN
		   	 ls_tip := 4 ;--'Kuponlu'
		ELSIF ls_Kupon='H' THEN
			 ls_tip := 5 ; --'Kuponsuz
	  	END IF;

	ELSIF ln_kote_oldugu_borsa_kodu  =0 THEN
		IF ls_Kupon='E' THEN
		   ls_tip := 4 ;--'Kuponlu'
		ELSE
			ls_tip := 5 ; --'Kuponsuz
		END IF;
	END IF;

	RETURN ls_tip ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2029' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_urun_turu_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_urun_tur	 			CBS_MENKUL.urun_tur_kod%TYPE;
  BEGIN

  SELECT DISTINCT urun_tur_kod
  INTO   ls_urun_tur
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_urun_tur	 ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_urun_sinifi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_urun_sinif	 			CBS_MENKUL.urun_sinif_kod%TYPE;
  BEGIN

  SELECT DISTINCT urun_sinif_kod
  INTO   ls_urun_sinif
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_urun_sinif	 ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3384' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_vade_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE
   IS
    ls_itfa_tarihi	 			CBS_MENKUL.itfa_tarihi%TYPE;
  BEGIN

  SELECT DISTINCT itfa_tarihi
  INTO   ls_itfa_tarihi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_itfa_tarihi	 ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_kupon_faiz_tipi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_kupon_faiz_tipi 			CBS_MENKUL.kupon_faiz_tipi%TYPE;
  BEGIN

  SELECT DISTINCT kupon_faiz_tipi
  INTO   ls_kupon_faiz_tipi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_kupon_faiz_tipi	 ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_kupon_endeks_turu_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
   IS
    ln_kupon_endeks_turu 			CBS_MENKUL.kupon_endeks_turu%TYPE;
  BEGIN

  SELECT DISTINCT kupon_endeks_turu
  INTO   ln_kupon_endeks_turu
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ln_kupon_endeks_turu ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION  menkul_risk_primi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
   IS
    ln_risk_primi			CBS_MENKUL.kupon_risk_primi%TYPE;
  BEGIN

  SELECT DISTINCT kupon_risk_primi
  INTO   ln_risk_primi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ln_risk_primi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN 0 ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION  menkul_kupon_yillik_faiz_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
   IS
    ln_yillik_faiz			CBS_MENKUL.KUPON_YILLIK_FAIZ_ORANI%TYPE;
  BEGIN

  SELECT DISTINCT KUPON_YILLIK_FAIZ_ORANI
  INTO   ln_yillik_faiz
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ln_yillik_faiz ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN 0 ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_kupon_odeme_donemi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
   IS
    ln_odeme_donemi			CBS_MENKUL.kupon_odeme_donemi%TYPE;
  BEGIN

  SELECT DISTINCT kupon_odeme_donemi
  INTO   ln_odeme_donemi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ln_odeme_donemi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN 0 ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_ilk_kupon_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE
   IS
    ld_ilk_kupon_tarihi			CBS_MENKUL.ILK_KUPON_ODEME_TARIHI%TYPE;
  BEGIN

  SELECT DISTINCT ILK_KUPON_ODEME_TARIHI
  INTO   ld_ilk_kupon_tarihi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ld_ilk_kupon_tarihi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_gelecek_odeme_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE
   IS
    ld_gelecek_odeme_tarihi		CBS_MENKUL.GELECEK_KUPON_ODEME_TARIHI%TYPE;
  BEGIN

  SELECT DISTINCT GELECEK_KUPON_ODEME_TARIHI
  INTO   ld_gelecek_odeme_tarihi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ld_gelecek_odeme_tarihi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_gecmis_odeme_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE
   IS
    ld_gecmis_odeme_tarihi		CBS_MENKUL.GECMIS_KUPON_ODEME_TARIHI%TYPE;
  BEGIN

  SELECT DISTINCT GECMIS_KUPON_ODEME_TARIHI
  INTO   ld_gecmis_odeme_tarihi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ld_gecmis_odeme_tarihi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_toplam_kupon_adedi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
   IS
    ln_TOPLAM_KUPON_ADEDI		CBS_MENKUL.TOPLAM_KUPON_ADEDI%TYPE;
  BEGIN

  SELECT DISTINCT TOPLAM_KUPON_ADEDI
  INTO   ln_TOPLAM_KUPON_ADEDI
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ln_TOPLAM_KUPON_ADEDI ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN 0 ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_gun_hesaplama_bazi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
   IS
    ln_GUN_HESAPLAMA_BAZI		CBS_MENKUL.GUN_HESAPLAMA_BAZI%TYPE;
  BEGIN

  SELECT DISTINCT GUN_HESAPLAMA_BAZI
  INTO   ln_GUN_HESAPLAMA_BAZI
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ln_GUN_HESAPLAMA_BAZI ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN 0 ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_doviz_cinsi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_doviz_kodu 			CBS_MENKUL.doviz_kodu%TYPE;
  BEGIN

  SELECT DISTINCT doviz_kodu
  INTO   ls_doviz_kodu
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_doviz_kodu	 ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_dovize_endekli_mi(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_dovize_endeksli_mk			CBS_MENKUL.dovize_endeksli_mk%TYPE;
  BEGIN

  SELECT DISTINCT dovize_endeksli_mk
  INTO   ls_dovize_endeksli_mk
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_dovize_endeksli_mk ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_dovize_para_kodu_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_endeks_para_kodu			CBS_MENKUL.endeks_para_kodu%TYPE;
  BEGIN

  SELECT DISTINCT endeks_para_kodu
  INTO   ls_endeks_para_kodu
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_endeks_para_kodu ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_ihrac_kuru_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
   IS
    ln_ihrac_kuru		CBS_MENKUL.IHRAC_KURU%TYPE;
  BEGIN

  SELECT DISTINCT ihrac_kuru
  INTO   ln_ihrac_kuru
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ln_ihrac_kuru ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_ihrac_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE
   IS
    ld_ihrac_tarihi  	CBS_MENKUL.ihrac_tarihi%TYPE;
  BEGIN

  SELECT DISTINCT ihrac_tarihi
  INTO   ld_ihrac_tarihi
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ld_ihrac_tarihi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  menkul_kuponlu_mu(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ls_KUPON			CBS_MENKUL.KUPON%TYPE;
  BEGIN

  SELECT DISTINCT KUPON
  INTO   ls_KUPON
  FROM   CBS_MENKUL
  WHERE  menkul_kiymet_kodu = ps_kod ;

	RETURN ls_KUPON ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	    RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3386' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

 PROCEDURE  Kupon_Odeme_Tablosu_Olustur(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 										pn_islem_no NUMBER,pn_islem_tarihi DATE,pn_faiz_orani NUMBER)

  IS
    ls_kod	 					   CBS_MENKUL.menkul_kiymet_kodu%TYPE;
    ld_itfa_tarihi				   CBS_MENKUL.itfa_tarihi%TYPE;
	ld_ilk_kupon_odeme_tarihi	   CBS_MENKUL.ilk_kupon_odeme_tarihi%TYPE;
	ld_gelecek_kupon_odeme_tarihi  CBS_MENKUL.gelecek_kupon_odeme_tarihi%TYPE;
	ld_kupon_tarihi  			   CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_tarihi%TYPE;
	ln_kupon_odeme_donemi		   CBS_MENKUL.kupon_odeme_donemi%TYPE;
	ln_toplam_kupon_adedi		   CBS_MENKUL.toplam_kupon_adedi%TYPE;
	ln_kupon_yillik_faiz_orani	   CBS_MENKUL.kupon_yillik_faiz_orani%TYPE;
	ln_kupon_donemsel_faiz_orani   CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_donemsel_faiz_orani%TYPE;
	ln_kupon_donem_faiz_orani      CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_donemsel_faiz_orani%TYPE;
	ln_donemsel_risk_primi		   CBS_MENKUL_KUPON_ODEME_TABLOSU.risk_primi%TYPE;
	ln_risk_primi				   CBS_MENKUL.kupon_risk_primi%TYPE;
	ls_count					   NUMBER;
	ln_kupon_odeme_sayisi		   NUMBER;
	ld_min_kupon_tarihi			   CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_tarihi%TYPE;

	CURSOR c_tablo  ( c_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) IS
	SELECT a.kupon_tarihi ,  a.kupon_yillik_faiz_orani ,
	        a.kupon_donemsel_faiz_orani , b.kupon_risk_primi
    FROM 	CBS_MENKUL_KUPON_ODEME_TABLOSU a ,CBS_MENKUL b
    WHERE   a.menkul_kiymet_kodu = trim(c_kod)
	AND     b.menkul_kiymet_kodu = a.menkul_kiymet_kodu
	AND     b.durum_kodu = 'A';


  BEGIN

	SELECT COUNT(*) 			   		  		/* ls_count>0 ise daha onceden bu tablo olusturulmus demektir.*/
	INTO   ls_count
	FROM   CBS_MENKUL_KUPON_ODEME_TABLOSU
	WHERE  menkul_kiymet_kodu = trim(ps_kod);

	-- Menkul koduna ait ilgili tanimlari al.(Hesaplamada kullanilacak)
	SELECT
			itfa_tarihi,ilk_kupon_odeme_tarihi,gelecek_kupon_odeme_tarihi,kupon_odeme_donemi,
			toplam_kupon_adedi,kupon_odeme_donemi,kupon_yillik_faiz_orani,NVL(kupon_risk_primi,0)
	INTO	ld_itfa_tarihi,ld_ilk_kupon_odeme_tarihi,ld_gelecek_kupon_odeme_tarihi,ln_kupon_odeme_donemi,
		    ln_toplam_kupon_adedi,ln_kupon_odeme_donemi,ln_kupon_yillik_faiz_orani,ln_risk_primi
	FROM  	CBS_MENKUL
	WHERE 	menkul_kiymet_kodu = trim(ps_kod);

	IF ls_count=0 THEN -- ?lk defa tablo olusturulacak
	   ln_kupon_odeme_sayisi  	    := Pkg_Menkul.Kupon_odeme_sayisi(ln_kupon_odeme_donemi);
	   ln_kupon_donemsel_faiz_orani := ln_kupon_yillik_faiz_orani / ln_kupon_odeme_sayisi ;
	   ln_donemsel_risk_primi		:= ln_risk_primi/ln_kupon_odeme_sayisi ;

	   -- Kagidi aldigimdan itibaren
	 BEGIN
	    FOR ln_i IN 1..ln_toplam_kupon_adedi LOOP
	   	   IF ln_i =1 THEN
		   	   -- ?lk kupon odeme doneminin tarihi ve faizleri yazilacak
		   	   INSERT INTO CBS_MENKUL_KUPON_ODEME_TBLISLM
			   		  (tx_no , menkul_kiymet_kodu , kupon_tarihi , kupon_yillik_faiz_orani ,
					   kupon_donemsel_faiz_orani , risk_primi , islem_tarihi)
			   VALUES (pn_islem_no , trim(ps_kod) , ld_ilk_kupon_odeme_tarihi , ln_kupon_yillik_faiz_orani ,
			   		   ln_kupon_donemsel_faiz_orani , ln_donemsel_risk_primi , pn_islem_tarihi) ;

		   ELSIF  ln_i =2 THEN
		   	   -- Gelecek kupon odeme doneminin tarihi ve faizleri yazilacak
		   	   INSERT INTO CBS_MENKUL_KUPON_ODEME_TBLISLM
			   		  (tx_no , menkul_kiymet_kodu , kupon_tarihi , kupon_yillik_faiz_orani ,
					   kupon_donemsel_faiz_orani , risk_primi , islem_tarihi)
			   VALUES (pn_islem_no , trim(ps_kod) , ld_gelecek_kupon_odeme_tarihi , ln_kupon_yillik_faiz_orani ,
			   		   ln_kupon_donemsel_faiz_orani , ln_donemsel_risk_primi , pn_islem_tarihi) ;

			  ld_kupon_tarihi := ld_gelecek_kupon_odeme_tarihi ;

		   ELSE
		   	   -- Sonraki kupon odeme doneminin tarihi ve faizleri yazilacak
			   ld_kupon_tarihi := Pkg_Menkul.Sonraki_Kupon_Odeme_Tarihi(ld_kupon_tarihi,ln_kupon_odeme_donemi);
		   	   INSERT INTO CBS_MENKUL_KUPON_ODEME_TBLISLM
			   		  (tx_no , menkul_kiymet_kodu , kupon_tarihi , kupon_yillik_faiz_orani ,
					   kupon_donemsel_faiz_orani , risk_primi , islem_tarihi)
			   VALUES (pn_islem_no , trim(ps_kod) , ld_kupon_tarihi , ln_kupon_yillik_faiz_orani ,
			   		   ln_kupon_donemsel_faiz_orani , ln_donemsel_risk_primi , pn_islem_tarihi) ;

		   END IF;
	    END LOOP;
--	    COMMIT;

  	    EXCEPTION
		  WHEN OTHERS THEN
		  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1983' || Pkg_Hata.getUCPOINTER);

	 END;

	ELSE
	--Daha onceden kupon olusturuldu ise...

		DELETE FROM   CBS_MENKUL_KUPON_ODEME_TBLISLM
		WHERE  menkul_kiymet_kodu = trim(ps_kod)
		AND    tx_no = pn_islem_no  ;

	   ln_kupon_odeme_sayisi  	    := Pkg_Menkul.Kupon_odeme_sayisi(ln_kupon_odeme_donemi);
	   ln_kupon_donemsel_faiz_orani := pn_faiz_orani / ln_kupon_odeme_sayisi ;

	   /* Degisen Kayitlari islem tablosuna insert et.Ekranda sadece bunlari gorecek ve degistirebilecek
	    Onayladigi zamanda sadece burda insert ettigi kayitlari cbs_menkul_kupon_odeme_tablosu tablosunda guncelleecek*/
	  BEGIN

		OPEN c_tablo (ps_kod);
		 LOOP
		  	FETCH c_tablo
			INTO ld_kupon_tarihi,ln_kupon_yillik_faiz_orani,ln_kupon_donem_faiz_orani,ln_risk_primi;
		  	EXIT WHEN c_tablo%NOTFOUND;

			IF ld_kupon_tarihi < pn_islem_tarihi THEN
		   	     INSERT INTO CBS_MENKUL_KUPON_ODEME_TBLISLM
			   		  (tx_no , menkul_kiymet_kodu , kupon_tarihi , kupon_yillik_faiz_orani ,
					   kupon_donemsel_faiz_orani , risk_primi , islem_tarihi)
			     VALUES (pn_islem_no ,trim(ps_kod), ld_kupon_tarihi ,  ln_kupon_yillik_faiz_orani ,
					   ln_kupon_donem_faiz_orani , ln_risk_primi/ln_kupon_odeme_sayisi , pn_islem_tarihi) ;
			ELSE
		   	     INSERT INTO CBS_MENKUL_KUPON_ODEME_TBLISLM
			   		  (tx_no , menkul_kiymet_kodu , kupon_tarihi , kupon_yillik_faiz_orani ,
					   kupon_donemsel_faiz_orani , risk_primi , islem_tarihi)
			     VALUES (pn_islem_no ,trim(ps_kod), ld_kupon_tarihi ,  pn_faiz_orani ,
					   ln_kupon_donemsel_faiz_orani , ln_risk_primi/ln_kupon_odeme_sayisi , pn_islem_tarihi) ;
			END IF ;


		 END LOOP;
		 CLOSE c_tablo;

 	   --  Commit;

  	    EXCEPTION
		  WHEN OTHERS THEN
		  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2262' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	   END;
	END IF;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1983' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;


  /****************************************/
 FUNCTION kupon_odeme_tablosu_var_mi(ps_menkul_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
 IS
 ln_count NUMBER;

 BEGIN
	SELECT COUNT(*)
	INTO   ln_count
	FROM   CBS_MENKUL_KUPON_ODEME_TABLOSU
	WHERE  menkul_kiymet_kodu = ps_menkul_kodu;

	IF ln_count >0 THEN
       RETURN 'E';
	ELSE
	   RETURN 'H';
	END IF;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
  	      RETURN 'H';
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3109' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
/**************************************************************/
 FUNCTION Kupur_Tutari_Al(pn_kod CBS_KUPUR_KODLARI.KOD%TYPE) RETURN NUMBER
  IS
  ln_kupur  NUMBER;
  BEGIN
  	 SELECT TO_NUMBER(REPLACE(REPLACE(aciklama,','),'.'))
	 INTO   ln_kupur
	 FROM   CBS_KUPUR_KODLARI
	 WHERE  kod=pn_kod;


  	RETURN ln_kupur;

	EXCEPTION
	  WHEN OTHERS THEN
	    RETURN 0;

   END ;
  --*******************************************************************************************
  FUNCTION  Stoktan_Menkul_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2
   IS
    ls_menkul	 			CBS_MENKUL.menkul_kiymet_kodu%TYPE;
  BEGIN

  SELECT menkul_kiymet_kodu
  INTO   ls_menkul
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ls_menkul	 ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;

  --*******************************************************************************************
  FUNCTION  Stoktan_Stok_Tanim_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2
   IS
    ls_stok_tanim 			CBS_MENKUL_STOK.stok_tanim%TYPE;
  BEGIN

  SELECT stok_tanim
  INTO   ls_stok_tanim
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ls_stok_tanim	 ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Stoktan_Depo_Turu_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2
   IS
    ls_depo_turu		CBS_MENKUL_STOK.depo_turu%TYPE;
  BEGIN

  SELECT depo_turu
  INTO   ls_depo_turu
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ls_depo_turu ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Stoktan_Saklama_Yeri_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_Saklama_Yeri	CBS_MENKUL_STOK.Saklama_Yeri%TYPE;
  BEGIN

  SELECT Saklama_Yeri
  INTO   ln_Saklama_Yeri
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ln_Saklama_Yeri;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Stok_Nominali_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_NOMINAL_TUTAR	CBS_MENKUL_STOK.NOMINAL_TUTAR%TYPE;
  BEGIN

  SELECT NOMINAL_TUTAR
  INTO   ln_NOMINAL_TUTAR
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ln_NOMINAL_TUTAR;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Stok_adedi_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_adet	CBS_MENKUL_STOK.adet%TYPE;
  BEGIN

  SELECT adet
  INTO   ln_adet
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ln_adet;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Stok_Tutari_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_TOPLAM_TUTAR	CBS_MENKUL_STOK.TOPLAM_TUTAR%TYPE;
  BEGIN

  SELECT TOPLAM_TUTAR
  INTO   ln_TOPLAM_TUTAR
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ln_TOPLAM_TUTAR;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Stoktan_Kupur_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_KUPUR	CBS_MENKUL_STOK.KUPUR%TYPE;
  BEGIN

  SELECT KUPUR
  INTO   ln_KUPUR
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ln_KUPUR;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Bloke_Durumu_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2
   IS
    ls_BLOKE_DURUMU	CBS_MENKUL_STOK.BLOKE_DURUMU%TYPE;
  BEGIN

  SELECT BLOKE_DURUMU
  INTO   ls_BLOKE_DURUMU
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ls_BLOKE_DURUMU;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Bloke_Adedi_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_BLOKE_ADET	CBS_MENKUL_STOK.BLOKE_ADET%TYPE;
  BEGIN

  SELECT BLOKE_ADET
  INTO   ln_BLOKE_ADET
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ln_BLOKE_ADET;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Bloke_Nominali_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_BLOKE_NOMINAL_TUTAR	CBS_MENKUL_STOK.BLOKE_NOMINAL_TUTAR%TYPE;
  BEGIN

  SELECT BLOKE_NOMINAL_TUTAR
  INTO   ln_BLOKE_NOMINAL_TUTAR
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_kod ;

	RETURN ln_BLOKE_NOMINAL_TUTAR;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  RETURN NULL ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3383' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION   Repo_rezerv_adedi(pn_stok_no  NUMBER ) RETURN NUMBER

  IS
    ln_rezervdeki_tutar	   CBS_MENKUL_ALT_STOK.adet%TYPE;

  BEGIN
	   SELECT  NVL(SUM(ADET),0)
	   INTO    ln_rezervdeki_tutar
	   FROM    CBS_MENKUL_ALT_STOK
	   WHERE   ana_stok_no =  pn_stok_no
	   AND 	   durumu 	   = 'D'
	   AND     islem_turu  = 'REPO';

	RETURN ln_rezervdeki_tutar;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	    RETURN 0;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2835' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
  FUNCTION   Repo_rezerv_nominali(pn_stok_no  NUMBER ) RETURN NUMBER

  IS
    ln_rezervdeki_tutar	   CBS_MENKUL_ALT_STOK.nominal_tutar%TYPE;

  BEGIN
	   SELECT  NVL(SUM(NOMINAL_TUTAR),0)
	   INTO    ln_rezervdeki_tutar
	   FROM    CBS_MENKUL_ALT_STOK
	   WHERE   ana_stok_no =  pn_stok_no
	   AND 	   durumu 	   = 'D'
	   AND     islem_turu  = 'REPO';

	RETURN ln_rezervdeki_tutar;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	    RETURN 0;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2835' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
  FUNCTION   Repo_rezerv_tutari(pn_stok_no  NUMBER ) RETURN NUMBER

  IS
    ln_rezervdeki_tutar	   CBS_MENKUL_ALT_STOK.TOPLAM_TUTAR%TYPE;

  BEGIN
	   SELECT  NVL(SUM(TOPLAM_TUTAR),0)
	   INTO    ln_rezervdeki_tutar
	   FROM    CBS_MENKUL_ALT_STOK
	   WHERE   ana_stok_no =  pn_stok_no
	   AND 	   durumu 	   = 'D'
	   AND     islem_turu  = 'REPO';

	RETURN ln_rezervdeki_tutar;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	    RETURN 0;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2835' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

 FUNCTION Bloke_Referansi_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_bloke_referansi   CBS_MENKUL_BANKA_ALIM.bloke_referansi%TYPE;
	 ln_sira_no 	 NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	 	:= Pkg_Baglam.bolum_kodu ;
	 ls_bloke_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.MBL.' ;
	 ln_sira_no    		:= Pkg_Genel.genel_kod_al(ls_bloke_referansi);
	 ls_bloke_referansi := ls_bloke_referansi || LPAD(ln_sira_no,5,0);

  	RETURN ls_bloke_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1992' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************
 FUNCTION Menkul_REPODONUS_Referansi_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_MRD_referansi     CBS_MENKUL_REPO_GIRIS.referans_no%TYPE;
	 ln_sira_no 	 	  NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	  := Pkg_Baglam.bolum_kodu ;
	 ls_MRD_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.RD.' ;
	 ln_sira_no    	  := Pkg_Genel.genel_kod_al(ls_MRD_referansi);
	 ls_MRD_referansi := ls_MRD_referansi || LPAD(ln_sira_no,6,0);

  	RETURN ls_MRD_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3584' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************


 FUNCTION Menkul_TERSREPODONUS_Ref_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_MTRD_referansi     CBS_MENKUL_TREPO_GIRIS.referans_no%TYPE;
	 ln_sira_no 	 	  NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	   := Pkg_Baglam.bolum_kodu ;
	 ls_MTRD_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.TD.' ;
	 ln_sira_no    	   := Pkg_Genel.genel_kod_al(ls_MTRD_referansi);
	 ls_MTRD_referansi := ls_MTRD_referansi || LPAD(ln_sira_no,6,0);

  	RETURN ls_MTRD_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3766' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************
 FUNCTION Menkul_BANKATREPODONUS_Ref_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_BTRD_referansi    CBS_MENKUL_BANKA_TREPO_GIRIS.referans_no%TYPE;
	 ln_sira_no 	 	  NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	   := Pkg_Baglam.bolum_kodu ;
	 ls_BTRD_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.BTD.' ;
	 ln_sira_no    	   := Pkg_Genel.genel_kod_al(ls_BTRD_referansi);
	 ls_BTRD_referansi := ls_BTRD_referansi || LPAD(ln_sira_no,5,0);

  	RETURN ls_BTRD_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3902' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************

 FUNCTION Menkul_TREPO_DONUSIPTAL_Ref_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_MTRDI_referansi   CBS_MENKUL_TREPO_DONUS.referans_no%TYPE;
	 ln_sira_no 	 	  NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	   := Pkg_Baglam.bolum_kodu ;
	 ls_MTRDI_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.TDI.' ;
	 ln_sira_no    	   := Pkg_Genel.genel_kod_al(ls_MTRDI_referansi);
	 ls_MTRDI_referansi := ls_MTRDI_referansi || LPAD(ln_sira_no,5,0);

  	RETURN ls_MTRDI_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3730' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************

 FUNCTION Menkul_BNKTREPODONIPT_Ref_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_MTRDI_referansi   CBS_MENKUL_TREPO_DONUS.referans_no%TYPE;
	 ln_sira_no 	 	  NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	   := Pkg_Baglam.bolum_kodu ;
	 ls_MTRDI_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.BTDI.' ;
	 ln_sira_no    	   := Pkg_Genel.genel_kod_al(ls_MTRDI_referansi);
	 ls_MTRDI_referansi := ls_MTRDI_referansi || LPAD(ln_sira_no,4,0);

  	RETURN ls_MTRDI_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3909' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************



 FUNCTION Menkul_Itfa_Ref_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_itfa_referansi    VARCHAR2(16);
	 ln_sira_no 	 	  NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	   := Pkg_Baglam.bolum_kodu ;
	 ls_itfa_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.itf.' ;
	 ln_sira_no    	   := Pkg_Genel.genel_kod_al(ls_itfa_referansi);
	 ls_itfa_referansi := ls_itfa_referansi || LPAD(ln_sira_no,5,0);

  	RETURN ls_itfa_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4166' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************
  FUNCTION  tahvil_tescil_grup_adi_al(pn_kod CBS_MENKUL.tahvil_tescil_grup_kod%TYPE,
  									  ps_urun_tur CBS_MENKUL.urun_tur_kod%TYPE) RETURN VARCHAR2
   IS
    ls_grup_adi 	 CBS_TAHVIL_TESCIL_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_grup_adi
	FROM   CBS_TAHVIL_TESCIL_KODLARI
	WHERE  kod = pn_kod
	AND urun_tur_kod = ps_urun_tur  ;

	RETURN ls_grup_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1668' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/


  FUNCTION  Stok_Tanim_adi_al(pn_kod CBS_STOK_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_stok_adi 	 CBS_STOK_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_stok_adi
	FROM   CBS_STOK_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_stok_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1967' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Stok_No_al RETURN CBS_MENKUL_BANKA_ALIM.stok_no%TYPE
   IS
    ln_stok_no 	 CBS_MENKUL_BANKA_ALIM.stok_no%TYPE;
  BEGIN

  	ln_stok_no := Pkg_Genel.genel_kod_al('STOK_NO') ;

	RETURN ln_stok_no  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1989' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION  Yasakli_Kiymet_Seri_Kodu_Al RETURN CBS_MENKUL_YASAKLI_KIYMET_SERI.kod%TYPE
   IS
    ln_kod 	 CBS_MENKUL_YASAKLI_KIYMET_SERI.kod%TYPE;
  BEGIN

  	ln_kod := Pkg_Genel.genel_kod_al('YASAKLI_KIYMET') ;

	RETURN ln_kod  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3124' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

 PROCEDURE  Stok_Tablosu_Hareket_Yarat(pn_islem_no NUMBER,pn_islem_tipi NUMBER)

  IS

  	ln_stok_no						     CBS_MENKUL_BANKA_ALIM_ISLEM.stok_no%TYPE;
	ls_stok_tanim						 CBS_MENKUL_BANKA_ALIM_ISLEM.stok_tanim%TYPE;
	ls_depo_turu						 CBS_MENKUL_BANKA_ALIM_ISLEM.depo_turu%TYPE;
	ln_saklama_yeri						 CBS_MENKUL_BANKA_ALIM_ISLEM.saklama_yeri%TYPE;
	ls_mk_referans_no					 CBS_MENKUL_BANKA_ALIM_ISLEM.mk_referans_no%TYPE;
	ls_menkul_kiymet_kodu				 CBS_MENKUL_BANKA_ALIM_ISLEM.menkul_kiymet_kodu%TYPE;
	ld_islem_tarihi						 CBS_MENKUL_BANKA_ALIM_ISLEM.islem_tarihi%TYPE;
	ln_kupur							 CBS_MENKUL_BANKA_ALIM_ISLEM.kupur%TYPE;
	ln_adet								 CBS_MENKUL_BANKA_ALIM_ISLEM.adet%TYPE;
	ln_nominal_tutar					 CBS_MENKUL_BANKA_ALIM_ISLEM.nominal_tutar%TYPE;
	ln_toplam_alis_tutari				 CBS_MENKUL_BANKA_ALIM_ISLEM.toplam_alis_tutari%TYPE;
	ln_temiz_fiyat						 CBS_MENKUL_BANKA_ALIM_ISLEM.temiz_fiyat%TYPE;
	ln_kupon_faizli_fiyat				 CBS_MENKUL_BANKA_ALIM_ISLEM.kupon_faizli_fiyat%TYPE;
	ln_dovend_fiyati					 CBS_MENKUL_BANKA_ALIM_ISLEM.dovend_alim_fiyati%TYPE;
	ln_islenmis_kupon_faizi				 CBS_MENKUL_BANKA_ALIM_ISLEM.islenmis_kupon_faizi%TYPE;
	ln_prim_iskonto_tutari				 CBS_MENKUL_BANKA_ALIM_ISLEM.prim_iskonto_tutari%TYPE;
	ln_toplam_satis_tutari				 CBS_MENKUL_BANKA_SATIS_ISLEM.toplam_satis_tutari%TYPE;
	ln_verim							 CBS_MENKUL_BANKA_ALIM_ISLEM.verim%TYPE;
	ls_bloke							 CBS_MENKUL_BANKA_ALIM_ISLEM.bloke%TYPE;
	ln_bloke_adet						 CBS_MENKUL_BANKA_ALIM_ISLEM.bloke_adet%TYPE;
	ln_bloke_nominal_tutar				 CBS_MENKUL_BANKA_ALIM_ISLEM.bloke_nominal_tutar%TYPE;
	ln_musteri_no_kime					 CBS_MENKUL_BANKA_ALIM_ISLEM.musteri_no_kime%TYPE;
	ln_hesap_no_kime					 CBS_MENKUL_BANKA_ALIM_ISLEM.hesap_no_kime%TYPE;
	ls_kime_alindigi					 CBS_MENKUL_BANKA_ALIM_ISLEM.kime_alindigi%TYPE;
	ln_stoktaki_adet					 CBS_MENKUL_BANKA_ALIM_ISLEM.adet%TYPE;
	ln_stoktaki_nominal_tutar			 CBS_MENKUL_BANKA_ALIM_ISLEM.nominal_tutar%TYPE;
	ln_stoktaki_toplam_tutar		     CBS_MENKUL_BANKA_ALIM_ISLEM.toplam_alis_tutari%TYPE;
	ln_ana_stok							 CBS_MENKUL_STOK.ana_stok%TYPE;
	ln_satilanin_maliyeti				 CBS_MENKUL_BANKA_SATIS_STOKISL.satilanin_maliyeti%TYPE;
	ls_alt_stok_no 			  		 	 CBS_MENKUL_ALT_STOK_HAREKET.alt_stok_no%TYPE;
	ln_repo_adedi					  	 CBS_MENKUL_REPO_GIRIS_STOKISL.repo_adedi%TYPE;
	ln_repo_nominali				  	 CBS_MENKUL_REPO_GIRIS_STOKISL.repo_nominali%TYPE;
	ln_repo_tutari					  	 CBS_MENKUL_ALT_STOK_HAREKET.toplam_tutar%TYPE;
	ls_repo								 CBS_MENKUL_STOK.repo%TYPE;
	ls_trepo							 CBS_MENKUL_STOK.trepo%TYPE;
	ld_trepo_vade						 CBS_MENKUL_STOK.trepo_vade%TYPE;
	ln_stoktaki_repo_nominali			 CBS_MENKUL_REPO_GIRIS_STOKISL.repo_nominali%TYPE;
	ln_stoktaki_repo_tutari				 CBS_MENKUL_ALT_STOK_HAREKET.toplam_tutar%TYPE;
	ln_count							 NUMBER;

	ln_alt_stok_nominali 				 CBS_MENKUL_REPO_GIRIS_STOKISL.repo_nominali%TYPE;
	ls_ana_stok_durumu					 CBS_MENKUL_STOK.stok_durumu%TYPE;

	ln_onceki_repo_adedi				 CBS_MENKUL_REPO_GIRIS_STOK.repo_adedi%TYPE;
	ln_onceki_repo_nominali				 CBS_MENKUL_REPO_GIRIS_STOK.repo_nominali%TYPE;
	ln_onceki_repo_tutari				 CBS_MENKUL_REPO_GIRIS_STOK.repo_tutari%TYPE;
	ln_tersrepo_stokno					 CBS_MENKUL_TREPO_GIRIS_STOK.stok_no%TYPE;

    ld_emanete_giris_tarihi				 CBS_MENKUL_EMANET_GIRIS.emanete_giris_tarihi%TYPE;
	ln_musteri_no						 CBS_MENKUL_EMANET_GIRIS.musteri_no%TYPE;
	ln_hesap_no							 CBS_MENKUL_EMANET_GIRIS.hesap_no%TYPE;
	ln_bildirim_birim_fiyati			 CBS_MENKUL_EMANET_GIRIS.bildirim_birim_fiyati%TYPE;
	ln_tcmb_birim_fiyati				 CBS_MENKUL_EMANET_GIRIS.tcmb_birim_fiyati%TYPE;
	ln_bloke_toplam_tutar				 CBS_MENKUL_EMANET_GIRIS.bloke_toplam_tutar%TYPE;
	ln_virman_yeri						 CBS_MENKUL_EMANET_GIRIS.virman_yeri%TYPE;

	ln_stok_adet   	 					 CBS_MENKUL_STOK.adet%TYPE;
	ln_stok_nominal 					 CBS_MENKUL_STOK.nominal_tutar%TYPE;
	ln_stok_toplam_tutar 				 CBS_MENKUL_STOK.toplam_tutar%TYPE;
	ln_stok_repo_nominal  				 CBS_MENKUL_STOK.nominal_tutar%TYPE;
	ln_stok_repo_tutar    				 CBS_MENKUL_STOK.toplam_tutar%TYPE;
	ln_stok_repo_adet					 CBS_MENKUL_STOK.repo_adet%TYPE;
	ls_stok_repo						 CBS_MENKUL_STOK.repo%TYPE;
	ls_referans_no						 CBS_MENKUL_STOK_HAREKET.islem_referans_no%TYPE;

	ls_stok_bloke_durumu				 CBS_MENKUL_STOK.bloke_durumu%TYPE;
	ln_stok_bloke_adet					 CBS_MENKUL_STOK.bloke_adet%TYPE;
	ln_stok_bloke_nominal_tutar			 CBS_MENKUL_STOK.bloke_nominal_tutar%TYPE;
	ln_stok_bloke_toplam_tutar			 CBS_MENKUL_STOK.bloke_toplam_tutar%TYPE;
	ln_menkul_kiymet_tipi				 NUMBER;
	ln_yeni_stok						 NUMBER;
	ln_mddaf							 NUMBER;
	ln_yeni_mddaf						 NUMBER;
	ln_orj_repo_tutari					 NUMBER;
	ln_stok_orj_repo_tutari				 NUMBER;
	ld_yeni_vade_tarihi					 DATE;
	ln_yeni_oran						 NUMBER;

	CURSOR c_banka_satis_stok (c_islem_no CBS_MENKUL_BANKA_SATIS_STOKISL.tx_no%TYPE) IS
	SELECT a.referans_no, a.stok_no, a.stok_kupur, a.satilan_nominal_adet,b.menkul_kiymet_kodu,
       	   a.satilan_nominal_tutar, a.dovend_satis_fiyati, a.temiz_fiyat,
       	   a.kupon_faizli_fiyat, a.toplam_satis_tutari, a.islenmis_kupon_faizi,
       	   a.prim_iskonto_tutari, a.verim,a.satilanin_maliyeti,b.islem_tarihi,
		   NVL(c.adet,0) - NVL(a.satilan_nominal_adet,0) stokta_kalan_adet ,
		   NVL(c.nominal_tutar,0) - NVL(a.satilan_nominal_tutar,0) stokta_kalan_nominal,
		   NVL(c.toplam_tutar,0) - NVL(a.satilanin_maliyeti,0)  stokta_kalan_tutar,
		   a.stoktaki_adet, a.stoktaki_nominal, a.toplam_alis_tutari,b.satis_valor_tarihi,
   		   (NVL(c.islenmis_kupon_faizi,0) - NVL(a.islenmis_kupon_faizi,0)) stokta_kalan_IK_faizi,
		   (NVL(c.prim_iskonto_tutari,0) - NVL(a.prim_iskonto_tutari,0)) stokta_kalan_PI_tutari,
		   c.repo,b.satilan_portfoy,b.musteri_no_kimden, b.hesap_no_kimden
	FROM   CBS_MENKUL_BANKA_SATIS_STOKISL a,CBS_MENKUL_BANKA_SATIS_ISLEM b,CBS_MENKUL_STOK c
	WHERE  a.tx_no       = c_islem_no
	AND	   a.satildi     = 'E'
	AND    b.referans_no = a.referans_no
	AND    c.stok_no 	 = a.stok_no
	AND	   b.tx_no       = a.tx_no;

	r_BS			c_banka_satis_stok%ROWTYPE;

	CURSOR c_repo_giris_islem (c_islem_no CBS_MENKUL_REPO_GIRIS_STOKISL.tx_no%TYPE) IS
	SELECT a.stok_no, c.stok_tanim, a.depo_turu,b.saklama_yeri,'B',
		   a.referans_no,b.menkul_kiymet_kodu,b.islem_tarihi,c.ana_stok,c.kupur,
		   NVL(c.adet,0) - NVL(a.repo_adedi,0) stoktaki_adet,
		   NVL(c.nominal_tutar,0) - NVL(a.repo_nominali,0) stoktaki_nominal_tutar,
		   NVL(c.toplam_tutar,0) - NVL(a.repo_tutari,0) stoktaki_toplam_tutar,
		   c.bloke_durumu, c.bloke_adet, NVL(c.bloke_nominal_tutar,0),b.musteri_no, b.hesap_no,
		   c.dovend_fiyati, c.temiz_fiyat, c.kupon_faizli_fiyat,NVL(a.repo_tutari,0) satilanin_maliyeti,
		   'E', NVL(a.repo_nominali,0) repo_nominali ,NVL(a.repo_tutari,0) repo_tutari , NVL(a.repo_adedi,0) repo_adedi ,
		   NVL(c.repo_nominal,0) stoktaki_repo_nominali,  NVL(c.repo_tutar,0) stoktaki_repo_tutari,NVL(c.repo_adet,0) stoktaki_repo_adedi,
		   c.trepo, c.trepo_vade
    FROM   CBS_MENKUL_REPO_GIRIS_STOKISL a,CBS_MENKUL_REPO_GIRIS_ISLEM b,CBS_MENKUL_STOK c
    WHERE  a.tx_no   	 = c_islem_no
	AND    a.tx_no		 = b.tx_no
	AND    c.stok_no 	 = a.stok_no
    AND    a.repolanacak = 'E'		;

	r_RG			c_repo_giris_islem%ROWTYPE;

	CURSOR c_trepo_giris_islem (c_islem_no CBS_MENKUL_TREPO_GIRIS_STOKISL.tx_no%TYPE) IS
	SELECT a.stok_no, c.stok_tanim, a.depo_turu,b.saklama_yeri,'B' kime_alindigi,
		   a.referans_no,b.menkul_kiymet_kodu,b.islem_tarihi,c.ana_stok,c.kupur,
		   NVL(c.adet,0) - NVL(a.repo_adedi,0)  stoktaki_adet,
		   NVL(c.nominal_tutar,0) - NVL(a.repo_nominali,0) stoktaki_nominal_tutar,
		   NVL(c.toplam_tutar,0) - NVL(a.orj_repo_tutari,0) stoktaki_toplam_tutar,
		   c.bloke_durumu, c.bloke_adet, NVL(c.bloke_nominal_tutar,0),b.musteri_no, b.hesap_no,
		   c.dovend_fiyati, c.temiz_fiyat, c.kupon_faizli_fiyat,NVL(a.repo_tutari,0) satilanin_maliyeti,
		   'H', NVL(a.repo_nominali,0) repo_nominali,NVL(a.repo_tutari,0) repo_tutari , NVL(a.repo_adedi,0) repo_adedi,
		    NVL(c.repo_nominal,0) stoktaki_repo_nominali,  NVL(c.repo_tutar,0) stoktaki_repo_tutari,
			NVL(c.repo_adet,0) stoktaki_repo_adedi,'E', a.repo_vade_tarihi,NVL(a.orj_repo_tutari,0) orj_repo_tutari
    FROM   CBS_MENKUL_TREPO_GIRIS_STOKISL a,CBS_MENKUL_TREPO_GIRIS_ISLEM b,CBS_MENKUL_STOK c
    WHERE  a.tx_no   	 = c_islem_no
	AND    a.tx_no		 = b.tx_no
	AND    c.stok_no 	 = a.stok_no
    AND    a.repolanacak ='E'		;

	r_TRG			c_trepo_giris_islem%ROWTYPE;

	CURSOR c_emanete_giris (c_islem_no CBS_MENKUL_EMANET_GIRIS_ISLEM.tx_no%TYPE) IS
	SELECT stok_no, depo_turu,saklama_yeri,referans_no,
	   	   menkul_kiymet_kodu, emanete_giris_tarihi,kupur,adet,
		   nominal_tutar, bloke, bloke_adet,bloke_nominal_tutar,
		   musteri_no, hesap_no,bloke_toplam_tutar,virman_yeri,
		   bildirim_birim_fiyati,tcmb_birim_fiyati
	FROM   CBS_MENKUL_EMANET_GIRIS_ISLEM
	WHERE  tx_no = c_islem_no ;


	CURSOR c_emanet_cikis (c_islem_no CBS_MENKUL_EMANET_CIKIS_ISLEM.tx_no%TYPE) IS
	SELECT a.stok_no, c.depo_turu,c.saklama_yeri,a.referans_no,b.menkul_kiymet_kodu,
		   b.islem_tarihi,c.ana_stok,a.kupur, (NVL(c.adet,0) - NVL(a.adet,0)),
		   (NVL(c.nominal_tutar,0) - NVL(a.nominal,0)),
		   (NVL(c.toplam_tutar,0) -
		    DECODE(NVL(c.toplam_tutar,0),0,0,((NVL(a.nominal,0) * NVL(c.toplam_tutar,0)) /NVL(c.nominal_tutar,0)))
		   ),
		   c.bloke_durumu, c.bloke_adet, NVL(c.bloke_nominal_tutar,0),b.musteri_no, b.virman_yeri,a.tcmb_birim_fiyati,
		   NVL(c.bloke_toplam_tutar,0)	,hesap_no   ,c.repo,NVL(a.nominal,0),NVL(a.adet,0)
	FROM   CBS_MENKUL_EMANET_CIKSTK_ISLEM a ,CBS_MENKUL_EMANET_CIKIS_ISLEM b,CBS_MENKUL_STOK c
	WHERE  a.tx_no   	 = c_islem_no
	AND    a.tx_no		 = b.tx_no
	AND    c.stok_no 	 = a.stok_no
    AND    a.cikildi	 = 'E'		;


    CURSOR c_stok_devir_yenistok (c_islem_no CBS_MENKUL_STOK_DEVIR_ISLEM.tx_no%TYPE) IS
	SELECT stok_no, stok_tanim, depo_turu,saklama_yeri,referans_no ,menkul_kiymet_kodu,islem_tarihi,
		   Pkg_Menkul.kupur_kodu_al(devir_nominal /devir_adet ) kupur,devir_adet, devir_nominal,
		   devir_maliyeti, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi, prim_iskonto_tutari
	FROM   CBS_MENKUL_STOK_DEVIR_ISLEM
	WHERE  tx_no = c_islem_no ;
    r_SD_Yeni			c_stok_devir_yenistok%ROWTYPE;

    CURSOR c_stok_devir_eskistok (c_islem_no CBS_MENKUL_STOK_DEVIR_ISLEM.tx_no%TYPE) IS
	SELECT a.stok_no, b.stok_tanim, b.depo_turu,b.saklama_yeri,'B' kime_alindigi,
		   a.referans_no,b.menkul_kiymet_kodu,b.islem_tarihi,
		   NVL(c.adet,0) - NVL(a.devir_adet,0) stokta_kalan_adet,NVL(a.devir_adet,0)  devir_adet,
		   NVL(c.nominal_tutar,0) - NVL(a.devir_nominal,0) stokta_kalan_nominal,
		   NVL(c.toplam_tutar,0) - NVL(a.devir_maliyeti,0) stokta_kalan_tutar,NVL(a.devir_maliyeti,0) devir_maliyeti,
		   (NVL(c.islenmis_kupon_faizi,0) - (NVL(c.adet,0) * NVL(b.islenmis_kupon_faizi,0))/ NVL(a.devir_adet,0))  stokta_kalan_IK_faizi,
		   (NVL(c.prim_iskonto_tutari,0) -(NVL(c.adet,0) * NVL(b.prim_iskonto_tutari,0))/ NVL(a.devir_adet,0))  stokta_kalan_PI_tutari,
		   NVL(a.devir_nominal,0) devir_nominal,c.repo,NVL(b.prim_iskonto_tutari,0) prim_iskonto_tutari,NVL(b.islenmis_kupon_faizi,0) islenmis_kupon_faizi,
		   (NVL(a.devir_nominal,0) * NVL(c.MDDAF,0)) / NVL(c.nominal_tutar,0)  mddaf
    FROM   CBS_MENKUL_STOK_DEVIR_STOK_ISL a,CBS_MENKUL_STOK_DEVIR_ISLEM b,CBS_MENKUL_STOK c
    WHERE  a.tx_no   	 = c_islem_no
	AND    a.tx_no		 = b.tx_no
	AND    c.stok_no 	 = a.stok_no
    AND    a.devredildi  = 'E'		;
	r_SD_Eski			c_stok_devir_eskistok%ROWTYPE	;

    CURSOR c_repo_bozum  (c_islem_no CBS_MENKUL_REPO_BOZUM_ISLEM.tx_no%TYPE) IS
	SELECT *
	FROM   CBS_MENKUL_ALT_STOK
	WHERE  durumu 	 = 'A'
	AND    islem_referans_no IN (SELECT repo_islem_referans_no FROM CBS_MENKUL_REPO_BOZUM_ISLEM
		   					 	 WHERE tx_no = c_islem_no );
	r_repo			c_repo_bozum%ROWTYPE;

	CURSOR c_Bloke_koyma (c_islem_no CBS_MENKUL_BLOKE_KOYMA_ISLEM.tx_no%TYPE) IS
	SELECT b.stok_no,b.referans_no,a.islem_tarihi,NVL(b.bloke_adet,0),NVL(b.bloke_nominal_tutar,0), NVL(b.bloke_toplam_tutar,0)
	FROM   CBS_MENKUL_BLOKE_KOYMA_ISLEM a ,CBS_MENKUL_BLOKE_KOYMA_STOK b
	WHERE  a.tx_no 		 = c_islem_no
	AND    b.tx_no		 = a.tx_no
	AND    b.referans_no = a.referans_no;

	CURSOR c_Bloke_kaldirma (c_islem_no CBS_MENKUL_BLOKE_KALDIRMA_ISL.tx_no%TYPE) IS
	SELECT b.stok_no,b.referans_no,a.islem_tarihi,NVL(b.bloke_adet,0),NVL(b.bloke_nominal_tutar,0), NVL(b.bloke_toplam_tutar,0)
	FROM   CBS_MENKUL_BLOKE_KALDIRMA_ISL a, CBS_MENKUL_BLOKE_KALDIRMA_STOK b
	WHERE  a.tx_no 		 = c_islem_no
	AND    b.tx_no		 = a.tx_no
	AND    b.referans_no = a.referans_no;


    CURSOR c_repo_donus_iptal  (c_islem_no CBS_MENKUL_REPO_DONUS_IPTISL.tx_no%TYPE) IS
    SELECT *
    FROM   CBS_MENKUL_ALT_STOK
    WHERE  durumu 	 = 'K'
    AND    islem_referans_no = (SELECT DISTINCT a.repo_referans_no
								FROM CBS_MENKUL_REPO_DONUS a,CBS_MENKUL_REPO_DONUS_IPTISL b
								WHERE a.referans_no = b.repo_donus_referans_no
		   					    AND   b.tx_no = c_islem_no );

    r_repo_donus_iptal			c_repo_donus_iptal%ROWTYPE;

	CURSOR c_trepo_donus_iptal(c_islem_no CBS_MENKUL_REPO_DONUS_IPTISL.tx_no%TYPE )IS
	SELECT stok_no,repo_tutari, repo_nominali,repo_adedi,trepo_stok_no, orj_repo_nominali, orj_repo_adedi, orj_repo_tutari,referans_no
	FROM   CBS_MENKUL_TREPO_DONUS_STOK
	WHERE  referans_no  = (SELECT repo_donus_referans_no FROM CBS_MENKUL_REPO_DONUS_IPTISL
		   				   WHERE tx_no = c_islem_no )
	AND    repolanacak  = 'E';

    r_trepo_donus_iptal			c_trepo_donus_iptal%ROWTYPE;

	CURSOR c_banka_trepo_donus_iptal(c_islem_no CBS_MENKUL_BANKA_TREPO_DIPTISL.tx_no%TYPE )IS
	SELECT tx_no, referans_no, durum_kodu, musteri_no, hesap_no, hesabin_subesi, adet, nominal_tutar,
		   toplam_repo_tutari, islem_tarihi, repo_vade_tarihi, islem_gun_sayisi, oran_net, oran_brut,
		   donus_tutari_net, donus_tutari_brut, menkul_kiymet_kodu, aciklama, repo_donus_referans_no,stok_no
	FROM   CBS_MENKUL_BANKA_TREPO_DIPTISL
	WHERE  tx_no = c_islem_no ;

    r_banka_trepo_donus_iptal			c_banka_trepo_donus_iptal%ROWTYPE;

	CURSOR c_musteri_alim_yenistok(c_islem_no CBS_MENKUL_MUSTERI_ALIM_ISLEM.tx_no%TYPE )IS
	SELECT referans_no, menkul_kiymet_kodu, durum_kodu, urun_tur_kod, urun_sinif_kod, alis_kaynagi, kime_alindigi,
		   musteri_no_kimden, hesap_no_kimden, islem_tarihi, portfoye_giris_tarihi, muhabir_banka, muhabir_hesap,
		   stok_no, stok_tanim, depo_turu, saklama_yeri, dovend_alim_fiyati, temiz_fiyat, kupon_faizli_fiyat,
		   islenmis_kupon_faizi, toplam_adet, toplam_nominal, toplam_alis_tutari, prim_iskonto_tutari, verim,
		   aciklama, modul_tur_kod, odenen_masraf_tutari, odenen_masraf_doviz_kodu, odenen_masraf_hesap_no,
		   alinan_masraf_tutari, alinan_masraf_doviz_kodu, alinan_masraf_hesap_no
	FROM   CBS_MENKUL_MUSTERI_ALIM_ISLEM
	WHERE  tx_no = c_islem_no ;

    r_MA_Yeni			c_musteri_alim_yenistok%ROWTYPE;

    CURSOR c_musteri_alim_eskistok (c_islem_no CBS_MENKUL_MUSTERI_ALIM_ISLEM.tx_no%TYPE) IS
	SELECT a.stok_no, b.kime_alindigi, a.referans_no,b.menkul_kiymet_kodu,b.islem_tarihi,b.portfoye_giris_tarihi,
		   NVL(c.adet,0) - NVL(a.satilan_nominal_adet,0) stokta_kalan_adet ,
		   NVL(c.nominal_tutar,0) - NVL(a.satilan_nominal_tutar,0) stokta_kalan_nominal,
		   NVL(c.toplam_tutar,0) - NVL(a.satilanin_maliyeti,0)  stokta_kalan_tutar,
		   (NVL(c.islenmis_kupon_faizi,0) - NVL(a.islenmis_kupon_faizi,0)) stokta_kalan_IK_faizi,
		   (NVL(c.prim_iskonto_tutari,0) - NVL(a.prim_iskonto_tutari,0)) stokta_kalan_PI_tutari,
		   a.stok_kupur, a.satilan_nominal_adet, a.satilan_nominal_tutar, b.musteri_no_kimden,
		   b.hesap_no_kimden,a.satilanin_maliyeti,a.islenmis_kupon_faizi,a.prim_iskonto_tutari,a.toplam_satis_tutari,
		   c.repo
    FROM   CBS_MENKUL_MUSTERI_ALIM_STKISL a,CBS_MENKUL_MUSTERI_ALIM_ISLEM b,CBS_MENKUL_STOK c
    WHERE  a.tx_no   	 = c_islem_no
	AND    a.tx_no		 = b.tx_no
	AND    c.stok_no 	 = a.stok_no
    AND    a.satildi     = 'E'		;

	r_MA_Eski			c_musteri_alim_eskistok%ROWTYPE;

	CURSOR c_musteri_satis_yenistok(c_islem_no CBS_MENKUL_MUSTERI_SATIS_ISLEM.tx_no%TYPE )IS
	SELECT referans_no, menkul_kiymet_kodu, durum_kodu, urun_tur_kod, urun_sinif_kod, piyasa, satilan_portfoy,
		   musteri_no_kimden, hesap_no_kimden, islem_tarihi, satis_valor_tarihi, muhabir_banka, muhabir_hesap,
		   stok_no, stok_tanim, depo_turu, saklama_yeri, dovend_alim_fiyati, temiz_fiyat, kupon_faizli_fiyat,
		   islenmis_kupon_faizi, toplam_adet, toplam_nominal, toplam_alis_tutari, prim_iskonto_tutari, verim,
		   bloke, bloke_referansi, bloke_nominal_tutar, bloke_adet, bloke_nedeni, blokaj_aciklamasi,
		   bloke_bitis_tarihi, aciklama, modul_tur_kod, bloke_hesabi, odenen_masraf_tutari, odenen_masraf_doviz_kodu,
		   odenen_masraf_hesap_no, alinan_masraf_tutari, alinan_masraf_doviz_kodu, alinan_masraf_hesap_no
	FROM   CBS_MENKUL_MUSTERI_SATIS_ISLEM
	WHERE  tx_no = c_islem_no ;

    r_MS_Yeni			c_musteri_satis_yenistok%ROWTYPE;

    CURSOR c_musteri_satis_eskistok (c_islem_no CBS_MENKUL_MUSTERI_SATIS_ISLEM.tx_no%TYPE) IS
	SELECT a.stok_no,b.satilan_portfoy, a.referans_no,b.menkul_kiymet_kodu,b.islem_tarihi,b.satis_valor_tarihi,
		   NVL(c.adet,0) - NVL(a.satilan_nominal_adet,0) stokta_kalan_adet ,
		   NVL(c.nominal_tutar,0) - NVL(a.satilan_nominal_tutar,0) stokta_kalan_nominal,
		   NVL(c.toplam_tutar,0) - NVL(a.satilanin_maliyeti,0)  stokta_kalan_tutar,
		   (NVL(c.islenmis_kupon_faizi,0) - NVL(a.islenmis_kupon_faizi,0)) stokta_kalan_IK_faizi,
		   (NVL(c.prim_iskonto_tutari,0) - NVL(a.prim_iskonto_tutari,0)) stokta_kalan_PI_tutari,
		   a.stok_kupur, a.satilan_nominal_adet, a.satilan_nominal_tutar, b.musteri_no_kimden,
		   b.hesap_no_kimden,a.satilanin_maliyeti,a.islenmis_kupon_faizi,a.prim_iskonto_tutari,a.toplam_satis_tutari,
		   c.repo
    FROM   CBS_MENKUL_MUSTERI_SATIS_STISL a,CBS_MENKUL_MUSTERI_SATIS_ISLEM b,CBS_MENKUL_STOK c
    WHERE  a.tx_no   	 = c_islem_no
	AND    a.tx_no		 = b.tx_no
	AND    c.stok_no 	 = a.stok_no
    AND    a.satildi     = 'E'		;

	r_MS_Eski			c_musteri_satis_eskistok%ROWTYPE;

	ld_portfoye_giris_tarihi DATE;
  BEGIN
    /**  Islem tiplerine gore hareket tablosu doldurulur **/

	IF  pn_islem_tipi = 6011 THEN   -- Banka alis islemi ise
		BEGIN
			-- Once hesaplamalar ya da arama kriterleri icin ihtiyacin olan kayitlari al.
			SELECT stok_no,bloke,bloke_adet,bloke_nominal_tutar,toplam_alis_tutari, ln_adet,
				   ln_nominal_tutar,  mk_referans_no,portfoye_giris_tarihi,islem_tarihi
			INTO   ln_stok_no,ls_bloke, ln_bloke_adet,ln_bloke_nominal_tutar,ln_toplam_alis_tutari,
				   ln_adet, ln_nominal_tutar , ls_mk_referans_no,ld_portfoye_giris_tarihi,ld_islem_tarihi
			FROM   CBS_MENKUL_BANKA_ALIM_ISLEM
			WHERE  tx_no = pn_islem_no ;

			--Eger blokeli ise bloke tutarini bul
			IF ls_bloke = 'E' THEN
			   IF NVL(ln_bloke_nominal_tutar,0) = 0 THEN
			   	   ln_bloke_toplam_tutar := ln_bloke_nominal_tutar * ln_toplam_alis_tutari / ln_nominal_tutar ;
			   ELSIF NVL(ln_bloke_adet,0) = 0 THEN
			   	   ln_bloke_toplam_tutar := ln_bloke_adet * ln_toplam_alis_tutari / ln_adet ;
			   END IF;
			END IF;

			-- Bu ileri vadeli bir islem ise 'B' bekleme durumunda saklanacak.
			IF ld_portfoye_giris_tarihi <> ld_islem_tarihi THEN
			    ls_ana_stok_durumu := 'B' ;
			ELSE
 				ls_ana_stok_durumu := 'A'  ;
			END IF;

		    -- Once stok hareket tablosuna islem kaydedilir.
			INSERT INTO CBS_MENKUL_STOK_HAREKET
			   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
			   menkul_kiymet_kodu, islem_tarihi, kupur, adet, nominal_tutar, toplam_tutar, verim, bloke_durumu,
			   bloke_adet, bloke_nominal_tutar, musteri_no_kime,hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat,
			   kupon_faizli_fiyat, islenmis_kupon_faizi,prim_iskonto_tutari, repo,
			   trepo, bloke_toplam_tutar,  stok_durumu)
			SELECT
			   stok_no,stok_tanim, depo_turu, saklama_yeri,kime_alindigi,6011,mk_referans_no, menkul_kiymet_kodu,
			   islem_tarihi,kupur, adet, nominal_tutar, toplam_alis_tutari,verim, bloke,bloke_adet, bloke_nominal_tutar,
			   musteri_no_kime,hesap_no_kime,tx_no, dovend_alim_fiyati,temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
			   prim_iskonto_tutari, 'H','H',ln_bloke_toplam_tutar,ls_ana_stok_durumu
			FROM	CBS_MENKUL_BANKA_ALIM_ISLEM
			WHERE   tx_no = pn_islem_no ;

			--Stok ilk defa girildigi icin insert yapiliyor.
			INSERT INTO CBS_MENKUL_STOK
			   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
			   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
			   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
			   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
			   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
			   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
			   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
			   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
			   orj_repo_tutari,repo_adet)
			 SELECT  stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
			   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
			   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
			   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
			   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
			   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
			   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
			   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
			   orj_repo_tutari,repo_adet
			FROM 	CBS_MENKUL_STOK_HAREKET
			WHERE   stok_no 		  = ln_stok_no
			AND 	islem_tipi 		  = 6011
			AND 	islem_referans_no = ls_mk_referans_no
			AND		sira_no 		  = pn_islem_no ;


	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2282' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	    END ;


	ELSIF pn_islem_tipi = 6020 THEN   -- Banka satis islemi ise
		 -- Once hangi stoklari sattiysan, bunlari stok tablosu ve stok hareket tablosuna isle.
		  BEGIN

			OPEN c_banka_satis_stok (pn_islem_no);
			 LOOP
				FETCH   c_banka_satis_stok INTO r_BS ;
 				EXIT WHEN c_banka_satis_stok%NOTFOUND;
 				-- Stok tablosunda son bilgileri guncelle.Satis oldugu icin mali bilgiler guncellenecek.

				-- Bu ileri vadeli bir islem ise stoga bloke koy. Degilse stoktan ilgili tutari dus
				IF r_BS.satis_valor_tarihi <> r_BS.islem_tarihi THEN
					UPDATE CBS_MENKUL_STOK
					SET    BLOKE_DURUMU	  		= 'E',
						   BLOKE_ADET	  		= BLOKE_ADET + r_BS.satilan_nominal_adet,
						   BLOKE_NOMINAL_TUTAR	= BLOKE_NOMINAL_TUTAR + r_BS.satilan_nominal_tutar ,
						   BLOKE_TOPLAM_TUTAR	= BLOKE_TOPLAM_TUTAR  + r_BS.satilanin_maliyeti
					WHERE  stok_no = r_BS.stok_no ;

					INSERT INTO CBS_MENKUL_STOK_HAREKET
					   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
						menkul_kiymet_kodu, islem_tarihi,  kupur, adet, nominal_tutar,
						toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
						hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
						prim_iskonto_tutari, maliyet, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
						bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu,
						deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari,
						yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo_reeskont_faizi,
						yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi, icverim_reeskont_irr,
						yillik_icverim_reeskont_irr, orj_mddaf, orj_repo_tutari,repo_adet)
					SELECT stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, 6020, r_BS.referans_no,
						menkul_kiymet_kodu, r_BS.islem_tarihi, kupur, adet, nominal_tutar,
						toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
						hesap_no_kime, pn_islem_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
						prim_iskonto_tutari,r_BS.satilanin_maliyeti, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
						bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu,
						deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari,
						yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo_reeskont_faizi,
						yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi, icverim_reeskont_irr,
						yillik_icverim_reeskont_irr, orj_mddaf, orj_repo_tutari,repo_adet
					FROM CBS_MENKUL_STOK
					WHERE stok_no = r_BS.stok_no;
					--Sadece bloke konuldugu icin stok tutar duzenle fonksiyonu cagirilmiyor.
				ELSE

					--Eski stok icin durum kotrolu yap. Satilan stok kapatilabilir mi?
					IF r_BS.stokta_kalan_nominal  = 0 THEN
						ls_ana_stok_durumu := 'K' ; -- Once kapat ama nominalin sifir olmasinin bir sebebi varsa ac

						SELECT COUNT(*)
						INTO   ln_count
						FROM   CBS_MENKUL_STOK
						WHERE  ana_stok    =  r_BS.stok_no
						AND    stok_durumu = 'A'
						AND    trepo 	   = 'E' ;

						IF r_BS.repo = 'E' THEN
						   ls_ana_stok_durumu := 'A' ; -- Repo yapilmis olabilir.
						ELSIF ln_count >0 THEN
						   ls_ana_stok_durumu := 'A' ; -- Ters repo yapilmis olabilir
						END IF ;
					 ELSE
					    ls_ana_stok_durumu := 'A' ;
					 END IF;

					 UPDATE CBS_MENKUL_STOK
					 SET    adet 		         = r_BS.stokta_kalan_adet,
						    nominal_tutar        = r_BS.stokta_kalan_nominal,
						    toplam_tutar         = r_BS.stokta_kalan_tutar ,
						    islenmis_kupon_faizi = r_BS.stokta_kalan_IK_faizi ,
						    prim_iskonto_tutari  = r_BS.stokta_kalan_PI_tutari,
						    stok_durumu			 = ls_ana_stok_durumu
					 WHERE  stok_no = r_BS.stok_no ;

					 -- Stok hareket tablosuna bu bilgileri isle
					 INSERT INTO CBS_MENKUL_STOK_HAREKET
						   (stok_no, portfoy_tipi,islem_tipi, islem_referans_no, menkul_kiymet_kodu,islem_tarihi,
						    adet, nominal_tutar,toplam_tutar, maliyet,sira_no,islenmis_kupon_faizi,prim_iskonto_tutari,
							musteri_no_kime	,hesap_no_kime,stok_durumu)
					 VALUES (r_BS.stok_no,r_BS.satilan_portfoy,6020,r_BS.referans_no,r_BS.menkul_kiymet_kodu,
					 		 r_BS.islem_tarihi,r_BS.satilan_nominal_adet, r_BS.satilan_nominal_tutar,
							 r_BS.toplam_satis_tutari,r_BS.satilanin_maliyeti,pn_islem_no, r_BS.islenmis_kupon_faizi,
							 r_BS.prim_iskonto_tutari,r_BS.musteri_no_kimden,r_BS.hesap_no_kimden, ls_ana_stok_durumu);

					 Pkg_Menkul.Stok_Tutar_Duzenle(r_BS.stok_no,6020,pn_islem_no,r_BS.satilan_nominal_tutar) ;
				END IF;

			 END LOOP;
			CLOSE c_banka_satis_stok;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2342' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF pn_islem_tipi = 6030 THEN   -- Repo Giris

		 -- Sonra hangi stoklari repoladiysan, bunlari stok tablosu ve stok hareket tablosuna isle.
		  BEGIN
			OPEN c_repo_giris_islem (pn_islem_no);
			 LOOP
				FETCH   c_repo_giris_islem INTO r_RG ;
				--Repolanan stoklarin bilgileri tek tek islenecek.
				EXIT WHEN c_repo_giris_islem%NOTFOUND;

				-- Bu stoktan rezerve edilen alt stogu bul
				SELECT alt_stok_no
				INTO   ls_alt_stok_no
			  	FROM   CBS_MENKUL_ALT_STOK_HAREKET
				WHERE  ana_stok_no	= r_RG.stok_no
				AND    islem_no     = pn_islem_no ;

				--Alt stok Durum kodu Update edilir.
		        UPDATE CBS_MENKUL_ALT_STOK
			    SET    durumu = 'A'
			    WHERE  alt_stok_no  = ls_alt_stok_no ;


 				-- Stok tablosunda son bilgileri guncelle.Repo oldugu icin mali bilgiler guncellenecek.
				UPDATE CBS_MENKUL_STOK
				SET    adet 		  = r_RG.stoktaki_adet,
					   nominal_tutar  = r_RG.stoktaki_nominal_tutar ,
					   toplam_tutar   = r_RG.stoktaki_toplam_tutar ,
					   repo			  = 'E',
					   repo_nominal   = (r_RG.stoktaki_repo_nominali + r_RG.repo_nominali),
					   repo_tutar     = (r_RG.stoktaki_repo_tutari + r_RG.repo_tutari ),
					   repo_adet      = (r_RG.stoktaki_repo_adedi + r_RG.repo_adedi )
				WHERE  stok_no = r_RG.stok_no ;

				-- Stok hareket tablosuna bu bilgileri isle

				INSERT INTO CBS_MENKUL_STOK_HAREKET
					   (stok_no, stok_tanim, depo_turu,saklama_yeri,portfoy_tipi,islem_tipi, islem_referans_no, menkul_kiymet_kodu,islem_tarihi,
					    ana_stok,kupur,adet, nominal_tutar,toplam_tutar, maliyet,sira_no,
						musteri_no_kime	,hesap_no_kime)
				SELECT r_RG.stok_no, r_RG.stok_tanim, r_RG.depo_turu, r_RG.saklama_yeri,'B',6030,r_RG.referans_no,
					   r_RG.menkul_kiymet_kodu,r_RG.islem_tarihi, r_RG.ana_stok,r_RG.kupur, r_RG.repo_adedi,
					   r_RG.repo_nominali,r_RG.repo_tutari,r_RG.repo_tutari,pn_islem_no,r_RG.musteri_no,r_RG.hesap_no
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no = r_RG.stok_no ;
				-- Stok hareketlerinde repo tutari toplam tutardan dusulmus hali ile saklanacak

				--?PTAL17/03/04 repo geri donecegi icin bu degerleri duzenlemeye gerek kalmadi.
				Pkg_Menkul.Stok_Tutar_Duzenle(r_RG.stok_no,6030,pn_islem_no,r_RG.repo_nominali) ;

			 END LOOP;
			CLOSE c_repo_giris_islem;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2848' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF pn_islem_tipi = 6040 THEN   -- Ters Repo Giris
		 -- Hangi stoklari ters repoladiysan, bunlari stok tablosu ve stok hareket tablosuna isle.
		  BEGIN
			OPEN c_trepo_giris_islem (pn_islem_no);
			 LOOP
				FETCH   c_trepo_giris_islem INTO r_TRG;

				--Repolanan stoklarin bilgileri tek tek islenecek.
				EXIT WHEN c_trepo_giris_islem%NOTFOUND;

				-- 2 hareket yatarilmali. Biri , Ana stoktan 	ters repo yapilmasi
				-- Digeri de yeni dogan stogun ilk kaydi
				-- Stok hareket tablosuna bu bilgileri isle

				--cocuk icin yeni stok no alinacak, referans stokno'ya yazilacak
				ln_tersrepo_stokno := Pkg_Menkul.stok_no_al;

				/* *******************Ana Stok  Bilgileri Hazirlaniyor*************************/

 				-- Ana stok icin Stok tablosunda son bilgileri guncelle.Ters Repo oldugu icin mali bilgiler guncellenecek.
				UPDATE CBS_MENKUL_STOK
				SET    adet 		  = r_TRG.stoktaki_adet,
					   nominal_tutar  = r_TRG.stoktaki_nominal_tutar ,
					   toplam_tutar   = r_TRG.stoktaki_toplam_tutar,
					   orj_repo_tutari= NVL(orj_repo_tutari,0) + r_TRG.orj_repo_tutari	 --???
				WHERE  stok_no 		  = r_TRG.stok_no ;

				/* *****************Hareketler Hazirlaniyor*************************/
				--ana stok hareketi;
				-- Ters repo yapilan tutari ana stok bakiyelerinden dusuyoruz.(Aslinda hepsi de trepo yapilabilir.)

				INSERT INTO CBS_MENKUL_STOK_HAREKET
					   (stok_no, stok_tanim, depo_turu,saklama_yeri,portfoy_tipi,islem_tipi, islem_referans_no,
					   menkul_kiymet_kodu,islem_tarihi,ana_stok,kupur,adet, nominal_tutar,toplam_tutar, maliyet,sira_no,
						musteri_no_kime	,hesap_no_kime)
				SELECT stok_no,stok_tanim, depo_turu, saklama_yeri,r_TRG.kime_alindigi,6040,
						r_TRG.referans_no, menkul_kiymet_kodu,r_TRG.islem_tarihi, ana_stok,kupur, r_TRG.repo_adedi,
					   r_TRG.repo_nominali,r_TRG.repo_tutari,r_TRG.repo_tutari,pn_islem_no,r_TRG.musteri_no,r_TRG.hesap_no
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no = r_TRG.stok_no ;

				Pkg_Menkul.Stok_Tutar_Duzenle(r_TRG.stok_no,6040,pn_islem_no,r_TRG.repo_nominali) ;

				/* ******************* Cocuk Stok  Bilgileri Hazirlaniyor*************************/
				-- cocuk stok hareketi;
				-- Yeni bir stok numarasi alindi. TREPO 'E' olacak, musteri portfoyune alinacak ve
				 --depo turu, ters repo deposu (RRD-1101) olacak

				INSERT INTO CBS_MENKUL_STOK_HAREKET
					   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi,islem_tipi, islem_referans_no,
					    menkul_kiymet_kodu, islem_tarihi, ana_stok, kupur, adet, nominal_tutar, toplam_tutar,bloke_durumu,
						bloke_adet, bloke_nominal_tutar,musteri_no_kime, hesap_no_kime,sira_no,	dovend_fiyati,
						temiz_fiyat,kupon_faizli_fiyat,	maliyet , repo, trepo, trepo_vade)
				VALUES (ln_tersrepo_stokno, r_TRG.stok_tanim, 'RRD-1101', r_TRG.saklama_yeri,'B',6040,r_TRG.referans_no,
					   r_TRG.menkul_kiymet_kodu,r_TRG.islem_tarihi,r_TRG.stok_no,r_TRG.kupur, r_TRG.repo_adedi,
					   r_TRG.repo_nominali,r_TRG.repo_tutari,'H',0,0,r_TRG.musteri_no, r_TRG.hesap_no,pn_islem_no,
					   r_TRG.dovend_fiyati,r_TRG.temiz_fiyat,r_TRG.kupon_faizli_fiyat,r_TRG.satilanin_maliyeti,'H',
					   'E', r_TRG.repo_vade_tarihi);

 				-- Cocuk stok icin stok tablosunda yeni kayit olustur

				INSERT INTO CBS_MENKUL_STOK
				   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
				   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
				   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
				   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
				   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
				   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
				   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
				   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
				   orj_repo_tutari,repo_adet)
				 SELECT  stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
				   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
				   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
				   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
				   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
				   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
				   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
				   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
				   orj_repo_tutari,repo_adet
				FROM 	CBS_MENKUL_STOK_HAREKET
				WHERE   stok_no 		  = ln_tersrepo_stokno
				AND 	islem_tipi 		  = 6040
				AND 	islem_referans_no = r_TRG.referans_no
				AND		sira_no			  = pn_islem_no;

				/* ************************************************************************/

				UPDATE CBS_MENKUL_TREPO_GIRIS_STOK
				SET    trepo_stok_no  = ln_tersrepo_stokno
				WHERE  referans_no    = r_TRG.referans_no
				AND	   stok_no		  = r_TRG.stok_no ;

				UPDATE CBS_MENKUL_TREPO_GIRIS_STOKISL
				SET    trepo_stok_no  = ln_tersrepo_stokno
				WHERE  tx_no		  = pn_islem_no
				AND	   stok_no		  = r_TRG.stok_no ;

			 END LOOP;
			CLOSE c_trepo_giris_islem;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2984' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF pn_islem_tipi = 6043 THEN   -- Ters Repo Donus ?ptal
		 -- Hangi stoklari ters repoladiysan, bunlari stok tablosu ve stok hareket tablosuna isle.
		  BEGIN
			-- ?nce donus iptal isleminin referansini al
		    SELECT referans_no,islem_tarihi
		    INTO   ls_mk_referans_no,ld_islem_tarihi
		    FROM   CBS_MENKUL_TREPO_DONUS_IPTISL
		    WHERE  tx_no = pn_islem_no ;

			-- Donen ters repo stok degerlerini bul
			OPEN  c_trepo_donus_iptal (pn_islem_no);
		    LOOP
		      FETCH  c_trepo_donus_iptal INTO r_trepo_donus_iptal;
		      EXIT WHEN c_trepo_donus_iptal%NOTFOUND;

				--ters repoya konu olan stok bilgilerini bul
				SELECT adet , nominal_tutar , toplam_tutar , repo , repo_nominal , repo_tutar
				INTO   ln_stok_adet , ln_stok_nominal , ln_stok_toplam_tutar,
					   ls_stok_repo , ln_stok_repo_nominal , ln_stok_repo_tutar
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no = r_trepo_donus_iptal.stok_no ;

				--repo donmeden onceki olmasi gereken stok degerlerini bul
				ln_stok_adet   	 		:= ln_stok_adet - r_trepo_donus_iptal.repo_adedi;
				ln_stok_nominal 		:= ln_stok_nominal - r_trepo_donus_iptal.repo_nominali ;
				ln_stok_toplam_tutar 	:= ln_stok_toplam_tutar - r_trepo_donus_iptal.repo_tutari;

				-- bunlari yerine koy
				UPDATE CBS_MENKUL_STOK
				SET	   adet 		 = ln_stok_adet  ,
					   nominal_tutar = ln_stok_nominal ,
					   toplam_tutar  = ln_stok_toplam_tutar
				WHERE  stok_no 		 = r_trepo_donus_iptal.stok_no ;

				-- Repoya konu olan stoklar icin  ters repo donus iptal hareketi yarat
				INSERT INTO CBS_MENKUL_STOK_HAREKET
				SELECT   stok_no, stok_tanim, depo_turu,saklama_yeri, portfoy_tipi, 6043, ls_mk_referans_no ,
						 menkul_kiymet_kodu, ld_islem_tarihi,ana_stok, NULL , kupur,adet, nominal_tutar,
						 toplam_tutar,NULL, bloke_durumu, bloke_adet,bloke_nominal_tutar, musteri_no_kime,
						 hesap_no_kime, pn_islem_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat,
						 islenmis_kupon_faizi, prim_iskonto_tutari,NULL, repo, repo_nominal,repo_tutar, trepo,
						 trepo_vade,NULL, bloke_toplam_tutar, virman_yeri,bildirim_birim_fiyati, tcmb_birim_fiyati,
						 stok_durumu, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
						 yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari,
						 yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
						 yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr,orj_mddaf,orj_repo_tutari,NULL
				FROM    CBS_MENKUL_STOK
				WHERE   stok_no =  r_trepo_donus_iptal.stok_no ;

				Pkg_Menkul.Stok_Tutar_Duzenle(r_trepo_donus_iptal.stok_no,6043,pn_islem_no,r_trepo_donus_iptal.repo_nominali) ;


				-- Simdide ters repo donus sonrasi yeni acilan stoklari ac ve hareket olustur.
				UPDATE CBS_MENKUL_STOK
				SET	   stok_durumu 	 = 'A'
				WHERE  stok_no 		 = r_trepo_donus_iptal.trepo_stok_no ;

				INSERT INTO CBS_MENKUL_STOK_HAREKET
				SELECT   stok_no, stok_tanim, depo_turu,saklama_yeri, portfoy_tipi, 6043,ls_mk_referans_no ,
						 menkul_kiymet_kodu, ld_islem_tarihi,ana_stok, NULL , kupur,adet, nominal_tutar,
						 toplam_tutar,NULL, bloke_durumu, bloke_adet,bloke_nominal_tutar, musteri_no_kime,
						 hesap_no_kime, pn_islem_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat,
						 islenmis_kupon_faizi, prim_iskonto_tutari,NULL, repo, repo_nominal,repo_tutar, trepo,
						 trepo_vade,NULL, bloke_toplam_tutar, virman_yeri,bildirim_birim_fiyati, tcmb_birim_fiyati	,
						 stok_durumu, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
						 yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari,
						 yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
						 yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr,orj_mddaf,orj_repo_tutari,NULL
				FROM    CBS_MENKUL_STOK
				WHERE   stok_no =  r_trepo_donus_iptal.trepo_stok_no  ;

				Pkg_Menkul.Stok_Tutar_Duzenle(r_trepo_donus_iptal.trepo_stok_no,6043,pn_islem_no,r_trepo_donus_iptal.repo_nominali) ;
				-- Donus tablolarina bilgileri kaydetmek gerekiyor

		    END LOOP;
		    CLOSE c_trepo_donus_iptal;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3788' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF pn_islem_tipi = 6047 THEN   -- Banka Ters Repo Donus ?ptal
		 -- Hangi stoklari ters repoladiysan, bunlari stok tablosu ve stok hareket tablosuna isle.
		  BEGIN

			-- Donen ters repo stok degerlerini bul
			OPEN  c_banka_trepo_donus_iptal (pn_islem_no);
		    LOOP
		      FETCH  c_banka_trepo_donus_iptal INTO r_banka_trepo_donus_iptal;
		      EXIT WHEN c_banka_trepo_donus_iptal%NOTFOUND;

				-- bunlari yerine koy
				UPDATE CBS_MENKUL_STOK
				SET	   stok_durumu 	 = 'A'
				WHERE  stok_no 		 = r_banka_trepo_donus_iptal.stok_no ;

				-- Repoya konu olan stoklar icin  ters repo donus iptal hareketi yarat
				INSERT INTO CBS_MENKUL_STOK_HAREKET
				SELECT   stok_no, stok_tanim, depo_turu,saklama_yeri, portfoy_tipi, 6047, r_banka_trepo_donus_iptal.referans_no ,
						 menkul_kiymet_kodu, r_banka_trepo_donus_iptal.islem_tarihi,ana_stok, NULL , kupur,adet, nominal_tutar,
						 toplam_tutar,NULL, bloke_durumu, bloke_adet,bloke_nominal_tutar, musteri_no_kime,
						 hesap_no_kime, pn_islem_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat,
						 islenmis_kupon_faizi, prim_iskonto_tutari,NULL, repo, repo_nominal,repo_tutar, trepo,
						 trepo_vade,NULL, bloke_toplam_tutar, virman_yeri,bildirim_birim_fiyati, tcmb_birim_fiyati,
						 stok_durumu, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
						 yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari,
						 yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
						 yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr,orj_mddaf,orj_repo_tutari,NULL
				FROM    CBS_MENKUL_STOK
				WHERE   stok_no =  r_banka_trepo_donus_iptal.stok_no ;

				Pkg_Menkul.Stok_Tutar_Duzenle(r_banka_trepo_donus_iptal.stok_no ,6047,pn_islem_no,r_banka_trepo_donus_iptal.nominal_tutar) ;
				-- Donus tablolarina bilgileri kaydetmek gerekiyor

		    END LOOP;
		    CLOSE c_banka_trepo_donus_iptal;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3907' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF  pn_islem_tipi = 6044 THEN   -- Banka ters repo islemi ise
		BEGIN
			-- ?nce hesaplamalar ya da arama kriterleri icin ihtiyacin olan kayitlari al.
			SELECT stok_no,toplam_repo_tutari, ln_adet,ln_nominal_tutar,  referans_no
			INTO   ln_stok_no,ln_toplam_alis_tutari,ln_adet, ln_nominal_tutar , ls_mk_referans_no
			FROM   CBS_MENKUL_BANKA_TREPO_GIRISL
			WHERE  tx_no = pn_islem_no ;

		    -- ?nce stok hareket tablosuna islem kaydedilir.

			INSERT INTO CBS_MENKUL_STOK_HAREKET
			   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
			    menkul_kiymet_kodu, islem_tarihi, kupur, adet, nominal_tutar, toplam_tutar, verim, bloke_durumu,
			    musteri_no_kime,hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat,  stok_durumu)
			SELECT
			   stok_no,'TRP', 'RRD-1101', saklama_yeri,'B',6044,REFERANS_NO, menkul_kiymet_kodu,islem_tarihi,kupur,
			   NVL(adet,0), NVL(nominal_tutar,0),NVL(toplam_repo_tutari,0),NVL(toplam_repo_tutari,0), 'H',
			   musteri_no,hesap_no,tx_no, 	NVL(kiymet_birim_fiyati,0), NVL(kiymet_birim_fiyati,0),
			   NVL(kiymet_birim_fiyati,0), 'A'
			FROM	CBS_MENKUL_BANKA_TREPO_GIRISL
			WHERE   tx_no = pn_islem_no ;


			--Stok ilk defa girildigi icin insert yapiliyor. Guncellemesinde update yapilacak.
			INSERT INTO CBS_MENKUL_STOK
				   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
				    nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu,
					ana_stok, musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat,
					islenmis_kupon_faizi, prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari,
					reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
					yillik_reeskont_tutari, yillik_mddaf, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
					bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, repo_reeskont_faizi,
					yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,
					icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf, orj_repo_tutari, repo_adet)
			SELECT  stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
					nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu,
					ana_stok, musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat,
					islenmis_kupon_faizi, prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari,
					reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
					yillik_reeskont_tutari, yillik_mddaf, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
					bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, repo_reeskont_faizi,
					yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,
					icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim,orj_mddaf,orj_repo_tutari,repo_adet
			FROM 	CBS_MENKUL_STOK_HAREKET
			WHERE   stok_no 		  = ln_stok_no
			AND 	islem_tipi 		  = 6044
			AND 	islem_referans_no = ls_mk_referans_no
			AND		sira_no 		  = pn_islem_no ;


	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3892' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	    END ;

	ELSIF  pn_islem_tipi = 6024 THEN   -- Emanete Giris islemi ise
		 -- Once stok hareket tablosuna islem kaydedilir.
		  BEGIN
			OPEN c_emanete_giris(pn_islem_no);
			 LOOP
				FETCH   c_emanete_giris
				INTO    ln_stok_no, ls_depo_turu,ln_saklama_yeri,ls_mk_referans_no,
					   	ls_menkul_kiymet_kodu, ld_emanete_giris_tarihi,ln_kupur,ln_adet,
						ln_nominal_tutar, ls_bloke, ln_bloke_adet,ln_bloke_nominal_tutar,
						ln_musteri_no, ln_hesap_no,ln_bloke_toplam_tutar,ln_virman_yeri,
						ln_bildirim_birim_fiyati,ln_tcmb_birim_fiyati;

				EXIT WHEN c_emanete_giris%NOTFOUND;

				ln_menkul_kiymet_tipi  := Pkg_Menkul.menkul_kiymet_tipi_al(ls_menkul_kiymet_kodu);
				IF NVL(ln_bildirim_birim_fiyati,0) = 0 THEN
					ln_toplam_alis_tutari := ln_tcmb_birim_fiyati  ;
				ELSE
					ln_toplam_alis_tutari := ln_bildirim_birim_fiyati  ;
				END IF;

				IF ln_menkul_kiymet_tipi = 1 THEN
					ln_toplam_alis_tutari := ln_toplam_alis_tutari * ln_nominal_tutar/1000;
				ELSE
					ln_toplam_alis_tutari := ln_toplam_alis_tutari * ln_nominal_tutar/100;
				END IF;


				INSERT INTO CBS_MENKUL_STOK_HAREKET (
					 	    stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
							menkul_kiymet_kodu, islem_tarihi, ana_stok, referans_stok, kupur, adet, nominal_tutar,
							toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
							hesap_no_kime, sira_no, repo, repo_nominal, repo_tutar, trepo, trepo_vade, alt_stok_no,
							bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu)
				VALUES (	ln_stok_no, NULL, ls_depo_turu,ln_saklama_yeri, 'M', 6024,ls_mk_referans_no,
					   		ls_menkul_kiymet_kodu, ld_emanete_giris_tarihi, NULL,NULL,ln_kupur,ln_adet,
							ln_nominal_tutar, ln_toplam_alis_tutari,NULL, ls_bloke, ln_bloke_adet,
							ln_bloke_nominal_tutar,ln_musteri_no, ln_hesap_no,pn_islem_no, 'H', NULL,NULL,
							'H',NULL,NULL,ln_bloke_toplam_tutar,ln_virman_yeri,ln_bildirim_birim_fiyati,
							ln_tcmb_birim_fiyati,'A');

			    -- Sonra stok tablosuna islem kaydedilir.
				BEGIN
					--Stok ilk defa girildigi icin insert yapiliyor. Guncellemesinde update yapilacak.
					INSERT INTO CBS_MENKUL_STOK
						   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur,
						   adet, nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar,
						   stok_durumu, ana_stok, musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat,
						   kupon_faizli_fiyat, islenmis_kupon_faizi, prim_iskonto_tutari, deger_dusuklugu_tutari,
						   deger_artis_tutari, reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari,
						   yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo, repo_nominal,
						   repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
						   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
						   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim,
						   orj_mddaf, orj_repo_tutari, repo_adet)
					SELECT stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
						   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu,
						   ana_stok, musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat,
						   islenmis_kupon_faizi, prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari,
						   reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
						   yillik_reeskont_tutari, yillik_mddaf, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
						   bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, repo_reeskont_faizi,
						   yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi, icverim_reeskont_irr,
						   yillik_icverim_reeskont_irr, verim,orj_mddaf,orj_repo_tutari,repo_adet
					FROM   CBS_MENKUL_STOK_HAREKET
					WHERE  stok_no 		      = ln_stok_no
					AND    islem_tipi 		  = 6024
					AND    islem_referans_no  = ls_mk_referans_no
					AND	   sira_no			  = pn_islem_no ;

			  	    EXCEPTION
					  WHEN OTHERS THEN
					  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
					    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3185' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
			    END ;

			 END LOOP;
			 CLOSE c_emanete_giris;


	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3186' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;


	ELSIF  pn_islem_tipi = 6026 THEN   -- Emanet Cikis islemi ise
		 -- Once stok hareket tablosuna islem kaydedilir.
		  BEGIN
			OPEN c_emanet_cikis(pn_islem_no);
			 LOOP
				FETCH   c_emanet_cikis
				INTO    ln_stok_no, ls_depo_turu,ln_saklama_yeri,ls_mk_referans_no,ls_menkul_kiymet_kodu,
						ld_islem_tarihi,ln_ana_stok,ln_kupur,ln_stoktaki_adet,ln_stoktaki_nominal_tutar,
						ln_stoktaki_toplam_tutar,ls_bloke, ln_bloke_adet,ln_bloke_nominal_tutar,
						ln_musteri_no, ln_virman_yeri,ln_tcmb_birim_fiyati,ln_bloke_toplam_tutar,ln_hesap_no,
						ls_repo,ln_nominal_tutar,ln_adet;
				EXIT WHEN c_emanet_cikis%NOTFOUND;

				IF ln_stoktaki_nominal_tutar  = 0 THEN
					ls_ana_stok_durumu := 'K' ; -- Once kapat ama nominalin sifir olmasinin bir sebebi varsa ac

					  SELECT COUNT(*)
					  INTO   ln_count
					  FROM   CBS_MENKUL_STOK
					  WHERE  ana_stok    = ln_stok_no
					  AND 	 stok_durumu = 'A'
					  AND    trepo 		 = 'E' ;

					IF ls_repo = 'E' THEN
					   ls_ana_stok_durumu := 'A' ;  -- Repo yapilmis olabilir.
					ELSIF ln_count >0 THEN
					 	 ls_ana_stok_durumu := 'A' ; -- Ters repo yapilmis olabilir
					END IF ;
				ELSE
				  ls_ana_stok_durumu := 'A' ;
				END IF;

 				--Stogun sadece bir bolumunu cikabilecegi icin, geri kalani etkilemesin diye
				--virman yeri ta da tcmb fiyatini update etmiyorum. Zaten stok harekette tutuyorum.
				--Sadece tutar bilgileri degisecek.

				UPDATE CBS_MENKUL_STOK
				SET    adet 		  = ln_stoktaki_adet,
					   nominal_tutar  = ln_stoktaki_nominal_tutar ,
					   toplam_tutar   = ln_stoktaki_toplam_tutar ,
					   stok_durumu	  = ls_ana_stok_durumu
				WHERE  stok_no = ln_stok_no ;

				INSERT INTO CBS_MENKUL_STOK_HAREKET
					   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
					   menkul_kiymet_kodu, islem_tarihi, ana_stok, referans_stok, kupur, adet, nominal_tutar,
					   toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
					   hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, maliyet, repo, repo_nominal, repo_tutar, trepo, trepo_vade, alt_stok_no,
					   bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu,
					   deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari,
					   yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
					   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, orj_mddaf,
					   orj_repo_tutari, repo_adet)
				SELECT stok_no, stok_tanim, depo_turu, saklama_yeri,ls_kime_alindigi,6026,ls_mk_referans_no,
					   menkul_kiymet_kodu,ld_islem_tarihi, ana_stok, NULL, kupur, ln_adet, ln_nominal_tutar,
					   toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
					   hesap_no_kime,pn_islem_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, NULL, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
					   NULL, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati,
					   stok_durumu, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf,
					   repo_reeskont_faizi,yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,
					   icverim_reeskont_irr,yillik_icverim_reeskont_irr,orj_mddaf,orj_repo_tutari,NULL
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no = ln_stok_no ;

				-- Stok hareketlerinde temiz, kirli fiyat gibi yeni degerler olacak ama ana stok
				--tablosunda aldigim zamanki degerler kalacak

				Pkg_Menkul.Stok_Tutar_Duzenle(ln_stok_no,6026,pn_islem_no,ln_nominal_tutar) ;


			 END LOOP;
			 CLOSE c_emanet_cikis;

	  	     EXCEPTION
			   WHEN OTHERS THEN
			   	 ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3277' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

  	ELSIF  pn_islem_tipi = 6050 THEN   -- Stok Devir islemi ise
		 -- Once Yeni olusan stok icin hareket ve stok bilgisi olusturulmali
		  BEGIN

			OPEN c_stok_devir_yenistok(pn_islem_no) ;
			 LOOP
				FETCH   c_stok_devir_yenistok INTO r_SD_Yeni;
				EXIT WHEN c_stok_devir_yenistok%NOTFOUND;

				INSERT INTO CBS_MENKUL_STOK_HAREKET
				   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
				   menkul_kiymet_kodu, islem_tarihi, kupur, adet, nominal_tutar, toplam_tutar,  bloke_durumu,sira_no,
				   temiz_fiyat,kupon_faizli_fiyat,islenmis_kupon_faizi,prim_iskonto_tutari, repo,trepo, stok_durumu)
			    VALUES (
			      r_SD_Yeni.stok_no, r_SD_Yeni.stok_tanim, r_SD_Yeni.depo_turu,r_SD_Yeni.saklama_yeri, 'B', 6050,
			      r_SD_Yeni.referans_no,r_SD_Yeni.menkul_kiymet_kodu,r_SD_Yeni.islem_tarihi,r_SD_Yeni.kupur,r_SD_Yeni.devir_adet,
				  r_SD_Yeni.devir_nominal, r_SD_Yeni.devir_maliyeti,'H',pn_islem_no, r_SD_Yeni.temiz_fiyat,
				  r_SD_Yeni.kupon_faizli_fiyat, r_SD_Yeni.islenmis_kupon_faizi,r_SD_Yeni.prim_iskonto_tutari,'H','H','A');

			    -- Sonra stok tablosuna islem kaydedilir.
				BEGIN
					--Stok ilk defa girildigi icin insert yapiliyor. Guncellemesinde update yapilacak.
					INSERT INTO CBS_MENKUL_STOK
					   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
					   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
					   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
					   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
					   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
					   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
					   orj_repo_tutari,repo_adet)
					 SELECT  stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
					   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
					   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
					   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
					   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
					   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
					   orj_repo_tutari,repo_adet
					 FROM 	CBS_MENKUL_STOK_HAREKET
					 WHERE  stok_no 		  = r_SD_Yeni.stok_no
					 AND 	islem_tipi 		  = 6050
					 AND 	islem_referans_no = r_SD_Yeni.referans_no
					 AND	sira_no			  = pn_islem_no;

					ln_yeni_stok := r_SD_Yeni.stok_no;

			  	    EXCEPTION
					  WHEN OTHERS THEN
					  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
					    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3464' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
			    END ;

			 END LOOP;
			 CLOSE c_stok_devir_yenistok;


			 -- Sonra hangi stoklari devrettiysen, bunlari stok tablosu ve stok hareket tablosuna isle.
			BEGIN
				OPEN c_stok_devir_eskistok (pn_islem_no);
				 LOOP
					FETCH   c_stok_devir_eskistok INTO r_SD_Eski ;
					EXIT WHEN c_stok_devir_eskistok%NOTFOUND;

					IF ls_stok_tanim = 'ASP' THEN
					   ln_yeni_mddaf	:= NVL(ln_yeni_mddaf,0) + r_SD_Eski.mddaf ;
					END IF;

					--Eski stok icin durum kotrolu yap. Devredilen stok kapatilabilir mi?
					IF r_SD_Eski.stokta_kalan_nominal  = 0 THEN
						ls_ana_stok_durumu := 'K' ; -- Once kapat ama nominalin sifir olmasinin bir sebebi varsa ac

						  SELECT COUNT(*)
						  INTO   ln_count
						  FROM   CBS_MENKUL_STOK
						  WHERE  ana_stok    = r_SD_Eski.stok_no
						  AND 	 stok_durumu = 'A'
						  AND    trepo 		 = 'E' ;

						IF r_SD_Eski.repo = 'E' THEN
						   ls_ana_stok_durumu := 'A' ;  -- Repo yapilmis olabilir.
						ELSIF ln_count >0 THEN
						 	 ls_ana_stok_durumu := 'A' ; -- Ters repo yapilmis olabilir
						END IF ;
					ELSE
					  ls_ana_stok_durumu := 'A' ;
					END IF;

					UPDATE     CBS_MENKUL_STOK
					SET     	adet 		         = r_SD_Eski.stokta_kalan_adet,
							    nominal_tutar        = r_SD_Eski.stokta_kalan_nominal,
							    toplam_tutar         = r_SD_Eski.stokta_kalan_tutar ,
							    islenmis_kupon_faizi = r_SD_Eski.stokta_kalan_IK_faizi ,
							    prim_iskonto_tutari  = r_SD_Eski.stokta_kalan_PI_tutari,
							    stok_durumu			 = ls_ana_stok_durumu
					WHERE  stok_no = r_SD_Eski.stok_no ;

					-- Stok hareket tablosuna bu bilgileri isle

					INSERT INTO CBS_MENKUL_STOK_HAREKET
						   (stok_no,stok_tanim, depo_turu, saklama_yeri,portfoy_tipi,islem_tipi, islem_referans_no,
						    menkul_kiymet_kodu,islem_tarihi, adet, nominal_tutar,toplam_tutar,sira_no,
							islenmis_kupon_faizi,prim_iskonto_tutari,stok_durumu)
					VALUES ( r_SD_Eski.stok_no, r_SD_Eski.stok_tanim,  r_SD_Eski.depo_turu,  r_SD_Eski.saklama_yeri,
						   r_SD_Eski.kime_alindigi, 6050, r_SD_Eski.referans_no, r_SD_Eski.menkul_kiymet_kodu,
						   r_SD_Eski.islem_tarihi,r_SD_Eski.devir_adet ,  r_SD_Eski.devir_nominal,  r_SD_Eski.devir_maliyeti,
						   pn_islem_no, r_SD_Eski.islenmis_kupon_faizi, r_SD_Eski.prim_iskonto_tutari,ls_ana_stok_durumu);


					Pkg_Menkul.Stok_Tutar_Duzenle( r_SD_Eski.stok_no,6050,pn_islem_no, r_SD_Eski.devir_nominal) ;

				 END LOOP;
				CLOSE c_stok_devir_eskistok;

		  	    EXCEPTION
				  WHEN OTHERS THEN
				  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3467' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
			END ;

			-- Eski stoklardan glen toplam gunluk mddaf'yi ,yeni olusan stogun orj_mddaf'si olarak belirle.
			UPDATE  CBS_MENKUL_STOK
			SET		orj_mddaf = ln_yeni_mddaf
			WHERE   stok_no   = r_SD_Yeni.stok_no ;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3465' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF  pn_islem_tipi = 6034 THEN   -- Repo Bozum islemi ise
	  BEGIN
		--  Once Repo yapilan tutarlar, ana stoga geri dondurulmeli
		OPEN  c_repo_bozum(pn_islem_no);
	    LOOP
	      FETCH  c_repo_bozum INTO r_repo;
	      EXIT WHEN c_repo_bozum%NOTFOUND;

			--ana stok bilgilerini bul
			SELECT adet , nominal_tutar , toplam_tutar , repo , repo_nominal , repo_tutar,repo_adet
			INTO   ln_stok_adet , ln_stok_nominal , ln_stok_toplam_tutar,
				   ls_stok_repo , ln_stok_repo_nominal , ln_stok_repo_tutar,ln_stok_repo_adet
			FROM   CBS_MENKUL_STOK
			WHERE  stok_no = r_repo.ana_stok_no ;

			--repo bozulunca olmasi gereken stok degerlerini bul
			ln_stok_adet   	 		:= ln_stok_adet + r_repo.adet;
			ln_stok_nominal 		:= ln_stok_nominal + r_repo.nominal_tutar ;
			ln_stok_toplam_tutar 	:= ln_stok_toplam_tutar + r_repo.toplam_tutar;
			-- Repolanan tutarlari dus
			ln_stok_repo_nominal    := ln_stok_repo_nominal - r_repo.nominal_tutar ;
			ln_stok_repo_tutar      := ln_stok_repo_tutar - r_repo.toplam_tutar ;
			ln_stok_repo_adet       := ln_stok_repo_adet - r_repo.adet ;

			-- Kalan Repo tutarina gore bakiye kalmiyorsa repo durumunu duzelt
			IF ln_stok_repo_nominal >0 THEN
			   ls_stok_repo := 'E';
			ELSE
			   ls_stok_repo := 'H';
			END IF;

			-- Ana stoktaki bakiyeleri yerine koy.
			UPDATE CBS_MENKUL_STOK
			SET	   adet 		 = ln_stok_adet  ,
				   nominal_tutar = ln_stok_nominal ,
				   toplam_tutar  = ln_stok_toplam_tutar ,
				   repo			 = ls_stok_repo ,
				   repo_nominal  = ln_stok_repo_nominal,
				   repo_tutar    = ln_stok_repo_tutar,
   				   repo_adet     = ln_stok_repo_adet
			WHERE  stok_no 		 = r_repo.ana_stok_no ;

			SELECT referans_no ,repo_bozum_tarihi
			INTO   ls_referans_no ,ld_islem_tarihi
			FROM   CBS_MENKUL_REPO_BOZUM_ISLEM
		   	WHERE  tx_no = pn_islem_no;


			-- Ana stok icin repo bozum hareketi yarat
			INSERT INTO CBS_MENKUL_STOK_HAREKET
				   (stok_no, stok_tanim, depo_turu,saklama_yeri,portfoy_tipi,islem_tipi, islem_referans_no, menkul_kiymet_kodu,islem_tarihi,
				    ana_stok,kupur,adet, nominal_tutar,toplam_tutar, maliyet,sira_no,
					musteri_no_kime	,hesap_no_kime,alt_stok_no)
			SELECT stok_no, stok_tanim, depo_turu, saklama_yeri,'B',6034,ls_referans_no,
				   menkul_kiymet_kodu,ld_islem_tarihi, ana_stok,kupur,r_repo.adet,
				   r_repo.nominal_tutar,r_repo.toplam_tutar,r_repo.toplam_tutar,pn_islem_no,
				   musteri_no_kime	,hesap_no_kime,ls_alt_stok_no
			FROM   CBS_MENKUL_STOK
			WHERE  stok_no = r_repo.ana_stok_no;

			--repo tutari kadar geri koyuyoruz.
			Pkg_Menkul.Stok_Tutar_Duzenle_iptal(r_repo.ana_stok_no,r_repo.nominal_tutar ) ;


			-- Donusu yapilan alt stok icin hareket yarat
			INSERT INTO CBS_MENKUL_ALT_STOK_HAREKET
				   (alt_stok_no, ana_stok_no, islem_turu, depo_turu, adet,nominal_tutar, toplam_tutar,
				   islem_tarihi, musteri_no, hesap_no,islem_no,islem_referans_no)
			VALUES (r_repo.alt_stok_no, r_repo.ana_stok_no, 'REPO_BOZUM', r_repo.depo_turu,r_repo.adet,
					r_repo.nominal_tutar,r_repo.toplam_tutar,ld_islem_tarihi,r_repo.musteri_no,
					r_repo.hesap_no,pn_islem_no,ls_referans_no) ;

			--Alt stoktan donen kayitlarin durumu kapaliya cevrilecek
			UPDATE  CBS_MENKUL_ALT_STOK
			SET     durumu 	 = 'K'
			WHERE   islem_referans_no = r_repo.islem_referans_no
			AND 	alt_stok_no 	  = r_repo.alt_stok_no;

	    END LOOP;
	    CLOSE c_repo_bozum;

	    EXCEPTION
   	     WHEN OTHERS THEN
		 	RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3673' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	  END;

	ELSIF  pn_islem_tipi = 6035 THEN   -- Repo Donus Iptal islemi ise
	  BEGIN

		-- Once donus iptal isleminin referansini al
	    SELECT referans_no,islem_tarihi,yeni_vade_tarihi, yeni_oran
	    INTO   ls_mk_referans_no,ld_islem_tarihi,ld_yeni_vade_tarihi, ln_yeni_oran
	    FROM   CBS_MENKUL_REPO_DONUS_IPTISL
	    WHERE  tx_no = pn_islem_no ;

		--  ?nce Repo donus yapilan tutarlar, ana stoga geri dondurulmeli
		OPEN  c_repo_donus_iptal(pn_islem_no);
	    LOOP
	      FETCH  c_repo_donus_iptal INTO r_repo_donus_iptal;
	      EXIT WHEN c_repo_donus_iptal%NOTFOUND;

			--ana stok bilgilerini bul
			SELECT adet , nominal_tutar , toplam_tutar , repo , repo_nominal , repo_tutar,repo_adet
			INTO   ln_stok_adet , ln_stok_nominal , ln_stok_toplam_tutar,
				   ls_stok_repo , ln_stok_repo_nominal , ln_stok_repo_tutar,ln_stok_repo_adet
			FROM   CBS_MENKUL_STOK
			WHERE  stok_no = r_repo_donus_iptal.ana_stok_no ;

			--repo donus oncesi stok degerlerini bul
			ln_stok_adet   	 		:= ln_stok_adet - r_repo_donus_iptal.adet;
			ln_stok_nominal 		:= ln_stok_nominal - r_repo_donus_iptal.nominal_tutar ;
			ln_stok_toplam_tutar 	:= ln_stok_toplam_tutar - r_repo_donus_iptal.toplam_tutar;

			-- Repolanan tutarlari dus
			ln_stok_repo_nominal    := ln_stok_repo_nominal + r_repo_donus_iptal.nominal_tutar ;
			ln_stok_repo_tutar      := ln_stok_repo_tutar + r_repo_donus_iptal.toplam_tutar ;
			ln_stok_repo_adet		:= ln_stok_repo_adet + r_repo_donus_iptal.adet ;
			-- Repo donusu geri aldigimiz icin stok hala repolu
		    ls_stok_repo := 'E';

			-- Ana stoktaki bakiyeleri yerine koy.
			UPDATE CBS_MENKUL_STOK
			SET	   adet 		 = ln_stok_adet  ,
				   nominal_tutar = ln_stok_nominal ,
				   toplam_tutar  = ln_stok_toplam_tutar ,
				   repo			 = ls_stok_repo ,
				   repo_nominal  = ln_stok_repo_nominal,
				   repo_tutar    = ln_stok_repo_tutar,
				   repo_adet     = ln_stok_repo_adet
			WHERE  stok_no 		 = r_repo_donus_iptal.ana_stok_no ;

		   -- Ana stok icin hareket yarat
			INSERT INTO CBS_MENKUL_STOK_HAREKET
				   (stok_no, stok_tanim, depo_turu,saklama_yeri,portfoy_tipi,islem_tipi, islem_referans_no, menkul_kiymet_kodu,islem_tarihi,
				    ana_stok,kupur,adet, nominal_tutar,toplam_tutar, maliyet,sira_no,
					musteri_no_kime	,hesap_no_kime,alt_stok_no)
			SELECT stok_no, stok_tanim, depo_turu, saklama_yeri,'B',6035,ls_mk_referans_no,
				   menkul_kiymet_kodu,ld_islem_tarihi, ana_stok,kupur,r_repo.adet,
				   r_repo_donus_iptal.nominal_tutar,r_repo_donus_iptal.toplam_tutar,
				   r_repo_donus_iptal.toplam_tutar,pn_islem_no,
				   musteri_no_kime	,hesap_no_kime,ls_alt_stok_no
			FROM   CBS_MENKUL_STOK
			WHERE  stok_no = r_repo_donus_iptal.ana_stok_no ;


			--repo tutari kadar geri koyuyoruz.
			Pkg_Menkul.Stok_Tutar_Duzenle(r_repo_donus_iptal.ana_stok_no ,6035,pn_islem_no,r_repo.nominal_tutar ) ;


		   --alt stogu kapatmistik. Tekrar acik hale getirmemiz gerekir.vade ve oran da degisebilir diye update ediyoruz
		   UPDATE  CBS_MENKUL_ALT_STOK
		   SET     durumu 	   = 'A',
		   		   vade		   = ld_yeni_vade_tarihi,
				   oran_net    = ln_yeni_oran
		   WHERE   alt_stok_no = r_repo_donus_iptal.alt_stok_no  ;

		   INSERT INTO CBS_MENKUL_ALT_STOK_HAREKET
		   SELECT alt_stok_no, ana_stok_no,'REPO_DONUSIPTAL', depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu,
		   		  adet, nominal_tutar, toplam_tutar,ld_islem_tarihi, ld_yeni_vade_tarihi, musteri_no, hesap_no, pn_islem_no, ln_yeni_oran,
		   		  ls_referans_no
		   FROM   CBS_MENKUL_ALT_STOK
		   WHERE  alt_stok_no =  r_repo_donus_iptal.alt_stok_no
		   AND    durumu 	  = 'A';

	    END LOOP;
	    CLOSE c_repo_donus_iptal;

	    EXCEPTION
   	     WHEN OTHERS THEN
		 	RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3778' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	  END;

	ELSIF  pn_islem_tipi = 6052 THEN   -- Bloke Koyma
		 -- ?nce stok hareket tablosuna islem kaydedilir.
		  BEGIN
			OPEN c_bloke_koyma (pn_islem_no);
			 LOOP
				FETCH   c_bloke_koyma
				INTO    ln_stok_no,ls_mk_referans_no,ld_islem_tarihi,ln_bloke_adet,
						ln_bloke_nominal_tutar,ln_bloke_toplam_tutar;
				EXIT WHEN c_bloke_koyma%NOTFOUND;

				--Once bloke koyulan tutarlari cbs_menkul_bloke_koyma tablosundan aldik. Sonrada stok tablosundan ilgili stogun
				--bloke bilgilerini aliyoruz.
				SELECT bloke_durumu,NVL(bloke_adet,0),NVL(bloke_nominal_tutar,0),NVL(bloke_toplam_tutar,0)
				INTO   ls_stok_bloke_durumu,ln_stok_bloke_adet,ln_stok_bloke_nominal_tutar,ln_stok_bloke_toplam_tutar
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no =  ln_stok_no ;

				--stok tablosunu yeni degerleri ile update et.
				UPDATE CBS_MENKUL_STOK
				SET    bloke_durumu   		= 'E' ,
					   bloke_adet     	   	=  ln_stok_bloke_adet + ln_bloke_adet ,
					   bloke_nominal_tutar  =  ln_stok_bloke_nominal_tutar + ln_bloke_nominal_tutar ,
 					   bloke_toplam_tutar	=  ln_stok_bloke_toplam_tutar + ln_bloke_toplam_tutar
				WHERE  stok_no =  ln_stok_no ;

				-- Stoktaki bu hareketle ilgili kayit olustur. (Stogun yeni hali)

				INSERT INTO CBS_MENKUL_STOK_HAREKET
					   (stok_no, stok_tanim, depo_turu,saklama_yeri,portfoy_tipi,islem_tipi, islem_referans_no,
					    menkul_kiymet_kodu,islem_tarihi,ana_stok,kupur,adet, nominal_tutar,toplam_tutar, sira_no,
					    musteri_no_kime	,hesap_no_kime,bloke_adet,bloke_nominal_tutar, bloke_toplam_tutar)
				SELECT stok_no,stok_tanim, depo_turu, saklama_yeri,portfoy_tipi,6052,ls_mk_referans_no,
					   menkul_kiymet_kodu,ld_islem_tarihi, ana_stok,kupur, adet, nominal_tutar,toplam_tutar,
					   pn_islem_no,musteri_no_kime	,hesap_no_kime,ln_bloke_adet,ln_bloke_nominal_tutar, ln_bloke_toplam_tutar
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no = ln_stok_no ;

			 END LOOP;
			CLOSE c_bloke_koyma;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3706' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;
	ELSIF  pn_islem_tipi = 6054 THEN   -- Bloke Kaldirma
		 -- ?nce stok hareket tablosuna islem kaydedilir.
		  BEGIN
			OPEN c_bloke_kaldirma (pn_islem_no);
			 LOOP
				FETCH   c_bloke_kaldirma
				INTO    ln_stok_no,ls_mk_referans_no,ld_islem_tarihi,ln_bloke_adet,
						ln_bloke_nominal_tutar,ln_bloke_toplam_tutar;
				EXIT WHEN c_bloke_kaldirma%NOTFOUND;

				--?nce bloke koyulan tutarlari cbs_menkul_bloke_kaldirma tablosundan aldik. Sonrada stok tablosundan ilgili stogun
				--bloke bilgilerini aliyoruz.
				SELECT bloke_durumu,NVL(bloke_adet,0),NVL(bloke_nominal_tutar,0),NVL(bloke_toplam_tutar,0)
				INTO   ls_stok_bloke_durumu,ln_stok_bloke_adet,ln_stok_bloke_nominal_tutar,ln_stok_bloke_toplam_tutar
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no =  ln_stok_no ;

				--stok tablosunu yeni degerleri ile update et.
				ln_stok_bloke_adet 		    := ln_stok_bloke_adet - ln_bloke_adet ;
			    ln_stok_bloke_nominal_tutar := ln_stok_bloke_nominal_tutar - ln_bloke_nominal_tutar ;
				ln_stok_bloke_toplam_tutar  := ln_stok_bloke_toplam_tutar - ln_bloke_toplam_tutar ;

				 IF ln_stok_bloke_nominal_tutar >0 THEN
				 	 ls_stok_bloke_durumu := 'E' ;
				 ELSE
				 	 ls_stok_bloke_durumu := 'H' ;
				 END IF;

				--stok tablosunu yeni degerleri ile update et.
				UPDATE CBS_MENKUL_STOK
				SET    bloke_durumu   		=  ls_stok_bloke_durumu ,
					   bloke_adet     	   	=  ln_stok_bloke_adet  ,
					   bloke_nominal_tutar  =  ln_stok_bloke_nominal_tutar  ,
 					   bloke_toplam_tutar	=  ln_stok_bloke_toplam_tutar
				WHERE  stok_no =  ln_stok_no ;

				-- Stoktaki bu hareketle ilgili kayit olustur. (Stogun yeni hali)
				INSERT INTO CBS_MENKUL_STOK_HAREKET
					   (stok_no, stok_tanim, depo_turu,saklama_yeri,portfoy_tipi,islem_tipi, islem_referans_no,
					    menkul_kiymet_kodu,islem_tarihi,ana_stok,kupur,adet, nominal_tutar,toplam_tutar, sira_no,
					    musteri_no_kime	,hesap_no_kime,bloke_adet,bloke_nominal_tutar, bloke_toplam_tutar)
				SELECT stok_no,stok_tanim, depo_turu, saklama_yeri,portfoy_tipi,6054,ls_mk_referans_no,
					   menkul_kiymet_kodu,ld_islem_tarihi, ana_stok,kupur, adet, nominal_tutar,toplam_tutar,
					   pn_islem_no,musteri_no_kime	,hesap_no_kime,ln_bloke_adet,ln_bloke_nominal_tutar, ln_bloke_toplam_tutar
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no = ln_stok_no ;


			 END LOOP;
			CLOSE c_bloke_kaldirma;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3747' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF  pn_islem_tipi = 6060 THEN   -- Musteri Alim islemi ise
		 -- ?Once Yeni olusan stok icin hareket ve stok bilgisi olusturulmali
		  BEGIN

			OPEN c_musteri_alim_yenistok(pn_islem_no);
			 LOOP
				FETCH  c_musteri_alim_yenistok INTO r_MA_Yeni;
				EXIT WHEN c_musteri_alim_yenistok%NOTFOUND;

				-- Bu ileri vadeli bir islem ise 'B' bekleme durumunda saklanacak.
				IF r_MA_Yeni.portfoye_giris_tarihi <> r_MA_Yeni.islem_tarihi THEN
				    ls_ana_stok_durumu := 'B' ;
				ELSE
	 				ls_ana_stok_durumu := 'A'  ;
				END IF;

				BEGIN
					SELECT DISTINCT stok_kupur
					INTO   ln_kupur
					FROM   CBS_MENKUL_MUSTERI_ALIM_STKISL
					WHERE  tx_no = pn_islem_no ;
				  EXCEPTION
				    WHEN OTHERS THEN -- 1'den fazla gelebilir.
					  ln_kupur := 1 ;
				END ;

				INSERT INTO CBS_MENKUL_STOK_HAREKET
				   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
				   menkul_kiymet_kodu, islem_tarihi, kupur, adet, nominal_tutar, toplam_tutar, verim, bloke_durumu,
				   musteri_no_kime,hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat,kupon_faizli_fiyat,
				   islenmis_kupon_faizi,prim_iskonto_tutari, repo,trepo, stok_durumu)
				VALUES(
				   r_MA_Yeni.stok_no,r_MA_Yeni.stok_tanim, r_MA_Yeni.depo_turu, r_MA_Yeni.saklama_yeri,r_MA_Yeni.kime_alindigi,
				   6060,r_MA_Yeni.referans_no, r_MA_Yeni.menkul_kiymet_kodu,r_MA_Yeni.islem_tarihi,ln_kupur,
				   r_MA_Yeni.toplam_adet, r_MA_Yeni.toplam_nominal, r_MA_Yeni.toplam_alis_tutari,r_MA_Yeni.verim, 'H',
				   r_MA_Yeni.musteri_no_kimden,r_MA_Yeni.hesap_no_kimden,pn_islem_no,r_MA_Yeni.dovend_alim_fiyati,r_MA_Yeni.temiz_fiyat,
				   r_MA_Yeni.kupon_faizli_fiyat, r_MA_Yeni.islenmis_kupon_faizi,r_MA_Yeni.prim_iskonto_tutari, 'H','H',
				   ls_ana_stok_durumu);

			    -- Sonra stok tablosuna islem kaydedilir.
				BEGIN
					INSERT INTO CBS_MENKUL_STOK
					   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
					   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
					   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
					   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
					   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
					   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
					   orj_repo_tutari,repo_adet)
					 SELECT  stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
					   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
					   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
					   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
					   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
					   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
					   orj_repo_tutari,repo_adet
					FROM 	CBS_MENKUL_STOK_HAREKET
					WHERE   stok_no 		  = r_MA_Yeni.stok_no
					AND 	islem_tipi 		  = 6060
					AND 	islem_referans_no = r_MA_Yeni.referans_no
					AND		sira_no 		  = pn_islem_no ;

			  	    EXCEPTION
					  WHEN OTHERS THEN
					  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
					    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4085' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
			    END ;

			 END LOOP;
			 CLOSE c_musteri_alim_yenistok;


			 -- Sonra hangi stoklari sattiysan, bunlari stok tablosu ve stok hareket tablosuna isle.
			BEGIN
				OPEN c_musteri_alim_eskistok (pn_islem_no);
				 LOOP
					FETCH  c_musteri_alim_eskistok INTO r_MA_eski;
					EXIT WHEN c_musteri_alim_eskistok%NOTFOUND;

					-- Bu ileri vadeli bir islem ise eski stoga bloke koy. Degilse stoktan ilgili tutari dus
					IF r_MA_eski.portfoye_giris_tarihi <> r_MA_eski.islem_tarihi THEN
						UPDATE CBS_MENKUL_STOK
						SET    BLOKE_DURUMU	  		='E',
							   BLOKE_ADET	  		= bloke_adet + r_MA_eski.satilan_nominal_adet,
							   BLOKE_NOMINAL_TUTAR	= BLOKE_NOMINAL_TUTAR + r_MA_eski.satilan_nominal_tutar ,
							   BLOKE_TOPLAM_TUTAR	= BLOKE_TOPLAM_TUTAR  + r_MA_eski.satilanin_maliyeti
						WHERE  stok_no = r_MA_eski.stok_no ;

						INSERT INTO CBS_MENKUL_STOK_HAREKET
						   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
							menkul_kiymet_kodu, islem_tarihi,  kupur, adet, nominal_tutar,
							toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
							hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
							prim_iskonto_tutari, maliyet, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
							bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu,
							deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari,
							yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo_reeskont_faizi,
							yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi, icverim_reeskont_irr,
							yillik_icverim_reeskont_irr, orj_mddaf, orj_repo_tutari,repo_adet)
						SELECT stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, 6060,  r_MA_eski.referans_no,
							menkul_kiymet_kodu, r_MA_eski.islem_tarihi, kupur, adet, nominal_tutar,
							toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
							hesap_no_kime, pn_islem_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
							prim_iskonto_tutari, r_MA_eski.satilanin_maliyeti, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
							bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu,
							deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari,
							yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo_reeskont_faizi,
							yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi, icverim_reeskont_irr,
							yillik_icverim_reeskont_irr, orj_mddaf, orj_repo_tutari,repo_adet
						FROM CBS_MENKUL_STOK
						WHERE stok_no = r_MA_eski.stok_no;
						--Sadece bloke konuldugu icin stok tutar duzenle fonksiyonu cagirilmiyor.
					ELSE

						--Eski stok icin durum kotrolu yap. Sat?lan stok kapatilabilir mi?
						IF r_MA_eski.stokta_kalan_nominal  = 0 THEN
							ls_ana_stok_durumu := 'K' ; -- Once kapat ama nominalin sifir olmasinin bir sebebi varsa ac

							SELECT COUNT(*)
							INTO   ln_count
							FROM   CBS_MENKUL_STOK
							WHERE  ana_stok    =  r_MA_eski.stok_no
							AND    stok_durumu = 'A'
							AND    trepo 	   = 'E' ;

							IF r_MA_eski.repo = 'E' THEN
							   ls_ana_stok_durumu := 'A' ;  -- Repo yapilmis olabilir.
							ELSIF ln_count >0 THEN
							   ls_ana_stok_durumu := 'A' ; -- Ters repo yapilmis olabilir
							END IF ;
						 ELSE
						    ls_ana_stok_durumu := 'A' ;
						 END IF;

						 UPDATE CBS_MENKUL_STOK
						 SET    adet 		         = r_MA_eski.stokta_kalan_adet,
							    nominal_tutar        = r_MA_eski.stokta_kalan_nominal,
							    toplam_tutar         = r_MA_eski.stokta_kalan_tutar ,
							    islenmis_kupon_faizi = r_MA_eski.stokta_kalan_IK_faizi ,
							    prim_iskonto_tutari  = r_MA_eski.stokta_kalan_PI_tutari,
							    stok_durumu			 = ls_ana_stok_durumu
						 WHERE  stok_no = r_MA_eski.stok_no ;

						 -- Stok hareket tablosuna bu bilgileri isle
						 INSERT INTO CBS_MENKUL_STOK_HAREKET
							   (stok_no, portfoy_tipi,islem_tipi, islem_referans_no, menkul_kiymet_kodu,islem_tarihi,
							    adet, nominal_tutar,toplam_tutar, maliyet,sira_no,islenmis_kupon_faizi,prim_iskonto_tutari,
								musteri_no_kime	,hesap_no_kime,stok_durumu)
						 VALUES (r_MA_eski.stok_no,'M',6060,r_MA_eski.referans_no,r_MA_eski.menkul_kiymet_kodu,
						 		 r_MA_eski.islem_tarihi,r_MA_eski.satilan_nominal_adet, r_MA_eski.satilan_nominal_tutar,
								 r_MA_eski.toplam_satis_tutari,r_MA_eski.satilanin_maliyeti,pn_islem_no,
								 r_MA_eski.islenmis_kupon_faizi,r_MA_eski.prim_iskonto_tutari,
								 r_MA_eski.musteri_no_kimden,r_MA_eski.hesap_no_kimden, ls_ana_stok_durumu);

						 Pkg_Menkul.Stok_Tutar_Duzenle(r_MA_eski.stok_no,6060,pn_islem_no,r_MA_eski.satilan_nominal_tutar) ;

					END IF;

				 END LOOP;
				CLOSE c_musteri_alim_eskistok;

		  	    EXCEPTION
				  WHEN OTHERS THEN
				  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4086' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
			END ;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4087' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	ELSIF  pn_islem_tipi = 6062 THEN   -- Musteri satis islemi ise
		 -- ?nce Yeni olusan stok icin hareket ve stok bilgisi olusturulmali
		  BEGIN

			OPEN c_musteri_satis_yenistok(pn_islem_no);
			 LOOP
				FETCH  c_musteri_satis_yenistok INTO r_MS_Yeni;
				EXIT WHEN c_musteri_satis_yenistok%NOTFOUND;

				-- Bu ileri vadeli bir islem ise 'B' bekleme durumunda saklanacak.
				IF r_MS_Yeni.satis_valor_tarihi <> r_MS_Yeni.islem_tarihi THEN
				    ls_ana_stok_durumu := 'B' ;
				ELSE
	 				ls_ana_stok_durumu := 'A'  ;
				END IF;

				IF r_MS_Yeni.bloke = 'E' THEN
				   IF r_MS_Yeni.bloke_adet = 0 THEN
				   	  ln_bloke_toplam_tutar := r_MS_Yeni.bloke_nominal_tutar  *  r_MS_Yeni.toplam_alis_tutari / r_MS_Yeni.toplam_nominal ;
				   ELSE
				   	  ln_bloke_toplam_tutar := r_MS_Yeni.bloke_adet  *  r_MS_Yeni.toplam_alis_tutari / r_MS_Yeni.toplam_adet ;
				   END IF;
				ELSE
					ln_bloke_toplam_tutar := 0 ;
				END IF;

				BEGIN
					SELECT DISTINCT stok_kupur
					INTO   ln_kupur
					FROM   CBS_MENKUL_MUSTERI_SATIS_STISL
					WHERE  tx_no = pn_islem_no ;
				  EXCEPTION
				    WHEN OTHERS THEN -- 1'den fazla gelebilir.
					  ln_kupur := 1 ;
				END ;

				INSERT INTO CBS_MENKUL_STOK_HAREKET
				   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
				   menkul_kiymet_kodu, islem_tarihi, kupur, adet, nominal_tutar, toplam_tutar, verim, bloke_durumu,
				   musteri_no_kime,hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat,kupon_faizli_fiyat,
				   islenmis_kupon_faizi,prim_iskonto_tutari, repo,trepo, bloke_adet,bloke_nominal_tutar,
				   bloke_toplam_tutar,stok_durumu)
			    VALUES (r_MS_Yeni.stok_no, r_MS_Yeni.stok_tanim, r_MS_Yeni.depo_turu, r_MS_Yeni.saklama_yeri,
						'M', 6062, r_MS_Yeni.referans_no,r_MS_Yeni.menkul_kiymet_kodu,
						r_MS_Yeni.islem_tarihi,ln_kupur, r_MS_Yeni.toplam_adet, r_MS_Yeni.toplam_nominal,
						r_MS_Yeni.toplam_alis_tutari, r_MS_Yeni.verim, r_MS_Yeni.bloke, r_MS_Yeni.musteri_no_kimden,
						r_MS_Yeni.hesap_no_kimden,pn_islem_no,r_MS_Yeni.dovend_alim_fiyati,r_MS_Yeni.temiz_fiyat,
						r_MS_Yeni.kupon_faizli_fiyat, r_MS_Yeni.islenmis_kupon_faizi, r_MS_Yeni.prim_iskonto_tutari,'H',
						'H',r_MS_Yeni.bloke_adet,r_MS_Yeni.bloke_nominal_tutar,ln_bloke_toplam_tutar,ls_ana_stok_durumu);

			    -- Sonra stok tablosuna islem kaydedilir.
				BEGIN
					INSERT INTO CBS_MENKUL_STOK
					   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
					   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
					   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
					   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
					   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
					   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
					   orj_repo_tutari,repo_adet)
					 SELECT  stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, menkul_kiymet_kodu, kupur, adet,
					   nominal_tutar, toplam_tutar, bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu, ana_stok,
					   musteri_no_kime, hesap_no_kime, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
					   prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf,
					   yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo,
					   repo_nominal, repo_tutar, trepo, trepo_vade, bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati,
					   tcmb_birim_fiyati, repo_reeskont_faizi, yillik_repo_reeskont_faizi, trepo_reeskont_faizi,
					   yillik_trepo_reeskont_faizi, icverim_reeskont_irr, yillik_icverim_reeskont_irr, verim, orj_mddaf,
					   orj_repo_tutari,repo_adet
					FROM 	CBS_MENKUL_STOK_HAREKET
					WHERE   stok_no 		  = r_MS_Yeni.stok_no
					AND 	islem_tipi 		  = 6062
					AND 	islem_referans_no = r_MS_Yeni.referans_no
					AND		sira_no			  = pn_islem_no;

			  	    EXCEPTION
					  WHEN OTHERS THEN
					  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
					    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4131' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
			    END ;

			 END LOOP;
			 CLOSE c_musteri_satis_yenistok;


			 -- Sonra hangi stoklari sattiysan, bunlari stok tablosu ve stok hareket tablosuna isle.
			BEGIN
				OPEN c_musteri_satis_eskistok (pn_islem_no);
				 LOOP
					FETCH  c_musteri_satis_eskistok INTO r_MS_eski;
					EXIT WHEN c_musteri_satis_eskistok%NOTFOUND;


					-- Bu ileri vadeli bir islem ise eski stoga bloke koy. Degilse stoktan ilgili tutari dus
					IF r_MS_eski.satis_valor_tarihi <> r_MS_eski.islem_tarihi THEN
						UPDATE CBS_MENKUL_STOK
						SET    BLOKE_DURUMU	  		='E',
							   BLOKE_ADET	  		= bloke_adet + r_MS_eski.satilan_nominal_adet,
							   BLOKE_NOMINAL_TUTAR	= BLOKE_NOMINAL_TUTAR + r_MS_eski.satilan_nominal_tutar ,
							   BLOKE_TOPLAM_TUTAR	= BLOKE_TOPLAM_TUTAR  + r_MS_eski.satilanin_maliyeti
						WHERE  stok_no = r_MS_eski.stok_no ;

						INSERT INTO CBS_MENKUL_STOK_HAREKET
						   (stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, islem_tipi, islem_referans_no,
							menkul_kiymet_kodu, islem_tarihi,  kupur, adet, nominal_tutar,
							toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
							hesap_no_kime, sira_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
							prim_iskonto_tutari, maliyet, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
							bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu,
							deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari,
							yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo_reeskont_faizi,
							yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi, icverim_reeskont_irr,
							yillik_icverim_reeskont_irr, orj_mddaf, orj_repo_tutari,repo_adet)
						SELECT stok_no, stok_tanim, depo_turu, saklama_yeri, portfoy_tipi, 6062,  r_MS_eski.referans_no,
							menkul_kiymet_kodu, r_MS_eski.islem_tarihi, kupur, adet, nominal_tutar,
							toplam_tutar, verim, bloke_durumu, bloke_adet, bloke_nominal_tutar, musteri_no_kime,
							hesap_no_kime, pn_islem_no, dovend_fiyati, temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
							prim_iskonto_tutari, r_MA_eski.satilanin_maliyeti, repo, repo_nominal, repo_tutar, trepo, trepo_vade,
							bloke_toplam_tutar, virman_yeri, bildirim_birim_fiyati, tcmb_birim_fiyati, stok_durumu,
							deger_dusuklugu_tutari, deger_artis_tutari, reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari,
							yillik_deger_artis_tutari, yillik_reeskont_tutari, yillik_mddaf, repo_reeskont_faizi,
							yillik_repo_reeskont_faizi, trepo_reeskont_faizi, yillik_trepo_reeskont_faizi, icverim_reeskont_irr,
							yillik_icverim_reeskont_irr, orj_mddaf, orj_repo_tutari,repo_adet
						FROM CBS_MENKUL_STOK
						WHERE stok_no = r_MS_eski.stok_no;
						--Sadece bloke konuldugu icin stok tutar duzenle fonksiyonu cagirilmiyor.
					ELSE

						--Eski stok icin durum kotrolu yap. Sat?lan stok kapatilabilir mi?
						 IF r_MS_eski.stokta_kalan_nominal  = 0 THEN
							ls_ana_stok_durumu := 'K' ; -- Once kapat ama nominalin sifir olmasinin bir sebebi varsa ac

							SELECT COUNT(*)
							INTO   ln_count
							FROM   CBS_MENKUL_STOK
							WHERE  ana_stok    =  r_MS_eski.stok_no
							AND    stok_durumu = 'A'
							AND    trepo 	   = 'E' ;

							IF r_MS_eski.repo = 'E' THEN
							   ls_ana_stok_durumu := 'A' ;  -- Repo yapilmis olabilir.
							ELSIF ln_count >0 THEN
							   ls_ana_stok_durumu := 'A' ; -- Ters repo yapilmis olabilir
							END IF ;
						 ELSE
						    ls_ana_stok_durumu := 'A' ;
						 END IF;

						 UPDATE CBS_MENKUL_STOK
						 SET    adet 		         = r_MS_eski.stokta_kalan_adet,
							    nominal_tutar        = r_MS_eski.stokta_kalan_nominal,
							    toplam_tutar         = r_MS_eski.stokta_kalan_tutar ,
							    islenmis_kupon_faizi = r_MS_eski.stokta_kalan_IK_faizi ,
							    prim_iskonto_tutari  = r_MS_eski.stokta_kalan_PI_tutari,
							    stok_durumu			 = ls_ana_stok_durumu
						 WHERE  stok_no = r_MS_eski.stok_no ;


						 -- Stok hareket tablosuna bu bilgileri isle
						 INSERT INTO CBS_MENKUL_STOK_HAREKET
							   (stok_no, portfoy_tipi,islem_tipi, islem_referans_no, menkul_kiymet_kodu,islem_tarihi,
							    adet, nominal_tutar,toplam_tutar, maliyet,sira_no,islenmis_kupon_faizi,prim_iskonto_tutari,
								musteri_no_kime	,hesap_no_kime,stok_durumu)
						 VALUES (r_MS_eski.stok_no,'B',6062,r_MS_eski.referans_no,r_MS_eski.menkul_kiymet_kodu,
						 		 r_MS_eski.islem_tarihi,r_MS_eski.satilan_nominal_adet, r_MS_eski.satilan_nominal_tutar,
								 r_MS_eski.toplam_satis_tutari,r_MS_eski.satilanin_maliyeti,pn_islem_no,
								 r_MS_eski.islenmis_kupon_faizi,r_MS_eski.prim_iskonto_tutari,
								 r_MS_eski.musteri_no_kimden,r_MS_eski.hesap_no_kimden, ls_ana_stok_durumu);

						 Pkg_Menkul.Stok_Tutar_Duzenle(r_MS_eski.stok_no,6062,pn_islem_no,r_MS_eski.satilan_nominal_tutar) ;

					END IF;

				 END LOOP;
				CLOSE c_musteri_satis_eskistok;

		  	    EXCEPTION
				  WHEN OTHERS THEN
				  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4132' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
			END ;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4133' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;

	END IF;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2849' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END  Stok_Tablosu_Hareket_Yarat;


  /****************************************/

 PROCEDURE  Alt_Stok_Tablosu_Hareket_Yarat(pn_islem_no NUMBER,pn_islem_tipi NUMBER)

  IS
	ls_alt_stok_no 			  		  CBS_MENKUL_ALT_STOK_HAREKET.alt_stok_no%TYPE;
	ln_ana_stok_no					  CBS_MENKUL_ALT_STOK_HAREKET.ana_stok_no%TYPE;
	ls_depo_turu					  CBS_MENKUL_ALT_STOK_HAREKET.depo_turu%TYPE;
	ln_saklama_yeri					  CBS_MENKUL_ALT_STOK_HAREKET.saklama_yeri%TYPE;
	ln_repo_adedi					  CBS_MENKUL_REPO_GIRIS_STOKISL.repo_adedi%TYPE;
	ln_repo_nominali				  CBS_MENKUL_REPO_GIRIS_STOKISL.repo_nominali%TYPE;
	ln_repo_tutari					  CBS_MENKUL_ALT_STOK_HAREKET.toplam_tutar%TYPE;
	ld_islem_tarihi					  CBS_MENKUL_REPO_GIRIS_ISLEM.islem_tarihi%TYPE;
	ld_repo_vade_tarihi				  CBS_MENKUL_REPO_GIRIS_STOKISL.repo_vade_tarihi%TYPE;
	ln_musteri_no					  CBS_MENKUL_REPO_GIRIS_ISLEM.musteri_no%TYPE;
	ln_hesap_no						  CBS_MENKUL_REPO_GIRIS_ISLEM.hesap_no%TYPE;
	ln_oran_net						  CBS_MENKUL_REPO_GIRIS_STOKISL.oran_net%TYPE;
	ls_menkul_kiymet_kodu			  CBS_MENKUL_REPO_GIRIS_ISLEM.menkul_kiymet_kodu%TYPE;
	ls_referans_no					  CBS_MENKUL_REPO_GIRIS_ISLEM .referans_no%TYPE;
	ln_count_alt_stok				  NUMBER;
	ln_count						  NUMBER;
	ln_alt_stok_hareket_adet		  NUMBER;
	ls_sube							  CBS_ISLEM.AMIR_BOLUM_KODU%TYPE;

	CURSOR c_repo_giris IS
	SELECT a.stok_no,a.repo_tutari, a.repo_nominali, a.repo_vade_tarihi,
		   a.oran_net,a.depo_turu,a.repo_adedi,(b.saklama_yeri),
		   b.menkul_kiymet_kodu,b.islem_tarihi,b.musteri_no,b.hesap_no,b.referans_no
    FROM   CBS_MENKUL_REPO_GIRIS_STOKISL a , CBS_MENKUL_REPO_GIRIS_ISLEM b
    WHERE  a.tx_no       = pn_islem_no
	AND    a.tx_no       = b.tx_no
	AND    a.repolanacak = 'E';

  BEGIN
    --  ?slem tiplerine gore alt stok hareket tablosu doldurulur  - alt stoklar insert edilir ya da guncellenir
	BEGIN
		SELECT amir_bolum_kodu
		INTO   ls_sube
		FROM   CBS_ISLEM
		WHERE  numara = pn_islem_no;

		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			SELECT amir_bolum_kodu
			INTO   ls_sube
			FROM   CBS_ISLEM_GECICI
			WHERE  numara = pn_islem_no;

	END ;
	IF  pn_islem_tipi = 6030 THEN   -- Repo Giris ?slemi ise

	     BEGIN
			OPEN c_repo_giris ;
			 LOOP
				FETCH   c_repo_giris
				INTO    ln_ana_stok_no,ln_repo_tutari, ln_repo_nominali, ld_repo_vade_tarihi,
		   				ln_oran_net, ls_depo_turu,ln_repo_adedi,ln_saklama_yeri,
		   				ls_menkul_kiymet_kodu,ld_islem_tarihi,ln_musteri_no,ln_hesap_no,ls_referans_no;

				EXIT WHEN c_repo_giris%NOTFOUND;



				 -- ?nce alt stok numarasi almak gerekiyor.
				ls_alt_stok_no := Pkg_Menkul.Alt_Stok_Numarasi_Al(ls_sube);
				IF  ls_depo_turu = 'RRD-1101' THEN -- Ters repo ise...
					ls_depo_turu := 'RRR1103';				 -- Ters repo, repo deposuna alinacak
				ELSE
					ls_depo_turu := 'RDP-106';
				END IF;

			    ln_count := Pkg_Menkul.Alt_stok_repo_tekrar_rezerv(6030,ln_ana_stok_no,ls_referans_no);
				IF 	ln_count =0 THEN

					INSERT INTO CBS_MENKUL_ALT_STOK_HAREKET
						   (alt_stok_no, ana_stok_no, islem_turu, depo_turu, saklama_yeri, portfoy_tipi,
				   		    menkul_kiymet_kodu, adet,nominal_tutar, toplam_tutar, islem_tarihi,
				   			vade, musteri_no, hesap_no,islem_no,oran_net,islem_referans_no)
					VALUES (ls_alt_stok_no, ln_ana_stok_no, 'REPO', ls_depo_turu, ln_saklama_yeri, 'B',
				   		    ls_menkul_kiymet_kodu, ln_repo_adedi,ln_repo_nominali, ln_repo_tutari,ld_islem_tarihi,
							ld_repo_vade_tarihi, ln_musteri_no, ln_hesap_no,pn_islem_no,ln_oran_net,ls_referans_no) ;

					BEGIN
						--Stok ilk defa girildigi icin insert yapiliyor. Guncellemesinde update yapilacak.
						INSERT INTO CBS_MENKUL_ALT_STOK
						SELECT alt_stok_no, ana_stok_no,depo_turu, saklama_yeri, portfoy_tipi,
							   menkul_kiymet_kodu, adet, nominal_tutar, toplam_tutar, 'D',islem_turu, vade,
							   musteri_no, hesap_no,  oran_net,ls_referans_no
						FROM   CBS_MENKUL_ALT_STOK_HAREKET
						WHERE  alt_stok_no = ls_alt_stok_no ;

				  	    EXCEPTION
						  WHEN OTHERS THEN
						  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
						    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2833' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
				    END ;
				END IF;
			 END LOOP;
			CLOSE c_repo_giris;

	  	    EXCEPTION
			  WHEN OTHERS THEN
			  	ROLLBACK;   -- Hataya duserse hepsini rollback yap.
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2832' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
		  END ;
	END IF;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2834' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END  Alt_Stok_Tablosu_Hareket_Yarat;


  /****************************************/


 PROCEDURE  Stok_Bilgileri_Getir(
 								 pn_stok_no		   		   	CBS_MENKUL_STOK.stok_no%TYPE,
								 ps_stok_tanim			   OUT	CBS_MENKUL_STOK.stok_tanim%TYPE ,
								 ps_depo_turu			   OUT	CBS_MENKUL_STOK.depo_turu%TYPE,
								 pn_saklama_yeri		   OUT	CBS_MENKUL_STOK.saklama_yeri%TYPE,
								 ps_portfoy_tipi		   OUT	CBS_MENKUL_STOK.portfoy_tipi%TYPE ,
								 ps_menkul_kiymet_kodu	   OUT	CBS_MENKUL_STOK.menkul_kiymet_kodu%TYPE ,
								 pn_kupur				   OUT	CBS_MENKUL_STOK.kupur%TYPE ,
								 pn_adet				   OUT	CBS_MENKUL_STOK.adet%TYPE ,
								 pn_nominal_tutar		   OUT	CBS_MENKUL_STOK.nominal_tutar%TYPE ,
								 pn_toplam_tutar		   OUT	CBS_MENKUL_STOK.toplam_tutar%TYPE ,
								 ps_bloke_durumu		   OUT	CBS_MENKUL_STOK.bloke_durumu%TYPE ,
								 pn_bloke_adet			   OUT	CBS_MENKUL_STOK.bloke_adet%TYPE ,
								 pn_bloke_nominal_tutar	   OUT	CBS_MENKUL_STOK.bloke_nominal_tutar%TYPE ,
								 ps_stok_durumu			   OUT	CBS_MENKUL_STOK.stok_durumu%TYPE ,
								 pn_ana_stok			   OUT	CBS_MENKUL_STOK.ana_stok%TYPE ,
								 pn_musteri_no_kime		   OUT	CBS_MENKUL_STOK.musteri_no_kime%TYPE ,
								 pn_hesap_no_kime		   OUT	CBS_MENKUL_STOK.hesap_no_kime%TYPE ,
								 pn_dovend_fiyati		   OUT	CBS_MENKUL_STOK.dovend_fiyati%TYPE ,
								 pn_temiz_fiyat			   OUT	CBS_MENKUL_STOK.temiz_fiyat%TYPE ,
								 pn_kupon_faizli_fiyat	   OUT	CBS_MENKUL_STOK.kupon_faizli_fiyat%TYPE,
								 pn_islenmis_kupon_faizi   OUT	CBS_MENKUL_STOK.islenmis_kupon_faizi%TYPE ,
								 pn_prim_iskonto_tutari	   OUT	CBS_MENKUL_STOK.prim_iskonto_tutari%TYPE
								)
 IS

  BEGIN

	  SELECT stok_tanim, depo_turu, saklama_yeri, portfoy_tipi,
	         menkul_kiymet_kodu, kupur, adet, nominal_tutar, toplam_tutar,
	         bloke_durumu, bloke_adet, bloke_nominal_tutar, stok_durumu,
	         ana_stok, musteri_no_kime, hesap_no_kime, dovend_fiyati,
	         temiz_fiyat, kupon_faizli_fiyat, islenmis_kupon_faizi,
	         prim_iskonto_tutari
	  INTO 	 ps_stok_tanim, ps_depo_turu, pn_saklama_yeri, ps_portfoy_tipi,
	         ps_menkul_kiymet_kodu, pn_kupur, pn_adet, pn_nominal_tutar, pn_toplam_tutar,
	         ps_bloke_durumu, pn_bloke_adet, pn_bloke_nominal_tutar, ps_stok_durumu,
	         pn_ana_stok, pn_musteri_no_kime, pn_hesap_no_kime, pn_dovend_fiyati,
	         pn_temiz_fiyat, pn_kupon_faizli_fiyat, pn_islenmis_kupon_faizi,
	         pn_prim_iskonto_tutari
	  FROM   CBS_MENKUL_STOK
	  WHERE  stok_no		=   pn_stok_no ;

	    EXCEPTION
		  WHEN OTHERS THEN
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2303' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

 PROCEDURE  Stok_Trepo_Bilgileri_Getir(
 								 	   pn_stok_no		   	CBS_MENKUL_STOK.stok_no%TYPE,
								 	   ps_TREPO 		OUT	CBS_MENKUL_STOK.TREPO%TYPE,
								 	   pd_TREPO_VADE	OUT	CBS_MENKUL_STOK.TREPO_VADE%TYPE
									   )
 IS

  BEGIN

	  SELECT TREPO ,TREPO_VADE
	  INTO 	 ps_trepo, pd_trepo_vade
	  FROM   CBS_MENKUL_STOK
	  WHERE  stok_no		=   pn_stok_no ;

	    EXCEPTION
		  WHEN OTHERS THEN
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2303' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

  FUNCTION  Depo_turu_adi_al(pn_kod CBS_DEPO_TUR_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_depo_adi 	 CBS_DEPO_TUR_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_depo_adi
	FROM   CBS_DEPO_TUR_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_depo_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1968' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION Saklama_yeri_adi_al(pn_kod CBS_SAKLAMA_YERI_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_saklama_adi 	 CBS_SAKLAMA_YERI_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_saklama_adi
	FROM   CBS_SAKLAMA_YERI_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_saklama_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1969' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION  Dealer_adi_al(pn_kod CBS_DEALER_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_dealer_adi 	 CBS_DEALER_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_dealer_adi
	FROM   CBS_DEALER_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_dealer_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1963' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION  Bloke_nedeni_adi_al(pn_kod CBS_MENKUL_BLOKE_NEDEN_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ln_Bloke_nedeni_adi 	 CBS_MENKUL_BLOKE_NEDEN_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ln_Bloke_nedeni_adi
	FROM   CBS_MENKUL_BLOKE_NEDEN_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ln_Bloke_nedeni_adi   ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1994' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/


  FUNCTION  ihrac_eden_kurulus_adi_al(pn_kod CBS_IHRACEDENKURULUS_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_ihracedenkurulus_adi 	 CBS_IHRACEDENKURULUS_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_ihracedenkurulus_adi
	FROM   CBS_IHRACEDENKURULUS_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_ihracedenkurulus_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1686' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

 FUNCTION  borsa_adi_al(pn_kod CBS_BORSA_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_borsa_adi 	 CBS_BORSA_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_borsa_adi
	FROM   CBS_BORSA_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_borsa_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1669' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

 FUNCTION  borsa_uye_adi_al(pn_kod CBS_BORSA_UYE_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_borsa_adi 	 CBS_BORSA_UYE_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_borsa_adi
	FROM   CBS_BORSA_UYE_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_borsa_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3889' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/


 FUNCTION  kupon_endeks_tur_adi_al(pn_kod CBS_KUPON_ENDEKS_TUR_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_kupon_endeks_tur_adi 	 CBS_KUPON_ENDEKS_TUR_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_kupon_endeks_tur_adi
	FROM   CBS_KUPON_ENDEKS_TUR_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_kupon_endeks_tur_adi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2030' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/
 FUNCTION  Kupur_aciklama_al(pn_kod CBS_KUPUR_KODLARI.kod%TYPE) RETURN VARCHAR2
   IS
    ls_kupur_adi 	 CBS_KUPUR_KODLARI.aciklama%TYPE;
  BEGIN
  	SELECT aciklama
	INTO   ls_kupur_adi
	FROM   CBS_KUPUR_KODLARI
	WHERE  kod = pn_kod  ;

	RETURN ls_kupur_adi  ;

  EXCEPTION
      WHEN NO_DATA_FOUND THEN
	  	   ls_kupur_adi := ' ' ;
		   RETURN ls_kupur_adi  ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1966' || Pkg_Hata.getUCPOINTER);
  END;

  /********************************************************/
  FUNCTION  Merkez_Bankasi_Mustno_Al RETURN NUMBER IS
  BEGIN
    RETURN(75);
  END;

  /********************************************************/
  FUNCTION  Takas_Bank_Mustno_Al RETURN NUMBER IS
  BEGIN
    RETURN(72);
  END;

  /***************************************/
  FUNCTION  Menkul_kiymet_tanimli_mi(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2
   IS
    ln_tanimli	 NUMBER;
  BEGIN

  	SELECT COUNT(*)
	INTO   ln_tanimli
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_kod
	AND    durum_kodu <> 'K'		  ;

	IF ln_tanimli >0 THEN
	   ln_tanimli :=1 ;  --Tanimli
	END IF;

	RETURN ln_tanimli ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2242' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

 PROCEDURE  menkul_kiymet_bilgi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 								ps_urun_tur_kod				  OUT CBS_MENKUL.urun_tur_kod%TYPE,
 								ps_urun_sinif_kod             OUT CBS_MENKUL.urun_sinif_kod%TYPE,
  							    pn_tahvil_tescil_grup_kod     OUT CBS_MENKUL.tahvil_tescil_grup_kod%TYPE,
								ps_ulke_kodu   				  OUT CBS_MENKUL.ulke_kodu%TYPE,
								ps_doviz_kodu  				  OUT CBS_MENKUL.doviz_kodu%TYPE,
  								ps_dovize_endeksli_mk     	  OUT CBS_MENKUL.dovize_endeksli_mk%TYPE,
  								ps_endeks_para_kodu       	  OUT CBS_MENKUL.endeks_para_kodu%TYPE,
  								pn_ihrac_kuru             	  OUT CBS_MENKUL.ihrac_kuru%TYPE ,
  								pn_kote_oldugu_borsa_kodu  	  OUT CBS_MENKUL.kote_oldugu_borsa_kodu%TYPE,
  								ps_ihrac_eden_kurum_kurulus   OUT CBS_MENKUL.ihrac_eden_kurum_kurulus%TYPE,
  								pd_ihrac_tarihi               OUT CBS_MENKUL.ihrac_tarihi%TYPE ,
  								pn_ihrac_birim_fiyati         OUT CBS_MENKUL.ihrac_birim_fiyati%TYPE,
  								pd_itfa_tarihi                OUT CBS_MENKUL.itfa_tarihi%TYPE,
  								ps_kupon                      OUT CBS_MENKUL.kupon%TYPE ,
  								ps_kupon_faiz_tipi            OUT CBS_MENKUL.kupon_faiz_tipi%TYPE,
  								pn_kupon_endeks_turu          OUT CBS_MENKUL.kupon_endeks_turu%TYPE  ,
  								pn_kupon_risk_primi           OUT CBS_MENKUL.kupon_risk_primi%TYPE ,
  								pn_kupon_yillik_faiz_orani    OUT CBS_MENKUL.kupon_yillik_faiz_orani%TYPE ,
  								pn_kupon_odeme_donemi         OUT CBS_MENKUL.kupon_odeme_donemi%TYPE ,
  								pd_ilk_kupon_odeme_tarihi     OUT CBS_MENKUL.ilk_kupon_odeme_tarihi%TYPE,
  								pd_gelecek_kupon_odeme_tarihi OUT CBS_MENKUL.gelecek_kupon_odeme_tarihi%TYPE ,
  								pn_toplam_kupon_adedi         OUT CBS_MENKUL.toplam_kupon_adedi%TYPE,
  								pn_gun_hesaplama_bazi         OUT CBS_MENKUL.gun_hesaplama_bazi%TYPE,
  								ps_tescil                     OUT CBS_MENKUL.tescil%TYPE   ,
  								pd_gecmis_kupon_odeme_tarihi  OUT CBS_MENKUL.gecmis_kupon_odeme_tarihi%TYPE
								  )
   IS
    ls_kod	 CBS_MENKUL.menkul_kiymet_kodu%TYPE;
	ln_count NUMBER;
  BEGIN

	SELECT  COUNT(*)
	INTO    ln_count
	FROM    CBS_MENKUL
    WHERE 	menkul_kiymet_kodu = trim(ps_kod)
	AND 	durum_kodu='A';

	IF ln_count <>0 THEN

	    SELECT
		      urun_tur_kod,urun_sinif_kod,tahvil_tescil_grup_kod,ulke_kodu,doviz_kodu,dovize_endeksli_mk,
			  endeks_para_kodu,ihrac_kuru,kote_oldugu_borsa_kodu,ihrac_eden_kurum_kurulus,ihrac_tarihi,
			  ihrac_birim_fiyati,itfa_tarihi,kupon,kupon_faiz_tipi,kupon_endeks_turu,
			  kupon_risk_primi,kupon_yillik_faiz_orani,kupon_odeme_donemi,ilk_kupon_odeme_tarihi,
			  gelecek_kupon_odeme_tarihi,toplam_kupon_adedi,gun_hesaplama_bazi,tescil,
			  gecmis_kupon_odeme_tarihi
	   	INTO  ps_urun_tur_kod,ps_urun_sinif_kod,pn_tahvil_tescil_grup_kod,ps_ulke_kodu,ps_doviz_kodu,ps_dovize_endeksli_mk,
			  ps_endeks_para_kodu,pn_ihrac_kuru,pn_kote_oldugu_borsa_kodu,ps_ihrac_eden_kurum_kurulus,pd_ihrac_tarihi,
			  pn_ihrac_birim_fiyati,pd_itfa_tarihi,ps_kupon,ps_kupon_faiz_tipi,pn_kupon_endeks_turu,
			  pn_kupon_risk_primi,pn_kupon_yillik_faiz_orani,pn_kupon_odeme_donemi,pd_ilk_kupon_odeme_tarihi,
			  pd_gelecek_kupon_odeme_tarihi,pn_toplam_kupon_adedi,pn_gun_hesaplama_bazi,ps_tescil,
			  pd_gecmis_kupon_odeme_tarihi

	     FROM  CBS_MENKUL
	     WHERE menkul_kiymet_kodu = trim(ps_kod)
		 AND durum_kodu='A';
	ELSE
	    SELECT
		      urun_tur_kod,urun_sinif_kod,tahvil_tescil_grup_kod,ulke_kodu,doviz_kodu,dovize_endeksli_mk,
			  endeks_para_kodu,ihrac_kuru,kote_oldugu_borsa_kodu,ihrac_eden_kurum_kurulus,ihrac_tarihi,
			  ihrac_birim_fiyati,itfa_tarihi,kupon,kupon_faiz_tipi,kupon_endeks_turu,
			  kupon_risk_primi,kupon_yillik_faiz_orani,kupon_odeme_donemi,ilk_kupon_odeme_tarihi,
			  gelecek_kupon_odeme_tarihi,toplam_kupon_adedi,gun_hesaplama_bazi,tescil,
			  gecmis_kupon_odeme_tarihi
	   	INTO  ps_urun_tur_kod,ps_urun_sinif_kod,pn_tahvil_tescil_grup_kod,ps_ulke_kodu,ps_doviz_kodu,ps_dovize_endeksli_mk,
			  ps_endeks_para_kodu,pn_ihrac_kuru,pn_kote_oldugu_borsa_kodu,ps_ihrac_eden_kurum_kurulus,pd_ihrac_tarihi,
			  pn_ihrac_birim_fiyati,pd_itfa_tarihi,ps_kupon,ps_kupon_faiz_tipi,pn_kupon_endeks_turu,
			  pn_kupon_risk_primi,pn_kupon_yillik_faiz_orani,pn_kupon_odeme_donemi,pd_ilk_kupon_odeme_tarihi,
			  pd_gelecek_kupon_odeme_tarihi,pn_toplam_kupon_adedi,pn_gun_hesaplama_bazi,ps_tescil,
			  pd_gecmis_kupon_odeme_tarihi

	     FROM  CBS_MENKUL
	     WHERE menkul_kiymet_kodu = trim(ps_kod)
		 AND   durum_kodu = 'K';

	END IF;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1687' || Pkg_Hata.getUCPOINTER);
  END;


  /***************************************/
  /*Bir yil icinde odenecek kupon odeme sayisini hesaplar*/
   FUNCTION  Kupon_odeme_sayisi(pn_donem CBS_MENKUL.kupon_odeme_donemi%TYPE) RETURN NUMBER
   IS
    ln_odeme_sayisi 	 NUMBER;
  BEGIN

  	IF  pn_donem = 1 THEN 				  		-- 1 ay
		ln_odeme_sayisi := 12 ;
  	ELSIF  pn_donem = 2 OR pn_donem = 5 THEN 	-- 3 ay veya 91 gun
		ln_odeme_sayisi := 4 ;
  	ELSIF  pn_donem = 3 OR pn_donem = 6 THEN    -- 6 ay ya da 182 gun
		ln_odeme_sayisi := 2 ;
  	ELSIF  pn_donem = 4 THEN  	  	   	 	    -- 12 ay
		ln_odeme_sayisi := 1 ;
	END IF;

	RETURN ln_odeme_sayisi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2031' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

  /*verilen tarihten itibaren kalan kupon adedi */
  FUNCTION  Kalan_kupon_adedi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_kupon_tarihi	 DATE)
								  RETURN NUMBER
   IS
    ln_adet	 NUMBER;
  BEGIN

	SELECT COUNT(*)
	INTO   ln_adet
	FROM   CBS_MENKUL_KUPON_ODEME_TABLOSU
	WHERE  menkul_kiymet_kodu = trim(ps_menkul_kiymet_kodu)
    AND	   kupon_tarihi       >= pd_kupon_tarihi	;

	RETURN ln_adet  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1965' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

  /*Kupon donemindeki gun sayisini hesaplar*/
   FUNCTION  Kupon_Gun_sayisi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,pd_tarih DATE) RETURN NUMBER
   IS
    ln_gun_sayisi 	  NUMBER;
	ln_hesaplama_bazi NUMBER;
	ln_donem		  NUMBER;
	ld_gecmis_kupon_odeme_tarihi  DATE;
  BEGIN

	SELECT gun_hesaplama_bazi,kupon_odeme_donemi,gecmis_kupon_odeme_tarihi
	INTO   ln_hesaplama_bazi,ln_donem,ld_gecmis_kupon_odeme_tarihi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = trim(ps_menkul_kiymet_kodu)
	AND durum_kodu='A';

    IF ln_hesaplama_bazi=4 THEN
	  	IF  ln_donem = 1 THEN 		-- 1 ay
			ln_gun_sayisi := 30 ;
	  	ELSIF  ln_donem = 2  THEN 	-- 3 ay
			ln_gun_sayisi := 90 ;
	  	ELSIF  ln_donem = 3  THEN   -- 6 ay
			ln_gun_sayisi := 180 ;
	  	ELSIF  ln_donem = 4 THEN  	-- 12 ay
			ln_gun_sayisi := 360 ;
		END IF;
    ELSIF ln_hesaplama_bazi<>4 THEN
	  	IF  ln_donem = 5 THEN 	   -- 91 gun
			ln_gun_sayisi := 91 ;
	  	ELSIF  ln_donem = 182 THEN --182 gun
			ln_gun_sayisi := 182 ;
		ELSE
			ln_gun_sayisi :=  Pkg_Menkul.Kupon_odeme_tarihi(ps_menkul_kiymet_kodu ,pd_tarih)- ld_gecmis_kupon_odeme_tarihi;
        END IF;
	END IF;

	RETURN ln_gun_sayisi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2031' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/
  FUNCTION  Kalan_gun_sayisi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_tarihi	 DATE)  RETURN NUMBER
  -- ?cinde bulundugun kuponun odeme tarihine kac gun kaldigini hesaplar
   IS
    ln_gun_sayisi	 NUMBER;
	ld_kupon_tarihi	 DATE	; -- ?cinde bulunulan kupon donemi
	ln_hesaplama_bazi NUMBER; -- 1- gercek/365
					  		  -- 2- gercek/gercek
							  -- 3- gercek/360
							  -- 4- 30/360
    ln_yil_1   NUMBER;
	ln_yil_2   NUMBER;
	ln_ay_1    NUMBER;
	ln_ay_2    NUMBER;
	ln_gun_1   NUMBER;
	ln_gun_2   NUMBER;
  BEGIN
    ld_kupon_tarihi := Pkg_Menkul.Kupon_odeme_tarihi(trim(ps_menkul_kiymet_kodu),pd_tarihi	);

	SELECT gun_hesaplama_bazi
	INTO   ln_hesaplama_bazi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    durum_kodu='A';

    IF ln_hesaplama_bazi=1 OR ln_hesaplama_bazi=2 OR ln_hesaplama_bazi=3 THEN
	   -- verdigin gunden (banka alis icin portfoye giris tarihi)
	   -- icinde bulundugun kupon odeme tarihine kadar ki gun sayisi
       ln_gun_sayisi := (ld_kupon_tarihi - pd_tarihi) ;
	ELSE
	   ln_yil_1 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(ld_kupon_tarihi),'DD/MM/YYYY'),7,4));
	   ln_ay_1 	 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(ld_kupon_tarihi),'DD/MM/YYYY'),4,2));
	   ln_gun_1 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(ld_kupon_tarihi),'DD/MM/YYYY'),1,2));

	   ln_yil_2 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(pd_tarihi),'DD/MM/YYYY'),7,4));
	   ln_ay_2 	 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(pd_tarihi),'DD/MM/YYYY'),4,2));
	   ln_gun_2 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(pd_tarihi),'DD/MM/YYYY'),1,2));


	   ln_gun_sayisi := (ln_yil_1 - ln_yil_2) * 360 + (ln_ay_1 - ln_ay_2) * 30 + (ln_gun_1 - ln_gun_2) * 1 ;

	END IF;


	RETURN ln_gun_sayisi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1991' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/
  FUNCTION  Gecen_gun_sayisi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_tarihi	 DATE)  RETURN NUMBER
  -- ?cinde bulundugun kuponun odeme tarihine kac gun kaldigini hesaplar
   IS
    ln_gun_sayisi	     NUMBER;
	ld_kupon_tarihi	 	 DATE ; --icinde bulundugun kupon tarihi
	ld_son_kupon_tarihi	 DATE	; -- Son kupon odeme tarihi
	ln_hesaplama_bazi    NUMBER; -- 1- gercek/365
					  		  -- 2- gercek/gercek
							  -- 3- gercek/360
							  -- 4- 30/360
    ln_yil_1   NUMBER;
	ln_yil_2   NUMBER;
	ln_ay_1    NUMBER;
	ln_ay_2    NUMBER;
	ln_gun_1   NUMBER;
	ln_gun_2   NUMBER;
  BEGIN


    ld_son_kupon_tarihi := Pkg_Menkul.onceki_kupon_odeme_tarihi(ps_menkul_kiymet_kodu,pd_tarihi	);

	SELECT gun_hesaplama_bazi
	INTO   ln_hesaplama_bazi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    durum_kodu='A';

	ld_kupon_tarihi := Pkg_Menkul.kupon_odeme_tarihi(ps_menkul_kiymet_kodu,pd_tarihi);

    IF ln_hesaplama_bazi=1 OR ln_hesaplama_bazi=2 OR ln_hesaplama_bazi=3 THEN
	   -- verdigin gunden (banka alis icin portfoye giris tarihi)
	   -- icinde bulundugun kupon odeme tarihine kadar ki gun sayisi
       ln_gun_sayisi := (pd_tarihi - ld_son_kupon_tarihi) ; --(ld_kupon_tarihi - pd_tarihi); 02/04/2004 CNV upd
	ELSE
	   ln_yil_1 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(ld_son_kupon_tarihi),'DD/MM/YYYY'),7,4));
	   ln_ay_1 	 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(ld_son_kupon_tarihi),'DD/MM/YYYY'),4,2));
	   ln_gun_1 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(ld_son_kupon_tarihi),'DD/MM/YYYY'),1,2));

	   ln_yil_2 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(pd_tarihi),'DD/MM/YYYY'),7,4));
	   ln_ay_2 	 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(pd_tarihi),'DD/MM/YYYY'),4,2));
	   ln_gun_2 	 := TO_NUMBER(SUBSTR(TO_CHAR(TRUNC(pd_tarihi),'DD/MM/YYYY'),1,2));


	   ln_gun_sayisi := (ln_yil_1 - ln_yil_2) * 360 + (ln_ay_1 - ln_ay_2) * 30 + (ln_gun_1 - ln_gun_2) * 1 ;

	END IF;


	RETURN ln_gun_sayisi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1991' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/
  FUNCTION  Yil_gun_sayisi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_tarihi	 DATE)  RETURN NUMBER

   IS
    ln_gun_sayisi 	  			  NUMBER;
	ln_hesaplama_bazi 			  CBS_MENKUL.GUN_HESAPLAMA_BAZI%TYPE;
	ln_donem		  			  CBS_MENKUL.KUPON_ODEME_DONEMI%TYPE;
	ld_son_kupon_odeme_tarihi  	  DATE;
	ln_gecen_gun_sayisi			  NUMBER;
	ln_yil_gun_sayisi			  NUMBER;
	ln_gun						  NUMBER;
	ld_subat					  DATE;
	ls VARCHAR2(2000);
	ln_kupon_odeme_sayisi		  NUMBER;
  BEGIN

	SELECT gun_hesaplama_bazi
	INTO   ln_hesaplama_bazi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    durum_kodu='A';

    ld_son_kupon_odeme_tarihi :=  Pkg_Menkul.Kupon_odeme_tarihi(ps_menkul_kiymet_kodu,
  								  								pd_tarihi)	;

	IF ln_hesaplama_bazi = 1 THEN
		ln_yil_gun_sayisi := 365 ;
	ELSIF 	ln_hesaplama_bazi = 2 THEN
		ln_yil_gun_sayisi := 365 ;

		ld_subat := TO_DATE('01/02' || '/' || TO_CHAR(TRUNC(SYSDATE),'YYYY'),'DD/MM/YYYY') ;
		ln_gun 	 := TO_NUMBER(SUBSTR(LAST_DAY(ld_subat),1,2)) ;

		IF ln_gun=29 THEN -- Artik yil demektir
		   IF ld_son_kupon_odeme_tarihi > ld_subat AND pd_tarihi <ld_subat THEN
		   		ln_yil_gun_sayisi := 366 ;
		   END IF;
		ELSE
			ln_yil_gun_sayisi := 365 ;
		END IF;
	ELSIF 	ln_hesaplama_bazi = 3 OR ln_hesaplama_bazi = 4 THEN
		ln_yil_gun_sayisi := 360 ;
	END IF;


	RETURN ln_gun_sayisi  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3323' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

  /*?slenmis Kupon faizini bulur*/
   FUNCTION  Islenmis_kupon_faizi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
   			 					  pn_nominal_tutar NUMBER,
								  pd_portfoye_giris_tarihi DATE) RETURN NUMBER
   IS
    ln_gun_sayisi 	  			  NUMBER;
	ln_hesaplama_bazi 			  CBS_MENKUL.GUN_HESAPLAMA_BAZI%TYPE;
	ln_donem		  			  CBS_MENKUL.KUPON_ODEME_DONEMI%TYPE;
	ld_gecmis_kupon_odeme_tarihi  CBS_MENKUL.GECMIS_KUPON_ODEME_TARIHI%TYPE;
	ld_son_kupon_odeme_tarihi  	  DATE;
	Islenmis_kupon_faizi		  NUMBER;
	ln_kupon_donem_faizi 		  NUMBER;
	ln_gecen_gun_sayisi			  NUMBER;
	ln_yil_gun_sayisi			  NUMBER;
	ln_gun						  NUMBER;
	ld_subat					  DATE;
	ls VARCHAR2(2000);
	ln_kupon_odeme_sayisi		  NUMBER;
  BEGIN



	SELECT gun_hesaplama_bazi , kupon_odeme_donemi , gecmis_kupon_odeme_tarihi
	INTO   ln_hesaplama_bazi , ln_donem	, ld_gecmis_kupon_odeme_tarihi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    durum_kodu= 'A';

	ln_kupon_donem_faizi 	  :=  Pkg_Menkul.Kupon_donem_faiz_orani_bul(ps_menkul_kiymet_kodu,
  								  								   pd_portfoye_giris_tarihi)	;

    ld_son_kupon_odeme_tarihi :=  Pkg_Menkul.Kupon_odeme_tarihi(ps_menkul_kiymet_kodu,
  								  								pd_portfoye_giris_tarihi)	;
	ln_gecen_gun_sayisi		  :=  Pkg_Menkul.gecen_gun_sayisi(ps_menkul_kiymet_kodu,
  								  							  pd_portfoye_giris_tarihi)	;

	ln_kupon_odeme_sayisi	  := Pkg_Menkul.Kupon_odeme_sayisi(ln_donem);

	IF ln_hesaplama_bazi = 1 THEN
		ln_yil_gun_sayisi := 365 ;
	ELSIF 	ln_hesaplama_bazi = 2 THEN
		ln_yil_gun_sayisi := 365 ;

		ld_subat := TO_DATE('01/02' || '/' || TO_CHAR(TRUNC(SYSDATE),'YYYY'),'DD/MM/YYYY') ;
		ln_gun 	 := TO_NUMBER(SUBSTR(LAST_DAY(ld_subat),1,2)) ;

		IF ln_gun=29 THEN -- Artik yil demektir
		   IF ld_son_kupon_odeme_tarihi > ld_subat AND pd_portfoye_giris_tarihi <ld_subat THEN
		   		ln_yil_gun_sayisi := 366 ;
		   END IF;
		ELSE
			ln_yil_gun_sayisi := 365 ;
		END IF;
	ELSIF 	ln_hesaplama_bazi = 3 OR ln_hesaplama_bazi = 4 THEN
		ln_yil_gun_sayisi := 360 ;
	END IF;

	IF 	ln_donem = 5 THEN --91 gun
	  Islenmis_kupon_faizi :=(ln_kupon_donem_faizi/100) * pn_nominal_tutar *
	  					   	 (( pd_portfoye_giris_tarihi - ld_son_kupon_odeme_tarihi) / 91 ) ;
	ELSE
	  Islenmis_kupon_faizi :=(ln_kupon_donem_faizi*ln_kupon_odeme_sayisi/100) * pn_nominal_tutar *
	  					   	 (ln_gecen_gun_sayisi / ln_yil_gun_sayisi ) ;

	END IF;

	RETURN Islenmis_kupon_faizi ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  	   ls := SQLERRM;
		   	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2031' || Pkg_Hata.getUCPOINTER);
	  WHEN OTHERS THEN
	  ls := SQLERRM;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2031' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/
  /*Kupon ?deme Donemine gore verilen tarihten bir sonraki kupon odeme tarihini bulur
  	Kupon tablosu olustururken kullanilir
	Gelecek kupon odeme tarihinden sonraki kuponlar icin kullnilir.
  */
  FUNCTION  Sonraki_Kupon_Odeme_Tarihi(pd_kupon_tarihi	 DATE,
   			 						    pn_donem 		 CBS_MENKUL.kupon_odeme_donemi%TYPE) RETURN DATE
   IS
    ln_odeme_tarihi 	 DATE;
  BEGIN

  	IF  pn_donem = 1 THEN 		-- 1 ay
		ln_odeme_tarihi  :=  ADD_MONTHS(pd_kupon_tarihi,1);
  	ELSIF  pn_donem = 2 THEN    -- 3 ay
		ln_odeme_tarihi  :=  ADD_MONTHS(pd_kupon_tarihi,3);
  	ELSIF  pn_donem = 3 THEN    -- 6 ay
		ln_odeme_tarihi  :=  ADD_MONTHS(pd_kupon_tarihi,6);
  	ELSIF  pn_donem = 4 THEN    -- 12 ay
		ln_odeme_tarihi  :=  ADD_MONTHS(pd_kupon_tarihi,12);
	ELSIF pn_donem = 5 THEN 	-- 91 gun
		ln_odeme_tarihi  :=  pd_kupon_tarihi + 91 ;
  	ELSIF pn_donem = 6 THEN    -- 182 gun
		ln_odeme_tarihi  :=  pd_kupon_tarihi + 182 ;
	END IF;

	RETURN ln_odeme_tarihi   ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1982' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

  /* Verilen tarihe gore, o menkulun, icinde bulunulan kupon odeme tarihinden onceki
  	 son kupon odeme tarihi bulur. Eger verilen tarih, ilk kupon odeme tarihinden kucuk ise,
	 gecmis_kupon_tarihi bilgisi alinir.
  */
  FUNCTION  Onceki_Kupon_Odeme_Tarihi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  									  pd_tarih	DATE ) RETURN DATE
   IS
    ld_onceki_tarihi	 DATE;
    ld_kupon_tarihi 	 DATE;
	ld_ilk_kupon_odeme_tarihi  		 CBS_MENKUL.ilk_kupon_odeme_tarihi%TYPE;
	ld_gecmis_kupon_odeme_tarihi  	 CBS_MENKUL.gecmis_kupon_odeme_tarihi%TYPE;

  BEGIN

	SELECT ilk_kupon_odeme_tarihi,gecmis_kupon_odeme_tarihi
	INTO   ld_ilk_kupon_odeme_tarihi ,ld_gecmis_kupon_odeme_tarihi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    durum_kodu= 'A';

	-- once icinde bulundugun kupon odeme tarihini bul
	ld_kupon_tarihi := Pkg_Menkul.Kupon_odeme_tarihi(ps_menkul_kiymet_kodu,pd_tarih);

	IF  ld_kupon_tarihi	  = ld_ilk_kupon_odeme_tarihi THEN
	  	ld_onceki_tarihi := ld_gecmis_kupon_odeme_tarihi ;
	ELSE
		SELECT MAX(kupon_tarihi)
		INTO   ld_onceki_tarihi
		FROM   CBS_MENKUL_KUPON_ODEME_TABLOSU
		WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	    AND	   kupon_tarihi       <= ld_kupon_tarihi;

	END IF;

	RETURN ld_onceki_tarihi	   ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1982' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

  /*Kupon ?deme Donemine gore verilen tarihte icinde bulunulan kupon odeme faiz oranini */
  FUNCTION  Kupon_donem_faiz_orani_bul(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  								  pd_kupon_tarihi	 DATE)
								  RETURN CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_donemsel_faiz_orani%TYPE
   IS
    ln_faiz_orani 	 CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_donemsel_faiz_orani%TYPE;
  BEGIN

	SELECT NVL(kupon_donemsel_faiz_orani,0)
	INTO   ln_faiz_orani
	FROM   CBS_MENKUL_KUPON_ODEME_TABLOSU
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
    AND	   kupon_tarihi       = Pkg_Menkul.Kupon_odeme_tarihi(ps_menkul_kiymet_kodu ,
  								     							pd_kupon_tarihi) ;

	RETURN ln_faiz_orani   ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  	 ln_faiz_orani := NULL;
		 RETURN   ln_faiz_orani;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1964' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

  /*verilen tarihte icinde bulunulan kupon tarihini verir */
  FUNCTION  Kupon_odeme_tarihi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  								     pd_tarih	 DATE)
								     RETURN CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_tarihi%TYPE
   IS
    ld_tarih 	 					 CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_tarihi%TYPE;
	ld_ilk_kupon_odeme_tarihi  		 CBS_MENKUL.ilk_kupon_odeme_tarihi%TYPE;
	ld_gecmis_kupon_odeme_tarihi  	 CBS_MENKUL.gecmis_kupon_odeme_tarihi%TYPE;
  BEGIN

	SELECT ilk_kupon_odeme_tarihi,gecmis_kupon_odeme_tarihi
	INTO   ld_ilk_kupon_odeme_tarihi ,ld_gecmis_kupon_odeme_tarihi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    durum_kodu= 'A';

	IF  pd_tarih	<= ld_ilk_kupon_odeme_tarihi THEN
	  	ld_tarih 	:= ld_ilk_kupon_odeme_tarihi ;
	ELSE
		SELECT MAX(kupon_tarihi)
		INTO   ld_tarih
		FROM   CBS_MENKUL_KUPON_ODEME_TABLOSU
		WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	    AND	   kupon_tarihi       <= pd_tarih	;

	END IF;

	RETURN ld_tarih  ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	  	  ld_tarih := TO_DATE('01/01/1900','DD/MM/YYYY');
  	  	  RETURN ld_tarih  ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1964' || Pkg_Hata.getUCPOINTER);
  END;

  /***************************************/

 FUNCTION kupon_odeme_tablosu_varmi(ps_menkul_kodu CBS_MENKUL_KUPON_ODEME_TBLISLM.menkul_kiymet_kodu%TYPE) RETURN NUMBER
 IS
 ln_ret NUMBER;
 BEGIN
	SELECT COUNT(*)
	INTO   ln_ret
	FROM   CBS_MENKUL_KUPON_ODEME_TABLOSU
	WHERE  menkul_kiymet_kodu = ps_menkul_kodu;

  RETURN ln_ret;


  EXCEPTION
   	  WHEN NO_DATA_FOUND THEN
	   	   ln_ret := 0 ;
		   RETURN ln_ret;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3109' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
/**************************************************************/


  FUNCTION Urun_sinif_doviz_cinsi(ps_modul_kod  CBS_URUN_SINIF.modul_tur_kod%TYPE,
  		   						  ps_urun_tur   CBS_MENKUL.urun_tur_kod%TYPE,
  		   						  ps_urun_sinif CBS_MENKUL.urun_sinif_kod%TYPE) RETURN VARCHAR2
  IS

  ls_doviz_cinsi  CBS_URUN_SINIF.lc%TYPE;

  BEGIN
    -- ?run sinif TL mi YP mi bilgisini doner

   SELECT lc
   INTO   ls_doviz_cinsi
   FROM   CBS_URUN_SINIF
   WHERE  modul_tur_kod = ps_modul_kod
   AND    urun_tur_kod  = ps_urun_tur
   AND 	  kod 			= ps_urun_sinif ;

   RETURN  ls_doviz_cinsi ;

   EXCEPTION
   	    WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2126' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;



 /***********************************/
 FUNCTION  Verim_Hesaplama_Kosulu(ps_urun_tur_kodu CBS_MENKUL.urun_tur_kod%TYPE) RETURN NUMBER
 IS
	ln_hesapla 					NUMBER;
 	ls_urun_tur_kodu 			CBS_MENKUL.urun_tur_kod%TYPE;
 BEGIN
 	ls_urun_tur_kodu  :=  UPPER(trim(ps_urun_tur_kodu)) ;

 	IF   ls_urun_tur_kodu = 'BONO-TP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'BONO-YP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'TAHVIL-YP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'TAHVIL-TP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'YBTAHBO-YP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'VDMK-YP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'VDMK-TP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'GOS-YP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'GOS-TP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'GAYRMEN-YP' THEN
		 ln_hesapla :=1;
	ELSIF ls_urun_tur_kodu = 'GAYRMEN-TP'  THEN
		 ln_hesapla :=1;
	ELSE
		 ln_hesapla :=0;
	END IF;
	RETURN ln_hesapla ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || 'Hesaplanamaz' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;

  /********************************************************/

 FUNCTION  Verim_Formul_A(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  pd_portfoye_giris_tarihi DATE,
						  pn_toplam_alis_tutari NUMBER,
 		   		 		  pn_nominal_tutar NUMBER) RETURN NUMBER
 IS
	ln_stopaj_orani 			NUMBER;
	ln_stopaj_fon_orani			NUMBER;
	ln_ihrac_birim_fiyati       NUMBER;
	ld_itfa_tarihi				DATE;
	ln_pay						NUMBER;
	ln_payda					NUMBER;
	ln_verim 					NUMBER;
    ls_urun_sinif_kod			VARCHAR2(20);
    ln_kupon_yillik_faiz_orani	NUMBER;
    ln_kupon_odeme_donemi		NUMBER;
	ln_nominal_tutar 			NUMBER;
	ln_KFO						NUMBER;
    ln_verim_us 				NUMBER;

 BEGIN
   -- Bu formul kuponsuz kiymetler icin kullanilmaktadir.

	/*		      [  pn_nominal_tutar -  pn_toplam_alis_tutari - (pn_nominal_tutar * ln_stopaj_orani	* (1+ ln_stopaj_fon_orani)*(1- (ln_ihrac_birim_fiyati/100)))]      ^ (365/(ld_itfa_tarihi - pd_portfoye_giris_tarihi) )
	verim = (1 +   ----------------------------------------------------------------------------------------------------------------------------------------------------  )    - 1
		  												pn_toplam_alis_tutari
	*/

	SELECT NVL(ihrac_birim_fiyati,0),itfa_tarihi,
		   trim(urun_sinif_kod),NVL(kupon_yillik_faiz_orani,0), NVL(kupon_odeme_donemi,0)
	INTO   ln_ihrac_birim_fiyati,ld_itfa_tarihi	,
		   ls_urun_sinif_kod,ln_kupon_yillik_faiz_orani, ln_kupon_odeme_donemi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND durum_kodu='A';

	IF ls_urun_sinif_kod = 'DEVLET TAHVIL KUPON' THEN
	   ln_KFO := ln_kupon_yillik_faiz_orani / Pkg_Menkul.Kupon_odeme_sayisi(ln_kupon_odeme_donemi);
	   ln_nominal_tutar := (pn_nominal_tutar * ln_KFO) /100 ;
	ELSE
	   ln_nominal_tutar := pn_nominal_tutar ;
	END IF;


	ln_pay   :=(ln_nominal_tutar -  pn_toplam_alis_tutari - (ln_nominal_tutar * ln_stopaj_orani	* (1+ ln_stopaj_fon_orani)*(1- (ln_ihrac_birim_fiyati/100)))) ;
	ln_payda := pn_toplam_alis_tutari ;
	ln_verim := 1 + (ln_pay/ln_payda);
	ln_verim_us := 365 / (ld_itfa_tarihi - pd_portfoye_giris_tarihi) ;
	ln_verim    := POWER(ln_verim , ln_verim_us );
	ln_verim    := ln_verim - 1 ;

	RETURN ln_verim  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1990' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;

  /********************************************************/


 FUNCTION  FormulB_Seri(pn_UstDeger NUMBER, pn_NominalTutar NUMBER, pn_verim NUMBER,
 		   			 pn_KuponFaizOrani NUMBER,pn_KGS NUMBER, pn_DGS NUMBER,pn_M NUMBER) RETURN NUMBER
   IS
    ln_deger   NUMBER :=0 ;
	ln_i	  NUMBER;
	ln_power  NUMBER;
    ln_pay   NUMBER;
	ln_payda  NUMBER;
  BEGIN

	FOR ln_i IN 2..pn_UstDeger LOOP
	    ln_power := ((ln_i -1) + (pn_KGS/pn_DGS));
		ln_pay   := pn_NominalTutar * (pn_KuponFaizOrani/100);
		ln_payda := POWER((1 + (pn_verim/pn_M)),ln_power);
		ln_power := POWER((1 + (pn_verim/pn_M)),ln_power);
 		ln_deger := ln_deger +  (ln_pay/ln_payda) ;

	END LOOP;

	RETURN ln_deger  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1678' || Pkg_Hata.getUCPOINTER);
  END;

  /********************************************************/
 FUNCTION  FormulB_Toplam(pn_N NUMBER, pn_NominalTutar NUMBER ,pn_verim NUMBER ,
 		   				  pn_KFO NUMBER ,pn_KGS NUMBER, pn_DGS NUMBER ,pn_M NUMBER) RETURN NUMBER
   IS
    ln_formul1   NUMBER :=0 ;
    ln_formul2   NUMBER ;
	ln_formul3   NUMBER ;
	ln_power1  NUMBER;
	ln_power2  NUMBER;
	ln_toplam   NUMBER :=0 ;
	ln_verim  NUMBER :=0 ;
	ln_verim2  NUMBER :=0 ;


  BEGIN
	    ln_power1  := (pn_KGS/pn_DGS);
		ln_formul1 := ((pn_NominalTutar * pn_KFO) /100) /  POWER((1 + (pn_verim/pn_M)),ln_power1);
		ln_formul1 := ln_formul1;

	    ln_power2  := ((pn_N -1) + (pn_KGS/pn_DGS));
 		ln_formul2 := ((pn_NominalTutar ) /  POWER((1 + (pn_verim/pn_M)),ln_power2)) ;
		ln_formul2 := ln_formul2;

		ln_formul3 := FormulB_Seri(pn_N , pn_NominalTutar,pn_verim ,pn_KFO,pn_KGS , pn_DGS ,pn_M ) ;
		ln_formul3 := ln_formul3;

		ln_toplam := ln_formul1 +
				  	 ln_formul3 +
					 ln_formul2 ;

	RETURN ln_toplam   ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1678' || Pkg_Hata.getUCPOINTER);
  END;

  /********************************************************/
 FUNCTION  Verim_Formul_B(ps_menkul_kiymet_kodu  CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  pd_portfoye_giris_tarihi DATE,
						  pn_toplam_alis_tutari	 NUMBER,
						  pn_NominalTutar 		 NUMBER)	RETURN NUMBER
   IS
    ln_gun_hesaplama_bazi				NUMBER;
	ld_gecmis_kupon_odeme_tarihi		DATE;
	ln_kupon_odeme_donemi				NUMBER;
	ln_M								NUMBER;
	ln_N								NUMBER;
	ln_KGS								NUMBER;
	ln_KFO								NUMBER;
	ln_DGS								NUMBER;

	ln_toplam   NUMBER :=0 ;
	ln_verim  NUMBER :=0 ;
	ln_verim2  NUMBER :=0 ;
	ln_toplam_tutar NUMBER;
	ln_t NUMBER ;
	ln_bulundu NUMBER :=0 ;

  BEGIN
    --DBMS_OUTPUT.Put_Line('RetVal = ' || TO_CHAR(sysdate,'DD/MM/YY HH24:MM:SS'));
  	-- ln_M => Bir yil icindeki kupon sayisi
	-- ln_N => ?cinde bulundugun donemden itfaya kadar odenecek kupon sayisi (kaln_kupon sayisi)
	SELECT gun_hesaplama_bazi, gecmis_kupon_odeme_tarihi,kupon_odeme_donemi
	INTO   ln_gun_hesaplama_bazi,ld_gecmis_kupon_odeme_tarihi,ln_kupon_odeme_donemi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND durum_kodu='A';

    ln_M   :=Pkg_Menkul.Kupon_odeme_sayisi(ln_kupon_odeme_donemi);
    ln_N   :=Pkg_Menkul.Kalan_kupon_adedi(ps_menkul_kiymet_kodu ,pd_portfoye_giris_tarihi)	;
  	ln_KGS :=Pkg_Menkul.Kalan_gun_sayisi(ps_menkul_kiymet_kodu,pd_portfoye_giris_tarihi);
    ln_KFO :=Pkg_Menkul.Kupon_donem_faiz_orani_bul(ps_menkul_kiymet_kodu ,pd_portfoye_giris_tarihi);
    ln_DGS :=Pkg_Menkul.Kupon_Gun_sayisi(ps_menkul_kiymet_kodu ,pd_portfoye_giris_tarihi );

	ln_verim	  := 0.00001 ;
/********/
	ln_verim := 0;
	FOR ln_t IN 1..10 LOOP
		ln_verim := ln_verim + 0.1 ;
		ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
		ln_toplam := ROUND(ln_toplam,12) ;

		IF pn_toplam_alis_tutari > ln_toplam THEN
		   EXIT;
		ELSIF pn_toplam_alis_tutari = ln_toplam THEN
		   ln_bulundu := 1 ;
		   EXIT;
		END IF;

	END LOOP;

    IF ln_bulundu = 0 THEN
		ln_verim := ln_verim - 0.1 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.01 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12) ;

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;
	END IF;

	IF ln_bulundu =0 THEN
		ln_verim := ln_verim - 0.01 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12);

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;
	END IF;


	IF ln_bulundu =0 THEN
		ln_verim := ln_verim - 0.001 ;
		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.0001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12);

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;
	END IF;

	IF ln_bulundu =0 THEN

		ln_verim := ln_verim - 0.0001 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.00001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12) ;

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;

	END IF;
	IF ln_bulundu =0 THEN

		ln_verim := ln_verim - 0.00001 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.000001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12);

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;

	END IF;

	IF ln_bulundu =0 THEN

		ln_verim := ln_verim - 0.000001 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.0000001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12) ;

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;

	END IF;

	IF ln_bulundu =0 THEN

		ln_verim := ln_verim - 0.0000001 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.00000001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12) ;

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;

	END IF;
	IF ln_bulundu =0 THEN

		ln_verim := ln_verim - 0.00000001 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.000000001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12) ;

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;

	END IF;
	IF ln_bulundu =0 THEN

		ln_verim := ln_verim - 0.000000001 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.0000000001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12) ;

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;

	END IF;
	IF ln_bulundu =0 THEN

		ln_verim := ln_verim - 0.0000000001 ;

		FOR ln_t IN 1..10 LOOP
			ln_verim := ln_verim + 0.00000000001 ;
			ln_toplam := Pkg_Menkul.FormulB_Toplam(ln_N , pn_NominalTutar ,ln_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
			ln_toplam := ROUND(ln_toplam,12) ;

			IF pn_toplam_alis_tutari > ln_toplam THEN
			   EXIT;
			ELSIF pn_toplam_alis_tutari = ln_toplam THEN
			   ln_bulundu := 1 ;
			   EXIT;
			END IF;

		END LOOP;

	END IF;

    ln_verim2 := ln_verim ;
	RETURN ln_verim2  ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1678' || Pkg_Hata.getUCPOINTER);
  END;

  /********************************************************/

 PROCEDURE  Repo_TRepo_Oran_Tbl_Hazirla(pn_islem_no NUMBER,
 										ps_oran_cinsi CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
										ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE)

  IS

  BEGIN
    IF ps_oran_cinsi = 'REPO' THEN
		INSERT INTO CBS_MENKUL_REPO_TREPO_ORANISL
		SELECT   pn_islem_no,'REPO',Pkg_Muhasebe.banka_tarihi_bul,
			   	 a.tutar_1,a.tutar_2,b.vade_1,b.vade_2,ps_rating_kodu,0 oran
		FROM   	 CBS_MENKUL_REPO_TUTAR_ARA a,CBS_MENKUL_REPO_VADE_ARA b
		WHERE 	 a.gecerli='E'
		AND		 b.gecerli='E'
		ORDER BY a.tutar_1,b.vade_1		;


	ELSIF ps_oran_cinsi = 'TERS_REPO' THEN
		INSERT INTO CBS_MENKUL_REPO_TREPO_ORANISL
		SELECT   pn_islem_no,'TERS_REPO',Pkg_Muhasebe.banka_tarihi_bul,
			   	 a.tutar_1,a.tutar_2,b.vade_1,b.vade_2, ps_rating_kodu,0 oran
		FROM   	 CBS_MENKUL_REPO_TUTAR_ARA a,CBS_MENKUL_REPO_VADE_ARA b
		WHERE 	 a.gecerli='E'
		AND		 b.gecerli='E'
		ORDER BY a.tutar_1,b.vade_1		;

	END IF;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2645' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

 FUNCTION  Repo_TRepo_Oran_Insert_Konrol(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
									 	  pd_tarih	   CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
										  ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE) RETURN NUMBER
  IS
	ln_count		NUMBER;
  BEGIN
  	   /* ln_count = 0 ise islem yapilabilir. ln_count = 1 ise islem yapilamaz.*/
    SELECT COUNT(*)
    INTO   ln_count
    FROM   CBS_MENKUL_REPO_TREPO_ORANLARI
    WHERE  tarih = pd_tarih
    AND    oran_cinsi = ps_oran_cinsi
    AND    rating_kodu = ps_rating_kodu ;

    IF ln_count <> 0 THEN
	   ln_count := 1 ;
	END IF;

	RETURN ln_count ;
    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2663' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
  FUNCTION Repo_TRepo_Oranlari_gnc_ctrl(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
								 	    pd_tarih	   CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
										ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE) RETURN NUMBER
   IS
    ln_sonuc 	 NUMBER;
	ln_txno      NUMBER;
	ln_count     NUMBER;
	/* Repo - Ters Repo guncelleme ekrani icin kullanilir.*/
  BEGIN
    --    ln_sonuc = 0 ise guncellenemez,ln_sonuc=1 guncellenebilir

    SELECT NVL(MAX(tx_no),0)
    INTO   ln_txno
    FROM   CBS_MENKUL_RTR_ORANGNC
    WHERE  tarih 	   = pd_tarih
    AND    oran_cinsi  = ps_oran_cinsi
    AND    rating_kodu = ps_rating_kodu
	AND    durum_kodu  = 'G';

	ln_sonuc := Pkg_Tx.islem_bitmis_mi(ln_txno) ;


	RETURN ln_sonuc  ;
	  EXCEPTION
		  WHEN OTHERS THEN
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2702' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
  /***************************************/
 PROCEDURE Repo_TRepo_Oran_BilgiAktar(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
								 	  pd_tarih	   CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
									  ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE,
									  pn_txno NUMBER) IS
  BEGIN
    -- 	/* Repo - Ters Repo guncelleme ekrani icin kullanilir.*/

		INSERT INTO CBS_MENKUL_RTR_ORANGNC(tx_no, oran_cinsi, tarih,rating_kodu, durum_kodu )
		SELECT pn_txno, oran_cinsi, tarih,rating_kodu, 'A'
		FROM   CBS_MENKUL_RTR_ORAN
		WHERE  oran_cinsi = ps_oran_cinsi
		AND	   tarih      = pd_tarih
		AND	   rating_kodu= 'X' ; --ps_rating_kodu ;

		INSERT INTO CBS_MENKUL_REPO_TREPO_ORANGNC
		SELECT pn_txno, oran_cinsi, tarih, tutar_1, tutar_2, vade_1, vade_2,rating_kodu,oran
		FROM   CBS_MENKUL_REPO_TREPO_ORANLARI
		WHERE  oran_cinsi = ps_oran_cinsi
		AND	   tarih      = pd_tarih
		AND	   rating_kodu= 'X' ; --ps_rating_kodu ;



	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2443' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************/
 FUNCTION  Repo_TRepo_Tutar_Araligi_Bul(ps_oran_cinsi CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
										pn_tutar CBS_MENKUL_REPO_GIRIS.toplam_repo_tutari%TYPE)
										RETURN NUMBER
  IS
  	ln_bastutar		NUMBER;
	ln_bittutar		NUMBER;
	ln_aralik 		NUMBER;

  	CURSOR c_repo_tutar IS
	SELECT tutar_1,tutar_2
	FROM   CBS_MENKUL_REPO_TUTAR_ARA
	WHERE    gecerli='E';

  	CURSOR c_trepo_tutar IS
	SELECT tutar_1,tutar_2
	FROM   CBS_MENKUL_TERSREPO_TUTAR_ARA
	WHERE    gecerli='E';

  BEGIN
   ln_aralik := 0;

    IF ps_oran_cinsi = 'REPO' THEN
		OPEN c_repo_tutar;
		 LOOP
			FETCH   c_repo_tutar
			INTO    ln_bastutar ,ln_bittutar ;
			EXIT WHEN c_repo_tutar%NOTFOUND;

			IF ln_bastutar <= pn_tutar	AND   pn_tutar <= ln_bittutar THEN
			   ln_aralik := ln_bastutar ;
			END IF;

		 END LOOP;
		CLOSE c_repo_tutar;

	ELSIF ps_oran_cinsi = 'TERS_REPO' THEN
		OPEN c_trepo_tutar;
		 LOOP
			FETCH   c_trepo_tutar
			INTO    ln_bastutar ,ln_bittutar ;
			EXIT WHEN c_trepo_tutar%NOTFOUND;

			IF ln_bastutar <= pn_tutar	AND   pn_tutar <= ln_bittutar THEN
			   ln_aralik := ln_bastutar ;
			END IF;

		 END LOOP;
		CLOSE c_trepo_tutar;

	END IF;

	RETURN ln_aralik ;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2730' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

NULL;
  END;
/*******************************************************/

 FUNCTION  Repo_TRepo_Vade_Araligi_Bul(ps_oran_cinsi CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
										pn_vade CBS_MENKUL_REPO_GIRIS.islem_gun_sayisi%TYPE)
										RETURN NUMBER
  IS
  	ln_basvade		NUMBER;
	ln_bitvade		NUMBER;
	ln_aralik 		NUMBER;

  	CURSOR c_repo_vade IS
	SELECT vade_1,vade_2
	FROM   CBS_MENKUL_REPO_VADE_ARA
	WHERE    gecerli='E';

  	CURSOR c_trepo_vade IS
	SELECT vade_1,vade_2
	FROM   CBS_MENKUL_TERSREPO_VADE_ARA
	WHERE    gecerli='E';

  BEGIN
    ln_aralik := 0;

    IF ps_oran_cinsi = 'REPO' THEN
		OPEN c_repo_vade;
		 LOOP
			FETCH   c_repo_vade
			INTO    ln_basvade,ln_bitvade;
			EXIT WHEN c_repo_vade%NOTFOUND;

			IF ln_basvade <= pn_vade	AND   pn_vade <= ln_bitvade THEN
			   ln_aralik := ln_basvade ;
			END IF;

		 END LOOP;
		CLOSE c_repo_vade;

	ELSIF ps_oran_cinsi = 'TERS_REPO' THEN
		OPEN c_trepo_vade;
		 LOOP
			FETCH   c_trepo_vade
			INTO    ln_basvade,ln_bitvade;
			EXIT WHEN c_trepo_vade%NOTFOUND;

			IF ln_basvade <= pn_vade	AND   pn_vade <= ln_bitvade THEN
			   ln_aralik := ln_basvade ;
			END IF;

		 END LOOP;
		CLOSE c_trepo_vade;

	END IF;

	RETURN ln_aralik ;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2731' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

NULL;
  END;
/*******************************************************/
 FUNCTION repo_trepo_oran_al(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
							 pd_tarih	    CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
							 ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE,
							 pn_tutar 		NUMBER,
							 pn_vade		NUMBER) RETURN NUMBER
 IS

 ls_oran					 NUMBER;
 ln_tutar_araligi			 NUMBER;
 ln_vade_araligi			 NUMBER;

 BEGIN

   ln_tutar_araligi := Pkg_Menkul.Repo_TRepo_tutar_Araligi_Bul(ps_oran_cinsi,pn_tutar) ;
   ln_vade_araligi  := Pkg_Menkul.Repo_TRepo_vade_Araligi_Bul(ps_oran_cinsi,pn_vade) ;

	SELECT oran
	INTO ls_oran
	FROM CBS_MENKUL_REPO_TREPO_ORANLARI
	WHERE tarih 	  = pd_tarih
	AND oran_cinsi 	  = ps_oran_cinsi
	AND rating_kodu   = 'X'--ps_rating_kodu
	AND tutar_1 	  = ln_tutar_araligi
	AND vade_1  	  = ln_vade_araligi;

	RETURN ls_oran;
    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2733' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

	NULL;
 END;
/*******************************/

  FUNCTION  rating_kodu_al(pn_musteri CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2
   IS
    ls_rating_kodu	 			CBS_MUSTERI.rating_kodu%TYPE;
  BEGIN

  SELECT NVL(rating_kodu,'X')
  INTO   ls_rating_kodu
  FROM   CBS_MUSTERI
  WHERE  musteri_no = pn_musteri ;

	RETURN ls_rating_kodu	 ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2746' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

 FUNCTION Alt_Stok_Numarasi_Al(ps_tip VARCHAR2 ) RETURN VARCHAR2
  IS

     ls_alt_stokno        CBS_MENKUL_ALT_STOK.alt_stok_no%TYPE;
	 ln_sira_no 	 	  NUMBER := 0;

  BEGIN

	 ls_alt_stokno    := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'DD.MM.YY')  ||'.' || SUBSTR(ps_tip,1,3) ||'.' ;
	 ln_sira_no    	  := Pkg_Genel.genel_kod_al(ls_alt_stokno);
	 ls_alt_stokno    := ls_alt_stokno || LPAD(ln_sira_no,7,0);

  	RETURN ls_alt_stokno;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2831' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************
   FUNCTION   Alt_stok_repo_rezerv_var_mi(pn_islem_tipi NUMBER,
 										  pn_stok_no  NUMBER
										 ) RETURN NUMBER

  IS
    ln_rezervdeki_tutar	   CBS_MENKUL_ALT_STOK.nominal_tutar%TYPE;

  BEGIN
    IF pn_islem_tipi = 6030 THEN  -- Repo Giris ise

	   SELECT  NVL(SUM(nominal_tutar),0)
	   INTO    ln_rezervdeki_tutar
	   FROM    CBS_MENKUL_ALT_STOK
	   WHERE   ana_stok_no =  pn_stok_no
	   AND 	   durumu 	   = 'D'
	   AND     islem_turu  = 'REPO';


    END IF;

	RETURN ln_rezervdeki_tutar;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2835' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

  FUNCTION   Alt_stok_repo_tekrar_rezerv(pn_islem_tipi NUMBER,
 										  pn_stok_no  NUMBER,
										  ps_referans CBS_MENKUL_ALT_STOK.islem_referans_no%TYPE
										 ) RETURN NUMBER

  IS
    ln_count	   NUMBER;

  BEGIN
    IF pn_islem_tipi = 6030 THEN  -- Repo Giris ise

	   SELECT  COUNT(*)
	   INTO    ln_count
	   FROM    CBS_MENKUL_ALT_STOK
	   WHERE   ana_stok_no =  pn_stok_no
	   AND 	   durumu 	   = 'D'
	   AND     islem_turu  = 'REPO'
	   AND 	   islem_referans_no = ps_referans;


    END IF;

	RETURN ln_count;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	    ln_count := 0;
	    RETURN ln_count;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2835' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

  FUNCTION  Stoktaki_SerbestTutar_Yeter_Mi(pn_islem_no NUMBER,pn_islem_tipi NUMBER) RETURN NUMBER

  IS
  	ln_sonuc 			   NUMBER ; -- 0 ise yeterli degil, 1 ise yeterli.
    ln_rezervdeki_tutar	   CBS_MENKUL_STOK.nominal_tutar%TYPE;
    ln_repolanabilir_tutar NUMBER;

    ln_stok_no			   CBS_MENKUL_STOK.stok_no%TYPE;
	ln_nominal 			   CBS_MENKUL_STOK.nominal_tutar%TYPE;
	ln_repo_nominali 	   CBS_MENKUL_STOK.nominal_tutar%TYPE;
	ls_bloke			   CBS_MENKUL_STOK.bloke_durumu%TYPE;
	ln_bloke_nominal_tutar CBS_MENKUL_STOK.nominal_tutar%TYPE;

	CURSOR c_repo_giris_islem IS
	SELECT a.stok_no,c.nominal_tutar , a.repo_nominali , c.bloke_durumu, c.bloke_nominal_tutar
    FROM   CBS_MENKUL_REPO_GIRIS_STOKISL a,CBS_MENKUL_STOK c
    WHERE  a.tx_no   	 = pn_islem_no
	AND    c.stok_no 	 = a.stok_no
    AND    a.repolanacak ='E'		;

  BEGIN
   -- 0 ise yeterli degil, 1 ise yeterli.

    IF pn_islem_tipi = 6030 THEN  -- Repo Giris ise
		OPEN c_repo_giris_islem ;
		 LOOP
			FETCH   c_repo_giris_islem
			INTO    ln_stok_no,ln_nominal , ln_repo_nominali ,ls_bloke, ln_bloke_nominal_tutar  ;
			EXIT WHEN c_repo_giris_islem%NOTFOUND;

			ln_repolanabilir_tutar := ln_nominal ;

			IF ls_bloke ='E' THEN
			   ln_repolanabilir_tutar := ln_repolanabilir_tutar - ln_bloke_nominal_tutar ;
			END IF;

			-- Bu arada rezervasyon yapilmis mi?
			ln_rezervdeki_tutar := Pkg_Menkul.Alt_stok_repo_rezerv_var_mi(6030,ln_stok_no) ;

			ln_repolanabilir_tutar :=  ln_repolanabilir_tutar - ln_rezervdeki_tutar  ;

			IF ln_repolanabilir_tutar < ln_repo_nominali THEN
			    ln_sonuc:= 0 ; -- yeterli degil.
				EXIT;
			ELSE
				ln_sonuc:= 1 ;
			END IF;
		 END LOOP;
		CLOSE c_repo_giris_islem;

    END IF;

	RETURN ln_sonuc;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2836' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

  PROCEDURE Menkul_Marj_Orani_BilgiAktar(pd_tarih DATE) IS
    ln_genel_marj_orani   NUMBER;
	ln_count			  NUMBER;
  BEGIN


  	Pkg_Parametre.deger('SISTEM','TEKNIK',NULL,'G_TRepo_Ozel_Oran',ln_genel_marj_orani);

	SELECT COUNT(*)
	INTO   ln_count
	FROM   CBS_MENKUL_KIYMET_MARJ_ORANI
	WHERE  tarih = pd_tarih;

	IF ln_count = 0 THEN

		INSERT INTO CBS_MENKUL_KIYMET_MARJ_ORANI
		SELECT pd_tarih, menkul_kiymet_kodu, ln_genel_marj_orani,ln_genel_marj_orani ,urun_sinif_kod ,ihrac_tarihi,
		itfa_tarihi,doviz_kodu, ''
		FROM CBS_MENKUL
		WHERE durum_kodu = 'A';

	ELSE
		-- Gun icinde yeni menkuller tanimlanmis olabilir. Onlar eklenecek
		INSERT INTO CBS_MENKUL_KIYMET_MARJ_ORANI
		SELECT pd_tarih, menkul_kiymet_kodu, ln_genel_marj_orani,ln_genel_marj_orani ,urun_sinif_kod ,ihrac_tarihi,
		itfa_tarihi,doviz_kodu, ''
		FROM CBS_MENKUL
		WHERE durum_kodu = 'A'
		AND   menkul_kiymet_kodu NOT IN (SELECT menkul_kiymet_kodu
							   	       FROM CBS_MENKUL_KIYMET_MARJ_ORANI
									   WHERE tarih = pd_tarih );

	END IF;

	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3003' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 /*******************************************************/
 FUNCTION Gunluk_Marj_Orani_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		  					   pd_tarih DATE  DEFAULT NULL ) RETURN NUMBER
 IS

 ln_oran					 NUMBER;
 ld_tarih					 DATE;

 BEGIN
 	IF pd_tarih IS NULL THEN
 	   ld_tarih  := Pkg_Muhasebe.banka_tarihi_bul	;
	ELSE
	   ld_tarih  := pd_tarih	;
	END IF;

	SELECT marj_orani
	INTO   ln_oran
	FROM   CBS_MENKUL_KIYMET_MARJ_ORANI
	WHERE  tarih 	  = ld_tarih
	AND    menkul_kiymet_kodu = ps_menkul_kiymet_kodu ;

	RETURN ln_oran;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3011' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 END;
/*******************************/

 FUNCTION Gunluk_Satis_Fiyati_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		  						 pd_tarih DATE  DEFAULT NULL ) RETURN NUMBER
 IS

 ln_fiyat		 NUMBER;
 ld_tarih		 DATE;

 BEGIN
 	IF pd_tarih IS NULL THEN
 	   ld_tarih  := Pkg_Muhasebe.banka_tarihi_bul	;
	ELSE
	   ld_tarih  := pd_tarih	;
	END IF;

	SELECT banka_satis_kupon_faizli_fiyat
	INTO   ln_fiyat
	FROM   CBS_MENKUL_ALIS_SATIS_FIYATI
	WHERE  tarih 	  = ld_tarih
	AND    menkul_kiymet_kodu = ps_menkul_kiymet_kodu ;

	RETURN ln_fiyat;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3012' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 END;
/*******************************/

  PROCEDURE Menkul_Stok_Bloke_Koy(pn_txno IN NUMBER ,pn_islem_tipi NUMBER) IS
  ln_count NUMBER;
  ls_string VARCHAR2(2000);
  BEGIN
  -- Bu fonksiyonun amaci, ters repo yapilirken, islem onaylanana kadar musterinin emanet stoguna
  -- bloke koymakti. ama farkli islemler icin farkli bloke koymalar icin de kullanilabilir.

   IF pn_islem_tipi = 6040 THEN
   	  BEGIN
	    -- ?nce stok icin bloke koydugun icin hareket olustur.

		INSERT INTO CBS_MENKUL_STOK_HAREKET
		SELECT a.stok_no, b.stok_tanim, b.depo_turu, b.saklama_yeri, b.portfoy_tipi, 16040 , a.referans_no, b.menkul_kiymet_kodu,
			   c.islem_tarihi,b.ana_stok,NULL, b.kupur,b.adet, b.nominal_tutar, b.toplam_tutar,NULL,
			   'E' bloke_durumu, NVL(b.bloke_adet,0) + a.repo_adedi, NVL(b.bloke_nominal_tutar,0) + a.repo_nominali,
			   c.musteri_no,  c.hesap_no,  a.tx_no , b.dovend_fiyati, b.temiz_fiyat, b.kupon_faizli_fiyat,
		   	   b.islenmis_kupon_faizi, b.prim_iskonto_tutari, a.repo_tutari, b.repo, b.repo_nominal,b.repo_tutar,
			   b.trepo, b.trepo_vade,NULL ,NVL(b.bloke_toplam_tutar,0) + a.repo_tutari,NULL,NULL,NULL,
			   b.stok_durumu, b.deger_dusuklugu_tutari, b.deger_artis_tutari, b.reeskont_tutari, mddaf,
			   b.yillik_deger_dusuklugu_tutari, b.yillik_deger_artis_tutari, b.yillik_reeskont_tutari,
			   b.yillik_mddaf, b.repo_reeskont_faizi, b.yillik_repo_reeskont_faizi, b.trepo_reeskont_faizi,
  			   b.yillik_trepo_reeskont_faizi, b.icverim_reeskont_irr, b.yillik_icverim_reeskont_irr,orj_mddaf,b.orj_repo_tutari,NULL
		FROM   CBS_MENKUL_TREPO_GIRIS_STOKISL a , CBS_MENKUL_STOK  b ,CBS_MENKUL_TREPO_GIRIS_ISLEM c
		WHERE  a.tx_no 			= pn_txno
		AND	   a.stok_no 		= b.stok_no
		AND	   c.referans_no	= a.referans_no
		AND	   a.repolanacak 	= 'E' ;


		--Sonra stoktaki bloke durumlarini update et
		UPDATE CBS_MENKUL_STOK a
		SET    (a.bloke_durumu,a.bloke_adet,a.bloke_nominal_tutar,a.bloke_toplam_tutar)
		     = (SELECT bloke_durumu,bloke_adet,bloke_nominal_tutar,bloke_toplam_tutar
		       FROM CBS_MENKUL_STOK_HAREKET
			   WHERE sira_no = pn_txno
			   AND stok_no = a.stok_no
			   AND islem_tipi = 16040)
		WHERE stok_no IN (SELECT stok_no
			  		      FROM 	 CBS_MENKUL_STOK_HAREKET
						  WHERE  sira_no = pn_txno
						  AND islem_tipi = 16040)		;

		EXCEPTION
	   	    WHEN OTHERS THEN
			ROLLBACK;
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3014' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	  END;

    END IF;

  END;

 /*******************************************************/
  PROCEDURE Menkul_Stok_Bloke_Kaldir(pn_txno IN NUMBER ,pn_islem_tipi NUMBER) IS
  BEGIN
  -- Bu fonksiyonun amaci, ters repo yapilirken, islem onaylanana kadar musterinin emanet stoguna
  -- bloke koymakti. ama farkli islemler icin farkli bloke koymalar icin de kullanilabilir.

   IF pn_islem_tipi = 6040 THEN
   	  BEGIN
	    -- ?nce stok icin bloke koydugun icin hareket olustur.

		INSERT INTO CBS_MENKUL_STOK_HAREKET
		SELECT a.stok_no, b.stok_tanim, b.depo_turu, b.saklama_yeri, b.portfoy_tipi,26040, a.referans_no, b.menkul_kiymet_kodu,
			   c.islem_tarihi,b.ana_stok,NULL, b.kupur,b.adet, b.nominal_tutar, b.toplam_tutar,NULL,
			   DECODE(NVL(b.bloke_adet,0) - a.repo_adedi , 0,'H','E') bloke_durumu,
			   NVL(b.bloke_adet,0) - a.repo_adedi, NVL(b.bloke_nominal_tutar,0) - a.repo_nominali,
			   c.musteri_no,  c.hesap_no,  a.tx_no , b.dovend_fiyati, b.temiz_fiyat, b.kupon_faizli_fiyat,
		   	   b.islenmis_kupon_faizi, b.prim_iskonto_tutari, a.repo_tutari, b.repo, b.repo_nominal,b.repo_tutar,
			   b.trepo, b.trepo_vade,NULL ,  NVL(b.bloke_toplam_tutar,0) - a.repo_tutari,NULL,NULL,NULL,
			   b.stok_durumu, b.deger_dusuklugu_tutari, b.deger_artis_tutari, b.reeskont_tutari, b.mddaf,
			   b.yillik_deger_dusuklugu_tutari, b.yillik_deger_artis_tutari, b.yillik_reeskont_tutari,
			   b.yillik_mddaf, b.repo_reeskont_faizi, b.yillik_repo_reeskont_faizi, b.trepo_reeskont_faizi,
			   b.yillik_trepo_reeskont_faizi, b.icverim_reeskont_irr, b.yillik_icverim_reeskont_irr,b.orj_mddaf,NULL,NULL
		FROM   CBS_MENKUL_TREPO_GIRIS_STOKISL a , CBS_MENKUL_STOK  b ,CBS_MENKUL_TREPO_GIRIS_ISLEM c
		WHERE  a.tx_no 			= pn_txno
		AND	   a.stok_no 		= b.stok_no
		AND	   c.referans_no	= a.referans_no
		AND	   a.repolanacak 	= 'E' ;


		--Sonra stoktaki bloke durumlarini update et
		UPDATE CBS_MENKUL_STOK a
		SET    (a.bloke_durumu,a.bloke_adet,a.bloke_nominal_tutar,a.bloke_toplam_tutar)
		     = (SELECT bloke_durumu,bloke_adet,bloke_nominal_tutar,bloke_toplam_tutar
		       FROM CBS_MENKUL_STOK_HAREKET
			   WHERE sira_no = pn_txno
			   AND stok_no = a.stok_no
			   AND islem_tipi = 26040)
		WHERE stok_no IN (SELECT stok_no
			  		      FROM 	 CBS_MENKUL_STOK_HAREKET
						  WHERE  sira_no = pn_txno
						  AND    islem_tipi = 26040)		;

		EXCEPTION
	   	    WHEN OTHERS THEN
			ROLLBACK;
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3015' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	  END;
    END IF;

  END;

 /*******************************************************/

  FUNCTION  stok_bloke_tutari_al(pn_stok_no CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER
   IS
    ln_tutar			CBS_MENKUL_STOK.bloke_toplam_tutar%TYPE;
  BEGIN

  SELECT NVL(bloke_toplam_tutar,0)
  INTO   ln_tutar
  FROM   CBS_MENKUL_STOK
  WHERE  stok_no = pn_stok_no ;

	RETURN ln_tutar ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3046' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

 FUNCTION Gunluk_TCMB_Degerleme_Fiyat_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER
 IS

 ln_fiyat		 NUMBER;
 ld_tarih		 DATE;

 BEGIN
 	ld_tarih  := Pkg_Muhasebe.banka_tarihi_bul	;

	SELECT TCMB_FIYATI
	INTO   ln_fiyat
	FROM   CBS_MENKUL_DEGERLEME_FIYATI
	WHERE  tarih 	  = ld_tarih
	AND    menkul_kiymet_kodu = ps_menkul_kiymet_kodu ;

	RETURN ln_fiyat;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	  	   ln_fiyat := 0 ;
		   RETURN ln_fiyat;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3147' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 END;
/*******************************/
 FUNCTION  Yasakli_Kiymet_Kontrol(ps_menkul_kiymet CBS_MENKUL_YASAKLI_KIYMET_SERI.menkul_kiymet_kodu%TYPE,
								  pn_baslangic CBS_MENKUL_YASAKLI_KIYMET_SERI.baslangic_serino%TYPE,
								  pn_bitis CBS_MENKUL_YASAKLI_KIYMET_SERI.bitis_serino%TYPE)	RETURN NUMBER
  IS
  	ln_basseri		NUMBER;
	ln_bitseri		NUMBER;
	ln_aralik 		NUMBER;

  	CURSOR c_yasakli_kiymetler IS
	SELECT baslangic_serino,bitis_serino
	FROM   CBS_MENKUL_YASAKLI_KIYMET_SERI
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet ;

	-- 0 ise yasakli degil, 1 ise yasakli

  BEGIN
   ln_aralik := 0;
	OPEN c_yasakli_kiymetler;
	 LOOP
		FETCH   c_yasakli_kiymetler
		INTO    ln_basseri ,ln_bitseri ;
		EXIT WHEN c_yasakli_kiymetler%NOTFOUND;

		IF  (pn_baslangic <= ln_basseri AND ln_basseri <= pn_bitis) OR
			(pn_baslangic <= ln_bitseri AND ln_bitseri <= pn_bitis) OR
		    (ln_basseri <= pn_baslangic AND pn_baslangic <= ln_bitseri) OR
		    (ln_basseri <= pn_bitis AND pn_bitis <= ln_bitseri)
		THEN
		   ln_aralik := 1 ;
		END IF;

	 END LOOP;
	CLOSE c_yasakli_kiymetler;

	RETURN ln_aralik ;

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3203' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

NULL;
  END;
/*******************************************************/

  FUNCTION Emanet_giris_iptal_ctrl(ps_MEC_Referans_kodu CBS_MENKUL_EMANET_GIRIS.referans_no%TYPE,
  		   							  pn_stokno NUMBER) RETURN NUMBER
   IS
    ln_sonuc 	 NUMBER;
	ln_txno      NUMBER;
	ln_count     NUMBER;
	/* Emanet giris iptal oan oncesi fonksiyonuicin kullanilir.*/
	/* Eger ayni referans numarali emanet girisi  daha once guncellenmis ama yapilan bu islem hala onay bekliyorsa (tamamlanmamissa) */
	/* iptale izin vermemeli . Ayrica baska islem yapildi ise de izin vermemeli.*/
  BEGIN
    --    ln_sonuc = 0 ya da 2 ise iptal edilemez,ln_sonuc=1 iptal edilebilir.
    SELECT NVL(MAX(tx_no),0)
	INTO   ln_txno
	FROM   CBS_MENKUL_EMANET_GIRIS_GUNCEL
	WHERE  referans_no = ps_MEC_Referans_kodu
	AND	   durum_kodu 	  = 'G';

	ln_sonuc := Pkg_Tx.islem_bitmis_mi(ln_txno) ;

	IF 	ln_sonuc = 1 THEN

		SELECT COUNT(*)
		INTO ln_count
		FROM CBS_MENKUL_STOK_HAREKET
		WHERE stok_no = pn_stokno
		AND   islem_tipi NOT IN ( 6024,6025)	;

		IF ln_count = 0 THEN
			ln_sonuc := 1 ;
		ELSE
			ln_sonuc := 2 ;
		END IF;
	END IF;

	RETURN ln_sonuc  ;
	  EXCEPTION
		  WHEN OTHERS THEN
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3923' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
  /***************************************/

  PROCEDURE Alis_Satis_Fiyati_BilgiAktar(pd_tarih DATE) IS
	ln_count			  NUMBER;
  BEGIN

	SELECT COUNT(*)
	INTO   ln_count
	FROM   CBS_MENKUL_ALIS_SATIS_FIYATI
	WHERE  tarih = pd_tarih;

	IF ln_count = 0 THEN
		INSERT INTO CBS_MENKUL_ALIS_SATIS_FIYATI
		SELECT pd_tarih, menkul_kiymet_kodu, 'H',NULL, NULL, NULL,NULL,NULL, NULL,NULL
		FROM   CBS_MENKUL
		WHERE  durum_kodu = 'A';
	ELSE
		-- Gun icinde yeni menkuller tanimlanmis olabilir. Onlar eklenecek
		INSERT INTO CBS_MENKUL_ALIS_SATIS_FIYATI
		SELECT pd_tarih, menkul_kiymet_kodu,'H',NULL, NULL, NULL,NULL,NULL, NULL,NULL
		FROM   CBS_MENKUL
		WHERE  durum_kodu = 'A'
		AND    menkul_kiymet_kodu NOT IN (SELECT menkul_kiymet_kodu
							   	          FROM   CBS_MENKUL_ALIS_SATIS_FIYATI
									      WHERE  tarih = pd_tarih );
	END IF;

	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3306' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 /*******************************************************/

  PROCEDURE Degerleme_Fiyati_BilgiAktar(pd_tarih DATE) IS
	ln_count			  NUMBER;
  BEGIN

	SELECT COUNT(*)
	INTO   ln_count
	FROM   CBS_MENKUL_DEGERLEME_FIYATI
	WHERE  tarih = pd_tarih;

	IF ln_count = 0 THEN
		INSERT INTO CBS_MENKUL_DEGERLEME_FIYATI
		SELECT pd_tarih, menkul_kiymet_kodu, NULL,NULL, NULL,NULL,NULL,NULL
		FROM   CBS_MENKUL
		WHERE  durum_kodu = 'A'
		AND    itfa_tarihi >= pd_tarih;
	ELSE
		-- Gun icinde yeni menkuller tanimlanmis olabilir. Onlar eklenecek
		INSERT INTO CBS_MENKUL_DEGERLEME_FIYATI
		SELECT pd_tarih, menkul_kiymet_kodu,NULL,NULL, NULL,NULL,NULL,NULL
		FROM   CBS_MENKUL
		WHERE  durum_kodu = 'A'
		AND    itfa_tarihi >= pd_tarih
		AND    menkul_kiymet_kodu NOT IN (SELECT menkul_kiymet_kodu
							   	          FROM   CBS_MENKUL_DEGERLEME_FIYATI
									      WHERE  tarih = pd_tarih );
	END IF;

	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3306' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 /*******************************************************/
 FUNCTION  Alis_Satis_Formulu_Kuponsuz(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  	  pd_tarih DATE,
						      pn_verim NUMBER,
 		   		 		      pn_nominal_tutar NUMBER) RETURN NUMBER
 IS
	ln_stopaj_orani 			NUMBER;
	ln_stopaj_fon_orani			NUMBER;
	ln_ihrac_birim_fiyati       NUMBER;
	ld_itfa_tarihi				DATE;
	ln_pay						NUMBER;
	ln_payda					NUMBER;
	ln_fiyat					NUMBER;
 BEGIN
   -- Bu formul kuponsuz kiymetler icin kullanilmaktadir.
   -- Verim Formulunden fiyat cekilecektir.

	/*		  [  pn_nominal_tutar -  pn_toplam_alis_tutari - (pn_nominal_tutar * ln_stopaj_orani	* (1+ ln_stopaj_fon_orani)*(1- (ln_ihrac_birim_fiyati/100)))] * 365
	verim = ----------------------------------------------------------------------------------------------------------------------------------------------------------------
		  												(ld_itfa_tarihi - pd_portfoye_giris_tarihi) * 	pn_toplam_alis_tutari
	*/

	SELECT NVL(ihrac_birim_fiyati,0),itfa_tarihi
	INTO   ln_ihrac_birim_fiyati,ld_itfa_tarihi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND durum_kodu='A';

	ln_pay   :=(pn_nominal_tutar - (pn_nominal_tutar * ln_stopaj_orani	* (1+ ln_stopaj_fon_orani)*(1- (ln_ihrac_birim_fiyati/100)))) * 365;
	ln_payda :=((ld_itfa_tarihi - pd_tarih) * pn_verim) + 365;
	ln_fiyat := ln_pay/ln_payda;

	RETURN ln_fiyat ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3326' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;

  /********************************************************/
 FUNCTION Alis_Satis_Formulu_Kuponlu(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  	  		 pd_tarih DATE,
						      		 pn_verim NUMBER,
 		   		 		      		 pn_nominal_tutar NUMBER) RETURN NUMBER

   IS
    ln_gun_hesaplama_bazi				NUMBER;
	ld_gecmis_kupon_odeme_tarihi		DATE;
	ln_kupon_odeme_donemi				NUMBER;
	ln_M								NUMBER;
	ln_N								NUMBER;
	ln_KGS								NUMBER;
	ln_KFO								NUMBER;
	ln_DGS								NUMBER;
	ln_fiyat 							NUMBER;

  BEGIN

  	-- ln_M => Bir yil icindeki kupon sayisi
	-- ln_N => ?cinde bulundugun donemden itfaya kadar odenecek kupon sayisi (kaln_kupon sayisi)
	SELECT gun_hesaplama_bazi, gecmis_kupon_odeme_tarihi,kupon_odeme_donemi
	INTO   ln_gun_hesaplama_bazi,ld_gecmis_kupon_odeme_tarihi,ln_kupon_odeme_donemi
	FROM   CBS_MENKUL
	WHERE  menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    durum_kodu='A';

    ln_M   :=Pkg_Menkul.Kupon_odeme_sayisi(ln_kupon_odeme_donemi);
    ln_N   :=Pkg_Menkul.Kalan_kupon_adedi(ps_menkul_kiymet_kodu ,pd_tarih)	;
  	ln_KGS :=Pkg_Menkul.Kalan_gun_sayisi(ps_menkul_kiymet_kodu,pd_tarih);
    ln_KFO :=Pkg_Menkul.Kupon_donem_faiz_orani_bul(ps_menkul_kiymet_kodu ,pd_tarih);
    ln_DGS :=Pkg_Menkul.Kupon_Gun_sayisi(ps_menkul_kiymet_kodu ,pd_tarih );


	ln_fiyat := Pkg_Menkul.FormulB_Toplam(ln_N , pn_Nominal_Tutar ,pn_verim ,ln_KFO ,ln_KGS , ln_DGS,ln_M );
	RETURN ln_fiyat ;

   EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3326' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
/*******************************************************/

 FUNCTION  Kupur_kodu_al(pn_tutar NUMBER) RETURN NUMBER
   IS
    ln_kod 	 CBS_KUPUR_KODLARI.kod%TYPE;
  BEGIN


  	SELECT kod
	INTO   ln_kod
	FROM   CBS_KUPUR_KODLARI
	WHERE  REPLACE(aciklama,',') = pn_tutar  ;

	RETURN ln_kod ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	   	ln_kod  := 1 ;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3443' || Pkg_Hata.getUCPOINTER);

  END;

  /***************************************/
 PROCEDURE Stok_devir_oncesi_Degerler (pn_stok_no CBS_MENKUL_STOK.stok_no%TYPE ,
 		   							   ps_referans 	CBS_MENKUL_STOK_DEVIR_STOK.referans_no%TYPE,
 		   							   pn_adet OUT NUMBER,
									   pn_nominal OUT NUMBER,
									   pn_maliyet OUT NUMBER  ) IS

   BEGIN

		SELECT
		NVL(a.adet,0) + NVL((SELECT NVL(devir_adet,0) FROM CBS_MENKUL_STOK_DEVIR_STOK b
			   	 WHERE  referans_no = ps_referans AND b.stok_no = a.stok_no ),0) adet ,
		NVL(a.nominal_tutar,0) + NVL((SELECT NVL(devir_nominal,0) FROM CBS_MENKUL_STOK_DEVIR_STOK b
			   	 WHERE  referans_no = ps_referans AND b.stok_no = a.stok_no ),0) nominal_tutar,
		NVL(a.toplam_tutar,0) + NVL((SELECT NVL(devir_maliyeti,0) FROM CBS_MENKUL_STOK_DEVIR_STOK b
			   	 WHERE  referans_no = ps_referans AND b.stok_no = a.stok_no ),0) maliyet
		INTO  pn_adet,pn_nominal,pn_maliyet
		FROM   CBS_MENKUL_STOK a
		WHERE  a.stok_no = pn_stok_no
		--AND	   a.stok_durumu  = 'A' /*onceki degerini alacagim stok kapanmis ise kayidi donduremiyordu*/
		AND    a.depo_turu   NOT IN ( 'EMN','RRR1103')
		AND    a.portfoy_tipi = 'B';
	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3503' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*************************************************************************/


  PROCEDURE Repo_donus_log( pn_stok_no  NUMBER,ps_alt_stok_no VARCHAR2,ps_depo_turu  VARCHAR2,
  							pn_musteri_no  NUMBER,pn_hesap_no NUMBER,pn_repo_nominal NUMBER,pn_repo_tutar NUMBER,
							ps_referans_no	VARCHAR2,pn_hata_kodu NUMBER,ps_hata_mesaji	VARCHAR2) IS
   PRAGMA autonomous_transaction;
   -- Repo donus programi icin kullanilir. Loga atilan stoklar raporlanir ve sorunu duzeltilince repo bozum
   -- ekranindan donusu saglanir
  BEGIN

    INSERT INTO CBS_MENKUL_REPO_DONUS_LOG
		   (tarih,stok_no ,alt_stok_no ,depo_turu ,musteri_no ,hesap_no ,repo_nominal ,
	 		repo_tutar ,referans_no	,hata_kodu ,hata_mesaji )
    VALUES (SYSDATE,pn_stok_no ,ps_alt_stok_no ,ps_depo_turu ,pn_musteri_no ,pn_hesap_no ,pn_repo_nominal ,
	 		pn_repo_tutar ,ps_referans_no	,pn_hata_kodu ,ps_hata_mesaji ) ;
    COMMIT;

  END;
/*********************************************************************************/
  PROCEDURE TRepo_donus_log( pn_musteri_no  NUMBER,pn_hesap_no NUMBER,
  							 pn_toplam_repo_tutari NUMBER,pn_oran_net NUMBER,ps_referans_no	VARCHAR2,
							 pn_hata_kodu NUMBER,ps_hata_mesaji	VARCHAR2) IS
   PRAGMA autonomous_transaction;
   -- Ters Repo donus programi icin kullanilir. Loga atilan stoklar raporlanir
  BEGIN

    INSERT INTO CBS_MENKUL_TREPO_DONUS_LOG
		   (tarih, musteri_no, hesap_no, toplam_repo_tutari, oran_net,
		    referans_no, hata_kodu, hata_mesaji )
    VALUES (SYSDATE,pn_musteri_no, pn_hesap_no, pn_toplam_repo_tutari, pn_oran_net,
		    ps_referans_no, pn_hata_kodu ,ps_hata_mesaji ) ;
    COMMIT;

  END;
/*********************************************************************************/
  PROCEDURE Banka_TRepo_donus_log( pn_musteri_no  NUMBER,pn_hesap_no NUMBER,
  							 pn_toplam_repo_tutari NUMBER,pn_oran_net NUMBER,ps_referans_no	VARCHAR2,
							 pn_hata_kodu NUMBER,ps_hata_mesaji	VARCHAR2) IS
   PRAGMA autonomous_transaction;
   -- Banka_Ters Repo donus programi icin kullanilir. Loga atilan stoklar raporlanir
  BEGIN

    INSERT INTO CBS_MENKUL_BNK_TREPO_DONUS_LOG
		   (tarih, musteri_no, hesap_no, toplam_repo_tutari, oran_net,
		    referans_no, hata_kodu, hata_mesaji )
    VALUES (SYSDATE,pn_musteri_no, pn_hesap_no, pn_toplam_repo_tutari, pn_oran_net,
		    ps_referans_no, pn_hata_kodu ,ps_hata_mesaji ) ;
    COMMIT;

  END;
/*********************************************************************************/

 PROCEDURE  Repo_Bilgileri_Getir(
 								 ps_islem_referans_no 	   IN 		CBS_MENKUL_REPO_GIRIS.referans_no%TYPE,
								 pn_musteri_no   		   OUT		CBS_MENKUL_REPO_GIRIS.musteri_no%TYPE ,
								 ps_musteri_adi	   		   OUT		VARCHAR2,
								 pn_hesap_no   			   OUT		CBS_MENKUL_REPO_GIRIS.hesap_no%TYPE,
								 ps_hesap_sube			   OUT		CBS_MENKUL_REPO_GIRIS.hesabin_subesi%TYPE,
								 pd_repo_vadesi			   OUT		CBS_MENKUL_REPO_GIRIS.repo_vade_tarihi%TYPE,
								 ps_sube_adi	   		   OUT		VARCHAR2,
								 pd_repo_islem_tarihi	   OUT      CBS_MENKUL_REPO_GIRIS.islem_tarihi%TYPE,
								 pn_oran_net			   OUT		CBS_MENKUL_REPO_GIRIS.oran_net%TYPE,
								 pn_oran_brut  		       OUT		CBS_MENKUL_REPO_GIRIS.oran_brut%TYPE,
								 pn_repo_tutari			   OUT		CBS_MENKUL_REPO_GIRIS.toplam_repo_tutari%TYPE,
								 pn_donus_tutari_brut      OUT		CBS_MENKUL_REPO_GIRIS.donus_tutari_brut%TYPE,
								 pn_donus_tutari_net       OUT		CBS_MENKUL_REPO_GIRIS.donus_tutari_net%TYPE,
								 ps_urun_tur_kod		   OUT		CBS_MENKUL.urun_tur_kod%TYPE,
								 ps_urun_sinif_kod		   OUT		CBS_MENKUL.urun_tur_kod%TYPE,
								 ps_menkul_kiymet_kodu	   OUT		CBS_MENKUL.menkul_kiymet_kodu%TYPE,
								 pn_acilis_fiyati		   OUT		CBS_MENKUL_REPO_GIRIS.acilis_fiyati%TYPE,
								 pn_kapanis_fiyati		   OUT		CBS_MENKUL_REPO_GIRIS.kapanis_fiyati%TYPE,
								 pn_repo_adedi			   OUT		CBS_MENKUL_REPO_GIRIS.toplam_repo_adedi%TYPE
								)
 IS
  -- Repo Bozum ekraninda kullanilir.
  BEGIN

    SELECT  b.musteri_no,
			UPPER(trim(DECODE(a.musteri_tipi_kod, 'G',a.isim || ' ' || a.ikinci_isim || ' '||a.soyadi, a.ticari_unvan))) musteri_adi,
			b.hesap_no, b.hesabin_subesi,Pkg_Genel.bolum_adi_al_hatasiz(b.hesabin_subesi),b.repo_vade_tarihi,b.islem_tarihi,
			b.oran_brut,b.oran_net,b.toplam_repo_tutari,b.donus_tutari_brut,b.donus_tutari_net,
			c.urun_tur_kod,c.urun_sinif_kod,b.menkul_kiymet_kodu,b.acilis_fiyati, b.kapanis_fiyati,b.toplam_repo_adedi
	INTO	pn_musteri_no,ps_musteri_adi,pn_hesap_no,ps_hesap_sube,ps_sube_adi,pd_repo_vadesi,
			pd_repo_islem_tarihi,pn_oran_brut,pn_oran_net,pn_repo_tutari,pn_donus_tutari_brut,pn_donus_tutari_net,
			ps_urun_tur_kod,ps_urun_sinif_kod,ps_menkul_kiymet_kodu	,pn_acilis_fiyati, pn_kapanis_fiyati,pn_repo_adedi
	FROM    CBS_MUSTERI a ,CBS_MENKUL_REPO_GIRIS b,CBS_MENKUL c
	WHERE   b.referans_no 		 = ps_islem_referans_no
	AND     a.musteri_no 		 = b.musteri_no
	AND     c.menkul_kiymet_kodu = b.menkul_kiymet_kodu
    AND     c.durum_kodu = 'A';

    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3665' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
 FUNCTION Gunluk_IMKB_Fiyati_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		  						pd_tarih CBS_MENKUL_DEGERLEME_FIYATI.tarih%TYPE DEFAULT NULL) RETURN NUMBER
 IS

 ln_fiyat		 NUMBER;
 ld_tarih		 DATE;

 BEGIN
 	IF pd_tarih IS NULL THEN
	 	ld_tarih  := Pkg_Muhasebe.banka_tarihi_bul	;
	ELSE
	 	ld_tarih  := pd_tarih	;
	END IF;

	SELECT NVL(imkb_fiyati,0)
	INTO   ln_fiyat
	FROM   CBS_MENKUL_DEGERLEME_FIYATI
	WHERE  tarih 	  = ld_tarih
	AND    menkul_kiymet_kodu = ps_menkul_kiymet_kodu ;

	RETURN ln_fiyat;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	  	   ln_fiyat := 0 ;
		   RETURN ln_fiyat;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3703' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 END;
/*******************************/
 FUNCTION Gunluk_TCMB_Fiyati_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		  						pd_tarih CBS_MENKUL_DEGERLEME_FIYATI.tarih%TYPE DEFAULT NULL) RETURN NUMBER
 IS

 ln_fiyat		 NUMBER;
 ld_tarih		 DATE;

 BEGIN
 	IF pd_tarih IS NULL THEN
	 	ld_tarih  := Pkg_Muhasebe.banka_tarihi_bul	;
	ELSE
	 	ld_tarih  := pd_tarih	;
	END IF;

	SELECT NVL(tcmb_fiyati,0)
	INTO   ln_fiyat
	FROM   CBS_MENKUL_DEGERLEME_FIYATI
	WHERE  tarih 	  = ld_tarih
	AND    menkul_kiymet_kodu = ps_menkul_kiymet_kodu ;

	RETURN ln_fiyat;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN
	  	   ln_fiyat := 0 ;
		   RETURN ln_fiyat;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4029' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 END;
/*******************************/
 PROCEDURE Bloke_Koyma_TutarBilgileri(ps_menkul_kiymet_kodu IN CBS_MENKUL_BLOKE_KOYMA.menkul_kiymet_kodu%TYPE,
 		   							  pn_musteri_no NUMBER,
									  ps_doviz_kodu	    OUT CBS_MENKUL.doviz_kodu%TYPE,
									  ps_urun_tur_kod   OUT CBS_MENKUL.urun_tur_kod%TYPE,
									  ps_urun_sinif_kod OUT CBS_MENKUL.urun_sinif_kod%TYPE,
									  ps_itfa_tarihi    OUT CBS_MENKUL.itfa_tarihi%TYPE,
									  pn_adet			OUT NUMBER,
									  pn_nominal		OUT NUMBER,
									  pn_toplam_tutar	OUT NUMBER,
									  pn_bloke_adet		OUT NUMBER,
									  pn_bloke_nominal  OUT NUMBER,
									  pn_bloke_toplam_tutar	OUT NUMBER,
									  pn_piyasa_fiyati	OUT NUMBER	) IS
 BEGIN
    -- Bu fonksiyon Menkul Bloke Koyma ekraninda menkul kiymetin uzerindeki o anki toplan bilgileri
	-- bulmasi amaci ile yapilmistir.

	SELECT  b.doviz_kodu,b.urun_tur_kod,b.urun_sinif_kod,b.itfa_tarihi,
			SUM(NVL(a.adet,0)) adet ,SUM(NVL(a.nominal_tutar,0)) nominal,
			SUM(NVL(a.toplam_tutar,0)) toplam_tutar,SUM(NVL(a.bloke_adet,0)) bloke_adet ,
			SUM(NVL(a.bloke_nominal_tutar,0)) bloke_nominal,
			SUM(NVL(a.bloke_toplam_tutar,0)) bloke_toplam_tutar,
			SUM(Pkg_Menkul.gunluk_imkb_fiyati_al(a.menkul_kiymet_kodu) * a.nominal_tutar /100) piyasa_fiyati
	INTO	ps_doviz_kodu	,ps_urun_tur_kod,ps_urun_sinif_kod,ps_itfa_tarihi,
			pn_adet, pn_nominal,pn_toplam_tutar,pn_bloke_adet,pn_bloke_nominal,pn_bloke_toplam_tutar,
			pn_piyasa_fiyati
	FROM   CBS_MENKUL_STOK a, CBS_MENKUL b
	WHERE  a.musteri_no_kime    = pn_musteri_no
	AND    a.stok_durumu	    = 'A'
	AND    a.portfoy_tipi		= 'M'
	AND    b.durum_kodu 		= 'A'
	AND    a.menkul_kiymet_kodu = ps_menkul_kiymet_kodu
	AND    a.menkul_kiymet_kodu = b.menkul_kiymet_kodu
	GROUP BY b.doviz_kodu,b.urun_tur_kod,b.urun_sinif_kod,b.itfa_tarihi;


	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4366' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
 /*******************************************************/
 FUNCTION Bloke_Kaldirma_Referansi_Al RETURN VARCHAR2
  IS
     ls_bolum_kodu    	  CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_bloke_referansi   CBS_MENKUL_BLOKE_KALDIRMA.referans_no%TYPE;
	 ln_sira_no 	 NUMBER := 0;

  BEGIN

	 ls_bolum_kodu 	 	:= Pkg_Baglam.bolum_kodu ;
	 ls_bloke_referansi := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.MBK.' ;
	 ln_sira_no    		:= Pkg_Genel.genel_kod_al(ls_bloke_referansi);
	 ls_bloke_referansi := ls_bloke_referansi || LPAD(ln_sira_no,5,0);

  	RETURN ls_bloke_referansi;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3743' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;
  --*******************************************************************************************

 PROCEDURE Stok_Tutar_Duzenle(pn_stok_no    CBS_MENKUL_STOK.stok_no%TYPE,
 		   					  pn_islem_tipi	CBS_MENKUL_STOK_HAREKET.islem_tipi%TYPE,
							  pn_islem_no   CBS_MENKUL_STOK_HAREKET.sira_no%TYPE,
							  pn_islem_nominal	NUMBER DEFAULT NULL,
							  pn_islem_tutar	NUMBER DEFAULT NULL
							 ) IS

 ln_nominal_tutar      CBS_MENKUL_STOK.nominal_tutar%TYPE;
 ln_toplam_tutar	   CBS_MENKUL_STOK.toplam_tutar%TYPE;
 ln_adet			   CBS_MENKUL_STOK.adet%TYPE;
 ln_oran			   NUMBER;

 BEGIN
    -- Bu fonksiyonun amaci, stok tablosuna sonradan giren ve bolundukce degismesi gereken tutarlarin belirlenmesidir.

 	-- ?lgili stogu bul

  	SELECT NVL(ADET,0),NVL(nominal_tutar,0),NVL(toplam_tutar,0)
	INTO   ln_adet,ln_nominal_tutar,ln_toplam_tutar
	FROM   CBS_MENKUL_STOK
	WHERE  stok_no  = 	pn_stok_no ;

	-- Yeni islem tutarina gore yuzde kaclik bir bolunme yapacagini hesapla
	-- Bazi islemlerde nominal bilgisi bos olabilir (yatirim fonlari gibi)  , ya da
	-- emanet giriste oldugu gibi toplam tutar bilgisi bos olabilir. O yuzden hangisi dolu ise ona gore
	-- oran araniyor.

	IF  ln_nominal_tutar  = 0 THEN
		ln_oran := 1;	-- Tamamini dusmus demektir. Sifirlamak icin orani 1 yap
	ELSIF  pn_islem_nominal IS NOT NULL  THEN
		ln_oran := (100 * pn_islem_nominal) / ln_nominal_tutar;
		ln_oran := ln_oran/100;
	ELSIF 	pn_islem_tutar IS NOT NULL THEN
		ln_oran := (100 * pn_islem_tutar) / ln_toplam_tutar;
		ln_oran := ln_oran/100;
	END IF;


	-- Stok tablosunu duzenle
	UPDATE CBS_MENKUL_STOK
	SET   (deger_dusuklugu_tutari, deger_artis_tutari,
		   reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
		   yillik_reeskont_tutari,yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi,
		   trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,icverim_reeskont_irr,
		   yillik_icverim_reeskont_irr,orj_mddaf
		   )
	= 	   (SELECT NVL(deger_dusuklugu_tutari,0) - (NVL(deger_dusuklugu_tutari,0)  * ln_oran),
				   NVL(deger_artis_tutari,0) - (NVL(deger_artis_tutari,0) * ln_oran),
		   		   NVL(reeskont_tutari,0) - (NVL(reeskont_tutari,0) * ln_oran),
				   NVL(mddaf,0) - (NVL(mddaf,0) * ln_oran ),
				   NVL(yillik_deger_dusuklugu_tutari,0) - (NVL(yillik_deger_dusuklugu_tutari,0) * ln_oran),
				   NVL(yillik_deger_artis_tutari,0) - (NVL(yillik_deger_artis_tutari,0) * ln_oran),
		   		   NVL(yillik_reeskont_tutari,0) - (NVL(yillik_reeskont_tutari,0) * ln_oran),
				   NVL(yillik_mddaf,0) - (NVL(yillik_mddaf,0) * ln_oran),
				   NVL(repo_reeskont_faizi,0) - (NVL(repo_reeskont_faizi,0) * ln_oran),
				   NVL(yillik_repo_reeskont_faizi,0) - (NVL(yillik_repo_reeskont_faizi,0) * ln_oran ),
		   		   NVL(trepo_reeskont_faizi,0) - (NVL(trepo_reeskont_faizi,0) * ln_oran),
				   NVL(yillik_trepo_reeskont_faizi,0) - (NVL(yillik_trepo_reeskont_faizi,0) * ln_oran),
				   NVL(icverim_reeskont_irr,0) - (NVL(icverim_reeskont_irr,0) * ln_oran),
		   		   NVL(yillik_icverim_reeskont_irr,0) - (NVL(yillik_icverim_reeskont_irr,0) * ln_oran),
				   NVL(orj_mddaf,0)- (NVL(orj_mddaf,0)*ln_oran)
			FROM   CBS_MENKUL_STOK
			WHERE  stok_no = pn_stok_no
		   )
    WHERE   stok_no = pn_stok_no ;

	UPDATE CBS_MENKUL_STOK_HAREKET
	SET  ( deger_dusuklugu_tutari, deger_artis_tutari,
		   reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
		   yillik_reeskont_tutari,yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi,
		   trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,icverim_reeskont_irr,
		   yillik_icverim_reeskont_irr,orj_mddaf
		 )
	=    (SELECT deger_dusuklugu_tutari, deger_artis_tutari,
		   		 reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
		   		 yillik_reeskont_tutari,yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi,
		   		 trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,icverim_reeskont_irr,
		   		 yillik_icverim_reeskont_irr,orj_mddaf
		  FROM   CBS_MENKUL_STOK
		  WHERE  stok_no = pn_stok_no
		  )
	WHERE 	stok_no    = pn_stok_no
	AND		islem_tipi = pn_islem_tipi
	AND 	sira_no    = pn_islem_no ;

	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3843' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
 /*******************************************************/
  PROCEDURE Stok_Tutar_Duzenle_iptal(pn_stok_no    CBS_MENKUL_STOK.stok_no%TYPE,
							  		 pn_islem_nominal	NUMBER DEFAULT NULL,
							  		 pn_islem_tutar		NUMBER DEFAULT NULL
							 		 ) IS

 ln_nominal_tutar      CBS_MENKUL_STOK.nominal_tutar%TYPE;
 ln_toplam_tutar	   CBS_MENKUL_STOK.toplam_tutar%TYPE;
 ln_oran			   NUMBER;
 ln_sira_no			   NUMBER;
 ln_eski_nominal       NUMBER;

 BEGIN
    -- Bu fonksiyonun amaci, stok tablosuna sonradan giren ve bolundukce degismesi gereken tutarlarin duzenlenmesinden sonra
	-- islem iptali yapilirsa, bu duzenlemelerin geri alinmasidir.

 	-- ?lgili stogu bul

  	SELECT NVL(nominal_tutar,0),NVL(toplam_tutar,0)
	INTO   ln_nominal_tutar,ln_toplam_tutar
	FROM   CBS_MENKUL_STOK
	WHERE  stok_no  = 	pn_stok_no ;

	-- Yeni islem tutarina gore yuzde kaclik bir bolunme yapacagini hesapla
	-- Bazi islemlerde nominal bilgisi bos olabilir (yatirim fonlari gibi)  , ya da
	-- emanet giriste oldugu gibi toplam tutar bilgisi bos olabilir. O yuzden hangisi dolu ise ona gore
	-- oran araniyor.

	ln_eski_nominal :=  pn_islem_nominal - ln_nominal_tutar;

	IF  ln_eski_nominal  = 0 THEN
		ln_oran := 1 ;
	ELSIF  pn_islem_nominal IS NOT NULL  THEN
		ln_oran := (100 * pn_islem_nominal) / ln_nominal_tutar;
		ln_oran := ln_oran/100;
	ELSIF 	pn_islem_tutar IS NOT NULL THEN
		ln_oran := (100 * pn_islem_tutar) / ln_toplam_tutar;
		ln_oran := ln_oran/100;
	END IF;

	IF ln_eski_nominal  <> 0 THEN
		-- Stok tablosunu duzenle
		UPDATE CBS_MENKUL_STOK
		SET   (islenmis_kupon_faizi, prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari,
			   reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
			   yillik_reeskont_tutari,yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi,
			   trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,icverim_reeskont_irr,
			   yillik_icverim_reeskont_irr,orj_mddaf
			   )
		= 	   (SELECT NVL(islenmis_kupon_faizi,0) + (NVL(islenmis_kupon_faizi,0) * ln_oran) ,
			   		   NVL(prim_iskonto_tutari,0) + (NVL(prim_iskonto_tutari,0) * ln_oran) ,
					   NVL(deger_dusuklugu_tutari,0) + (NVL(deger_dusuklugu_tutari,0)  * ln_oran),
					   NVL(deger_artis_tutari,0) + (NVL(deger_artis_tutari,0) * ln_oran),
			   		   NVL(reeskont_tutari,0) + (NVL(reeskont_tutari,0) * ln_oran),
					   NVL(mddaf,0) + (NVL(mddaf,0) * ln_oran ),
					   NVL(yillik_deger_dusuklugu_tutari,0) + (NVL(yillik_deger_dusuklugu_tutari,0) * ln_oran),
					   NVL(yillik_deger_artis_tutari,0) + (NVL(yillik_deger_artis_tutari,0) * ln_oran),
			   		   NVL(yillik_reeskont_tutari,0) + (NVL(yillik_reeskont_tutari,0) * ln_oran),
					   NVL(yillik_mddaf,0) + (NVL(yillik_mddaf,0) * ln_oran),
					   NVL(repo_reeskont_faizi,0) + (NVL(repo_reeskont_faizi,0) * ln_oran),
					   NVL(yillik_repo_reeskont_faizi,0) + (NVL(yillik_repo_reeskont_faizi,0) * ln_oran ),
			   		   NVL(trepo_reeskont_faizi,0)+ (NVL(trepo_reeskont_faizi,0) * ln_oran),
					   NVL(yillik_trepo_reeskont_faizi,0) + (NVL(yillik_trepo_reeskont_faizi,0) * ln_oran),
					   NVL(icverim_reeskont_irr,0) + (NVL(icverim_reeskont_irr,0) * ln_oran),
			   		   NVL(yillik_icverim_reeskont_irr,0) + (NVL(yillik_icverim_reeskont_irr,0) * ln_oran),
					   NVL(orj_mddaf,0) + (NVL(orj_mddaf,0) * ln_oran)
				FROM   CBS_MENKUL_STOK
				WHERE  stok_no = pn_stok_no
			   )
	    WHERE   stok_no = pn_stok_no ;
	ELSE

		-- stogun ilk alindigi degerine git
	  	SELECT sira_no,NVL(nominal_tutar,0),NVL(toplam_tutar,0)
		INTO   ln_sira_no,ln_nominal_tutar,ln_toplam_tutar
		FROM   CBS_MENKUL_STOK_HAREKET
		WHERE  stok_no  = 	pn_stok_no
		AND    sira_no  = (SELECT  MIN(sira_no) FROM CBS_MENKUL_STOK_HAREKET
					   	   WHERE  stok_no  = 	pn_stok_no ) ;

		-- O zamanki degerleri oranlayarak al.
		IF  pn_islem_nominal IS NOT NULL  THEN
			ln_oran := (100 * pn_islem_nominal) / ln_nominal_tutar;
			ln_oran := ln_oran/100;
		ELSIF 	pn_islem_tutar IS NOT NULL THEN
			ln_oran := (100 * pn_islem_tutar) / ln_toplam_tutar;
			ln_oran := ln_oran/100;
		END IF;

		UPDATE CBS_MENKUL_STOK
		SET   (islenmis_kupon_faizi, prim_iskonto_tutari, deger_dusuklugu_tutari, deger_artis_tutari,
			   reeskont_tutari, mddaf, yillik_deger_dusuklugu_tutari, yillik_deger_artis_tutari,
			   yillik_reeskont_tutari,yillik_mddaf, repo_reeskont_faizi, yillik_repo_reeskont_faizi,
			   trepo_reeskont_faizi, yillik_trepo_reeskont_faizi,icverim_reeskont_irr,
			   yillik_icverim_reeskont_irr,orj_mddaf
			   )
		= 	   (SELECT (NVL(islenmis_kupon_faizi,0) * ln_oran) ,
			   		   (NVL(prim_iskonto_tutari,0) * ln_oran) ,
					   (NVL(deger_dusuklugu_tutari,0)  * ln_oran),
					   (NVL(deger_artis_tutari,0) * ln_oran),
			   		   (NVL(reeskont_tutari,0) * ln_oran),
					   (NVL(mddaf,0) * ln_oran ),
					   (NVL(yillik_deger_dusuklugu_tutari,0) * ln_oran),
					   (NVL(yillik_deger_artis_tutari,0) * ln_oran),
			   		   (NVL(yillik_reeskont_tutari,0) * ln_oran),
					   (NVL(yillik_mddaf,0) * ln_oran),
					   (NVL(repo_reeskont_faizi,0) * ln_oran),
					   (NVL(yillik_repo_reeskont_faizi,0) * ln_oran ),
			   		   (NVL(trepo_reeskont_faizi,0) * ln_oran),
					   (NVL(yillik_trepo_reeskont_faizi,0) * ln_oran),
					   (NVL(icverim_reeskont_irr,0) * ln_oran),
			   		   (NVL(yillik_icverim_reeskont_irr,0) * ln_oran),
					   (NVL(orj_mddaf,0) * ln_oran)
				FROM   CBS_MENKUL_STOK_HAREKET
				WHERE  stok_no = pn_stok_no
				AND    sira_no = ln_sira_no
			   )
	    WHERE   stok_no = pn_stok_no ;


	END IF;

	EXCEPTION
   	    WHEN OTHERS THEN
		ROLLBACK;
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3887' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
 /*******************************************************/


 FUNCTION  Repo_tutar_aralik_Kontrol RETURN NUMBER
  IS
	ln_sonuc		NUMBER;
	ln_tutar_1		NUMBER;
	ln_tutar_2		NUMBER;
	ln_tutar_11		NUMBER;
	ln_tutar_22		NUMBER;

	CURSOR c_tutar IS
	SELECT tutar_1,tutar_2
	FROM   CBS_MENKUL_REPO_TUTAR_ARA
	WHERE  gecerli='E'
	ORDER BY tutar_1;

	CURSOR c_tutar_aralik IS
	SELECT tutar_1,tutar_2
	FROM   CBS_MENKUL_REPO_TUTAR_ARA
	WHERE  gecerli='E'
	ORDER BY tutar_1 ;

  BEGIN
  	ln_sonuc := 0 ;
  	OPEN c_tutar ;
	LOOP
      FETCH  c_tutar INTO ln_tutar_1,ln_tutar_2;
      EXIT WHEN c_tutar%NOTFOUND;

	   	OPEN c_tutar_aralik ;
		LOOP
	      FETCH  c_tutar_aralik INTO ln_tutar_11,ln_tutar_22;
	      EXIT WHEN c_tutar_aralik%NOTFOUND;
	  	    IF ln_tutar_1 <> ln_tutar_11 AND ln_tutar_2 <> ln_tutar_22 THEN
				IF ln_tutar_1 >= ln_tutar_11 AND ln_tutar_1 <= ln_tutar_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;
				IF ln_tutar_2 >= ln_tutar_11 AND ln_tutar_2 <= ln_tutar_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;

			END IF;
		END LOOP;
		CLOSE c_tutar_aralik;

	END LOOP;
	CLOSE c_tutar;

	RETURN ln_sonuc ;
    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3883' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
 FUNCTION  TRepo_tutar_aralik_Kontrol RETURN NUMBER
  IS
	ln_sonuc		NUMBER;
	ln_tutar_1		NUMBER;
	ln_tutar_2		NUMBER;
	ln_tutar_11		NUMBER;
	ln_tutar_22		NUMBER;

	CURSOR c_tutar IS
	SELECT tutar_1,tutar_2
	FROM   CBS_MENKUL_TERSREPO_TUTAR_ARA
	WHERE  gecerli='E'
	ORDER BY tutar_1;

	CURSOR c_tutar_aralik IS
	SELECT tutar_1,tutar_2
	FROM   CBS_MENKUL_TERSREPO_TUTAR_ARA
	WHERE  gecerli='E'
	ORDER BY tutar_1 ;

  BEGIN
  	ln_sonuc := 0 ;
  	OPEN c_tutar ;
	LOOP
      FETCH  c_tutar INTO ln_tutar_1,ln_tutar_2;
      EXIT WHEN c_tutar%NOTFOUND;

	   	OPEN c_tutar_aralik ;
		LOOP
	      FETCH  c_tutar_aralik INTO ln_tutar_11,ln_tutar_22;
	      EXIT WHEN c_tutar_aralik%NOTFOUND;
	  	    IF ln_tutar_1 <> ln_tutar_11 AND ln_tutar_2 <> ln_tutar_22 THEN
				IF ln_tutar_1 >= ln_tutar_11 AND ln_tutar_1 <= ln_tutar_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;
				IF ln_tutar_2 >= ln_tutar_11 AND ln_tutar_2 <= ln_tutar_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;

			END IF;
		END LOOP;
		CLOSE c_tutar_aralik;

	END LOOP;
	CLOSE c_tutar;

	RETURN ln_sonuc ;
    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3884' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
 FUNCTION  Repo_vade_aralik_Kontrol RETURN NUMBER
  IS
	ln_sonuc		NUMBER;
	ln_vade_1		NUMBER;
	ln_vade_2		NUMBER;
	ln_vade_11		NUMBER;
	ln_vade_22		NUMBER;

	CURSOR c_vade IS
	SELECT vade_1,vade_2
	FROM   CBS_MENKUL_REPO_VADE_ARA
	WHERE  gecerli='E'
	ORDER BY vade_1;

	CURSOR c_vade_aralik IS
	SELECT vade_1,vade_2
	FROM   CBS_MENKUL_REPO_VADE_ARA
	WHERE  gecerli='E'
	ORDER BY vade_1 ;

  BEGIN
  	ln_sonuc := 0 ;
  	OPEN c_vade ;
	LOOP
      FETCH  c_vade INTO ln_vade_1,ln_vade_2;
      EXIT WHEN c_vade%NOTFOUND;

	   	OPEN c_vade_aralik ;
		LOOP
	      FETCH  c_vade_aralik INTO ln_vade_11,ln_vade_22;
	      EXIT WHEN c_vade_aralik%NOTFOUND;
	  	    IF ln_vade_1 <> ln_vade_11 AND ln_vade_2 <> ln_vade_22 THEN
				IF ln_vade_1 >= ln_vade_11 AND ln_vade_1 <= ln_vade_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;
				IF ln_vade_2 >= ln_vade_11 AND ln_vade_2 <= ln_vade_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;

			END IF;
		END LOOP;
		CLOSE c_vade_aralik;

	END LOOP;
	CLOSE c_vade;

	RETURN ln_sonuc ;
    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3885' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
 FUNCTION  TRepo_vade_aralik_Kontrol RETURN NUMBER
  IS
	ln_sonuc		NUMBER;
	ln_vade_1		NUMBER;
	ln_vade_2		NUMBER;
	ln_vade_11		NUMBER;
	ln_vade_22		NUMBER;

	CURSOR c_vade IS
	SELECT vade_1,vade_2
	FROM   CBS_MENKUL_TERSREPO_VADE_ARA
	WHERE  gecerli='E'
	ORDER BY vade_1;

	CURSOR c_vade_aralik IS
	SELECT vade_1,vade_2
	FROM   CBS_MENKUL_TERSREPO_VADE_ARA
	WHERE  gecerli='E'
	ORDER BY vade_1 ;

  BEGIN
  	ln_sonuc := 0 ;
  	OPEN c_vade ;
	LOOP
      FETCH  c_vade INTO ln_vade_1,ln_vade_2;
      EXIT WHEN c_vade%NOTFOUND;

	   	OPEN c_vade_aralik ;
		LOOP
	      FETCH  c_vade_aralik INTO ln_vade_11,ln_vade_22;
	      EXIT WHEN c_vade_aralik%NOTFOUND;
	  	    IF ln_vade_1 <> ln_vade_11 AND ln_vade_2 <> ln_vade_22 THEN
				IF ln_vade_1 >= ln_vade_11 AND ln_vade_1 <= ln_vade_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;
				IF ln_vade_2 >= ln_vade_11 AND ln_vade_2 <= ln_vade_22 THEN
			       ln_sonuc := 1 ;
				   EXIT ;
				END IF ;

			END IF;
		END LOOP;
		CLOSE c_vade_aralik;

	END LOOP;
	CLOSE c_vade;

	RETURN ln_sonuc ;
    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3886' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
 FUNCTION Menkul_Bnk_trepo_iptal_ctrl(ps_BTR_Referans_kodu CBS_MENKUL_BANKA_TREPO_GIRIS.referans_no%TYPE,
  		   							  pn_stokno NUMBER) RETURN NUMBER
   IS
    ln_sonuc 	 NUMBER;
	ln_txno      NUMBER;
	ln_count     NUMBER;
	/* Menkul Banka ters repo iptal  oncesi fonksiyonu icin kullanilir.*/
	/* Eger ayni referans numarali banka alimi daha once guncellenmis ama yapilan bu islem hala onay bekliyorsa (tamamlanmamissa) */
	/* iptale izin vermemeli . Ayrica baska islem yapildi ise de izin vermemeli.*/
  BEGIN
    --    ln_sonuc = 0 ya da 2 ise iptal edilemez,ln_sonuc=1 iptal edilebilir.
    SELECT NVL(MAX(tx_no),0)
	INTO   ln_txno
	FROM   CBS_MENKUL_BANKA_TREPO_GIRGNC
	WHERE  referans_no = ps_BTR_Referans_kodu
	AND	   durum_kodu 	  = 'GM_GUNC';

	ln_sonuc := Pkg_Tx.islem_bitmis_mi(ln_txno) ;

	IF 	ln_sonuc = 1 THEN

		SELECT COUNT(*)
		INTO ln_count
		FROM CBS_MENKUL_STOK_HAREKET
		WHERE stok_no = pn_stokno
		AND   islem_tipi NOT IN ( 6044,6045)  ;

		IF ln_count = 0 THEN
			ln_sonuc := 1 ;
		ELSE
			ln_sonuc := 2 ;
		END IF;
	END IF;

	RETURN ln_sonuc  ;
	  EXCEPTION
		  WHEN OTHERS THEN
		    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3893' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
  /***************************************/
 FUNCTION  Borsa_Uye_Kodu_al(pn_musteri NUMBER) RETURN VARCHAR2
   IS
    ls_kod 	 CBS_BORSA_UYE_KODLARI.kod%TYPE;
  BEGIN


  	SELECT NVL(kod,' ')
	INTO   ls_kod
	FROM   CBS_BORSA_UYE_KODLARI
	WHERE  musteri_no = pn_musteri ;

	RETURN ls_kod ;

  EXCEPTION
  	  WHEN NO_DATA_FOUND THEN
	   	ls_kod  := ' ' ;
		RETURN ls_kod ;
	  WHEN OTHERS THEN
	   	ls_kod  := ' ' ;
		RETURN ls_kod ;

  END;

  /***************************************/

  FUNCTION  Stok_Kaynagi_Bul(pn_stokno CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2
   IS
   ls_stok_kaynagi   VARCHAR2(10);
  BEGIN

	SELECT DISTINCT DECODE(islem_tipi,6011,'KS',6024,'EG',6062,'KA',6040,'RS','BL')
	INTO   ls_stok_kaynagi
	FROM CBS_MENKUL_STOK_HAREKET
	WHERE sira_no = (SELECT MIN(sira_no) FROM CBS_MENKUL_STOK_HAREKET
		  		  	 WHERE stok_no = pn_stokno)	 ;

	RETURN ls_stok_kaynagi ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4145' || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

 END  Pkg_Menkul;
/

