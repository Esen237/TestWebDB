create PACKAGE BODY     pkg_masraf_tx33202  IS

p_33202_FC_MSRF_DOVIZ_KODU        NUMBER;
p_33202_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_33202_KUR						  NUMBER;
p_33202_REFERENCE				  NUMBER;
p_33202_ISTA_KOD				  NUMBER;
p_33202_MUS_ACIK				  NUMBER;
p_33202_BANKA_ACIK				  NUMBER;
p_33202_ISLEM_SUBE				  NUMBER;
p_33202_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_33202_FC_MASRAF_TUTARI		  NUMBER;
p_33202_LC_MASRAF_TUTAR			  NUMBER;
p_33202_MASRAF_HESAP_SUBE		  NUMBER;
p_33202_MASRAF_HESAP_NO			  NUMBER;
p_33202_LC_MAIL_CHARGE			  NUMBER;
p_33202_LC_COMM_CHARGE			  NUMBER;
p_33202_LC_CONF_COM				  NUMBER;
p_33202_LC_ADVICE_COM			  NUMBER;
p_33202_MAIL_CHARGE_GL			  NUMBER;
p_33202_COMM_CHARGE_GL			  NUMBER;
p_33202_CONF_COM_GL				  NUMBER;
p_33202_ADVICE_COM_GL			  NUMBER;
p_33202_UNCOMFIRM				  NUMBER;
p_33202_COMFIRM					  NUMBER;
p_33202_FC						  NUMBER;
p_33202_LC						  NUMBER;
p_33202_MAILCOM_VAR				  NUMBER;
p_33202_COMMCOM_VAR				  NUMBER;
p_33202_CONFCOM_VAR				  NUMBER;
p_33202_ADVICECOM_VAR			  NUMBER;
p_33202_FC_MASRAF_ANA			  NUMBER;
p_33202_LC_MASRAF_ANA			  NUMBER;
p_33202_MAILCOM_EXP				  NUMBER;
p_33202_COMMCOM_EXP				  NUMBER;
p_33202_CONFCOM_EXP				  NUMBER;
p_33202_ADVICECOM_EXP			  NUMBER;
p_33202_LC_SERVICE_TAX			  NUMBER;
p_33202_FC_SERVICE_TAX			  NUMBER;
p_33202_SERVICE_TAX_VAR			  NUMBER;
p_33202_SERVICE_TAX_GL			  NUMBER;

/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number, ps_ref varchar2, ps_no number) is
  begin
   pkg_masraf.onay_sonrasi(pn_islem_no, ps_ref, ps_no, 'P', 'EXPCONFCOM');
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   pkg_masraf.Reddetme_Sonrasi(pn_islem_no, ps_ref);
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
    pkg_masraf.Iptal_Onay_Sonrasi_odeme(pn_islem_no, ps_ref);
  end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number, pn_fis_no in out number) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   ls_tahsil_doviz        varchar2(3);
   ls_hesap_doviz         varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_eski_tahsil_tutar	  number;
   ln_tahsil_tutar		  number;
   ls_istatistik_kodu     VARCHAR2(2000);
   ln_dk_grup_no number;
   ls_aciklama			  VARCHAR2(2000);
   ln_tax_rate            NUMBER;
   ln_tax_amount          NUMBER;
   lb_vergi_var           boolean;
   cursor cur_masraf is
    select *
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID'
	 order by sira_no desc   --en son girilen ?deme komisyonu ilk al?nmaya ?al???lacak...
	for update;
	row_masraf cur_masraf%rowtype;

   cursor c_0 is
    select count(*)
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID';
	 ln_temp number;

   cursor cur_akr_detay is
    select doviz_kodu,teyit_kodu,lehdar_musteri_no
	  from cbs_akreditif
	 where referans = ls_referans;
	row_akr_detay  cur_akr_detay%rowtype;

   cursor cur_po is
     select * from cbs_akr_pesin_odeme_islem
	  where tx_no = pn_islem_no;
	 row_po cur_po%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no --referans = ls_referans
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;

  Begin
    ln_fis_no := pn_fis_no;
	open c_0;
	fetch c_0 into ln_temp;
	close c_0;
	if ln_temp <= 0 then
	  return;
	end if;
	open cur_akr_detay;
	 fetch cur_akr_detay into row_akr_detay;
	close cur_akr_detay;

   	open cur_po;
	fetch cur_po into row_po;
	 varchar_list(p_33202_MASRAF_HESAP_NO) := row_po.masraf_hesap_no;
     varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_po.masraf_hesap_no);
	 ls_hesap_doviz:=Pkg_Hesap.HesaptanDovizKoduAl(row_po.masraf_hesap_no);
     varchar_list(p_33202_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_po.masraf_hesap_no);
	 ls_referans := row_po.referans;
 	 varchar_list(p_33202_ISLEM_SUBE) := pkg_tx.amir_bolumkodu_al(pn_islem_no);--pkg_baglam.bolum_kodu;
 	close cur_po;
	 ls_akr_doviz := row_akr_detay.doviz_kodu;
	 IF row_akr_detay.teyit_kodu='TEYITLI' THEN
		boolean_list(p_33202_UNCOMFIRM) := FALSE ;
		boolean_list(p_33202_COMFIRM)	:= TRUE ;
	 ELSE
		boolean_list(p_33202_UNCOMFIRM) := TRUE ;
		boolean_list(p_33202_COMFIRM)	:= FALSE ;
	 END IF;



	    boolean_list(p_33202_MAILCOM_VAR) := FALSE ;
		boolean_list(p_33202_COMMCOM_VAR) := FALSE ;
		boolean_list(p_33202_CONFCOM_VAR) := FALSE ;
		boolean_list(p_33202_ADVICECOM_VAR) := FALSE ;
		boolean_list(p_33202_FC_MASRAF_ANA) := FALSE ;
		boolean_list(p_33202_LC_MASRAF_ANA) := FALSE ;
        boolean_list(p_33202_SERVICE_TAX_VAR) := FALSE;


		IF  row_po.masraf_hesap_no IS NOT NULL THEN
	       ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33202_MASRAF_HESAP_NO)) );
		   varchar_list(p_33202_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPMAILCHR');
		   varchar_list(p_33202_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCOMCAT');
		   varchar_list(p_33202_CONF_COM_GL)	  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCONFCOM');
		   varchar_list(p_33202_ADVICE_COM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPADVCOM');
           varchar_list(p_33202_SERVICE_TAX_GL) := '';
		   if pkg_musteri.musteri_vergiden_muafmi(row_akr_detay.lehdar_musteri_no) = 'H' then -- Lehdar m?steri no dogru mu?????
		     lb_vergi_var := TRUE;
		   end if;
    	ELSE
		   varchar_list(p_33202_MAIL_CHARGE_GL) := '';
		   varchar_list(p_33202_COMM_CHARGE_GL) := '';
		   varchar_list(p_33202_CONF_COM_GL)	  := '';
		   varchar_list(p_33202_ADVICE_COM_GL) := '';
           varchar_list(p_33202_SERVICE_TAX_GL) := '';
	    END IF;

     	   varchar_list(p_33202_REFERENCE) := ls_referans;
	       varchar_list(p_33202_ISTA_KOD)  := ls_istatistik_kodu;

		IF varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		   boolean_list(p_33202_LC_MSRF_DOVIZ_KODU) := FALSE;
		   boolean_list(p_33202_FC_MSRF_DOVIZ_KODU) := TRUE ;
		ELSE
		   boolean_list(p_33202_LC_MSRF_DOVIZ_KODU) := TRUE;
		   boolean_list(p_33202_FC_MSRF_DOVIZ_KODU) := FALSE;
		END IF;

		number_list(p_33202_LC_COMM_CHARGE) := 0;
		number_list(p_33202_LC_MAIL_CHARGE) := 0;
		number_list(p_33202_LC_CONF_COM) := 0;
		number_list(p_33202_LC_ADVICE_COM) := 0;
		number_list(p_33202_LC_MASRAF_TUTAR) := 0;
		number_list(p_33202_FC_MASRAF_TUTARI) := 0;
        number_list(p_33202_LC_SERVICE_TAX)   := 0;
        number_list(p_33202_FC_SERVICE_TAX)   := 0;
		varchar_list(p_33202_MAILCOM_EXP)	:='';
		varchar_list(p_33202_COMMCOM_EXP)	:='';
	    varchar_list(p_33202_CONFCOM_EXP)	:='';
	    varchar_list(p_33202_ADVICECOM_EXP):='';

		IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
		  boolean_list(p_33202_LC) := TRUE;
	      boolean_list(p_33202_FC) := FALSE;
		ELSE
		  boolean_list(p_33202_LC) := FALSE;
	      boolean_list(p_33202_FC) := TRUE;
		END IF;
		ls_aciklama := 'Advance Payment of an Export L/C Charges' ;
		varchar_list(p_33202_BANKA_ACIK) := ls_aciklama;
		varchar_list(p_33202_MUS_ACIK) :=varchar_list(p_33202_BANKA_ACIK) ;

		IF  varchar_list(p_33202_MASRAF_HESAP_NO) IS NOT NULL THEN  --masraf hesab? girilmi?se
--            IF varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU) =pkg_genel.lc_al then
--			   number_list(p_33202_KUR) := Pkg_Komisyon_Kur.KUR_to_lc(varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU),1);
--			else
        	   number_list(p_33202_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU),1);
--			end if;
		     --masraf alinacak hesabin bakiyesini al
		     ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33202_MASRAF_HESAP_NO));
        END IF;



	open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  ls_tahsil_doviz:=row_masraf.DVZ;

	  IF nvl(row_masraf.tahsil_edilemeyen,0) > 0  THEN

		   IF pkg_ihracat.masraf_kontrol_yap(row_masraf.ODEYECEK) = 'Y'  THEN
	         ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);

			 IF row_masraf.masraf_kodu = 'EXPCOMCAT'  THEN  --haberle?me
			     boolean_list(p_33202_COMMCOM_VAR) := TRUE ;
--			   IF boolean_list(p_33202_LC_MSRF_DOVIZ_KODU) THEN
--            	  number_list(p_33202_LC_COMM_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--               ELSE
				  number_list(p_33202_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--			   END IF;
				 ln_borc_tutar := number_list(p_33202_LC_COMM_CHARGE);--number_list(p_33202_HABR_MDV);
				 ln_borc_trl := number_list(p_33202_LC_COMM_CHARGE);
			     varchar_list(p_33202_COMMCOM_EXP) := 'EXPCOMCAT '||row_po.referans||' Export Communication Charge' ;

			  ELSIF row_masraf.masraf_kodu = 'EXPMAILCHR' THEN   --posta

				  boolean_list(p_33202_MAILCOM_VAR) := TRUE ;
--				  IF boolean_list(p_33202_LC_MSRF_DOVIZ_KODU) THEN
--            	     number_list(p_33202_LC_MAIL_CHARGE)  := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--                  ELSE
				     number_list(p_33202_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  ln_borc_tutar := number_list(p_33202_LC_MAIL_CHARGE);--number_list(p_33202_POSTA_MDV);
				  ln_borc_trl := number_list(p_33202_LC_MAIL_CHARGE);
				  varchar_list(p_33202_MAILCOM_EXP)	:='EXPMAILCHR '||row_po.referans||' Export Mail Charge';

			  ELSIF  row_masraf.masraf_kodu = 'EXPADVCOM' THEN   --Advise

			      boolean_list(p_33202_ADVICECOM_VAR) := TRUE ;
--			   	  IF boolean_list(p_33202_LC_MSRF_DOVIZ_KODU) THEN
--            	     number_list(p_33202_LC_ADVICE_COM)  := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--                  ELSE
				     number_list(p_33202_LC_ADVICE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  ln_borc_tutar := number_list(p_33202_LC_ADVICE_COM);--number_list(p_33202_POSTA_MDV);
				  ln_borc_trl := number_list(p_33202_LC_ADVICE_COM);
			      varchar_list(p_33202_ADVICECOM_EXP)	:='EXPADVCOM '||row_po.referans||' Advising Commission';

			   ELSIF row_masraf.masraf_kodu =  'EXPCONFCOM' then  --Confirmation taksitli OLUR
			       boolean_list(p_33202_CONFCOM_VAR) := TRUE ;
			       ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
				   IF nvl(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
					   --daha fazlas? veya ayn?s? ?nceden al?nm??
					   --hi? bir ?ey yapma
					   ln_tahsil_tutar := 0;
				   ELSE
							  lb_taksit_var := true;
							  open cur_taksitler;
							  loop
							    fetch cur_taksitler into row_taksit;
								exit when cur_taksitler%notfound;

									ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
--									IF boolean_list(p_33202_LC_MSRF_DOVIZ_KODU) THEN
--									   number_list(p_33202_LC_CONF_COM)   := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--                                    ELSE
                                       number_list(p_33202_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--						            END IF;
		 				            ln_borc_tutar := number_list(p_33202_LC_CONF_COM);--number_list(p_33202_TEYIT_MDV);
								    ln_borc_trl := number_list(p_33202_LC_CONF_COM);
		                            varchar_list(p_33202_CONFCOM_EXP)	:='EXPCONFCOM '||row_po.referans||' Export L/C Confirmtion Commission';


								if ln_son_bakiye >= ln_borc_tutar then
								   boolean_list(p_33202_COMMCOM_VAR) := FALSE ;
							       boolean_list(p_33202_MAILCOM_VAR) := FALSE ;
							       boolean_list(p_33202_ADVICECOM_VAR) := FALSE ;
						           ln_fis_no:=pkg_muhasebe.fis_kes ( 33202, null, pn_islem_no, varchar_list, number_list,
												    			  	  date_list, boolean_list, null, false, ln_fis_no, null);
					     		     update cbs_masraf_ith_ihr_isl
									   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
									       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
								     where current of cur_masraf;

		  					  		pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
		                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

									update cbs_masraf_taksit_islem
									   set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
									       odenen_tutar = taksit_tutari
									 where current of cur_taksitler;

	      						           pkg_masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_33202_LC_CONF_COM), row_po.masraf_hesap_no,
																   row_po.valor_tarihi, 'E');

									ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
									number_list(p_33202_LC_MASRAF_TUTAR) := number_list(p_33202_LC_MASRAF_TUTAR) + ln_borc_trl;
							        number_list(p_33202_FC_MASRAF_TUTARI) := number_list(p_33202_FC_MASRAF_TUTARI) + ln_borc_tutar;
								END IF;
					  END LOOP;
					  CLOSE cur_taksitler;

				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
			  ELSE
			    CLOSE cur_masraf;
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '341' ||  pkg_hata.getDelimiter || row_masraf.masraf_kodu || pkg_hata.getUCPOINTER);
			  end if;
			  if not lb_taksit_var then
			   if ln_son_bakiye >= ln_borc_tutar then --bakiye yeterliyse satiri ekle
			     if ln_tahsil_tutar <> 0 then
			         ln_fis_no:=pkg_muhasebe.fis_kes ( 33202, null, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  null, false, ln_fis_no, null);

					  IF boolean_list(p_33202_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33202_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33202_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33202_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33202_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33202_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33202_ADVICECOM_VAR) = TRUE THEN
					  	 boolean_list(p_33202_ADVICECOM_VAR) := FALSE;
					  END IF;

					  pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      update cbs_masraf_ith_ihr_isl
					     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       where current of cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
					  number_list(p_33202_LC_MASRAF_TUTAR) := number_list(p_33202_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33202_FC_MASRAF_TUTARI) := number_list(p_33202_FC_MASRAF_TUTARI) + ln_borc_tutar;
				end if;
			   end if;
			  end if;
 	      end if; --ihracat?? ?demesi
	  end if;  --tahsil edilmeyen var....

	end loop;
	close cur_masraf;
	boolean_list(p_33202_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33202_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33202_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33202_ADVICECOM_VAR) := FALSE ;


    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_tax_rate);
	ln_tax_amount := (nvl(number_list(p_33202_LC_COMM_CHARGE),0) + nvl(number_list(p_33202_LC_MAIL_CHARGE),0)) * ln_tax_rate / 100;
	if lb_vergi_var and ln_tax_amount != 0 then
	  number_list(p_33202_LC_SERVICE_TAX)   := ln_tax_amount;
      number_list(p_33202_FC_SERVICE_TAX)   := ln_tax_amount/Pkg_Kur.MB_dak_to_lc(varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU),1);
	  boolean_list(p_33202_SERVICE_TAX_VAR) := TRUE;
	else
	  boolean_list(p_33202_SERVICE_TAX_VAR) := FALSE;
	end if;


	IF number_list(p_33202_FC_MASRAF_TUTARI) > 0 THEN
	   number_list(p_33202_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33202_LC_MASRAF_TUTAR)) ;
	   number_list(p_33202_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33202_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33202_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33202_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33202_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33202_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33202_LC_MASRAF_ANA) := TRUE ;

		END IF;
	       ln_fis_no:=pkg_muhasebe.fis_kes ( 33202,
		    			 	              	  null,
			     						  	  pn_islem_no,
				    					  	  varchar_list ,
					    				  	  number_list  ,
						    			  	  date_list    ,
							    		  	  boolean_list ,
								    	  	  null,
									     	  false,
									  	      ln_fis_no,
									  	      null);
	END IF;

/*
	 varchar_list(p__M_HESAP) := row_po.masraf_hesap_no;
	 varchar_list(p__MHESAP_DVZ):= row_po.masraf_hesap_doviz;
	 varchar_list(p__MHESAP_SUBE) := row_po.masraf_hesap_sube;
	 varchar_list(p__ISLEM_SUBE) := pkg_tx.amir_bolumkodu_al(pn_islem_no);--pkg_baglam.bolum_kodu;
	 ls_referans := row_po.referans;
	close cur_po;
	open cur_akr_detay;
	 fetch cur_akr_detay into row_akr_detay;
	close cur_akr_detay;
	ls_akr_doviz := row_akr_detay.doviz_kodu;
    if varchar_list(p__MHESAP_DVZ) = pkg_genel.LC_AL then
	 boolean_list(p__M_HESAP_TRL) := TRUE;
	 boolean_list(p__M_HESAP_DVZ) := FALSE;
	else
	 boolean_list(p__M_HESAP_TRL) := FALSE;
	 boolean_list(p__M_HESAP_DVZ) := TRUE;
	end if;
	boolean_list(p__MAS_TP_ANA) := FALSE;
	boolean_list(p__MAS_YP_ANA) := FALSE;
	number_list(p__HABR_TRL) := 0;
	number_list(p__HABR_MDV) := 0;
	varchar_list(p__MAS_HABR_ACIKLAMA) := '';
	boolean_list(p__HABR_VAR) := FALSE;
	number_list(p__POK_TRL) := 0;
	number_list(p__POK_MDV) := 0;
	varchar_list(p__MAS_POK_ACIKLAMA) := '';
	boolean_list(p__POK_VAR) := FALSE;
	number_list(p__POSTA_TRL) := 0;
	number_list(p__POSTA_MDV) := 0;
	varchar_list(p__MAS_POST_ACIKLAMA) := '';
	boolean_list(p__POSTA_VAR) := FALSE;
	number_list(p__TEYIT_TRL) := 0;
	number_list(p__TEYIT_MDV) := 0;
	varchar_list(p__MAS_TEY_ACIKLAMA) := '';
	boolean_list(p__TEYIT_VAR) := FALSE;
	number_list(p__IHBAR_TRL) := 0;
	number_list(p__IHBAR_MDV) := 0;
	varchar_list(p__MAS_IHBAR_ACIKLAMA) := '';
	boolean_list(p__IHBAR_VAR) := FALSE;

	number_list(p__KOM_TOPLAMI) := 0;
	number_list(p__KOM_MDV_TOPLAM) := 0;
	varchar_list(p__MAS_ACIKLAMA) := 'AKREDITIF MASRAFLARI';
	if varchar_list(p__M_HESAP) is not null then  --masraf hesab? girilmi?se
		number_list(p__KUR_TUTAR) := pkg_kur.dak_to_lc(varchar_list(p__MHESAP_DVZ),1);
		--masraf al?nacak hesab?n bakiyesini al
		ln_son_bakiye := pkg_hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p__M_HESAP));
    end if;
	open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  boolean_list(p__TEYIT_VAR) := FALSE;
	  boolean_list(p__IHBAR_VAR) := FALSE;
	  boolean_list(p__HABR_VAR) := FALSE;
	  boolean_list(p__POSTA_VAR) := FALSE;
	  boolean_list(p__POK_VAR) := FALSE;
	  if nvl(row_masraf.tahsil_edilemeyen,0) > 0  then
		  if row_masraf.ODEYECEK = '?HRACAT?I' then
		      ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
		      if row_masraf.masraf_kodu = 'LCACIHBAR'  then     --ihbar masraf?
	--masraflar akreditif kurunda, onlar? masraf hesab?n?n kuruna ?evirmek gerekli......
			    if boolean_list(p__M_HESAP_TRL) then
				   number_list(p__IHBAR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
				   number_list(p__IHBAR_MDV) := number_list(p__IHBAR_TRL);
				else
				   number_list(p__IHBAR_MDV) := pkg_kur.yuvarla(varchar_list(p__MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p__MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p__IHBAR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p__MHESAP_DVZ),number_list(p__IHBAR_MDV)));
				end if;
  --bu iki de?i?ken ile hesab?n ?demeyi alabilmek i?in yeterli olup olmad??? ara?t?r?lacak
  --e?er yeterli miktar varsa, toplam sat?r i?in toplanacak
				ln_borc_tutar := number_list(p__IHBAR_MDV);
				ln_borc_trl := number_list(p__IHBAR_TRL);
				varchar_list(p__MAS_IHBAR_ACIKLAMA) := '?HBAR MASRAFLARI';
				boolean_list(p__IHBAR_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu = 'LCACHABR'  then   --haberle?me
			    if boolean_list(p__M_HESAP_TRL) then
					number_list(p__HABR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					number_list(p__HABR_MDV) := number_list(p__HABR_TRL);
				else
				   number_list(p__HABR_MDV) := pkg_kur.yuvarla(varchar_list(p__MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p__MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p__HABR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p__MHESAP_DVZ),number_list(p__HABR_MDV)));
				end if;
				ln_borc_tutar := number_list(p__HABR_MDV);
				ln_borc_trl := number_list(p__HABR_TRL);
		    	varchar_list(p__MAS_HABR_ACIKLAMA) := 'HABERLE?ME MASRAFLARI';
				boolean_list(p__HABR_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu = 'LCACPOSTA' then   --posta
			    if boolean_list(p__M_HESAP_TRL) then
					number_list(p__POSTA_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					number_list(p__POSTA_MDV) := number_list(p__POSTA_TRL);
				else
				   number_list(p__POSTA_MDV) := pkg_kur.yuvarla(varchar_list(p__MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p__MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p__POSTA_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p__MHESAP_DVZ),number_list(p__POSTA_MDV)));
				end if;
				ln_borc_tutar := number_list(p__POSTA_MDV);
				ln_borc_trl := number_list(p__POSTA_TRL);
				varchar_list(p__MAS_POST_ACIKLAMA) := 'POSTA MASRAFLARI';
				boolean_list(p__POSTA_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu = 'LCPODEKOM'  then   --pe?in ?deme komisyonu
			    if boolean_list(p__M_HESAP_TRL) then
					number_list(p__POK_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					number_list(p__POK_MDV) := number_list(p__POK_TRL);
				else
				   number_list(p__POK_MDV) := pkg_kur.yuvarla(varchar_list(p__MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p__MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p__POK_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p__MHESAP_DVZ),number_list(p__POK_MDV)));
				end if;
				ln_borc_tutar := number_list(p__POK_MDV);
				ln_borc_trl := number_list(p__POK_TRL);
		    	varchar_list(p__MAS_POK_ACIKLAMA) := 'PE??N ?DEME KOM?SYONU';
				boolean_list(p__POK_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu =  'AKRTEYITKM' then  --teyit TAKS?TL? OLUR
			    ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
				if nvl(row_masraf.tahsil_edilemeyen,0) <= 0  then
				   --daha fazlas? veya ayn?s? ?nceden al?nm??
				   --hi? bir ?ey yapma
				   ln_tahsil_tutar := 0;
				else
					if  row_masraf.komisyon_tipi not like 'DONEMSEL%' then
					    ln_tahsil_tutar := row_masraf.hesaplanan - nvl(row_masraf.tahsil_toplam,0);
					    if boolean_list(p__M_HESAP_TRL) then
						  number_list(p__TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
						  number_list(p__TEYIT_MDV) := number_list(p__TEYIT_TRL);
						else
						  number_list(p__TEYIT_MDV) := pkg_kur.yuvarla(varchar_list(p__MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p__MHESAP_DVZ), null,
					                                       ln_tahsil_tutar, 1, null, null, 'O', 'A'));
						  number_list(p__TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p__MHESAP_DVZ),number_list(p__TEYIT_MDV)));
						end if;
						ln_borc_tutar := number_list(p__TEYIT_MDV);
						ln_borc_trl := number_list(p__TEYIT_TRL);
						varchar_list(p__MAS_TEY_ACIKLAMA) := 'AKREDITIF TEY?T MASRAFLARI';
						boolean_list(p__TEYIT_VAR) := TRUE;
					else   --d?nemsel masraf
					  lb_taksit_var := true;
					  open cur_taksitler;
					  loop
					    fetch cur_taksitler into row_taksit;
						exit when cur_taksitler%notfound;
					    if boolean_list(p__M_HESAP_TRL) then
						  number_list(p__TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)));
						  number_list(p__TEYIT_MDV) := number_list(p__TEYIT_TRL);
						else
						  number_list(p__TEYIT_MDV) := pkg_kur.yuvarla(varchar_list(p__MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p__MHESAP_DVZ), null,
					                                    row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0), 1, null, null, 'O', 'A'));
						  number_list(p__TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p__MHESAP_DVZ),number_list(p__TEYIT_MDV)));
						end if;
						varchar_list(p__MAS_TEY_ACIKLAMA) := row_taksit.taksit_no || '. AKREDITIF TEY?T TAKS?D?';
						ln_borc_tutar := number_list(p__TEYIT_MDV);
						ln_borc_trl := number_list(p__TEYIT_TRL);
						if ln_son_bakiye >= ln_borc_tutar then
							boolean_list(p__TEYIT_VAR) := TRUE;
						    ln_fis_no:=pkg_muhasebe.fis_kes ( , null, pn_islem_no, varchar_list, number_list,
										    			  	  date_list, boolean_list, null, false, ln_fis_no, null);

							--pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                            --                             row_masraf.masraf_kodu, (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)), row_masraf.vs_no);

						    update cbs_masraf_ith_ihr_isl
							   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
							       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
						     where current of cur_masraf;

  					  		pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

							update cbs_masraf_taksit_islem
							   set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
							       odenen_tutar = taksit_tutari
							 where current of cur_taksitler;

							ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
							number_list(p__KOM_TOPLAMI) := number_list(p__KOM_TOPLAMI) + ln_borc_trl;
							number_list(p__KOM_MDV_TOPLAM) := number_list(p__KOM_MDV_TOPLAM) + ln_borc_tutar;
						end if;
					  end loop;
					  close cur_taksitler;
					end if; --komisyon tipi
				end if; --row_masraf.tutar < ln_eski_tahsil_tutar
			  else
			    close cur_masraf;
		 	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '341' ||  pkg_hata.getDelimiter || row_masraf.masraf_kodu || pkg_hata.getUCPOINTER);
			  end if;
			  if not lb_taksit_var then
			   if ln_son_bakiye >= ln_borc_tutar then --bakiye yeterliyse satiri ekle
			     if ln_tahsil_tutar <> 0 then

			         ln_fis_no:=pkg_muhasebe.fis_kes ( , null, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  null, false, ln_fis_no, null);

					  pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);
				      update cbs_masraf_ith_ihr_isl
					     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       where current of cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
					  number_list(p__KOM_TOPLAMI) := number_list(p__KOM_TOPLAMI) + ln_borc_trl;
					  number_list(p__KOM_MDV_TOPLAM) := number_list(p__KOM_MDV_TOPLAM) + ln_borc_tutar;
				end if;
			   else
			     if  row_masraf.masraf_kodu = 'LCPODEKOM'  then
				  --pe?in ?deme komisyonu al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				    close cur_masraf;
				    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '342' ||  pkg_hata.getDelimiter || ltrim(to_char(ln_borc_tutar, '999,999,999,999,999,999,999.99')) || pkg_hata.GetDELIMITER || varchar_list(p__M_HESAP) || pkg_hata.GetDELIMITER || ltrim(to_char(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || pkg_hata.getUCPOINTER);
				 end if;
			   end if;
			  end if;
 	      end if; --ihracat?? ?demesi
	  end if;  --tahsil edilmeyen var....

	end loop;
	close cur_masraf;
	if number_list(p__KOM_MDV_TOPLAM) > 0 then
	   boolean_list(p__TEYIT_VAR) := FALSE;
	   boolean_list(p__IHBAR_VAR) := FALSE;
	   boolean_list(p__HABR_VAR) := FALSE;
	   boolean_list(p__POSTA_VAR) := FALSE;
	   boolean_list(p__POK_VAR) := FALSE;
       if boolean_list(p__M_HESAP_TRL) then
	      boolean_list(p__MAS_TP_ANA) := TRUE;
	   else
	      boolean_list(p__MAS_YP_ANA) := TRUE;
	   end if;

	       ln_fis_no:=pkg_muhasebe.fis_kes ( ,
		    			 	              	  null,
			     						  	  pn_islem_no,
				    					  	  varchar_list ,
					    				  	  number_list  ,
						    			  	  date_list    ,
							    		  	  boolean_list ,
								    	  	  null,
									     	  false,
									  	      ln_fis_no,
									  	      null);
	end if;*/
	pn_fis_no := ln_fis_no;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
    null;
   end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
    pkg_masraf.Muhasebe_Sonrasi_odeme(pn_islem_no, ps_ref);
  end;
/*------------------------------------------------------------------------------------------------------*/
 Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2 is
 ln_temp number;
 begin
   select count(*)
     into ln_temp
	 from cbs_masraf_ith_ihr_isl
	where islem_no = pn_islem_no
	  and odeyecek = 'EXPORTER'
	  and nvl(durum,'VALID') = 'VALID';
   if ln_temp > 0 then
     return 'E';
   else
     return 'H';
   end if;
 end;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN
	p_33202_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('33202_FC_MSRF_DOVIZ_KODU');
	p_33202_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('33202_LC_MSRF_DOVIZ_KODU');
	p_33202_KUR						  := Pkg_Muhasebe.parametre_index_bul('33202_KUR');
	p_33202_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('33202_REFERENCE');
	p_33202_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('33202_ISTA_KOD');
	p_33202_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33202_MUS_ACIK');
	p_33202_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33202_BANKA_ACIK');
	p_33202_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('33202_ISLEM_SUBE');
	p_33202_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('33202_MASRAF_HESAP_DOVIZ_KODU');
	p_33202_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('33202_FC_MASRAF_TUTARI');
	p_33202_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('33202_LC_MASRAF_TUTAR');
	p_33202_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('33202_MASRAF_HESAP_SUBE');
	p_33202_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('33202_MASRAF_HESAP_NO');
	p_33202_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33202_LC_MAIL_CHARGE');
	p_33202_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33202_LC_COMM_CHARGE');
	p_33202_LC_CONF_COM				  := Pkg_Muhasebe.parametre_index_bul('33202_LC_CONF_COM');
	p_33202_LC_ADVICE_COM			  := Pkg_Muhasebe.parametre_index_bul('33202_LC_ADVICE_COM');
	p_33202_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33202_MAIL_CHARGE_GL');
	p_33202_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33202_COMM_CHARGE_GL');
	p_33202_CONF_COM_GL				  := Pkg_Muhasebe.parametre_index_bul('33202_CONF_COM_GL');
	p_33202_ADVICE_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33202_ADVICE_COM_GL');
	p_33202_UNCOMFIRM				  := Pkg_Muhasebe.parametre_index_bul('33202_UNCOMFIRM');
	p_33202_COMFIRM					  := Pkg_Muhasebe.parametre_index_bul('33202_COMFIRM');
	p_33202_FC						  := Pkg_Muhasebe.parametre_index_bul('33202_FC');
	p_33202_LC						  := Pkg_Muhasebe.parametre_index_bul('33202_LC');
	p_33202_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33202_MAILCOM_VAR');
	p_33202_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33202_COMMCOM_VAR');
	p_33202_CONFCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33202_CONFCOM_VAR');
	p_33202_ADVICECOM_VAR			  := Pkg_Muhasebe.parametre_index_bul('33202_ADVICECOM_VAR');
	p_33202_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33202_FC_MASRAF_ANA');
	p_33202_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33202_LC_MASRAF_ANA');
	p_33202_MAILCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33202_MAILCOM_EXP');
	p_33202_COMMCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33202_COMMCOM_EXP');
	p_33202_CONFCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33202_CONFCOM_EXP');
	p_33202_ADVICECOM_EXP			  := Pkg_Muhasebe.parametre_index_bul('33202_ADVICECOM_EXP');
	p_33202_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33202_LC_SERVICE_TAX');
	p_33202_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33202_FC_SERVICE_TAX');
	p_33202_SERVICE_TAX_VAR			  := Pkg_Muhasebe.parametre_index_bul('33202_SERVICE_TAX_VAR');
	p_33202_SERVICE_TAX_GL			  := Pkg_Muhasebe.parametre_index_bul('33202_SERVICE_TAX_GL');
 END;
/

