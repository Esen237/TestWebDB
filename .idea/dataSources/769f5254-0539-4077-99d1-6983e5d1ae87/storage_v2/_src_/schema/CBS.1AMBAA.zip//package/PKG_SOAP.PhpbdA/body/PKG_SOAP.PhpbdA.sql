create PACKAGE BODY     "PKG_SOAP" AS

  FUNCTION new_request(method    IN VARCHAR2,
                       namespace IN VARCHAR2)
                       RETURN request AS
    req request;
  BEGIN
    req.method    := method;
    req.namespace := namespace;
    RETURN req;
  END;


  /*
   * Create a new SOAP RPC header.
   * AdiletK new web service Card Operations
   */
  PROCEDURE new_header(req   IN OUT NOCOPY request,
                       header_method    IN VARCHAR2,
                       header IN CLOB)  AS
  BEGIN
    req.header_method    := header_method;
    req.header := to_char(header);
  END;

  PROCEDURE add_parameter(req   IN OUT NOCOPY request,
                          name  IN VARCHAR2,
                          type  IN VARCHAR2,
                          value IN VARCHAR2) AS
  BEGIN
   if type is not null then
    req.body := req.body ||
       '<'||name||' xsi:type="'||type||'">'||value||'</'||name||'>';
   else
    req.body := req.body ||
       '<'||name||'>'||value||'</'||name||'>';
   end if;
  END;

  PROCEDURE generate_envelope(req IN OUT NOCOPY request,
                  env IN OUT NOCOPY VARCHAR2) AS
  BEGIN
    env := '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
        || '<soap:Body><'||req.method||' '|| req.namespace || '>'
        || req.body||'</'||req.method||'></soap:Body></soap:Envelope>';
  END;

-- AdiletK method with header for new web service call to Card Operations 
  PROCEDURE generate_envelope_card(req IN OUT NOCOPY request,
                  env IN OUT NOCOPY VARCHAR2) AS
  BEGIN
    env := '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
        || '<soap:Header><h:'||req.header_method||' xmlns:h="http://www.banksoft.com.tr/" xmlns="http://www.banksoft.com.tr/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">'
        || req.header ||'</h:'||req.header_method||'></soap:Header>'
        || '<soap:Body><'||req.method||' '||req.namespace || '>'
        || req.body||'</'||req.method||'></soap:Body></soap:Envelope>';
  END;
  -- BOM CQ5453 AskhatS 09.10.2017
  PROCEDURE generate_envelope_auto_credit(req IN OUT NOCOPY request,
                  env IN OUT NOCOPY VARCHAR2) AS
  BEGIN
    env := '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
        || /*'<soap:Header><h:'||req.header_method||' xmlns:h="http://www.banksoft.com.tr/" xmlns="http://www.banksoft.com.tr/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">'
        || req.header ||'</h:'||req.header_method||'></soap:Header>' --nurzalata
        || */
        '<soap:Header>'||
    '<UserCredentials xmlns="http://www.banksoft.com.tr/">'||
      '<userName>01</userName><password>DFJADHFA8UDF8ADkdsk18FJCHN</password></UserCredentials></soap:Header>'||
        '<soap:Body><'||req.method||' '||req.namespace || '>'
        || req.body||'</'||req.method||'></soap:Body></soap:Envelope>';
  END;
  -- EOM CQ5453 AskhatS 09.10.2017
  PROCEDURE show_envelope(env IN VARCHAR2) AS
    i   pls_integer;
    len pls_integer;
  BEGIN
    i := 1; len := length(env);
    WHILE (i <= len) LOOP
      dbms_output.put_line(substr(env, i, 60));
      i := i + 60;
    END LOOP;
  END;

  PROCEDURE check_fault(resp IN OUT NOCOPY response) AS
    fault_node   xmltype;
    fault_code   VARCHAR2(256);
    fault_string VARCHAR2(32767);
  BEGIN
  log_at('CheckElcardBalanceWS_ais',12); 
     fault_node := resp.doc.extract('/soap:Fault', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/');
     log_at('CheckElcardBalanceWS_ais',13); 
     IF (fault_node IS NOT NULL) THEN
     log_at('CheckElcardBalanceWS_ais',14); 
       fault_code := fault_node.extract('/soap:Fault/faultcode/child::text()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/').getstringval();
       log_at('CheckElcardBalanceWS_ais',15,fault_code); 
       fault_string := fault_node.extract('/soap:Fault/faultstring/child::text()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/').getstringval();
       log_at('CheckElcardBalanceWS_ais',16,fault_string); 
       --raise_application_error(-20000, fault_code || ' - ' || fault_string);
     END IF;
  END;

  FUNCTION invoke_utf8(req    IN OUT NOCOPY request,
                  url    IN VARCHAR2,
                  action IN VARCHAR2) RETURN response AS
    env       VARCHAR2(32767);
    http_req  utl_http.req;
    http_resp utl_http.resp;
    resp      response;
    PTEST VARCHAR2(2000);
  BEGIN

    generate_envelope(req, env);
    utl_http.Get_body_charset(PTEST);
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml; charset=utf-8');

    utl_http.set_header(http_req, 'Content-Length', length(convert(env,'UTF8')));
    utl_http.set_header(http_req, 'SOAPAction', action);
    utl_http.write_text(http_req, env);
    http_resp := utl_http.get_response(http_req);
    utl_http.read_text(http_resp, env);
    utl_http.end_response(http_resp);
    resp.doc := xmltype.createxml(env);
    resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');
    --resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns="http://lt.is/webservice"');
    check_fault(resp);
    RETURN resp;
  END;

  FUNCTION get_return_value(resp      IN OUT NOCOPY response,
                            name      IN VARCHAR2,
                            namespace IN VARCHAR2) RETURN VARCHAR2 AS
  BEGIN
    RETURN resp.doc.extract('//'||name||'/child::text()',
      namespace).getstringval();
  END;

  FUNCTION get_value(source_str in varchar2, search_str in varchar2, start_pos in out number) return varchar2 is
    srcSt varchar2(4000);
    ln_start_pos number;
    ln_end_pos number;
    ls_ret_str varchar2(2000);
  begin
    srcSt := '<'||search_str||'>';
    ln_start_pos := instr(source_str, srcSt, start_pos);
    if ln_start_pos > 0 then
        ln_start_pos := ln_start_pos + length(srcSt);
        srcSt := '</'||search_str||'>';
        ln_end_pos := instr(source_str, srcSt, start_pos);
        if ln_end_pos > 0 then
           start_pos := ln_end_pos + length(srcSt);
           ls_ret_str := substr(source_str, ln_start_pos, ln_end_pos-ln_start_pos);
           return ls_ret_str;
        end if;
     else
      return '';
     end if;
  end;

  FUNCTION invoke_utf8_v11(req    IN OUT NOCOPY request,
                  url    IN VARCHAR2,
                  action IN VARCHAR2) RETURN response AS
    env       VARCHAR2(32767);
    http_req  utl_http.req;
    http_resp utl_http.resp;
    resp      response;
    PTEST VARCHAR2(2000);
    ls_header_method VARCHAR2(256);
    ls_header_user VARCHAR2(256);
    ls_header_pass VARCHAR2(256);
  BEGIN
   Log_At('write_text 1',env);
    --bom nurzalata header setting 18092018
    if instr(action, 'banksoft') > 0 then
    Log_At('CreditCardCPaymentTx 2',action);
        pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
        pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
        ls_header_method := 'UserCredentials';
         Log_At('CreditCardCPaymentTx 4',url,ls_header_user,ls_header_pass );
        
        PKG_SOAP.NEW_HEADER(req, ls_header_method,
        '<BankCode>' || ls_header_user || '</BankCode>' ||
        '<password>' || /*ls_header_pass*/'DFJADHFA8UDF8ADkdsk18FJCHN' || '</password>'); -- change for PenTest 09/03/2022
        generate_envelope_card(req, env);
    else
        generate_envelope(req, env);
    end if;
    --eom nurzalata header setting 18092018
    log_at('soap_header_test', substr(env, 1, 1999));
    utl_http.set_proxy(null, '192.168.111.222,192.168.111.3');
    utl_http.Get_body_charset(PTEST);
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml; charset=utf-8');
    log_at('CheckElcardBalanceWS_ais',6); 
    utl_http.set_header(http_req, 'Content-Length', length(convert(env,'UTF8')));
    log_at('CheckElcardBalanceWS_ais',7); 
    utl_http.set_header(http_req, 'SOAPAction', action);
    utl_http.write_text(http_req, env);
    http_resp := utl_http.get_response(http_req);
    utl_http.read_text(http_resp, env);
    utl_http.end_response(http_resp);
    log_at('CheckElcardBalanceWS_ais',8); 
    log_at('CheckElcardBalanceWS_ais_env', substr(env, 1, 1999));
    resp.doc := xmltype.createxml(env);
    log_at('CheckElcardBalanceWS_ais',9);    
    resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');
    log_at('CheckElcardBalanceWS_ais',10);
    check_fault(resp);
    log_at('CheckElcardBalanceWS_ais',11); 
    RETURN resp;
  exception 
     when others then
       log_at('sendTaxHouseReportSoap', sqlerrm, dbms_utility.format_error_backtrace);
  END;
  
  /*******************************************************************************
    Name        :invoke_utf8_v11_cib_clob
    Prepared By :Chyngyz Omurov
    Date:       07.08.2014
    Base Project :  CQ614 - CIB Automatization
    Purpose     :  to make web service call to CIB for credit history retrieval
*******************************************************************************/
  FUNCTION invoke_utf8_v11_cib_clob(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response AS
    env         VARCHAR2(32767);
    l_clob      clob;
    http_req    utl_http.req;
    http_resp   utl_http.resp;
    resp        response;
    PTEST       VARCHAR2(2000);
    ls_header_method VARCHAR2(256);
    ls_header_user VARCHAR2(256);
    ls_header_pass VARCHAR2(256);
  BEGIN
  --bom nurzalata header setting 18092018
    if instr(action, 'banksoft') > 0 then
        pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
        pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
        ls_header_method := 'UserCredentials';
        PKG_SOAP.NEW_HEADER(req, ls_header_method,
        '<userName>' || ls_header_user || '</userName>' ||
        '<password>' || ls_header_pass || '</password>');
    else
        generate_envelope_card(req, env);
    end if;
    --eom nurzalata header setting 18092018
    DBMS_LOB.createtemporary(l_clob, FALSE);
    utl_http.Get_body_charset(PTEST);
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml; charset=utf-8');
    utl_http.set_header(http_req, 'Content-Length', length(convert(env,'UTF8')));
    utl_http.set_header(http_req, 'SOAPAction', action);
    utl_http.write_text(http_req, env);
    http_resp := utl_http.get_response(http_req);
        BEGIN
            LOOP
              utl_http.read_text(http_resp, env, 32000);
              env := REPLACE(env, 'xmlns="https://service.ishenim.kg/basic/"');
              env := REPLACE(env, 'xmlns="http://services.demirbank.kg/"');

              DBMS_LOB.writeappend(l_clob, LENGTH(env), env);
            END LOOP;
        EXCEPTION
            WHEN others THEN
                utl_http.end_response(http_resp);
        END;       
    resp.doc := xmltype.createxml(l_clob);
    resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');
    check_fault(resp); 
    RETURN resp;
  END;
  
  /*******************************************************************************
    Name        :decode_base64
    Prepared By :Chyngyz Omurov
    Date:       :07.08.2014
    Base Project :  CQ614 - CIB Automatization
    Purpose     :to decode base64-encoded CLOB
*******************************************************************************/
  function decode_base64(p_clob_in in clob) return blob is
    v_blob blob;
    v_result blob;
    v_offset integer;
    v_buffer_size binary_integer := 48;
    v_buffer_varchar varchar2(48);
    v_buffer_raw raw(48);
  begin
    if p_clob_in is null then
      return null;
    end if;
    dbms_lob.createtemporary(v_blob, true);
    v_offset := 1;
    for i in 1 .. ceil(dbms_lob.getlength(p_clob_in) / v_buffer_size) loop
      dbms_lob.read(p_clob_in, v_buffer_size, v_offset, v_buffer_varchar);
      v_buffer_raw := utl_raw.cast_to_raw(v_buffer_varchar);
      v_buffer_raw := utl_encode.base64_decode(v_buffer_raw);
      dbms_lob.writeappend(v_blob, utl_raw.length(v_buffer_raw), v_buffer_raw);
      v_offset := v_offset + v_buffer_size;
    end loop;
    v_result := v_blob;
    dbms_lob.freetemporary(v_blob);
    return v_result;
  end ;
  
 /*******************************************************************************
    Name        :invoke_utf8_v11_cib_binary
    Prepared By :Chyngyz Omurov
    Date:       :07.08.2014
    Base Project :  CQ614 - CIB Automatization
    Purpose     : to download excel file from CIB
*******************************************************************************/
 FUNCTION invoke_utf8_v11_cib_binary(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN BLOB AS
    env         VARCHAR2(32767);
    l_clob      clob;
    http_req    utl_http.req;
    http_resp   utl_http.resp;
    resp        response;
    PTEST       VARCHAR2(2000);
        
    l_clob_response  CLOB;
    l_clob_response_new  CLOB;
    l_blob_new blob;
      
    l_raw            RAW(512);
    l_buffer_size    NUMBER(10) := 512;
    l_tag_start NUMBER;
    l_tag_end NUMBER;
    ls_header_method VARCHAR2(256);
    ls_header_user VARCHAR2(256);
    ls_header_pass VARCHAR2(256);
    
  BEGIN
    --bom nurzalata header setting 18092018
    if instr(action, 'banksoft') > 0 then
        pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
        pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
        ls_header_method := 'UserCredentials';
        PKG_SOAP.NEW_HEADER(req, ls_header_method,
        '<userName>' || ls_header_user || '</userName>' ||
        '<password>' || ls_header_pass || '</password>');
    else
        generate_envelope_card(req, env);
    end if;
    --eom nurzalata header setting 18092018
    utl_http.Get_body_charset(PTEST);
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml; charset=utf-8');

    utl_http.set_header(http_req, 'Content-Length', length(convert(env,'UTF8')));
    utl_http.set_header(http_req, 'SOAPAction', action);
    utl_http.write_text(http_req, env);
            
    http_resp := utl_http.get_response(http_req);
            
     DBMS_LOB.createtemporary(l_clob_response, FALSE);
     
        BEGIN
            LOOP
                  UTL_HTTP.READ_RAW(http_resp, l_raw, l_buffer_size);
                  l_clob_response := l_clob_response || UTL_RAW.cast_to_varchar2(l_raw);
             END LOOP;
        EXCEPTION      
            WHEN others THEN
               utl_http.end_response(http_resp);
        END;
      
        l_tag_start := dbms_lob.instr(l_clob_response, '<cibFileContent>');
        l_tag_end := dbms_lob.instr(l_clob_response, '</cibFileContent>');
        
        DBMS_LOB.createtemporary(l_clob_response_new, FALSE);
         
      
        DBMS_LOB.COPY(l_clob_response_new, 
                                        l_clob_response, 
                                        l_tag_end - l_tag_start -  DBMS_LOB.GETLENGTH('<cibFileContent>') , 
                                        1,
                                         l_tag_start + DBMS_LOB.GETLENGTH('<cibFileContent>') ) ;
              
         l_blob_new := decode_base64(l_clob_response_new);
              
    RETURN l_blob_new;
    
    EXCEPTION 
        WHEN OTHERS THEN

            if  l_blob_new is not null then
                DBMS_LOB.freetemporary(l_blob_new);
             end if;
             
            RETURN null;
  END;
PROCEDURE generate_envelope_mi(req IN OUT NOCOPY request,
                                 env IN OUT NOCOPY clob) AS
  BEGIN
      env := '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
      || '<soap:Body>'
      || '<'||req.method|| ' ' || req.namespace||'>'
      || req.BODY
      || '</'||req.method||'>'
      || '</soap:Body>'
      || '</soap:Envelope>';
  END;
  
FUNCTION invoke_utf8_v11_mi(req    IN OUT NOCOPY request,
                            url    IN VARCHAR2,
                            action IN VARCHAR2) RETURN response AS
    env       VARCHAR2(32767);
    l_clob    CLOB;
    http_req  utl_http.req;
    http_resp utl_http.resp;
    resp      response;
    PTEST VARCHAR2(2000);
    ln_index NUMBER:=1;
    ls_header_method VARCHAR2(256);
    ls_header_user VARCHAR2(256);
    ls_header_pass VARCHAR2(256);
  BEGIN
  --bom nurzalata header setting 18092018
    if instr(action, 'banksoft') > 0 then
        pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
        pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
        ls_header_method := 'UserCredentials';
        PKG_SOAP.NEW_HEADER(req, ls_header_method,
        '<userName>' || ls_header_user || '</userName>' ||
        '<password>' || ls_header_pass || '</password>');
    else
        generate_envelope_card(req, env);
    end if;
    --eom nurzalata header setting 18092018
    utl_http.Get_body_charset(PTEST);
    --UTL_HTTP.SET_WALLET('file:/oradata/DOSYA', 'asd123456' );
dbms_output.put_line('11 : ');
    utl_http.set_wallet('file:C:\SMS_WALLET','admin123');
    utl_http.set_proxy('10.0.0.252:8080','');

dbms_output.put_line('12 : ');
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
dbms_output.put_line('13 : ');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml; charset=utf-8');
    utl_http.set_header(http_req, 'Content-Length', LENGTH(CONVERT(env, 'UTF8')));
    utl_http.set_header(http_req, 'SOAPAction', action);

dbms_output.put_line('14 : ');
    utl_http.write_text(http_req, env);
    BEGIN

dbms_output.put_line('15 : ');
     http_resp := utl_http.get_response(http_req);
     log_at(http_resp.status_code||':'||http_resp.reason_phrase);

dbms_output.put_line('16 : ');
     DBMS_LOB.createtemporary(l_clob, FALSE);

dbms_output.put_line('17 : ');
        BEGIN
            LOOP
              UTL_HTTP.read_text(http_resp, env, 32767);
              DBMS_LOB.writeappend (l_clob, LENGTH(env), env);
              ln_index:=ln_index + 32767;
            END LOOP;
        EXCEPTION
        WHEN UTL_HTTP.end_of_body THEN
          UTL_HTTP.end_response(http_resp);
        END;
dbms_output.put_line('18 : ');

    EXCEPTION
     WHEN utl_http.request_failed THEN
      dbms_output.put_line('Request Failed: ' || utl_http.get_detailed_sqlerrm);
      log_at(sqlerrm);
     WHEN utl_http.http_server_error THEN
      dbms_output.put_line('Server Error: ' || utl_http.get_detailed_sqlerrm);
      log_at(sqlerrm);
     WHEN utl_http.http_client_error THEN
      dbms_output.put_line('Client Error: ' || utl_http.get_detailed_sqlerrm);
      log_at(sqlerrm);
     WHEN utl_http.end_of_body THEN
      utl_http.end_response(http_resp);
      log_at(sqlerrm);
     WHEN OTHERS THEN
      utl_http.end_response(http_resp);
      log_at(sqlerrm);
    END;

    resp.doc := xmltype.createxml(l_clob);

    resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');

    check_fault(resp);

    DBMS_LOB.freetemporary(l_clob);

    RETURN resp;
  END;

-- BOM AdiletK Kompanion Sponsorship

    /*******************************************************************************
        Name        :invoke_utf8_v11_card
        Prepared By :Adilet Kachkeev
        Date:       23.11.2016
        Base Project :  New call to web service from Card Operations Dep
        Purpose     :  to make web service call to Card Operation's server
    *******************************************************************************/
  FUNCTION invoke_utf8_v11_card(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response AS
    env       VARCHAR2(32767);
    http_req  utl_http.req;
    http_resp utl_http.resp;
    resp      response;
    PTEST VARCHAR2(2000);
    ls_buffer varchar2(4000);
    ln_cnt number := 0;
    ls_header_method VARCHAR2(256);
    ls_header_user VARCHAR2(256);
    ls_header_pass VARCHAR2(256);
    
  BEGIN
    utl_http.set_proxy(null, '192.168.111.222,192.168.111.3'); --chyngyzo 09.12.2016 setting proxy to null
    --bom nurzalata header setting 18092018
    if instr(action, 'banksoft') > 0 then
        pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
        pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
        ls_header_method := 'UserCredentials';
        if instr(action, 'KirgizDemirWS') > 0 /*or instr(action, 'GetCreditCardTransactions') > 0 or instr(action, 'GetStatementDetails') > 0*/ or instr(action, 'GetCreditCardInfo') > 0 then
            PKG_SOAP.NEW_HEADER(req, ls_header_method,
            '<BankCode>' || ls_header_user || '</BankCode>' ||
            '<password>' || ls_header_pass || '</password>');
        end if;
        generate_envelope_card(req, env);
    else
        generate_envelope(req, env);
    end if;
    utl_http.Get_body_charset(PTEST);
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml;charset=utf-8');
    utl_http.set_header(http_req, 'Content-Length', length(convert(env,'UTF8')));
    utl_http.set_header(http_req, 'SOAPAction', action);
    utl_http.write_text(http_req, env);
    http_resp := utl_http.get_response(http_req);
    utl_http.read_text(http_resp, env); 
    utl_http.end_response(http_resp);
    resp.doc := xmltype.createxml(substr(env, 1, 32767));--4000 NurzalatA CQ5895
    resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');
    check_fault(resp);
    RETURN resp;
  EXCEPTION
        WHEN OTHERS THEN
            log_at('pkg_soap.error', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            return resp;

  END;
  /*******************************************************************************
        Name        : invoke_utf8_v11_auto_credit
        Prepared By : Askhat Serikov
        Date        : 09.10.2017
        Base Project : CQ5453 New call to web service from Card Operations Dep
        Purpose     : to make web service call to Card Operation's server.create xml from CLOB
    *******************************************************************************/  
  FUNCTION invoke_utf8_v11_auto_credit(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response AS
    env       VARCHAR2(32767);
    http_req  utl_http.req;
    http_resp utl_http.resp;
    resp      response;
    PTEST VARCHAR2(2000);
    ls_buffer varchar2(4000);
    ln_cnt number := 0;
  BEGIN

    generate_envelope_auto_credit(req, env);
    log_at('test_env', substr(env, 1, 2000), substr(env, 2000, 2000), substr(env, 4000, 2000));
    utl_http.Get_body_charset(PTEST);
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml;charset=utf-8');

    utl_http.set_header(http_req, 'Content-Length', length(convert(env,'UTF8')));
    utl_http.set_header(http_req, 'SOAPAction', action);
    utl_http.write_text(http_req, env);
    http_resp := utl_http.get_response(http_req);
    
    utl_http.read_text(http_resp, env);
    utl_http.end_response(http_resp);
    log_at('pkg_soap1', substr(env, 1, 1500));
    dbms_output.put_line('11 : '||substr(env, 1, 4000));
    --log_at('123', length(env),'','');
    resp.doc := xmltype.createxml(substr(env, 1, 32767)); --4000
    resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');

    check_fault(resp);
    RETURN resp;
    EXCEPTION
        WHEN OTHERS THEN
            log_at('pkg_soap.error', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            return resp;

  END;
  

    /*******************************************************************************
        Name            :invoke_utf8_v11_card_clob
        Prepared By     :NursultanSa
        Date:           :18.07.2022
        Base Project    :CBS-415
        Purpose         :Web service from Card Operations Dep, answer more than 32767 bytes
    *******************************************************************************/  
  FUNCTION invoke_utf8_v11_card_clob(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response AS
    env       VARCHAR2(32767);
    http_req  utl_http.req;
    http_resp utl_http.resp;
    resp      response;
    PTEST VARCHAR2(2000);
    ls_buffer varchar2(4000);
    ln_cnt number := 0;
    ls_header_method VARCHAR2(256);
    ls_header_user VARCHAR2(256);
    ls_header_pass VARCHAR2(256);
    
    l_clob      clob;    
  BEGIN
    utl_http.set_proxy(null, '192.168.111.222,192.168.111.3'); 

    if instr(action, 'banksoft') > 0 then
        pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
        pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
        ls_header_method := 'UserCredentials';
        if instr(action, 'KirgizDemirWS') > 0 or instr(action, 'GetCreditCardInfo') > 0 then
            PKG_SOAP.NEW_HEADER(req, ls_header_method,
            '<BankCode>' || ls_header_user || '</BankCode>' ||
            '<password>' || ls_header_pass || '</password>');
        end if;
        generate_envelope_card(req, env);
    else
        generate_envelope(req, env);
    end if;
    utl_http.Get_body_charset(PTEST);
    http_req := utl_http.begin_request(url, 'POST','HTTP/1.1');
    utl_http.set_header(http_req, 'Content-Type', 'text/xml;charset=utf-8');
    utl_http.set_header(http_req, 'Content-Length', length(convert(env,'UTF8')));
    utl_http.set_header(http_req, 'SOAPAction', action);
    utl_http.write_text(http_req, env);
    http_resp := utl_http.get_response(http_req);
    
    DBMS_LOB.createtemporary(l_clob, FALSE);
    BEGIN
        LOOP
          utl_http.read_text(http_resp, env, 32000);
          DBMS_LOB.writeappend(l_clob, LENGTH(env), env);
        END LOOP;
    EXCEPTION
        WHEN others THEN
            utl_http.end_response(http_resp);
    END;  
    
    resp.doc := xmltype.createxml(l_clob);
    resp.doc := resp.doc.extract('/soap:Envelope/soap:Body/child::node()', 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');
    check_fault(resp);
    RETURN resp;
  EXCEPTION
        WHEN OTHERS THEN
            log_at('pkg_soap.error', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            return resp;

  END;
END;
/

