create PACKAGE BODY     pkg_masraf_tx33200  IS

p_33200_FC_MSRF_DOVIZ_KODU        NUMBER;
p_33200_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_33200_KUR						  NUMBER;
p_33200_REFERENCE				  NUMBER;
p_33200_ISTA_KOD				  NUMBER;
p_33200_MUS_ACIK				  NUMBER;
p_33200_BANKA_ACIK				  NUMBER;
p_33200_ISLEM_SUBE				  NUMBER;
p_33200_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_33200_FC_MASRAF_TUTARI		  NUMBER;
p_33200_LC_MASRAF_TUTAR			  NUMBER;
p_33200_MASRAF_HESAP_SUBE		  NUMBER;
p_33200_MASRAF_HESAP_NO			  NUMBER;
p_33200_LC_MAIL_CHARGE			  NUMBER;
p_33200_LC_COMM_CHARGE			  NUMBER;
p_33200_LC_CONF_COM				  NUMBER;
p_33200_LC_ADVICE_COM			  NUMBER;
p_33200_LC_PREADVS_COM			  NUMBER;
p_33200_MAIL_CHARGE_GL			  NUMBER;
p_33200_COMM_CHARGE_GL			  NUMBER;
p_33200_CONF_COM_GL				  NUMBER;
p_33200_ADVICE_COM_GL			  NUMBER;
p_33200_PREADVS_COM_GL			  NUMBER;
p_33200_UNCOMFIRM				  NUMBER;
p_33200_COMFIRM					  NUMBER;
p_33200_FC						  NUMBER;
p_33200_LC						  NUMBER;
p_33200_MAILCOM_VAR				  NUMBER;
p_33200_COMMCOM_VAR				  NUMBER;
p_33200_CONFCOM_VAR				  NUMBER;
p_33200_ADVICECOM_VAR			  NUMBER;
p_33200_PREADVS_VAR				  NUMBER;
p_33200_FC_MASRAF_ANA			  NUMBER;
p_33200_LC_MASRAF_ANA			  NUMBER;
p_33200_MAILCOM_EXP				  NUMBER;
p_33200_COMMCOM_EXP				  NUMBER;
p_33200_CONFCOM_EXP				  NUMBER;
p_33200_ADVICECOM_EXP			  NUMBER;
p_33200_PREADVS_EXP				  NUMBER;

p_33200_LC_SERVICE_TAX			  NUMBER;
p_33200_FC_SERVICE_TAX			  NUMBER;
p_33200_SERVICE_TAX_VAR			  NUMBER;
p_33200_SERVICE_TAX_GL			  NUMBER;

/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
     pkg_masraf.onay_sonrasi(pn_islem_no, ps_ref, 0, 'A', 'EXPCONFCOM');
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   pkg_masraf.Reddetme_Sonrasi(pn_islem_no, ps_ref);
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is		-- Islem iptal edilemez
  begin
    pkg_masraf.Iptal_Onay_Sonrasi_grs_guncel(pn_islem_no, ps_ref, 0);
  end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number, pn_fis_no in out number) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   ls_tahsil_doviz        varchar2(3);
   ls_hesap_doviz         varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_eski_tahsil_tutar	  number;
   ln_tahsil_tutar		  number;
   ls_istatistik_kodu     VARCHAR2(2000);
   ln_dk_grup_no number;
   ls_aciklama			  VARCHAR2(2000);
   ln_tax_rate            NUMBER;
   ln_tax_amount          NUMBER;
   lb_vergi_var           boolean;

   cursor cur_masraf is
    select *
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID'
	 order by sira_no
	for update;
	row_masraf cur_masraf%rowtype;

    cursor c_0 is
    select count(*)
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID';
	 ln_temp number;

   cursor cur_akr is
     select * from cbs_akreditif_islem
	  where tx_no = pn_islem_no;
	 row_akr cur_akr%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no --referans = ls_referans
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;

  Begin
    ln_fis_no := pn_fis_no;
	open c_0;
	fetch c_0 into ln_temp;
	close c_0;
	if ln_temp <= 0 then
	  return;
	end if;

	open cur_akr;
	fetch cur_akr into row_akr;
	 ls_akr_doviz := row_akr.doviz_kodu;  --ls_islem_d?viz yerine ge?ecek
	 varchar_list(p_33200_MASRAF_HESAP_NO) := row_akr.masraf_hesap_no;
     varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_akr.masraf_hesap_no);
	 ls_hesap_doviz:=Pkg_Hesap.HesaptanDovizKoduAl(row_akr.masraf_hesap_no);
     varchar_list(p_33200_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_akr.masraf_hesap_no);
	 ls_referans := row_akr.referans;
 	 varchar_list(p_33200_ISLEM_SUBE) := row_akr.bolum_kodu;


	 IF row_akr.teyit_kodu='TEYITLI' THEN
		boolean_list(p_33200_UNCOMFIRM) := FALSE ;
		boolean_list(p_33200_COMFIRM)	:= TRUE ;
	 ELSE
		boolean_list(p_33200_UNCOMFIRM) := TRUE ;
		boolean_list(p_33200_COMFIRM)	:= FALSE ;
	 END IF;

	close cur_akr;

	    boolean_list(p_33200_MAILCOM_VAR) := FALSE ;
		boolean_list(p_33200_COMMCOM_VAR) := FALSE ;
		boolean_list(p_33200_CONFCOM_VAR) := FALSE ;
		boolean_list(p_33200_PREADVS_VAR) := FALSE;
		boolean_list(p_33200_ADVICECOM_VAR) := FALSE ;
		boolean_list(p_33200_FC_MASRAF_ANA) := FALSE ;
		boolean_list(p_33200_LC_MASRAF_ANA) := FALSE ;
        boolean_list(p_33200_SERVICE_TAX_VAR) := FALSE;


		IF  row_akr.masraf_hesap_no IS NOT NULL THEN
	       ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33200_MASRAF_HESAP_NO)) );
		   varchar_list(p_33200_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPMAILCHR');
		   varchar_list(p_33200_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCOMCAT');
		   varchar_list(p_33200_CONF_COM_GL)	:=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCONFCOM');
		   varchar_list(p_33200_ADVICE_COM_GL)  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPADVCOM');
		   varchar_list(p_33200_PREADVS_COM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPPREADVS');
           varchar_list(p_33200_SERVICE_TAX_GL) := '';
		   if pkg_musteri.musteri_vergiden_muafmi(row_akr.lehdar_musteri_no) = 'H' then -- Lehdar m?steri no dogru mu?????
		     lb_vergi_var := TRUE;
		   end if;
    	ELSE
		   varchar_list(p_33200_MAIL_CHARGE_GL) := '';
		   varchar_list(p_33200_COMM_CHARGE_GL) := '';
		   varchar_list(p_33200_CONF_COM_GL)	:= '';
		   varchar_list(p_33200_ADVICE_COM_GL)  := '';
		   varchar_list(p_33200_PREADVS_COM_GL) := '';
           varchar_list(p_33200_SERVICE_TAX_GL) := '';
	    END IF;

     	   varchar_list(p_33200_REFERENCE) := ls_referans;
	       varchar_list(p_33200_ISTA_KOD)  := ls_istatistik_kodu;

		IF varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		   boolean_list(p_33200_LC_MSRF_DOVIZ_KODU) := FALSE;
		   boolean_list(p_33200_FC_MSRF_DOVIZ_KODU) := TRUE ;
		ELSE
		   boolean_list(p_33200_LC_MSRF_DOVIZ_KODU) := TRUE;
		   boolean_list(p_33200_FC_MSRF_DOVIZ_KODU) := FALSE;
		END IF;

		number_list(p_33200_LC_COMM_CHARGE) := 0;
		number_list(p_33200_LC_MAIL_CHARGE) := 0;
		number_list(p_33200_LC_CONF_COM)    := 0;
		number_list(p_33200_LC_ADVICE_COM)  := 0;
		number_list(p_33200_LC_MASRAF_TUTAR):= 0;
		number_list(p_33200_FC_MASRAF_TUTARI) := 0;
        number_list(p_33200_LC_SERVICE_TAX)   := 0;
        number_list(p_33200_FC_SERVICE_TAX)   := 0;
		varchar_list(p_33200_MAILCOM_EXP)	:='';
		varchar_list(p_33200_COMMCOM_EXP)	:='';
	    varchar_list(p_33200_CONFCOM_EXP)	:='';
	    varchar_list(p_33200_ADVICECOM_EXP) :='';
		varchar_list(p_33200_PREADVS_EXP)   :='';


		IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
		  boolean_list(p_33200_LC) := TRUE;
	      boolean_list(p_33200_FC) := FALSE;
		ELSE
		  boolean_list(p_33200_LC) := FALSE;
	      boolean_list(p_33200_FC) := TRUE;
		END IF;
		ls_aciklama := 'EXPORT L/C OPENING  ' ;
		varchar_list(p_33200_BANKA_ACIK) := ls_aciklama;
		varchar_list(p_33200_MUS_ACIK) :=varchar_list(p_33200_BANKA_ACIK) ;

		IF  varchar_list(p_33200_MASRAF_HESAP_NO) IS NOT NULL THEN  --masraf hesab? girilmi?se
--            IF varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU) =pkg_genel.lc_al then
--			   number_list(p_33200_KUR) := Pkg_Komisyon_Kur.KUR_to_lc(varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU),1);
--			else
        	   number_list(p_33200_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU),1);
--			end if;
		     --masraf alinacak hesabin bakiyesini al
		     ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33200_MASRAF_HESAP_NO));
        END IF;



	open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  ls_tahsil_doviz:=row_masraf.DVZ;

	  IF nvl(row_masraf.tahsil_edilemeyen,0) > 0  THEN

		   IF pkg_ihracat.masraf_kontrol_yap(row_masraf.ODEYECEK) = 'Y'  THEN
	         ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);

			 IF row_masraf.masraf_kodu = 'EXPCOMCAT'  THEN  --haberle?me
			     boolean_list(p_33200_COMMCOM_VAR) := TRUE ;
--			   IF boolean_list(p_33200_LC_MSRF_DOVIZ_KODU) THEN
--            	  number_list(p_33200_LC_COMM_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--               ELSE
				  number_list(p_33200_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--			   END IF;
				 ln_borc_tutar := number_list(p_33200_LC_COMM_CHARGE);--number_list(p_33200_HABR_MDV);
				 ln_borc_trl := number_list(p_33200_LC_COMM_CHARGE);
			     varchar_list(p_33200_COMMCOM_EXP) := 'EXPCOMCAT '||row_akr.referans||' Export Communication Charge' ;

			  ELSIF row_masraf.masraf_kodu = 'EXPMAILCHR' THEN   --posta

				  boolean_list(p_33200_MAILCOM_VAR) := TRUE ;
--				  IF boolean_list(p_33200_LC_MSRF_DOVIZ_KODU) THEN
--            	     number_list(p_33200_LC_MAIL_CHARGE)  := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--                  ELSE
				     number_list(p_33200_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  ln_borc_tutar := number_list(p_33200_LC_MAIL_CHARGE);--number_list(p_33200_POSTA_MDV);
				  ln_borc_trl := number_list(p_33200_LC_MAIL_CHARGE);
				  varchar_list(p_33200_MAILCOM_EXP)	:='EXPMAILCHR '||row_akr.referans||' Export Mail Charge';

			  ELSIF  row_masraf.masraf_kodu = 'EXPADVCOM' THEN   --Advise

			      boolean_list(p_33200_ADVICECOM_VAR) := TRUE ;
--			   	  IF boolean_list(p_33200_LC_MSRF_DOVIZ_KODU) THEN
--            	     number_list(p_33200_LC_ADVICE_COM)  := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--                  ELSE
 				     number_list(p_33200_LC_ADVICE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  ln_borc_tutar := number_list(p_33200_LC_ADVICE_COM);--number_list(p_33200_POSTA_MDV);
				  ln_borc_trl := number_list(p_33200_LC_ADVICE_COM);
			      varchar_list(p_33200_ADVICECOM_EXP)	:='EXPADVCOM '||row_akr.referans||' Advising Commission';

			  ELSIF  row_masraf.masraf_kodu = 'EXPPREADVS' THEN   --Advise

			      boolean_list(p_33200_PREADVS_VAR) := TRUE ;
--			   	  IF boolean_list(p_33200_LC_MSRF_DOVIZ_KODU) THEN
--            	     number_list(p_33200_LC_PREADVS_COM)  := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--                  ELSE
				     number_list(p_33200_LC_PREADVS_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  ln_borc_tutar := number_list(p_33200_LC_PREADVS_COM);--number_list(p_33200_POSTA_MDV);
				  ln_borc_trl := number_list(p_33200_LC_PREADVS_COM);
			      varchar_list(p_33200_PREADVS_EXP)	:='EXPPREADVS '||row_akr.referans||' Export Pre-Advising Commission';



			  ELSIF row_masraf.masraf_kodu =  'EXPCONFCOM' then  --Confirmation taksitli OLUR
			       boolean_list(p_33200_CONFCOM_VAR) := TRUE ;
			       ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
				   IF nvl(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
					   --daha fazlas? veya ayn?s? ?nceden al?nm??
					   --hi? bir ?ey yapma
					   ln_tahsil_tutar := 0;
				   ELSE

					 		  lb_taksit_var := true;
							  open cur_taksitler;
							  loop
							    fetch cur_taksitler into row_taksit;
								exit when cur_taksitler%notfound;

									ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
--									IF boolean_list(p_33200_LC_MSRF_DOVIZ_KODU) THEN
--									   number_list(p_33200_LC_CONF_COM)   := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--                                    ELSE
                                       number_list(p_33200_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--						            END IF;
		 				            ln_borc_tutar := number_list(p_33200_LC_CONF_COM);--number_list(p_33200_TEYIT_MDV);
								    ln_borc_trl := number_list(p_33200_LC_CONF_COM);
		                            varchar_list(p_33200_CONFCOM_EXP)	:='EXPCONFCOM '||row_akr.referans||' Export L/C Confirmation Commission';


								if ln_son_bakiye >= ln_borc_tutar then
								   boolean_list(p_33200_COMMCOM_VAR)  := FALSE ;
							       boolean_list(p_33200_MAILCOM_VAR)  := FALSE ;
							       boolean_list(p_33200_ADVICECOM_VAR):= FALSE ;
								   boolean_list(p_33200_PREADVS_VAR)  := FALSE;
						           ln_fis_no:=pkg_muhasebe.fis_kes ( 33200, null, pn_islem_no, varchar_list, number_list,
												    			  	  date_list, boolean_list, null, false, ln_fis_no, null);
					     		     update cbs_masraf_ith_ihr_isl
									   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
									       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
								     where current of cur_masraf;

		  					  		pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
		                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

									    update cbs_masraf_taksit_islem
										set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
										       odenen_tutar = taksit_tutari
										where current of cur_taksitler;

										if nvl(row_akr.masraf_zamani,'A') = 'A' then
	      						           pkg_masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_33200_LC_CONF_COM), row_akr.masraf_hesap_no,
																   row_akr.akreditif_vade, 'E');
							            end if;
									ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
									number_list(p_33200_LC_MASRAF_TUTAR) := number_list(p_33200_LC_MASRAF_TUTAR) + ln_borc_trl;
							        number_list(p_33200_FC_MASRAF_TUTARI) := number_list(p_33200_FC_MASRAF_TUTARI) + ln_borc_tutar;
								END IF;
					  END LOOP;
					  CLOSE cur_taksitler;
				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
			  ELSE
			    CLOSE cur_masraf;
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '341' ||  pkg_hata.getDelimiter || row_masraf.masraf_kodu || pkg_hata.getUCPOINTER);
			  end if;
			  if not lb_taksit_var then
			   if ln_son_bakiye >= ln_borc_tutar then --bakiye yeterliyse satiri ekle
			     if ln_tahsil_tutar <> 0 then
			         ln_fis_no:=pkg_muhasebe.fis_kes ( 33200, null, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  null, false, ln_fis_no, null);

					  IF boolean_list(p_33200_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33200_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33200_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33200_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33200_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33200_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33200_ADVICECOM_VAR) = TRUE THEN
					  	 boolean_list(p_33200_ADVICECOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33200_PREADVS_VAR) = TRUE THEN
						 boolean_list(p_33200_PREADVS_VAR) := FALSE;
					  END IF;

					  pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      update cbs_masraf_ith_ihr_isl
					     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       where current of cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
					  number_list(p_33200_LC_MASRAF_TUTAR) := number_list(p_33200_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33200_FC_MASRAF_TUTARI) := number_list(p_33200_FC_MASRAF_TUTARI) + ln_borc_tutar;
				end if;
			   end if;
			  end if;
 	      end if; --ihracat?? ?demesi
	  end if;  --tahsil edilmeyen var....

	end loop;
	close cur_masraf;
	boolean_list(p_33200_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33200_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33200_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33200_ADVICECOM_VAR) := FALSE ;
	boolean_list(p_33200_PREADVS_VAR) := FALSE;

    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_tax_rate);
	ln_tax_amount := (nvl(number_list(p_33200_LC_COMM_CHARGE),0) + nvl(number_list(p_33200_LC_MAIL_CHARGE),0)) * ln_tax_rate / 100;
	if lb_vergi_var and ln_tax_amount != 0 then
	  number_list(p_33200_LC_SERVICE_TAX)   := ln_tax_amount;
      number_list(p_33200_FC_SERVICE_TAX)   := ln_tax_amount/Pkg_Kur.MB_dak_to_lc(varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU),1);
	  boolean_list(p_33200_SERVICE_TAX_VAR) := TRUE;
	else
	  boolean_list(p_33200_SERVICE_TAX_VAR) := FALSE;
	end if;

	IF number_list(p_33200_FC_MASRAF_TUTARI) > 0 THEN
	   number_list(p_33200_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33200_LC_MASRAF_TUTAR)) ;
	   number_list(p_33200_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33200_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33200_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33200_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33200_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33200_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33200_LC_MASRAF_ANA) := TRUE ;

		END IF;
	       ln_fis_no:=pkg_muhasebe.fis_kes ( 33200,
		    			 	              	  null,
			     						  	  pn_islem_no,
				    					  	  varchar_list ,
					    				  	  number_list  ,
						    			  	  date_list    ,
							    		  	  boolean_list ,
								    	  	  null,
									     	  false,
									  	      ln_fis_no,
									  	      null);
	END IF;
	pn_fis_no := ln_fis_no;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
     null;
   end;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebe_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
    pkg_masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, null);
  End;
/*------------------------------------------------------------------------------------------------------*/
 Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2 is
 ln_temp number;
 begin
   select count(*)
     into ln_temp
	 from cbs_masraf_ith_ihr_isl
	where islem_no = pn_islem_no
	  and odeyecek = 'EXPORTER'
	  and nvl(durum,'VALID') = 'VALID';
   if ln_temp > 0 then
     return 'E';
   else
     return 'H';
   end if;
 end;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN
    p_33200_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('33200_FC_MSRF_DOVIZ_KODU');
	p_33200_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('33200_LC_MSRF_DOVIZ_KODU');
	p_33200_KUR						  := Pkg_Muhasebe.parametre_index_bul('33200_KUR');
	p_33200_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('33200_REFERENCE');
	p_33200_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('33200_ISTA_KOD');
	p_33200_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33200_MUS_ACIK');
	p_33200_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33200_BANKA_ACIK');
	p_33200_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('33200_ISLEM_SUBE');
	p_33200_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('33200_MASRAF_HESAP_DOVIZ_KODU');
	p_33200_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('33200_FC_MASRAF_TUTARI');
	p_33200_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('33200_LC_MASRAF_TUTAR');
	p_33200_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('33200_MASRAF_HESAP_SUBE');
	p_33200_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('33200_MASRAF_HESAP_NO');
	p_33200_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33200_LC_MAIL_CHARGE');
	p_33200_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33200_LC_COMM_CHARGE');
	p_33200_LC_CONF_COM				  := Pkg_Muhasebe.parametre_index_bul('33200_LC_CONF_COM');
	p_33200_LC_ADVICE_COM			  := Pkg_Muhasebe.parametre_index_bul('33200_LC_ADVICE_COM');
	p_33200_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33200_MAIL_CHARGE_GL');
	p_33200_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33200_COMM_CHARGE_GL');
	p_33200_CONF_COM_GL				  := Pkg_Muhasebe.parametre_index_bul('33200_CONF_COM_GL');
	p_33200_ADVICE_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33200_ADVICE_COM_GL');
	p_33200_UNCOMFIRM				  := Pkg_Muhasebe.parametre_index_bul('33200_UNCOMFIRM');
	p_33200_COMFIRM					  := Pkg_Muhasebe.parametre_index_bul('33200_COMFIRM');
	p_33200_FC						  := Pkg_Muhasebe.parametre_index_bul('33200_FC');
	p_33200_LC						  := Pkg_Muhasebe.parametre_index_bul('33200_LC');
	p_33200_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33200_MAILCOM_VAR');
	p_33200_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33200_COMMCOM_VAR');
	p_33200_CONFCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33200_CONFCOM_VAR');
	p_33200_ADVICECOM_VAR			  := Pkg_Muhasebe.parametre_index_bul('33200_ADVICECOM_VAR');
	p_33200_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33200_FC_MASRAF_ANA');
	p_33200_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33200_LC_MASRAF_ANA');
	p_33200_MAILCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33200_MAILCOM_EXP');
	p_33200_COMMCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33200_COMMCOM_EXP');
	p_33200_CONFCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33200_CONFCOM_EXP');
	p_33200_PREADVS_EXP				  := Pkg_Muhasebe.parametre_index_bul('33200_PREADVS_EXP');
	p_33200_ADVICECOM_EXP			  := Pkg_Muhasebe.parametre_index_bul('33200_ADVICECOM_EXP');
	p_33200_PREADVS_VAR				  := Pkg_Muhasebe.parametre_index_bul('33200_PREADVS_VAR');
	p_33200_LC_PREADVS_COM			  := Pkg_Muhasebe.parametre_index_bul('33200_LC_PREADVS_COM');
	p_33200_PREADVS_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33200_PREADVS_COM_GL');
	p_33200_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33200_LC_SERVICE_TAX');
	p_33200_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33200_FC_SERVICE_TAX');
	p_33200_SERVICE_TAX_VAR			  := Pkg_Muhasebe.parametre_index_bul('33200_SERVICE_TAX_VAR');
	p_33200_SERVICE_TAX_GL			  := Pkg_Muhasebe.parametre_index_bul('33200_SERVICE_TAX_GL');

 END;
/

