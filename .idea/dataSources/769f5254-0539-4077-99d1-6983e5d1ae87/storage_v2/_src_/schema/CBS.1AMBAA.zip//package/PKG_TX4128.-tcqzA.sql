create PACKAGE PKG_TX4128 IS

  /******************************************************************************
   Name       : PKG_TX4128
   Created By : Bilal GUL
   Date	   	  : 19/04/2004
   Purpose	  : LEHIMIZE VERILEN TM KOMISYON ODEMESI
  ******************************************************************************/

  --TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrili

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Function masraf_kontrol_yap(ps_odeyecek varchar2) return varchar2;

  Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2;

  Procedure TM_LehVer_BilgiAktar(pn_txno number,ps_refno varchar2);

  procedure geri_kopyala(pn_islem_no number, ps_ref varchar2);

  Procedure  Guncelleme_Kontrolu(pn_islem_no NUMBER,
  			 					ps_block	 VARCHAR2,
								ps_rowid   	 VARCHAR2,
		  				   		ps_column  	 VARCHAR2,
  		   				   		pd_column  	 VARCHAR2,
								ps_oldvalue IN OUT VARCHAR2);

  Function TM_LEHVER_BAKIYE_AL(PS_REFERANS varchar2) RETURN NUMBER;

  Procedure TM_LehVer_Bilgisi_Al(ps_REFERANS CBS_TM_LEHIMIZE_VERILEN.REFERANS%type,
                               ps_MEK_VEREN_BANKA out CBS_TM_LEHIMIZE_VERILEN.MEK_VEREN_BANKA%type,
							   ps_BANKA_KODU out CBS_TM_LEHIMIZE_VERILEN.BANKA_KODU%type,
							   ps_SUBE_KODU out CBS_TM_LEHIMIZE_VERILEN.SUBE_KODU%type,
							   ps_DUZENLEME_TARIHI out CBS_TM_LEHIMIZE_VERILEN.DUZENLEME_TARIHI%type,
							   ps_KARSI_BANKA_REFERANSI out CBS_TM_LEHIMIZE_VERILEN.KARSI_BANKA_REFERANSI%type,
							   ps_DOVIZ_KODU out CBS_TM_LEHIMIZE_VERILEN.DOVIZ_KODU%type,
							   ps_TUTAR out CBS_TM_LEHIMIZE_VERILEN.TUTAR%type,
							   ps_SURESIZ out CBS_TM_LEHIMIZE_VERILEN.SURESIZ%type,
							   ps_VADE_TARIHI out CBS_TM_LEHIMIZE_VERILEN.VADE_TARIHI%type,
							   ps_MUHATAP_MUSTERI_NO out CBS_TM_LEHIMIZE_VERILEN.MUHATAP_MUSTERI_NO%type,
							   ps_MUHATAP_UNVANI out CBS_TM_LEHIMIZE_VERILEN.MUHATAP_UNVANI%type,
							   ps_KONU out CBS_TM_LEHIMIZE_VERILEN.KONU%type,
							   ps_MEKTUP_TIPI CBS_TM_LEHIMIZE_VERILEN.MEKTUP_TIPI%type,
							   ps_BSMV out CBS_TM_LEHIMIZE_VERILEN.BSMV%type,
							   ps_BAKIYE out CBS_TM_LEHIMIZE_VERILEN.BAKIYE%type,
							   ps_ACIKLAMA out CBS_TM_LEHIMIZE_VERILEN.ACIKLAMA%type,
							   ps_MASRAF_HESAP_NO out CBS_TM_LEHIMIZE_VERILEN.MASRAF_HESAP_NO%type,
							   ps_DONEM_BAS_SON out CBS_TM_LEHIMIZE_VERILEN.DONEM_BAS_SON%type,
							   ps_ODEME_DOVIZ_KODU out CBS_TM_LEHIMIZE_VERILEN.ODEME_DOVIZ_KODU%type,
							   ps_KOM_ODEME_SEKLI out CBS_TM_LEHIMIZE_VERILEN.KOM_ODEME_SEKLI%type
							   );

  FUNCTION TxGonderReferansAl(pn_tx_no number) return varchar2;

  Procedure MasrafAktar(pn_txno number,ps_refno varchar2);

   Procedure Masraf_Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2,pn_odeme_tutari number);

END;


/

