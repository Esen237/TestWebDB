create PACKAGE BODY     Pkg_Int_INFO IS

/**************************************************************************************/
FUNCTION MakeSubscription(  pn_customername IN VARCHAR2,
                             ps_customeremail IN VARCHAR2,
                            ps_subscribecd     IN VARCHAR2,
                            ps_subscribeperiod     IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_returncode VARCHAR2(3):='000';
     ln_date date;
     ln_count number;
     SubscribeException EXCEPTION;

BEGIN
open pc_ref for select '-' from dual;
    SELECT COUNT(*)
    INTO ln_count
    FROM CBS_SUBSCRIPTION
    WHERE SUBSCRIBE_CD=ps_subscribecd
    AND CUSTOMER_EMAIL=ps_customeremail
    AND STATUS_CD='sENABLE';

    if(ln_count!=0) then
    raise SubscribeException;
    end if;

    if(ps_subscribeperiod='DAILY') then
        ln_date:=sysdate+1;
    elsif(ps_subscribeperiod='WEEKLY') then
        ln_date:=sysdate+7;
    elsif(ps_subscribeperiod='MONTHLY') then
        ln_date:=sysdate+30;
    elsif(ps_subscribeperiod='ANNUAL') then
        ln_date:=sysdate+365;
    end if;
  log_at('test',ps_subscribecd,pn_customername,ps_subscribeperiod);


  INSERT INTO CBS_SUBSCRIPTION
  (SUBSCRIBE_CD, CUSTOMER_NAME, CUSTOMER_EMAIL,
  SUBSCRIBE_DATE, STATUS_CD, NEXTRUN_DATE, SUBSCRIBE_PERIOD)

   VALUES
   (ps_subscribecd,pn_customername,ps_customeremail,
   SYSDATE,'sENABLE',ln_date,ps_subscribeperiod);


   RETURN ls_returncode;

EXCEPTION
         WHEN SubscribeException THEN
               ls_returncode:='444';
               RETURN ls_returncode;

END;
-------------------------------------------------------------------------------------------------
FUNCTION ConvertCurrency(ps_FromCurr IN VARCHAR2,
                             pn_ToCurr IN VARCHAR2,
                             pn_Amount IN VARCHAR2,
                            ps_BankNBType     IN VARCHAR2,
                            ps_BuySellType     IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_returncode VARCHAR2(3):='000';

     ln_amount NUMBER ;
     ln_fromaount      number;

 BEGIN

   ln_fromaount:=to_number(pn_Amount);
   ln_amount := Pkg_Kur.doviz_doviz_karsilik(ps_FromCurr,pn_ToCurr,NULL,ln_fromaount,1,NULL,NULL,ps_BankNBType,ps_BuySellType);

    OPEN pc_ref FOR
         SELECT ln_amount FROM dual;

    RETURN ls_returncode;

EXCEPTION
         WHEN OTHERS THEN
               Log_At(SQLERRM);
               RETURN '444';

END;
-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------

END;
/

