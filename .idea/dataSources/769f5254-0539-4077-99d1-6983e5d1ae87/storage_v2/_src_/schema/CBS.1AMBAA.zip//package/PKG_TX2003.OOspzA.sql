create PACKAGE     PKG_TX2003 is

  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54
  -- Purpose : Vadeli Hesap A??l??lar?n?nda kullan?lacakt?r.

  Procedure Yaratma_Oncesi(pn_islem_no number); 		-- Islem giris kontrolden once cagrilir
  Procedure Kontrol_Sonrasi(pn_islem_no number); 		-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			-- Islem iptal edildikten sonra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);				-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			-- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);				-- Islem onaylandiktan sonra cagrilir
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);				-- Islem onaylandiktan sonra cagrilir

PROCEDURE vergi_tablo_doldur ;
FUNCTION  Find_Tax_Rate( pn_musteri number, ps_dvz varchar2) RETURN  number;
FUNCTION  Find_Int_Rate(ps_dvz varchar2, pn_gun_say number) RETURN  number;

  Function sf_istatistikkod_zorunlumu_1(pn_by_debiting number, pn_musteri_no number, ps_doviz_kodu varchar2 ) return varchar2;
  Function sf_istatistikkod_zorunlumu_2(pn_hesap_no number) return varchar2;

end;


/

