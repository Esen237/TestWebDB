create PACKAGE BODY pkg_sozlesme
IS
 /***************************************************************************************/
 /*     Procedure sp_sozlesme_modulurunsinif_al                                         */
 /***************************************************************************************/
 Procedure sp_sozlesme_modulurunsinif_al(ps_modul_tur_kod out varchar2,
		  								ps_urun_tur_kod out varchar2,
										ps_urun_sinif_kod out varchar2)
  is
  begin
	 	  ps_modul_tur_kod := 'CUSTOMER';
		  ps_urun_tur_kod := 'GENERAL';
		  ps_urun_sinif_kod := 'CONTRACT';
  end;
 /****************************************************************************************/
 /*     Function sf_sozlesme_no_al                                                       */
 /****************************************************************************************/
 Function sf_sozlesme_no_al(pn_musteri_no number) return number
 is
 ln_sozlesme_no number := 1;
 Begin
	 select max(sozlesme_no) + 1
     into ln_sozlesme_no
	 from cbs_sozlesme
	 where musteri_no = pn_musteri_no ;

 return nvl(ln_sozlesme_no,1);

 Exception
 When others then  	  return 1 ;

 End ;

 /****************************************************************************************/
 /*     Function sf_sozlesme_ekno_al                                                       */
 /****************************************************************************************/
 Function sf_sozlesme_ekno_al(pn_musteri_no number ,pn_sozlesme_no number)return number
 is
  ln_eksozlesme_no number := 1;
 Begin
	 select max(ek_sozlesme_no) + 1
     into ln_eksozlesme_no
	 from cbs_sozlesme
	 where musteri_no = pn_musteri_no and
	 	   sozlesme_no = pn_sozlesme_no;

 return nvl(ln_eksozlesme_no,1);

 Exception
  When others then return ln_eksozlesme_no ;

End ;

 /****************************************************************************************/
 /*  Procedure sp_sozlesme_anatabloya_at                                                    */
 /****************************************************************************************/
  Procedure sp_sozlesme_anatabloya_at(pn_islem_no number)
 is
 Begin

 	  insert into cbs_sozlesme
	  		 	  (Musteri_No, Sozlesme_No, Ek_Sozlesme_No, Modul_Tur_Kod, Urun_Tur_Kod,
	  			   Urun_Sinif_kod, Durum_Kodu, Sozlesme_Tur_Kodu, Sozlesme_Tarihi, Doviz_Kodu,
				   Sozlesme_Tutari, Vergilimi, Damga_Vergisi, Damga_Vergisi_Musteri_Payi,
				   Musteri_Tahsil_Edilecek_Tutar, Dv_Tahsil_Hesap_No, Kefil1_Musteri_No,
				   Kefil2_Musteri_No, Kefil3_Musteri_No, Kefil4_Musteri_No, Kefil5_Musteri_No,
				   Kefil6_Musteri_No, Kefil7_Musteri_No, Kefil8_Musteri_No, Kefil9_Musteri_No,
				   Kefil10_Musteri_No ,kapanis_tarihi,
				   KEFIL1_MUSTERI_AD, KEFIL2_MUSTERI_AD, KEFIL3_MUSTERI_AD, KEFIL4_MUSTERI_AD,
				   KEFIL5_MUSTERI_AD, KEFIL6_MUSTERI_AD, KEFIL7_MUSTERI_AD,
				   KEFIL8_MUSTERI_AD, KEFIL9_MUSTERI_AD, KEFIL10_MUSTERI_AD,
				   sozlesme_amaci,son_fis_numara,bolum_kodu)
	  select  	   Musteri_No, Sozlesme_No, Ek_Sozlesme_No, Modul_Tur_Kod, Urun_Tur_Kod,
	  			   Urun_Sinif_Kod, Durum_Kodu, Sozlesme_Tur_Kodu, Sozlesme_Tarihi, Doviz_Kodu,
				   Sozlesme_Tutari, Vergilimi, Damga_Vergisi, Damga_Vergisi_Musteri_Payi,
				   Musteri_Tahsil_Edilecek_Tutar, Dv_Tahsil_Hesap_No, Kefil1_Musteri_No,
				   Kefil2_Musteri_No, Kefil3_Musteri_No, Kefil4_Musteri_No, Kefil5_Musteri_No,
				   Kefil6_Musteri_No, Kefil7_Musteri_No, Kefil8_Musteri_No, Kefil9_Musteri_No,
				   Kefil10_Musteri_No,kapanis_tarihi,
				   KEFIL1_MUSTERI_AD, KEFIL2_MUSTERI_AD, KEFIL3_MUSTERI_AD, KEFIL4_MUSTERI_AD,
				   KEFIL5_MUSTERI_AD, KEFIL6_MUSTERI_AD, KEFIL7_MUSTERI_AD,
				   KEFIL8_MUSTERI_AD, KEFIL9_MUSTERI_AD, KEFIL10_MUSTERI_AD,
				   sozlesme_amaci,son_fis_numara,bolum_kodu
	  from cbs_sozlesme_islem
	  where tx_no = pn_islem_no;


 End;

 /****************************************************************************************/
 /*     Function Sf_Bitmemis_HesapIslm_VarMi                                                      */
 /****************************************************************************************/
  Function Sf_Bitmemis_HesapIslm_VarMi(pn_musteri_no cbs_musteri.musteri_no%type,
 		  								pn_islem_no cbs_islem.numara%type	) return number
 is

    ln_tx_no   cbs_islem.numara%type  := 0;
	onayda_bekleyen_islem_var 		 exception;
  Begin
	   select  max(tx_no)
	   into    ln_tx_no
	   from   cbs_sozlesme_islem a , cbs_islem b
	   where  a.musteri_no = pn_musteri_no and
	   		  a.tx_no = b.numara and
			  a.tx_no <> pn_islem_no and
			  pkg_tx.ISLEM_BITMIS_MI(b.numara)= 0;

	   if  nvl(ln_tx_no,0) <> 0 then
	   	   raise 	onayda_bekleyen_islem_var;
	   end if;

	   return ln_tx_no ;

    Exception
	  When Others Then
  	   	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '456' ||pkg_hata.getdelimiter|| ln_tx_no  || pkg_hata.getdelimiter ||  pkg_hata.getUCPOINTER);
	End;

 /****************************************************************************************/
 /*   Procedure sp_sozlesmeyi_isleme_at                                                      */
 /****************************************************************************************/
 Procedure sp_sozlesmeyi_isleme_at(pn_islem_no number ,pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number)
 is
 Begin

 	  insert into cbs_sozlesme_islem
	  		 	  ( tx_no,Musteri_No, Sozlesme_No, Ek_Sozlesme_No, Modul_Tur_Kod, Urun_Tur_Kod,
	  			   Urun_Sinif_kod, Durum_Kodu, Sozlesme_Tur_Kodu, Sozlesme_Tarihi, Doviz_Kodu,
				   Sozlesme_Tutari, Vergilimi, Damga_Vergisi, Damga_Vergisi_Musteri_Payi,
				   Musteri_Tahsil_Edilecek_Tutar, Dv_Tahsil_Hesap_No, Kefil1_Musteri_No,
				   Kefil2_Musteri_No, Kefil3_Musteri_No, Kefil4_Musteri_No, Kefil5_Musteri_No,
				   Kefil6_Musteri_No, Kefil7_Musteri_No, Kefil8_Musteri_No, Kefil9_Musteri_No,
				   Kefil10_Musteri_No,kapanis_tarihi,
  				   KEFIL1_MUSTERI_AD, KEFIL2_MUSTERI_AD, KEFIL3_MUSTERI_AD, KEFIL4_MUSTERI_AD,
				   KEFIL5_MUSTERI_AD, KEFIL6_MUSTERI_AD, KEFIL7_MUSTERI_AD,
				   KEFIL8_MUSTERI_AD, KEFIL9_MUSTERI_AD, KEFIL10_MUSTERI_AD,
				   sozlesme_amaci,son_fis_numara,bolum_kodu)
	  select  	   pn_islem_no,Musteri_No, Sozlesme_No, Ek_Sozlesme_No, Modul_Tur_Kod, Urun_Tur_Kod,
	  			   Urun_Sinif_kod, Durum_Kodu, Sozlesme_Tur_Kodu, Sozlesme_Tarihi, Doviz_Kodu,
				   Sozlesme_Tutari, Vergilimi, Damga_Vergisi, Damga_Vergisi_Musteri_Payi,
				   Musteri_Tahsil_Edilecek_Tutar, Dv_Tahsil_Hesap_No, Kefil1_Musteri_No,
				   Kefil2_Musteri_No, Kefil3_Musteri_No, Kefil4_Musteri_No, Kefil5_Musteri_No,
				   Kefil6_Musteri_No, Kefil7_Musteri_No, Kefil8_Musteri_No, Kefil9_Musteri_No,
				   Kefil10_Musteri_No,kapanis_tarihi,
				   KEFIL1_MUSTERI_AD, KEFIL2_MUSTERI_AD, KEFIL3_MUSTERI_AD, KEFIL4_MUSTERI_AD,
				   KEFIL5_MUSTERI_AD, KEFIL6_MUSTERI_AD, KEFIL7_MUSTERI_AD,
				   KEFIL8_MUSTERI_AD, KEFIL9_MUSTERI_AD, KEFIL10_MUSTERI_AD,
				   sozlesme_amaci,son_fis_numara,bolum_kodu
	  from cbs_sozlesme
	  where musteri_no =pn_musteri_no and
	  		sozlesme_no = pn_sozlesme_no and
			ek_sozlesme_no = pn_ek_sozlesme_no;


 End;

 /****************************************************************************************/
 /*  Function sf_sozlesme_turu_al                                                     */
 /****************************************************************************************/
 Function sf_sozlesme_turu_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return varchar2
 is
   ls_sozlesme_tur cbs_sozlesme.sozlesme_tur_kodu%type;
 Begin

 	  select sozlesme_tur_kodu
	  into ls_sozlesme_tur
	  from cbs_sozlesme
	  where musteri_no =pn_musteri_no and
	  		sozlesme_no = pn_sozlesme_no and
			ek_sozlesme_no = pn_ek_sozlesme_no;

 	  return ls_sozlesme_tur;
 End;

 /****************************************************************************************/
 /*  procedure sp_sozlesme_guncelle                                                   */
 /****************************************************************************************/
 procedure sp_sozlesme_guncelle(pn_islem_no number)
 is
 Begin
 	  update cbs_sozlesme
	  set	 	  (Musteri_No, Sozlesme_No, Ek_Sozlesme_No, Modul_Tur_Kod, Urun_Tur_Kod,
	  			   Urun_Sinif_kod, Durum_Kodu, Sozlesme_Tur_Kodu, Sozlesme_Tarihi, Doviz_Kodu,
				   Sozlesme_Tutari, Vergilimi, Damga_Vergisi, Damga_Vergisi_Musteri_Payi,
				   Musteri_Tahsil_Edilecek_Tutar, Dv_Tahsil_Hesap_No, Kefil1_Musteri_No,
				   Kefil2_Musteri_No, Kefil3_Musteri_No, Kefil4_Musteri_No, Kefil5_Musteri_No,
				   Kefil6_Musteri_No, Kefil7_Musteri_No, Kefil8_Musteri_No, Kefil9_Musteri_No,
				   Kefil10_Musteri_No,kapanis_tarihi,
				   KEFIL1_MUSTERI_AD, KEFIL2_MUSTERI_AD, KEFIL3_MUSTERI_AD, KEFIL4_MUSTERI_AD,
				   KEFIL5_MUSTERI_AD, KEFIL6_MUSTERI_AD, KEFIL7_MUSTERI_AD,
				   KEFIL8_MUSTERI_AD, KEFIL9_MUSTERI_AD, KEFIL10_MUSTERI_AD,sozlesme_amaci,son_fis_numara
				   ) =
	 ( select  	   Musteri_No, Sozlesme_No, Ek_Sozlesme_No, Modul_Tur_Kod, Urun_Tur_Kod,
	  			   Urun_Sinif_kod, Durum_Kodu, Sozlesme_Tur_Kodu, Sozlesme_Tarihi, Doviz_Kodu,
				   Sozlesme_Tutari, Vergilimi, Damga_Vergisi, Damga_Vergisi_Musteri_Payi,
				   Musteri_Tahsil_Edilecek_Tutar, Dv_Tahsil_Hesap_No, Kefil1_Musteri_No,
				   Kefil2_Musteri_No, Kefil3_Musteri_No, Kefil4_Musteri_No, Kefil5_Musteri_No,
				   Kefil6_Musteri_No, Kefil7_Musteri_No, Kefil8_Musteri_No, Kefil9_Musteri_No,
				   Kefil10_Musteri_No,kapanis_tarihi,
				   KEFIL1_MUSTERI_AD, KEFIL2_MUSTERI_AD, KEFIL3_MUSTERI_AD, KEFIL4_MUSTERI_AD,
				   KEFIL5_MUSTERI_AD, KEFIL6_MUSTERI_AD, KEFIL7_MUSTERI_AD,
				   KEFIL8_MUSTERI_AD, KEFIL9_MUSTERI_AD, KEFIL10_MUSTERI_AD,sozlesme_amaci,son_fis_numara

	  from cbs_sozlesme_islem
	  where tx_no = pn_islem_no )
  Where (musteri_no,sozlesme_no,ek_sozlesme_no) in (select musteri_no,sozlesme_no,ek_sozlesme_no
	 	   										 	 from cbs_sozlesme_islem
													 where tx_no = pn_islem_no );


 End;

 /****************************************************************************************/
 /*  procedure sp_sozlesme_durum_guncelle                                                  */
 /****************************************************************************************/
 Procedure sp_sozlesme_durum_guncelle( pn_musteri_no number,pn_sozlesme_no number ,pn_ek_sozlesme_no number ,ps_durum_kodu varchar2  ,pn_islem_no number default null)
   is
	 Begin
		    update cbs_sozlesme
		    set   durum_kodu = ps_durum_kodu
		    where musteri_no = pn_musteri_no and
				  sozlesme_no =pn_sozlesme_no and
				  ek_sozlesme_no = pn_ek_sozlesme_no;

		 if pn_islem_no is not null then
		    update cbs_sozlesme_islem
		    set   durum_kodu = ps_durum_kodu
		 	where tx_no =pn_islem_no ;
		  end if;
     exception
	 	when no_data_found then null;
	 	when others then
     		  raise_application_error(-20100,pkg_hata.getucpointer || '584' || pkg_hata.getdelimiter ||to_char(SQLCODE) || sqlerrm ||pkg_hata.getdelimiter|| pkg_hata.getucpointer);
 end;

 /****************************************************************************************/
 /*   Function sf_sozlesme_tutari_al                                                   */
 /****************************************************************************************/
  Function sf_sozlesme_tutari_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return varchar2
  is
    ln_tutar  number := 0;
  Begin
  	   select nvl(SOZLESME_TUTARI,0)
	   into ln_tutar
	   from cbs_sozlesme
	   where musteri_no = pn_musteri_no and
				  sozlesme_no =pn_sozlesme_no and
				  ek_sozlesme_no = pn_ek_sozlesme_no ;

	 return ln_tutar;
  End;


 /****************************************************************************************/
 /*    Function sf_sozlesme_bakiye_al                                                 */
 /****************************************************************************************/
  Function sf_sozlesme_bakiye_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return number
  /* sozlesme doviz kodunda dondurulur */
  is
   ln_tutar  					  number := 0;
   ln_bakiye 					  number := 0;
   ln_kullanilan_tutar 			  number := 0;
   ls_doviz_kodu				  cbs_sozlesme.doviz_kodu%type;
  Begin
  	   select nvl(SOZLESME_TUTARI,0),
	   		 doviz_kodu
	   into ln_tutar ,
	   		ls_doviz_kodu
	   from cbs_sozlesme
	   where musteri_no = pn_musteri_no and
				  sozlesme_no =pn_sozlesme_no and
				  ek_sozlesme_no = pn_ek_sozlesme_no ;

   	   select sum(nvl( pkg_kur.doviz_doviz_karsilik(nvl(teminat_doviz_kodu,sozlesme_doviz_kodu) ,sozlesme_doviz_kodu,null,kullanilan_tutar,1,null,null,'O','A'),0))
	   into ln_kullanilan_tutar
	   from cbs_teminat
	   where musteri_no = pn_musteri_no and
			 sozlesme_no =pn_sozlesme_no and
			 ek_sozlesme_no = pn_ek_sozlesme_no and
			 teminat_durumu = 'ACIK';

	 ln_bakiye := pkg_kur.yuvarla(ls_doviz_kodu, nvl(ln_tutar,0) - nvl(ln_kullanilan_tutar,0));

	 return ln_bakiye;


  End;


 /****************************************************************************************/
 /*    Function sf_sozlesme_bakiye_al                                                 */
 /****************************************************************************************/
 Function sf_sozlesme_Durum_Al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return  varchar2
 is
    	ls_durum_kodu		VARCHAR2(10);
   BEGIN
   		select durum_kodu
	    into   ls_durum_kodu
		from   cbs_sozlesme
	    where musteri_no = pn_musteri_no and
				  sozlesme_no =pn_sozlesme_no and
				  ek_sozlesme_no = pn_ek_sozlesme_no ;


	   return ls_durum_kodu;
   exception
        when no_data_found then null;
		  when others then
          raise_application_error (-20100, pkg_hata.getucpointer || '806' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
  end;

 /****************************************************************************************/
 /*     Function  sf_sozlesme_kullanilantutar_al                                              */
 /****************************************************************************************/
 Function  sf_sozlesme_kullanilantutar_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return number
  /* sozlesme doviz kodunda dondurulur */
  is
   ln_kullanilan_tutar 			  number := 0;
   ls_doviz_kodu				  cbs_sozlesme.doviz_kodu%type;
  Begin

   	   select doviz_kodu
	   into   ls_doviz_kodu
	   from cbs_sozlesme
	   where musteri_no = pn_musteri_no and
				  sozlesme_no =pn_sozlesme_no and
				  ek_sozlesme_no = pn_ek_sozlesme_no ;

   	   select sum(nvl( pkg_kur.doviz_doviz_karsilik(nvl(teminat_doviz_kodu,sozlesme_doviz_kodu) ,sozlesme_doviz_kodu,null,kullanilan_tutar,1,null,null,'O','A'),0))
	   into ln_kullanilan_tutar
	   from cbs_teminat
	   where musteri_no = pn_musteri_no and
			 sozlesme_no =pn_sozlesme_no and
			 ek_sozlesme_no = pn_ek_sozlesme_no and
			 teminat_durumu = 'ACIK';

	  ln_kullanilan_tutar := pkg_kur.yuvarla(ls_doviz_kodu, ln_kullanilan_tutar);
	 return NVL(ln_kullanilan_tutar,0);

	Exception when others then return 0 ;
  End;

 Function  sf_sozlesmeturteminata_uygunmu( ps_sozlesme_tur_kodu varchar2) return varchar2
 is
 Begin
 	 /* if nvl(ps_sozlesme_tur_kodu,'BIREYSEL KREDI' ) = 'BIREYSEL KREDI' then
	  	 return 'H';
	   else
	   	  return 'E';
	  end if;
	  */
	  return 'E';
 End;
 Function  sozlesme_doviz return varchar2
 is
 Begin
 	  return 'DOVIZ KREDISI';
 End;

 Function  sozlesme_diger return varchar2
 is
 Begin
 	  return 'DIGER';
 End;


 Function  sf_sozlesmeamaci_al(ps_urun_tur_kod varchar2,ps_urun_sinif_kod varchar2,ps_doviz_kodu varchar2) return varchar2
 is
 Begin
 	  if ps_urun_sinif_kod  in ( 'IHRACAT-LC','IHRACAT-FC') then
	  	 return sozlesme_doviz;
	   else
	   	  return sozlesme_diger;
	  end if;

 End;
END ;
/

