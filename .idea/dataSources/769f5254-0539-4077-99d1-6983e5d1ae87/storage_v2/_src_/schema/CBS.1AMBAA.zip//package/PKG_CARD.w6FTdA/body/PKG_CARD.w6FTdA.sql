create PACKAGE BODY pkg_card IS

   INPUT_PATH varchar2(100):='C:\CBSDATA\SALARY';
   BACKUP_PATH varchar2(100):='C:\CBSDATA\SALARY\ARCHIVE';

   CARDFILE_PATH varchar2(100):='C:\CBSDATA\UTILITY\CREDITCARD\FILEUPLOAD';
   CARDFILE_BACKUP_PATH varchar2(100):='C:\CBSDATA\UTILITY\CREDITCARD\FILEUPLOAD\ARCHIVE';

   	l_uc					   			  VARCHAR2(3):=pkg_hata.getUCPOINTER;
	l_ara					   			  VARCHAR2(3):=pkg_hata.getDELIMITER;
----------------------------------------------------------------------------------------------------
Function GetCustomerFromCardNo(ps_cardno varchar2) return number is

	ln_customerno			  number;

BEGIN

	 select CUSTOMER_NO
	 into ln_customerno
	 from CBS_CARD_INFO
	 where CARD_NO= ps_cardno
	 and STATUS_CODE='sVALID';

	 return ln_customerno;

END;
------------------------------
Function GetCardNoFromCustomer(ps_custno varchar2) return varchar2 is

	ls_cardno			  varchar2(16);

BEGIN

	 select CARD_NO
	 into ls_cardno
	 from CBS_CARD_INFO
	 where ACCOUNT_NO= ps_custno
	 and SALARY_CARD='Y'
 	 and STATUS_CODE='sVALID';

	 return ls_cardno;

END;
----------------------------------------------------------------------------------------------------
Function GetSalaryInfoFile(ps_filename varchar2,pn_txno number) return varchar2 is
     f	  					 utl_file.file_type;
	 ls_outstr				 varchar2(2000);
	 ln_COMPANY_ACCOUNT_NO	 number;
	 ln_STAFF_ACCOUNT_NO	 number;
	 ln_AMOUNT				 number;
	 ls_CURRENCY_CODE		 varchar2(3);
	 ld_PAYMENT_DATE		 date;
	 ls_DESCRIPTION			 varchar2(250);
	 ls_PAYROL_NO			 varchar2(10);
	 ls_FIRM_CODE			 varchar2(10);
 	 ln_ORDER_NO			 number;
	 ls_initial			 	 varchar2(10);
	 ln_sum				 	 number:=0;
 	 ln_count			 	 number:=0;
	 ln_totalamount			 number:=0;
 	 ln_totalcount			 number:=0;

	 ln_messageid			 number;
	 ls_content			CLOB;
	 ls_outputmsg		varchar2(1000):='OK';
BEGIN

	 insert into CBS_SALARY_ISLEM
	 (TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, FILE_NAME)
	 values
	 (pn_txno, 'CUSTOMER', 'SALARY', 'PAYMENT', ps_filename);

	 --COMMIT;

	 f:=utl_file.fopen(INPUT_PATH, ps_filename, 'r',2000);

	 LOOP

		 begin
	      utl_file.get_line(f, ls_outstr);
	     EXCEPTION
	      WHEN NO_DATA_FOUND THEN
	        EXIT;
	     end;

		 EXIT WHEN instr(ls_outstr,'#')<1;

		 if instr(ls_outstr,'#')>1 then

			 ln_ORDER_NO:=to_number(pkg_message.Split(ls_outstr,'#',0));
			 ln_COMPANY_ACCOUNT_NO:=to_number(pkg_message.Split(ls_outstr,'#',1));
			 ln_STAFF_ACCOUNT_NO:=to_number(pkg_message.Split(ls_outstr,'#',2));
 			 --ln_COMPANY_ACCOUNT_NO:=to_number(pkg_conv.YENI_HESAPNO_BUL(pkg_message.Split(ls_outstr,'#',1),null, '51'));
			 --ln_STAFF_ACCOUNT_NO:=to_number(pkg_conv.YENI_HESAPNO_BUL(pkg_message.Split(ls_outstr,'#',2),null, '51'));
			 ls_CURRENCY_CODE:=pkg_hesap.HesaptanDovizKoduAl(ln_STAFF_ACCOUNT_NO);
			 ln_AMOUNT:=pkg_kur.yuvarla(ls_CURRENCY_CODE,to_number(pkg_message.Split(ls_outstr,'#',3)));--
			 ld_PAYMENT_DATE:=to_date(pkg_message.Split(ls_outstr,'#',4),'YYYYMMDD');
			 ls_FIRM_CODE:=pkg_message.Split(ls_outstr,'#',5);
			 ls_PAYROL_NO:=pkg_message.Split(ls_outstr,'#',6);
			 ls_DESCRIPTION:=pkg_message.Split(ls_outstr,'#',7);

			 insert into CBS_SALARY_DETAIL_ISLEM
			 (TX_NO, ORDER_NO, COMPANY_ACCOUNT_NO, STAFF_ACCOUNT_NO, AMOUNT, CURRENCY_CODE, PAYMENT_DATE,DESCRIPTION,FIRM_CODE,PAYROL_NO)
			 values
			 (pn_txno, ln_ORDER_NO,ln_COMPANY_ACCOUNT_NO, ln_STAFF_ACCOUNT_NO, ln_AMOUNT, ls_CURRENCY_CODE, ld_PAYMENT_DATE, ls_DESCRIPTION,ls_FIRM_CODE,ls_PAYROL_NO);

			 ln_sum:=ln_sum+ln_AMOUNT;
			 ln_count:=ln_count+1;
		 end if;


	 END LOOP;

	 update CBS_SALARY_ISLEM
	 set CUSTOMER_NO=pkg_hesap.HesaptanMusteriNoAl(ln_COMPANY_ACCOUNT_NO)
	 ,SALARY_DATE=ld_PAYMENT_DATE
	 where tx_no= pn_txno;

	 utl_file.fclose(f);

	 --move the file
	 --utl_file.frename(INPUT_PATH, ps_filename,BACKUP_PATH, ps_filename);

	 COMMIT;

	 return ls_outputmsg;

exception
	 when others then
	  	ROLLBACK;
		ln_messageid:=pkg_genel.genel_kod_al('EMAIL-MSGID');

		ls_content:=sqlerrm || ls_outstr;
		ls_outputmsg:=sqlerrm || ls_outstr;

		insert into CBS_EMAIL_MESSAGES
		(MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
		values
		(ln_messageid, 'SALARYFILEUPLOAD', 50, 'info@demirbank.kz', 'timucin@demirbank.kz', 'ERROR-SALARY FILE UPLOAD',ls_content);

		return ls_outputmsg;
END;
----------------------------------------------------------------------------------------------------
Function GetISOCurrency(ps_currencycode varchar2) return varchar2 is
		 ls_isocurr varchar2(3);
BEGIN
	 select ISO_CODE
	 into ls_isocurr
	 from CBS_DOVIZ_KODLARI
	 where DOVIZ_KODU=ps_currencycode;

	 return ls_isocurr;
END;
 ----------------------------------------------------------------------------------------------------
Procedure ModifyCardinfo(ps_cardno varchar2,p_txno in number) is
BEGIN

	INSERT INTO cbs_card_info_islem
	(TX_NO,C_ID,CARD_NO, CUSTOMER_NO, ACCOUNT_NO, STATUS_CODE,SALARY_CARD)
	SELECT p_txno,C_ID,CARD_NO, CUSTOMER_NO, ACCOUNT_NO, STATUS_CODE,SALARY_CARD
	FROM cbs_card_info
	WHERE CARD_NO = ps_cardno;

END;
-------------------------------------------------------------------------------------------------------
Function GetSelectedPayments(ps_sqlstr varchar2) return varchar2 is

	ls_txnostr varchar2(3000):=' ';

	TYPE EmpCurTyp IS REF CURSOR;

	cursor_card EmpCurTyp;

    row_card	 CBS_CARD_PAYMENT%rowtype;

BEGIN

	--log_at('select  * from CBS_CARD_PAYMENT where STATUS_CD=''sWAIT'' and ' || ps_sqlstr || ' for update');

	OPEN cursor_card FOR
		'select  * from CBS_CARD_PAYMENT where STATUS_CD=''sWAIT'' and ' || ps_sqlstr || ' for update';

	FETCH cursor_card INTO row_card;
	WHILE cursor_card%found
	LOOP
		--ls_txnostr:=ls_txnostr || ',' || row_card.TX_NO;
		null;
	FETCH cursor_card INTO row_card;
	END LOOP;
	CLOSE  cursor_card;


	return ls_txnostr;
END;
------------------------------------------------------------------------------------------------------
Function GetCardUploadFile(ps_filename varchar2,pn_txno number) return varchar2 is
     f	  					 utl_file.file_type;
	 ls_outstr				 varchar2(2000);
	 ls_initial			 	 varchar2(10);
	 ln_sum				 	 number:=0;
 	 ln_count			 	 number:=1;
	 ln_totalamount			 number:=0;
 	 ln_totalcount			 number:=0;
	 ls_seperator			 varchar2(1):=' ';
	 ln_uploadid				 number;

	 ln_UPLOAD_ID				 number;
	 ln_ORDER_ID				 number;
	 ls_DEBIT_GL				 varchar2(8);
	 ls_CREDIT_GL				 varchar2(8);
	 ln_FC_AMOUNT				 number;
	 ln_LC_AMOUNT				 number;
	 ls_EXPLANATION				 varchar2(250);
	 ls_CURRENCY_CODE			 varchar2(8);

	 ln_messageid			number;
	 ls_content			CLOB;
	 ls_outputmsg		varchar2(1000):='OK';
	 ls_filename		varchar2(50);
BEGIN

	 ln_uploadid:=pkg_genel.genel_kod_al('CARDFILEUPLOAD');

	 insert into CBS_CARD_UPLOAD_TRAN
	 (TX_NO, UPLOAD_DATE, UPLOAD_ID, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD)
	 values
	 (pn_txno, to_date(ps_filename,'DDMMYYYY'),ln_uploadid,'CARD', 'CREDIT','UPLOAD');

	 --COMMIT;
	 ls_filename:='gn' || to_char(to_date(ps_filename,'DDMMYYYY'),'DDMMYY') || '.txt';

	 f:=utl_file.fopen(CARDFILE_PATH, ls_filename, 'r',2000);

	 LOOP

		 begin
	      utl_file.get_line(f, ls_outstr);
	     EXCEPTION
	      WHEN NO_DATA_FOUND THEN
	        EXIT;
	     end;

		 EXIT WHEN instr(ls_outstr,ls_seperator)<1;

		 if instr(ls_outstr,ls_seperator)>1 then

		 	 ln_UPLOAD_ID:=ln_uploadid;
			 ln_ORDER_ID:= ln_count;
			 if length(to_number(pkg_message.Split(ls_outstr,ls_seperator,0)))=6 then
			 	ls_DEBIT_GL:=rpad(to_number(pkg_message.Split(ls_outstr,ls_seperator,0)),8,'0');
			 else
			 	 ls_DEBIT_GL:=pkg_message.Split(ls_outstr,ls_seperator,0);
			 end if;
		  	 if length(to_number(pkg_message.Split(ls_outstr,ls_seperator,1)))=6 then
			 	ls_CREDIT_GL:=rpad(to_number(pkg_message.Split(ls_outstr,ls_seperator,1)),8,'0');
			 else
			 	 ls_CREDIT_GL:=pkg_message.Split(ls_outstr,ls_seperator,1);
			 end if;

			 ls_CURRENCY_CODE:=pkg_genelkz.GetCurrencyCodeFromISO(pkg_message.Split(ls_outstr,ls_seperator,2));

			 ln_FC_AMOUNT:=to_number(replace(pkg_message.Split(ls_outstr,ls_seperator,3),',','.'));
			 --ln_LC_AMOUNT:=to_number(replace(pkg_message.Split(ls_outstr,ls_seperator,4),',','.'));
			 ln_LC_AMOUNT:=pkg_kur.doviz_doviz_karsilik(ls_CURRENCY_CODE,pkg_genel.lc_al,null,ln_FC_AMOUNT,1,null,null,'N','A');
			 ls_EXPLANATION:=substr(ls_outstr,instr(ls_outstr,ls_seperator,1,5));

		 	 insert into CBS_CARD_UPLOAD_DETAIL_TRAN
			 (TX_NO, UPLOAD_ID, ORDER_ID, DEBIT_GL, CREDIT_GL, FC_AMOUNT, LC_AMOUNT, EXPLANATION, CURRENCY_CODE)
			 values
			 (pn_txno, ln_UPLOAD_ID, ln_ORDER_ID, ls_DEBIT_GL, ls_CREDIT_GL, ln_FC_AMOUNT, ln_LC_AMOUNT, ls_EXPLANATION, ls_CURRENCY_CODE);

			 ln_count:=ln_count+1;
		 end if;


	 END LOOP;

	 update CBS_CARD_UPLOAD_TRAN
	 set AMOUNT_1859=abs(pkg_card.Get1859Balance(pn_txno)),
	 	 AMOUNT_2858=abs(pkg_card.Get2858Balance(pn_txno)),
		 BALANCE_DIFFERENCE=abs(abs(pkg_card.Get1859Balance(pn_txno))-abs(pkg_card.Get2858Balance(pn_txno)))
	 where TX_NO=pn_txno;

	 utl_file.fclose(f);

	 --move the file
	 --utl_file.frename(CARDFILE_PATH, ls_filename, CARDFILE_BACKUP_PATH, ls_filename);

	 COMMIT;

	 return ls_outputmsg;

exception
	 when others then
	  	ROLLBACK;
		ln_messageid:=pkg_genel.genel_kod_al('EMAIL-MSGID');

		ls_content:=sqlerrm;
		ls_outputmsg:=sqlerrm || '-' || ls_outstr;

		insert into CBS_EMAIL_MESSAGES
		(MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
		values
		(ln_messageid, 'CARDFILEUPLOAD', 50, 'info@demirbank.kz', 'timucin@demirbank.kz', 'ERROR-CARD FILE UPLOAD',ls_content);

		return ls_outputmsg;

END;
-------------------------------------------------------------------------
  Function Get1859Balance(pn_txno number) return number is
  		   ln_total				  number;
		   ln_debit				  number:=0;
		   ln_credit			  number:=0;
  BEGIN
  	   begin
			select  nvl(sum(decode(LC_AMOUNT,0,FC_AMOUNT,LC_AMOUNT)),0)
			into ln_debit
			from CBS_CARD_UPLOAD_DETAIL_TRAN
			where tx_no=pn_txno
			and DEBIT_GL='18590000';
	   exception
	   		when no_data_found then
				 ln_debit:=0;
	   end;
  	   begin
			select  nvl(sum(LC_AMOUNT),0)
			into ln_credit
			from CBS_CARD_UPLOAD_DETAIL_TRAN
			where tx_no=pn_txno
			and CREDIT_GL='18590000';
	   exception
	   		when no_data_found then
				 ln_credit:=0;
	   end;

	   return ln_credit-ln_debit;
  END;
------------------------------------------------------------------------------------------
  Function Get2858Balance(pn_txno number) return number is
  		   ln_total				  number;
		   ln_debit				  number:=0;
		   ln_credit			  number:=0;
  BEGIN
  	   begin
			select  nvl(sum(LC_AMOUNT),0)
			into ln_debit
			from CBS_CARD_UPLOAD_DETAIL_TRAN
			where tx_no=pn_txno
			and DEBIT_GL='28580000';
	   exception
	   		when no_data_found then
				 ln_debit:=0;
	   end;
  	   begin
			select  nvl(sum(LC_AMOUNT),0)
			into ln_credit
			from CBS_CARD_UPLOAD_DETAIL_TRAN
			where tx_no=pn_txno
			and CREDIT_GL='28580000';
	   exception
	   		when no_data_found then
				 ln_credit:=0;
	   end;

	   return ln_credit-ln_debit;
  END;
------------------------------------------------------------------------------------------------------
  Function IsSalaryCard(ps_cardno varchar2) return varchar2 is
  		   ls_salarycard				  varchar2(1);
  BEGIN

		select  SALARY_CARD
		into ls_salarycard
		from CBS_CARD_INFO
		where CARD_NO=ps_cardno;

		return ls_salarycard;

  END;
-----------------------------------------------------------------------------
  Function GetIDCardNo(pn_customerno number) return varchar2 is
  		   ls_kimliktipi varchar2(1);
		   ls_idcardno varchar2(25);
  begin

	   select decode(KIMLIK_KOD,1,NUFUS_CUZDANI_SERI_NO,2,EHLIYET_BELGE_NO,3,PASAPORT_NO)
	   into ls_idcardno
	   from cbs_musteri
	   where musteri_no=pn_customerno;

	   return ls_idcardno;

  exception
  	   when others then
	   		return null;
  end;
  -----------------------------------------------------------------------------------------------------
  Function GetSalaryCardTransferAmount(pn_amount number,pn_companyacc number,pn_staffacc number) return number is

	CURSOR cardex_cursor(pn_company_acc number, pn_staff_acc number)IS
	   	 	SELECT * from CBS_SALARY_EXCEPTION_LIST
			where COMPANY_ACCOUNT_NO=pn_company_acc
			and STAFF_ACCOUNT_NO=pn_staff_acc
			and STATUS_CD='sVALID';

	row_cardex  				  	  cardex_cursor%ROWTYPE;
	ls_currency						  varchar2(3);
	ln_amounttocard					  number;
	ln_cardno						  number;
Begin

	ls_currency:=pkg_hesap.HesaptanDovizKoduAl(pn_companyacc);

	OPEN cardex_cursor(pn_companyacc,pn_staffacc);
	FETCH cardex_cursor INTO row_cardex;
	if cardex_cursor%FOUND then
	   if row_cardex.REMAINING_AMOUNT is null  then
	   	   if pn_amount>(pkg_kur.YUVARLA(ls_currency,pn_amount*row_cardex.REMAINING_PERCENT/100)) then
		   	  ln_amounttocard:=pn_amount-(pkg_kur.YUVARLA(ls_currency,pn_amount*row_cardex.REMAINING_PERCENT/100));
		   else
		   	   ln_amounttocard:=0;
		   end if;
	   else
	   	   if pn_amount>row_cardex.REMAINING_AMOUNT then
	   	   	  ln_amounttocard:=pn_amount-row_cardex.REMAINING_AMOUNT;
		   else
		   	   ln_amounttocard:=0;
		   end if;
	   end if;
	else
		ln_amounttocard:=pn_amount;
	end if;
	CLOSE cardex_cursor;

	 select count(*)
	 into ln_cardno
	 from CBS_CARD_INFO
	 where ACCOUNT_NO= pn_staffacc
	 and SALARY_CARD='Y'
 	 and STATUS_CODE='sVALID';

	if ln_cardno=0 then
	   ln_amounttocard:=0;
	end if;

	return ln_amounttocard;
END;
-----------------------------------------------------------------------------------------------------
END;
/

