create PACKAGE BODY pkg_bireysel_kredi IS

 function cakisan_vadeler(pn_kredi_tur_no number) return number is
 cursor c_0 is
	select 1
	  from cbs_kredi_tur_vade c
	 where c.kredi_tur_kod_no = pn_kredi_tur_no
	   and (kredi_tur_kod_no, min_vade, max_vade)
	       not in (select kredi_tur_kod_no, min_vade, max_vade
                     from cbs_kredi_tur_vade a
					where a.kredi_tur_kod_no = pn_kredi_tur_no
					  and not exists (select 1
										from cbs_kredi_tur_vade b
									   where b.kredi_tur_kod_no = pn_kredi_tur_no
									     and a.numara<> b.numara
										 and (   a.min_vade between b.min_vade and b.max_vade
	     									  or a.max_vade between b.min_vade and b.max_vade)
									 )
					);
 ln_temp number;
 begin
    open c_0;
	fetch c_0 into ln_temp;
	if c_0%notfound then
	  ln_temp:=0;
	end if;
	close c_0;
	return ln_temp;
 end;
----------------------------------------------------------------------------------
 procedure min_max_vade_al(pn_kredi_tur_no in number, pn_max_vade out number,
                           pn_min_vade out number) is
 cursor c_0 is
	select max(max_vade) max_vade
	  from cbs_kredi_tur_vade c
	 where c.kredi_tur_kod_no = pn_kredi_tur_no;
 cursor c_1 is
	select min(min_vade) min_vade
	  from cbs_kredi_tur_vade c
	 where c.kredi_tur_kod_no = pn_kredi_tur_no;

 begin
    open c_0;
		fetch c_0 into pn_max_vade;
		if c_0%notfound then
	      close c_0;
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '692' ||  pkg_hata.getUCPOINTER);
		end if;
	close c_0;
    open c_1;
		fetch c_1 into pn_min_vade;
		if c_1%notfound then
	      close c_1;
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '693' ||  pkg_hata.getUCPOINTER);
		end if;
	close c_1;
 end;
----------------------------------------------------------------------------------
 function faiz_oran_al(pn_kredi_tur_no in number, pn_taksit_sayi number) return number is
 ln_temp number;
 begin
	select faiz_orani
	  into ln_temp
	  from cbs_kredi_tur_vade c
	 where c.kredi_tur_kod_no = pn_kredi_tur_no
	   and pn_taksit_sayi between min_vade and max_vade;
     return ln_temp;
  exception
    when no_data_found then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '694' ||  pkg_hata.getUCPOINTER);
	when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '695' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);

 end;
----------------------------------------------------------------------------------
 function kredi_tur_adi_al(pn_kredi_tur_no number) return varchar2 is
 ls_temp cbs_kredi_tur.KREDI_TUR%type;
 begin
	select kredi_tur
	  into ls_temp
	  from cbs_kredi_tur c
	 where c.kod_no = pn_kredi_tur_no;
     return ls_temp;
  exception
    when no_data_found then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '696' ||  pkg_hata.getUCPOINTER);
	when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '697' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
 end;
----------------------------------------------------------------------------------
 procedure eski_taksitleri_temizle(pn_islem_no number) is
 begin
   delete from cbs_hesap_kredi_taksit_islem
    where tx_no = pn_islem_no
		  and nvl(durum_kodu ,'A')= 'A';

 end;
----------------------------------------------------------------------------------
 procedure eski_ozel_odeme_temizle(pn_islem_no number) is
 begin
   delete from cbs_hesap_kredi_ozel_tkst_isl
    where tx_no = pn_islem_no;
 end;
----------------------------------------------------------------------------------
 procedure sp_rapor_degerlerini_al(pn_islem_no number, ps_rapor_adi   out varchar2,
           ps_1_alan_adi  out varchar2, ps_1_degeri    out varchar2,
		   ps_2_alan_adi  out varchar2, ps_2_degeri    out varchar2,
		   ps_3_alan_adi  out varchar2, ps_3_degeri    out varchar2,
		   ps_4_alan_adi  out varchar2, ps_4_degeri    out varchar2,
		   ps_5_alan_adi  out varchar2, ps_5_degeri    out varchar2,
		   ps_6_alan_adi  out varchar2, ps_6_degeri    out varchar2,
		   ps_7_alan_adi  out varchar2, ps_7_degeri    out varchar2,
		   ps_8_alan_adi  out varchar2, ps_8_degeri    out varchar2,
		   ps_9_alan_adi  out varchar2, ps_9_degeri    out varchar2,
		   ps_18_alan_adi out varchar2, ps_18_degeri   out varchar2,
		   ps_19_alan_adi out varchar2, ps_19_degeri   out varchar2,
		   ps_20_alan_adi out varchar2, ps_20_degeri   out varchar2)
 is
 Begin
     if pn_islem_no is not null then
		 	    select 'B?REYSEL KRED?LER ?DEME PLANI',
					   'KRED? TUTARI ', to_char(tutar,'FM999G999G999G999G990D00'),
					   'TAKS?T SAYISI' , taksit_sayisi,
					   'D?V?Z C?NS? ', decode(nvl(endeks_doviz_kodu,'111'), '111', doviz_kodu, endeks_doviz_kodu),
					   '?DEME T?P? ', decode(odeme_turu,1,'1-Sabit Taksitli',
					                                     2,'2-Artan Taksitli',
														 3,'3-Ara ?demeli',
														 4,'4-Karma Ara ?demeli',
														 5,'5-D?nemsel ?demeli',
														 6,'6-?zel ?demeli'),
					   'FA?Z ORANI ', to_char(faiz_orani,'FM99G990D0099'),
					   'KRED? T?R? ', kredi_turu || '-' || kredi_tur_adi_al(kredi_turu),
					   'KKDF ORANI', to_char(fon_orani,'FM99G990D0099'),
					   'BSMV ORANI', to_char(bsmv_orani,'FM99G990D0099'),
					   'TAR?H ', to_char(acilis_tarihi,'DD.MM.YYYY'),
					   '?? bu belge ', 'kredisi i?in imzalam?? oldu?unuz',
					   'tarihli s?zle?menin ayr?lmaz bir par?as? olup;',
					   's?z konusu s?zle?me gere?i taraf?m?za verilen kredi borcunuzu ,geri ?deme plan?nda belirlenen vadelerde ve vadelerin',
					   'kar??s?nda g?sterilen tutarlarda;s?zle?me hukumlerine uygun olarak ?deyece?imi/?deyece?imizi gayrikabili r?c? olarak ',
					   'beyan ve taahhut ederim/ederiz.'
				into   ps_rapor_adi,
			           ps_1_alan_adi, ps_1_degeri,
					   ps_2_alan_adi, ps_2_degeri,
					   ps_3_alan_adi, ps_3_degeri,
					   ps_4_alan_adi, ps_4_degeri,
					   ps_5_alan_adi, ps_5_degeri,
					   ps_6_alan_adi, ps_6_degeri,
					   ps_7_alan_adi, ps_7_degeri,
					   ps_8_alan_adi, ps_8_degeri,
					   ps_9_alan_adi, ps_9_degeri,
					   ps_18_alan_adi, ps_18_degeri,
					   ps_19_alan_adi, ps_19_degeri,
					   ps_20_alan_adi, ps_20_degeri
		  		from cbs_hesap_kredi_islem
				where tx_no = pn_islem_no ;
      end if;
 End;

  /*****************************************************************************************************************/
  /*   Function	 Sf_BireyselUrunUygunmu											               			  */
  /****************************************************************************************************************/
  Function  Sf_BireyselUrunUygunmu( ps_urun_tur_kod cbs_hesap_kredi.urun_tur_kod%type ) return varchar2
  is
     ls_uygun  varchar2(1) := 'H';
  Begin
  	   if ps_urun_tur_kod in (
	   	  				  	 'RT-FIXRATE',
							 'RT-VRRATE',
							 'RT-CARD'
							 ) Then

	   	  ls_uygun := 'E';
		else
		    ls_uygun := 'H';
		end if;

	   return ls_uygun ;

    Exception
	  When Others Then return 'H';
  End ;

   /*****************************************************************************************************************/
  /*   Procedure sf_min_odenmemis_taksiti_bul								               			  */
  /****************************************************************************************************************/
	 Procedure sf_min_odenmemis_taksiti_bul (pn_hesap_no cbs_hesap_kredi.hesap_no%type,
			 								 pd_vade_tarihi date ,
											 pn_taksit_sira_no  out number,
											 pd_taksit_vade out date )
	 is

	 Begin
	 	  select min(sira_no),min( vade_tarih)
		  into pn_taksit_sira_no  ,pd_taksit_vade
		  FROM CBS_hesap_kredi_taksit
		  where hesap_no = pn_hesap_no and
		  		vade_tarih <= nvl(pd_vade_Tarihi,pkg_muhasebe.banka_tarihi_bul) and
				durum_kodu = 'A';

	  Exception when others then null;

	 End;

  /*****************************************************************************************************************/
  /*  Function sf_taksit_durumu_al									               			  */
  /****************************************************************************************************************/

  Function sf_taksit_durumu_al( pn_hesap_no cbs_hesap_kredi.hesap_no%type,
 		  					    pn_taksit_sira_no   number ) return varchar2
  is
   ls_durum_kodu cbs_hesap_kredi_taksit.durum_kodu%type ;
  Begin
  	   select durum_kodu
	   into ls_durum_kodu
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
	   		 sira_no = pn_taksit_sira_no  ;

  	  return ls_durum_kodu;

    Exception
	when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '911' ||  pkg_hata.getdelimiter|| to_char(  pn_taksit_sira_no) || pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);

  End;

  /*****************************************************************************************************************/
  /*  Function sf_taksit_vadetarihi_al								               			  */
  /****************************************************************************************************************/

 Function sf_taksit_vadetarihi_al( pn_hesap_no cbs_hesap_kredi.hesap_no%type,
 		  					  	   pn_taksit_sira_no   number ) return date
 is
   ld_vade	date;
  Begin

  	   select vade_tarih
	   into ld_vade
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
	   		 sira_no = pn_taksit_sira_no  ;

  	  return ld_vade;

    Exception
	when no_data_found then return null ;
 	when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '911' ||  pkg_hata.getdelimiter|| to_char(  pn_taksit_sira_no) || pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
	   return null;
  End;

  /*****************************************************************************************************************/
  /*  Function  sf_ensonodenmis_vadetarihial								               			  */
  /****************************************************************************************************************/

 Function sf_ensonodenmis_vadetarihial( pn_hesap_no cbs_hesap_kredi.hesap_no%type) return date

 is
   ld_vade	date;
  Begin

  	   select max(vade_tarih)
	   into ld_vade
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
			 odeme_tarihi is not null  ;

	  if ld_vade is null then
	   	   select acilis_Tarihi
		   into ld_vade
		   from cbs_hesap_kredi
		   where hesap_no = pn_hesap_no ;
	 end if;

	 return ld_vade;

    Exception
	when no_data_found then

	   	   select acilis_Tarihi
		   into ld_vade
		   from cbs_hesap_kredi
		   where hesap_no = pn_hesap_no ;

		   return ld_vade;
  End;

 Function sf_ensonodenmis_taksitfaizal( pn_hesap_no cbs_hesap_kredi.hesap_no%type) return number
 is
  ln_faiz number := 0;
 Begin
  	  SELECT faiz
	  into ln_faiz
	  from cbs_hesap_kredi_taksit
	  where hesap_no = pn_hesap_no and ( sira_no) in (
		   select min(sira_no)
		   from cbs_hesap_kredi_taksit
		   where hesap_no = pn_hesap_no and
		   		 durum_kodu = 'A' );


  return nvl(ln_faiz,0);

  exception when others then return 0;
 End;

 Function sf_taksit_anapara_al( pn_hesap_no cbs_hesap_kredi.hesap_no%type,
 		  					  	pn_taksit_sira_no   number ) return number
 is
   ln_tutar	number ;
  Begin

  	   select ANAPARA
	   into ln_tutar
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
	   		 sira_no = pn_taksit_sira_no  ;

  	  return ln_tutar;

    Exception
	when no_data_found then return 0 ;
 	End;

 Function sf_taksit_faiz_al( pn_hesap_no cbs_hesap_kredi.hesap_no%type,
 		  					  	pn_taksit_sira_no   number ) return number
 is
   ln_tutar	number ;
  Begin

  	   select faiz
	   into ln_tutar
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
	   		 sira_no = pn_taksit_sira_no  ;

  	  return ln_tutar;

    Exception
	when no_data_found then return 0 ;
 	End;

Function sf_max_odenmis_taksit_no (pn_hesap_no cbs_hesap_kredi.hesap_no%type) return number
 is
  ln_sira_no number := 0;
 Begin
	   select max(sira_no)
	   into ln_sira_no
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
	   		 durum_kodu = 'O' ;
  return nvl(ln_sira_no,0);

  exception when others then return 0;
 End;

END;
/

