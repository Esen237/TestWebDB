create PACKAGE     PKG_TX2050 is

  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54
  -- Purpose : Hesap G?ncelleme kullan?lacakt?r.

  Procedure Yaratma_Oncesi(pn_islem_no number); 		-- Islem giris kontrolden once cagrilir
  Procedure Kontrol_Sonrasi(pn_islem_no number); 		-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Onay_Sonrasi(pn_islem_no number);				-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			-- Islemin muhasebelesmesi icin cagrilir

  Procedure Guncelleme_Kontrolu(pn_islem_no NUMBER,
							ps_block	VARCHAR2,
							ps_rowid   VARCHAR2,
 				   			ps_column  	VARCHAR2,
	   				   		pd_column   VARCHAR2,
							ps_oldvalue IN OUT VARCHAR2); --G?ncellenen alanlar? bulmak i?in
FUNCTION  sf_durum_kodu_al(ps_durum_kodu CBS_HAZINE_VERILENDEPO.DURUM_KODU%type) RETURN VARCHAR2;
FUNCTION  sf_modul_tur_kodu_al(ps_modul_tur_kod CBS_HESAP.MODUL_TUR_KOD%type) RETURN VARCHAR2 ;
FUNCTION  sf_urun_sinif_al(ps_urun_sinif_kod CBS_URUN_SINIF.MODUL_TUR_KOD%type) RETURN VARCHAR2;
FUNCTION  sf_musteri_tipi_al(ps_musteri_tipi_kod CBS_MUSTERI.MUSTERI_TIPI_KOD%type) RETURN VARCHAR2;
FUNCTION  sf_kod_al(ps_kod CBS_URUN_TUR.KOD%type) RETURN VARCHAR2 ;

end PKG_TX2050;


/

