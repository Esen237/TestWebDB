create PACKAGE Pkg_Menkul_Rapor IS
/******************************************************************************
   Name       : PKG_MENKUL
   Created By : G?lnihal Cengiz
   Date    	  : 02/04/2004
   Purpose	  : Menkul islemleri ile ilgili rapor ve izlemelerde kullanilacak fonksiyonlar ve
   			    procedure'lar yer alir.
******************************************************************************/
 FUNCTION   islem_tipi_adi_al(pn_kod NUMBER) RETURN VARCHAR2 ;
 FUNCTION 	stok_kartina_giris_tarihi(pn_stok NUMBER) RETURN DATE;
 FUNCTION   Kupon_odeme_donemi_aciklamasi(pn_donem NUMBER) RETURN VARCHAR2;
 FUNCTION 	Gun_Hesaplama_Bazi_Aciklamasi(pn_gun NUMBER) RETURN VARCHAR2;
 FUNCTION  urun_grubu_nakdi_mi(pn_urun_grubu CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2;
END;


/

