create PACKAGE BODY     pkg_musteri_gizle IS

 /******************************************************************************
   Name       : PKG_MUSTERI_GIZLE
   Created By : Chyngyz O.
   Date          : 18.01.2014
   Purpose      : For Customer Information Hiding project ( Request No 617). 
                      Contains functions to determine whether certain customer should be hidden from specified CBS user.
                      They are called from Oracle Forms and Oracle Reports.
******************************************************************************/


-- Returns if customer (pn_customer_no) is defined as hidden or not ('E' or 'H')
FUNCTION is_customer_hidden(pn_customer_no CBS_MUSTERI.MUSTERI_NO%TYPE) RETURN VARCHAR2
IS
 ln_musteri_no   NUMBER;
BEGIN

    SELECT T.CUSTOMER_NO
    INTO ln_musteri_no
    FROM CBS_HIDDEN_CUSTOMERS T
    WHERE T.CUSTOMER_NO = pn_customer_no;

   IF ln_musteri_no IS NOT NULL
   THEN
      RETURN 'E';
   ELSE
      RETURN 'H';
   END IF;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      RETURN 'H';
END;


-- Determines whether for current user (pkg_baglam.kullanici_kodu) customer (pn_musteri_no) should be hidden or not ('E' or 'H')
-- Called from Oracle Forms
FUNCTION musteri_gizlensin_mi(pn_musteri_no CBS_MUSTERI.MUSTERI_NO%TYPE) RETURN VARCHAR2
IS
BEGIN
      return PKG_MUSTERI_GIZLE.MUSTERI_GIZLENSIN_MI(pn_musteri_no, PKG_BAGLAM.KULLANICI_KODU);
END;


-- Determines whether for current user (pc_kullanici_kodu) customer (pn_musteri_no) should be hidden or not ('E' or 'H')
-- Called from Oracle Reports.
FUNCTION musteri_gizlensin_mi(pn_musteri_no CBS_MUSTERI.MUSTERI_NO%TYPE, pc_kullanici_kodu CBS_KULLANICI.KODU%TYPE) RETURN VARCHAR2
IS

 ln_musteri_no   NUMBER; 
 ls_kullanicinin_musteri NUMBER;
 ls_yetkili_kullanici VARCHAR2(2);
 ls_new_hidden_customer VARCHAR2(2000); --bahianab cbs_344 05112020
 ls_result VARCHAR2(100); --bahianab cbs-344 05112020 
 ls_check NUMBER ; --bahianab cbs-344 05112020
 
BEGIN

   /* cbs-344 bahianab commented out due to new logic  
   SELECT CHM.CUSTOMER_NO
     INTO ln_musteri_no
     FROM CBS_HIDDEN_CUSTOMERS chm
     WHERE CHM.CUSTOMER_NO = pn_musteri_no;

   IF ln_musteri_no IS NOT NULL
   THEN
   
        ls_yetkili_kullanici := pkg_musteri_gizle.is_user_authorized(pc_kullanici_kodu);
        ls_kullanicinin_musteri := pkg_musteri.sf_kullanicinin_musterino_al(pc_kullanici_kodu) ;
        
        if ls_yetkili_kullanici = 'E' or 
             pn_musteri_no = ls_kullanicinin_musteri   
         then
             return 'H';
        else
             return 'E';
        end if;
        
   ELSE
      RETURN 'H';
   END IF;
   cbs-344 bahianab commented out due to new logic*/

--BOM bahianab cbs-344 05112020

ls_check:= 0;  
            pkg_parametre.deger('NEW_HIDDEN_CUSTOMERS',ls_new_hidden_customer);

            if  instr(ls_new_hidden_customer, pn_musteri_no||';') > 0
             then  
                ls_result:= 'E';
                ls_check  := 1;      
               RETURN ls_result;  
            end if;
     
IF ls_check= 0 THEN

    SELECT CHM.CUSTOMER_NO
     INTO ln_musteri_no
     FROM CBS_HIDDEN_CUSTOMERS chm
     WHERE CHM.CUSTOMER_NO = pn_musteri_no;

   IF ln_musteri_no IS NOT NULL 
   THEN
   
        ls_yetkili_kullanici := pkg_musteri_gizle.is_user_authorized(pc_kullanici_kodu);               
        ls_kullanicinin_musteri := pkg_musteri.sf_kullanicinin_musterino_al(pc_kullanici_kodu) ;
                
        if ls_yetkili_kullanici = 'E' or 
             pn_musteri_no = ls_kullanicinin_musteri   
         then
             ls_result:= 'H'; 
        else
             ls_result:= 'E';
        end if;         
          RETURN ls_result;   
   ELSE
        ls_result:= 'H';
       
      RETURN ls_result;
   END IF;
   
 END IF;  
--EOM bahianab cbs-344 05112020
    
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      RETURN 'H';
END;
-- Returns if user (ps_kullanici) is authorized to view hidden customers or not ('E' or 'H')
FUNCTION is_user_authorized (ps_kullanici CBS_KULLANICI.KODU%TYPE)
   RETURN VARCHAR2
IS
   ls_kullanici   CBS_KULLANICI.KODU%TYPE;
BEGIN

   SELECT CV.kodu
     INTO ls_kullanici
     FROM CBS_AUTHORIZED_USERS CV
    WHERE CV.kodu = ps_kullanici;

   IF ls_kullanici IS NOT NULL
   THEN
      RETURN 'E';
   ELSE
      RETURN 'H';
   END IF;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      RETURN 'H';
      
END is_user_authorized;



-- For given transaction no (pn_islem_no) determines whether transaction contains account of hidden customer ('E' or 'H')
FUNCTION fiste_gizli_hesap_var_mi( pn_islem_no number) return varchar2 is
  ln_count number;
BEGIN

    if pkg_musteri_gizle.is_user_authorized(pkg_baglam.kullanici_kodu) = 'E'
    then
        return 'H';
    end if;

    select count(*)
    into ln_count
    from cbs_fis a, cbs_satir b
    where a.numara=b.fis_numara
    and a.islem_numara=pn_islem_no
    and hesap_tur_kodu <> 'DK'
    and PKG_MUSTERI_GIZLE.MUSTERI_GIZLENSIN_MI(pkg_hesap.hesaptanmusterinoal(hesap_numara)) = 'E';

    if nvl(ln_count,0)<>0 then
        return 'E';
    else
        return 'H';
    end if;

END;


-- Returns a message which is shown when current CBS user is not authorized to view hidden customer accounts
FUNCTION not_authorized_message return varchar2 is
    lc_error_message CBS_HATA_MESAJLARI.MESAJ_TEXT%TYPE;
BEGIN

        select MESAJ_TEXT into lc_error_message 
        from cbs_hata_mesajlari 
        where hata_no = 999998 and dil = 'ENGLISH';
        
       return lc_error_message;     
    
    EXCEPTION
        WHEN OTHERS THEN
         return 'You are not authorized to view hidden customer account details!!';
END;

 END pkg_musteri_gizle;
/

