create PACKAGE     PKG_TX1616 IS

 /******************************************************************************
   Name       : PKG_TX1616
   Created By : Andrei Dubov
   Date          : 05.02.19
   Purpose      : Cash Exchange between Local Banks
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );

  Procedure Bakiye_Kontrol(pn_islem_no number);
  procedure iptal_edilebilir_mi(pn_islem_no  number);
  Function sf_istatistik_kod_uygunmu(ps_istatistik_kodu varchar2) return varchar2;

  Function sf_istatistik_kod_zorunlumu(ps_choice varchar2, ps_doviz varchar2) return varchar2;

END;
/

