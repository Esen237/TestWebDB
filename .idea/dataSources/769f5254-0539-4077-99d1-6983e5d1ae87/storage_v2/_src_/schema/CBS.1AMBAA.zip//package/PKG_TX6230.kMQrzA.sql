create PACKAGE     "PKG_TX6230" IS

  /******************************************************************************
   Name       : Pkg_Tx6230
   Created By : Hakan Samsa
   Purpose      : Account Product & Branch Change
  ******************************************************************************/
  FUNCTION Modul_Tur_Uygun_mu(ps_modul  VARCHAR2) RETURN VARCHAR2;
  FUNCTION Urun_Tur_Uygun_mu(ps_modul  VARCHAR2,ps_urun  VARCHAR2) RETURN VARCHAR2;
  FUNCTION Urun_Sinif_Uygun_mu(ps_modul  VARCHAR2,ps_urun  VARCHAR2, ps_sinif VARCHAR2) RETURN VARCHAR2 ;
  FUNCTION Hesap_Ana_DK_al(pn_hesap_no  NUMBER) RETURN VARCHAR2 ;
  FUNCTION get_interest_gl(pn_hesap_no  NUMBER) RETURN VARCHAR2 ; --aisuluud cq5721
  FUNCTION get_loan_pastdue_type(pn_hesap_no  NUMBER) RETURN VARCHAR2; --aisuluud cq5721
  PROCEDURE Hata_Kontrolleri(pn_islem_no NUMBER) ;
  FUNCTION Hesap_Kredi_Teklif_Satirno_al(pn_hesap_no  NUMBER) RETURN NUMBER;
  FUNCTION Hesap_urun_grup_no_al(pn_teklif_satir_no   NUMBER) RETURN NUMBER ;
  FUNCTION Faiz_Tahakkuk_Hesap_No_al(pn_hesap_no  NUMBER) RETURN NUMBER ;
  FUNCTION Vergi_Tahakkuk_Hesap_No_al(pn_hesap_no  NUMBER) RETURN NUMBER ;

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);     -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);    -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);        -- Islem iptal edildikten sonra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);        -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);    -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);        -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);      -- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);        -- Islemin muhasebelesmesi icin cagrilir

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
  FUNCTION Bitmemis_islem_var_mi(pn_hesap_no  NUMBER) RETURN NUMBER ;
END;
/

