create PACKAGE PKG_MIS is

  FUNCTION GetITRRate(ps_DOVIZKODU varchar2,ps_INTERESTTYPE varchar2) RETURN NUMBER;
  FUNCTION CalculateDayDifference(pd_today date) RETURN NUMBER;
  FUNCTION GetAverageBalance(ps_type varchar2,pn_hesapno number,pd_today date) RETURN NUMBER;

  FUNCTION SumOfCurrentDeposits(pn_MUSTERINO NUMBER,ps_DOVIZKODU varchar2,pd_today date ) RETURN NUMBER;
  FUNCTION SumOfTimeDeposits(pn_MUSTERINO NUMBER,ps_DOVIZKODU varchar2,pd_today date ) RETURN NUMBER;
  FUNCTION SumOfLoans(pn_MUSTERINO NUMBER,ps_DOVIZKODU varchar2,pd_today date ) RETURN NUMBER;

  FUNCTION CalcCurrentDepositInterest(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER;
  FUNCTION CalcTimeDepositInterest(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER;
  FUNCTION CalcLoanInterest(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER;
  FUNCTION CalcITRInterest(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER;

  FUNCTION CalcCustFXProfit(pn_MUSTERINO NUMBER,pd_today date ) RETURN NUMBER;

  Procedure CreateMISReport(pd_today date );

END PKG_MIS;

/

