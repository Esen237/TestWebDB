create PACKAGE BODY     pkg_creditbureau IS

  function GetCountryCode(pn_COUNTRY_CODE VARCHAR2) return number
  is
    result number;
  begin
    select country_id
	  into result
	  from cbs_cb_countries
	 where country_code = pn_COUNTRY_CODE;
	return result;
  exception
    when others then
	  return 110;
  end;

  function GetCollaterals(pn_musteri_no number) return varchar2
  is
    result varchar2(3000);
  begin
    result := '<collateralrecords>';  --chr(10);
    for recin in (  select ' <collateral>'  ||
                    	   '  <collateraltypeid>' || case when b.ANA_TEMINAT_KODU = 2 and b.DETAY_TEMINAT_KODU = 2 then 14
                    	   						   		when b.ANA_TEMINAT_KODU = 2 and b.DETAY_TEMINAT_KODU = 6 then 11
                    									when b.ANA_TEMINAT_KODU = 2 and b.DETAY_TEMINAT_KODU = 7 then 11
                    									when b.ANA_TEMINAT_KODU = 2 and b.DETAY_TEMINAT_KODU = 3 then 7
                    									when b.ANA_TEMINAT_KODU = 2 and b.DETAY_TEMINAT_KODU = 1 then 2
                    									when b.ANA_TEMINAT_KODU = 2 and b.DETAY_TEMINAT_KODU = 4 then 2
                    									when b.ANA_TEMINAT_KODU = 2 and b.DETAY_TEMINAT_KODU = 5 then 11
                    									when b.ANA_TEMINAT_KODU = 3 and b.DETAY_TEMINAT_KODU = 2 then 12
                    									when b.ANA_TEMINAT_KODU = 3 and b.DETAY_TEMINAT_KODU = 1 then 13
                    									when b.ANA_TEMINAT_KODU = 4 and b.DETAY_TEMINAT_KODU = 0 then 11
                    									when b.ANA_TEMINAT_KODU = 4 and b.DETAY_TEMINAT_KODU = 2 then 6
                    									when b.ANA_TEMINAT_KODU = 4 and b.DETAY_TEMINAT_KODU = 4 then 6
                    									when b.ANA_TEMINAT_KODU = 4 and b.DETAY_TEMINAT_KODU = 3 then 7
                    									when b.ANA_TEMINAT_KODU = 4 and b.DETAY_TEMINAT_KODU = 1 then 3
                    									when b.ANA_TEMINAT_KODU = 5 and b.DETAY_TEMINAT_KODU = 5 then 5
                    									when b.ANA_TEMINAT_KODU = 6 and b.DETAY_TEMINAT_KODU = 6 then 6
                    									when b.ANA_TEMINAT_KODU = 9 and b.DETAY_TEMINAT_KODU = 9 then 14
                    									when b.ANA_TEMINAT_KODU = 10 and b.DETAY_TEMINAT_KODU = 10 then 14
                    									when b.ANA_TEMINAT_KODU = 12 and b.DETAY_TEMINAT_KODU = 12 then 10
                    									when b.ANA_TEMINAT_KODU = 13 and b.DETAY_TEMINAT_KODU = 1 then 13
                    									when b.ANA_TEMINAT_KODU = 13 and b.DETAY_TEMINAT_KODU = 2 then 13
                    									when b.ANA_TEMINAT_KODU = 14 and b.DETAY_TEMINAT_KODU = 1 then 14
                    									when b.ANA_TEMINAT_KODU = 14 and b.DETAY_TEMINAT_KODU = 2 then 14
                    									when b.ANA_TEMINAT_KODU = 14 and b.DETAY_TEMINAT_KODU = 3 then 14
                    									when b.ANA_TEMINAT_KODU = 14 and b.DETAY_TEMINAT_KODU = 4 then 14
                    									when b.ANA_TEMINAT_KODU = 14 and b.DETAY_TEMINAT_KODU = 5 then 14
                    									when b.ANA_TEMINAT_KODU = 16 and b.DETAY_TEMINAT_KODU = 16 then 14
                    									else 14
                    								end || '</collateraltypeid>' ||
                    	   '  <value>' || b.TUTAR || '</value>' ||
                    	   '  <valuetypeid>3</valuetypeid>' ||
                    	   ' </collateral>' data
                      from cbs_teminat a,
                      	   CBS_KREDI_TEMINAT_TANIM b
                     where a.teklif_musteri_no = 4404 and
                     	   a.MUSTERI_NO = b.MUSTERI_NO) loop
      result := result || recin.data; --|| chr(10);
    end loop;
	result := result || '</collateralrecords>'; --|| chr(10);
    return result;
  end;

  function GetXMLdata(pn_hesap_no number) return varchar2
  is
    XMLdata varchar2(5000);
  begin
        select '<contractcode>'||a.hesap_no || '</contractcode>' ||
        	   '<fundingtypeid>'||case
                when a.URUN_TUR_KOD = 'DEPO'       THEN 10
        		when a.URUN_TUR_KOD = 'EXPORT L/C' THEN 7
        		when a.URUN_TUR_KOD = 'FACTORING'  THEN 3
        		when a.URUN_TUR_KOD = 'FORFEITING' THEN 4
        		when a.URUN_TUR_KOD = 'ISSUED GR.' THEN 8
        		when a.URUN_TUR_KOD = 'L/G'        THEN 8
        		when a.URUN_TUR_KOD = 'LEASING'    THEN 5
        		when a.URUN_TUR_KOD IN ('LOAN GIVEN', 'LONG TERM', 'MED.TERM', 'OTHERS', 'PD-LN.TERM', 'PD-OTHER', 'PD-SH.TERM', 'RT-LN.TERM', 'RT-OTHER', 'RT-SH.TERM', 'SHORT TERM') THEN 2
        		when a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('FACTORING-FC', 'FACTORING-LC') THEN 3
        		when a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('FORFEITING-FC', 'FORFEITING-LC') THEN 4
        		when a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('LEASING-FC', 'LEASING-LC') THEN 5
        		when a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('LONG TERM-FC', 'LONG TERM-LC', 'MED.TERM-FC', 'MED.TERM-LC', 'OTHER-FC', 'OTHERS-LC', 'SHORT TERM-FC', 'SHORT TERM-LC') THEN 2
        		when a.URUN_TUR_KOD IN ('PD-CR.CARD', 'RT-CR.CARD') THEN 9
        		when a.URUN_TUR_KOD IN ('PD-OVRDRWN', 'RT-OVRDRWN') THEN 1
        	   end || '</fundingtypeid>' ||
        	   '<creditpurposeid>' || case
        	    when a.kredi_kullandirim_kodu = 10 THEN 1
        		when a.kredi_kullandirim_kodu = 11 THEN 2
        		when a.kredi_kullandirim_kodu = 12 THEN 3
        		when a.kredi_kullandirim_kodu = 14 THEN 3
        		when a.kredi_kullandirim_kodu = 15 THEN
        		  case
        			when a.URUN_SINIF_KOD LIKE 'CAR%' 	 THEN 5
        			else 6
        		  end
        		when a.kredi_kullandirim_kodu = 17 THEN 2
        		when a.kredi_kullandirim_kodu = 20 THEN 6
        		else 6
        	   end || '</creditpurposeid>' ||
        	   '<contractphaseid>' || decode(a.DURUM_KODU, 'A', 4, 5) || '</contractphaseid>' ||
               '<contractstatusid>' || nvl(a.CONTRACT_STATUS,1) || '</contractstatusid>' ||
               '<currency>' || a.DOVIZ_KODU || '</currency>' ||
        	   '<creditstartdate>' || to_char(a.ACILIS_TARIHI, 'yyyy-mm-dd') || '</creditstartdate>'  ||
        	   '<contractenddate>' || to_char(nvl(a.KREDI_VADE,sysdate), 'yyyy-mm-dd') || '</contractenddate>' ||
        	   '<classification>classification</classification>' ||
        	   '<subjectrecords>' ||
        	   '<subject>' ||
        	   '<entity>' ||
			   decode(pkg_musteri.sf_musteri_tipi_al(a.MUSTERI_NO), 1,
        	   '<individual>' ||
        	   '<firstname>' || b.isim || '</firstname>' ||
        	   '<surname>' || b.SOYADI || '</surname>' ||
        	   '<fathersname>' || b.SOYADI || '</fathersname>' ||
        	   '<gender>' || b.CINSIYET_KOD || '</gender>' ||
        	   '<classificationid>' ||decode(c.islem_kod, '3250', 1, 2) || '</classificationid>' ||
        	   '<residencyid>' || b.YERLESIM_KOD || '</residencyid>' ||
        	   '<dateofbirth>' || to_char(b.DOGUM_TARIHI, 'yyyy-mm-dd') || '</dateofbirth>' ||
			   '<citizenshipid>1</citizenshipid>'  ||
               '<addressrecord>'  ||
        	   '<address>'  ||
         	   '<streetname>' || substr(pkg_musteri.sf_adres_al(a.MUSTERI_NO), 1, 30) || '</streetname>' ||
        	   '<cityid>675</cityid>'  ||
        	   '<addresstypeid>1</addresstypeid>' ||
        	   '</address>'  ||
        	   '</addressrecord>'  ||
               '<identificationrecord>'  ||
        	   '<identification>' ||
               '<number>' || nvl(b.NUFUS_CUZDANI_SERI_NO, '0') || '</number>' ||
        	   '<rankid>2</rankid>' ||
        	   '<identificationtypeid>' || decode(b.KIMLIK_KOD, 1, 7, 3, 6, 6) || '</identificationtypeid>' ||
        	   '<registrationdate>' || to_char(nvl(b.VERILDIGI_TARIH, sysdate), 'yyyy-mm-dd') || '</registrationdate>' ||
        	   '</identification>'   ||
        	   '<identification>' ||
               '<number>' || nvl(b.VERGI_NO, '0') || '</number>' ||
        	   '<rankid>1</rankid>' ||
        	   '<identificationtypeid>1</identificationtypeid>' ||
        	   '<registrationdate>' || to_char(nvl(b.VERILDIGI_TARIH, sysdate), 'yyyy-mm-dd') || '</registrationdate>' ||
        	   '</identification>'   ||
        	   '<identification>' ||
               '<number>' || nvl(b.BIC_KOD, '0') || '</number>' ||
        	   '<rankid>2</rankid>' ||
        	   '<identificationtypeid>2</identificationtypeid>' ||
        	   '<registrationdate>' || to_char(nvl(b.VERILDIGI_TARIH,sysdate), 'yyyy-mm-dd') || '</registrationdate>' ||
        	   '</identification>'   ||
        	   '<identification>' ||
               '<number>1</number>' ||
        	   '<rankid>2</rankid>' ||
        	   '<identificationtypeid>9</identificationtypeid>' ||
        	   '<registrationdate>' || to_char(nvl(b.VERILDIGI_TARIH,sysdate), 'yyyy-mm-dd') || '</registrationdate>' ||
        	   '</identification>'   ||
        	   '</identificationrecord>'  ||
        	   '</individual>',
	   '   <company>' ||
	   '    <name>' || substr(b.TICARI_UNVAN,1,50) || '</name>' ||
	   '    <statusid>1</statusid>' ||
	   '    <tradename>' || substr(b.TICARI_UNVAN,1,30) || '</tradename>' ||
	   '    <abbrevationoftradename>' || substr(b.TICARI_UNVAN,1,30) || '</abbrevationoftradename>' ||
	   '    <legalformid>16</legalformid>' ||
	   '    <nationalityid>' || GetCountryCode(b.UYRUK_KOD) || '</nationalityid>' ||
       '    <addressrecord>'  ||
	   '     <address>'  ||
 	   '      <streetname>' || substr(nvl(pkg_musteri.sf_adres_al(a.MUSTERI_NO), '1'),1,30) || '</streetname>' ||
	   '      <cityid>27</cityid>'  ||
	   '      <addresstypeid>1</addresstypeid>' ||
	   '     </address>'  ||
	   '    </addressrecord>'  ||
       '    <identificationrecord>'  ||
	   '     <identification>' ||
       '      <number>' || nvl(b.NUFUS_CUZDANI_SERI_NO, '1') || '</number>' ||
	   '      <rankid>2</rankid>' ||
	   '      <identificationtypeid>' || decode(b.KIMLIK_KOD, 1, 7, 3, 6, 6) || '</identificationtypeid>' ||
	   '      <registrationdate>' || to_char(nvl(b.VERILDIGI_TARIH,sysdate), 'yyyy-mm-dd') || '</registrationdate>' ||
	   '     </identification>'   ||
	   '     <identification>' ||
       '      <number>' || nvl(b.VERGI_NO, '1') || '</number>' ||
	   '      <rankid>1</rankid>' ||
	   '      <identificationtypeid>1</identificationtypeid>' ||
	   '      <registrationdate>' || to_char(nvl(b.VERILDIGI_TARIH,sysdate), 'yyyy-mm-dd') || '</registrationdate>' ||
	   '     </identification>'   ||
	   '     <identification>' ||
       '      <number>' || nvl(b.BIC_KOD, '1') || '</number>' ||
	   '      <rankid>2</rankid>' ||
	   '      <identificationtypeid>2</identificationtypeid>' ||
	   '      <registrationdate>' || to_char(nvl(b.VERILDIGI_TARIH,sysdate), 'yyyy-mm-dd') || '</registrationdate>' ||
	   '     </identification>'   ||
	   '     <identification>' ||
       '      <number>1</number>' ||
	   '      <rankid>2</rankid>' ||
	   '      <identificationtypeid>9</identificationtypeid>' ||
	   '      <registrationdate>1999-12-30</registrationdate>' ||
	   '     </identification>'   ||
	   '    </identificationrecord>'  ||
	   '   </company>') ||
        	   '</entity>' ||
        	   '<subjectroleid>1</subjectroleid>' ||
        	   '</subject>' ||
        	   '</subjectrecords>' ||
        	   '<typeofpp>' ||
			     '<instalment>' ||
				 '   <totalamount>' || nvl(e.total, '0') || '</totalamount>' ||
			     '<records>' ||
			     ' <recorditem>' ||
				 '   <accountingdate>' || to_char(nvl(e.account_date, sysdate), 'yyyy-mm-dd') || '</accountingdate>' ||
				 ' </recorditem>' ||
				 '</records>' ||
				 '</instalment>' ||
        	   '</typeofpp>' ||
        	   pkg_creditbureau.GetCollaterals(b.MUSTERI_NO) data
		  into XMLdata
          from cbs_hesap_KREDI A,
          	   cbs_musteri b,
               (select a1.hesap_no,
                	   b1.ISLEM_KOD
                  from (select hesap_no,
                        	   min(tx_no) tx_no
                          from cbs_hesap_kredi_islem
                         group by hesap_no) a1,
                		cbs_islem b1
                 where a1.TX_NO = b1.NUMARA) c,
        	   --CBS_VW_BIREY_KREDI_TAKSITTOPLA d,
			   (select hesap_no,
	   		   		   trunc(min(yaratildigi_tarih)) account_date,
	   				   sum(nvl(anapara,0)) + sum(nvl(faiz, 0)) total
                  from CBS_VW_KREDI_HESAP_TAKSIT
                 group by hesap_no) e
         where a.HESAP_NO = pn_hesap_no and
         	   a.MUSTERI_NO = b.musteri_no and
         	   a.HESAP_NO = c.hesap_no(+) and
			   a.HESAP_NO = e.hesap_no(+) and
        	   --d.hesap_no = a.HESAP_NO and
         	   (
                (a.URUN_TUR_KOD = 'DEPO'       and a.URUN_SINIF_KOD IN ('CONDITIONAL DEP-FC', 'CONDITIONAL DEP-LC')) OR
        		(a.URUN_TUR_KOD = 'EXPORT L/C' and a.URUN_SINIF_KOD IN ('CONFIRMED L/C-FC', 'CONFIRMED L/C-LC')) OR
        		(a.URUN_TUR_KOD = 'FACTORING'  and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'FORFEITING' and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'ISSUED GR.' and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'L/G' 		 and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'LEASING'	 and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD IN ('LOAN GIVEN', 'LONG TERM', 'MED.TERM', 'OTHERS', 'PD-LN.TERM', 'PD-OTHER', 'PD-SH.TERM', 'RT-LN.TERM', 'RT-OTHER', 'RT-SH.TERM', 'SHORT TERM')) OR
        		(a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('FACTORING-FC', 'FACTORING-LC')) OR
        		(a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('FORFEITING-FC', 'FORFEITING-LC')) OR
        		(a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('LEASING-FC', 'LEASING-LC')) OR
        		(a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('LONG TERM-FC', 'LONG TERM-LC', 'MED.TERM-FC', 'MED.TERM-LC', 'OTHER-FC', 'OTHERS-LC', 'SHORT TERM-FC', 'SHORT TERM-LC')) OR
        		(a.URUN_TUR_KOD = 'PD-CR.CARD' and a.URUN_SINIF_KOD IN ('CR.CARDS-FC', 'CR.CARDS-LC')) OR
        		(a.URUN_TUR_KOD = 'PD-OVRDRWN' and a.URUN_SINIF_KOD IN ('OVERDRAWN-FC', 'OVERDRAWN-LC')) OR
        		(a.URUN_TUR_KOD = 'RT-CR.CARD' and a.URUN_SINIF_KOD IN ('CR.CARDS-FC', 'CR.CARDS-LC')) OR
        		(a.URUN_TUR_KOD = 'RT-OVRDRWN' and a.URUN_SINIF_KOD IN ('OVERDRAWN-FC', 'OVERDRAWN-LC'))
        	   );
    return XMLdata;
  end;

  procedure SendInformation(pn_hesap_no number, pn_operation number)
  is
    lp_batch_id number;
    XMLdata VARCHAR2(30000);
	lc_Result VARCHAR2(30000);
	lc_begin NUMBER;
	lc_end	 NUMBER;
	lc_begin_valid NUMBER;
	dest_name VARCHAR2(100);
	block_id varchar2(2);
	SEND_URL varchar2(32000):='https://212.154.146.195/Webservice/DataPump/DataPumpService.asmx/UploadStringData?username=DMRuser01'||'&' || 'password=Kazteleport2030'||'&' || 'xmlData=##XML_DOC##'||'&' || 'schemaVersion=1,0';
  
    /*BOM SURMALII 05.06.2018*/
    ls_content CLOB;
    ls_json CLOB;
    ls_ret varchar2(3);
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    /*EOM*/
  begin
    block_id := '01';
    dest_name := 'max@demirbank.kz';/*'ITgroup@demirbank.kz' */
	block_id := '02';
    XMLdata := '<records xmlns="http://www.datapump.cig.com" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xs:schemaLocation="http://www.datapump.cig.com datapump-pp-1.0.xsd">' || '<pp operation="' || pn_operation || '">' || trim(getXMLdata(pn_hesap_no)) || '</pp></records>';
	block_id := '03';
	SEND_URL := replace(SEND_URL, '##XML_DOC##', XMLdata);
	block_id := '04';
	SEND_URL := replace(SEND_URL, ' ', '%20');
	block_id := '05';
	lc_result:=utl_http.request(SEND_URL,null,'file:C:\WALLET','manager123');
	block_id := '06';
	block_id := '07';
	lc_begin := instr(lc_result, 'batch id');
	if lc_begin <> 0 then
	  block_id := '09';
	  lc_end   := instr(lc_result, 'statusid');
	  block_id := '10';
	  lp_batch_id := to_number(substr(lc_result, lc_begin+10, (lc_end - lc_begin)-12));
	  block_id := '11';
	  update CBS_CB_LOAD set STATUS_ID = 0, BATCH_ID = lp_batch_id, OPERATION_NO = 2 where account_no = pn_hesap_no;
	  block_id := '12';
	  COMMIT;
	else
      ls_content := substr('Send url:' || '<BR />' || SEND_URL || '<BR />' || 'Result:' || '<BR />' || lc_result, 1, 4000);
      ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
      ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(13), '<BR/>');
      ls_content:=replace(ls_content, '"', '''''');
      ------------------------------------------------------------
	  --pkg_email.AddToEmailQueue('CREDIT BUREAU', 50, 'info@demirbank.kz', dest_name, 'CREDIT BUREAU SendInformation. Error: Batch id not found.  Account = ' || pn_hesap_no, substr('Send url: ' || chr(10) || SEND_URL || chr(10) || chr(10) || 'Result:' || chr(10) || lc_result, 1, 4000),'TEXT');
      /*BOM SURMALII 05.06.2018*/
      ls_json := '{';
      ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
      ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(dest_name, 'CREDIT BUREAU SendInformation. Error: Batch id not found.  Account = ' || pn_hesap_no, to_char(ls_json), pc_ref);
      /*EOM*/
    end if;
  exception
    when others then
	  ROLLBACK;
      ls_content := substr('Error message: ' || '<BR />' || sqlerrm || '<BR />' || 'Send url: ' || '<BR />' || SEND_URL || '<BR />' || 'Result: ' || '<BR />' || lc_result, 1, 4000);
	  ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
      ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(13), '<BR/>');
      ls_content:=replace(ls_content, '"', '''''');
      ------------------------------------------------------------
      --pkg_email.AddToEmailQueue('CREDIT BUREAU', 50, 'info@demirbank.kz', dest_name, 'CREDIT BUREAU SendInformation. Error: Block = ' || block_id || '.  Account = ' || pn_hesap_no, substr('Error message:' || chr(10) || sqlerrm || chr(10) || chr(10) || 'Send url: ' || chr(10) || SEND_URL || chr(10) || chr(10) || 'Result:' || chr(10) || lc_result, 1, 4000),'TEXT');
      /*BOM SURMALII 05.06.2018*/
      ls_json := '{';
      ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
      ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(dest_name, 'CREDIT BUREAU SendInformation. Error: Block = ' || block_id || '.  Account = ' || pn_hesap_no, to_char(ls_json), pc_ref);
      /*EOM*/
  end;

  procedure CheckInformation(pn_hesap_no number, pn_batch_id number)
  is
	lc_Result VARCHAR2(30000);
	lc_begin NUMBER;
	lc_end	 NUMBER;
	lc_status NUMBER;
	lc_begin_valid NUMBER;
	dest_name VARCHAR2(100);
	CHECK_URL varchar2(2000);
	block_id varchar2(2);
    
    /*BOM SURMALII 05.06.2018*/
    ls_content CLOB;
    ls_json CLOB;
    ls_ret varchar2(3);
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    /*EOM*/
  begin
    block_id := '01';
    dest_name := 'max@demirbank.kz';/*'ITgroup@demirbank.kz'  */
	block_id := '02';
	CHECK_URL := 'https://212.154.146.195/Webservice/DataPump/DataPumpService.asmx/GetBatchStatus?username=DMRuser01'||'&' || 'password=Kazteleport2030'||'&' || 'batchId=' || pn_batch_id;
	block_id := '03';
	lc_result:=utl_http.request(CHECK_URL,null,'file:C:\WALLET','manager123');
	block_id := '04';

	lc_begin_valid := instr(lc_result, '<validrecords>');
	block_id := '05';
	if substr(lc_result, lc_begin_valid+14, 1) = '1' then /*ok*/
	  block_id := '06';
	  lc_begin := instr(lc_result, 'statusid');
	  block_id := '07';
	  lc_end   := instr(lc_result, 'statusname');
	  block_id := '08';
	  lc_status := to_number(substr(lc_result, lc_begin+10, (lc_end - lc_begin)-12));
	  block_id := '09';
	  update CBS_CB_LOAD set STATUS_ID = lc_status where account_no = pn_hesap_no;
	  block_id := '10';
	  COMMIT;
	  if lc_status in (5,6) then
	    block_id := '11';
        ls_content := substr('Check url: ' || '<BR />' || CHECK_URL || '<BR />' || 'Result: ' || '<BR />' || lc_result,1,4000);
        ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
        ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
        ls_content:=replace(ls_content, chr(10), '<BR/>');
        ls_content:=replace(ls_content, chr(13), '<BR/>');
        ls_content:=replace(ls_content, '"', '''''');
        ------------------------------------------------------------
	    --pkg_email.AddToEmailQueue('CREDIT BUREAU', 50, 'info@demirbank.kz', dest_name, 'CREDIT BUREAU Check Information. Error: Status id = ' || lc_status || '. Account = ' || pn_hesap_no || '. Batch id = ' || pn_batch_id, substr('Check url:' || chr(10) || CHECK_URL || chr(10) ||chr(10) || 'Result:'|| chr(10) || lc_result,1,4000),'TEXT');
	    /*BOM SURMALII 05.06.2018*/
        ls_json := '{';
        ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
        ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(dest_name, 'CREDIT BUREAU Check Information. Error: Status id = ' || lc_status || '. Account = ' || pn_hesap_no || '. Batch id = ' || pn_batch_id, to_char(ls_json), pc_ref);
        /*EOM*/
      end if;
	else
	  block_id := '12';
      ls_content := substr('Check url: ' || '<BR />' || CHECK_URL || '<BR />' || 'Result: ' || '<BR />' || lc_result,1,4000);
      ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
      ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(13), '<BR/>');
      ls_content:=replace(ls_content, '"', '''''');
      ------------------------------------------------------------
	  --pkg_email.AddToEmailQueue('CREDIT BUREAU', 50, 'info@demirbank.kz', dest_name, 'CREDIT BUREAU Check Information. Error: Validrecords = 0 Error. Account = ' || pn_hesap_no || '. Batch id ' || pn_batch_id, substr('Check url:' || chr(10) || CHECK_URL || chr(10) ||chr(10) || 'Result:'|| chr(10) || lc_result,1,4000),'TEXT');
      /*BOM SURMALII 05.06.2018*/
      ls_json := '{';
      ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
      ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(dest_name, 'CREDIT BUREAU Check Information. Error: Validrecords = 0 Error. Account = ' || pn_hesap_no || '. Batch id ' || pn_batch_id, to_char(ls_json), pc_ref);
      /*EOM*/
      block_id := '13';
	  if substr(lc_Result, 'Execute failed to return a value --> problem in find ') = 0 then
	    UPDATE CBS_CB_LOAD set STATUS_ID = NULL where account_no = pn_hesap_no;
 	    block_id := '14';
	    COMMIT;
	  end if;
	end if;
  exception
    when others then
	  ROLLBACK;
      ls_content := substr('Error message: ' || '<BR />' || sqlerrm  || '<BR />' || 'Check url: ' || '<BR />' || CHECK_URL || 'Result: ' || '<BR />' || lc_result,1,4000);
      ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
      ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(10), '<BR/>');
      ls_content:=replace(ls_content, chr(13), '<BR/>');
      ls_content:=replace(ls_content, '"', '''''');
      ------------------------------------------------------------
	  --pkg_email.AddToEmailQueue('CREDIT BUREAU', 50, 'info@demirbank.kz', dest_name, 'CREDIT BUREAU Check Information. Error: Block id = ' || block_id || '. Account = ' || pn_hesap_no || '. Batch id = ' || pn_batch_id, substr('Error message: ' || sqlerrm  || '  Check url: ' || CHECK_URL || '  Result: ' || lc_result,1,4000),'TEXT');
      /*BOM SURMALII 05.06.2018*/
      ls_json := '{';
      ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
      ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(dest_name, 'CREDIT BUREAU Check Information. Error: Block id = ' || block_id || '. Account = ' || pn_hesap_no || '. Batch id = ' || pn_batch_id, to_char(ls_json), pc_ref);
      /*EOM*/
  end; 


  procedure RunSender
  is
  begin
/*
        DELETE
          FROM CBS_CB_LOAD
         WHERE ACCOUNT_NO NOT IN (
                SELECT A.HESAP_NO
                  from cbs_hesap_KREDI A
                 WHERE ((a.URUN_TUR_KOD = 'DEPO'       and a.URUN_SINIF_KOD IN ('CONDITIONAL DEP-FC', 'CONDITIONAL DEP-LC')) OR
                		(a.URUN_TUR_KOD = 'EXPORT L/C' and a.URUN_SINIF_KOD IN ('CONFIRMED L/C-FC', 'CONFIRMED L/C-LC')) OR
                		(a.URUN_TUR_KOD = 'FACTORING'  and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
                		(a.URUN_TUR_KOD = 'FORFEITING' and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
                		(a.URUN_TUR_KOD = 'ISSUED GR.' and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
                		(a.URUN_TUR_KOD = 'L/G' 	   and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
                		(a.URUN_TUR_KOD = 'LEASING'	   and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
                		(a.URUN_TUR_KOD IN ('LOAN GIVEN', 'LONG TERM', 'MED.TERM', 'OTHERS', 'PD-LN.TERM', 'PD-OTHER', 'PD-SH.TERM', 'RT-LN.TERM', 'RT-OTHER', 'RT-SH.TERM', 'SHORT TERM')) OR
                		(a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('FACTORING-FC', 'FACTORING-LC', 'FORFEITING-FC', 'FORFEITING-LC', 'LEASING-FC', 'LEASING-LC', 'LONG TERM-FC', 'LONG TERM-LC', 'MED.TERM-FC', 'MED.TERM-LC', 'OTHER-FC', 'OTHERS-LC', 'SHORT TERM-FC', 'SHORT TERM-LC')) OR
                		(a.URUN_TUR_KOD = 'PD-CR.CARD' and a.URUN_SINIF_KOD IN ('CR.CARDS-FC', 'CR.CARDS-LC')) OR
                		(a.URUN_TUR_KOD = 'PD-OVRDRWN' and a.URUN_SINIF_KOD IN ('OVERDRAWN-FC', 'OVERDRAWN-LC')) OR
                		(a.URUN_TUR_KOD = 'RT-CR.CARD' and a.URUN_SINIF_KOD IN ('CR.CARDS-FC', 'CR.CARDS-LC')) OR
                		(a.URUN_TUR_KOD = 'RT-OVRDRWN' and a.URUN_SINIF_KOD IN ('OVERDRAWN-FC', 'OVERDRAWN-LC')))
        				);
        INSERT INTO CBS_CB_LOAD
        SELECT A.HESAP_NO, NULL, 1, NULL
          from cbs_hesap_KREDI A
         WHERE ((a.URUN_TUR_KOD = 'DEPO'       and a.URUN_SINIF_KOD IN ('CONDITIONAL DEP-FC', 'CONDITIONAL DEP-LC')) OR
        		(a.URUN_TUR_KOD = 'EXPORT L/C' and a.URUN_SINIF_KOD IN ('CONFIRMED L/C-FC', 'CONFIRMED L/C-LC')) OR
        		(a.URUN_TUR_KOD = 'FACTORING'  and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'FORFEITING' and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'ISSUED GR.' and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'L/G' 	   and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD = 'LEASING'	   and a.URUN_SINIF_KOD IN ('FC', 'LC')) OR
        		(a.URUN_TUR_KOD IN ('LOAN GIVEN', 'LONG TERM', 'MED.TERM', 'OTHERS', 'PD-LN.TERM', 'PD-OTHER', 'PD-SH.TERM', 'RT-LN.TERM', 'RT-OTHER', 'RT-SH.TERM', 'SHORT TERM')) OR
        		(a.URUN_TUR_KOD = 'PAST DUE'	 and a.URUN_SINIF_KOD IN ('FACTORING-FC', 'FACTORING-LC', 'FORFEITING-FC', 'FORFEITING-LC', 'LEASING-FC', 'LEASING-LC', 'LONG TERM-FC', 'LONG TERM-LC', 'MED.TERM-FC', 'MED.TERM-LC', 'OTHER-FC', 'OTHERS-LC', 'SHORT TERM-FC', 'SHORT TERM-LC')) OR
        		(a.URUN_TUR_KOD = 'PD-CR.CARD' and a.URUN_SINIF_KOD IN ('CR.CARDS-FC', 'CR.CARDS-LC')) OR
        		(a.URUN_TUR_KOD = 'PD-OVRDRWN' and a.URUN_SINIF_KOD IN ('OVERDRAWN-FC', 'OVERDRAWN-LC')) OR
        		(a.URUN_TUR_KOD = 'RT-CR.CARD' and a.URUN_SINIF_KOD IN ('CR.CARDS-FC', 'CR.CARDS-LC')) OR
        		(a.URUN_TUR_KOD = 'RT-OVRDRWN' and a.URUN_SINIF_KOD IN ('OVERDRAWN-FC', 'OVERDRAWN-LC'))) AND
               A.HESAP_NO NOT IN (SELECT ACCOUNT_NO FROM CBS_CB_LOAD);
    commit;
*/
/*
    for recin in (select account_no, operation_no
	                 from cbs_cb_load
					where status_id is null) loop
      SendInformation(recin.account_no, recin.operation_no);
    end loop;
	*/

    for recin in (select account_no, batch_id
	                 from cbs_cb_load
					where batch_id is not null  and (status_id in (0,1,2,3) or status_id is null)) loop -- status_id <> 4) loop
      CheckInformation(recin.account_no, recin.batch_id);
    end loop;


  end;

END;
/

