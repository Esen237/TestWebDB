create package body PKG_REPORT7 is




  function GET_GL_ACIKLAMA(DK_KODU_ CBS_DKHESAP.DK_KOD%TYPE, LANG_KODU_ CBS_DKHESAP_DEFINITION.LANG_KODU%TYPE) return VARCHAR2
  is
    result CBS_DKHESAP_DEFINITION.DESCRIPTION%TYPE;
	len    NUMBER;
  begin
    len := LENGTH(DK_KODU_);
	select MAX(A.DESCRIPTION)
	  into result
	  from cbs_dkhesap_definition a
	 where a.DK_KODU = DK_KODU_ and
		   a.LANG_KODU = 'RUS';
    return result;
  exception
    when others then
	  begin
   	    select MAX(A.DESCRIPTION)
   	      into result
   	      from cbs_dkhesap_definition a
   	     where substr(a.DK_KODU, 1, len) = DK_KODU_ and
   		       a.LANG_KODU = 'RUS';
	    return result;
	  exception
	    when others then
		  return '';
	  end;

  end;


  function GET_AVERAGE_BAKIYE(DATE_ DATE, NUMARA_ VARCHAR2, DOVIZ_KOD_ VARCHAR2, TYPE_ VARCHAR2/*FC, LC*/) RETURN NUMBER
  is
    result number;
  begin
    if TYPE_ = 'LC' then
        select a.ortalama_bakiye*c.DVZALIS
		  into result
          from CBS_DKHESAP_YILORTALAMA_BAKIYE a,
        	   CBS_MBKURLOG c
         where to_date(to_char(a.GUN, '00')||to_char(a.AY, '00')||to_char(a.YIL, '0000'), 'ddmmyyyy') = DATE_ and
        	   a.DOVIZ_KOD = DOVIZ_KOD_ and
        	   a.NUMARA = NUMARA_ and
        	   c.DVZ = a.DOVIZ_KOD and
        	   TRUNC(c.TARIH) = TRUNC(DATE_);
    else
        select a.ortalama_bakiye
		  into result
          from CBS_DKHESAP_YILORTALAMA_BAKIYE a
         where to_date(to_char(a.GUN, '00')||to_char(a.AY, '00')||to_char(a.YIL, '0000'), 'ddmmyyyy') = DATE_ and
        	   a.DOVIZ_KOD = DOVIZ_KOD_ and
        	   a.NUMARA = NUMARA_;
    end if;
    return result;
  exception
    when others then
	  return 0;
  end;

  function GET_BAKIYE(DATE_ DATE, BOLUM_KOD_ VARCHAR2, TUR_ VARCHAR2, NUMARA_ VARCHAR2, DOVIZ_KOD_ VARCHAR2, TYPE_ VARCHAR2/*FC, LC*/) RETURN NUMBER
  is
    result number;
  begin
    if TYPE_ = 'LC' then
	  select sum(bakiye_lc) bakiye_lc
		into result
        from cbs_rpt_mizan
       where bolum_kodu=nvl(BOLUM_KOD_, bolum_kodu)
         and length(dk_numara) in (4,6,8)
		 and trunc(tarih)= trunc(decode(TRIM(UPPER(TO_CHAR(DATE_, 'DAY'))), 'SUNDAY', DATE_-2, 'SATURDAY', DATE_ - 1, DATE_))
         --and trunc(tarih)=trunc(DATE_)
         and tur=nvl(tur_, tur)
         and ( borc_lc !=0  or alacak_lc  !=0  or borc_fc !=0  or alacak_fc !=0  or bakiye_lc !=0  or bakiye_fc !=0)
         and dk_numara = numara_
         and doviz_kod = doviz_kod_;
    else
	  select sum(decode(length(dk_numara),8,bakiye_fc,0)) bakiye_fc
		into result
        from cbs_rpt_mizan
       where bolum_kodu=nvl(BOLUM_KOD_, bolum_kodu)
         and length(dk_numara) in (4,6,8)
		 and trunc(tarih)= trunc(decode(TRIM(UPPER(TO_CHAR(DATE_, 'DAY'))), 'SUNDAY', DATE_-2, 'SATURDAY', DATE_ - 1, DATE_))
         --and trunc(tarih)=trunc(DATE_)
         and tur=tur_
         and ( borc_lc !=0  or alacak_lc  !=0  or borc_fc !=0  or alacak_fc !=0  or bakiye_lc !=0  or bakiye_fc !=0)
         and dk_numara = numara_
         and doviz_kod = doviz_kod_;
    end if;
    return result;
  exception
    when others then
	  return 0;
  end;


end PKG_REPORT7;
/

