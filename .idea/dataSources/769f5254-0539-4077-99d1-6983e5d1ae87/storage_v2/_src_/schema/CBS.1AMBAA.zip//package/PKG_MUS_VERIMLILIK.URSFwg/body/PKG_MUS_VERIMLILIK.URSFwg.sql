create PACKAGE BODY PKG_MUS_VERIMLILIK IS
/*
 Function satir_gelir_toplam(pn_musteri_no number) return number is
 ln_temp number;
 ls_temp varchar2(3);
 begin
   select s.doviz_kod, nvl(sum(nvl(s.lc_tutar,0)),0)
     into ls_temp, ln_temp
	 from cbs_fis f, cbs_satir s
	where f.numara = s.fis_numara
	  and f.muhasebelestigi_tarih is not null
	  and f.tur = 'G'
	  and substr(s.hesap_numara,1,3) in ('748', '749', '760', '761')
	  and hesap_tur_kodu = 'DK'
	  and s.referans in(select unique to_char(hesap_no)
	                      from cbs_vw_masraf v
	                     where musteri_no = pn_musteri_no);
	return ln_temp;
  end;
------------------------------------------------------------------------
 Function masraf_gelir_toplam(pn_musteri_no number) return number is
 ln_temp number;
 begin

   select nvl(sum(nvl(m.tahsil_toplam,0)),0)
     into ln_temp
	 from cbs_masraf_ith_ihr m
	where m.referans in (select unique referans
	                       from cbs_vw_masraf
						  where musteri_no = pn_musteri_no)
	  and m.durum = 'VALID';

	return ln_temp;
  end;
  */
------------------------------------------------------------------------
 Function Islem_post_edilmis_mi(pn_islem_no number) return number
   is
     pn_dummy number;
 Begin
     select 1
	   into pn_dummy
	   from cbs_islem
	  where numara=pn_islem_no
	    and (  (durum = 'P')
		    or (durum = 'N' and kayit_kullanici_bolum_kodu = 'SYS'));--batch yaratilmi?
	 return 0;	 --  evet bitmis
   Exception
     When no_data_found then
	   return 1;  --hayir bitmemis veya yok
 End;
------------------------------------------------------------------------
 Function oran_bul(ps_dvz varchar2, pd_date date) return number is
 cursor c_0 is
  select *
    from cbs_gunluk_oranlar
   where tarih = pd_date
     and doviz = ps_dvz;
  r_0 c_0%rowtype;

 cursor c_1 is
  select *
    from cbs_gunluk_oranlar
   where tarih = pkg_mus_verimlilik.date_bul(pd_date)
     and doviz = '000';
  r_1 c_1%rowtype;
 begin
   open c_0;
    fetch c_0 into r_0;
    if c_0%notfound then
	  close c_0;
	  open c_1;
	   fetch c_1 into r_1;
	   if c_1%notfound then
	      close c_1;
		  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '824' || pkg_hata.getDelimiter || to_char(pd_date,'dd.mm.yyyy') || pkg_hata.getDelimiter || ps_dvz ||pkg_hata.getUCPOINTER);
	      return null;
	   end if;
	   close c_1;
	   return r_1.tcmb_o_n_oran * ((100-r_1.tcmb_zorunlu_karsilik)/100);
	end if;
	close c_0;
	return r_0.tcmb_o_n_oran * ((100-r_0.tcmb_zorunlu_karsilik)/100);
 end;
------------------------------------------------------------------------
Function referanstan_hesap_no_al(ps_referans varchar2) return number is
 cursor c_0 is
  select hesap_no
    from cbs_hesap_kredi
   where referans = ps_referans;
 r_0 c_0%rowtype;
 begin
   open c_0;
    fetch c_0 into r_0;
	if c_0%notfound then
	  close c_0;
	  return null;
	end if;
   close c_0;
   return r_0.hesap_no;
 end;
------------------------------------------------------------------------
/*

insert into cbs_mus_karlilik_vadesiz (tarih, musteri_no, hesap_no, doviz_kodu, ortalama, gun, mus_getiri)
 (select pkg_muhasebe.banka_tarihi_bul, musteri_no, hesap_no, doviz_kodu, ortalama, gun, mus_getiri
    from cbs_vw_mus_karli_detay_vadesiz)

	insert into cbs_mus_karlilik_nakdi(tarih, musteri_no, hesap_no, doviz_kodu, ortalama, kar, karlilik, yillik_karlilik, rating_kodu)
	 (select pkg_muhasebe.banka_tarihi_bul, musteri_no, hesap_no, doviz_kodu, ortalama, kar, karlilik, yillik_karlilik, rating_kodu
	    from cbs_vw_mus_karlilik_nakdi)


  insert into cbs_mus_karlilik_gnakdi (tarih, musteri_no, hesap_no, doviz_kodu, ortalama, gun, operasyonel_gider, fc_gelir, lc_gelir)
  	 (select pkg_muhasebe.banka_tarihi_bul, musteri_no, hesap_no, doviz_kodu, ortalama, gun, operasyonel_gider, fc_gelir, lc_gelir
	    from cbs_vw_mus_karlilik_gnakdi)

*/
-----------------------------------------------------------------------------------
Function date_bul(pd_date date) return date is
BEGIN
	 if pd_date>pkg_muhasebe.Banka_Tarihi_Bul then
	 	return pkg_muhasebe.Banka_Tarihi_Bul;
	 else
	 	return pd_date;
	 end if;
END;
----------------------------------------------------------------------------------
END;
/

