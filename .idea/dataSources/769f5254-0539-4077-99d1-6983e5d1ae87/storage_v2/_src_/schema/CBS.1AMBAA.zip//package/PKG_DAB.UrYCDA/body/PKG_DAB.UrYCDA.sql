create PACKAGE BODY     pkg_dab IS
--*******************************************************************************************
  FUNCTION f_get_token(ps_sourcetext IN OUT VARCHAR2, ps_separator VARCHAR2) RETURN VARCHAR2
  IS
    ln_adet           NUMBER;
    ls_sourcetext  VARCHAR2(1000);
    ls_RET         VARCHAR2(1000);

  BEGIN
        /*Verilen sourcetext i?inde , verilen ayrac? ilk g?rd??? yere kadar olan text'i ve geri kalan k?sm?n? dondurur. */
        ls_sourcetext :=ps_sourcetext;
        ln_adet       := INSTR(ls_sourcetext, ps_separator);
        IF ln_adet = 0 THEN
            ls_RET              := ls_sourcetext        ;
            ps_sourcetext := NULL        ;
--            ls_sourcetext := null        ;  Muhasebe plan?n? i?eri atarken kullandu??m?zdan de?i?ti
        ELSE
            ls_RET           := SUBSTR(ls_sourcetext, 1, ln_adet - 1)    ;
            ps_sourcetext := SUBSTR(ls_sourcetext, LENGTH(ls_RET)+2,LENGTH(ls_sourcetext) - ln_adet);
        END IF;

        RETURN ls_RET;

  END f_get_token;
------------------------------------------------------------------------------------------
FUNCTION OncekiGunBakiyeAl(pn_hesapno NUMBER,pd_tarih DATE DEFAULT Pkg_Muhasebe.banka_tarihi_bul) RETURN NUMBER IS
         ln_bakiye                      NUMBER;
         ld_date                      DATE;
 BEGIN
     ld_date:= Pkg_Tarih.geri_is_gunu(NVL(pd_tarih,Pkg_Muhasebe.banka_tarihi_bul));

     SELECT b.BAKIYE
     INTO ln_bakiye
     FROM CBS_HESAP_GUNLUK_BAKIYE b
     WHERE b.hesap_no=pn_hesapno
     --AND yil=TO_NUMBER(TO_CHAR(ld_date,'YYYY'))
     --AND ay=TO_NUMBER(TO_CHAR(ld_date,'MM'))
     --AND gun=TO_NUMBER(TO_CHAR(ld_date,'DD'));
     and b.balance_date=trunc(ld_date);--CBS-475

     RETURN ln_bakiye;
 EXCEPTION
     WHEN OTHERS THEN       RETURN 0;
 END;
------------------------------------------------------------------------------------------
END;
/

