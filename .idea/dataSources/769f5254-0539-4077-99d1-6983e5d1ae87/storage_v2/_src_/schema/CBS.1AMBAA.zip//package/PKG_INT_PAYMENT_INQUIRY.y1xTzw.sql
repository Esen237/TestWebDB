create PACKAGE     PKG_INT_PAYMENT_INQUIRY IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION GetIntalLlc(ps_row_number in varchar2,
                     ps_container_number in varchar2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
FUNCTION GetIntalLlcAccount(ps_name in varchar2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
FUNCTION GetLoanDebt(ps_account_no in varchar2, ps_cust_no in varchar2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
FUNCTION GetAUCAStudentByID(ps_student_id in varchar2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
END;
/

