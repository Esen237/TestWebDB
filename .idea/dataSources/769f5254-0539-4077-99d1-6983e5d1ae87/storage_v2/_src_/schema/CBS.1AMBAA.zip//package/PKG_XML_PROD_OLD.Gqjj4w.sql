create PACKAGE PKG_XML_PROD_OLD IS

/******************************************************************************
   Name       : PKG_XML
   Created By : Bilal G?L
   Date    	  : 27.05.2007
   Purpose	  : XML procedures
******************************************************************************/

  out_file  utl_file.file_type;
  in_file  utl_file.file_type;

 Procedure CreateXML_AntiMoney_Laundering(pd_date date);

 Function sf_get_conv_legal_form_code(pn_code number) return varchar2;


END;

/

