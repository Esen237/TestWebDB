create PACKAGE     PKG_KREDI_TAHSILAT IS
/******************************************************************************
   Name       : PKG_KREDI_TAHSILAT
   Created By : Seval Colak
   Date       :15092021
   Purpose   : Loan  accrual payment procedure and functions
******************************************************************************/

PROCEDURE KRGECIKMEFAIZHESAPLA(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 );

PROCEDURE KRGECIKMEAYBASIFAIZHESAPLA(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 );

PROCEDURE SP_INSERT_CBSRPTKREDIFAIZTAHAK(
            pn_grup_no NUMBER, 
            pn_log_no NUMBER,
            pn_kredi_hesap_no        number,
            ps_hata_mesaj            VARCHAR2,
            pn_islem_tanim_kod number default 0 );
            
PROCEDURE KREDI_TAHAKKUK(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) ;

Procedure SF_ACCRUAL_INT_TAX_ACCOUNT_OPEN(  pn_kredi_hesap_no number,
                                            pn_yaratan_islem_no    number default 0,                                           
                                            pn_tutar number default 0 
                                         );
Procedure SF_NONACCRUAL_ACCOUNTS_OPENING(  pn_kredi_hesap_no number,
                                            pn_yaratan_islem_no    number default 0,                                           
                                            pn_tutar number default 0 
                                         );                                         
Procedure SF_PASTDUE_ACCRUAL_KREDI_HESAP_AC(pn_kredi_hesap_no number,
                                            pn_yaratan_islem_no    number default 0,
                                            pn_yeni_islem_no    number default 0 ,
                                            pn_tutar number,
                                            ps_faiz_anapara varchar2 default 'FAIZ',
                                            pn_pastdue_hesap_no out number
                                    ) ;

FUNCTION  TAHSILAT_MUSTERI_TOP_BAKIYE_AL(pn_musteri_no number, ps_convert_dvz varchar2) RETURN NUMBER ;

function TAHSILAT_HESAP_BAKIYE_AL(pn_hesap_no number, ps_convert_dvz varchar2) return number ;

PROCEDURE ANAPARA_TAHSILAT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) ;

PROCEDURE KREDI_TAHSILAT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ,ps_transfer_Arbitrage_E varchar2 default 'H') ;
PROCEDURE KREDI_TAHSILAT_TRANSFERSIZ(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2);
PROCEDURE KREDI_TAHSILAT_TRANSFERLI(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2);
PROCEDURE AccrualKrediHesapAcilis_Full(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2  ,pn_kredi_hesap_no number default null );
PROCEDURE NONACCRUAL_STATUS_UPDATE(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) ; --seval.colak 13042022

Procedure sf_min_odenmemis_taksiti_bul (pn_hesap_no cbs_hesap_kredi.hesap_no%type,
			 								 pn_taksit_sira_no  out number,
											 pd_taksit_vade out date );
PROCEDURE sp_tahsilat_tutar_bilgi_al(         pn_hesap_no number ,        --seval.colak 20052022
                                                 ps_geriodeme_kapama_Secimi varchar2 default NULL,
                                                 pn_tahsil_anapara    OUT number,
                                                 pn_tahsil_faiz    OUT number,
                                                 pn_tahsil_vergi    OUT number,                                                
                                                 pn_tahsil_birikmis_gecikme_faiz    OUT number,
                                                 pn_tahsil_gecikme_faiz_tax    OUT number,
                                                 pn_tahsil_penalty_amount    OUT number,
                                                 pn_tahsil_penalty_tax    OUT number ,
                                                 pn_tahsil_deferred_interest    out number,
                                                 pn_tahsil_deferred_interest_tax    out number,
                                                 pn_tahsil_deferred_delayed_interest    out number,
                                                 pn_tahsil_deferred_delayed_int_tax    out number,
                                                 pn_tahsil_deferred_tax    out number,
                                                 pn_tahsil_deferred_penalty_amount    out number,
                                                 pn_tahsil_deferred_penalty_tax    out number,
                                                 pn_min_odenmemis_taksit_no out number,
                                                 pd_min_odenmemis_taksit_vade out date                                                
                                                 );

PROCEDURE sp_tahsilat_tutar_isl_bilgi_al(        pn_tx_no number,
                                                 pn_hesap_no number ,        --seval.colak 20052022
                                                 ps_geriodeme_kapama_Secimi varchar2 default NULL,
                                                 pn_tahsil_anapara    OUT number,
                                                 pn_tahsil_faiz    OUT number,
                                                 pn_tahsil_vergi    OUT number,                                                
                                                 pn_tahsil_birikmis_gecikme_faiz    OUT number,
                                                 pn_tahsil_gecikme_faiz_tax    OUT number,
                                                 pn_tahsil_penalty_amount    OUT number,
                                                 pn_tahsil_penalty_tax    OUT number ,
                                                 pn_tahsil_deferred_interest    out number,
                                                 pn_tahsil_deferred_interest_tax    out number,
                                                 pn_tahsil_deferred_delayed_interest    out number,
                                                 pn_tahsil_deferred_delayed_int_tax    out number,
                                                 pn_tahsil_deferred_tax    out number,
                                                 pn_tahsil_deferred_penalty_amount    out number,
                                                 pn_tahsil_deferred_penalty_tax    out number,
                                                 pn_min_odenmemis_taksit_no out number,
                                                 pd_min_odenmemis_taksit_vade out date                                                
                                                 );
  PROCEDURE Accrual_Closing(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) ; --seval.colak 27072022
  FUNCTION ConvertStringToNumber (ps_str VARCHAR2)   RETURN NUMBER ; --seval.colak 25082022 SIMUL
  PROCEDURE Main_Loan_Accrual_Closing(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) ; --seval.colak 08122022
  FUNCTION Loan_BadListFlag(pn_hesap_no VARCHAR2) RETURN VARCHAR2 ;--seval.colak 18012023
END;
/

