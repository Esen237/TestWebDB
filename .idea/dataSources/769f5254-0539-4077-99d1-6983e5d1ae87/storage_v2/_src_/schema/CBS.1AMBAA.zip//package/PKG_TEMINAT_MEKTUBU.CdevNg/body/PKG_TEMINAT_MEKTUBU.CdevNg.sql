create PACKAGE BODY     PKG_TEMINAT_MEKTUBU IS


  FUNCTION  AlinanGarantiKullanilmismi(pn_referans CBS_VW_AKTIF_TEMINAT.referans%TYPE) RETURN VARCHAR2
   IS
    ln_kullanim_sayisi	 CBS_VW_AKTIF_TEMINAT.KULLANILAN_TUTAR%TYPE;
     BEGIN
          SELECT COUNT(*)
        	INTO   ln_kullanim_sayisi
        	FROM   CBS_VW_AKTIF_TEMINAT
        	WHERE  referans = pn_referans;

        	IF ln_kullanim_sayisi>0 THEN RETURN 'E';
        	ELSE RETURN 'H';
        	END IF;

     EXCEPTION
   	  WHEN OTHERS THEN
   	    NULL;
  END;

--**************************************************************************

  PROCEDURE kredi_hesap_ac(ps_modul_tur VARCHAR2, ps_urun_tur VARCHAR2, ps_urun_sinif VARCHAR2,
                           pn_musteri_no NUMBER, ps_doviz VARCHAR2, ps_sube VARCHAR2, pd_vade DATE,
						   ps_referans VARCHAR2,pn_kredi_teklif_satir_no NUMBER, pn_hesap_no OUT NUMBER)  IS
  -- gayrinakdi kredi hesab? a??l?r
  ln_hesap_no NUMBER;
  ln_grup_kod NUMBER;
  ls_gl_code VARCHAR2(30);

  BEGIN

	pkg_kredi.kredi_hesap_ac(ps_modul_tur, ps_urun_tur,  ps_urun_sinif,
	                         pn_musteri_no, ps_doviz, ps_sube, pd_vade,
                             ps_referans, ln_hesap_no,NULL,0, NULL, NULL, pn_kredi_teklif_satir_no);

	pn_hesap_no := ln_hesap_no;

  END;

--**************************************************************************

  FUNCTION TxGonderReferansAl(pn_tx_no NUMBER) RETURN VARCHAR2 IS
  ln_referans VARCHAR2(16);
  BEGIN

   SELECT referans
    INTO ln_referans
    FROM cbs_tm_algar_cikis_islem
    WHERE tx_no=pn_tx_no;

    RETURN ln_referans;

  END;

--**************************************************************************

PROCEDURE IzlemeAlGarBilgisiAl(ps_referans cbs_tm_alinan_garanti.REFERANS%TYPE,
  								   PS_GON_BANKA_MUSTERI_NO OUT NUMBER,
								   ps_DOVIZ_KODU OUT cbs_tm_alinan_garanti.DOVIZ_KODU%TYPE,
								   ps_TUTAR OUT NUMBER,
								   ps_BAKIYE OUT NUMBER,
								   ps_VADE_TARIHI OUT DATE
								   )
  IS
  BEGIN

  SELECT GON_BANKA_MUSTERI_NO, DOVIZ_KODU, TUTAR, BAKIYE, VADE_TARIHI
  INTO   PS_GON_BANKA_MUSTERI_NO, ps_DOVIZ_KODU, ps_TUTAR, ps_BAKIYE, ps_VADE_TARIHI
  FROM cbs_tm_alinan_garanti
  WHERE referans=ps_referans;

	EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,pkg_hata.getUCPOINTER || '2633' || pkg_hata.getUCPOINTER);
  END;

--**************************************************************************

 FUNCTION TM_SUBE_LIMIT_BAKIYESI RETURN NUMBER IS
 ln_sube_bakiye NUMBER;
 ls_bolum_kodu VARCHAR2(10);
 BEGIN

 ls_bolum_kodu:=pkg_baglam.bolum_kodu;

 IF ls_bolum_kodu IS NOT NULL THEN

  SELECT (NVL(SUBE_LIMITI,0)-NVL(SUBE_LIMITI_KULLANILAN,0))
   INTO ln_sube_bakiye
   FROM CBS_TM_LIMIT_DETAY
   WHERE sube_kodu=pkg_baglam.bolum_kodu;

  RETURN ln_sube_bakiye;

  ELSE
   RAISE_APPLICATION_ERROR(-20100,pkg_hata.getUCPOINTER || '4427' || pkg_hata.getUCPOINTER);
  END IF;



  EXCEPTION
	  WHEN OTHERS  THEN
	    RETURN 0;
 END;

--**************************************************************************

 FUNCTION TM_SUBE_GMIF_BAKIYESI RETURN NUMBER IS
 ln_sube_gmif_bakiye NUMBER;
 ls_bolum_kodu VARCHAR2(10);
 BEGIN

 ls_bolum_kodu:=pkg_baglam.bolum_kodu;

  IF ls_bolum_kodu IS NOT NULL THEN

  SELECT (NVL(GMIF_AYRILAN,0)-NVL(GMIF_KULLANILAN,0))
   INTO ln_sube_gmif_bakiye
   FROM CBS_TM_LIMIT_DETAY
   WHERE sube_kodu=pkg_baglam.bolum_kodu;

  RETURN ln_sube_gmif_bakiye;

  ELSE
    RAISE_APPLICATION_ERROR(-20100,pkg_hata.getUCPOINTER || '4427' || pkg_hata.getUCPOINTER);
  END IF;

  EXCEPTION
	  WHEN OTHERS  THEN
	    RETURN 0;
 END;

--**************************************************************************

 FUNCTION TM_SUBE_TOPLAM_BAKIYESI RETURN NUMBER IS
  BEGIN
    RETURN TM_SUBE_LIMIT_BAKIYESI+TM_SUBE_GMIF_BAKIYESI;
  END;

--**************************************************************************

 FUNCTION TM_SUBE_BAKIYE_YETERLI(pn_lc_tutar NUMBER) RETURN BOOLEAN IS
 BEGIN

  IF pn_lc_tutar<=TM_SUBE_TOPLAM_BAKIYESI THEN
     RETURN TRUE;
   ELSE
 	 RETURN FALSE;
  END IF;

 END;

--**************************************************************************

 PROCEDURE TM_BAKIYE_UPDATE(ps_artma_azalma VARCHAR2,pn_lc_tutar NUMBER) IS
 ln_fark NUMBER;
 ln_sube_gmif_kullanilan NUMBER;

 BEGIN

 IF ps_artma_azalma='ARTMA' THEN

    IF pn_lc_tutar<=TM_SUBE_LIMIT_BAKIYESI THEN

	   UPDATE CBS_TM_LIMIT_DETAY
	   SET SUBE_LIMITI_KULLANILAN=NVL(SUBE_LIMITI_KULLANILAN,0)+pn_lc_tutar
	   WHERE sube_kodu=pkg_baglam.bolum_kodu;

	ELSIF pn_lc_tutar>TM_SUBE_LIMIT_BAKIYESI THEN

	   ln_fark:=pn_lc_tutar-TM_SUBE_LIMIT_BAKIYESI;

	   UPDATE CBS_TM_LIMIT_DETAY
	   SET SUBE_LIMITI_KULLANILAN=SUBE_LIMITI
	   WHERE sube_kodu=pkg_baglam.bolum_kodu;

	   UPDATE CBS_TM_LIMIT_DETAY
	   SET GMIF_KULLANILAN=NVL(GMIF_KULLANILAN,0)+ln_fark
	   WHERE sube_kodu=pkg_baglam.bolum_kodu;

	 END IF;


 ELSIF ps_artma_azalma='AZALMA' THEN

    SELECT NVL(GMIF_KULLANILAN,0)
     INTO ln_sube_gmif_kullanilan
     FROM CBS_TM_LIMIT_DETAY
     WHERE sube_kodu=pkg_baglam.bolum_kodu;

	IF pn_lc_tutar<=ln_sube_gmif_kullanilan THEN

	   UPDATE CBS_TM_LIMIT_DETAY
	   SET GMIF_KULLANILAN=NVL(GMIF_KULLANILAN,0)-pn_lc_tutar
	   WHERE sube_kodu=pkg_baglam.bolum_kodu;

	ELSIF pn_lc_tutar>ln_sube_gmif_kullanilan THEN

	   ln_fark:=pn_lc_tutar-ln_sube_gmif_kullanilan;

	   UPDATE CBS_TM_LIMIT_DETAY
	   SET GMIF_KULLANILAN=0
	   WHERE sube_kodu=pkg_baglam.bolum_kodu;

	   UPDATE CBS_TM_LIMIT_DETAY
	   SET SUBE_LIMITI_KULLANILAN=NVL(SUBE_LIMITI_KULLANILAN,0)-ln_fark
	   WHERE sube_kodu=pkg_baglam.bolum_kodu;

	 END IF;

 END IF;

END;

--**************************************************************************

 FUNCTION Pasif_Hesap_Adi_Al(ps_dk_no VARCHAR2) RETURN VARCHAR2 IS
  ls_pasif_hesap_aciklama VARCHAR2(300);
 BEGIN

 SELECT HESAP_ACIKLAMA
  INTO ls_pasif_hesap_aciklama
  FROM CBS_TM_PASIF_HESAP
  WHERE DK_NO=ps_dk_no;

  RETURN ls_pasif_hesap_aciklama;
 END;

--**************************************************************************

 FUNCTION TM_bakiyesi_al(ps_referans VARCHAR2) RETURN NUMBER IS
  ln_bakiye NUMBER;
 BEGIN

 SELECT NVL(bakiye,0)
  INTO ln_bakiye
  FROM CBS_TM_HG_ACILIS
  WHERE referans=ps_referans;

  RETURN ln_bakiye;
 END;

--**************************************************************************
   Function TM_Urun_tur return varchar2
   is
   begin
   		return 'L/G';
   end;
--**************************************************************************
FUNCTION KG_bakiyesi_al(ps_referans VARCHAR2) RETURN NUMBER IS
  ln_bakiye NUMBER;
 BEGIN

 SELECT NVL(bakiye,0)
  INTO ln_bakiye
  FROM CBS_TM_ALINAN_GARANTI
  WHERE referans=ps_referans;

  RETURN ln_bakiye;
END;
-----------------------------------------------------------------------
FUNCTION KG_tutari_al(ps_referans VARCHAR2) RETURN NUMBER IS
  ln_bakiye NUMBER;
 BEGIN

 SELECT NVL(tutar,0)
  INTO ln_bakiye
  FROM CBS_TM_ALINAN_GARANTI
  WHERE referans=ps_referans;

  RETURN ln_bakiye;
END;
 -----------------------------------------------------------------------

 -----------------------------------------------------------------------
FUNCTION KG_Kullanim_Tutari(ps_referans VARCHAR2) RETURN NUMBER IS
  ln_kullanim_tutari NUMBER;
 BEGIN

 select nvl(sum(KULLANILACAK_TUTAR),0)
  into ln_kullanim_tutari
  from CBS_TM_KG_KULLANIM
  where KG_REFERANS=ps_referans;

  RETURN ln_kullanim_tutari;
END;
 -----------------------------------------------------------------------

FUNCTION KG_Top_Tazmin_Tutari(ps_referans VARCHAR2) RETURN NUMBER IS
  ln_top_tazmin_tutari NUMBER;
 BEGIN

 select nvl(sum(TOP_TAZMIN_TUTAR),0)
  into ln_top_tazmin_tutari
  from  CBS_TM_KG_KULLANIM
  where KG_REFERANS=ps_referans;

  RETURN ln_top_tazmin_tutari;
END;
 -----------------------------------------------------------------------

BEGIN

  NULL;

END;
/

