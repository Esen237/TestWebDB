create PACKAGE PKG_KUR_REZERVASYON IS


Function Rezerve_Kur_Tutar_Uygunmu(pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
 		  							pn_tutar number,
									pn_Alis_Satis varchar,
									pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return boolean;

 Function Rezervasyon_Tutar_Turu_Al( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
 		  					         pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									 ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
									) return varchar;

 Function Rezervasyon_Bakiye( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,pn_islem_numara cbs_islem.NUMARA%type,
 		  					  pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
							  ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
							 ) return number;

 Function Rezervasyon_Gercek_Bakiye( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                     ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
 		  					         ) return number;

Function Rezervasyon_Kullanim_Orani(pd_tarih cbs_kur_rezervasyon.tarih%type,
 		  							 ps_sube_kodu cbs_kur_rezervasyon.sube_kodu%type,
 		  							 pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type
 		  					         ) return number;

Function Rezervasyon_Maliyet_Kur_Al(pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
									pn_Alis_Satis varchar,
									pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return number;


Function Kur_Rezervasyon_Kullanilmismi( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                        pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									    ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return boolean;


 Procedure Rezervasyon_Bilgisi_Al(pn_rezervasyon_no in cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                  pn_musteri_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								  pn_musteri_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
								  pn_maliyet_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								  pn_maliyet_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
								  pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
								  ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
								  );

 Procedure Rezervasyon_Alis_Bilgisi_Al(pn_rezervasyon_no in cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                       pn_musteri_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								       pn_maliyet_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								       pd_date in date default pkg_muhasebe.banka_tarihi_bul,
									   ps_sube in varchar2 default pkg_baglam.bolum_kodu);

 Procedure Rezervasyon_Satis_Bilgisi_Al(pn_rezervasyon_no in cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                        pn_musteri_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
								        pn_maliyet_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
								        pd_date in date default pkg_muhasebe.banka_tarihi_bul,
									    ps_sube in varchar2 default pkg_baglam.bolum_kodu);

 Procedure Rezervasyon_Kullanim_Kaydet(pn_REZERVASYON_NO in number,
                                       pn_islem_numara in number,
									   pn_TUTAR in number,
									   pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									   ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu);
Procedure Rezervasyon_Kullanim_Iptal(pn_islem_numara in number);

Function Kur_Marj_Al( ps_doviz_kodu cbs_doviz_kodlari.doviz_kodu%type,ps_Alis_Satis varchar) return number;
-------------------------------------------------------------------------------------------------------------
FUNCTION CalculateParity(ps_currency_1 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE,
 		  				 ps_currency_2 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE,
						 ps_buy_sell VARCHAR2) RETURN NUMBER;
-------------------------------------------------------------------------------------------------------------
 FUNCTION sf_base_doviz_hangisi(ps_currency_1 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE,
 		  					    ps_currency_2 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE) RETURN VARCHAR;
-------------------------------------------------------------------------------------------------------------
END;


/

