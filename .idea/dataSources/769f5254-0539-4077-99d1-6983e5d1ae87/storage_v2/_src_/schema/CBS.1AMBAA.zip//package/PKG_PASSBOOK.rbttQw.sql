create PACKAGE     Pkg_Passbook IS

TYPE CursorReferenceType IS REF CURSOR;

PROCEDURE HesapKontrol(pn_hesap_no IN VARCHAR2,
		  			   pn_baslangic_tarihi OUT date,
					   pn_son_fis_no OUT number,
					   pn_son_satir_no OUT number,
					   pn_passbook_no OUT number,
                       pn_kaldigi_satir_no OUT number);
FUNCTION SonSatirUpdate(pn_hesap_no IN number) RETURN VARCHAR2 ;
FUNCTION Fis_No_Update(pn_hesap_no IN number,pn_fis_no number) RETURN VARCHAR2;
FUNCTION Satir_No_Update(pn_hesap_no IN number,pn_satir_no number) RETURN VARCHAR2;
FUNCTION SatirNoUpdate(pn_hesap_no IN number) RETURN VARCHAR2 ;
FUNCTION KalanSatirNoUpdate(pn_hesap_no IN number) RETURN VARCHAR2 ;
FUNCTION SonSatir(pn_hesap_no IN number) RETURN NUMBER ;
FUNCTION Hesap_Passbook_Tanimli(pn_hesap_no IN number) RETURN VARCHAR2 ;
FUNCTION Ortak_Al(pn_hesap_no IN number) RETURN VARCHAR2 ;
FUNCTION HareketliBakiyeHesapla(pn_hesap_no NUMBER,pn_fis_numara NUMBER,pn_satir_no NUMBER) RETURN NUMBER ;
END;
/

