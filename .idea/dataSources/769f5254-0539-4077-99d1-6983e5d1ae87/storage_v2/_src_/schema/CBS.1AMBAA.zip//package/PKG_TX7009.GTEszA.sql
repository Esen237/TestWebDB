create PACKAGE Pkg_Tx7009 IS

  /******************************************************************************
   Name       : PKG_TX7009
   Created By : Hakan SAMSA
   Purpose	  : MAAS HESAPLARINI IZLEYECEK PERSONEL TANIMLAMA
  ******************************************************************************/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 	-- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edildikten sonra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);	-- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);		-- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  	-- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);		-- Islemin muhasebelesmesi icin cagrilir

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
   PROCEDURE BilgiAktar(pn_txno IN NUMBER,
                        s1 IN VARCHAR2) ;
END;


/

