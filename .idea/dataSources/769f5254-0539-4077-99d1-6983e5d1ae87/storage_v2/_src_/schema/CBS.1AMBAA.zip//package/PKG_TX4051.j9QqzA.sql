create PACKAGE     PKG_TX4051 IS

  /******************************************************************************
   Name       : PKG_TX4051
   Created By : Bilal GUL
   Purpose      : Bankamiz Kur Guncelleme
  ******************************************************************************/

  -- TX Event Listesi
  Procedure bankamiz_kur_getir(ln_islem_no number);
  Procedure Kontrol_Sonrasi(pn_islem_no number);     -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);    -- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);        -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);        -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);    -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);        -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);      -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);        -- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Procedure Guncelleme_Kontrolu(pn_islem_no NUMBER,
                                  ps_block    VARCHAR2,
                                ps_rowid   VARCHAR2,
                                     ps_column      VARCHAR2,
                                        pd_column   VARCHAR2,
                                ps_oldvalue IN OUT VARCHAR2); --G?ncellenen alanlar? bulmak i?in

Function mevcut_kur_getir( ps_doviz_kodu varchar2 ,ps_kur_tip varchar2) return number ;--sevalb 26562 - Implementation of additional preventive logic to FX rate modification screen (4051)
Function uyari_mesaji_gonderilmeli_mi (pn_eski_kur number,pn_yeni_kur number) return varchar2 ;

END;

/

