create PACKAGE     PKG_ODEME_PLAN IS
/******************************************************************************
   Name       : PKG_ODEME_PLAN
   Created By : Seval Colak
   Date       : 12.04.2021
   Purpose    :Yeni odeme plani yapisi icin kullanilacak olan procedur ve fonksiyonlari icerir.
******************************************************************************/
 TYPE  v_odeme_satir is RECORD (
       v_sira                    number,
       v_vade                    date,
       v_taksit                  number ,
       v_anapara                 number,
       v_faiz                    number,
       v_vergi1                  number,
       v_vergi2                  number,
       v_kalan_anapara           number ,
       v_taksit_faiz_orani       number ,
       v_taksit_vergi1_orani     number ,
       v_taksit_vergi2_orani     number,
       v_taksit_gun_sayisi       number default 30,
       v_hesaplama_gun_sayisi    number default 30 ,
       v_taksit_baz_anapara      number ,
       v_ozel_odeme_tutari       number,  
       v_orj_vergi_tutari        number, 
       v_orj_faiz_tutari         number ,
       v_deferred_interest       number,
       v_deferred_tax            number,
       v_delayed_interest        number,
       v_penalty_amount          number,
       v_deferred_penalty_amount number  ,
       v_deferred_delayed_interest number       );
        
 TYPE v_odeme_plan is table of  v_odeme_satir;
 
 
 type lrec_extpaylist is record   (  paymentnumber    varchar2(100),
                                     amount           varchar2(100),
                                     installmenttypes varchar2(100));
 type type_extpaylist is table of lrec_extpaylist         index by     binary_integer; 

 ----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_odeme_plan_islem_at       (   p_odeme_plan_no          cbs_odeme_plan_islem.odeme_plan_no%type ,
                                            p_tran_tipi              cbs_odeme_plan_islem.tran_tipi%type ,
                                            p_odeme_plan_tipi        cbs_odeme_plan_islem.odeme_plan_tipi%type ,
                                            p_sozlesme_no            cbs_odeme_plan_islem.sozlesme_no%type ,
                                            p_sozlesme_tarihi        cbs_odeme_plan_islem.sozlesme_tarihi%type ,
                                            p_kredi_tutari           cbs_odeme_plan_islem.kredi_tutari%type ,
                                            p_doviz_kodu             cbs_odeme_plan_islem.doviz_kodu%type ,
                                            p_taksit_sayisi          cbs_odeme_plan_islem.taksit_sayisi%type ,
                                            p_kullandirim_tarihi     cbs_odeme_plan_islem.kullandirim_tarihi%type ,
                                            p_ilk_taksit_tarihi      cbs_odeme_plan_islem.ilk_taksit_tarihi%type ,
                                            p_odeme_gunu             cbs_odeme_plan_islem.odeme_gunu%type ,
                                            p_odeme_tarihi_secimi    cbs_odeme_plan_islem.odeme_tarihi_secimi%type ,
                                            p_faiz_tipi              cbs_odeme_plan_islem.faiz_tipi%type ,
                                            p_faiz_orani             cbs_odeme_plan_islem.faiz_orani%type ,
                                            p_sozlesme_faiz_orani    cbs_odeme_plan_islem.sozlesme_faiz_orani%type ,
                                            p_faiz_hesaplama_tipi    cbs_odeme_plan_islem.faiz_hesaplama_tipi%type ,
                                            p_faiz_siklik_tipi       cbs_odeme_plan_islem.faiz_siklik_tipi%type ,
                                            p_faiz_siklik            cbs_odeme_plan_islem.faiz_siklik%type ,
                                            p_vergi1_orani           cbs_odeme_plan_islem.vergi1_orani%type ,
                                            p_vergi2_orani           cbs_odeme_plan_islem.vergi2_orani%type ,
                                            p_komisyon_tipi          cbs_odeme_plan_islem.komisyon_tipi%type ,
                                            p_komisyon_orani         cbs_odeme_plan_islem.komisyon_orani%type ,
                                            p_komisyon_tutari        cbs_odeme_plan_islem.komisyon_tutari%type ,
                                            p_taksit_siklik          cbs_odeme_plan_islem.taksit_siklik%type ,
                                            p_taksit_artis_siklik    cbs_odeme_plan_islem.taksit_artis_siklik%type ,
                                            p_taksit_artis_orani     cbs_odeme_plan_islem.taksit_artis_orani%type ,
                                            p_odemesiz_ay_sayisi     cbs_odeme_plan_islem.odemesiz_ay_sayisi%type ,
                                            p_faiz_yontemi_methodu   cbs_odeme_plan_islem.faiz_yontemi_methodu%type ,
                                            p_ek_faiz_tutari         cbs_odeme_plan_islem.ek_faiz_tutari%type ,
                                            p_imza_1_adi             cbs_odeme_plan_islem.imza_1_adi%type ,
                                            p_imza_2_adi             cbs_odeme_plan_islem.imza_2_adi%type  ,
                                            p_musteri_no             cbs_odeme_plan_islem.musteri_no%type ,
                                            p_kredi_hesap_No         number default 0, --seval.colak 23012022
                                            p_payment_amount          number default 0, --seval.colak 03022022
                                            p_file_servis            varchar2 default 'WS',
                                            p_file_name              varchar2 default null,
                                            p_kredi_tipi             cbs_odeme_plan_islem.kredi_tipi%type  default null ,
                                            p_penalty_rate           cbs_odeme_plan_islem.penalty_rate%type  default null ,
                                            p_pastdue_faiz_orani      cbs_odeme_plan_islem.pastdue_faiz_orani%type  default null , 
                                            p_yearly_effective_int_rate            number default null ,       --seval.colak 29082022                                             
                                            p_Expense_type_1            varchar2 default 'CreditAllocationFee',
                                            p_expense_payer_type_1      varchar2 default 'Customer',
                                            p_Expense_fee_amount_1      number default 0 ,
                                            p_Expense_type_2            varchar2 default null,
                                            p_expense_payer_type_2      varchar2 default 'Customer',
                                            p_Expense_fee_amount_2      number default 0 ,
                                            p_expense_type_3            varchar2 default null,
                                            p_expense_payer_type_3      varchar2 default 'Customer',
                                            p_Expense_fee_amount_3      number default 0 ,                               
                                            p_expense_type_4            varchar2 default null,
                                            p_expense_payer_type_4      varchar2 default 'Customer',
                                            p_Expense_fee_amount_4      number default 0 ,
                                            p_expense_type_5            varchar2 default null,
                                            p_expense_payer_type_5      varchar2 default 'Customer',
                                            p_Expense_fee_amount_5      number default 0                                                                                     
                                         ) ;
                                         
----------------------------------------------------------------------------------------------------------------------------------------                                         
  Procedure sp_ozel_odeme_plan_islem_at (   p_odeme_plan_no          cbs_ozel_odeme_plan_islem.odeme_plan_no%type ,
                                            p_taksit_no              cbs_ozel_odeme_plan_islem.taksit_no%type ,
                                            p_taksit_tipi            cbs_ozel_odeme_plan_islem.taksit_tipi%type,
                                            p_tutar                  cbs_ozel_odeme_plan_islem.tutar%type                                       
                                         ) ;
                                       
----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_taksit_odeme_plan_islem_at( p_odeme_plan_no          cbs_taksit_odeme_plan_islem.odeme_plan_no%type ,
                                          p_taksit_no              cbs_taksit_odeme_plan_islem.taksit_no%type ,
                                          p_taksit                 cbs_taksit_odeme_plan_islem.taksit%type ,
                                          p_anapara                cbs_taksit_odeme_plan_islem.anapara%type ,
                                          p_faiz                   cbs_taksit_odeme_plan_islem.faiz%type ,
                                          p_vergi1                 cbs_taksit_odeme_plan_islem.vergi1%type ,
                                          p_vergi2                 cbs_taksit_odeme_plan_islem.vergi2%type ,
                                          p_vade_tarih             cbs_taksit_odeme_plan_islem.vade_tarih%type ,
                                          p_kal_anapara            cbs_taksit_odeme_plan_islem.kal_anapara%type ,
                                          p_taksit_gun_sayisi      cbs_taksit_odeme_plan_islem.taksit_gun_sayisi%type ,
                                          p_hesaplama_gun_sayisi   cbs_taksit_odeme_plan_islem.hesaplama_gun_sayisi%type ,
                                          p_taksit_baz_anapara     cbs_taksit_odeme_plan_islem.taksit_baz_anapara%type ,
                                          p_taksit_faiz_orani      cbs_taksit_odeme_plan_islem.taksit_faiz_orani%type ,
                                          p_taksit_vergi1_orani    cbs_taksit_odeme_plan_islem.taksit_vergi1_orani%type ,
                                          p_taksit_vergi2_orani    cbs_taksit_odeme_plan_islem.taksit_vergi2_orani%type,
                                          p_ozel_odeme_tutari      cbs_taksit_odeme_plan_islem.ozel_odeme_tutari%type,  
                                          p_orj_vergi_tutari       cbs_taksit_odeme_plan_islem.orj_vergi_tutari%type,
                                          p_orj_faiz_tutari        cbs_taksit_odeme_plan_islem.orj_faiz_tutari%type ,
                                          p_ek_faiz_tutari         cbs_taksit_odeme_plan_islem.ek_faiz_tutari%type ,
                                          p_deferred_interest      cbs_taksit_odeme_plan_islem.deferred_interest%type ,
                                          p_deferred_delayed_interest cbs_taksit_odeme_plan_islem.deferred_delayed_interest%type , --seval.colak 17122021
                                          p_deferred_tax           cbs_taksit_odeme_plan_islem.deferred_tax%type ,
                                          p_delayed_interest       cbs_taksit_odeme_plan_islem.delayed_interest%type ,
                                          p_penalty_amount         cbs_taksit_odeme_plan_islem.penalty_amount%type  default null ,
                                          p_deferred_penalty_amount  cbs_taksit_odeme_plan_islem.deferred_penalty_amount%type  default null,
                                          p_yearly_cost_rate          cbs_taksit_odeme_plan_islem.yearly_cost_rate%type  default null ,
                                          p_monthly_cost_rate         cbs_taksit_odeme_plan_islem.monthly_cost_rate%type  default null                                          
                                          
 );
----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_odeme_plan_anatabloya_at(p_odeme_plan_no  number ) ;
 
 ----------------------------------------------------------------------------------------------------------------------------------------                                         
-- sp_taksit_test sadece test etme amacli silinecek sonrasinda
 procedure sp_taksit_test_kopyala  (  p_odeme_plan_no      cbs_taksit_odeme_plan_islem.odeme_plan_no%type  ,
                                      p_taksit_faiz_orani          cbs_taksit_odeme_plan_islem.taksit_faiz_orani%type ,
                                      p_taksit_vergi1_orani        cbs_taksit_odeme_plan_islem.taksit_vergi1_orani%type ,
                                      p_taksit_vergi2_orani        cbs_taksit_odeme_plan_islem.taksit_vergi2_orani%type,
                                      p_ek_faiz_tutari    number ,
                                      pn_hesap_no number default 0   );    
                          
----------------------------------------------------------------------------------------------------------------------------------------   
Procedure sp_ws_getPaymentPlan   (    p_odeme_plan_no              number ,  
                                       pn_caller_tx_no              number default 0,
                                       pn_principal                 number ,
                                       pn_term                      number ,
                                       pn_interestRate              number ,
                                       pn_kkdfRate                  number,
                                       pn_bsmvRate                  number,
                                       pn_paymentDay                number,
                                       pd_customFirstPaymentDate    date,
                                       pd_utilizationDate           date,
                                       ps_interestRateType          varchar2,
                                       ps_paymentPlanType           varchar2,
                                       ps_calculationType           varchar2,
                                       ps_workingDayType            varchar2,
                                       pn_duration                  number,
                                       pn_noPaymentPeriod           number,  
                                       ps_frequencyCode             varchar2,
                                       pn_additionalInterest        number,
                                       ps_commissionType            varchar2,
                                       pn_commissionRate            number,
                                       pn_commissionAmount          number,    
                                       pn_increaseRate              number,
                                       pn_increaseFrequency         number,
                                       pn_frequencyValue            number, 
                                       ps_interestUsageType         varchar2,
                                       ps_tbl_type_extpaylist       pkg_payment_plan_ws.type_extpaylist,
                                       pn_tbl_type_extpaylist_cnt   number,
                                       p_expense_type_1            varchar2 default 'CreditAllocationFee',
                                       p_expense_payer_type_1      varchar2 default 'Customer',
                                       p_Expense_fee_amount_1      number default 0 ,
                                       p_expense_type_2            varchar2 default null,
                                       p_expense_payer_type_2      varchar2 default 'Customer',
                                       p_Expense_fee_amount_2      number default 0 ,
                                       p_expense_type_3            varchar2 default null,
                                       p_expense_payer_type_3      varchar2 default 'Customer',
                                       p_Expense_fee_amount_3      number default 0 ,                               
                                       p_expense_type_4            varchar2 default null,
                                       p_expense_payer_type_4      varchar2 default 'Customer',
                                       p_Expense_fee_amount_4      number default 0 ,
                                       p_expense_type_5            varchar2 default null,
                                       p_expense_payer_type_5      varchar2 default 'Customer',
                                       p_Expense_fee_amount_5      number default 0                                  
                                       );      
                                                               
---------------------------------------------------------------------------------------------------------------------------------------- 
                                                              
Procedure sp_taksit_odeme_plan_isltbl_at  ( p_odeme_plan_no           number ,
                                            pv_odeme                  pkg_odeme_plan.v_odeme_plan ,
                                            pn_taksit_sayi            number);
----------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE sp_vw_odeme_plan_bilgi_al( p_odeme_plan_no              cbs_vw_odeme_plan.odeme_plan_no%type ,
                                    p_musteri_no                  out  cbs_vw_odeme_plan.musteri_no%type ,
                                    p_durum_kodu                  out  cbs_vw_odeme_plan.durum_kodu%type ,
                                    p_tran_tipi                   out  cbs_vw_odeme_plan.tran_tipi%type ,
                                    p_odeme_plan_tipi             out  cbs_vw_odeme_plan.odeme_plan_tipi%type ,
                                    p_sozlesme_no                 out  cbs_vw_odeme_plan.sozlesme_no%type ,
                                    p_sozlesme_tarihi             out  cbs_vw_odeme_plan.sozlesme_tarihi%type ,
                                    p_kredi_tutari                out  cbs_vw_odeme_plan.kredi_tutari%type ,
                                    p_doviz_kodu                  out  cbs_vw_odeme_plan.doviz_kodu%type ,
                                    p_taksit_sayisi               out  cbs_vw_odeme_plan.taksit_sayisi%type ,
                                    p_kullandirim_tarihi          out  cbs_vw_odeme_plan.kullandirim_tarihi%type ,
                                    p_ilk_taksit_tarihi           out  cbs_vw_odeme_plan.ilk_taksit_tarihi%type ,
                                    p_vade_tarihi                 out  cbs_vw_odeme_plan.ilk_taksit_tarihi%type ,
                                    p_odeme_gunu                  out  cbs_vw_odeme_plan.odeme_gunu%type ,
                                    p_taksit_once_sonra           out  cbs_vw_odeme_plan.taksit_once_sonra%type ,
                                    p_faiz_tipi                   out  cbs_vw_odeme_plan.faiz_tipi%type ,
                                    p_faiz_orani                  out  cbs_vw_odeme_plan.faiz_orani%type ,
                                    p_sozlesme_faiz_orani         out  cbs_vw_odeme_plan.sozlesme_faiz_orani%type ,
                                    p_monthly_interest_rate       out  cbs_vw_odeme_plan.monthly_interest_rate%type ,
                                    p_yearly_int_rate             out  cbs_vw_odeme_plan.yearly_int_rate%type ,
                                    p_yearly_effective_int_rate   out  cbs_vw_odeme_plan.yearly_effective_int_rate%type ,
                                    p_faiz_hesaplama_tipi         out  cbs_vw_odeme_plan.faiz_hesaplama_tipi%type ,
                                    p_faiz_siklik_tipi            out  cbs_vw_odeme_plan.faiz_siklik_tipi%type ,
                                    p_faiz_siklik                 out  cbs_vw_odeme_plan.faiz_siklik%type ,
                                    p_bsmv_alinsin                out  cbs_vw_odeme_plan.bsmv_alinsin%type ,
                                    p_bsmv_orani                  out  cbs_vw_odeme_plan.bsmv_orani%type ,
                                    p_kkdf_alinsin                out  cbs_vw_odeme_plan.kkdf_alinsin%type ,
                                    p_fon_orani                   out  cbs_vw_odeme_plan.fon_orani%type ,
                                    p_komisyon_tipi               out  cbs_vw_odeme_plan.komisyon_tipi%type ,
                                    p_komisyon_orani              out  cbs_vw_odeme_plan.komisyon_orani%type ,
                                    p_komisyon_tutari             out  cbs_vw_odeme_plan.komisyon_tutari%type ,
                                    p_taksit_siklik               out  cbs_vw_odeme_plan.taksit_siklik%type ,
                                    p_taksit_artis_siklik         out  cbs_vw_odeme_plan.taksit_artis_siklik%type ,
                                    p_taksit_artis_orani          out  cbs_vw_odeme_plan.taksit_artis_orani%type ,
                                    p_odemesiz_ay_sayisi          out  cbs_vw_odeme_plan.odemesiz_ay_sayisi%type ,
                                    p_faiz_yontemi_methodu        out  cbs_vw_odeme_plan.faiz_yontemi_methodu%type ,
                                    p_ek_faiz_tutari              out  cbs_vw_odeme_plan.ek_faiz_tutari%type ,
                                    p_imza_1_adi                  out  cbs_vw_odeme_plan.imza_1_adi%type ,
                                    p_imza_2_adi                  out  cbs_vw_odeme_plan.imza_2_adi%type ,
                                    p_odeme_turu                  out  cbs_vw_odeme_plan.odeme_turu%type ,
                                    p_file_servis                 out  cbs_vw_odeme_plan.file_servis %type ,
                                    p_file_name                   out  cbs_vw_odeme_plan.file_name %type ,
                                    p_kredi_tipi                  out  cbs_vw_odeme_plan.kredi_tipi%type ,
                                    p_penalty_rate                out  cbs_vw_odeme_plan.penalty_rate%type,
                                    p_pastdue_faiz_orani          out  cbs_vw_odeme_plan.pastdue_faiz_orani%type           
                                    );
----------------------------------------------------------------------------------------------------------------------------------------
Procedure sp_odeme_plan_hes_kredi_isl_at( p_tx_no    number,
                                          p_islem_kod number,   
                                          p_sube_kodu varchar2 ,      
                                          p_odeme_plan_no     number,
                                          p_repayment_type    varchar2  default 'INSTALLMENT DATE',  
                                          p_musteri_no number, 
                                          p_hesap_no number default null,
                                          p_faiz_indirimi varchar2 default null
                                          ) ;
----------------------------------------------------------------------------------------------------------------------------------------                                          
FUNCTION sf_bitmemis_planislem_var_mi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                       pn_islem_no CBS_ISLEM.numara%TYPE,
                                       pn_odeme_plan_no number default 0 ) RETURN NUMBER;   
------------------------------------------------------------------------------------------------------------------------------------------
--- PASTDUE ile ilgili fonk ve procedurler KRPFI Accrued Loan Interest
------------------------------------------------------------------------------------------------------------------------------------------
Function sf_kredi_taksitli_mi(pn_kredi_hesap_no number) return varchar2; -- yeni taksitli yapida taksit tablosunda kaydi olan ve  repayment_type = 'INSTALLMENT DATE' kayit taksitlidir.
Function sf_pastdue_principal_total(pn_kredi_hesap_no number) return number;
Function sf_pastdue_interest_total(pn_kredi_hesap_no number) return number;
Function sf_pastdue_tax_total(pn_kredi_hesap_no number) return number;      
Function sf_accrued_int_amount(pn_kredi_hesap_no number) return number; 
Function sf_non_accrued_int_amount(pn_kredi_hesap_no number) return number;  
Function sf_cumulated_int_total(pn_kredi_hesap_no number) return number;
Function sf_delay_days_of_principal(pn_kredi_hesap_no number) return number;
Function sf_delay_days_of_interest(pn_kredi_hesap_no number) return number ;
Function sf_delayed_interest_total(pn_kredi_hesap_no number) return number;
Function sf_delayed_interest_tax_total(pn_kredi_hesap_no number) return number;
Function sf_delayed_interest_accruedtax_total(pn_kredi_hesap_no number) return number;
Function sf_penalty_amount_total(pn_kredi_hesap_no number) return number;
function  sf_urun_tahakkuk_eh(ps_modul_tur_kod IN varchar2, 
                              ps_urun_tur_kod IN varchar2,
                              ps_urun_sinif_kod varchar2 ) RETURN VARCHAR2;    
------------------------------------------------------------------------------------------------------------------------------------------
Function sf_min_pastdue_int_hesno(pn_kredi_hesap_no number) return number;                                                                                                                                        
Function sf_min_pastdue_tax_hesno(pn_kredi_hesap_no number) return number;
Function sf_min_pastdue_principal_hesno(pn_kredi_hesap_no number) return number;
---------------------------------------------------------------------------------------
Function sf_pastdue_tax_hesno(pn_kredi_hesap_no number) return number;
Function sf_pastdue_int_hesno(pn_kredi_hesap_no number) return number ;
---------------------------------------------------------------------------------------
Function sf_ap_gecikme_gun_sayisi(pn_kredi_hesap_no number) return number;
Function sf_faiz_gecikme_gun_sayisi(pn_kredi_hesap_no number) return number;
Function sf_pastdue_opening_date(pn_kredi_hesap_no number) return date;
---------------------------------------------------------------------------------------
Function sf_acik_taksit_adedi(pn_hesap_no number) return number;
Function sf_max_odenmis_taksit_no (pn_hesap_no cbs_hesap_kredi.hesap_no%type) return number;
function sf_hesap_taksit_maxno_al(pn_hesap_no  number) return number;
Function sf_ensonodenmis_vadetarihial( pn_hesap_no number) return date;
Procedure sp_vw_odeme_plan_hesap_bilgi(  p_hesapno               number ,
                                            p_sozlesme_tarihi       out date ,
                                            p_sozlesme_no           out varchar2,
                                            p_kredi_tutari          out number,
                                            p_doviz                 out varchar2,
                                            p_taksit_sayisi         out number,
                                            p_acilis_tarihi         out date,		
                                            p_odeme_gunu            out number,
                                            p_odeme_tarihi_secimi   out varchar2,
                                            p_faiz_tipi             out varchar2,
                                            p_faiz_orani            out number,
                                            p_faiz_hesaplama_tipi   out varchar2,
                                            p_faiz_siklik_tipi      out varchar2,
                                            p_faiz_siklik           out number,
                                            p_taksit_siklik         out number,
                                            p_taksit_artis_siklik   out number,
                                            p_taksit_artis_orani    out number,
                                            p_odemesiz_ay_sayisi    out number,
                                            p_faiz_yontemi_methodu  out varchar2,
                                            p_ek_faiz_tutari        out number,
                                            p_odeme_plan_tipi       out varchar2,
                                            p_penalty_rate          out number,
                                            p_pastdue_faiz_orani    out number,
                                            p_yearly_effective_int_rate  out  number       --seval.colak 29082022 
                                            );
---------------------------------------------------------------------------------------
--seval.colak 23062022
 PROCEDURE sp_installment_unpaid_amounts( pn_hesap_no   number ,
                                          pn_taksit_no  number default 0 , --0 means all installments
                                          pn_unpaid_principal out number  ,
                                          pn_unpaid_interest out number  ,
                                          pn_unpaid_tax out number  ,
                                          pn_unpaid_delayed_interest out number  ,
                                          pn_unpaid_penalty_amount  out number  ,
                                          pn_unpaid_deferred_interest out number ,
                                          pn_unpaid_deferred_delayed_interest out number ,
                                          pn_unpaid_deferred_tax  out number ,
                                          pn_unpaid_deferred_penalty_amount out number )  ;  
---------------------------------------------------------------------------------------
 -- B-O-M seval.colak 02092022
    Function sf_deferred_int_total(pn_kredi_hesap_no number)     return number; 
    Function sf_deferred_delayed_int_total(pn_kredi_hesap_no number) return number; 
    Function sf_deferred_penalty_total(pn_kredi_hesap_no number) return number; 
    Function sf_deferred_tax_total(pn_kredi_hesap_no number) return number; 
    Function sf_cumint_for_undue_principal(pn_kredi_hesap_no number) return number;
    Function sf_undue_deferred_total(pn_kredi_hesap_no number) return number;
 -- E-O-M seval.colak 02092022
END;
/

