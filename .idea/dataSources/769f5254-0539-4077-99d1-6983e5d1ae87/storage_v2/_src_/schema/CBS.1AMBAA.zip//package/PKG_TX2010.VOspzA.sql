create PACKAGE     "PKG_TX2010" is

  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54
  -- Purpose : Hesap A??l??lar?n?nda kullan?lacakt?r.

  Procedure Yaratma_Oncesi(pn_islem_no number); 		-- Islem giris kontrolden once cagrilir
  Procedure Kontrol_Sonrasi(pn_islem_no number); 		-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			-- Islem iptal edildikten sonra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);				-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			-- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);			-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Function Sf_Rg_ModulTurUygunmu( ps_modul_tur_kod cbs_modul_tur.kod%type ) return varchar2;
  Function Sf_Rg_UrunTurUygunmu( ps_urun_tur_kod cbs_urun_tur.KOD%type ) return varchar2;

  Function Sf_Rg_HesapModulTur return varchar2;
  Function sf_istatistikkod_zorunlumu(ps_doviz_kodu varchar2 ) return varchar2;
  
--BOM CQDB00000598 Automation of incoming SWIFT MT103 MederT 05.02.2015
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);   
  PROCEDURE create_mt103_tx2010(pd_date date);       --Create MT103 Swift Tx2010-2012 from Swift messages table
  PROCEDURE create_prt_file(pd_date date);           --Create PRT file of incoming messages
--EOM CQDB00000598 Automation of incoming SWIFT MT103 MederT 05.02.2015

end PKG_TX2010;
/

