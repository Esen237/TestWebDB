create PACKAGE BODY     PKG_INT_QR_TRX IS
    /*** Sender ***/
    FUNCTION CreateQrPaymentRequest(ps_customer_id varchar2,
                                    ps_source_iban varchar2,
                                    ps_tran_type varchar2,
                                    pn_amount number,
                                    ps_recipient varchar2,
                                    ps_description varchar2,
                                    pc_ref OUT CursorReferenceType)
    RETURN varchar2 IS
        ln_islem_no number;
        ln_check_number number;
        ln_customer_no CBS.CBS_MUSTERI.MUSTERI_NO%type;
        ln_account_no CBS.CBS_HESAP.HESAP_NO%type;
        ls_account_branch CBS.CBS_HESAP.SUBE_KODU%type;

        ls_response varchar2(3) := '000';
        ls_check_result varchar2(3);
        account_check_failed exception;
    BEGIN
        ls_check_result := CBS.PKG_INT_QR_INQ.CheckQrAccount(ps_customer_id, ps_source_iban, CBS.PKG_GENEL.LC_AL, pn_amount);
        IF ls_check_result != '000' THEN
            RETURN ls_check_result;
        END IF;

        ln_islem_no := CBS.PKG_TX.islem_no_al;
        ln_check_number := CBS.PKG_GENEL.genel_kod_al('QR_CHECK_NUMBER');

        ln_customer_no := CBS.PKG_HESAP.GetMusteriNoFromExternal(ps_source_iban);
        ln_account_no := CBS.PKG_HESAP.GetHesapNoFromExternal(ps_source_iban, CBS.PKG_GENEL.LC_AL);
        ls_account_branch := CBS.PKG_HESAP.HesaptanSubeAl(ln_account_no);

        INSERT INTO CBS.CBS_IPC_QR_PAYMENTS(TX_NO, CHECK_NUMBER, TRANSACTION_TYPE, STATUS, CUSTOMER_NO, EXTERNAL_ACCOUNT, ACCOUNT_NO,
                                            ACCOUNT_BRANCH, AMOUNT, CURRENCY, RECIPIENT, DESCRIPTION, DIRECTION, CUSTOMER_ID)
        VALUES (ln_islem_no, ln_check_number, ps_tran_type, 'NEW', ln_customer_no, ps_source_iban, ln_account_no,
                ls_account_branch, pn_amount, CBS.PKG_GENEL.LC_AL, ps_recipient, ps_description, 'OUT', ps_customer_id);

        OPEN pc_ref
        FOR
            SELECT ln_islem_no as transaction_number,
                   ln_check_number as check_number
            FROM DUAL;

        RETURN ls_response;
    EXCEPTION
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.CreateQrPaymentRequest', ps_customer_id || '|' || ps_source_iban || '|' || ps_recipient || '|' || pn_amount, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            --RAISE_APPLICATION_ERROR(-20100, SQLERRM);
            ls_response := CBS.PKG_INT_API.GetErrorCode(SQLERRM);
            if ls_response = '999' or ls_response IS NULL then
                RAISE;
            end if;
            RETURN ls_response;
    END CreateQrPaymentRequest;

    FUNCTION GetTransaction(ps_transaction_number number,
                            ps_ipc_transaction_id varchar2,
                            ps_acquirer_bic varchar2,
                            ps_merchant_provider varchar2,
                            pn_fee number,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType)
    RETURN varchar2 IS
        l_row CBS.CBS_IPC_QR_PAYMENTS%rowtype;
        ls_check_result varchar2(3);
        ln_real_amount number := 0;
        ls_response varchar2(3) := '000';
        ln_transaction_check number;
        duplicate_ipc_transaction exception;
    BEGIN
        SELECT count(*) INTO ln_transaction_check FROM CBS.CBS_IPC_QR_PAYMENTS WHERE TRANSACTION_REFERENCE = ps_ipc_transaction_id;
        IF nvl(ln_transaction_check, 0) > 0 THEN
            RAISE duplicate_ipc_transaction;
        END IF;

        SELECT * INTO l_row
        FROM CBS.CBS_IPC_QR_PAYMENTS
        WHERE TX_NO = ps_transaction_number
          AND STATUS = 'NEW';

        ls_check_result := CBS.PKG_INT_QR_INQ.CheckQrAccount(PKG_INT_CUSTOMER_INQ.GetCustomerIdByCustomer(l_row.CUSTOMER_NO), l_row.EXTERNAL_ACCOUNT, l_row.CURRENCY,(l_row.AMOUNT + nvl(pn_fee, 0)));
        IF ls_check_result != '000' THEN
            RETURN ls_check_result;
        END IF;

        UPDATE CBS.CBS_IPC_QR_PAYMENTS
           SET TRANSACTION_REFERENCE = ps_ipc_transaction_id,
               ACQUIRER_BIC = ps_acquirer_bic,
               SERVICE_PROVIDER = ps_merchant_provider,
               FEE = nvl(pn_fee, 0)
         WHERE TX_NO = ps_transaction_number
           AND STATUS = 'NEW';

        ln_real_amount := CBS.PKG_HESAP.HesapBakiyeAl(l_row.ACCOUNT_NO);
        if ln_real_amount < 0 then
            ln_real_amount := -ln_real_amount;
        else
            ln_real_amount := 0;
        end if;

        OPEN pc_ref FOR
            SELECT ps_transaction_number as transaction_number,
                   l_row.RECIPIENT as recipient,
                   l_row.AMOUNT as amount,
                   l_row.CURRENCY as currency_code,
                   CBS.PKG_HESAP.Kullanilabilir_Bakiye_Al(l_row.ACCOUNT_NO) as initial_balance,
                   CBS.PKG_HESAP.Kullanilabilir_Bakiye_Al(l_row.ACCOUNT_NO) - l_row.AMOUNT - nvl(pn_fee, 0) as final_balance,
                   l_row.CREATED_DATE as transaction_date
            FROM DUAL;

        OPEN pc_ref2 FOR
            SELECT 'commission' as name,
                   'bank' as client,
                   nvl(pn_fee, 0) as amount,
                   CBS.PKG_GENEL.LC_AL as currency_code
            FROM DUAL
            UNION
            SELECT 'tax' as name,
                   'bank' as client,
                   0 as amount,
                   CBS.PKG_GENEL.LC_AL as currency_code
            FROM DUAL;

        OPEN pc_ref3 FOR
            SELECT CBS.PKG_KREDI.Sf_Kredi_Turu_Aciklamasi_Al(a.URUN_GRUB_NO) as name,
                   a.FC_LIMIT - nvl(a.FC_RISK, 0) - ln_real_amount as amount,
                   c.OVD_FAIZ_ORANI as interest_rate,
                   a.FC_DOVIZ_KODU as currency_code
            FROM CBS.CBS_MUSTERI b
                INNER JOIN CBS.CBS_HESAP c
                    ON b.MUSTERI_NO = c.MUSTERI_NO
                    AND c.OVERDRAFT = 'E'
                    AND c.DURUM_KODU = 'A'
                    AND c.HESAP_NO = l_row.ACCOUNT_NO
                INNER JOIN CBS.CBS_KREDI_TEKLIF e
                    ON e.MUSTERI_NO = b.MUSTERI_NO
                    AND e.DURUM_KODU = 'A'
                INNER JOIN CBS.CBS_MUSTERI_URUN_LIMIT a
                    ON a.MUSTERI_NO = b.MUSTERI_NO
                    AND a.FC_LIMIT <> 0
                    AND a.URUN_GRUB_NO in (18,19,20,44,59)
                    AND a.FC_DOVIZ_KODU = c.DOVIZ_KODU
                    AND a.KREDI_TEKLIF_SATIR_NUMARA = c.OVD_PROPOSAL_LINE_NO
                INNER JOIN CBS.CBS_KREDI_TEKLIF_LIMIT f
                    ON e.TEKLIF_NO = f.TEKLIF_NO;

        RETURN ls_response;
    EXCEPTION
        WHEN duplicate_ipc_transaction THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.GetTransaction', ps_ipc_transaction_id, 'unique constraint TRANSACTION_REFERENCE violated');
            RETURN '497';
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.GetTransaction', ps_transaction_number, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            ls_response := CBS.PKG_INT_API.GetErrorCode(SQLERRM);
            if ls_response = '999' or ls_response IS NULL then
                RAISE;
            end if;
            RETURN ls_response;
    END GetTransaction;

    FUNCTION Blocking(ps_transaction_number number,
                      pc_ref OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType)
    RETURN varchar2 IS
        l_row CBS.CBS_IPC_QR_PAYMENTS%rowtype;
        ls_block_reference varchar2(100);
        ln_initial_balance number := 0;
        ln_real_amount number := 0;
        ls_response varchar2(3) := '000';
    BEGIN
        SELECT * INTO l_row
        FROM CBS.CBS_IPC_QR_PAYMENTS
        WHERE TX_NO = ps_transaction_number
          AND STATUS = 'NEW';

        ln_initial_balance := CBS.PKG_HESAP.Kullanilabilir_Bakiye_Al(l_row.ACCOUNT_NO);

        CBS.PKG_INT_API.create_transaction(pn_islem_numara => ps_transaction_number,
                                           pn_islem_kod => 7000,
                                           pc_modul_tur_kod => 'SYSTEM',
                                           pc_urun_tur_kod => 'GENERAL',
                                           pc_urun_sinif_kod => 'GENERAL',
                                           pn_tutar => (l_row.AMOUNT + l_row.FEE),
                                           pc_amir_bolum_kodu => l_row.ACCOUNT_BRANCH,
                                           pc_bolum_kodu => l_row.ACCOUNT_BRANCH,
                                           pc_doviz_kod => l_row.CURRENCY,
                                           pn_musteri_numara => l_row.CUSTOMER_NO,
                                           pc_hesap_numara => l_row.ACCOUNT_NO);
        ls_block_reference := NULL;
        CBS.PKG_BLOKE.sp_bloke_yarat(ls_block_reference,
                                     l_row.CUSTOMER_NO,
                                     l_row.ACCOUNT_NO,
                                     l_row.CURRENCY,
                                     (l_row.AMOUNT + l_row.FEE),
                                     '91',
                                     'QR Transaction blocking, QR payment code ' || l_row.TRANSACTION_TYPE || ' and Recipient ' || l_row.RECIPIENT,
                                     pkg_muhasebe.banka_tarihi_bul,
                                     NULL, --pkg_muhasebe.banka_tarihi_bul + 40,
                                     NULL,
                                     ps_transaction_number);

        UPDATE CBS.CBS_IPC_QR_PAYMENTS
        SET BLOCK_REFERENCE = ls_block_reference,
            STATUS = 'PENDING',
            CONFIRMED_DATE = SYSDATE
        WHERE TX_NO = ps_transaction_number
          AND STATUS = 'NEW';

        ln_real_amount := CBS.PKG_HESAP.HesapBakiyeAl(l_row.ACCOUNT_NO);
        if ln_real_amount < 0 then
            ln_real_amount := -ln_real_amount;
        else
            ln_real_amount := 0;
        end if;

        OPEN pc_ref FOR
            SELECT ps_transaction_number as transaction_number,
                   l_row.TRANSACTION_REFERENCE as ipc_transaction_id,
                   l_row.AMOUNT as amount,
                   l_row.CURRENCY as currency_code,
                   ln_initial_balance as initial_balance,
                   CBS.PKG_HESAP.Kullanilabilir_Bakiye_Al(l_row.ACCOUNT_NO) as final_balance,
                   l_row.CREATED_DATE as transaction_date
            FROM DUAL;

        OPEN pc_ref2 FOR
            SELECT 'commission' as name,
                   'bank' as client,
                   l_row.FEE as amount,
                   CBS.PKG_GENEL.LC_AL as currency_code
            FROM DUAL
            UNION
            SELECT 'tax' as name,
                   'bank' as client,
                   0 as amount,
                   CBS.PKG_GENEL.LC_AL as currency_code
            FROM DUAL;

        OPEN pc_ref3 FOR
            SELECT CBS.PKG_KREDI.Sf_Kredi_Turu_Aciklamasi_Al(a.URUN_GRUB_NO) as name,
                   a.FC_LIMIT - nvl(a.FC_RISK, 0) - ln_real_amount as amount,
                   c.OVD_FAIZ_ORANI as interest_rate,
                   a.FC_DOVIZ_KODU as currency_code
            FROM CBS.CBS_MUSTERI b
                INNER JOIN CBS.CBS_HESAP c
                    ON b.MUSTERI_NO = c.MUSTERI_NO
                    AND c.OVERDRAFT = 'E'
                    AND c.DURUM_KODU = 'A'
                    AND c.HESAP_NO = l_row.ACCOUNT_NO
                INNER JOIN CBS.CBS_KREDI_TEKLIF e
                    ON e.MUSTERI_NO = b.MUSTERI_NO
                    AND e.DURUM_KODU = 'A'
                INNER JOIN CBS.CBS_MUSTERI_URUN_LIMIT a
                    ON a.MUSTERI_NO = b.MUSTERI_NO
                    AND a.FC_LIMIT <> 0
                    AND a.URUN_GRUB_NO in (18,19,20,44,59)
                    AND a.FC_DOVIZ_KODU = c.DOVIZ_KODU
                    AND a.KREDI_TEKLIF_SATIR_NUMARA = c.OVD_PROPOSAL_LINE_NO
                INNER JOIN CBS.CBS_KREDI_TEKLIF_LIMIT f
                    ON e.TEKLIF_NO = f.TEKLIF_NO;

        RETURN ls_response;
    EXCEPTION
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.Blocking', ps_transaction_number, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            ls_response := CBS.PKG_INT_API.GetErrorCode(SQLERRM);
            if ls_response = '999' or ls_response IS NULL then
                RAISE;
            end if;
            RETURN ls_response;
    END Blocking;

    /*FUNCTION ExecuteQrPayment(pn_islem_no number, ps_transaction_id varchar2, ps_acquirer_bic varchar2, pn_fee number) RETURN CursorReferenceType IS
        l_row CBS.CBS_IPC_QR_PAYMENTS%rowtype;
        ls_block_reference varchar2(100);
        pc_ref CursorReferenceType;
    BEGIN
        SELECT * INTO l_row
        FROM CBS.CBS_IPC_QR_PAYMENTS
        WHERE TX_NO = pn_islem_no;

        Pkg_Int_Api.create_transaction(pn_islem_numara => pn_islem_no,
                                       pn_islem_kod => 7000,
                                       pc_modul_tur_kod => 'SYSTEM',
                                       pc_urun_tur_kod => 'GENERAL',
                                       pc_urun_sinif_kod => 'GENERAL',
                                       pn_tutar => (l_row.AMOUNT + nvl(pn_fee, 0)),
                                       pc_amir_bolum_kodu => l_row.ACCOUNT_BRANCH,
                                       pc_bolum_kodu => l_row.ACCOUNT_BRANCH,
                                       pc_doviz_kod => l_row.CURRENCY,
                                       pn_musteri_numara => l_row.CUSTOMER_NO,
                                       pc_hesap_numara => l_row.ACCOUNT_NO);

        ls_block_reference := NULL;
        CBS.PKG_BLOKE.sp_bloke_yarat(ls_block_reference,
                                     l_row.CUSTOMER_NO,
                                     l_row.ACCOUNT_NO,
                                     PKG_GENEL.LC_AL,
                                     (l_row.AMOUNT + nvl(pn_fee, 0)),
                                     '91',
                                     'IPC QR payment blocking',
                                     pkg_muhasebe.banka_tarihi_bul,
                                     NULL, --pkg_muhasebe.banka_tarihi_bul + 40,
                                     NULL,
                                     pn_islem_no);

        UPDATE CBS.CBS_IPC_QR_PAYMENTS
        SET TRANSACTION_REFERENCE = ps_transaction_id,
            BLOCK_REFERENCE = ls_block_reference,
            ACQUIRER_BIC = ps_acquirer_bic,
            FEE = nvl(pn_fee, 0),
            STATUS = 'PENDING',
            CONFIRMED_DATE = SYSDATE
        WHERE TX_NO = pn_islem_no;

        OPEN pc_ref
        FOR
            SELECT ls_block_reference as block_ref FROM DUAL;

        RETURN pc_ref;
    EXCEPTION
        WHEN OTHERS THEN
            log_at('CBS.PKG_INT_QR_TRX.ExecuteQrPayment', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE_APPLICATION_ERROR(-20100, SQLERRM);
    END ExecuteQrPayment;*/

    FUNCTION SetFinalStatus(ps_transaction_number number, ps_status varchar2, ps_description varchar2 DEFAULT NULL)
    RETURN varchar2 IS --PRAGMA AUTONOMOUS_TRANSACTION;
        CURSOR c_block IS
            SELECT b.*
            FROM CBS.CBS_IPC_QR_PAYMENTS q
            JOIN CBS.CBS_BLOKE b
                ON q.BLOCK_REFERENCE = b.BLOKE_REFERANS
                AND b.BLOKE_NEDEN_KODU = '91'
                AND b.DURUM_KODU = 'A'
            WHERE q.TX_NO = ps_transaction_number
              AND q.STATUS = 'PENDING'
              AND q.DIRECTION = 'OUT';

        r_block c_block%rowtype;
        ls_response varchar2(3) := '000';
        ls_description varchar2(2000);
    BEGIN
        IF ps_transaction_number IS NOT NULL then
            IF upper(ps_status) = 'OK' THEN
                CBS.PKG_INT_API.process_transaction(ps_transaction_number);

                UPDATE CBS.CBS_IPC_QR_PAYMENTS
                SET STATUS = 'PROCESSED',
                    PROCESSED_DATE = SYSDATE
                WHERE TX_NO = ps_transaction_number
                  AND STATUS = 'PENDING';
            ELSE
                ROLLBACK;

                OPEN c_block;
                FETCH c_block INTO r_block;

                IF (c_block%FOUND) THEN
                    BEGIN
                        CBS.PKG_BLOKE.sp_bloke_yarat(ps_bloke_referans => r_block.BLOKE_REFERANS,
                                                     pn_musteri_no => r_block.MUSTERI_NO,
                                                     pn_hesap_no => r_block.HESAP_NO,
                                                     ps_doviz_kodu => r_block.DOVIZ_KODU,
                                                     pn_bloke_tutari => 0,
                                                     ps_bloke_neden_kodu => '91',
                                                     ps_aciklama => 'Releasing IPC QR payment blocking',
                                                     pd_bloke_tarihi => PKG_MUHASEBE.BANKA_TARIHI_BUL,
                                                     pd_bloke_bitis_tarihi => PKG_MUHASEBE.BANKA_TARIHI_BUL,
                                                     p_coz_kayit_tarih => PKG_MUHASEBE.BANKA_TARIHI_BUL,
                                                     p_coz_kayit_sistem_tarih => SYSDATE,
                                                     p_coz_kayit_kullanici_kodu => PKG_BAGLAM.KULLANICI_KODU,
                                                     ps_kapama => 'KAPAMA');
                    EXCEPTION
                        WHEN OTHERS THEN
                            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.SetFinalStatus_CloseBlock', ps_transaction_number, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                            RAISE;
                    END;
                END IF;
                CLOSE c_block;

                CBS.PKG_INT_API.process_transaction(ps_transaction_number);

                ls_description := case when ps_description is null then SQLERRM else ps_description || ' \n ' || SQLERRM end;
                UPDATE CBS.CBS_IPC_QR_PAYMENTS
                SET STATUS = 'CANCELLED',
                    CANCELLED_DATE = SYSDATE,
                    ERROR_DESCRIPTION = ls_description
                WHERE TX_NO = ps_transaction_number;
                LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.SetFinalStatus_CancelledReason', ps_transaction_number, ls_description, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            END IF;
        ELSE
            ls_response := '490'; --ps_transaction_number is null
        END IF;

        RETURN ls_response;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;

            ls_description := case when ps_description is null then SQLERRM else ps_description || ' \n ' || SQLERRM end;
            UPDATE CBS.CBS_IPC_QR_PAYMENTS
            SET STATUS = 'CANCELLED',
                CANCELLED_DATE = SYSDATE,
                ERROR_DESCRIPTION = ls_description
            WHERE TX_NO = ps_transaction_number;

            COMMIT;

            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.SetFinalStatus', ps_transaction_number, ls_description, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

            ls_response := CBS.PKG_INT_API.GetErrorCode(SQLERRM);
            if ls_response = '999' or ls_response IS NULL then
                RAISE;
            end if;
            RETURN ls_response;
    END SetFinalStatus;

    /*** Beneficiary ***/
    FUNCTION CreateQrBeneficiaryTransaction(ps_transaction_type varchar2,
                                            ps_target_iban varchar2,
                                            pn_amount number,
                                            ps_provider varchar2,
                                            ps_description varchar2,
                                            ps_ipc_transaction_id varchar2,
                                            ps_aqr_transaction_id varchar2,
                                            ps_aqr_client_type varchar2,
                                            ps_aqr_check_number varchar2,
                                            ps_our_qr varchar2,
                                            pc_ref OUT CursorReferenceType)
    RETURN varchar2 IS
        ln_islem_no number;
        ln_check_number number;
        ln_customer_no CBS.CBS_MUSTERI.MUSTERI_NO%type;
        ln_account_no CBS.CBS_HESAP.HESAP_NO%type;
        ls_account_branch CBS.CBS_HESAP.SUBE_KODU%type;
        ls_merchant_name varchar2(2000);
        ls_response varchar2(3) := '000';
        ln_transaction_check number;
        ln_our_qr_count number;
        duplicate_ipc_transaction exception;
        our_qr_transaction_error exception;
    BEGIN
        SELECT count(*) INTO ln_transaction_check FROM CBS.CBS_IPC_QR_PAYMENTS WHERE TRANSACTION_REFERENCE = ps_ipc_transaction_id;
        
        IF nvl(ln_transaction_check, 0) > 0 THEN
            RAISE duplicate_ipc_transaction;
        END IF;

        SELECT count(*) INTO ln_our_qr_count FROM CBS.CBS_IPC_QR_PAYMENTS WHERE OUR_QR_TRANSACTION_ID = ps_our_qr AND STATUS = 'PROCESSED';
        IF nvl(ln_our_qr_count, 0) > 0 THEN
            RAISE our_qr_transaction_error;
        END IF;

        ln_islem_no := CBS.PKG_TX.islem_no_al;
        ln_check_number := CBS.PKG_GENEL.genel_kod_al('QR_CHECK_NUMBER');

        ln_customer_no := CBS.PKG_HESAP.GetMusteriNoFromExternal(ps_target_iban);
        ln_account_no := CBS.PKG_HESAP.GetHesapNoFromExternal(ps_target_iban, CBS.PKG_GENEL.LC_AL);
        ls_account_branch := CBS.PKG_HESAP.HesaptanSubeAl(ln_account_no);
        ls_merchant_name := CBS.PKG_MUSTERI.sf_musteri_adi(ln_customer_no);

        INSERT INTO CBS.CBS_IPC_QR_PAYMENTS(TX_NO, CHECK_NUMBER, TRANSACTION_TYPE, STATUS, CUSTOMER_NO, EXTERNAL_ACCOUNT, ACCOUNT_NO,
                                            ACCOUNT_BRANCH, AMOUNT, CURRENCY, RECIPIENT, SERVICE_PROVIDER, DESCRIPTION, TRANSACTION_REFERENCE,
                                            DIRECTION, SENDER_TRANSACTION_ID, SENDER_CLIENT_TYPE, SENDER_CHECK_NO, OUR_QR_TRANSACTION_ID)
        VALUES (ln_islem_no, ln_check_number, ps_transaction_type, 'NEW', ln_customer_no, ps_target_iban, ln_account_no,
                ls_account_branch, pn_amount, CBS.PKG_GENEL.LC_AL, ls_merchant_name, ps_provider, ps_description,
                ps_ipc_transaction_id, 'IN', ps_aqr_transaction_id, ps_aqr_client_type, ps_aqr_check_number, ps_our_qr);

        OPEN pc_ref
        FOR
            SELECT TX_NO as transaction_number,
                   TRANSACTION_REFERENCE as ipc_transaction_id,
                   CHECK_NUMBER,
                   STATUS,
                   AMOUNT,
                   CBS.PKG_INT_QR_INQ.MaskQRName(RECIPIENT) as recipient,
                   CBS.PKG_MUSTERI.SF_MUSTERI_TIPI_AL(CUSTOMER_NO) as client_type,
                   PROCESSED_DATE as executed_time,
                   CREATED_DATE as created,
                   TRANSACTION_TYPE as transaction_type
            FROM CBS.CBS_IPC_QR_PAYMENTS
            WHERE TX_NO = ln_islem_no;

        RETURN ls_response;
    EXCEPTION
        WHEN duplicate_ipc_transaction THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.CreateQrBeneficiaryTransaction', ps_ipc_transaction_id, 'unique constraint TRANSACTION_REFERENCE violated');
            RETURN '497';
        WHEN our_qr_transaction_error THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.CreateQrBeneficiaryTransaction', ps_our_qr, 'Duplicated our QR');
            RETURN '460';
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.CreateQrBeneficiaryTransaction', ps_ipc_transaction_id, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            ls_response := CBS.PKG_INT_API.GetErrorCode(SQLERRM);
            if ls_response = '999' or ls_response IS NULL then
                RAISE;
            end if;
            RETURN ls_response;
    END CreateQrBeneficiaryTransaction;

    FUNCTION ExecuteQrBeneficiaryTransaction(ps_ipc_transaction_id varchar2, pc_ref OUT CursorReferenceType) RETURN varchar2 IS
        CURSOR cur_ipc_qr IS
            SELECT q.*
            FROM CBS.CBS_IPC_QR_PAYMENTS q
            WHERE q.TRANSACTION_REFERENCE = ps_ipc_transaction_id;

        l_row cur_ipc_qr%rowtype;
        ln_tx_no CBS.CBS_ISLEM.NUMARA%type;
        ls_response varchar2(3) := '000';
        ln_transaction_check number;
        duplicate_ipc_transaction exception;
    BEGIN
        SELECT count(*) INTO ln_transaction_check FROM CBS.CBS_IPC_QR_PAYMENTS WHERE TRANSACTION_REFERENCE = ps_ipc_transaction_id;
        IF nvl(ln_transaction_check, 0) > 1 THEN
            RAISE duplicate_ipc_transaction;
        END IF;

        UPDATE CBS.CBS_IPC_QR_PAYMENTS
        SET STATUS = 'PENDING',
            CONFIRMED_DATE = SYSDATE
        WHERE TRANSACTION_REFERENCE = ps_ipc_transaction_id
          AND STATUS = 'NEW';

        IF cur_ipc_qr%ISOPEN THEN
            CLOSE cur_ipc_qr;
        END IF;

        OPEN cur_ipc_qr;
        FETCH cur_ipc_qr INTO l_row;

        IF cur_ipc_qr%FOUND THEN
            ln_tx_no := l_row.TX_NO;
            BEGIN
                CBS.PKG_INT_API.create_transaction(pn_islem_numara => ln_tx_no,
                                                   pn_islem_kod => 7000,
                                                   pc_modul_tur_kod => 'SYSTEM',
                                                   pc_urun_tur_kod => 'GENERAL',
                                                   pc_urun_sinif_kod => 'GENERAL',
                                                   pn_tutar => l_row.AMOUNT,
                                                   pc_amir_bolum_kodu => l_row.ACCOUNT_BRANCH,
                                                   pc_bolum_kodu => l_row.ACCOUNT_BRANCH,
                                                   pc_doviz_kod => l_row.CURRENCY,
                                                   pn_musteri_numara => l_row.CUSTOMER_NO,
                                                   pc_hesap_numara => l_row.ACCOUNT_NO);

                ls_response := SetFinalStatus(ln_tx_no, 'OK');

                IF ls_response <> '000' THEN
                    RETURN ls_response;
                END IF;
--             EXCEPTION
--                 WHEN OTHERS THEN
--                     LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.ExecuteQrBeneficiaryTransaction_createTransaction', ps_ipc_transaction_id,SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
--                     RAISE;
            END;
        END IF;
        CLOSE cur_ipc_qr;

        OPEN pc_ref
        FOR
            SELECT TX_NO as transaction_number,
                   TRANSACTION_REFERENCE as ipc_transaction_id,
                   CHECK_NUMBER,
                   STATUS,
                   AMOUNT,
                   CBS.PKG_INT_QR_INQ.MaskQRName(RECIPIENT) as recipient,
                   CBS.PKG_MUSTERI.SF_MUSTERI_TIPI_AL(CUSTOMER_NO) as client_type,
                   PROCESSED_DATE as executed_time,
                   CREATED_DATE as created,
                   transaction_type as transaction_type
            FROM CBS.CBS_IPC_QR_PAYMENTS
            WHERE TRANSACTION_REFERENCE = ps_ipc_transaction_id;

        RETURN ls_response;
    EXCEPTION
        WHEN duplicate_ipc_transaction THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.ExecuteQrBeneficiaryTransaction', ps_ipc_transaction_id, 'unique constraint TRANSACTION_REFERENCE violated');
            RETURN '497';
        WHEN OTHERS THEN
            ls_response := SetFinalStatus(ln_tx_no, 'CANCEL', SQLERRM);
            LOG_QR_ERROR('CBS.PKG_INT_QR_TRX.ExecuteQrBeneficiaryTransaction', ps_ipc_transaction_id, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            ls_response := CBS.PKG_INT_API.GetErrorCode(SQLERRM);
            if ls_response = '999' or ls_response IS NULL then
                RAISE;
            end if;
            RETURN ls_response;
    END ExecuteQrBeneficiaryTransaction;
END;
/

