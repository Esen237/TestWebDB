create PACKAGE BODY PKG_TX1500 IS
	pn_1500_musteri_aciklama        number;
	pn_1500_doviz_kod        number;
	pn_1500_lc_tutar        number;
	pn_1500_fc_tutar        number;
	pn_1500_banka_aciklama        number;
	pn_1500_borclu_hesap_sube_kodu        number;
	pn_1500_borclu_hesap_no        number;
	pn_1500_referans        number;
	pn_1500_fis_aciklama        number;
	pn_1500_kur_lc        number;
	pn_1500_istatistik_kod        number;
	pn_1500_islem_sube_kodu        number;
	pn_1500_tl_mi        number;
	pn_1500_yp_mi        number;
	pn_1500_damga_vergi_tutari        number;
	pn_1500_bsmv_tutari        number;
	pn_1500_musteri_tahsil_tutar        number;
	pn_1500_toplam_vergi        number;
	pn_1500_fark_tutar        number;
	pn_1500_musteri_aciklama_2        number;
	pn_1500_damga_vergi_orani        number;
	pn_1500_dv_aciklama_1        number;
	pn_1500_dv_aciklama_2        number;
	pn_1500_dv_aciklama_3        number;
	pn_1500_genel        number;
	pn_1500_ek        number;
	pn_1500_bireysel        number;
	pn_1500_kmh        number;
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
  	   null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	update cbs_sozlesme_islem
	set durum_kodu = 'ACIK'
	where tx_no = pn_islem_no;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	update cbs_sozlesme_islem
	set durum_kodu = 'IPTAL'
	where tx_no = pn_islem_no;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number)
  is
  	   ln_sozlesme_No number;
  	   ln_ek_sozlesme_No number;
	   ln_musteri_no number;
	   ls_sozlesme_tur_kodu cbs_sozlesme.SOZLESME_TUR_KODU%type;
   Begin
   		select musteri_no,
			   sozlesme_no ,
			   ek_sozlesme_no ,
			   sozlesme_tur_kodu
		into   ln_musteri_no,
			   ln_sozlesme_no ,
			   ln_ek_sozlesme_no,
			   ls_sozlesme_tur_kodu
		from cbs_sozlesme_islem
		where tx_no = pn_islem_no;

		if ls_sozlesme_tur_kodu = 'EK' then
		   ln_ek_sozlesme_no := pkg_sozlesme.SF_SOZLESME_EKNO_AL (ln_musteri_no,ln_sozlesme_no);
	  	else
  		  ln_sozlesme_no :=  pkg_sozlesme.SF_SOZLESME_NO_AL(ln_musteri_no);
		  ln_ek_sozlesme_no := 0 ;
		end if;

		update cbs_sozlesme_islem
		set sozlesme_no = ln_sozlesme_no ,
			ek_sozlesme_no = ln_ek_sozlesme_no
	    where tx_no = pn_islem_no ;

		pkg_sozlesme.sp_sozlesme_anatabloya_at(pn_islem_no);

  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
   Begin

   	update cbs_sozlesme_islem
	set durum_kodu = 'IPTAL'
	where tx_no = pn_islem_no;

   	update cbs_sozlesme
	set durum_kodu = 'IPTAL'
	where (musteri_no,sozlesme_no,ek_sozlesme_no) in (select musteri_no,sozlesme_no,ek_sozlesme_no
		  										   from cbs_sozlesme_islem
												   where tx_no = pn_islem_no) ;

  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	update cbs_sozlesme_islem
	set durum_kodu = 'RED'
	where tx_no = pn_islem_no;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;

	ln_fis_no				   cbs_fis.numara%type ;
	ls_islem_kod               cbs_islem.islem_kod%type :='1500';
	ls_musteri_aciklama        varchar2(2000);
	ls_banka_aciklama          varchar2(2000);
	ls_fis_aciklama            varchar2(2000);
	ls_aciklama				   varchar2(2000);
	ls_musteri_aciklama_2      varchar2(2000);
	ls_dv_aciklama_1            varchar2(2000);
	ls_dv_aciklama_2            varchar2(2000);
	ls_dv_aciklama_3            varchar2(2000);
	ln_musteri_no			   cbs_musteri.musteri_no%TYPE;
	ls_islem_sube_kodu  cbs_hesap.sube_kodu%TYPE;
    ln_borclu_hesap_no		   cbs_hesap.hesap_no%TYPE;
	ls_borclu_hesap_sube_kodu  cbs_hesap.sube_kodu%TYPE;
	ln_tutar			   	   number;
	ln_kur			   	   	   number;
	ln_istatistik_kodu		    number;
	ls_doviz_kodu			   cbs_hesap.doviz_kodu%type;
	ln_plan_no				   number ;
    ln_MUSTERI_TAHSIL_EDIL_TUTAR number;
	ln_sozlesme_no number;
	ln_DAMGA_VERGISI_MUSTERI_PAYI number;
	ln_dv_matrah				  number;
	ln_dv_tutar number;
	ln_dv_oran  number;
	ln_bsmv_oran number;
	ln_retval number;
	ln_BSMV_tutar number;
	ls_sozlesme_tur_kodu   cbs_sozlesme.sozlesme_tur_kodu%type;
	sozlesme_tur_yok exception;
	ln_ek_sozlesme_no number;
	cursor islem_cursor is
		select
		 musteri_no,
		 dv_tahsil_hesap_no ,
		 decode(dv_tahsil_hesap_no,null,null,Pkg_Hesap.HesaptanSubeAl(dv_tahsil_hesap_no)),
		 doviz_kodu,
		 sozlesme_tutari     ,
		 pkg_tx.Amir_BolumKodu_Al( tx_no),
		 sozlesme_no,
		 MUSTERI_TAHSIL_EDILECEK_TUTAR,
		 DAMGA_VERGISI_MUSTERI_PAYI,
		 sozlesme_tur_kodu ,
		 EK_sozlesme_no
	   from cbs_sozlesme_islem
	   where tx_no = pn_islem_no ;
  Begin

/* islem bilgisi detaylari alinir */
	 if islem_cursor%isopen then
	   close islem_cursor;
	 end if;

  	   open islem_cursor;
	    fetch islem_cursor into
			  ln_musteri_no,
			  ln_borclu_hesap_no,
			  ls_borclu_hesap_sube_kodu,
			  ls_doviz_kodu,
			  ln_tutar     ,
			  ls_islem_sube_kodu,
			  ln_sozlesme_no,
			  ln_musteri_tahsil_edil_tutar,
			  ln_DAMGA_VERGISI_MUSTERI_PAYI,
			  ls_sozlesme_tur_kodu,
			  ln_ek_sozlesme_no;

	   if islem_cursor%notfound then
	          close islem_cursor;
       end if;
	   close islem_cursor;

/*** Liste Deger Atama K?sm? **/

/**** varchar list ****/

   pkg_parametre.deger('1500_FIS_ACIKLAMA',ls_fis_aciklama);
   pkg_parametre.deger('1500_BANKA_ACIKLAMA',ls_banka_aciklama);
   pkg_parametre.deger('1500_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
   pkg_parametre.deger('1500_MUSTERI_ACIKLAMA_2',ls_musteri_aciklama_2);
   pkg_parametre.deger('1500_DV_ACIKLAMA_1',ls_dv_aciklama_1);
   pkg_parametre.deger('1500_DV_ACIKLAMA_2',ls_dv_aciklama_2);
   pkg_parametre.deger('1500_DV_ACIKLAMA_3',ls_dv_aciklama_3);
   pkg_parametre.deger('1500_DAMGA_VERGI_ORANI',ln_dv_oran);

   ln_retval := pkg_parametre.al ( 'G_BSMV_YUZDE', ln_bsmv_oran );
 /**** boolean list ****/
    boolean_list(pn_1500_tl_mi ):=false;
    boolean_list(pn_1500_YP_mi ):=false;
	boolean_list(pn_1500_EK):=false;
	boolean_list(pn_1500_kmh):=false;
	boolean_list(pn_1500_bireysel):=false;
	boolean_list(pn_1500_genel):=false;
/**** number list ****/
  if ls_doviz_kodu = pkg_genel.lc_al then
 	  boolean_list(pn_1500_tl_mi ) := true;
   else
 	   boolean_list(pn_1500_yp_mi ) := true;
   end if;

   case  ls_sozlesme_tur_kodu
	 	 when   'EK' Then
	   	  	  boolean_list(pn_1500_ek) := true;
	 	 when   'BIREYSEL KREDI' Then
	   	  	  boolean_list(pn_1500_bireysel) := true;
	 	 when   'GENEL KREDI' Then
	   	  	  boolean_list(pn_1500_genel) := true;
	 	 when   'KMH' Then
	   	  	  boolean_list(pn_1500_kmh) := true;
		 else
			 raise sozlesme_tur_yok;
	end case;

 if  NVL(ln_DAMGA_VERGISI_MUSTERI_PAYI,0) <> 0 then
 	ln_dv_matrah :=   pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(ls_DOVIZ_KODU,pkg_genel.LC_AL,null,ln_tutar,1,null,null,'N','S') );
	ln_dv_tutar  :=  pkg_kur.yuvarla(pkg_genel.LC_AL,(ln_dv_matrah  * ln_dv_oran ) /10000 );
	ln_bsmv_tutar := pkg_kur.yuvarla(pkg_genel.LC_AL, (ln_dv_tutar * ln_bsmv_oran ) /100);
 end if;

  number_list(pn_1500_lc_tutar) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_DOVIZ_KODU,pkg_genel.LC_AL,null,ln_tutar,1,null,null,'O','A'));
  number_list(pn_1500_fc_tutar) := ln_tutar;
  number_list(pn_1500_kur_lc)   :=  pkg_kur.doviz_doviz_karsilik(ls_DOVIZ_KODU,pkg_genel.LC_AL,null,1,1,null,null,'O','A');

  number_list(pn_1500_damga_vergi_tutari) :=NVL(ln_dv_tutar,0);
  number_list(pn_1500_bsmv_tutari) := NVL(ln_bsmv_tutar,0);
  number_list(pn_1500_musteri_tahsil_tutar) := pkg_kur.yuvarla(pkg_genel.LC_AL, NVL((ln_dv_TUTAR * ln_DAMGA_VERGISI_MUSTERI_PAYI)/ 100 ,0));
  number_list(pn_1500_toplam_vergi) :=  number_list(pn_1500_damga_vergi_tutari) + number_list(pn_1500_bsmv_tutari);
  number_list(pn_1500_fark_tutar) :=  number_list(pn_1500_damga_vergi_tutari) -  number_list(pn_1500_musteri_tahsil_tutar);

/*varchar list */

   ls_aciklama := to_char(ln_musteri_no)  || ls_musteri_aciklama  ||'  ' || to_char(ln_sozlesme_no) || ls_musteri_aciklama_2;
   ls_dv_aciklama_1 := to_char(ln_sozlesme_no) || ls_Dv_aciklama_1  || to_char(  number_list(pn_1500_toplam_vergi)) ;
   ls_dv_aciklama_2 := to_char(ln_musteri_no)  || ls_musteri_aciklama  ||'  ' || to_char(ln_sozlesme_no) || ls_Dv_aciklama_2 || to_char(ln_dv_matrah);
   ls_dv_aciklama_3 := to_char(ln_musteri_no)  || ls_musteri_aciklama  ||'  ' || to_char(ln_sozlesme_no) || ls_Dv_aciklama_3 || to_char(ln_bsmv_tutar);

   varchar_list(pn_1500_fis_aciklama) 	        := ls_fis_aciklama ;
   varchar_list(pn_1500_banka_aciklama)         := ls_aciklama;
   varchar_list(pn_1500_musteri_aciklama)       := ls_aciklama;
   varchar_list(pn_1500_dv_aciklama_1)          :=  ls_dv_aciklama_1;
   varchar_list(pn_1500_dv_aciklama_2)          :=  ls_dv_aciklama_2;
   varchar_list(pn_1500_dv_aciklama_3)          :=  ls_dv_aciklama_3;
   varchar_list(pn_1500_referans) 	   	 		:= to_char(ln_musteri_no);
   varchar_list(pn_1500_doviz_kod) 		 	    := ls_doviz_kodu;
   varchar_list(pn_1500_borclu_hesap_sube_kodu) := ls_borclu_hesap_sube_kodu;
   varchar_list(pn_1500_borclu_hesap_no)        := to_char(ln_borclu_hesap_no);
   varchar_list(pn_1500_islem_sube_kodu) 		:= ls_islem_sube_kodu;


/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							ln_plan_no,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							0,
							ls_fis_aciklama);

	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);


/* fis no alan? guncellenir */
		update cbs_sozlesme_islem
		set son_fis_numara = ln_fis_no
	    where tx_no = pn_islem_no ;

		update cbs_sozlesme
		set son_fis_numara = ln_fis_no
		where  musteri_no  =ln_musteri_no and
			   sozlesme_no = ln_sozlesme_no and
			   ek_sozlesme_no = ln_ek_sozlesme_no;


 Exception
  when sozlesme_tur_yok then
  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '583' || pkg_hata.getUCPOINTER);
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '581' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

 End;


 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

 Begin
		pn_1500_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1500_MUSTERI_ACIKLAMA');
		pn_1500_doviz_kod :=pkg_muhasebe.parametre_index_bul('1500_DOVIZ_KOD');
		pn_1500_lc_tutar :=pkg_muhasebe.parametre_index_bul('1500_LC_TUTAR');
		pn_1500_fc_tutar :=pkg_muhasebe.parametre_index_bul('1500_FC_TUTAR');
		pn_1500_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1500_BANKA_ACIKLAMA');
		pn_1500_borclu_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1500_BORCLU_HESAP_SUBE_KODU');
		pn_1500_borclu_hesap_no :=pkg_muhasebe.parametre_index_bul('1500_BORCLU_HESAP_NO');
		pn_1500_referans :=pkg_muhasebe.parametre_index_bul('1500_REFERANS');
		pn_1500_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1500_FIS_ACIKLAMA');
		pn_1500_kur_lc :=pkg_muhasebe.parametre_index_bul('1500_KUR_LC');
		pn_1500_istatistik_kod :=pkg_muhasebe.parametre_index_bul('1500_ISTATISTIK_KOD');
		pn_1500_islem_sube_kodu :=pkg_muhasebe.parametre_index_bul('1500_ISLEM_SUBE_KODU');
		pn_1500_tl_mi :=pkg_muhasebe.parametre_index_bul('1500_TL_MI');
		pn_1500_yp_mi :=pkg_muhasebe.parametre_index_bul('1500_YP_MI');
		pn_1500_damga_vergi_tutari :=pkg_muhasebe.parametre_index_bul('1500_DAMGA_VERGI_TUTARI');
		pn_1500_bsmv_tutari :=pkg_muhasebe.parametre_index_bul('1500_BSMV_TUTARI');
		pn_1500_musteri_tahsil_tutar :=pkg_muhasebe.parametre_index_bul('1500_MUSTERI_TAHSIL_TUTAR');
		pn_1500_toplam_vergi :=pkg_muhasebe.parametre_index_bul('1500_TOPLAM_VERGI');
		pn_1500_fark_tutar :=pkg_muhasebe.parametre_index_bul('1500_FARK_TUTAR');
		pn_1500_musteri_aciklama_2 :=pkg_muhasebe.parametre_index_bul('1500_MUSTERI_ACIKLAMA_2');
		pn_1500_damga_vergi_orani :=pkg_muhasebe.parametre_index_bul('1500_DAMGA_VERGI_ORANI');
		pn_1500_dv_aciklama_1 :=pkg_muhasebe.parametre_index_bul('1500_DV_ACIKLAMA_1');
		pn_1500_dv_aciklama_2 :=pkg_muhasebe.parametre_index_bul('1500_DV_ACIKLAMA_2');
		pn_1500_dv_aciklama_3 :=pkg_muhasebe.parametre_index_bul('1500_DV_ACIKLAMA_3');
		pn_1500_genel :=pkg_muhasebe.parametre_index_bul('1500_GENEL');
		pn_1500_ek :=pkg_muhasebe.parametre_index_bul('1500_EK');
		pn_1500_bireysel :=pkg_muhasebe.parametre_index_bul('1500_BIREYSEL');
		pn_1500_kmh :=pkg_muhasebe.parametre_index_bul('1500_KMH');
END;
/

