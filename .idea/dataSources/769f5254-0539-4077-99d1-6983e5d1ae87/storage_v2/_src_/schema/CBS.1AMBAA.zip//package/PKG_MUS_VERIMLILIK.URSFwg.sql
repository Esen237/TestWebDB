create PACKAGE PKG_MUS_VERIMLILIK IS

  Function Islem_post_edilmis_mi(pn_islem_no number) return number;
  Function oran_bul(ps_dvz varchar2, pd_date date) return number;
  Function date_bul(pd_date date) return date;
  Function referanstan_hesap_no_al(ps_referans varchar2) return number;
END;

/

