create PACKAGE     PKG_INT_TEMPLATE_INQ IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION GetTemplatesByOperationType(pn_customer_number number, 
                      ps_operation_type varchar2, 
                      pc_ref OUT CursorReferenceType) RETURN varchar2;

FUNCTION GetTemplateById(pn_id number, 
                      pn_customer_number number, 
                      pc_ref OUT CursorReferenceType) RETURN varchar2;                                         
END;
/

