create PACKAGE PKG_TX4031 IS

/******************************************************************************
   Name       : PKG_TX4031
   Created By : Bilal GUL
   Purpose	  : Efektif Kur Rezervasyon Iptal
******************************************************************************/

  -- TX Event Listesi
  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

Procedure Rezervasyon_Bilgisi_Al(ps_TARIH CBS_EF_KUR_REZERVASYON.TARIH%type,
                               ps_SUBE_KODU CBS_EF_KUR_REZERVASYON.SUBE_KODU%type,
							   ps_REZERVASYON_NO CBS_EF_KUR_REZERVASYON.REZERVASYON_NO%type,
							   ps_MUSTERI_NO out CBS_EF_KUR_REZERVASYON.MUSTERI_NO%type,
							   ps_MUSTERI_UNVAN out CBS_EF_KUR_REZERVASYON.MUSTERI_UNVAN%type,
							   ps_ISLEM_TIPI out CBS_EF_KUR_REZERVASYON.ISLEM_TIPI%type,
							   ps_ISLEM_SEKLI out CBS_EF_KUR_REZERVASYON.ISLEM_SEKLI%type,
							   ps_DOVIZ_KODU out CBS_EF_KUR_REZERVASYON.DOVIZ_KODU%type,
							   ps_TUTAR out CBS_EF_KUR_REZERVASYON.TUTAR%type,
							   ps_MUSTERI_KURU out CBS_EF_KUR_REZERVASYON.MUSTERI_KURU%type,
							   ps_DURUM_KODU out CBS_EF_KUR_REZERVASYON.DURUM_KODU%type,
							   ps_BOUGHT_CY out CBS_EF_KUR_REZERVASYON.BOUGHT_CY%type,
							   pn_BOUGHT_AMOUNT out CBS_EF_KUR_REZERVASYON.BOUGHT_AMOUNT%type,
							   ps_SOLD_CY out CBS_EF_KUR_REZERVASYON.SOLD_CY%type,
							   pn_SOLD_AMOUNT out CBS_EF_KUR_REZERVASYON.SOLD_AMOUNT%type,
							   pn_PARITE out CBS_EF_KUR_REZERVASYON.PARITE%type
							   );

END;


/

