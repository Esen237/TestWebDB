create PACKAGE BODY     PKG_INT_TRANSFER_TRX IS

FUNCTION PostBookToBookTransfer(ps_lang varchar2,
                                ps_source_iban varchar2,
                                ps_target_iban varchar2,
                                ps_amount varchar2,
                                ps_description varchar2,
                                ps_transafer_type varchar2,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER',            
                                pc_ref OUT CursorReferenceType,
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2 (20);
ls_product_type_code varchar2 (20);
ls_product_class_code varchar2 (20);
ls_source_product_class varchar2(20);
ls_target_product_class varchar2(20);
ln_role number := 7777;     
ln_channel_code number; 
ln_cash_code number;   
ln_final_balance number;
ln_source_account number;
ln_initial_balance number; 
ln_target_account number;
ln_amount number;
ls_branch_code varchar2(10);
ls_istatistik_kodu varchar2(10);
ls_prefix_stat varchar2(4);
ln_commission_amount number;
ps_payment_code varchar2(16) := '321'; 
ps_isdekont varchar2(1) := 'X';
ln_source_customer number;
ln_target_customer number;
ls_source_currency_code varchar2(3 byte);
ls_target_currency_code varchar2(3 byte);
ls_order_number varchar2(16); 
ln_tax_rate number;
ln_tax number := 0;
ls_returncode varchar2(3) := '000';

notenoughbalance  exception;
currencymismatch exception;
notownaccount exception;
le_target_elcard exception;
BEGIN

     ln_transaction_number := pkg_tx.islem_no_al;
     ln_transaction_code := 1203;
     ln_channel_code := to_number(ps_channel_code); 
     
     select hesap_no, musteri_no, doviz_kodu, sube_kodu, urun_sinif_kod
        into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code, ls_source_product_class
           from cbs_hesap where external_hesap_no = ps_source_iban;
       
     select hesap_no, musteri_no, doviz_kodu, urun_sinif_kod
        into ln_target_account, ln_target_customer, ls_target_currency_code, ls_target_product_class  
           from cbs_hesap where external_hesap_no = ps_target_iban;
        
     pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
        
     if ls_source_currency_code != ls_target_currency_code then
         raise currencymismatch;
     end if;
    
     if ps_transafer_type = 'b2b' then 
        if PKG_INT_CUSTOMER_INQ.GetCustomerIdByIban(ps_source_iban) != PKG_INT_CUSTOMER_INQ.GetCustomerIdByIban(ps_target_iban) then
            raise notownaccount;
        end if;
     end if;
     
     if ls_target_product_class = 'ELCARD NON INT.BR-LC' then
         raise le_target_elcard;
     end if;
      
     ln_amount := to_number(ps_amount,'999999999999999.9999');

     cbs.pkg_tx1203.sp_urun_tur_sinif_al(ln_source_account,
                                            ln_target_account  ,
                                            ls_source_currency_code ,
                                            'E',
                                            ls_module_type_code,
                                            ls_product_type_code,
                                            ls_product_class_code);

     ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, 
                                                         ln_transaction_code, 
                                                         ls_module_type_code, 
                                                         ls_product_type_code, 
                                                         ls_product_class_code,
                                                         ln_amount,  
                                                         ls_branch_code, 
                                                         ls_source_currency_code, 
                                                         ln_source_customer, 
                                                         ln_source_account, 
                                                         ln_cash_code);
                                                 
     if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
     else
       ln_tax_rate := 0;
       ln_tax := 0;   
     end if;  
     
     if ls_source_product_class = 'ELCARD NON INT.BR-LC' then
         ln_initial_balance := pkg_elcard.getelcardipcbalance(ln_source_account);
      
         --if source elcard check cbs balance also
         if (pkg_hesap.kullanilabilir_bakiye_al(ln_source_account) - ln_amount - ln_commission_amount - ln_tax) < 0 then
             raise notenoughbalance;
         end if;
    
     else
         ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
     end if;
 
     ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax; 
 
     if ln_final_balance < 0 then
         raise notenoughbalance;
     end if;
    
     ls_order_number :=  'I' || trim(substr(to_char(ln_transaction_number), 1, 15));


     ls_prefix_stat := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(ln_source_customer)) ||
                        pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(ln_source_customer)) ||
                        pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(ln_target_customer)) ||
                        pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(ln_target_customer));

     ls_istatistik_kodu := pkg_message.split(ps_payment_code,';',0);
      
     insert into cbs_virman_islem
            (tx_no, borc_hesap_no, doviz_kodu, tutar,alacak_hesap_no, aciklama, dekont_basim_f,
                   borc_external_hesap,alacak_external_hesap, borc_vergi_no,alacak_vergi_no,prefix_istatistik_kodu, istatistik_kodu,charge_amount, ref_no)
     values (ln_transaction_number, ln_source_account, ls_source_currency_code, ln_amount,
                   ln_target_account, ps_description, ps_isdekont, ps_source_iban, ps_target_iban, pkg_musteri.sf_vergino_al(ln_source_customer),
                   pkg_musteri.sf_vergino_al(ln_target_customer), ls_prefix_stat, ls_istatistik_kodu, ln_commission_amount, ls_order_number); 

     pkg_int_api.create_transaction(ln_transaction_number,
                                      ln_transaction_code,
                                      ls_module_type_code,
                                      ls_product_type_code,
                                      ls_product_class_code,
                                      ln_amount,
                                      ls_branch_code,
                                      ls_branch_code,
                                      ln_role,
                                      ls_source_currency_code,
                                      ln_source_customer,
                                      ln_source_account,
                                      ln_cash_code,
                                      ln_channel_code,
                                      ps_user_code);

    pkg_int_api.process_transaction(ln_transaction_number);
    
    open pc_ref for 
           select ln_transaction_number as transaction_number,
                  ln_amount as amount,
                  ls_source_currency_code as currency_code, 
                  ln_initial_balance as initial_balance,
                  ln_final_balance as final_balance,
                  sysdate as transaction_date from dual;
                  
   open pc_ref2 for 
     select 'commission' as name, 
                'bank' as client, 
                ln_commission_amount as amount,
                pkg_genel.lc_al as currency_code from dual
         union
         select 'tax' as name, 
                'bank' as client, 
                ln_tax as amount,
                pkg_genel.lc_al as currency_code from dual;
               
    open pc_ref3 for
        select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;        

    
    commit;
    return ls_returncode;

EXCEPTION
        when currencymismatch then
             rollback;
             return '453';
        when notenoughbalance then
             rollback;
             return '456';
        when notownaccount then
             rollback;
             return '457';
        when le_target_elcard then
             rollback;
             return '461';
        when no_data_found then
             rollback;
             return '454';
        when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PostBookToBookTransfer', ps_source_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
         rollback;
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         return ls_returncode;
END;


FUNCTION PostClearingTransfer(ps_lang varchar2,
                              ps_source_iban varchar2,
                              ps_target_full_name varchar2,
                              ps_target_iban varchar2,
                              ps_bic_code varchar2,
                              ps_payment_code varchar2,
                              ps_amount varchar2,
                              ps_description varchar2,
                              ps_transfer_type varchar2,
                              ps_tax_number varchar default null,
                              ps_source_name varchar default null,
                              ps_channel_code varchar2 default '1',
                              ps_user_code varchar2 default 'CINT_CALLER', 
                              pc_ref OUT CursorReferenceType, 
                              pc_ref2 OUT CursorReferenceType,
                              pc_ref3 OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ls_source_product_class varchar2(20);
ln_role number:= 7777;
ln_channel_code number; 
ln_cash_code number;
ld_date date;
ls_eftdate varchar2(10);
ln_commission_amount number := 0;
ln_tax_rate number;
ln_tax number := 0;
ln_final_balance number;
ls_currency_code varchar2(3); 
ln_initial_balance number;
ls_from_rnn varchar2(20);
ls_from_okpo varchar2(20);
ls_from_social varchar2(20);
ls_bank_code varchar2(14);
ln_payment_code number;
ln_amount number;
ls_description varchar2(250);
ps_ileritarihli varchar2(1) := '0';
ls_ref_no varchar2(15);
ls_sender_name varchar2(500);
ln_source_account number;
ln_source_customer number;
ls_source_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ln_max_amount number;
ls_res varchar2(100);

ls_retval varchar2(3) := '000';
ls_returncode varchar2(3) := '000';

lc_result  CursorReferenceType;
 
currencymismatch exception;
notenoughbalance exception;
daterror exception;
maxamount exception;
BEGIN

    ln_transaction_number := pkg_tx.islem_no_al;
    ln_transaction_code := 3555;
    ln_channel_code := to_number(ps_channel_code); 
    ln_amount := to_number(ps_amount,'99999999999.9999');
    
    select hesap_no, musteri_no, doviz_kodu, sube_kodu, urun_sinif_kod
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code, ls_source_product_class
          from cbs_hesap where external_hesap_no = ps_source_iban;
    
    pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
    
    ls_currency_code := pkg_genel.lc_al;

    if ls_currency_code !=  ls_source_currency_code then
        raise currencymismatch;
    end if;

    ln_max_amount := pkg_clearing.get_clearing_max_tutar;
    
    if ln_amount > ln_max_amount then
      raise maxamount;
    end if;
   
    ls_from_rnn := pkg_musteri.sf_vergino_al(ln_source_customer);
    ls_from_okpo := pkg_musteri.sf_okpo_al(ln_source_customer);
    ls_from_social := pkg_musteri.sf_sosyal_fon_no_al(ln_source_customer);
    ls_bank_code := pkg_message.split(ps_bic_code ,';',0);
    ln_payment_code := to_number(pkg_message.split(ps_payment_code  ,';',0));

    ls_retval := pkg_int_limit.checktimelimit('CLEARING');
    
    if ps_source_name is not null and ps_transfer_type = 'taxPayment' then
       ls_sender_name := ps_source_name;
    else 
       ls_sender_name := upper(PKG_MUSTERI.SF_MUSTERI_ADI(ln_source_customer));
    end if;
    
    pkg_parametre.deger('G_RIBCLEARING_MODUL_TYPE', ls_module_type_code);
    pkg_parametre.deger('G_RIBCLEARING_PRODUCT_TYPE', ls_product_type_code);
    pkg_parametre.deger('G_RIBCLEARING_PRODUCT_CLASS', ls_product_class_code);
 
    ls_returncode := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', lc_result);
    
    if (ls_returncode <> '000') then
       raise daterror;
    end if;
    
    fetch lc_result into ls_eftdate, ls_res, ls_res, ls_res, ls_res;
    close lc_result;
    
    ld_date := to_date(ls_eftdate, 'YYYYMMDD');
    
    if (ld_date > pkg_muhasebe.banka_tarihi_bul) then 
        ps_ileritarihli := '1'; 
    end if; 
    
    
    if ps_transfer_type = 'taxPayment' then
        ls_product_class_code :='RIBTAXPAY';
        if (length(ps_tax_number) > 0) then
            ls_from_rnn := ps_tax_number;
        end if;

        ls_ref_no := 'T'||pkg_tx.islem_no_al;
        ls_from_okpo   := '99999999';
        ls_from_social := '99999999999999';
    else
        ls_ref_no := 'I'||pkg_tx.islem_no_al;
    end if;

    ls_description := nvl(ps_description,'CLEARING PAYMENT');

    ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, ln_transaction_code, ls_module_type_code, ls_product_type_code, ls_product_class_code,
                               ln_amount, ls_branch_code, ls_currency_code, ln_source_customer, ln_source_account, ln_cash_code);


    if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
     else
       ln_tax_rate := 0;
       ln_tax := 0;   
     end if;  
     
    if ls_source_product_class = 'ELCARD NON INT.BR-LC' then
         ln_initial_balance := pkg_elcard.getelcardipcbalance(ln_source_account);
      
         --if source elcard check cbs balance also
         if (pkg_hesap.kullanilabilir_bakiye_al(ln_source_account) - ln_amount - ln_commission_amount - ln_tax) < 0 then
             raise notenoughbalance;
         end if;
    
    else
      ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
    end if;                                            
                                                                            
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
    if ln_final_balance < 0 then
         raise notenoughbalance;
    end if;

    ls_ref_no := 'I' || pkg_tx.islem_no_al;

    insert into cbs_clearing_islem
        (tx_no, urun_tur_kod, ref_no, payment_type, maturity_date,
        from_account, from_account_external_number, from_rnn, from_okpo, from_social_fund_number,
        to_account_external_number, to_subaccount, to_name, to_bank_bic, code_of_payment,
        amount, explanation, charge_amount, yaratildigi_tarih, yaratan_kullanici,
        musteri_no, from_description, to_account_number, gl_flag, gl_account,
        to_subaccount_name, bolum_kodu, giris_kullanici, onay_kullanici, internal_no,
        sira_no, msg_status)
    values
        (ln_transaction_number, ls_product_type_code, ls_ref_no, ls_module_type_code, ld_date,
        ln_source_account, ps_source_iban, ls_from_rnn, ls_from_okpo, ls_from_social,
        ps_target_iban, null, ps_target_full_name, ls_bank_code, ln_payment_code,
        ln_amount, ps_description, ln_commission_amount, sysdate, ps_user_code,
        ln_source_customer, ls_sender_name, null, null, null,
        null, ls_branch_code, ps_user_code, ps_user_code, null,
        null, 'sNEW');

    pkg_int_api.create_transaction(ln_transaction_number,
                                   ln_transaction_code,
                                   ls_module_type_code,
                                   ls_product_type_code,
                                   ls_product_class_code,
                                   ln_amount,
                                   ls_branch_code,
                                   ls_branch_code,
                                   ln_role,
                                   ls_currency_code,
                                   ln_source_customer,
                                   ln_source_account,
                                   ln_cash_code,
                                   ln_channel_code,
                                   ps_user_code);

    pkg_int_api.process_transaction (ln_transaction_number);

    
    open pc_ref for 
           select ln_transaction_number as transaction_number,
                  ln_amount as amount,
                  ls_source_currency_code as currency_code, 
                  ln_initial_balance as initial_balance,
                  ln_final_balance as final_balance,
                  sysdate as transaction_date,
                  ps_source_name as target_full_name,
                  ps_description as description from dual;
     
   open pc_ref2 for 
     select 'commission' as name, 
                'bank' as client, 
                ln_commission_amount as amount,
                pkg_genel.lc_al as currency_code from dual
         union
         select 'tax' as name, 
                'bank' as client, 
                ln_tax as amount,
                pkg_genel.lc_al as currency_code from dual;
               
    open pc_ref3 for
          select 
              pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;        
               
    commit;

     if (pkg_black_list.checkcustomerinblacklist_str(pkg_report4.cyr2lat(ps_target_full_name))  <> '0'
                 or pkg_black_list.checkcustomerinblacklist_str(ps_target_full_name)  <> '0') then
         
         --transaction should be verified and approved by Bank
         update cbs_islem set dogrulanmali_mi='E', onaylanmali_mi='E' 
                where numara = ln_transaction_number;
                
         --send email notification to Compliance department 
         pkg_black_list.black_list_report(null, 3555, null, null, ln_transaction_number, 'Clearing IB - Black list alert '||to_char(sysdate, 'dd/mm/yyyy'));
     else
         --transaction should be only approved by Bank 
         update cbs_islem set dogrulanmali_mi='H', onaylanmali_mi='E' 
                 where numara = ln_transaction_number;             
     end if;
            
    return ls_returncode; 
    
EXCEPTION   
      when currencymismatch then
             rollback;
             return '453';
      when notenoughbalance then
             rollback;
             return '456';
      when daterror then
             rollback;
             return '461';
      when maxamount then
             return '467';
      when no_data_found then
             rollback;
             return '454';
      when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PostClearingTransfer', ps_source_iban || ' '  || ln_transaction_number || ' ' || ps_user_code, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
            if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         return ls_returncode;
END;

/**************************************************************************************/
FUNCTION PostCrossTransfer (ps_lang varchar2,
                            ps_source_iban varchar2,
                            ps_target_full_name varchar2,
                            ps_target_iban varchar2,
                            ps_bic_code varchar2,
                            ps_payment_code varchar2,
                            ps_amount varchar2,
                            ps_description varchar2,
                            ps_transfer_type varchar2,
                            ps_channel_code varchar2 default '1',
                            ps_user_code varchar2 default 'CINT_CALLER', 
                            pc_ref OUT CursorReferenceType, 
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS
ln_transaction_number number;
ln_transaction_code number;   
ls_module_type_code varchar2 (10);
ls_product_type_code varchar2 (10);
ls_product_class_code varchar2 (20);
ls_source_product_class varchar2(20);
ln_role number := 7777;   
ln_channel_code number;
ln_cash_code number;  
ld_date date;
ls_eftdate varchar2(10);
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_final_balance number;
ls_from_bank_bic varchar2(6);
ls_from_description varchar2(500);
ls_currency_code varchar(3);
ln_initial_balance number; 
ls_from_rnn varchar2(20);
ls_from_okpo varchar2(20);
ls_from_social varchar2(20);
ls_to_bank_bic varchar2(6);
ls_to_main_bank_bic varchar2(6);
ln_payment_code number;
ls_payee_name varchar2(500);
ln_amount number;
ls_description varchar2 (250);
ps_ileritarihli varchar2(1):='0';
ls_ref_no varchar2(15);
ls_from_region_code varchar2(2) := '';
ls_to_region_code varchar2(2) := '';
ls_sender_name varchar2(500);
ln_source_account number;
ln_source_customer number;
ls_source_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ls_dummy_returncode varchar2(3) := '000';
ls_returncode varchar2 (3):= '000';

ls_res varchar2(100);

lc_result CursorReferenceType;

currencymismatch exception;
notenoughbalance exception; 
daterror exception;
BEGIN
      
     ln_transaction_number := pkg_tx.islem_no_al;
     ln_transaction_code := 3555;
     ln_channel_code := to_number(ps_channel_code);
      
     select hesap_no, musteri_no, doviz_kodu, sube_kodu, urun_sinif_kod
       into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code, ls_source_product_class
          from cbs_hesap where external_hesap_no = ps_source_iban;
      
     pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
     
     ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 

     ls_from_rnn := pkg_musteri.sf_vergino_al(ln_source_customer);
     ls_from_okpo := pkg_musteri.sf_okpo_al(ln_source_customer);
     ls_from_social := pkg_musteri.sf_sosyal_fon_no_al(ln_source_customer);
     ls_to_bank_bic := pkg_message.split(ps_bic_code,';',0);
     ls_to_main_bank_bic := substr(ls_to_bank_bic, 1, 3) || '001';
     ln_payment_code := to_number(pkg_message.split(ps_payment_code  ,';',0));
   
     ls_sender_name := upper(pkg_musteri.sf_musteri_adi(ln_source_customer));
    
      ls_module_type_code  := 'CLEARING';
      ls_product_type_code   := 'OUTGOING';

      if ps_transfer_type = 'gross' then
        ls_product_class_code := 'CIBGROSS';
      else
        ls_product_class_code := 'CIBCLEARING';
      end if;

      begin
          select  '118' || bolum.eft_kodu
               into  ls_from_bank_bic
                   from cbs.cbs_bolum bolum
                      where bolum.kodu = ls_branch_code;
      exception
        when no_data_found then
          ls_from_bank_bic := '118005';
      end;

      ls_from_description := ls_from_bank_bic || ' ' || ls_sender_name;
      if length(ls_description) > 200 then
        ls_from_description := substr(ls_from_description, 1, 200);
      end if;

      ls_payee_name := ps_target_full_name;

      if ps_transfer_type = 'gross' then
        begin
          select  lpad(region_no, 2, '0') into ls_from_region_code
          from cbs.cbs_bolum where kodu = ls_branch_code;
        exception
            when others then
                ls_from_region_code := '01';
        end;

        begin
          select  lpad(region_no, 2, '0') into ls_to_region_code
          from cbs.cbs_banka_kodlari where banka_kodu = ls_to_bank_bic;
        exception
            when others then
                ls_to_region_code := '01';
        end;

          ls_payee_name := ls_to_bank_bic || ' ' || ps_target_full_name;
      end if;


      if length(ls_payee_name) > 200 then
        ls_payee_name := substr(ls_payee_name, 1, 200);
      end if;

      ls_currency_code := pkg_genel.lc_al;
      ln_commission_amount := 0;
      ln_amount := to_number(ps_amount,'999999999999999.9999');
      
      if ls_currency_code !=  ls_source_currency_code then
        raise currencymismatch;
      end if;
    

       ls_returncode := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'GROSS', lc_result);
        
        if (ls_returncode <> '000') then
            raise daterror;
        end if;
        
        fetch lc_result into ls_eftdate, ls_res, ls_res, ls_res, ls_res;
        close lc_result;
        
        ld_date := to_date(ls_eftdate, 'YYYYMMDD');
        
        if (ld_date > pkg_muhasebe.banka_tarihi_bul) then 
            ps_ileritarihli := '1'; 
        end if; 
    

      ls_description := nvl(ps_description,'GROSS PAYMENT');

      ln_commission_amount := pkg_aps.ChargeAutoCalculate(ln_transaction_number, ln_transaction_code, ls_module_type_code, ls_product_type_code, ls_product_class_code,
                                   ln_amount, ls_branch_code, ls_currency_code, ln_source_customer, ln_source_account, ln_cash_code);


    if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
     else
       ln_tax_rate := 0;
       ln_tax := 0;   
     end if;  
     
    if ls_source_product_class = 'ELCARD NON INT.BR-LC' then
         ln_initial_balance := pkg_elcard.getelcardipcbalance(ln_source_account);
      
         --if source elcard check cbs balance also
         if (pkg_hesap.kullanilabilir_bakiye_al(ln_source_account) - ln_amount - ln_commission_amount - ln_tax) < 0 then
             raise notenoughbalance;
         end if;
    
    else
      ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
    end if;                                            
                                                                            
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
    if ln_final_balance < 0 then
         raise notenoughbalance;
    end if;

      ls_dummy_returncode := pkg_int_transfer.checkIfPaymentIsFavourMade(to_char(ln_source_customer), ps_source_iban, upper(ps_transfer_type), ls_payee_name);

      ls_ref_no := 'I'||pkg_tx.islem_no_al;
      
      insert into cbs_clearing_islem
        (tx_no, urun_tur_kod, ref_no, payment_type, maturity_date,
          from_account, from_account_external_number, from_rnn, from_okpo, from_social_fund_number,
          to_account_external_number, to_subaccount, to_name, to_bank_bic, code_of_payment,
          amount, explanation, charge_amount, yaratildigi_tarih, yaratan_kullanici,
          musteri_no, from_description, to_account_number, gl_flag, gl_account,
          to_subaccount_name, bolum_kodu, giris_kullanici, onay_kullanici, internal_no,
          sira_no, msg_status, from_region_code, to_region_code, type_of_payment, payment_details)
      values
          (ln_transaction_number, ls_product_type_code, ls_ref_no, decode(upper(ps_transfer_type), 'GROSS', 'GROSS', 'CLEARING'), ld_date,
           ln_source_account, ps_source_iban, ls_from_rnn, ls_from_okpo, ls_from_social,
           ps_target_iban, null, ls_payee_name, decode(upper(ps_transfer_type), 'GROSS', ls_to_main_bank_bic, ls_to_bank_bic), ln_payment_code,
           ln_amount, ps_description, ln_commission_amount, sysdate, ps_user_code,
           ln_source_customer, decode(upper(ps_transfer_type), 'GROSS', ls_from_description, ls_sender_name), null, null, null,
           null, ls_branch_code, ps_user_code, ps_user_code, null,
           null, 'sNEW', ls_from_region_code, ls_to_region_code, 'CRED', 'SHA');

     pkg_int_api.create_transaction(ln_transaction_number,
                                      ln_transaction_code,
                                      ls_module_type_code,
                                      ls_product_type_code,
                                      ls_product_class_code,
                                      ln_amount,
                                      ls_branch_code,
                                      ls_branch_code,
                                      ln_role,
                                      ls_currency_code,
                                      ln_source_customer,
                                      ln_source_account,
                                      ln_cash_code,
                                      ln_channel_code,
                                      ps_user_code);
     
     pkg_int_api.process_transaction(ln_transaction_number);
     
    
     open pc_ref for 
           select ln_transaction_number as transaction_number,
                  ln_amount as amount,
                  ls_source_currency_code as currency_code, 
                  ln_initial_balance as initial_balance,
                  ln_final_balance as final_balance,
                  sysdate as transaction_date from dual;
     
     open pc_ref2 for 
         select 'commission' as name, 
                    'bank' as client, 
                    ln_commission_amount as amount,
                    pkg_genel.lc_al as currency_code from dual
             union
             select 'tax' as name, 
                    'bank' as client, 
                    ln_tax as amount,
                    pkg_genel.lc_al as currency_code from dual;
               
     open pc_ref3 for
         select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;        
        
     commit;

    return ls_returncode;
    
EXCEPTION
      when currencymismatch then
             rollback;
             return '453';
      when notenoughbalance then
             rollback;
             return '456';
      when daterror then
             rollback;
             return '461';
      when no_data_found then
             rollback;
             return '454';
      when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PostCrossTransfer', ps_source_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
          rollback;
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         return ls_returncode;
END;

FUNCTION PostSwiftTransfer(ps_lang varchar2,
                           ps_source_iban varchar2,
                           ps_currency_code varchar2,
                           ps_country_code varchar2,
                           ps_swift_code varchar2,
                           ps_amount varchar2,       
                           ps_commission_type varchar2, 
                           ps_execution_type varchar2, 
                           ps_target_iban varchar2,
                           ps_target_bank_city_name varchar2,     
                           ps_target_full_name varchar2,  
                           ps_target_address varchar2, 
                           ps_target_phone_number varchar2,  
                           ps_target_passport varchar2,  
                           ps_payment_dest_code varchar2,                   
                           ps_purpose_code varchar2,
                           ps_payment_code varchar2,
                           ps_payment_details varchar2,
                           ps_channel_code varchar2 default '1',
                           ps_user_code varchar2 default 'CINT_CALLER', 
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType) RETURN varchar2  
IS 
pragma autonomous_transaction;
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_channel_code number;
ln_cash_code number;
ln_final_balance number;
ln_initial_balance number;
ln_amount number;
pd_valor_tarihi date; 
pn_muhabir_hesap_no number;
pn_muhabir_musteri_no number;
ps_muhabir_bic varchar2(11);
ps_bank_opr_code varchar2(4):='CRED';
ps_ordering_customer varchar2(1):='K';
ps_ben_customer varchar2(1):='N';
ps_detail_charges varchar2(3);
ps_acc_ins varchar2(1):='A';
ls_referans varchar2(16);
pc_oc_isim_adres_1 varchar2(35 char);
pc_oc_isim_adres_2 varchar2(35 char);
pc_oc_isim_adres_3 varchar2(35 char);
pc_bc_isim_adres_1 varchar2(35 char);
pc_bc_isim_adres_2 varchar2(35 char);
pc_bc_isim_adres_3 varchar2(35 char);
pc_ri_isim_1 varchar2(35 char);
pc_ri_isim_2 varchar2(35 char);
pc_ri_isim_3 varchar2(35 char);
ln_tahsil_tutari number;
ln_bdsk number;
ln_net_transfer_tutar  number:=0;
pc_ri_1 varchar2(35 char);
pc_ri_2 varchar2(35 char);
pc_ri_3 varchar2(35 char);
pc_ri_4 varchar2(35 char);
ls_sonuc varchar2(2000);
ln_count number:=0;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_correspondent_charge number := 0;
ln_musteri_tipi number:=0;
ls_address varchar2(2000):='';
ls_aciklama varchar2(2000);
ls_message_type varchar2(10):='';
ls_message_103 varchar2(1):='E';
ls_message_202 varchar2(1):='E';
ls_corres varchar2(20):='';
ls_corres_bic varchar2(20):='';
ls_ii_bic  varchar2(11):='';
ls_72 varchar2(10):='';
ls_awi_bic  varchar2(15);
ls_branch_no varchar2(3):= '010';
ln_swttrnpf_sasrn number;
ls_related_ref cbs_yphavale_giden_acilis.related_reference%type := null;
ls_senders_dvz cbs_yphavale_giden_acilis.senders_dvz%type;
ls_senders_charges cbs_yphavale_giden_acilis.senders_charges%type;
ls_cia_doviz cbs_yphavale_giden_acilis.cia_doviz%type;
ln_cia_tutar cbs_yphavale_giden_acilis.cia_tutar%type;
ls_swiftcode varchar2(20);
ls_commaccount varchar2(30);
pc_tahsil_doviz varchar2(3);
ps_payeeacc varchar2(34);
pd_acilis_tarih date;
pd_bugun date;
ln_source_account number;
ln_source_customer number;
ls_branch_code varchar2(3);
ls_currency_code varchar(3);
ps_transfer_doviz varchar2(20);
ls_customer_type varchar2(1 byte);
ps_iibic varchar2(15);
ls_ileri_gun_report varchar2(50);
ls_ileri_is_gunu_report varchar2(50);
ls_ileri_gun_report_2 varchar2(50);
ldd_date varchar2(50);
ps_tmp number := 0;
pn_client_name_from varchar2(200);
result_value varchar2(3):='000';
ls_returncode varchar2(3):='000';
ls_payment_dest_code varchar2(35);
ls_purpose_name varchar2(2000);

l_cursor CursorReferenceType;

notenoughbalance exception; 
daterror exception;
BEGIN
        
        ls_purpose_name := pkg_int_translation_inq.gettranslate(ps_lang, ps_purpose_code, 'msg.swift') ;
        
        ln_transaction_number := pkg_tx.islem_no_al;
        ln_transaction_code := '4003';
        ln_channel_code := to_number(ps_channel_code);
        ls_module_type_code := 'FCTRANSFER';
        ls_product_type_code := 'OUTGOING';
        ls_product_class_code := upper(ps_commission_type || ' ' ||  ps_execution_type || ' ' || ps_currency_code);
        
        ls_swiftcode := ps_swift_code;
        ls_currency_code := ps_currency_code;
        ps_transfer_doviz := ps_currency_code;
        pc_tahsil_doviz := ps_currency_code;
        ps_payeeacc := ps_target_iban;
        pd_acilis_tarih := Pkg_Muhasebe.banka_tarihi_bul;
        pd_bugun := pkg_muhasebe.banka_tarihi_bul;
        
        select hesap_no, musteri_no, sube_kodu
           into ln_source_account, ln_source_customer, ls_branch_code
                 from cbs_hesap where external_hesap_no = ps_source_iban;
          
        pkg_baglam.yarat(ls_branch_code, ln_role);
        
        ls_commaccount := ln_source_account;
        
        ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
        
        if ps_payment_dest_code is not null then
             ls_payment_dest_code := upper('/BENEFRES/AE//' || ps_payment_dest_code);
        end if;  

        ln_amount := to_number(ps_amount,'99999999999.9999');
        
        result_value := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', l_cursor);
        
        if result_value <> '000' then
            raise daterror;
        end if;
                                     
                                                
        loop
            fetch l_cursor into 
                    ldd_date,
                    ps_tmp,
                    ls_ileri_gun_report,
                    ls_ileri_is_gunu_report,
                    ls_ileri_gun_report_2;
            exit when l_cursor%notfound;  
        end loop;
        close l_cursor;    
                                       
        if upper(ps_execution_type) = 'NORMAL' then
         pd_valor_tarihi := to_date(ls_ileri_gun_report,'YYYYMMDD');
        else
          pd_valor_tarihi := to_date(ls_ileri_is_gunu_report,'YYYYMMDD');
        end if;
        
        ps_iibic := nvl(pkg_message.split(upper(ps_commission_type),'###',2),''); 
--        ps_iibic := nvl(pkg_message.split(ps_execution_type,'###',2),''); --NurmilaZ --Corp

        if (nvl(length(trim(substr(ps_target_bank_city_name,1,25))),0)>0) then 
            ls_72:='ACC'; 
        end if;

        if pkg_musteri.sf_personel_mi(ln_source_customer) = 'E' then
            ls_product_class_code := 'STAFF SWIFT';
        end if;

        ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, ln_transaction_code, ls_module_type_code, ls_product_type_code, ls_product_class_code,
                                   ln_amount, ls_branch_no, ls_currency_code, ln_source_customer, ln_source_account, null);
        -----------------------------------------
                                                     
         select count(*) into ln_count from cbs_bic_kodlari where bic_ulke_kodu = 'TR' and bic_kodu = ps_swift_code;
    
    
         if ln_count > 0 and pkg_kur.yuvarla('USD', pkg_kur.doviz_doviz_karsilik(ps_currency_code, 'USD', null,  ln_amount, 1, null, null, 'N', 'S')) < 5000 then
            ln_commission_amount := 0;
         end if;

         if ln_commission_amount > 0 then
               pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
               ln_tax := ln_commission_amount * ln_tax_rate / 100;
             else
               ln_tax_rate := 0;
               ln_tax := 0;   
         end if;  
     
        ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
 
        if ln_final_balance < 0 then
            raise notenoughbalance;
        end if;

        ls_referans:=to_char(pd_bugun,'YY')||'.'||ls_branch_code||'.'||'OMT'||'.'|| lpad(pkg_genel.genel_kod_al('YPHAVALE.GIDEN'||to_char(pd_bugun,'YY')||ls_branch_code),5,'0');
--        ps_net_brut := pkg_message.split(ps_execution_type,'###',0);
        
        if pkg_musteri.sf_musteri_eng_adi(to_number(ln_source_customer)) is null then
           pc_oc_isim_adres_1 := substr(pkg_report4.cyr2lat(pkg_musteri.sf_musteri_adi(to_number(ln_source_customer))),0,33);
        else 
           pc_oc_isim_adres_1 := substr(pkg_musteri.sf_musteri_eng_adi(to_number(ln_source_customer)),0,33);
        end if;
        
        pc_oc_isim_adres_2 := substr(pkg_report4.cyr2lat(pkg_musteri.sf_adres_al(to_number(ln_source_customer))),0,33);
        pc_oc_isim_adres_3 := substr(pkg_report4.cyr2lat(pkg_musteri.sf_adres_al(to_number(ln_source_customer))),33,33);
        pc_ri_isim_1 := substr(upper(pkg_report4.cyr2lat(ls_purpose_name)),1,33);
        pc_ri_isim_2 := substr(upper(pkg_report4.cyr2lat(ls_purpose_name)),34,33);
        pc_ri_isim_3 := substr(upper(pkg_report4.cyr2lat(ls_purpose_name)),67,33);

        pc_bc_isim_adres_1 := substr(ps_target_phone_number ||' '|| ps_target_passport ||' '|| ps_target_address,1,33); 
        pc_bc_isim_adres_2 := substr(ps_target_phone_number ||' '|| ps_target_passport ||' '|| ps_target_address,34,33);
        pc_bc_isim_adres_3 := substr(ps_target_phone_number ||' '|| ps_target_passport ||' '|| ps_target_address,67,33);
   
        pc_ri_1 := substr( upper(ls_purpose_name || ' ' || ps_payment_details ),1,33);
        pc_ri_2 := substr( upper(ls_purpose_name || ' ' ||  ps_payment_details ),34,33);
        pc_ri_3 := substr( upper(ls_purpose_name || ' ' ||  ps_payment_details ),67,33);
        pc_ri_4 := substr( upper(ls_purpose_name || ' ' ||  ps_payment_details ),100,33);

        ln_tahsil_tutari := pkg_kur.doviz_doviz_karsilik (ps_transfer_doviz,pc_tahsil_doviz,null,ln_amount,1,null, null,'O', 'S');
        ln_bdsk := pkg_kur.doviz_doviz_karsilik (ps_transfer_doviz,pkg_genel.lc_al,null,1,1,null, null,'O', 'S');
        pn_muhabir_hesap_no := pkg_soa_inquiry.getcorrespondentaccountno(ps_currency_code);
        pn_muhabir_musteri_no := pkg_hesap.hesaptanmusterinoal(pn_muhabir_hesap_no);
       
        pn_client_name_from := upper(pkg_musteri.sf_musteri_eng_adi(to_number(ln_source_customer)));
       
        if pn_client_name_from is null or pn_client_name_from = '' then
            pn_client_name_from := upper(pkg_report4.cyr2lat(pkg_musteri.sf_musteri_adi(to_number(ln_source_customer))));
        end if;
       
        ls_aciklama:='TRANSFER FROM '|| pn_client_name_from ||' TO '||upper(pkg_report4.cyr2lat(ps_target_full_name));
       
        ps_muhabir_bic := cbs.pkg_swift.getmubabirbiccode(pn_muhabir_musteri_no);

        select count(*)
            into ln_count
                from cbs_bic_kodlari
                        where bic_kodu = ps_swift_code
                        and substr(bic_kodu,1,4) in (select substr(sbkekd,1,4) from swtbkepf);

        if (ln_count > 0) then
            ls_message_type := '103';
            ls_message_202 := 'H';
            ls_corres:='A';
            ls_corres_bic:=ps_muhabir_bic;
            ls_awi_bic:=ps_swift_code;
        else
            ls_message_type := '202_103';
            ls_message_202 := 'H';
            ls_swiftcode:=ps_muhabir_bic;
            ls_corres:='';
            ls_corres_bic:='';
            if length(ps_swift_code) = 11 then
               ls_awi_bic:=substr(ps_swift_code,1,length(ps_swift_code)-3)||'XXX';
            else
               ls_awi_bic:= ps_swift_code ||'XXX';
            end if;

            ls_related_ref:=null;--'NONREF';
        end if;

        if length(ps_iibic) = 8 then
           ls_ii_bic :=ps_iibic ||'XXX';
        end if;

        if upper(ps_commission_type) = 'OUR' then
            ln_net_transfer_tutar := ln_amount;
            ps_detail_charges := 'OUR';
        else
            ln_net_transfer_tutar := ln_amount;
            ps_detail_charges := 'BEN';
            ls_senders_charges:=0;
            ls_senders_dvz:=ps_transfer_doviz;

            ls_cia_doviz:=ps_transfer_doviz;
            ln_cia_tutar:=ln_net_transfer_tutar;
        end if;

        ln_musteri_tipi := pkg_musteri.sf_musteri_tipi_al(ln_source_customer);

        ls_address := pkg_report4.cyr2lat(pc_oc_isim_adres_1);
        pc_oc_isim_adres_1 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_oc_isim_adres_2 := upper(substr(ls_address,35)) || ' ' || pc_oc_isim_adres_2; end if;

        ls_address := pkg_report4.cyr2lat(pc_oc_isim_adres_2);
        pc_oc_isim_adres_2 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_oc_isim_adres_3 := upper(substr(ls_address,35)) || ' ' || pc_oc_isim_adres_3; end if;

        ls_address := pkg_report4.cyr2lat(pc_oc_isim_adres_3);
        pc_oc_isim_adres_3 := upper(substr(ls_address,1,34));
------------------------------------------------------------------
        ls_address := pkg_report4.cyr2lat(pc_bc_isim_adres_1);

        pc_bc_isim_adres_1 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_bc_isim_adres_2 := upper(substr(ls_address,35)) || ' ' || pc_bc_isim_adres_2; end if;

        ls_address := pkg_report4.cyr2lat(pc_bc_isim_adres_2);
        pc_bc_isim_adres_2 := upper(substr(ls_address,1,34));
        if (length(upper(substr(ls_address,35)))>0) then pc_bc_isim_adres_3 := upper(substr(ls_address,35)) || ' ' || pc_bc_isim_adres_3; end if;

        ls_address := pkg_report4.cyr2lat(pc_bc_isim_adres_3);
        pc_bc_isim_adres_3 := upper(substr(ls_address,1,34));

        if ((length(pc_bc_isim_adres_3))<35)and(length(pc_bc_isim_adres_2)>0) then  pc_bc_isim_adres_3 := substr(pc_bc_isim_adres_3,1,34);
        elsif ((length(pc_bc_isim_adres_2))<35)and(length(pc_bc_isim_adres_1)>0) then  pc_bc_isim_adres_2 := substr(pc_bc_isim_adres_2,1,34);
        else pc_bc_isim_adres_1 := substr(pc_bc_isim_adres_1,1,34); end if;

        insert into cbs_yphavale_giden_acilis
            (tx_no, referans, gonderen_sube, musteri_no, modul_tur_kod,
             urun_tur_kod, urun_sinif_kod, ulke_kodu, cek_ile_f, cek_no,
             transfer_doviz_kodu, tutar, net_brut, tahsil_doviz_kodu, kur,
             parite, carpma_bolme, tahsil_tutari, net_transfer_tutari, valor_tarihi,
             transfer_sekli, borclu_hesap_no, borclu_dk_no, muh_bank_musteri_no, muh_bank_hesap_no,
             istatistik_kodu, aciklama, masraf_komisyon_hesap_no, boc, oc,
             bc, doc, awi, oc_hesap_no_k, durum_kodu,
             acilis_tarihi, masraf_toplami, related_reference, prefix_istatistik_kod, swift_tutari,
             rg_mesaj_olustur, alici_bic, muhabir_bic, mesaj_103, mesaj_202,
             oc_isim_adres_1, oc_isim_adres_2, oc_isim_adres_3, bc_hesap_no_n, bc_isim_adres_1,
             bc_isim_adres_2, bc_isim_adres_3, valor_tarihi_ch, tutar_ch, bc_hesap_no_ch,
             bi, ii_bic,awi_bic, sc, sc_bic, awi_location,
             ri_1, ri_2, ri_3, ri_4, ii,
             senders_charges, senders_dvz, pre_stri_1, post_stri_1, cia_doviz, cia_tutar, rr_1)
        values
            (ln_transaction_number, ls_referans, ls_branch_code, ln_source_customer, ls_module_type_code,
             ls_product_type_code, ls_product_class_code, ps_country_code, 'H', null,
             ps_transfer_doviz, ln_amount, 'N', pc_tahsil_doviz, null,
             null, null, null, ln_net_transfer_tutar, pd_valor_tarihi,
             'M', ln_source_account, null, pn_muhabir_musteri_no, pn_muhabir_hesap_no,
             ps_payment_code, substr(ls_aciklama,1,80), ls_commaccount, ps_bank_opr_code, ps_ordering_customer,
             ps_ben_customer, ps_detail_charges, ps_acc_ins, ps_source_iban, null,
             pd_acilis_tarih, ln_commission_amount + ln_correspondent_charge, ls_related_ref, null, ln_net_transfer_tutar,
             'E', ps_muhabir_bic, ps_muhabir_bic, ls_message_103, ls_message_202,
             pc_oc_isim_adres_1, pc_oc_isim_adres_2, pc_oc_isim_adres_3, ps_payeeacc, substr(ps_target_full_name,1,33),
             pc_bc_isim_adres_1, pc_bc_isim_adres_2, pd_valor_tarihi, ln_amount, null,
             null, ls_ii_bic, ls_awi_bic, null, null, null,
             pc_ri_1, pc_ri_2, pc_ri_3, pc_ri_4, 'A',
             ls_senders_charges, ls_senders_dvz, ls_72, trim(substr(ps_target_bank_city_name,1,25)), ls_cia_doviz, ln_cia_tutar, ls_payment_dest_code);

     pkg_int_api.create_transaction(ln_transaction_number, 
                                    ln_transaction_code,
                                    ls_module_type_code, 
                                    ls_product_type_code, 
                                    ls_product_class_code,
                                    ln_amount, 
                                    ls_branch_code, 
                                    ls_branch_code,
                                    ln_role,
                                    ls_currency_code, 
                                    ln_source_customer,
                                    ln_source_account,
                                    ln_cash_code,
                                    ln_channel_code,
                                    ps_user_code);
                                    
                                             
      open pc_ref for 
           select ln_transaction_number as transaction_number,
                  ln_amount as amount,
                  ps_currency_code as currency_code, 
                  ln_initial_balance as initial_balance,
                  ln_final_balance as final_balance,
                  sysdate as transaction_date from dual;
     
      open pc_ref2 for 
         select 'commission' as name, 
                'bank' as client, 
                ln_commission_amount as amount,
                pkg_genel.lc_al as currency_code from dual
         union
         select 'tax' as name, 
                'bank' as client, 
                ln_tax as amount,
                pkg_genel.lc_al as currency_code from dual;
               
               
      open pc_ref3 for
          select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;        
         
    commit;

    pkg_swift.sp_mesaj_sil(ln_transaction_number);

    pkg_swift.mesaj_olustur(4003, ln_transaction_number, 1, '103', null, null, null, null, ls_sonuc);

        if (ls_sonuc = 'SKYACK') then
            ls_returncode:='000';

            select musteri_tipi_kod into ls_customer_type
            from cbs_musteri
            where musteri_no = ln_source_customer;

            if (ls_customer_type = '1') then
                pkg_int_api.process_transaction(ln_transaction_number);
            end if;
        else
            ls_returncode:='777';

            if (ls_sonuc like '%BICNACK%') then
                ls_returncode:='761';
            elsif (ls_sonuc like '%SKYBLCK') then
                ls_returncode:='762';
            elsif (ls_sonuc like '%SKYE01%' or ls_sonuc like '%SKYE02%' or ls_sonuc like '%SKYE03%') then
                ls_returncode:='763';
            elsif (ls_sonuc like '%SKYE04%') then
                ls_returncode:='764';
            elsif (ls_sonuc like '%SKYE05%') then
                ls_returncode:='765';
            elsif (ls_sonuc like '%SKYE06%') then
                ls_returncode:='766';
            elsif (ls_sonuc like '%SKYE07%') then
                ls_returncode:='767';
            elsif (ls_sonuc like '%SKYE08%' or ls_sonuc like '%SKYE09%') then
                ls_returncode:='768';
            elsif (ls_sonuc like '%SKYE10%') then
                ls_returncode:='769';
            elsif (ls_sonuc like '%SKYE11%') then
                ls_returncode:='770';
            elsif (ls_sonuc like '%SKYE12%') then
                ls_returncode:='771';
            elsif (ls_sonuc like '%SKYE13%') then
                ls_returncode:='772';
            elsif (ls_sonuc like '%SKYE14%' or ls_sonuc like '%SKYE15%') then
                ls_returncode:='773';
            elsif (ls_sonuc like '%SKYE14 (57A)%') then
                ls_returncode:='774';
            elsif (ls_sonuc like '%SKYNACK (59N)%') then
                ls_returncode:='775';
            end if;
            
            select sasrn into ln_swttrnpf_sasrn
            from swttrnpf
            where tx_no = ln_transaction_number
            and rownum=1;
            
            for i in (select araerr from swtarapf_cbs
                      where arasrn = ln_swttrnpf_sasrn) loop
                if i.araerr is not null then
                    log_at('PostSwiftTransfer','SKY_ERROR: ' || ls_sonuc,substr(i.araerr,1,2000));
                end if;
            end loop;

            --ROLLBACK;
        end if;

        commit;
        
        return ls_returncode;
        
EXCEPTION
       when notenoughbalance then
            rollback;
            return '456';
       when daterror then
             rollback;
             return '461';
       when no_data_found then
             rollback;
             return '454';
       when others then
            ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);

            log_at('PostSwiftTransferNew', ps_source_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
            rollback;

            select count(*)
            into ln_count
            from cbs_yphavale_giden_acilis t
            where t.tx_no = ln_transaction_number;

            if (ln_count > 0) then
                  delete from cbs_yphavale_giden_acilis t
                  where t.tx_no = ln_transaction_number;
            end if;

            select count(*)
            into ln_count
            from cbs_islem t
            where t.numara = ln_transaction_number;

            if (ln_count > 0) then
                  delete from cbs_islem t
                  where t.numara = ln_transaction_number;
            end if;

            commit; --2011.07.26

            if ls_returncode = '999' or ls_returncode is null then
               raise;
            end if;
            return ls_returncode;
END;
END PKG_INT_TRANSFER_TRX;
/

