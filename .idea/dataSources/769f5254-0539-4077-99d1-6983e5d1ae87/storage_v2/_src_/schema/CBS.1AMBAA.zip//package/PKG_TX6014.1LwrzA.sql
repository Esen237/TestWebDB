create PACKAGE Pkg_Tx6014 IS

/******************************************************************************
/*   Name         : PKG_TX6014
/*   Created By   : Gulnihal Cengiz
/*   Date    	  : 24/10/2003
/*   Purpose	  : Menkul guncelleme
******************************************************************************/

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  PROCEDURE Guncelleme_Kontrolu(pn_islem_no NUMBER,
  								ps_block	VARCHAR2,
								ps_rowid   VARCHAR2,
		  				   		ps_column  	VARCHAR2,
  		   				   		pd_column   VARCHAR2,
								ps_oldvalue IN OUT VARCHAR2); --G?ncellenen alanlar? bulmak i?in
  FUNCTION Menkul_Tanim_guncelle_ctrl(ps_referans CBS_MENKUL.referans_no%TYPE,pn_islem_no NUMBER) RETURN NUMBER;

  PROCEDURE Menkul_kiymet_BilgiAktar(ps_referans IN CBS_MENKUL.referans_no%TYPE, p_txno IN NUMBER) ;
END;


/

