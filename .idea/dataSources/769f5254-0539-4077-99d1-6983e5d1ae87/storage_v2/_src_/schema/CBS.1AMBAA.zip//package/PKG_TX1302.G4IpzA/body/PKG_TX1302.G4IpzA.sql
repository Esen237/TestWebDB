create PACKAGE BODY     PKG_TX1302 IS
--------------------------------------------------------------
    pn_1302_REFERANCE       NUMBER ;
    pn_1302_HESAP_SUBE      NUMBER ;
    pn_1302_M_ACIKLAMA      NUMBER ;
    pn_1302_B_ACIKLAMA      NUMBER ;
    pn_1302_P1              NUMBER ;
    pn_1302_P2              NUMBER ;
    pn_1302_P3              NUMBER ;
    pn_1302_P4              NUMBER ;
    pn_1302_P5              NUMBER ;
    pn_1302_P6              NUMBER ;
    pn_1302_P7              NUMBER ;
    pn_1302_P8              NUMBER ;
    pn_1302_P9              NUMBER ;
    pn_1302_P10             NUMBER ;
    pn_1302_P11             NUMBER ;
    pn_1302_P12             NUMBER ;
    pn_1302_P13             NUMBER ;
    pn_1302_P14             NUMBER ;
    pn_1302_P15             NUMBER ;
    pn_1302_P16             NUMBER ;
    pn_1302_TUTAR1_LC       NUMBER ;
    pn_1302_TUTAR2_LC       NUMBER ;
    pn_1302_TUTAR3_LC       NUMBER ;
    pn_1302_TUTAR4_LC       NUMBER ;
    pn_1302_TUTAR5_LC       NUMBER ;
    pn_1302_TUTAR6_LC       NUMBER ;
    pn_1302_TUTAR7_LC       NUMBER ;
    pn_1302_TUTAR8_LC       NUMBER ;
    pn_1302_TUTAR9_LC       NUMBER ;
    pn_1302_TUTAR10_LC      NUMBER ;
    pn_1302_TUTAR11_LC      NUMBER ;
    pn_1302_TUTAR12_LC      NUMBER ;
    pn_1302_TUTAR13_LC      NUMBER ;
    pn_1302_TUTAR14_LC      NUMBER ;
    pn_1302_TUTAR15_LC      NUMBER ;
    pn_1302_TUTAR16_LC      NUMBER ;
    pn_1302_TUTAR1_FC       NUMBER ;
    pn_1302_TUTAR2_FC       NUMBER ;
    pn_1302_TUTAR3_FC       NUMBER ;
    pn_1302_TUTAR4_FC       NUMBER ;
    pn_1302_TUTAR5_FC       NUMBER ;
    pn_1302_TUTAR6_FC       NUMBER ;
    pn_1302_TUTAR7_FC       NUMBER ;
    pn_1302_TUTAR8_FC       NUMBER ;
    pn_1302_TUTAR9_FC       NUMBER ;
    pn_1302_TUTAR10_FC      NUMBER ;
    pn_1302_TUTAR11_FC      NUMBER ;
    pn_1302_TUTAR12_FC      NUMBER ;
    pn_1302_TUTAR13_FC      NUMBER ;
    pn_1302_TUTAR14_FC      NUMBER ;
    pn_1302_TUTAR15_FC      NUMBER ;
    pn_1302_TUTAR16_FC      NUMBER ;
    pn_1302_DVZ_1           NUMBER ;
    pn_1302_DVZ_2           NUMBER ;
    pn_1302_KUR_1           NUMBER ;
    pn_1302_KUR_2           NUMBER ;
-- BOM 04.01.2017 AdiletK CQ4712 Tranches    
    pn_1302_P18             NUMBER ;
    pn_1302_P19             NUMBER ;
    pn_1302_TUTAR18_LC      NUMBER ;
    pn_1302_TUTAR19_LC      NUMBER ;
    pn_1302_TUTAR18_FC      NUMBER ;
    pn_1302_TUTAR19_FC      NUMBER ;
-- EOM 04.01.2017 AdiletK CQ4712 Tranches         
--------------------------------------------------------------
Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
--------------------------------------------------------------
Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
--------------------------------------------------------------
Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
--------------------------------------------------------------
Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
--------------------------------------------------------------
Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
    -- NULL;
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '699' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
  End;
--------------------------------------------------------------
Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_teklif_no              cbs_kredi_teklif.teklif_no%type;
  ls_durum_kodu             cbs_kredi_teklif.durum_kodu%type;
  ln_musteri_no             cbs_musteri.musteri_no%type;
  ls_genel_doviz_kodu       VARCHAR2(200);
  ln_ref_teklif_no          NUMBER;
  ln_count                  integer;
  ln_teklif_satir_no        NUMBER;         --CQ6147 IadgarB
  ln_req_limit              NUMBER;         --CQ6147 IadgarB
  ln_app_limit              NUMBER;         --CQ6147 IadgarB
  ls_kredi_turu             NUMBER;         --CQ6147 IadgarB
  ls_doviz_kodu             VARCHAR2(3);    --CQ6147 IadgarB
  ps_response_code          VARCHAR2(200);  --CQ6147 IadgarB
  ps_response_desc          VARCHAR2(200);  --CQ6147 IadgarB
  is_found_rec              BOOLEAN:=FALSE; --CQ6147 IadgarB
  WEBSERVICE_GENERAL_ERROR  EXCEPTION;      --CQ6147 IadgarB
  CREDIT_ACCOUNTS_CLOSE     EXCEPTION;      --NurmilaZ
  ls_bolum_kodu             VARCHAR2(10 byte);   --NurmilaZ
  v_branch_code             varchar2(3);  --MaratM CBS-373
  
  --BOM ErkinZu cq614 23042017
  CURSOR cur_satir(ln_tek_no number) IS
    SELECT teklif_satir_no --, app_no  --CBS-233 GulkaiyrK
    FROM cbs_kredi_teklif_satir
    WHERE teklif_no = ln_tek_no 
    AND satir_durum is null ;
   -- AND app_no is not null;   --CBS-233 GulkaiyrK
  --EOM ErkinZu cq614 23042017

  --BOM CQ6147 IadgarB
  CURSOR cur_cr_card IS
    SELECT UNIQUE BANKSOFT_CUSTOMER_NO
      FROM CBS_CREDIT_CARD
     WHERE --STATUS = 'A' AND  --cbs-366
         primary_card_flag = 'A'
       AND CUSTOMER_NO = ln_musteri_no   and  substr(card_no, 1, 6) not in (458818);--cbs288 GulkaiyrK 17 .09 2020 Limit update for business cards ;;
  r_cur cur_cr_card%ROWTYPE;
  --EOM CQ6147 IadgarB  

  Begin

  /* teklif numarasi alinir*/
    SELECT teklif_no,durum_kodu,musteri_no,ref_teklif_no,bolum_kodu
      INTO ln_teklif_no,ls_durum_kodu,ln_musteri_no,ln_ref_teklif_no,ls_bolum_kodu
      FROM cbs_kredi_teklif_islem
     WHERE tx_no = pn_islem_no;

    UPDATE CBS_KREDI_TEKLIF_satir
       SET musteri_no = ln_musteri_no 
     WHERE teklif_no = ln_teklif_no 
       AND nvl(musteri_no,0) = 0;

    SELECT genel_doviz_kodu
      INTO ls_genel_doviz_kodu
      FROM CBS_KREDI_TEKLIF_LIMIT_ISLEM
     WHERE tx_no = pn_islem_no ;

    UPDATE CBS_MUSTERI_LIMIT
       SET fc_doviz_kodu = ls_genel_doviz_kodu
     WHERE musteri_no = ln_musteri_no ;

    if ls_durum_kodu = 'A' then
        UPDATE CBS_KREDI_TEKLIF_LIMIT_ISLEM
           SET MEVCUT_TEKLIF_NO = Pkg_Kredi.Sf_Onayli_Teklifi_VarMi(ln_musteri_no)
         WHERE tx_no = pn_islem_no;
        pkg_tx1302.Musteri_Limit_Guncelle(pn_islem_no);
    
        --BOM CQ6147 IadgarB
        select count(*) into ln_count from CBS_KREDI_TEKLIF_SATIR_ISLEM where TX_NO = pn_islem_no and pkg_tx1300.sf_kredi_kart_urun_mu(KREDI_TURU) = 'E';

        if nvl(ln_count, 0) <> 0 then
            SELECT TEKLIF_SATIR_NO, ONERILEN_LIMIT_YP, REAL_LIMIT, DOVIZ_KODU, KREDI_TURU
              INTO ln_teklif_satir_no, ln_req_limit, ln_app_limit, ls_doviz_kodu, ls_kredi_turu
              FROM CBS_KREDI_TEKLIF_SATIR_ISLEM 
             WHERE TX_NO = pn_islem_no 
               AND pkg_TX1300.sf_kredi_kart_urun_mu(KREDI_TURU) = 'E';

              --BOM CBS-373 MaratM 14052021
               begin
                    select min(sube_kodu)
                      into v_branch_code
                      from cbs.cbs_hesap_kredi
                     where musteri_no = ln_musteri_no
                           and durum_kodu = 'A' and pkg_tx1300.sf_kredi_kart_urun_mu(urun_grup_no) = 'E' and rownum = 1;
                    exception
                        when OTHERS then v_branch_code := ls_bolum_kodu;
               end;
              --EOM CBS-373 MaratM 14052021
              
              INSERT INTO cbs_kart_musteri_limit_islem(TX_NO, MUSTERI_NO, MUSTERI_LIMIT, MUSTERI_LIMIT_CY, KREDI_TEKLIF_SATIR_NUMARA, URUN_GRUP_NO, BRANCH_CODE)
                VALUES (pn_islem_no, ln_musteri_no, ln_app_limit, ls_doviz_kodu, ln_teklif_satir_no, ls_kredi_turu, nvl(v_branch_code, ls_bolum_kodu));
                
              --BOM CQ6147 NurmilaZh
              BEGIN
                PKG_TX7055.ONAY_SONRASI(pn_islem_no);
              END;
              --EOM CQ6147 NurmilaZh
            --BOM GulkaiyrK cbs-293
               select count(*) into ln_count from cbs_musteri_urun_limit 
                where  fc_limit <> 0 and musteri_no=ln_musteri_no
                and pkg_tx1300.sf_kredi_kart_install(urun_grub_no) = 'E'
                and KREDI_TEKLIF_SATIR_NUMARA in (
                                    select TEKLIF_SATIR_NO from CBS.CBS_KREDI_TEKLIF_SATIR s, CBS.CBS_KREDI_TEKLIF t
                                    where s.TEKLIF_NO = t.TEKLIF_NO and t.DURUM_KODU='A'
                                    and T.musteri_no=ln_musteri_no
                                    );
                    IF NVL(ln_count, 0) <> 0 THEN
                     BEGIN
                    IF ln_count >= 2 THEN
                        SELECT ONERILEN_LIMIT_YP, REAL_LIMIT
                        INTO ln_req_limit, ln_app_limit
                        FROM CBS_KREDI_TEKLIF_SATIR_ISLEM
                        WHERE TX_NO = pn_islem_no
                          AND KREDI_TURU = 32;
                        IF ln_req_limit = 0 and ln_app_limit = 0 THEN
                            SELECT ONERILEN_LIMIT_YP, REAL_LIMIT
                            INTO ln_req_limit, ln_app_limit
                            FROM CBS_KREDI_TEKLIF_SATIR_ISLEM
                            WHERE TX_NO = pn_islem_no
                              and pkg_tx1300.sf_kredi_kart_urun_mu(KREDI_TURU) = 'E';
                         END IF;
                    ELSE
                        SELECT ONERILEN_LIMIT_YP, REAL_LIMIT
                        INTO ln_req_limit, ln_app_limit
                        FROM CBS_KREDI_TEKLIF_SATIR_ISLEM
                        WHERE TX_NO = pn_islem_no
                          AND pkg_tx1300.sf_kredi_kart_urun_mu(KREDI_TURU) = 'E';
                    END IF;
               EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  NULL;
                END;
             end if;
             --EOM CBS-728 Berembek 20102022
             
           
            FOR r_cur IN cur_cr_card LOOP
              is_found_rec := TRUE;
              
               --BOM GulkaiyrK cbs-293
                     if ln_app_limit = 0 then
                        ln_app_limit := ln_req_limit;
                     end if;
               --EOM GulkaiyrK cbs-293    
              pkg_credit_card.SP_UPDATELIMITREQAPP_WS(pn_islem_no,
                                                      2,
                                                      r_cur.banksoft_customer_no,
                                                      nvl(ln_req_limit,0),       --requested limit
                                                      nvl(ln_app_limit,0),       --approved limit
                                                      ps_response_code,
                                                      ps_response_desc);
               
              IF ps_response_code <> '000' THEN
                RAISE WEBSERVICE_GENERAL_ERROR;          
              END IF;
    
              FOR cur in (select * from CBS_CREDIT_CARD_APP_TX where BANKSOFT_NO = r_cur.banksoft_customer_no) LOOP
                UPDATE CBS_CREDIT_CARD_DEF_TX SET CREDIT_CARD_LIMIT = ln_app_limit WHERE TX_NO = cur.TX_NO;
                UPDATE CBS_CREDIT_CARD_DEF SET CREDIT_CARD_LIMIT = ln_app_limit WHERE TX_NO = cur.TX_NO;
                UPDATE CBS_CREDIT_CARD_APP_TX SET LIMIT = ln_app_limit WHERE TX_NO = cur.TX_NO;
              END LOOP;
            END LOOP;
            
            --BOM CQ6147 NurmilaZh
             IF not sf_credit_accounts_close(pn_islem_no, false) then
                RAISE CREDIT_ACCOUNTS_CLOSE; 
             END IF;
            --EOM CQ6147 NurmilaZh
              
            IF NOT is_found_rec THEN
              log_at('limit_update_fail', 'Credit card is not found' ,pn_islem_no, 'CN: ' || ln_musteri_no);
            END IF;
        end if;
        --EOM CQ6147 IadgarB
    
    --BOM ErkinZu CQ614 23042017  
    --if teklif is refused then relation(s) between AppNo(s) and Satir(s) are removed  
    else
        select count(*)
        into ln_count
        from cbs_kredi_teklif_satir
        where teklif_no = ln_teklif_no 
        and satir_durum is null ;
          /******************************************************************************
       Name       :  cbs-233 Simplification of the process of transferring data to the KIB (deleted app_no)
       Created By : GulkaiyrK
       Date          : 22.06.2020
      ******************************************************************************
        and app_no is not null; 
        if ln_count > 0 then
            for cur_satir_row in cur_satir(ln_teklif_no) LOOP
                update cbs_cib_loan_application
                set teklif_satir_no = null
                where app_no = cur_satir_row.app_no;
                update cbs_kredi_teklif_satir
                set app_no = null
                where teklif_satir_no = cur_satir_row.teklif_satir_no;
                update cbs_kredi_teklif_satir_islem
                set app_no = null
                where teklif_satir_no = cur_satir_row.teklif_satir_no;
            end LOOP;
        end if;
        ******************************************************************************/
    --EOM ErkinZu CQ614 23042017
    end if;

  --BOM CQ6147 IadgarB
  EXCEPTION
    WHEN WEBSERVICE_GENERAL_ERROR THEN
        log_at('PKG_TX1300_WEBSERVICE_GENERAL_ERROR', pn_islem_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        -- RAISE_APPLICATION_ERROR(-20100,PKG_HATA.GETUCPOINTER || '6701' || PKG_HATA.GETDELIMITER  || ps_response_code||' '|| ps_response_desc || PKG_HATA.GETDELIMITER ||  PKG_HATA.GETUCPOINTER );
    WHEN CREDIT_ACCOUNTS_CLOSE THEN
        RAISE_APPLICATION_ERROR(-20100,PKG_HATA.GETUCPOINTER || '1203' || PKG_HATA.GETDELIMITER || TO_CHAR(SQLCODE) ||' '|| SQLERRM || PKG_HATA.GETDELIMITER || PKG_HATA.GETUCPOINTER);
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20100,PKG_HATA.GETUCPOINTER || '2050' || PKG_HATA.GETDELIMITER || TO_CHAR(SQLCODE) ||' '|| SQLERRM || PKG_HATA.GETDELIMITER || PKG_HATA.GETUCPOINTER);
    WHEN OTHERS THEN 
        RAISE_APPLICATION_ERROR(-20100,PKG_HATA.GETUCPOINTER || '66' || PKG_HATA.GETDELIMITER || TO_CHAR(SQLCODE) ||' '|| SQLERRM || PKG_HATA.GETDELIMITER || PKG_HATA.GETUCPOINTER);
  END;
  --EOM CQ6147 IadgarB
--------------------------------------------------------------


/******************************************************************************
       Name       :  CBS-366 Transfer last approved limit from 1302 to 7157 
       Created By : GulkaiyrK
       Date          : 22..02.2021
  ******************************************************************************/
  
 PROCEDURE musteri_limit(pn_musteri         IN  NUMBER,
                           pn_limit           OUT NUMBER,
                           ps_limit_cy        OUT VARCHAR2,
                           pn_teklif_satir_no OUT VARCHAR2,
                           pn_urun_Grup_no    OUT VARCHAR2   ) IS
    ln_cnt number;
       
      begin
   
        select count(*) into ln_cnt from  cbs_vw_aktif_kredi_teklif where musteri_no=pn_musteri and    pkg_tx1300.sf_kredi_kart_install(kredi_turu) = 'E'   ;
          if nvl(ln_cnt, 0) <> 0 then
  
               if ln_cnt =2 then 
               select  teklif_satir_no, mevcut_limit_yp ,mevcut_limit_doviz ,kredi_turu
                       into   pn_teklif_satir_no  , pn_limit , ps_limit_cy, pn_urun_grup_no
                       from cbs_vw_aktif_kredi_teklif  
                       where musteri_no = pn_musteri and   kredi_turu=32   ;
--                          
               else
                    
                select  teklif_satir_no, mevcut_limit_yp ,mevcut_limit_doviz ,kredi_turu
                      into   pn_teklif_satir_no  , pn_limit , ps_limit_cy, pn_urun_grup_no
                      from cbs_vw_aktif_kredi_teklif  
                      where musteri_no = pn_musteri and    pkg_tx1300.sf_kredi_kart_urun_mu(kredi_turu) = 'E'  ;       
                                                             
                
             end if;
     end if; 
 END;
/*************************************************************************************************************************/      
Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '699' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
    --  pkg_tx1300.sp_teklifislem_durum_guncelle(pn_islem_no,'I');
  End;
--------------------------------------------------------------
Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    pkg_tx1300.sp_teklifislem_durum_guncelle(pn_islem_no,'R');
  End;
--------------------------------------------------------------
Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
--------------------------------------------------------------
Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
--------------------------------------------------------------
PROCEDURE Muhasebelesme(pn_islem_no NUMBER) IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list             Pkg_Muhasebe.number_array;
    date_list               Pkg_Muhasebe.date_array;
    boolean_list            Pkg_Muhasebe.boolean_array;
    ln_fis_no               CBS_FIS.numara%TYPE ;

    ls_durum_kodu           cbs_kredi_teklif.durum_kodu%type;
    ln_ref_teklif_no        number;

    ls_genel_dvz            VARCHAR2(3);
    ln_genel_limit_lc       NUMBER;
    ln_genel_limit_fc       NUMBER;
    ls_line                 VARCHAR2(3);
    ld_validity_date        DATE;
    ls_mevcut_line          VARCHAR2(3);
    ld_mevcut_validity_date DATE;
    ls_mevcut_lim_dvz       VARCHAR2(3);
    ls_sube_kodu            VARCHAR2(3);
    ln_GENEL_MEVCUT_RISK_TL NUMBER;
    ln_GENEL_MEVCUT_RISK_YP NUMBER;
    ln_GENEL_MEVCUT_LIMIT_TL NUMBER;
    ln_GENEL_MEVCUT_LIMIT_YP NUMBER;
    ln_musteri_no            NUMBER;
    ln_teklif_no             NUMBER;
    ls_mevcut_limit_periyodu VARCHAR2(20);
    ln_mevcut_line_bakiyesi  number;
    ls_statement             varchar(20);
    ls_statement2            varchar(20);
    ln_fark                  NUMBER;
    ln_fark2                 NUMBER;
    ln_eski_teklif_no        NUMBER;
    ln_MEVCUT_TEKLIF_NO      NUMBER;
    ln_cnt                   NUMBER;
-- BOM AdiletK Tranches
    ln_prop_cnt number;
    ln_tranche_teklif_no number;
    ln_tranche_sum number;
-- EOM AdiletK Tranches    
  BEGIN
    varchar_list(pn_1302_HESAP_SUBE)    := '';
    varchar_list(pn_1302_REFERANCE)     := '';
    varchar_list(pn_1302_M_ACIKLAMA)    := '';
    varchar_list(pn_1302_B_ACIKLAMA)    := '';
    varchar_list(pn_1302_DVZ_1)         := '';
    varchar_list(pn_1302_DVZ_2)         := '';
    number_list(pn_1302_KUR_1)          := 0;
    number_list(pn_1302_KUR_2)          := 0;

    number_list(pn_1302_TUTAR1_LC)      := 0;
    number_list(pn_1302_TUTAR2_LC)      := 0;
    number_list(pn_1302_TUTAR3_LC)      := 0;
    number_list(pn_1302_TUTAR4_LC)      := 0;
    number_list(pn_1302_TUTAR5_LC)      := 0;
    number_list(pn_1302_TUTAR6_LC)      := 0;
    number_list(pn_1302_TUTAR7_LC)      := 0;
    number_list(pn_1302_TUTAR8_LC)      := 0;
    number_list(pn_1302_TUTAR9_LC)      := 0;
    number_list(pn_1302_TUTAR10_LC)     := 0;
    number_list(pn_1302_TUTAR11_LC)     := 0;
    number_list(pn_1302_TUTAR12_LC)     := 0;
    number_list(pn_1302_TUTAR13_LC)     := 0;
    number_list(pn_1302_TUTAR14_LC)     := 0;
    number_list(pn_1302_TUTAR15_LC)     := 0;
    number_list(pn_1302_TUTAR16_LC)     := 0;
    number_list(pn_1302_TUTAR1_FC)      := 0;
    number_list(pn_1302_TUTAR2_FC)      := 0;
    number_list(pn_1302_TUTAR3_FC)      := 0;
    number_list(pn_1302_TUTAR4_FC)      := 0;
    number_list(pn_1302_TUTAR5_FC)      := 0;
    number_list(pn_1302_TUTAR6_FC)      := 0;
    number_list(pn_1302_TUTAR7_FC)      := 0;
    number_list(pn_1302_TUTAR8_FC)      := 0;
    number_list(pn_1302_TUTAR9_FC)      := 0;
    number_list(pn_1302_TUTAR10_FC)     := 0;
    number_list(pn_1302_TUTAR11_FC)     := 0;
    number_list(pn_1302_TUTAR12_FC)     := 0;
    number_list(pn_1302_TUTAR13_FC)     := 0;
    number_list(pn_1302_TUTAR14_FC)     := 0;
    number_list(pn_1302_TUTAR15_FC)     := 0;
    number_list(pn_1302_TUTAR16_FC)     := 0;

    boolean_list(pn_1302_P1)  := false;
    boolean_list(pn_1302_P2)  := false;
    boolean_list(pn_1302_P3)  := false;
    boolean_list(pn_1302_P4)  := false;
    boolean_list(pn_1302_P5)  := false;
    boolean_list(pn_1302_P6)  := false;
    boolean_list(pn_1302_P7)  := false;
    boolean_list(pn_1302_P8)  := false;
    boolean_list(pn_1302_P9)  := false;
    boolean_list(pn_1302_P10) := false;
    boolean_list(pn_1302_P11) := false;
    boolean_list(pn_1302_P12) := false;
    boolean_list(pn_1302_P13) := false;
    boolean_list(pn_1302_P14) := false;
    boolean_list(pn_1302_P15) := false;
    boolean_list(pn_1302_P16) := false;
    
-- BOM AdiletK Tranches    
    boolean_list(pn_1302_P18) := false;
    boolean_list(pn_1302_P19) := false; 
    number_list(pn_1302_TUTAR18_LC)     := 0;
    number_list(pn_1302_TUTAR19_LC)     := 0;  
    number_list(pn_1302_TUTAR18_FC)     := 0;
    number_list(pn_1302_TUTAR19_FC)     := 0; 
-- EOM AdiletK Tranches      
-------------
    select
    genel_doviz_kodu,
    nvl(genel_onerilen_limit_tl,0),
    nvl(line_amount,0),    --nvl(genel_onerilen_limit_yp,0),--sevalb 150607
    line,validity_date_of_line,
    mevcut_line,
    mevcut_validity_date,
    mevcut_lim_dvz,
    nvl(genel_mevcut_risk_tl,0),
    nvl(genel_mevcut_risk_yp,0),
    nvl(genel_mevcut_limit_tl,0),
    -- nvl(genel_mevcut_limit_yp,0),--sevalb 150607
    nvl(mevcut_teklif_no,0)
    into
    ls_genel_dvz,
    ln_genel_limit_lc,
    ln_genel_limit_fc,
    ls_line,ld_validity_date,
    ls_mevcut_line,
    ld_mevcut_validity_date,
    ls_mevcut_lim_dvz,
    ln_genel_mevcut_risk_tl,
    ln_genel_mevcut_risk_yp,
    ln_genel_mevcut_limit_tl,
    --ln_genel_mevcut_limit_yp,--sevalb 150607
    ln_mevcut_teklif_no
    from  cbs_kredi_teklif_limit_islem
    where tx_no = pn_islem_no;

    log_at('hakan_1302_1','ls_genel_dvz',ls_genel_dvz);
    log_at('hakan_1302_2','ln_genel_limit_lc',ln_genel_limit_lc);
    log_at('hakan_1302_3','ln_genel_limit_fc',ln_genel_limit_fc);
    log_at('hakan_1302_4','ls_line',ls_line);
    log_at('hakan_1302_5','ld_validity_date',ld_validity_date);
    log_at('hakan_1302_6','ls_mevcut_line',ls_mevcut_line);
    log_at('hakan_1302_7','ld_mevcut_validity_date',ld_mevcut_validity_date);
    log_at('hakan_1302_8','ls_mevcut_lim_dvz',ls_mevcut_lim_dvz);
    log_at('hakan_1302_9','ln_genel_mevcut_risk_tl',ln_genel_mevcut_risk_tl);
    log_at('hakan_1302_10','ln_genel_mevcut_risk_yp',ln_genel_mevcut_risk_yp);
    log_at('hakan_1302_11','ln_genel_mevcut_limit_tl',ln_genel_mevcut_limit_tl);
    log_at('hakan_1302_12','ln_mevcut_teklif_no',ln_mevcut_teklif_no);

    select musteri_no,teklif_no,bolum_kodu,durum_kodu
    into ln_musteri_no,ln_teklif_no,ls_sube_kodu,ls_durum_kodu
    from cbs_kredi_teklif_islem
    where tx_no = pn_islem_no;
    
    log_at('hakan_1302_13','ln_musteri_no',ln_musteri_no);
    log_at('hakan_1302_14','ln_teklif_no',ln_teklif_no);
    log_at('hakan_1302_15','ls_sube_kodu',ls_sube_kodu);
    log_at('hakan_1302_16','ls_durum_kodu',ls_durum_kodu);
    
    --sevalb 150607 genel mevcut limit degeri yerine line amount degerinin konulmasi talep degisikligi
    ln_genel_mevcut_limit_yp := 0;

    select count(*)
    into ln_cnt
    from CBS_MUSTERI_LIMIT
    where musteri_no = ln_musteri_no;

    ls_mevcut_limit_periyodu := null;
    if ln_cnt = 1
    then
        select limit_revizyon_periyodu,
               line_bakiyesi,
               line_amount
        into   ls_mevcut_limit_periyodu,
               ln_mevcut_line_bakiyesi,
               ln_genel_mevcut_limit_yp
        from  CBS_MUSTERI_LIMIT
        where musteri_no = ln_musteri_no;
    end if;
    
    log_at('hakan_1302_17','ls_mevcut_limit_periyodu',ls_mevcut_limit_periyodu);
    log_at('hakan_1302_18','ln_mevcut_line_bakiyesi',ln_mevcut_line_bakiyesi);
    log_at('hakan_1302_19','ln_genel_mevcut_limit_yp',ln_genel_mevcut_limit_yp);

--B-O-M sevalb 070607
 if ls_durum_kodu  = 'A' then --sevalb 070607  red olanlarda muhasebe olmamali
      -- B-O-M sevalb 150607 line amount degisikligi
        update cbs_musteri_limit
        set  line_amount = ln_genel_limit_fc
        where musteri_no = ln_musteri_no;
     -- E-O-M sevalb 150607  line amount degisikligi

    ln_fark := null;
    ls_statement := null;
-------------
    varchar_list(PN_1302_REFERANCE)  := ln_musteri_no;
    varchar_list(pn_1302_HESAP_SUBE) := ls_sube_kodu;--pkg_baglam.Bolum_kodu; --sevalb 070607
    varchar_list(pn_1302_M_ACIKLAMA) := ln_musteri_no || ' Customer Loan Proposal';
    varchar_list(pn_1302_B_ACIKLAMA) := ln_musteri_no || ' Customer Loan Proposal';

    varchar_list(pn_1302_DVZ_1) := ls_genel_dvz;
    varchar_list(pn_1302_DVZ_2) := ls_mevcut_lim_dvz;

    number_list(pn_1302_KUR_1) := Pkg_Kur.doviz_doviz_karsilik(ls_genel_dvz,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A');
    if ls_mevcut_lim_dvz is not null
    then
        number_list(pn_1302_KUR_2) := Pkg_Kur.doviz_doviz_karsilik(ls_mevcut_lim_dvz,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A');
    end if;
-------------
    ln_eski_teklif_no := ln_MEVCUT_TEKLIF_NO;

    if ld_validity_date is null
    then
        ld_validity_date := ld_mevcut_validity_date;
    end if;

    if ln_eski_teklif_no = 0
    then
        if ld_validity_date is not null
        then
            ln_fark := ld_validity_date - pkg_muhasebe.Banka_Tarihi_Bul;
            if ln_fark > 365
            then
                boolean_list(pn_1302_P1) := TRUE;
                number_list(pn_1302_TUTAR1_FC):= ln_genel_limit_fc;
                number_list(pn_1302_TUTAR1_LC):= number_list(pn_1302_TUTAR1_FC) * number_list(pn_1302_KUR_1);
            else
                boolean_list(pn_1302_P2) := TRUE;
                number_list(pn_1302_TUTAR2_FC):= ln_genel_limit_fc;
                number_list(pn_1302_TUTAR2_LC):= number_list(pn_1302_TUTAR2_FC) * number_list(pn_1302_KUR_1);
            end if;

            if ls_line = 'YES' -- Buraya geldiyse zaten YES olmak zorunda ya neyse...
            then
                if ln_fark > 365
                then
                    ls_statement := '>1 YEAR';
                else
                    ls_statement := '<1 YEAR';
                end if;

                update cbs_musteri_limit
                set LINE_BAKIYESI = ln_genel_limit_fc,
                    LIMIT_REVIZYON_PERIYODU = ls_statement
                where musteri_no = ln_musteri_no;
            end if;
        end if;
    else -- Mevcut teklif
        if ld_validity_date is not null
        then
            ln_fark := ld_validity_date - pkg_muhasebe.Banka_Tarihi_Bul;
            if ln_fark > 365
            then
                ls_statement := '>1 YEAR';
            else
                ls_statement := '<1 YEAR';
            end if;
        end if;
log_at('hakan_1302_20','ls_statement',ls_statement);
--
---------- Dvz degisiyor ----------
        if ls_statement is not null and ls_mevcut_lim_dvz <> ls_genel_dvz
           and ls_line = 'YES' and ls_mevcut_line = 'YES'  --sevalb 220607
        then
log_at('hakan_1302_21');
            if ls_statement='>1 YEAR' and ls_mevcut_limit_periyodu='<1 YEAR'
            then
                boolean_list(pn_1302_P10) := TRUE;
                number_list(pn_1302_TUTAR10_FC):= ln_mevcut_line_bakiyesi;
                number_list(pn_1302_TUTAR10_LC):=number_list(pn_1302_TUTAR10_FC)*number_list(pn_1302_KUR_2);

                boolean_list(pn_1302_p11) := TRUE;
                number_list(pn_1302_TUTAR11_FC):=ln_genel_limit_fc;
                number_list(pn_1302_TUTAR11_LC):=number_list(pn_1302_TUTAR11_FC)*number_list(pn_1302_KUR_1);
log_at('hakan_1302_22','number_list(pn_1302_TUTAR10_FC)',number_list(pn_1302_TUTAR10_FC));
log_at('hakan_1302_23','number_list(pn_1302_TUTAR10_LC)',number_list(pn_1302_TUTAR10_LC))    ;
log_at('hakan_1302_24','number_list(pn_1302_TUTAR11_FC)',number_list(pn_1302_TUTAR11_FC));
log_at('hakan_1302_25','number_list(pn_1302_TUTAR11_LC)',number_list(pn_1302_TUTAR11_LC));
            end if;

            if ls_statement='>1 YEAR' and ls_mevcut_limit_periyodu='>1 YEAR'
            then
                boolean_list(pn_1302_P9) := TRUE;
                number_list(pn_1302_TUTAR9_FC):= ln_mevcut_line_bakiyesi;
                number_list(pn_1302_TUTAR9_LC):=number_list(pn_1302_TUTAR9_FC)*number_list(pn_1302_KUR_2);

                boolean_list(pn_1302_p11) := TRUE;
                number_list(pn_1302_TUTAR11_FC):=ln_genel_limit_fc;
                number_list(pn_1302_TUTAR11_LC):=number_list(pn_1302_TUTAR11_FC)*number_list(pn_1302_KUR_1);
log_at('hakan_1302_26','number_list(pn_1302_TUTAR9_FC)',number_list(pn_1302_TUTAR9_FC));
log_at('hakan_1302_27','number_list(pn_1302_TUTAR9_LC)',number_list(pn_1302_TUTAR9_LC));
log_at('hakan_1302_28','number_list(pn_1302_TUTAR11_FC)',number_list(pn_1302_TUTAR11_FC));
log_at('hakan_1302_29','number_list(pn_1302_TUTAR11_LC)',number_list(pn_1302_TUTAR11_LC));
            end if;

            if ls_statement='<1 YEAR' and ls_mevcut_limit_periyodu='<1 YEAR'
            then
                boolean_list(pn_1302_P10) := TRUE;
                number_list(pn_1302_TUTAR10_FC):= ln_mevcut_line_bakiyesi;
                number_list(pn_1302_TUTAR10_LC):=number_list(pn_1302_TUTAR10_FC)*number_list(pn_1302_KUR_2);

                boolean_list(pn_1302_p12) := TRUE;
                number_list(pn_1302_TUTAR12_FC):=ln_genel_limit_fc;
                number_list(pn_1302_TUTAR12_LC):=number_list(pn_1302_TUTAR12_FC)*number_list(pn_1302_KUR_1);
log_at('hakan_1302_30','number_list(pn_1302_TUTAR10_FC)',number_list(pn_1302_TUTAR10_FC));
log_at('hakan_1302_31','number_list(pn_1302_TUTAR10_LC)',number_list(pn_1302_TUTAR10_LC));
log_at('hakan_1302_32','number_list(pn_1302_TUTAR12_FC)',number_list(pn_1302_TUTAR12_FC));
log_at('hakan_1302_33','number_list(pn_1302_TUTAR12_LC)',number_list(pn_1302_TUTAR12_LC));
            end if;

            if ls_statement='<1 YEAR' and ls_mevcut_limit_periyodu='>1 YEAR'
            then
                boolean_list(pn_1302_P9) := TRUE;
                number_list(pn_1302_TUTAR9_FC):= ln_mevcut_line_bakiyesi;
                number_list(pn_1302_TUTAR9_LC):=number_list(pn_1302_TUTAR9_FC)*number_list(pn_1302_KUR_2);

                boolean_list(pn_1302_p12) := TRUE;
                number_list(pn_1302_TUTAR12_FC):=ln_genel_limit_fc;
                number_list(pn_1302_TUTAR12_LC):=number_list(pn_1302_TUTAR12_FC)*number_list(pn_1302_KUR_1);
log_at('hakan_1302_34','number_list(pn_1302_TUTAR9_FC)',number_list(pn_1302_TUTAR9_FC));
log_at('hakan_1302_35','number_list(pn_1302_TUTAR9_LC)',number_list(pn_1302_TUTAR9_LC));
log_at('hakan_1302_36','number_list(pn_1302_TUTAR12_FC)',number_list(pn_1302_TUTAR12_FC));
log_at('hakan_1302_37','number_list(pn_1302_TUTAR12_LC)',number_list(pn_1302_TUTAR12_LC));
            end if;

            update cbs_musteri_limit
            set LINE_BAKIYESI = ln_genel_limit_fc,
                LIMIT_REVIZYON_PERIYODU = ls_statement
            where musteri_no = ln_musteri_no;

---------- Dvz degisiyor ----------
        else
--
---------- Tutar ayni, periyod degisiyor ----------
log_at('hakan_1302_38');
            if  ls_statement is not null and ls_statement <> ls_mevcut_limit_periyodu and
                ln_genel_limit_fc = ln_GENEL_MEVCUT_LIMIT_YP and ls_mevcut_limit_periyodu is not null
                 and ls_line = 'YES' and ls_mevcut_line = 'YES'  --sevalb 220607
            then
log_at('hakan_1302_39');
                if ls_statement = '>1 YEAR'
                then
                    boolean_list(pn_1302_P3) := TRUE;
                    number_list(pn_1302_TUTAR3_FC):= ln_mevcut_line_bakiyesi;
                    number_list(pn_1302_TUTAR3_LC):= number_list(pn_1302_TUTAR3_FC)* number_list(pn_1302_KUR_1);
log_at('hakan_1302_40','number_list(pn_1302_TUTAR3_FC)',number_list(pn_1302_TUTAR3_FC));
log_at('hakan_1302_41','number_list(pn_1302_TUTAR3_LC)',number_list(pn_1302_TUTAR3_LC));
                else
                    boolean_list(pn_1302_P4) := TRUE;
                    number_list(pn_1302_TUTAR4_FC):= ln_mevcut_line_bakiyesi;
                    number_list(pn_1302_TUTAR4_LC):= number_list(pn_1302_TUTAR4_FC)* number_list(pn_1302_KUR_1);
log_at('hakan_1302_42','number_list(pn_1302_TUTAR4_FC)',number_list(pn_1302_TUTAR4_FC));
log_at('hakan_1302_43','number_list(pn_1302_TUTAR4_LC)',number_list(pn_1302_TUTAR4_LC));
                end if;

                ln_fark2 := ld_validity_date - pkg_muhasebe.Banka_Tarihi_Bul;

log_at('hakan_1302_44','ln_fark2',ln_fark2);
                if ln_fark2 > 365
                then
                    ls_statement2 := '>1 YEAR';
                else
                    ls_statement2 := '<1 YEAR';
                end if;

log_at('hakan_1302_45','ls_statement2',ls_statement2);
                update cbs_musteri_limit
                set LIMIT_REVIZYON_PERIYODU = ls_statement2
                where musteri_no = ln_musteri_no;
            end if;
---------- Tutar ayni, periyod degisiyor ----------
--
log_at('hakan_1302_46');
---------- Tutar da degisti, periyodta ----------
            if  ls_statement is not null and
                ls_mevcut_limit_periyodu is not null and
                ls_statement <> ls_mevcut_limit_periyodu and
                ln_genel_limit_fc <> ln_GENEL_MEVCUT_LIMIT_YP
                and ls_line = 'YES' and ls_mevcut_line = 'YES'  --sevalb 220607
            then
log_at('hakan_1302_47');
                if ls_statement = '>1 YEAR'
                then
                    boolean_list(pn_1302_P3) := TRUE;
                    if ln_genel_limit_fc > ln_GENEL_MEVCUT_LIMIT_YP
                    then
                        number_list(pn_1302_TUTAR3_FC):= ln_mevcut_line_bakiyesi;
                        number_list(pn_1302_TUTAR3_LC):= number_list(pn_1302_TUTAR3_FC)* number_list(pn_1302_KUR_1);
                    else
                        number_list(pn_1302_TUTAR3_FC):= ln_mevcut_line_bakiyesi ;
                        number_list(pn_1302_TUTAR3_LC):= number_list(pn_1302_TUTAR3_FC)* number_list(pn_1302_KUR_1);
                    end if;
log_at('hakan_1302_48','number_list(pn_1302_TUTAR3_FC)',number_list(pn_1302_TUTAR3_FC));
log_at('hakan_1302_49','number_list(pn_1302_TUTAR3_LC)',number_list(pn_1302_TUTAR3_LC));
                else
                    boolean_list(pn_1302_P4) := TRUE;
                    if ln_genel_limit_fc > ln_GENEL_MEVCUT_LIMIT_YP
                    then
                        number_list(pn_1302_TUTAR4_FC):= ln_mevcut_line_bakiyesi ;
                        number_list(pn_1302_TUTAR4_LC):= number_list(pn_1302_TUTAR4_FC)* number_list(pn_1302_KUR_1);
                    else
                        number_list(pn_1302_TUTAR4_FC):= ln_mevcut_line_bakiyesi;
                        number_list(pn_1302_TUTAR4_LC):= number_list(pn_1302_TUTAR4_FC)* number_list(pn_1302_KUR_1);
                    end if;
log_at('hakan_1302_50','number_list(pn_1302_TUTAR4_FC)',number_list(pn_1302_TUTAR4_FC));
log_at('hakan_1302_51','number_list(pn_1302_TUTAR4_LC)',number_list(pn_1302_TUTAR4_LC));
                end if;

                ln_fark2 := ld_validity_date - pkg_muhasebe.Banka_Tarihi_Bul;
                if ln_fark2 > 365
                then
                    ls_statement2 := '>1 YEAR';
                else
                    ls_statement2 := '<1 YEAR';
                end if;

log_at('hakan_1302_52','ls_statement2',ls_statement2);
                update cbs_musteri_limit
                set LIMIT_REVIZYON_PERIYODU = ls_statement2
                where musteri_no = ln_musteri_no;
            end if;
---------- Tutar da degisti, periyodta ----------
--
---------- Tutar degisiyor ----------
            if ls_statement is not null and ln_genel_limit_fc > ln_GENEL_MEVCUT_LIMIT_YP
             and ls_line = 'YES' and ls_mevcut_line = 'YES'  --sevalb 220607
            then
                if ls_statement = '>1 YEAR'
                then
                    boolean_list(pn_1302_P5) := TRUE;
                    number_list(pn_1302_TUTAR5_FC) := ln_genel_limit_fc - ln_GENEL_MEVCUT_LIMIT_YP;
                    number_list(pn_1302_TUTAR5_LC):=number_list(pn_1302_TUTAR5_FC)*number_list(pn_1302_KUR_1);
                else
                    boolean_list(pn_1302_P6) := TRUE;
                    number_list(pn_1302_TUTAR6_FC) := ln_genel_limit_fc - ln_GENEL_MEVCUT_LIMIT_YP;
                    number_list(pn_1302_TUTAR6_LC):=number_list(pn_1302_TUTAR6_FC)*number_list(pn_1302_KUR_1);
                end if;

log_at('hakan_1302_53','number_list(pn_1302_TUTAR5_FC)',number_list(pn_1302_TUTAR5_FC));
log_at('hakan_1302_54','number_list(pn_1302_TUTAR5_LC)',number_list(pn_1302_TUTAR5_LC));
log_at('hakan_1302_55','number_list(pn_1302_TUTAR6_FC)',number_list(pn_1302_TUTAR6_FC));
log_at('hakan_1302_56','number_list(pn_1302_TUTAR6_LC)',number_list(pn_1302_TUTAR6_LC));
                update cbs_musteri_limit
                set LINE_BAKIYESI = LINE_BAKIYESI + (ln_genel_limit_fc - ln_GENEL_MEVCUT_LIMIT_YP)
                where musteri_no = ln_musteri_no;
            end if;

            if ls_statement is not null and ln_genel_limit_fc < ln_GENEL_MEVCUT_LIMIT_YP
             and ls_line = 'YES' and ls_mevcut_line = 'YES'  --sevalb 220607
            then
                if ls_statement = '>1 YEAR'
                then
                    boolean_list(pn_1302_P7) := TRUE;
                    number_list(pn_1302_TUTAR7_FC):= ln_GENEL_MEVCUT_LIMIT_YP - ln_genel_limit_fc;
                    number_list(pn_1302_TUTAR7_LC):=number_list(pn_1302_TUTAR7_FC)*number_list(pn_1302_KUR_1);
                else
                    boolean_list(pn_1302_P8) := TRUE;
                    number_list(pn_1302_TUTAR8_FC):= ln_GENEL_MEVCUT_LIMIT_YP - ln_genel_limit_fc;
                    number_list(pn_1302_TUTAR8_LC):=number_list(pn_1302_TUTAR8_FC)*number_list(pn_1302_KUR_1);
                end if;
log_at('hakan_1302_57','number_list(pn_1302_TUTAR7_FC)',number_list(pn_1302_TUTAR7_FC));
log_at('hakan_1302_58','number_list(pn_1302_TUTAR7_LC)',number_list(pn_1302_TUTAR7_LC));
log_at('hakan_1302_59','number_list(pn_1302_TUTAR8_FC)',number_list(pn_1302_TUTAR8_FC));
log_at('hakan_1302_60','number_list(pn_1302_TUTAR8_LC)',number_list(pn_1302_TUTAR8_LC));

                update cbs_musteri_limit
                set LINE_BAKIYESI = LINE_BAKIYESI + (ln_genel_limit_fc - ln_GENEL_MEVCUT_LIMIT_YP)
                where musteri_no = ln_musteri_no;
            end if;
        end if;
---------- Tutar degisiyor ----------
--
---------- YES idi NO oldu ----------
        if ls_mevcut_line = 'YES' and ls_line = 'NO'
        then
log_at('hakan_1302_61');
            if ls_mevcut_limit_periyodu is not null
            then
log_at('hakan_1302_62');
                if ls_mevcut_limit_periyodu = '>1 YEAR'
                then
                    boolean_list(pn_1302_P13) := TRUE;
                    number_list(pn_1302_TUTAR13_FC):= ln_mevcut_line_bakiyesi;
                    number_list(pn_1302_TUTAR13_LC):=number_list(pn_1302_TUTAR13_FC)*number_list(pn_1302_KUR_1);
                else
                    boolean_list(pn_1302_P14) := TRUE;
                    number_list(pn_1302_TUTAR14_FC):= ln_mevcut_line_bakiyesi;
                    number_list(pn_1302_TUTAR14_LC):=number_list(pn_1302_TUTAR14_FC)*number_list(pn_1302_KUR_1);
                end if;
log_at('hakan_1302_63','number_list(pn_1302_TUTAR13_FC)',number_list(pn_1302_TUTAR13_FC));
log_at('hakan_1302_64','number_list(pn_1302_TUTAR13_LC)',number_list(pn_1302_TUTAR13_LC));
log_at('hakan_1302_65','number_list(pn_1302_TUTAR14_FC)',number_list(pn_1302_TUTAR14_FC));
log_at('hakan_1302_66','number_list(pn_1302_TUTAR14_LC)',number_list(pn_1302_TUTAR14_LC));
                update cbs_musteri_limit
                set LINE_BAKIYESI = null,
                    LIMIT_REVIZYON_PERIYODU = null
                where musteri_no = ln_musteri_no;
            end if;
        end if;
---------- YES idi NO oldu ----------
--
---------- NO idi YES oldu ----------
        if ls_mevcut_line = 'NO' and ls_line = 'YES'
        then
            if ls_statement = '>1 YEAR'
            then
                boolean_list(pn_1302_P15) := TRUE;
                number_list(pn_1302_TUTAR15_FC):=ln_genel_limit_fc;
                number_list(pn_1302_TUTAR15_LC):= number_list(pn_1302_TUTAR15_FC)*number_list(pn_1302_KUR_1);
            else
                boolean_list(pn_1302_P16) := TRUE;
                number_list(pn_1302_TUTAR16_FC):=ln_genel_limit_fc;
                number_list(pn_1302_TUTAR16_LC):= number_list(pn_1302_TUTAR16_FC)*number_list(pn_1302_KUR_1);
            end if;
log_at('hakan_1302_67');

            update cbs_musteri_limit
            set LINE_BAKIYESI = ln_genel_limit_fc,
                LIMIT_REVIZYON_PERIYODU = ls_statement
            where musteri_no = ln_musteri_no;
        end if;
---------- NO idi YES oldu ----------
--
    end if;  -- Mevcut teklif
log_at('hakan_1302_68');

-- BOM 04.01.2017 AdiletK CQ4712 Tranches
    select count(*)
    into ln_prop_cnt
    from cbs_kredi_teklif
    where teklif_no in (select t.ref_teklif_no
                                from cbs_kredi_teklif_islem t
                                where t.tx_no = pn_islem_no);
    log_at('test_1302', 1, pn_islem_no, ln_prop_cnt);                            
    IF ln_prop_cnt > 0 THEN
        select nvl(teklif_no, 0)
        into ln_tranche_teklif_no
        from cbs_kredi_teklif
        where teklif_no in (select t.ref_teklif_no
                                    from cbs_kredi_teklif_islem t
                                    where t.tx_no = pn_islem_no); 
        log_at('test_1302', 2, pn_islem_no, ln_tranche_teklif_no);                                  
        select  sum(Pkg_Kur.doviz_doviz_karsilik(s.doviz_kodu,ls_genel_dvz,NULL,(s.onerilen_limit_yp - l.fc_risk),1,NULL,NULL,'N','A'))
        into ln_tranche_sum
        from cbs_kredi_teklif_satir s,
                cbs_musteri_urun_limit l
        where s.musteri_no = l.musteri_no and
                  s.kredi_turu = l.urun_grub_no and
                  s.teklif_satir_no = l.kredi_teklif_satir_numara and
                  s.tranches = 'Y' and
                  s.teklif_no in (select teklif_no 
                                       from cbs_kredi_teklif_islem 
                                       where tx_no = pn_islem_no) and
                  s.teklif_satir_no in (select ss.teklif_satir_no
                                                from cbs_kredi_teklif_satir ss
                                                where ss.teklif_no = ln_tranche_teklif_no and
                                                          ss.tranches = s.tranches and
                                                          ss.maturity_date < pkg_muhasebe.banka_tarihi_bul) and
                  s.maturity_date >= pkg_muhasebe.banka_tarihi_bul;    
        log_at('test_1302', 3, ls_statement, ln_tranche_sum);           
        IF ls_statement = '<1 YEAR' THEN
            boolean_list(pn_1302_P18) := true;
            number_list(pn_1302_TUTAR18_LC) := Pkg_Kur.doviz_doviz_karsilik(ls_genel_dvz, pkg_genel.lc_al,NULL,ln_tranche_sum,1,NULL,NULL,'N','A');
            number_list(pn_1302_TUTAR18_FC) := ln_tranche_sum;                        
        ELSE
            boolean_list(pn_1302_P19) := true; 
            number_list(pn_1302_TUTAR19_LC) := Pkg_Kur.doviz_doviz_karsilik(ls_genel_dvz, pkg_genel.lc_al,NULL,ln_tranche_sum,1,NULL,NULL,'N','A');  
            number_list(pn_1302_TUTAR19_FC) := ln_tranche_sum;         
        END IF;          
                            
    END IF;
-- EOM 04.01.2017 AdiletK CQ4712 Tranches

    ln_fis_no:=Pkg_Muhasebe.fis_kes(1302,
                                    17,
                                    pn_islem_no,
                                    varchar_list ,
                                    number_list  ,
                                    date_list    ,
                                    boolean_list ,
                                    NULL,
                                    FALSE,
                                    0,
                                    'Loan Proposal');

    Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);

     -- sevalb 070607   sch calismasi istenmediginden eklendi.
       update cbs_islem
       set       AMIR_BOLUM_KODU = ls_sube_kodu
       where numara =pn_islem_no;


 end if; --E-O-M 070607

/* teklif numarasi alinir*/
      select teklif_no ,durum_kodu ,musteri_no ,ref_teklif_no
    into   ln_teklif_no ,ls_durum_kodu ,ln_musteri_no,ln_ref_teklif_no
    from   cbs_kredi_teklif_islem
    where  tx_no = pn_islem_no ;

/* ONAY Durum kodunda ise onceki teklifler kapatilir */
    if ls_durum_kodu  ='A' then
         pkg_kredi.Sp_Onceki_Kredi_Teklifi_Kapat(ln_teklif_no) ;
/* sifirlanmis satirlar ana tablodan silinir , iliskili oldugu detay teminat bilgisi de silinir */
         pkg_tx1302.Sp_teklif_Satir_sifirlanmissa(pn_islem_no);
        /* limit guncellenir */
         pkg_tx1302.Teklif_limit_satir_guncelle(pn_islem_no);
--         pkg_tx1302.Musteri_Limit_Guncelle(pn_islem_no);
/*BahianaB CBS-677 Installment Notification 05092022*/         
         pkg_tx1302.Installment_Notif(pn_islem_no);   
    end if;

/* teklif durumu yeni durum koduyla guncellenir */
    pkg_kredi.sp_teklif_durum_guncelle(ln_teklif_no,ls_durum_kodu);
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR1_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR2_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR3_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR4_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR5_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR6_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR7_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR8_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR9_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR10_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR11_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR12_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR13_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR14_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR15_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR16_LC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR1_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR2_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR3_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR4_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR5_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR6_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR7_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR8_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR9_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR10_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR11_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR12_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR13_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR14_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR15_FC));
    log_at('muhasebe_1302',    number_list(pn_1302_TUTAR16_FC));

   EXCEPTION
     WHEN OTHERS THEN
     log_at('PKG_TX1302','MUHASEBELESME',SQLERRM ||' '|| TO_CHAR(PN_ISLEM_NO),dbms_utility.format_error_backtrace);
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2056' || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
END;
--------------------------------------------------------------
Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
  Begin
    Null;
  End;
--------------------------------------------------------------
Procedure Musteri_Limit_Guncelle(pn_islem_no number) is
    ln_musteri_no       cbs_musteri.musteri_no%type;
    ln_teklif_no        cbs_kredi_teklif.teklif_no%type;
    
    cursor cursor_teklif_satir is
        select doviz_kodu,
               kredi_turu,
               onerilen_limit_tl,
               onerilen_limit_yp,
               teklif_satir_no,
               teklif_no,
               line,
               mevcut_risk_yp,
               nvl(real_limit, 0) real_limit
        from cbs_kredi_teklif_satir_islem
        where tx_no = pn_islem_no ;

    cursor cursor_teklif_limit_islem is
        select genel_doviz_kodu,
               grup_doviz_kodu,
               nakit_onerilen_limit_tl,
               nakit_onerilen_limit_yp,
               gayrinakit_onerilen_limit_tl,
               gayrinakit_onerilen_limit_yp,
               genel_onerilen_limit_tl,
               genel_onerilen_limit_yp,
               grup_onerilen_limit_tl,
               grup_onerilen_limit_yp,
               line, 
               validity_date_of_line
        from cbs_kredi_teklif_limit_islem
        where tx_no = pn_islem_no ;
--------------------------------------------------------------
-- B-O-M AdiletK 04.01.2017 CQ4712 Tranches
    ln_fc_limit CBS_MUSTERI_URUN_LIMIT.fc_limit%TYPE;
    ln_new_real_limit CBS_KREDI_TEKLIF_SATIR_ISLEM.real_limit%TYPE;
    ln_curr_real_limit CBS_KREDI_TEKLIF_SATIR.real_limit%TYPE;
    ln_limit_diff CBS_MUSTERI_URUN_LIMIT.fc_limit%TYPE;
    ls_is_cash CBS_URUN_GRUBU.nakdi_mi%TYPE;
-- E-O-M AdiletK 04.01.2017 CQ4712 Tranches
  BEGIN
    select musteri_no,teklif_no
    into ln_musteri_no,ln_teklif_no
    from cbs_kredi_teklif_islem
    where tx_no = pn_islem_no ;

    For cur_teklif_limit_islem in cursor_teklif_limit_islem loop
        pkg_limit.Sp_Musteri_Limit_Guncelle (ln_musteri_no ,
                                             cur_teklif_limit_islem.genel_doviz_kodu,
                                             cur_teklif_limit_islem.genel_onerilen_limit_tl,
                                             cur_teklif_limit_islem.genel_onerilen_limit_yp,
                                             cur_teklif_limit_islem.nakit_onerilen_limit_tl ,
                                             cur_teklif_limit_islem.nakit_onerilen_limit_yp,
                                             cur_teklif_limit_islem.gayrinakit_onerilen_limit_tl,
                                             cur_teklif_limit_islem.gayrinakit_onerilen_limit_yp);
    end loop;

    For cur_teklif_satir in cursor_teklif_satir loop
        pkg_limit.Sp_Musteri_Urun_Limit_Guncelle(ln_musteri_no ,
                                                 cur_teklif_satir.kredi_turu,
                                                 cur_teklif_satir.teklif_satir_no,
                                                 cur_teklif_satir.doviz_kodu ,
                                                 cur_teklif_satir.onerilen_limit_tl,
                                                 cur_teklif_satir.onerilen_limit_yp);

-- B-O-M AdiletK 04.01.2017 CQ4712 real limit
        
        ln_new_real_limit := cur_teklif_satir.real_limit;
                
        UPDATE CBS_KREDI_TEKLIF_SATIR
           SET real_limit = ln_new_real_limit
         WHERE musteri_no = ln_musteri_no 
           AND teklif_no = cur_teklif_satir.teklif_no 
           AND teklif_satir_no = cur_teklif_satir.teklif_satir_no;
-- E-O-M AdiletK 04.01.2017 CQ4712 real limit

    -- B-O-M sevalb 150607 line amount degisikligi
        UPDATE CBS_MUSTERI_URUN_LIMIT
           SET line = cur_teklif_satir.line
         WHERE musteri_no = ln_musteri_no 
           AND urun_grub_no =  cur_teklif_satir.kredi_turu 
           AND kredi_teklif_satir_numara = cur_teklif_satir.teklif_satir_no ;

    -- E-O-M sevalb 150607 line amount degisikligi
    end loop;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,pkg_hata.getUCPOINTER || '509' || pkg_hata.getDelimiter ||to_char(SQLCODE) || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
  END;
--------------------------------------------------------------
Procedure Teklif_limit_satir_guncelle(pn_islem_no number) is
    ln_teklif_no                cbs_kredi_teklif.teklif_no%type;
    ld_mevcut_yenileme_vade    cbs_kredi_teklif_limit.mevcut_yenileme_vade%type;
    ld_onerilen_yenileme_vade  cbs_kredi_teklif_limit.mevcut_yenileme_vade%type;
    ls_teklif_referans         cbs_kredi_teklif.teklif_referans%type;
    ln_musterino               cbs_kredi_teklif.musteri_no%type;
    ln_line_amount              number := 0 ;
  BEGIN
       select a.teklif_no,
              mevcut_yenileme_vade,
              onerilen_yenileme_vade,
              a.teklif_referans ,
              a.musteri_no,
              b.line_amount
         into ln_teklif_no,
              ld_mevcut_yenileme_vade,
              ld_onerilen_yenileme_vade,
              ls_teklif_referans,
              ln_musterino,
              ln_line_amount
         from cbs_kredi_teklif_islem a,
              cbs_kredi_teklif_limit_islem b
        where a.tx_no = pn_islem_no 
          and a.tx_no = b.tx_no;

/* yenileme tarihi de?i?tirildiyse musteri revize alanlari guncellenir*/
         if  (ld_mevcut_yenileme_vade  is null and ld_onerilen_yenileme_vade is not null ) or
             ( ld_mevcut_yenileme_vade <> ld_onerilen_yenileme_vade )then

             update cbs_musteri
            set  LIMIT_REVIZE_TARIHI = ld_onerilen_yenileme_vade,
                 LIMIT_REVIZE_ONAY_TARIHI =     pkg_muhasebe.banka_tarihi_bul,
                 LIMIT_REVIZE_TEKLIF_REFERANS =  ls_teklif_referans
            where musteri_no = ln_musterino;

         end if;

/* genel limit onerilen mevcut olarak guncelenir */

     update cbs_kredi_teklif_limit_islem
     set nakit_mevcut_limit_tl =nakit_onerilen_limit_tl,
         nakit_mevcut_limit_yp = nakit_onerilen_limit_yp,
         gayrinakit_mevcut_limit_tl =gayrinakit_onerilen_limit_tl,
         gayrinakit_mevcut_limit_yp = gayrinakit_onerilen_limit_yp,
         genel_mevcut_limit_tl =genel_onerilen_limit_tl,
         genel_mevcut_limit_yp = genel_onerilen_limit_yp,
         mevcut_yenileme_vade = onerilen_yenileme_vade
     where tx_no = pn_islem_no;

     update cbs_kredi_teklif_limit
      set nakit_mevcut_limit_tl =nakit_onerilen_limit_tl,
          nakit_mevcut_limit_yp = nakit_onerilen_limit_yp,
          gayrinakit_mevcut_limit_tl =gayrinakit_onerilen_limit_tl,
          gayrinakit_mevcut_limit_yp = gayrinakit_onerilen_limit_yp,
          genel_mevcut_limit_tl =genel_onerilen_limit_tl,
          genel_mevcut_limit_yp = genel_onerilen_limit_yp,
          mevcut_yenileme_vade = onerilen_yenileme_vade,
          line_amount = ln_line_amount
     where teklif_no = ln_teklif_no;

/* teklif satir limit onerilen mevcut olarak guncellenir */
     update cbs_kredi_teklif_satir_islem a
     set  (mevcut_limit_tl,
           mevcut_limit_yp,
           vade_suresi,
           vade_tipi) = (select onerilen_limit_tl,
                                onerilen_limit_yp,
                                onerilen_vade_suresi,
                                onerilen_vade_tipi
                         from cbs_kredi_teklif_satir_islem
                         where tx_no = pn_islem_no 
                         and teklif_no = ln_teklif_no 
                         and teklif_satir_no =a.teklif_satir_no)
     where tx_no =pn_islem_no 
     and teklif_no = ln_teklif_no;


     update cbs_kredi_teklif_satir a
        set (mevcut_limit_tl ,
             mevcut_limit_yp,
             vade_suresi,
             vade_tipi,
             line) = (select onerilen_limit_tl,
                             onerilen_limit_yp,
                             onerilen_vade_suresi,
                             onerilen_vade_tipi,
                             line
                      from cbs_kredi_teklif_satir
                      where teklif_no = ln_teklif_no 
                      and teklif_satir_no = a.teklif_satir_no)
      where teklif_no = ln_teklif_no;

  END;
--------------------------------------------------------------
--b-o-m sevalb sdlc18702 26072011
FUNCTION sf_teklif_hesap_mevcutmu( pn_teklif_Satir_no NUMBER) RETURN VARCHAR2 IS
    ln_hesap_no     NUMBER;
    hesaba_bagli    EXCEPTION;
    BEGIN
        SELECT MIN(hesap_no)
        INTO ln_hesap_no
        FROM CBS_HESAP_KREDI
        WHERE durum_kodu ='A' 
        AND kredi_teklif_satir_numara = pn_teklif_satir_no; 

        IF NVL(ln_hesap_no,0) <> 0 THEN
            RETURN 'E';
        ELSE
            RETURN 'H';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN RETURN  'H';
    END;  
FUNCTION sf_teklif_risk_mevcutmu(pn_musteri_no number,pn_urun_grub_no number ,pn_teklif_Satir_no NUMBER) RETURN VARCHAR2 IS
    ln_fc_risk      NUMBER := 0;
    hesaba_bagli    EXCEPTION;
    BEGIN
        select max(fc_risk)
        into ln_fc_risk
        from cbs_musteri_urun_limit
        where musteri_no = pn_musteri_no and 
              urun_grub_no =pn_urun_grub_no and 
              kredi_teklif_satir_numara = pn_teklif_satir_no and  nvl(fc_risk,0) <> 0;
     
        IF NVL(ln_fc_risk,0) <> 0 THEN
            RETURN 'E';
        ELSE
            RETURN 'H';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN RETURN  'H';
    END;  

--E-o-m sevalb sdlc18702 26072011
Procedure Sp_teklif_Satir_sifirlanmissa( pn_islem_no number)
  is
ln_musteri_no number := 0;
/* sifirlanan satirlar ana tablodan silinir */
    cursor cursor_teklif_satir is
    select teklif_no, teklif_satir_no
    from cbs_kredi_teklif_satir_islem
    where tx_no = pn_islem_no and
          nvl(onerilen_limit_tl,0) = 0 and nvl(onerilen_limit_yp,0) = 0 AND pkg_tx1300.sf_kredi_kart_install(kredi_turu) <> 'E'  and -- for credit_card_limits GulkaiyrK
          pkg_tx1302.sf_teklif_hesap_mevcutmu( teklif_satir_no) = 'H' and       --SEVALB SDLC18702 26072011
          pkg_tx1302.sf_teklif_risk_mevcutmu(ln_musteri_no , kredi_turu,teklif_satir_no) = 'H' ;--SEVALB SDLC18702 26072011

  Begin
    select musteri_no
    into ln_musteri_no
    from cbs_kredi_teklif_islem
    where tx_no = pn_islem_no;

    for cur_teklif_satir in cursor_teklif_satir loop
        delete from cbs_kredi_teklif_satir_teminat
         where teklif_no = cur_teklif_satir.teklif_no 
           and teklif_satir_no = cur_teklif_satir.teklif_satir_no;

        delete from cbs_kredi_teklif_satir
         where teklif_no = cur_teklif_satir.teklif_no 
           and teklif_satir_no = cur_teklif_satir.teklif_satir_no;
    end loop;
  End;
--------------------------------------------------------------
FUNCTION sf_credit_accounts_close(pn_islem_no number, pn_eom_close boolean) RETURN BOOLEAN
IS
  ln_musteri_no             cbs_musteri.musteri_no%type;              
  ln_bakiye                 NUMBER := 0; 
  ln_req_limit              NUMBER; 
  ld_kredi_vade             DATE;
  PS_OVERBALANCE            VARCHAR2(200);
  PS_CARDNO                 VARCHAR2(200);       
  PS_CUSTOMERNO             VARCHAR2(200);       
  PS_CRMNO                  VARCHAR2(200);       
  PS_CUSTOMERNAME           VARCHAR2(200);       
  PS_LASTSTATEMENTDATE      VARCHAR2(200);       
  PS_LASTPAYMENTDATE        VARCHAR2(200);       
  PS_NEARESTSTATEMENTDATE   VARCHAR2(200);       
  PS_STATEMENTCODE          VARCHAR2(200);       
  PS_MINPAYMENTAMOUNT       VARCHAR2(200);       
  PS_TOTALDEBT              VARCHAR2(200);
  PS_RESPONSE_CODE          VARCHAR2(200);
  PS_RESPONSE_DESC          VARCHAR2(200);
  PC_REF                    SYS_REFCURSOR;
  LN_OVERBALANCE            NUMBER;
  LN_CASHCOLLATERAL         NUMBER;
  LN_OVERLIMIT              NUMBER;
  LN_LOAN_HESAPNO           NUMBER;
  LN_PASTDUE_FIRST          NUMBER;
  LN_PASTDUE_SECOND         NUMBER;
  LN_INSTALLMENT            NUMBER;   
  ln_totaldebt              number := 0; --CBS-667 04072022
  ln_ws_overbalance         number := 0; --CBS-667 04072022   
  LD_AYIN_SON_IS_GUNU       DATE := Pkg_Tarih.ayin_son_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul);  
  CURSOR cur_cr_card IS
    select unique card_id_no, customer_no, created_date, emboss_name_eng from cbs_credit_card 
           where 
--           status = 'A' --CBS-667 04072022
           primary_card_flag = 'A'
           AND 
           customer_no = ln_musteri_no  and  substr(card_no, 1, 6) not in (458818);--cbs288 GulkaiyrK 17.09.2020 Limit update for business cards;;
  r_cur cur_cr_card%ROWTYPE;
    
BEGIN
        select musteri_no, onerilen_limit_yp
          into ln_musteri_no, ln_req_limit
           from cbs_kredi_teklif_satir_islem 
             where tx_no = pn_islem_no and pkg_tx1300.sf_kredi_kart_urun_mu(kredi_turu) = 'E'; 
          IF ln_req_limit = 0 then  
          
            LN_OVERBALANCE := PKG_ATM_HESAP.OVERBALANCE_HESAPNO_AL(ln_musteri_no,pkg_genel.lc_al);
            LN_CASHCOLLATERAL := PKG_ATM_HESAP.CASHCOLLATERAL_HESAPNO_AL(ln_musteri_no,pkg_genel.lc_al);
            LN_OVERLIMIT := PKG_ATM_HESAP.OVERLIMIT_HESAPNO_AL(ln_musteri_no,pkg_genel.lc_al);
            LN_LOAN_HESAPNO := PKG_ATM_HESAP.LOAN_HESAPNO_AL(ln_musteri_no,pkg_genel.lc_al);
            LN_PASTDUE_FIRST := PKG_ATM_HESAP.PASTDUE_HESAPNO_AL(PKG_ATM_HESAP.LOAN_HESAPNO_AL(ln_musteri_no,pkg_genel.lc_al));
            LN_PASTDUE_SECOND := PKG_ATM_HESAP.PASTDUE_HESAPNO_AL(PKG_ATM_HESAP.INSTALLMENT_HESAPNO_AL(ln_musteri_no,pkg_genel.lc_al));
            LN_INSTALLMENT := PKG_ATM_HESAP.INSTALLMENT_HESAPNO_AL(ln_musteri_no,pkg_genel.lc_al);    
            
            select sum(abs(bakiye)) into ln_bakiye from cbs_vw_hesap_izleme where
                                       musteri_no=ln_musteri_no
                                       and durum_kodu = 'A'
                                       and hesap_no in (LN_OVERBALANCE,
                                                        LN_CASHCOLLATERAL,
                                                        LN_OVERLIMIT,
                                                        LN_LOAN_HESAPNO,
                                                        LN_PASTDUE_FIRST,
                                                        LN_PASTDUE_SECOND,
                                                        LN_INSTALLMENT);      

            FOR r_cur IN cur_cr_card LOOP           
                pkg_credit_card.SP_STATSIMREQ_WS(r_cur.card_id_no,
                                                 LPAD(r_cur.customer_no, 13, '0'),   
                                                 TO_CHAR(sysdate, 'YYYYMMDD'),--date format YYYYMMDD
                                                 PS_CARDNO,
                                                 PS_CUSTOMERNO,
                                                 PS_CRMNO,
                                                 PS_CUSTOMERNAME,
                                                 PS_LASTSTATEMENTDATE,
                                                 PS_LASTPAYMENTDATE,
                                                 PS_NEARESTSTATEMENTDATE,
                                                 PS_STATEMENTCODE,
                                                 PS_MINPAYMENTAMOUNT,
                                                 PS_TOTALDEBT,
                                                 PS_RESPONSE_CODE,
                                                 PS_RESPONSE_DESC,
                                                 PC_REF);   
                pkg_credit_card.SP_CCARD_GET_OVERBALANCE_WS(LPAD(r_cur.customer_no, 13, '0'), r_cur.card_id_no, ps_overbalance);                                                                                   
       --BOM CBS-667 04072022      
                ln_totaldebt :=  ln_totaldebt + to_number(PS_TOTALDEBT,'99999999999.99');                                                                                
                ln_ws_overbalance := ln_ws_overbalance + to_number(ps_overbalance,'99999999999.9999');
                              
            END LOOP;
            
            --Close credit accounts                            
                IF ln_totaldebt = 0 and ln_bakiye = 0 and ln_ws_overbalance = 0 and ps_response_code='000' and ld_ayin_son_is_gunu <> Pkg_Muhasebe.Banka_Tarihi_Bul THEN
                    update cbs_hesap
                       set durum_kodu = 'K',
                           kapama_tarihi = Pkg_Muhasebe.banka_tarihi_bul
                     where durum_kodu = 'A'
                       and hesap_no in (LN_OVERBALANCE, 
                                        LN_CASHCOLLATERAL); 

                    update cbs_hesap_kredi
                       set durum_kodu = 'K',
                           kapanis_tarihi = Pkg_Muhasebe.banka_tarihi_bul
                     where durum_kodu = 'A'
                       and hesap_no in (LN_OVERLIMIT,
                                        LN_LOAN_HESAPNO,
                                        LN_PASTDUE_FIRST,
                                        LN_PASTDUE_SECOND,
                                        LN_INSTALLMENT); 
                     IF pn_eom_close THEN
                        update cbs_credit_accounts_close set status='C', close_date=Pkg_Muhasebe.banka_tarihi_bul where status='A' and customer_no=ln_musteri_no; 
                     END IF;                

                ELSIF not pn_eom_close THEN
                     insert into cbs_credit_accounts_close (customer_no, cust_name, status, totaldebt, overbalance, balance, rcode, rdesc, create_date) 
                                                     values(ln_musteri_no, r_cur.emboss_name_eng, 'A',ln_totaldebt, ln_ws_overbalance, ln_bakiye,ps_response_code,ps_response_desc,Pkg_Muhasebe.banka_tarihi_bul);   
                ELSIF pn_eom_close THEN
                
                     update cbs_credit_accounts_close
                          set totaldebt = ln_totaldebt, 
                          overbalance = ln_ws_overbalance, 
                          balance = ln_bakiye, 
                          rcode = ps_response_code,
                          rdesc = ps_response_desc,
                          update_date = Pkg_Muhasebe.banka_tarihi_bul where customer_no=ln_musteri_no and status = 'A';    
                                                             
                ELSE
                     log_at('sf_credit_accounts_close', 'ln_musteri_no => ' || ln_musteri_no || ' ln_totaldebt => ' || ln_totaldebt || ' ln_ws_overbalance => ' || ln_ws_overbalance || 'ln_bakiye => ' || ln_bakiye, ps_response_code, ld_ayin_son_is_gunu);                                               
                END IF; 
      --EOM CBS-667 04072022
          ELSE
            IF pn_eom_close THEN
              update cbs_credit_accounts_close set status='N', close_date=Pkg_Muhasebe.banka_tarihi_bul where status='A' and customer_no=ln_musteri_no;
            END IF;
          END IF;  
          
     RETURN true; 
     EXCEPTION
        WHEN NO_DATA_FOUND THEN
            log_at('sf_credit_accounts_close', 'ln_musteri_no => ' || ln_musteri_no, sqlerrm);                                         
          RETURN true; 
        WHEN OTHERS THEN
            log_at('sf_credit_accounts_close', 'ln_musteri_no => ' || ln_musteri_no, sqlerrm);                                                      
          RETURN true;            
END;
--EOM NurmilaZh CBS-197 15.07.19
 /******************************************************************************
    NAME :         INSTALLMENT_NOTIF
    Prepared By :  Bahiana Bektemir kyzy
    Date :         05.09.2022
******************************************************************************/   
PROCEDURE Installment_Notif(pn_islem_no number) IS
    
        CURSOR c_teklif IS
        SELECT S.MUSTERI_NO, S.KREDI_TURU, S.DOVIZ_KODU, S.ONERILEN_LIMIT_YP, S.KREDI_KULLANDIRIM_KODU, S.ACIKLAMA                               
        FROM  cbs_kredi_teklif_satir_islem s
        WHERE  S.TX_NO = PN_ISLEM_NO 
           AND S.KREDI_TURU IN (13,32)
        ORDER BY S.KREDI_TURU;
            
        r_teklif c_teklif%rowtype;
        
    LS_EMAIL_BODY       CLOB := '';
    PC_REF              CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    L_RECIPIENTS        CORPINT2.PKG_NOTIFICATION.RECIPIENTLIST; 
    LS_RES              VARCHAR2(3);
    LS_RET              VARCHAR2(3);
    LN_CUSTOMER_NO      NUMBER;
    LS_CUSTOMER_NAME    VARCHAR2(200);
    LS_LOAN_TYPE        CBS_KREDI_TEKLIF_SATIR_ISLEM.kredi_turu%TYPE;
    LS_TYPE_EXPL        CBS_URUN_GRUBU.tanim%TYPE;
    LS_CURRENCY         VARCHAR2 (3);
    LN_LIMIT_FC         NUMBER;
    LN_LOAN_PURPOSE     NUMBER;
    LS_PURPOSE_EXPL     CBS_KREDI_KULLANDIRIM_KODLARI.aciklama%TYPE;   
    LS_EXPLANATION      CBS_KREDI_TEKLIF_SATIR_ISLEM.aciklama%TYPE ;
    LS_EMAILS           CBS_PARAMETRE.deger%TYPE;
    LN_USER_ROLE        CBS_ROL.numara%TYPE;    
    LC_TABLE            CLOB:='';
    LN_ROWNUM           NUMBER;
    LS_ROW              VARCHAR2(32767);
    LN_I                NUMBER := 0;
    
 BEGIN
    ln_rownum := 0;
    pkg_parametre.deger('COD_EMAIL_LIST', LS_EMAILS);
    ln_user_role := PKG_BAGLAM.ROL_NUMARA;                                  
                        
    select distinct musteri_no, kredi_turu 
    into ln_customer_no, ls_loan_type 
    from cbs_kredi_teklif_satir_islem where tx_no = PN_ISLEM_NO and kredi_turu = 32; 
    
    ls_customer_name := pkg_musteri.Sf_Musteri_Adi(ln_customer_no);        
        
    if ls_loan_type = 32 and ln_user_role <> 0 then 
        lc_table := '<table style=''border-collapse:collapse;'' width=''570'' border=''0'' cellspacing=''0'' cellpadding=''0'' align=''center'' style=''border-''><tr><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Product Group</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Explanation</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Currency</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Limit FC</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Purpose of Loans</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Explanation</b></td></tr>';
        ls_email_body := ls_email_body || '{' ||
                            '"##TITLE_1##":"Customer No","##CUSTOMER_NO##":"' || ln_customer_no || '",' ||
                            '"##TITLE_2##":"Customer Name","##NAME_SURNAME##":"' || ls_customer_name || '",';     
                                
        OPEN c_teklif;                      
        loop
            FETCH c_teklif INTO r_teklif;
            EXIT WHEN c_teklif%NOTFOUND;
            ln_i := ln_i + 1;                
             
            ls_loan_type:= r_teklif.KREDI_TURU;
            ls_type_expl := pkg_kredi.Sf_Kredi_Turu_Aciklamasi_Al (r_teklif.KREDI_TURU);
            ls_currency := r_teklif.DOVIZ_KODU;
            ln_limit_fc := r_teklif.ONERILEN_LIMIT_YP;
            ln_loan_purpose := r_teklif.KREDI_KULLANDIRIM_KODU;
            ls_purpose_expl:= pkg_kredi.Sf_Kredi_Kullandir_Acikla (r_teklif.KREDI_KULLANDIRIM_KODU);
            ls_explanation := r_teklif.ACIKLAMA;                       
                    
            if mod(ln_i, 2) = 0 then
                    ls_row := '<tr><td bgcolor=''f9f9f9'' style=''padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_loan_type||'</td><td bgcolor=''f9f9f9'' style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_type_expl||'</td><td bgcolor=''f9f9f9'' style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_currency||'</td><td bgcolor=''f9f9f9'' style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_limit_fc,'FM999G999G999G999G999G999G999G999G990D00')||'</td><td bgcolor=''f9f9f9'' style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_loan_purpose) || ': ' ||ls_purpose_expl ||'</td><td bgcolor=''f9f9f9'' style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_explanation||'</td></tr>'; 
                else
                    ls_row := '<tr><td style=''padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_loan_type||'</td><td style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_type_expl||'</td><td style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_currency||'</td><td style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_limit_fc,'FM999G999G999G999G999G999G999G999G990D00')||'</td><td style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_loan_purpose) || ': ' ||ls_purpose_expl||'</td><td style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ls_explanation||'</td></tr>'; 
            end if;
                lc_table := lc_table || ls_row;
                ln_rownum := ln_rownum+1;
        end loop;                                                   
        
        lc_table := lc_table || '</table>';
        ls_email_body := ls_email_body || '"##TABLE##":"' || lc_table || '"}';
        
        if instr(LS_EMAILS, ';') > 0 then
                l_recipients := corpint2.pkg_NOTIFICATION.RecipientList();
                l_recipients:= CORPINT2.PKG_NOTIFICATION.SPLITTEXT(LS_EMAILS);
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(LS_EMAIL_BODY, 'Approved Installment Limit', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_installment',null,null);
            else
                l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1);
                l_recipients(1) := LS_EMAILS;
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(LS_EMAIL_BODY, 'Approved Installment Limit', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_installment',null,null);
        end if;
        
    end if;                  
                                        
     EXCEPTION
         WHEN OTHERS THEN
         log_at('PKG_TX1302','INSTALLMENT_NOTIF',SQLERRM ||' '|| TO_CHAR(PN_ISLEM_NO),dbms_utility.format_error_backtrace);
         NULL;
    END;
--------------------------------------------------------------
BEGIN
    pn_1302_HESAP_SUBE:= Pkg_Muhasebe.parametre_index_bul('1302_HESAP_SUBE');
    pn_1302_REFERANCE:= Pkg_Muhasebe.parametre_index_bul('1302_REFERANCE');
    pn_1302_M_ACIKLAMA:= Pkg_Muhasebe.parametre_index_bul('1302_M_ACIKLAMA');
    pn_1302_B_ACIKLAMA:= Pkg_Muhasebe.parametre_index_bul('1302_B_ACIKLAMA');
    pn_1302_P1:= Pkg_Muhasebe.parametre_index_bul('1302_P1');
    pn_1302_P2:= Pkg_Muhasebe.parametre_index_bul('1302_P2');
    pn_1302_P3:= Pkg_Muhasebe.parametre_index_bul('1302_P3');
    pn_1302_P4:= Pkg_Muhasebe.parametre_index_bul('1302_P4');
    pn_1302_P5:= Pkg_Muhasebe.parametre_index_bul('1302_P5');
    pn_1302_P6:= Pkg_Muhasebe.parametre_index_bul('1302_P6');
    pn_1302_P7:= Pkg_Muhasebe.parametre_index_bul('1302_P7');
    pn_1302_P8:= Pkg_Muhasebe.parametre_index_bul('1302_P8');
    pn_1302_P9:= Pkg_Muhasebe.parametre_index_bul('1302_P9');
    pn_1302_P10:= Pkg_Muhasebe.parametre_index_bul('1302_P10');
    pn_1302_P11:= Pkg_Muhasebe.parametre_index_bul('1302_P11');
    pn_1302_P12:= Pkg_Muhasebe.parametre_index_bul('1302_P12');
    pn_1302_P13:= Pkg_Muhasebe.parametre_index_bul('1302_P13');
    pn_1302_P14:= Pkg_Muhasebe.parametre_index_bul('1302_P14');
    pn_1302_P15:= Pkg_Muhasebe.parametre_index_bul('1302_P15');
    pn_1302_P16:= Pkg_Muhasebe.parametre_index_bul('1302_P16');
    pn_1302_TUTAR1_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR1_LC');
    pn_1302_TUTAR2_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR2_LC');
    pn_1302_TUTAR3_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR3_LC');
    pn_1302_TUTAR4_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR4_LC');
    pn_1302_TUTAR5_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR5_LC');
    pn_1302_TUTAR6_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR6_LC');
    pn_1302_TUTAR7_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR7_LC');
    pn_1302_TUTAR8_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR8_LC');
    pn_1302_TUTAR9_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR9_LC');
    pn_1302_TUTAR10_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR10_LC');
    pn_1302_TUTAR11_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR11_LC');
    pn_1302_TUTAR12_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR12_LC');
    pn_1302_TUTAR13_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR13_LC');
    pn_1302_TUTAR14_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR14_LC');
    pn_1302_TUTAR15_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR15_LC');
    pn_1302_TUTAR16_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR16_LC');
    pn_1302_TUTAR1_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR1_FC');
    pn_1302_TUTAR2_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR2_FC');
    pn_1302_TUTAR3_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR3_FC');
    pn_1302_TUTAR4_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR4_FC');
    pn_1302_TUTAR5_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR5_FC');
    pn_1302_TUTAR6_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR6_FC');
    pn_1302_TUTAR7_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR7_FC');
    pn_1302_TUTAR8_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR8_FC');
    pn_1302_TUTAR9_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR9_FC');
    pn_1302_TUTAR10_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR10_FC');
    pn_1302_TUTAR11_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR11_FC');
    pn_1302_TUTAR12_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR12_FC');
    pn_1302_TUTAR13_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR13_FC');
    pn_1302_TUTAR14_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR14_FC');
    pn_1302_TUTAR15_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR15_FC');
    pn_1302_TUTAR16_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR16_FC');
    pn_1302_DVZ_1:= Pkg_Muhasebe.parametre_index_bul('1302_DVZ_1');
    pn_1302_DVZ_2:= Pkg_Muhasebe.parametre_index_bul('1302_DVZ_2');
    pn_1302_KUR_1:= Pkg_Muhasebe.parametre_index_bul('1302_KUR_1');
    pn_1302_KUR_2:= Pkg_Muhasebe.parametre_index_bul('1302_KUR_2');
-- BOM 04.01.2017 AdiletK CQ4712 Tranches
    pn_1302_P18:= Pkg_Muhasebe.parametre_index_bul('1302_P18');
    pn_1302_P19:= Pkg_Muhasebe.parametre_index_bul('1302_P19');    
    pn_1302_TUTAR18_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR18_LC');
    pn_1302_TUTAR19_LC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR19_LC');    
    pn_1302_TUTAR18_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR18_FC');
    pn_1302_TUTAR19_FC:= Pkg_Muhasebe.parametre_index_bul('1302_TUTAR19_FC');    
-- EOM 04.01.2017 AdiletK CQ4712 Tranches
END;
/

