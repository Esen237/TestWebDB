create package body pkg_rapor is
  Function  Sf_Rpt_SiraAdi(ps_rpt_raporkod cbs_rpt_hesaptip.raporkod%type,pn_rpt_sirano cbs_rpt_hesaptip.raporkod%type) return varchar2
  is
    ls_sira_adi  	 varchar2(2000) := null;
  Begin
  	/*?lgili raporun sira numaras?na g?re tabloda tan?mlanm?? olan a??klamas?n? getirir.*/
  	select ad
	into   ls_sira_adi
	from   cbs_rpt_hesaptip
	where  raporkod =ps_rpt_raporkod
    and     sirano = pn_rpt_sirano ;

	return ls_sira_adi  ;
    Exception
	  When no_data_found Then
		return null;
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2006' ||  pkg_hata.getDelimiter || ps_rpt_raporkod || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		return null;
  End;
/**********************/

  Function  Sf_Rpt_HesapAdi(pn_rpt_sirano cbs_rpt_hesapkod.hesapno%type) return varchar2
  is
    ls_sira_adi  	 varchar2(2000) := null;
  Begin
  	/* ?lgili raporun hesap ad?n? getirir*/
  	select hesapad
	into   ls_sira_adi
	from   cbs_rpt_hesapkod
	where  hesapno = pn_rpt_sirano ;

	return ls_sira_adi  ;
	Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2007' ||  pkg_hata.getDelimiter || pn_rpt_sirano || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		return null;

  End;
/**********************/
  Function  Sf_Rpt_satirsayisi(pc_tabloadi  VARCHAR2,pd_donem date,pc_kosul VARCHAR2  ) return NUMBER
  is
    ln_satirsayisi  number(5) ;
    ls_sql      varchar(150);
    ls_format  varchar2(10);
  begin
  	 /* VErilen ko?ullara g?re raporda ka? kay?t oldu?u bilgisini getirir*/
    ls_format :='DD/MM/YYYY' ;
    ls_sql := 'Select count(*) from ' || pc_tabloadi ||
             ' where ' || 'donem = to_date(''' || to_char(pd_donem,'DD/MM/YYYY') || ''',''DD/MM/YYYY'')' ;--||  ls_format || ''')''  ;

    if pc_kosul is not null then
    ls_sql := 'Select count(*) from ' || pc_tabloadi ||
             ' where ' || 'donem = to_date(''' || to_char(pd_donem,'DD/MM/YYYY') || ''',''DD/MM/YYYY'') and ' || pc_kosul  ;--||  ls_format || ''')''  ;
	end if;


    if pc_tabloadi='CBS_RPT_UL200AS' or pc_tabloadi='CBS_RPT_UL201AS' then
	   ls_sql := 'Select count(*) from (Select distinct ulkekod,parakod from ' || pc_tabloadi ||
                 ' where ' || 'donem = to_date(''' || to_char(pd_donem,'DD/MM/YYYY') ||
			     ''',''DD/MM/YYYY''))' ;

	end if;

	execute immediate  ls_sql into  ln_satirsayisi ;

   return ln_satirsayisi;
   Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2008' ||  pkg_hata.getDelimiter || pc_tabloadi || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);


  end;
/*********************************************/

PROCEDURE sp_rpt_FR200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pc_parakod    VARCHAR2,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /* FR200AS Raporu i?in istenen formatta kay?t d?nd?r?r*/
    if  pc_rapor='BDDK' then
		Begin
		   OPEN pRetCur FOR
	       SELECT
	           a.PARAKODU ||';'|| a.SIRANO ||';'||
	           b.ad ||';'||nvl(a.BIRAYAKADAR,0) ||';'||
	           nvl(a.BIRUCAYARASI,0) ||';'|| nvl(a.UCALTIAYARASI,0) ||';'|| nvl(a.ALTIONIKIAYARASI,0) ||';'||
	           nvl(a.ONIKIAYDANFAZLA,0) ||';'|| nvl(a.TOPLAM,0)
	       FROM    CBS_RPT_FR200AS a,cbs_rpt_hesaptip b
	       WHERE   a.donem= pd_donem
	       AND     upper(a.parakodu)= upper(pc_parakod)
	       and     b.sirano = a.sirano
	       and     b.raporkod ='FR200AS'
		   order by a.sirano;
		   Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	            rpad(a.PARAKODU,3,' ') || lpad(a.SIRANO,2,' ') ||
  				case when nvl(A.BIRAYAKADAR,0) <0 then lpad(nvl(abs(A.BIRAYAKADAR),0),9,'-00000000')
				else lpad(nvl(A.BIRAYAKADAR,0),9,'000000000')end	||
  				case when nvl(A.BIRUCAYARASI,0) <0 then lpad(nvl(abs(A.BIRUCAYARASI),0),9,'-00000000')
				else lpad(nvl(A.BIRUCAYARASI,0),9,'000000000')end	||
  				case when nvl(A.UCALTIAYARASI,0) <0 then lpad(nvl(abs(A.UCALTIAYARASI),0),9,'-00000000')
				else lpad(nvl(A.UCALTIAYARASI,0),9,'000000000')end	||
  				case when nvl(A.ALTIONIKIAYARASI,0) <0 then lpad(nvl(abs(A.ALTIONIKIAYARASI),0),9,'-00000000')
				else lpad(nvl(A.ALTIONIKIAYARASI,0),9,'000000000')end	||
  				case when nvl(A.ONIKIAYDANFAZLA,0) <0 then lpad(nvl(abs(A.ONIKIAYDANFAZLA),0),9,'-00000000')
				else lpad(nvl(A.ONIKIAYDANFAZLA,0),9,'000000000')end	||
  				case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				else lpad(nvl(A.TOPLAM,0),9,'000000000')end
	        FROM    CBS_RPT_FR200AS a,cbs_rpt_dovizkod b
	        WHERE   a.donem= pd_donem
  	        --AND     upper(a.parakodu)= upper(pc_parakod)
	        AND     upper(a.parakodu)= upper(b.DOVIZKOD)
			order by b.sirano,a.sirano;

			Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_FR200AS;
/***********************************/

PROCEDURE sp_rpt_GM200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*GM200AS Raporu i?in uygun formatta kay?t d?nd?r?r */
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			  	  A.SIRANO ||';'|| b.ad ||';'|| nvl(A.TPORTTOP,0) ||';'|| nvl(A.TPGELGID,0) ||';'||
			      nvl(A.TPYILBAZ,0) ||';'|| nvl(A.YPORTTOP,0) ||';'|| nvl(A.YPGELGID,0) ||';'|| nvl(A.YPYILBAZ,0) ||';'||
				  nvl(A.TOPORTTOP,0) ||';'|| nvl(A.TOPGELGID,0) ||';'|| nvl(A.TOPYILBAZ,0)
		    FROM  CBS_RPT_GM200AS A ,cbs_rpt_hesaptip B
			WHERE   a.donem= pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='GM200AS'
			order by a.sirano;
		   Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
			OPEN pRetCur FOR
			SELECT
			lpad(A.SIRANO,2,' ') || lpad(nvl(A.TPORTTOP,0),9,' ') || lpad(nvl(A.TPGELGID,0),9,' ') ||
			trim(to_char(nvl(A.TPYILBAZ,0),'000.00')) || lpad(nvl(A.YPORTTOP,0),9,' ') || lpad(nvl(A.YPGELGID,0),9,' ') ||
			trim(to_char(nvl(A.YPYILBAZ,0),'000.00')) || lpad(nvl(A.TOPORTTOP,0),9,' ') || lpad(nvl(A.TOPGELGID,0),9,' ') ||
			trim(to_char(nvl(A.TOPYILBAZ,0),'000.00'))
			FROM  CBS_RPT_GM200AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;
		   Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    end if;

END sp_rpt_GM200AS;
/***********************************/

PROCEDURE sp_rpt_GS100AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /* GS100AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
	 -- Bu rapor sadece BDDK'ya gonderiliyor

    if  pc_rapor='BDDK' then
        OPEN pRetCur FOR
		SELECT
		   A.SIRANO ||';'|| b.ad ||';'|| nvl(A.TUTAR,0)
		FROM   CBS_RPT_GS100AS A , cbs_rpt_hesaptip B
		WHERE   a.donem= pd_donem
		and     b.sirano = a.sirano
		and     b.raporkod ='GS100AS'
		order by a.sirano;
    end if;

    Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_GS100AS;
/***********************************/

PROCEDURE sp_rpt_EK100US
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*EK100US Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			    A.SIRANO ||';'|| nvl(trim(A.KIYMETTURU),' ') ||';'|| nvl(A.KOD,0) ||';'||
				nvl(A.SOHISSE,0) ||';'||
				nvl(to_char(A.GIRISTARIHI,'DD'),' ') ||';'||
				nvl(to_char(A.GIRISTARIHI,'MM'),' ') ||';'||
				nvl(to_char(A.GIRISTARIHI,'YYYY'),' ') ||';'||
				nvl(A.DEFTERDEGERI,0)||';'||
				nvl(A.DEGDUSKARSILIGI,0) ||';'|| nvl(A.NETDEGER,0) ||';'|| nvl(A.PIYASADEGERI,0)
	        FROM    CBS_RPT_EK100US A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			    lpad(A.SIRANO,5,' ') || rpad(nvl(trim(A.KIYMETTURU),' '),50,' ') || nvl(A.KOD,0) ||
				trim(to_char(nvl(A.SOHISSE,0),'000.00')) || lpad(nvl(to_char(A.GIRISTARIHI,'DD-MM-YYYY'),' '),10,' ')|| lpad(nvl(A.DEFTERDEGERI,0),9,' ')||
				lpad(nvl(A.DEGDUSKARSILIGI,0),9,' ') || lpad(nvl(A.NETDEGER,0),9,' ')|| lpad(nvl(A.PIYASADEGERI,0)	,9,' ')
	        FROM    CBS_RPT_EK100US A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

		   Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_EK100US;
/***********************************/

PROCEDURE sp_rpt_FK100US
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*FK100US Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				to_char(a.DONEM,'MM/YYYY') ||';'|| A.SIRANO ||';'|| nvl(trim(A.TARAFLAR),' ') ||';'|| nvl(A.RISKKOD,' ') ||';'||
				nvl(A.VERGINO,' ') ||';'|| nvl(A.ULKEKOD,' ') ||';'|| nvl(A.ISLEMTUR,0) ||';'|| nvl(A.PARAKOD,' ') ||';'||
				nvl(to_char(A.SOZLESMETAR,'DD'),' ') ||';'||nvl(to_char(A.SOZLESMETAR,'MM'),' ') ||';'||nvl(to_char(A.SOZLESMETAR,'YYYY'),' ') ||';'||
				nvl(to_char(A.VADESONUTAR,'DD'),' ')||';'||nvl(to_char(A.VADESONUTAR,'MM'),' ')||';'||nvl(to_char(A.VADESONUTAR,'YYYY'),' ')||';'||
				nvl(A.SOZANATUT,0) ||';'|| nvl(A.SOZGGTUT,0) ||';'|| nvl(A.CYTEOANATUT,0) ||';'|| nvl(A.CYTEOGGTUT,0) ||';'|| nvl(A.FKALBORC,0)
				||';'|| nvl(A.KEFKALBORC,0)
			FROM	CBS_RPT_FK100US A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				lpad(A.SIRANO,5,' ') || rpad(nvl(trim(A.TARAFLAR),' '),50,' ') || lpad(nvl(A.RISKKOD,' '),6,' ') ||
				rpad(nvl(A.VERGINO,' '),12,' ') || lpad(nvl(A.ULKEKOD,' '),2,' ') || lpad(nvl(A.ISLEMTUR,0),1,' ') ||
				lpad(nvl(A.PARAKOD,' '),3,' ') || lpad(nvl(to_char(A.SOZLESMETAR,'DD-MM-YYYY'),' '),10,' ') ||
				lpad(nvl(to_char(A.VADESONUTAR,'DD-MM-YYYY'),' '),10,' ') || lpad(nvl(A.SOZANATUT,0),9,' ') ||
				lpad(nvl(A.SOZGGTUT,0),9,' ') || lpad(nvl(A.CYTEOANATUT,0),9,' ') || lpad(nvl(A.CYTEOGGTUT,0),9,' ') ||
				lpad(nvl(A.FKALBORC,0),9,' ')||lpad(nvl(A.KEFKALBORC,0),9,' ')
			FROM	CBS_RPT_FK100US A
	        WHERE   a.donem= pd_donem
			order by a.sirano;
 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    end if;

END sp_rpt_FK100US;
/***********************************/

PROCEDURE sp_rpt_EM100AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*EM100AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
			SELECT
			    A.SIRANO||';'||nvl(A.HESAPKODU,' ')||';'||nvl(trim(A.HESAPADI),' ')
				||';'|| nvl(A.YITESKILAT,0) ||';'||nvl(A.YDSUBELER,0)||';'||nvl(A.GENELKONS,0)
			FROM   CBS_RPT_EM100AS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
			SELECT
			    decode(a.sirano ,1,rpad('S1',7,' '),2,rpad('S2',7,' '),3,rpad('S3',7,' '),rpad(nvl(A.HESAPKODU,' '),7,' ')) ||
  				case when nvl(A.YITESKILAT,0) <0 then lpad(nvl(abs(A.YITESKILAT),0),9,'-00000000')
				else lpad(nvl(A.YITESKILAT,0),9,'000000000')end	||
  				case when nvl(A.YDSUBELER,0) <0 then lpad(nvl(abs(A.YDSUBELER),0),9,'-00000000')
				else lpad(nvl(A.YDSUBELER,0),9,'000000000')end	||
  				case when nvl(A.GENELKONS,0) <0 then lpad(nvl(abs(A.GENELKONS),0),9,'-00000000')
				else lpad(nvl(A.GENELKONS,0),9,'000000000')end
			FROM   CBS_RPT_EM100AS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_EM100AS;
/***********************************/

PROCEDURE sp_rpt_HS200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*HS200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
			SELECT
			   A.SIRANO ||';'|| nvl(trim(A.HISSEDARLAR),' ') ||';'|| nvl(A.HISULKEKODU,' ') ||';'||
			   nvl(A.VERGINO,' ') ||';'|| nvl(A.SERODENMEMIS,0) ||';'|| nvl(A.SERODENMIS,0) ||';'||
			   nvl(A.TOPLAM,0) ||';'|| trim(to_char(nvl(A.HISORNOSG,0),'000.00')) ||';'||
			   trim(to_char(nvl(A.HISORNTSG,0),'000.00'))
			FROM   CBS_RPT_HS200AS A
	        WHERE   a.donem= pd_donem
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
			SELECT
			   lpad(A.SIRANO,5,' ') || rpad(nvl(trim(A.HISSEDARLAR),' '),50,' ') || lpad(nvl(A.HISULKEKODU,' '),2,' ') ||
			   rpad(nvl(A.VERGINO,' '),12,' ') ||
  				case when nvl(A.SERODENMEMIS,0) <0 then lpad(nvl(abs(A.SERODENMEMIS),0),9,'-00000000')
				else lpad(nvl(A.SERODENMEMIS,0),9,'000000000')end	||
  				case when nvl(A.SERODENMIS,0) <0 then lpad(nvl(abs(A.SERODENMIS),0),9,'-00000000')
				else lpad(nvl(A.SERODENMIS,0),9,'000000000')end	||
  				case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				else lpad(nvl(A.TOPLAM,0),9,'000000000')end	||
			   trim(to_char(nvl(A.HISORNOSG,0),'000.00')) || trim(to_char(nvl(A.HISORNTSG,0),'000.00'))
			FROM   CBS_RPT_HS200AS A
	        WHERE   a.donem= pd_donem
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    end if;

END sp_rpt_HS200AS;
/***********************************/

PROCEDURE sp_rpt_KA200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KA200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  A.SIRANO ||';'|| b.ad ||';'|| nvl(A.DBBAKIYE,0) ||';'|| nvl(A.AKTSILODEME,0) ||';'|| nvl(A.PROVHAR,0)
				  ||';'|| nvl(A.TAHDIG,0) ||';'|| nvl(A.GYIHAR,0) ||';'|| nvl(A.DSIHKAR,0) ||';'|| nvl(A.CDSPROV,0)
		    FROM  CBS_RPT_KA200AS A	 ,cbs_rpt_hesaptip B
			WHERE   a.donem= pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='KA200AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
   			    lpad(A.SIRANO,2,' ')||
  				case when nvl(A.DBBAKIYE,0) <0 then lpad(nvl(abs(A.DBBAKIYE),0),9,'-00000000')
				else lpad(nvl(A.DBBAKIYE,0),9,'000000000')end	||
  				case when nvl(A.AKTSILODEME,0) <0 then lpad(nvl(abs(A.AKTSILODEME),0),9,'-00000000')
				else lpad(nvl(A.AKTSILODEME,0),9,'000000000')end	||
  				case when nvl(A.PROVHAR,0) <0 then lpad(nvl(abs(A.PROVHAR),0),9,'-00000000')
				else lpad(nvl(A.PROVHAR,0),9,'000000000')end	||
  				case when nvl(A.TAHDIG,0) <0 then lpad(nvl(abs(A.TAHDIG),0),9,'-00000000')
				else lpad(nvl(A.TAHDIG,0),9,'000000000')end	||
  				case when nvl(A.GYIHAR,0) <0 then lpad(nvl(abs(A.GYIHAR),0),9,'-00000000')
				else lpad(nvl(A.GYIHAR,0),9,'000000000')end	||
  				case when nvl(A.DSIHKAR,0) <0 then lpad(nvl(abs(A.DSIHKAR),0),9,'-00000000')
				else lpad(nvl(A.DSIHKAR,0),9,'000000000')end	||
  				case when nvl(A.CDSPROV,0) <0 then lpad(nvl(abs(A.CDSPROV),0),9,'-00000000')
				else lpad(nvl(A.CDSPROV,0),9,'000000000')end
		    FROM  CBS_RPT_KA200AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_KA200AS;
/***********************************/

PROCEDURE sp_rpt_KR100AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KR100AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  A.SIRANO||';'||b.ad ||';'|| nvl(A.MUSTERISAYI,0)||';'||nvl(A.KVTP,0)||';'||nvl(A.KVYP,0)
				  ||';'||nvl(A.OUVTP,0)||';'||nvl(A.OUVYP,0)||';'||nvl(A.KAMU,0)||';'||nvl(A.OZEL,0)||';'||nvl(A.YI,0)
				  ||';'||nvl(A.YD,0)
		    FROM  CBS_RPT_KR100AS A	 ,cbs_rpt_hesaptip B
			WHERE   a.donem= pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='KR100AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  lpad(A.SIRANO,2,' ')||lpad( nvl(A.MUSTERISAYI,0),9,' ')||lpad(nvl(A.KVTP,0),9,' ')||lpad(nvl(A.KVYP,0),9,' ')||
				  lpad(nvl(A.OUVTP,0),9,' ')||lpad(nvl(A.OUVYP,0),9,' ')||lpad(nvl(A.KAMU,0),9,' ')||lpad(nvl(A.OZEL,0),9,' ')||
				  lpad(nvl(A.YI,0),9,' ')||lpad(nvl(A.YD,0),9,' ')
		    FROM  CBS_RPT_KR100AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_KR100AS;

/********************************/
PROCEDURE sp_rpt_KR203AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KR203AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  A.SIRANO||';'||b.ad ||';'||nvl(A.KVTP,0)||';'||nvl(A.KVYP,0)||';'||nvl(A.OUVTP,0)
				  ||';'||nvl(A.OUVYP,0)||';'||nvl(A.TOPTP,0)||';'||nvl(A.TOPYP,0)||';'||nvl(A.AKTP,0)||';'||nvl(A.AKYP,0)
				  ||';'||nvl(A.REESTP,0)||';'||nvl(A.REESYP,0)
		    FROM  CBS_RPT_KR203AS A	 ,cbs_rpt_hesaptip B
			WHERE   a.donem= pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='KR203AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  lpad(A.SIRANO,2,' ')|| lpad(nvl(A.KVTP,0),9,' ')||lpad(nvl(A.KVYP,0),9,' ')||lpad(nvl(A.OUVTP,0),9,' ')
				  ||lpad(nvl(A.OUVYP,0),9,' ')||lpad(nvl(A.TOPTP,0),9,' ')||lpad(nvl(A.TOPYP,0),9,' ')||lpad(nvl(A.AKTP,0),9,' ')||lpad(nvl(A.AKYP,0),9,' ')
				  ||lpad(nvl(A.REESTP,0),9,' ')||lpad(nvl(A.REESYP,0),9,' ')
		    FROM  CBS_RPT_KR203AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    end if;

END sp_rpt_KR203AS;

/********************************/

PROCEDURE sp_rpt_KR206AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KR206AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			   A.SIRANO||';'||b.ad ||';'||nvl(A.DBBAKIYE,0)||';'||nvl(A.AKTSIL,0)||';'||nvl(A.DITAHSILAT,0)||';'||
			   nvl(A.DIILAVE,0)||';'||nvl(A.GRUPHAR,0)||';'||nvl(A.DSBAKIYE,0)||';'||nvl(A.TEMTUT,0)||';'||nvl(A.AYOZKAR,0)
		    FROM  CBS_RPT_KR206AS A	 ,cbs_rpt_hesaptip B
			WHERE   a.donem= pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='KR206AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			    lpad(A.SIRANO,2,' ')||
  				case when nvl(A.DBBAKIYE,0) <0 then lpad(nvl(abs(A.DBBAKIYE),0),9,'-00000000')
				else lpad(nvl(A.DBBAKIYE,0),9,'000000000')end	||
  				case when nvl(A.AKTSIL,0) <0 then lpad(nvl(abs(A.AKTSIL),0),9,'-00000000')
				else lpad(nvl(A.AKTSIL,0),9,'000000000')end	||
  				case when nvl(A.DITAHSILAT,0) <0 then lpad(nvl(abs(A.DITAHSILAT),0),9,'-00000000')
				else lpad(nvl(A.DITAHSILAT,0),9,'000000000')end	||
  				case when nvl(A.DIILAVE,0) <0 then lpad(nvl(abs(A.DIILAVE),0),9,'-00000000')
				else lpad(nvl(A.DIILAVE,0),9,'000000000')end	||
  				case when nvl(A.GRUPHAR,0) <0 then lpad(nvl(abs(A.GRUPHAR),0),9,'-00000000')
				else lpad(nvl(A.GRUPHAR,0),9,'000000000')end	||
  				case when nvl(A.DSBAKIYE,0) <0 then lpad(nvl(abs(A.DSBAKIYE),0),9,'-00000000')
				else lpad(nvl(A.DSBAKIYE,0),9,'000000000')end	||
  				case when nvl(A.TEMTUT,0) <0 then lpad(nvl(abs(A.TEMTUT),0),9,'-00000000')
				else lpad(nvl(A.TEMTUT,0),9,'000000000')end	||
  				case when nvl(A.AYOZKAR,0) <0 then lpad(nvl(abs(A.AYOZKAR),0),9,'-00000000')
				else lpad(nvl(A.AYOZKAR,0),9,'000000000')end
		    FROM  CBS_RPT_KR206AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_KR206AS;

/********************************/
PROCEDURE sp_rpt_KS100AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KS100AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
	 -- Bu rapor sadece BDDK'ya gonderiliyor

    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
			SELECT
			   A.SIRANO||';'||nvl(trim(A.MUSTERIADI),' ')||';'||nvl(trim(A.RISKGRUBU),' ')||';'||
			   nvl(trim(A.ISLEMTUR),' ')||';'||nvl(trim(A.ISTISNA),' ')||';'||nvl(A.DIKKATORN,0)||';'||
			   nvl(A.ISTISNATUT,0)||';'||nvl(A.DIKKATTUT,0)||';'||nvl(A.OZKAYNAKTUT,0)
			FROM   CBS_RPT_KS100AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;


END sp_rpt_KS100AS;
/***********************************/

PROCEDURE sp_rpt_LR200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pc_parakod    VARCHAR2,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*LR200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	           a.SIRANO ||';'|| b.ad ||';'||nvl(a.BIRAYAKADAR,0) ||';'||
	           nvl(a.BIRUCAYARASI,0) ||';'|| nvl(a.UCALTIAYARASI,0) ||';'|| nvl(a.ALTIONIKIAYARASI,0) ||';'||
	           nvl(a.ONIKIAYDANFAZLA,0) ||';'|| nvl(a.TOPLAM,0)
	        FROM    CBS_RPT_LR200AS a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        AND     upper(a.parakodu)= upper(pc_parakod)
	        and     b.sirano = a.sirano
	        and     b.raporkod ='LR200AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	           rpad(a.PARAKODU,3,' ') || lpad(a.SIRANO,2,' ') || lpad(nvl(a.BIRAYAKADAR,0),9,' ') ||
	           lpad(nvl(a.BIRUCAYARASI,0),9,' ') || lpad(nvl(a.UCALTIAYARASI,0),9,' ') ||
	           lpad(nvl(a.ALTIONIKIAYARASI,0),9,' ') || lpad(nvl(a.ONIKIAYDANFAZLA,0),9,' ') || lpad(nvl(a.TOPLAM,0),9,' ')
	        FROM    CBS_RPT_LR200AS a,cbs_rpt_dovizkod b
	        WHERE   donem= pd_donem
	        --AND     upper(parakodu)= upper(pc_parakod)
			AND     upper(a.parakodu)= upper(b.DOVIZKOD)
			order by  b.sirano,a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_LR200AS;
/***********************************/

PROCEDURE sp_rpt_KR201AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KR201AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			      A.SIRANO||';'|| b.ad ||';'||nvl(A.TPTOPKR,0)||';'||nvl(A.TPMUSSAY,0)||';'||nvl(A.YPTOPKR,0)
				  ||';'||nvl(A.YPMUSSAY,0)||';'||nvl(A.TOPKRTUT,0)||';'||nvl(A.TOPMUSSAY,0)
		    FROM  CBS_RPT_KR201AS A	 ,cbs_rpt_hesaptip B
			WHERE   a.donem= pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='KR201AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			      lpad(A.SIRANO,1,' ')|| lpad(nvl(A.TPTOPKR,0),9,' ')|| lpad(nvl(A.TPMUSSAY,0),9,' ')||
				  lpad(nvl(A.YPTOPKR,0),9,' ') || lpad(nvl(A.YPMUSSAY,0),9,' ') || lpad(nvl(A.TOPKRTUT,0),9,' ')|| lpad(nvl(A.TOPMUSSAY,0),9,' ')
		    FROM  CBS_RPT_KR201AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_KR201AS;

/********************************/

PROCEDURE sp_rpt_KR202AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KR202AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  A.SIRANO||';'||nvl(trim(A.SIRAADI),' ')||';'||nvl(A.VERGINO,' ')||';'|| nvl(A.RISKGRUBU,' ')||';'||
				  nvl(A.ULKEKODU,' ')||';'||nvl(A.SUBEKODU,0)||';'||nvl(A.HESAPKOD,' ')||';'||nvl(A.RISKAGIRLIGI,0)||';'||
				  nvl(A.FINKOD,' ')||';'||
				  nvl(to_char(A.ACILISTAR,'DD'),' ')||';'||nvl(to_char(A.ACILISTAR,'MM'),' ')||';'||nvl(to_char(A.ACILISTAR,'YYYY'),' ')||';'||
				  nvl(to_char(A.ORJVADETAR,'DD'),' ')||';'||nvl(to_char(A.ORJVADETAR,'MM'),' ')||';'||nvl(to_char(A.ORJVADETAR,'YYYY'),' ')||';'||
				  nvl(to_char(A.TEMDITVADETAR,'DD'),' ')||';'||nvl(to_char(A.TEMDITVADETAR,'MM'),' ')||';'||nvl(to_char(A.TEMDITVADETAR,'YYYY'),' ')||';'||
				  nvl(to_char(A.TAKSITTAR,'DD'),' ')||';'||nvl(to_char(A.TAKSITTAR,'MM'),' ')||';'||nvl(to_char(A.TAKSITTAR,'YYYY'),' ')||';'||
				  nvl(to_char(A.TAKIPTAR,'DD'),' ')||';'||nvl(to_char(A.TAKIPTAR,'MM'),' ')||';'||nvl(to_char(A.TAKIPTAR,'YYYY'),' ')||';'||
				  trim(to_char(nvl(A.FAIZORN,0),'000.00'))||';'||nvl(A.PARAKOD,' ')||';'||
				  nvl(A.ENDEKSKOD,' ')||';'||nvl(A.TEMTUT1,0)||';'||nvl(A.TEMTUT2,0)||';'||nvl(A.TEMTUT3,0)||';'||
				  nvl(A.TEMTUT4,0)||';'||nvl(A.ANAPARA,0)||';'||nvl(A.REESKONT,0)||';'||nvl(A.TAHAKKUK,0)||';'||nvl(A.AYRILANKARS,0)
		    FROM  CBS_RPT_KR202AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
			SELECT
				  lpad(A.SIRANO,5,' ')||rpad(nvl(trim(A.SIRAADI),' '),50,' ')||rpad(nvl(A.VERGINO,' '),12,' ')||
				  rpad(nvl(A.RISKGRUBU,' '),6,' ')||rpad(nvl(A.ULKEKODU,' '),2,' ')||lpad(nvl(A.SUBEKODU,0),5,' ')||
				  rpad(nvl(A.HESAPKOD,' '),6,' ')||trim(to_char(nvl(A.RISKAGIRLIGI,0),'0000'))||rpad(nvl(A.FINKOD,' '),3,' ')||
				  lpad(nvl(to_char(A.ACILISTAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(to_char(A.ORJVADETAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(to_char(A.TEMDITVADETAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(to_char(A.TAKSITTAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(to_char(A.TAKIPTAR,'DD-MM-YYYY'),' '),10,' ')||
				  trim(to_char(nvl(A.FAIZORN,0),'000.00'))||
				  rpad(nvl(A.PARAKOD,' '),3,' ')||rpad(nvl(A.ENDEKSKOD,' '),1,' ')||lpad(nvl(A.TEMTUT1,0),9,' ')||
				  lpad(nvl(A.TEMTUT2,0),9,' ')||lpad(nvl(A.TEMTUT3,0),9,' ')||lpad(nvl(A.TEMTUT4,0),9,' ')||lpad(nvl(A.ANAPARA,0),9,' ')||
				  lpad(nvl(A.REESKONT,0),9,' ')||lpad(nvl(A.TAHAKKUK,0),9,' ')||lpad(nvl(A.AYRILANKARS,0),9,' ')
		    FROM  CBS_RPT_KR202AS A
			WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_KR202AS;

/********************************/

PROCEDURE sp_rpt_IS200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*IS200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
			SELECT
			   A.SIRANO ||';'|| nvl(A.ISTIRAKLER,' ') ||';'|| nvl(A.ULKEKODU,' ') ||';'|| nvl(A.PARAKODU,' ') ||';'||
			   nvl(A.VERGINO,' ') ||';'|| nvl(A.RISKGRUBU,' ') ||';'|| nvl(A.ORTKOD,' ') ||';'|| nvl(A.SEKTORKOD,' ') ||';'||
			   nvl(A.DBDEGERI,0) ||';'|| nvl(A.ALISLAR,0) ||';'|| nvl(A.RUCHANHAK,0) ||';'|| nvl(A.SATISLAR,0) ||';'||
			   nvl(A.YDARTISI,0) ||';'|| nvl(A.DEGAZKAR,0) ||';'|| nvl(A.DSDEGERI,0) ||';'|| nvl(A.DSMALBED,0) ||';'||
			   nvl(A.SERMTAAH,0) ||';'|| trim(to_char(nvl(A.DSSERMKATPAY,0),'000.00')) ||';'|| nvl(A.SABTEMENDEG,0) ||';'|| nvl(A.DIGALACAK,0)
			FROM   CBS_RPT_IS200AS A
	        WHERE   a.donem= pd_donem
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
			SELECT
			   lpad(A.SIRANO,5,' ') || rpad(nvl(A.ISTIRAKLER,' '),50,' ') || lpad(nvl(A.ULKEKODU,' '),2,' ') ||
			   lpad(nvl(A.PARAKODU,' '),3,' ') || rpad(nvl(A.VERGINO,' '),12,' ') || rpad(nvl(A.RISKGRUBU,' '),6,' ')||
			    rpad(nvl(A.ORTKOD,' '),1,' ') || rpad(nvl(A.SEKTORKOD,' '),2,' ') ||
  				case when nvl(A.DBDEGERI,0) <0 then lpad(nvl(abs(A.DBDEGERI),0),9,'-00000000')
				else lpad(nvl(A.DBDEGERI,0),9,'000000000')end	||
  				case when nvl(A.ALISLAR,0) <0 then lpad(nvl(abs(A.ALISLAR),0),9,'-00000000')
				else lpad(nvl(A.ALISLAR,0),9,'000000000')end	||
  				case when nvl(A.RUCHANHAK,0) <0 then lpad(nvl(abs(A.RUCHANHAK),0),9,'-00000000')
				else lpad(nvl(A.RUCHANHAK,0),9,'000000000')end	||
  				case when nvl(A.SATISLAR,0) <0 then lpad(nvl(abs(A.SATISLAR),0),9,'-00000000')
				else lpad(nvl(A.SATISLAR,0),9,'000000000')end	||
  				case when nvl(A.YDARTISI,0) <0 then lpad(nvl(abs(A.YDARTISI),0),9,'-00000000')
				else lpad(nvl(A.YDARTISI,0),9,'000000000')end	||
  				case when nvl(A.DEGAZKAR,0) <0 then lpad(nvl(abs(A.DEGAZKAR),0),9,'-00000000')
				else lpad(nvl(A.DEGAZKAR,0),9,'000000000')end	||
  				case when nvl(A.DSDEGERI,0) <0 then lpad(nvl(abs(A.DSDEGERI),0),9,'-00000000')
				else lpad(nvl(A.DSDEGERI,0),9,'000000000')end	||
  				case when nvl(A.DSMALBED,0) <0 then lpad(nvl(abs(A.DSMALBED),0),9,'-00000000')
				else lpad(nvl(A.DSMALBED,0),9,'000000000')end	||
  				case when nvl(A.SERMTAAH,0) <0 then lpad(nvl(abs(A.SERMTAAH),0),9,'-00000000')
				else lpad(nvl(A.SERMTAAH,0),9,'000000000')end	||
			    trim(to_char(nvl(A.DSSERMKATPAY,0),'000.00'))||
  				case when nvl(A.SABTEMENDEG,0) <0 then lpad(nvl(abs(A.SABTEMENDEG),0),9,'-00000000')
				else lpad(nvl(A.SABTEMENDEG,0),9,'000000000')end	||
  				case when nvl(A.DIGALACAK,0) <0 then lpad(nvl(abs(A.DIGALACAK),0),9,'-00000000')
				else lpad(nvl(A.DIGALACAK,0),9,'000000000')end
			FROM   CBS_RPT_IS200AS A
	        WHERE   a.donem= pd_donem
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_IS200AS;
/***********************************/


PROCEDURE sp_rpt_BD101AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType  IS REF CURSOR;
  p_err                 NUMBER(10):= 0;
BEGIN
	 /*BD101AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	        A.SIRANO ||';'|| trim(A.MUSTERIADI) ||';'|| A.OFFSHORE ||';'|| A.RISKKODU ||';'|| A.ISLEMKODU
	        ||';'|| A.ULKEKODU ||';'|| A.PARAKODU ||';'|| A.ORJPARA ||';'|| A.TRLKARSILIGI ||';'|| A.REFFAIZORANI
	        ||';'|| trim(to_char(nvl(A.FAIZORANI,0),'000.00'))  ||';'|| to_char(A.ISLEMTARIHI,'DD') ||';'||
			to_char(A.ISLEMTARIHI,'MM') ||';'|| to_char(A.ISLEMTARIHI,'YYYY') ||';'||
	        to_char(A.VADETARIHI,'DD') ||';'|| to_char(A.VADETARIHI,'MM') ||';'|| to_char(A.VADETARIHI,'YYYY') ||';'||
	        A.KARSIPARAKODU ||';'|| A.SPOTKUR ||';'|| A.FORWARDKUR ||';'|| A.DEPOZIT ||';'|| A.REESKONT
	        FROM    CBS_RPT_BD101AS A
	        WHERE   a.donem= pd_donem ;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
    	Begin
	        OPEN pRetCur FOR
	        SELECT
	        lpad(nvl(A.SIRANO,0),5,' ') || rpad(nvl(trim(A.MUSTERIADI),' '),50,' ') ||lpad(nvl(A.OFFSHORE,' '),2,' ') ||
	        lpad(nvl(A.RISKKODU,' '),6,' ') || lpad(nvl(A.ISLEMKODU,' '),4,' ') || lpad(nvl(A.ULKEKODU,' '),2,' ') ||
	        lpad(nvl(A.PARAKODU,' '),3,' ') ||lpad(nvl(A.ORJPARA,0),9,' ') ||lpad(nvl(A.TRLKARSILIGI,0),9,' ') ||
	        lpad(nvl(A.REFFAIZORANI,' '),15,' ') ||trim(to_char(nvl(A.FAIZORANI,0),'000.00')) ||lpad(nvl(to_char(A.ISLEMTARIHI,'DD-MM-YYYY'),' '),10,' ')||
	        lpad(nvl(to_char(A.VADETARIHI,'DD-MM-YYYY'),' '),10,' ') ||
	        lpad(nvl(A.KARSIPARAKODU,' '),3,' ') || trim(to_char(nvl(A.SPOTKUR,0),'000000000.0000')) ||
			trim(to_char(nvl(A.FORWARDKUR,0),'000000000.0000')) ||
	        lpad(nvl(A.DEPOZIT,0),9,' ') || lpad(nvl(A.REESKONT,0),9,' ')
	        FROM    CBS_RPT_BD101AS A
	        WHERE   a.donem= pd_donem ;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;
END sp_rpt_BD101AS;
/***********************************/


PROCEDURE sp_rpt_BL200GS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --BL200GS Raporu i?in uygun formatta kay?t d?nd?r?l?r*

    --BU RAPORDA SADECE BDDK'YA DOSYA ?IKILIYOR

     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	           a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||  nvl(A.YP,0)
			FROM    CBS_RPT_BL200GS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='BL200GS'
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_BL200GS;


/***********************************/

PROCEDURE sp_rpt_BL201GS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --BL201GS Raporu i?in uygun formatta kay?t d?nd?r?l?r*

    --BU RAPORDA SADECE BDDK'YA DOSYA ?IKILIYOR

     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	           a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||  nvl(A.YP,0)
			FROM    CBS_RPT_BL201GS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='BL201GS'
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_BL201GS;
/********************************/

PROCEDURE sp_rpt_BL200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --BL200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*
     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	        	  a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||nvl(A.YP,0)||';'||
				  nvl(A.TOPLAM,0)
			FROM    CBS_RPT_BL200AS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='BL200AS'
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	        	 lpad(A.SIRANO,2,' ') ||
  				 case when nvl(A.TP,0) <0 then lpad(nvl(abs(A.TP),0),9,'-00000000')
				 else lpad(nvl(A.TP,0),9,'000000000')end	||
  				 case when nvl(A.YP,0) <0 then lpad(nvl(abs(A.YP),0),9,'-00000000')
				 else lpad(nvl(A.YP,0),9,'000000000')end	||
  				 case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				 else lpad(nvl(A.TOPLAM,0),9,'000000000')end
			FROM    CBS_RPT_BL200AS A
	        WHERE   A.donem   = pd_donem
			ORDER BY a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;

    end if;

END sp_rpt_BL200AS;

/**********************************/

PROCEDURE sp_rpt_BL201AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --BL201AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*
     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	        	  a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||nvl(A.YP,0)||';'||
				  nvl(A.TOPLAM,0)
			FROM    CBS_RPT_BL201AS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='BL200AS' --200 olmas? ?a??rtmas?n.De?erler ayn?
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	        	 lpad(A.SIRANO,2,' ') ||
  				 case when nvl(A.TP,0) <0 then lpad(nvl(abs(A.TP),0),9,'-00000000')
				 else lpad(nvl(A.TP,0),9,'000000000')end	||
  				 case when nvl(A.YP,0) <0 then lpad(nvl(abs(A.YP),0),9,'-00000000')
				 else lpad(nvl(A.YP,0),9,'000000000')end	||
  				 case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				 else lpad(nvl(A.TOPLAM,0),9,'000000000')end
			FROM    CBS_RPT_BL201AS A
	        WHERE   A.donem   = pd_donem
			ORDER BY a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;

    end if;

END sp_rpt_BL201AS;

/**********************************/


PROCEDURE sp_rpt_BL202AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pn_subekodu	NUMBER,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --BL202AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*
     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	        	  a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||nvl(A.YP,0)||';'||
				  nvl(A.TOPLAM,0)
			FROM    CBS_RPT_BL202AS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and		a.subekodu = pn_subekodu
			and     b.sirano = a.sirano
			and     b.raporkod ='BL200AS' --200 olmas? ?a??rtmas?n.De?erler ayn?
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	        	 lpad( a.subekodu,5,' ') || lpad(A.SIRANO,2,' ') ||
  				 case when nvl(A.TP,0) <0 then lpad(nvl(abs(A.TP),0),9,'-00000000')
				 else lpad(nvl(A.TP,0),9,'000000000')end	||
  				 case when nvl(A.YP,0) <0 then lpad(nvl(abs(A.YP),0),9,'-00000000')
				 else lpad(nvl(A.YP,0),9,'000000000')end	||
  				 case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				 else lpad(nvl(A.TOPLAM,0),9,'000000000')end
			FROM    CBS_RPT_BL202AS A
	        WHERE   A.donem   = pd_donem
			and		a.subekodu = pn_subekodu
			ORDER BY a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;

    end if;

END sp_rpt_BL202AS;

/**********************************/

PROCEDURE sp_rpt_MB100AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MB100AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	  		   A.SIRANO ||';'|| nvl(b.ad,' ') ||';'|| nvl(trim(A.ACIKLAMA),' ')
	        FROM    CBS_RPT_MB100AS a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        and     b.sirano = a.sirano
	        and     b.raporkod ='MB100AS'
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;

    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	  		   lpad(A.SIRANO,2,' ') || rpad(nvl(trim(A.ACIKLAMA),' '),50,' ')
	        FROM    CBS_RPT_MB100AS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;
END sp_rpt_MB100AS;
/***********************************/

PROCEDURE sp_rpt_MB101AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
    /*MB101AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  nvl(A.DVZCINSI,' ') ||';'||  nvl(A.DVZALIS,0) ||';'||  nvl(A.DVZSATIS,0)
	        FROM    CBS_RPT_MB101AS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  lpad(A.SIRANO,3,' ') || lpad(nvl(A.DVZCINSI,' '),3,' ') ||
				  lpad(nvl(A.DVZALIS,0),9,' ') || lpad(nvl(A.DVZSATIS,0),9,' ')
				  || lpad(' ',7,' ')
	        FROM    CBS_RPT_MB101AS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_MB101AS;
/***********************************/


PROCEDURE sp_rpt_MD200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MD200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  A.SIRANO||';'||nvl(b.ad,' ') ||';'|| nvl(A.DSMBTP,0)||';'||nvl(A.DSMBYP,0)||';'||
				  nvl(A.MDDATP,0) ||';'||nvl(A.MDDAYP,0)||';'||nvl(A.ADAKTP,0)||';'||nvl(A.ADAKYP,0)||';'||
				  nvl(A.BILDEGTP,0)||';'||nvl(A.BILDEGYP,0)||';'||nvl(A.REESTUTTP,0)||';'||nvl(A.REESTUTYP,0)||';'||
				  nvl(A.CPDEGTP,0)||';'||nvl(A.CPDEGYP,0)||';'||nvl(A.DSYDTP,0)||';'||nvl(A.DSYDYP,0)
	        FROM    CBS_RPT_MD200AS a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        and     b.sirano = a.sirano
	        and     b.raporkod ='MD200AS'
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  lpad(A.SIRANO,2,' ')||lpad(nvl(A.DSMBTP,0),9,' ')||lpad(nvl(A.DSMBYP,0),9,' ')||
				  lpad(nvl(A.MDDATP,0),9,' ') ||lpad(nvl(A.MDDAYP,0),9,' ')||lpad(nvl(A.ADAKTP,0),9,' ')||lpad(nvl(A.ADAKYP,0),9,' ')||
				  lpad(nvl(A.BILDEGTP,0),9,' ')||lpad(nvl(A.BILDEGYP,0),9,' ')||lpad(nvl(A.REESTUTTP,0),9,' ')||lpad(nvl(A.REESTUTYP,0),9,' ')||
				  lpad(nvl(A.CPDEGTP,0),9,' ')||lpad(nvl(A.CPDEGYP,0),9,' ')||lpad(nvl(A.DSYDTP,0),9,' ')||lpad(nvl(A.DSYDYP,0),9,' ')
	        FROM    CBS_RPT_MD200AS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End ;
    end if;

END sp_rpt_MD200AS;
/***********************************/

PROCEDURE sp_rpt_MD201AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MD201AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			   A.SIRANO||';'||nvl(A.KIYMETTURU,' ')||';'||nvl(A.FAIZYAPISI,' ')||';'||nvl(A.PORTFOY,' ')||';'||
			   nvl(A.ALTPORTFOY,' ')||';'||nvl(A.ULKEKODU,' ')||';'||nvl(A.PARAKODU,' ')||';'||nvl(A.ENDEKS,' ')||';'||
			   nvl(A.TANIM,' ') ||';'||nvl(A.KUPONODE,' ')||';'||nvl(A.STRIP,' ')||';'||nvl(A.IDKURULUS,' ')||';'||nvl(A.KULDEGYONT,' ')||';'||
			   nvl(to_char(A.GIRISTAR,'DD'),' ')||';'||nvl(to_char(A.GIRISTAR,'MM'),' ')||';'||nvl(to_char(A.GIRISTAR,'YYYY'),' ')||';'||
			   nvl(to_char(A.VADETAR,'DD'),' ')||';'||nvl(to_char(A.VADETAR,'MM'),' ')||';'||nvl(to_char(A.VADETAR,'YYYY'),' ')||';'||
			   nvl(A.DSMALBED,0)||';'||nvl(A.MDAK,0)||';'||nvl(A.ADAK,0)||';'||nvl(A.BILDEG,0)
			   ||';'||nvl(A.REFFAIZ,' ')||';'||trim(to_char(nvl(A.REESFORAN,0),'000.00'))||';'||nvl(A.REESTUT,0)||';'||nvl(A.CPDEG,0)||';'||nvl(A.DSYAZDEG,0)
	        FROM    CBS_RPT_MD201AS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter ||pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End ;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			   lpad(A.SIRANO,5,' ')||lpad(nvl(A.KIYMETTURU,' '),2,' ')||lpad(nvl(A.FAIZYAPISI,' '),1,' ')||lpad(nvl(A.PORTFOY,' '),1,' ')||
			   lpad(nvl(A.ALTPORTFOY,' '),2,' ')||lpad(nvl(A.ULKEKODU,' '),2,' ')||lpad(nvl(A.PARAKODU,' '),3,' ')||lpad(nvl(A.ENDEKS,' '),1,' ')||
			   lpad(nvl(A.TANIM,' '),12,' ') ||lpad(nvl(A.KUPONODE,' '),2,' ')||lpad(nvl(A.STRIP,' '),1,' ')||rpad(nvl(A.IDKURULUS,' '),25,' ')||lpad(nvl(A.KULDEGYONT,' '),2,' ')||
			   lpad(nvl(to_char(A.GIRISTAR,'DD-MM-YYYY'),' '),10,' ')||
			   lpad(nvl(to_char(A.VADETAR,'DD-MM-YYYY'),' '),10,' ')||
			   lpad(nvl(A.DSMALBED,0),9,' ')||lpad(nvl(A.MDAK,0),9,' ')||lpad(nvl(A.ADAK,0),9,' ')||lpad(nvl(A.BILDEG,0),9,' ')
			   ||lpad(nvl(A.REFFAIZ,' '),15,' ')||trim(to_char(nvl(A.REESFORAN,0),'000.00'))||lpad(nvl(A.REESTUT,0),9,' ')||lpad(nvl(A.CPDEG,0),9,' ')||lpad(nvl(A.DSYAZDEG,0),9,' ')
	        FROM    CBS_RPT_MD201AS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_MD201AS;
/***********************************/

PROCEDURE sp_rpt_MS200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MS200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	  			  A.SIRANO||';'||nvl(A.KURULUSADI,' ')||';'||nvl(A.GRUPKODU,' ')||';'||nvl(A.RISKKODU,' ')||';'||nvl(A.ULKEKODU,' ')
				  ||';'||nvl(A.GMULKEKODU,' ')||';'||nvl(A.GARANTORUK,' ')||';'||nvl(A.SUBEKODU,' ')||';'||nvl(A.ATUTAR,0)||';'||nvl(A.APARAKODU,' ')
				  ||';'||nvl(A.AUSDKARS,0)||';'||nvl(A.AREFFORAN,' ')||';'||trim(to_char(nvl(A.AFORAN,0),'000.00'))||';'||
				  nvl(to_char(A.AACILISTAR,'DD'),' ')||';'||nvl(to_char(A.AACILISTAR,'MM'),' ')||';'||nvl(to_char(A.AACILISTAR,'YYYY'),' ')||';'||
				  nvl(to_char(A.AVADETAR,'DD'),' ')||';'||nvl(to_char(A.AVADETAR,'MM'),' ')||';'||nvl(to_char(A.AVADETAR,'YYYY'),' ')||';'||
				  nvl(A.AISLEMTUR,' ')||';'||nvl(A.BTUTAR,0)||';'||nvl(A.BPARAKODU,' ')||';'||nvl(A.BUSDKARS,0)||';'||nvl(A.BREFFORAN,' ')
				  ||';'||trim(to_char(nvl(A.BFORAN,0),'000.00'))||';'||
				  nvl(to_char(A.BACILISTAR,'DD'),' ')||';'||nvl(to_char(A.BACILISTAR,'MM'),' ')||';'||nvl(to_char(A.BACILISTAR,'YYYY'),' ')||';'||
				  nvl(to_char(A.BVADETAR,'DD'),' ')||';'||nvl(to_char(A.BVADETAR,'MM'),' ')||';'||nvl(to_char(A.BVADETAR,'YYYY'),' ')||';'||
				  nvl(A.BISLEMTUR,' ')
	        FROM    CBS_RPT_MS200AS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	  			  lpad(A.SIRANO,5,' ')||rpad(nvl(A.KURULUSADI,' '),50,' ')||lpad(nvl(A.GRUPKODU,' '),1,' ')||
				  lpad(nvl(A.RISKKODU,' '),6,' ')||lpad(nvl(A.ULKEKODU,' '),2,' ')
				  ||lpad(nvl(A.GMULKEKODU,' '),2,' ')||lpad(nvl(A.GARANTORUK,' '),2,' ')||
				  lpad(nvl(A.SUBEKODU,' '),5,' ')||lpad(nvl(A.ATUTAR,0),9,' ')||lpad(nvl(A.APARAKODU,' '),3,' ')
				  ||lpad(nvl(A.AUSDKARS,0),9,' ')||lpad(nvl(A.AREFFORAN,' '),15,' ')||
				  trim(to_char(nvl(A.AFORAN,0),'000.00'))||lpad(nvl(to_char(A.AACILISTAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(to_char(A.AVADETAR,'DD-MM-YYYY'),' '),10,' ')|| lpad(nvl(A.AISLEMTUR,' '),2,' ')||
				  lpad(nvl(A.BTUTAR,0),9,' ')||lpad(nvl(A.BPARAKODU,' '),3,' ')||lpad(nvl(A.BUSDKARS,0),9,' ')||
				  lpad(nvl(A.BREFFORAN,' '),15,' ')||trim(to_char(nvl(A.BFORAN,0),'000.00'))||
				  lpad(nvl(to_char(A.BACILISTAR,'DD-MM-YYYY'),' '),10,' ')||lpad(nvl(to_char(A.BVADETAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(A.BISLEMTUR,' '),2,' ')
	        FROM    CBS_RPT_MS200AS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_MS200AS;

/***********************************/

PROCEDURE sp_rpt_MS201AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MS201AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
		   		  A.SIRANO||';'||nvl(trim(A.HAVISIM),' ')||';'||nvl(A.HAVVERGINO,' ')||';'||nvl(trim(A.MUHBANKADI),' ')||';'||
				  nvl(A.MUHBANKSWIFTKOD,' ')||';'||nvl(trim(A.HAVLEHISIM),' ')||';'||nvl(A.HAVLEHVERGINO,' ')||';'||nvl(A.ARACISUBE,0)||';'||
				  nvl(A.GGHAVISLKOD,' ')||';'||nvl(A.ULKEKODU,' ')||';'||nvl(A.PARAKODU,' ')||';'||
				  nvl(to_char(A.ISLEMTAR,'DD'),' ')||';'||nvl(to_char(A.ISLEMTAR,'MM'),' ')||';'||nvl(to_char(A.ISLEMTAR,'YYYY'),' ')||';'||
				  nvl(A.TRLKARS,0)||';'||nvl(A.ORJPARATUT,0)
	        FROM    CBS_RPT_MS201AS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
		   		  lpad(A.SIRANO,5,' ')||lpad(nvl(trim(A.HAVISIM),' '),50,' ')||lpad(nvl(A.HAVVERGINO,' '),12,' ')||lpad(nvl(trim(A.MUHBANKADI),' '),50,' ')||
				  lpad(nvl(A.MUHBANKSWIFTKOD,' '),8,' ')||lpad(nvl(trim(A.HAVLEHISIM),' '),50,' ')||lpad(nvl(A.HAVLEHVERGINO,' '),12,' ')||lpad(nvl(A.ARACISUBE,0),5,' ')||
				  lpad(nvl(A.GGHAVISLKOD,' '),3,' ')||lpad(nvl(A.ULKEKODU,' '),2,' ')||lpad(nvl(A.PARAKODU,' '),3,' ')||lpad(nvl(to_char(A.ISLEMTAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(A.TRLKARS,0),9,' ')||lpad(nvl(A.ORJPARATUT,0),9,' ')
	        FROM    CBS_RPT_MS201AS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_MS201AS;

/***********************************/

PROCEDURE sp_rpt_MV101AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MV101AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  A.SIRANO||';'||nvl(b.ad,' ')||';'||nvl(A.SIFIRONVDZ,0)||';'|| nvl(A.SIFIRONVDL,0)||';'||nvl(A.ONBIRELLIVDZ,0)||';'||
				  nvl(A.ONBIRELLIVDL,0)||';'||nvl(A.ELLIBIRVDZ,0)||';'||nvl(A.ELLIBIRVDL,0)||';'||nvl(A.IKIYUZELLIVDZ,0)||';'||nvl(A.IKIYUZELLIVDL,0)||';'||
				  nvl(A.BIRTRILYONVDZ,0)||';'||nvl(A.BIRTRILYONVDL,0)||';'||nvl(A.TOPLAMVDZ,0)||';'||nvl(A.TOPLAMVDL,0)
	        FROM    CBS_RPT_MV101AS a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        and     b.sirano = a.sirano
	        and     b.raporkod ='MV101AS'
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  lpad(A.SIRANO,5,' ')||lpad(nvl(A.SIFIRONVDZ,0),9,' ')||lpad(nvl(A.SIFIRONVDL,0),9,' ')||lpad(nvl(A.ONBIRELLIVDZ,0),9,' ')||
				  lpad(nvl(A.ONBIRELLIVDL,0),9,' ')||lpad(nvl(A.ELLIBIRVDZ,0),9,' ')||lpad(nvl(A.ELLIBIRVDL,0),9,' ')||lpad(nvl(A.IKIYUZELLIVDZ,0),9,' ')||lpad(nvl(A.IKIYUZELLIVDL,0),9,' ')||
				  lpad(nvl(A.BIRTRILYONVDZ,0),9,' ')||lpad(nvl(A.BIRTRILYONVDL,0),9,' ')||lpad(nvl(A.TOPLAMVDZ,0),9,' ')||lpad(nvl(A.TOPLAMVDL,0),9,' ')
	        FROM    CBS_RPT_MV101AS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_MV101AS;

/***********************************/

PROCEDURE sp_rpt_MZ200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MZ200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	 		      A.HESAPNO||';'||nvl(b.hesapad,' ')||';'||nvl(A.YITESKILAT,0)||';'||nvl(A.YDSUBE,0)||';'||nvl(A.GENKONSOLIDE,0)
	        FROM    CBS_RPT_MZ200AS a,cbs_rpt_hesapkod b
	        WHERE   a.donem= pd_donem
	        and     b.hesapno = a.hesapno
			order by A.hesapNO;
 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	 		      rpad(A.HESAPNO,7,' ')||lpad(nvl(A.YITESKILAT,0),9,' ')||lpad(nvl(A.YDSUBE,0),9,' ')||lpad(nvl(A.GENKONSOLIDE,0),9,' ')
	        FROM   CBS_RPT_MZ200AS A
	        WHERE   a.donem= pd_donem
			order by a.hesapno;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_MZ200AS;

/***********************************/

PROCEDURE sp_rpt_SY200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*SY200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/

    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  A.SIRANO ||';'||nvl(b.ad,' ')||';'||nvl(A.TUTAR,0)
	        FROM    CBS_RPT_SY200AS a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        and     b.sirano = a.sirano
	        and     b.raporkod ='SY200AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				lpad(A.SIRANO,3,' ')||
  				 case when nvl(A.TUTAR,0) <0 then lpad(nvl(abs(A.TUTAR),0),9,'-00000000')
				 else lpad(nvl(A.TUTAR,0),9,'000000000')end
	        FROM    CBS_RPT_SY200AS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_SY200AS;

/***********************************/

PROCEDURE sp_rpt_ST300A
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*ST300A Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
	 -- BDDK dosyasi cikilmiyor
    if PC_rapor='TCMB' then
        OPEN pRetCur FOR
        SELECT
 		      rpad(A.HESAPNO,7,' ')||lpad(nvl(A.YITESKILAT,0),9,' ')||lpad(' ',13,' ')
        FROM   CBS_RPT_ST300A A
        WHERE   a.donem= pd_donem
		order by a.hesapno;

    end if;
    Exception
	  When Others Then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_ST300A;

/***********************************/

PROCEDURE sp_rpt_MD202HS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*MD202HS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	  			  A.SIRANO||';'||nvl(A.ISINKOD,' ')||';'||lpad(nvl(A.TURKOD,' '),2,'00')||';'|| nvl(A.TARAFKOD,' ')||';'||
				  nvl(A.PARAKODU,' ')||';'||nvl(A.NDYI,0)||';'||nvl(A.NDYD,0)||';'||nvl(A.BKDYI,0)||';'||nvl(A.BKDYD,0)
	        FROM    CBS_RPT_MD202HS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

		    Exception
			  When Others Then
		      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	  			  lpad(A.SIRANO,5,' ')||rpad(nvl(A.ISINKOD,' '),15,' ')||lpad(nvl(A.TURKOD,' '),2,' ')||
				  lpad(nvl(A.TARAFKOD,' '),3,' ')|| lpad(nvl(A.PARAKODU,' '),3,' ')||lpad(nvl(A.NDYI,0),9,' ')||
				  lpad(nvl(A.NDYD,0),9,' ')||lpad(nvl(A.BKDYI,0),9,' ')||lpad(nvl(A.BKDYD,0),9,' ')
	        FROM    CBS_RPT_MD202HS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;
		    Exception
			  When Others Then
		      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_MD202HS;

/***********************************/

PROCEDURE sp_rpt_RP200HS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*RP200HS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  A.SIRANO||';'||
				  nvl(A.TURKODU,' ')||';'||nvl(A.ANAPARA,0)||';'||
				  nvl(to_char(A.ACILISTAR,'DD'),' ')||';'||nvl(to_char(A.ACILISTAR,'MM'),' ')||';'|| nvl(to_char(A.ACILISTAR,'YYYY'),' ')||';'||
				  nvl(to_char(A.VADETAR,'DD'),' ')||';'||nvl(to_char(A.VADETAR,'MM'),' ')||';'||nvl(to_char(A.VADETAR,'YYYY'),' ')||';'||
				  trim(to_char(nvl(A.FAIZORN,0),'000.00'))||';'||nvl(A.TANIM,' ')||';'||lpad(nvl(A.TUR,' '),2,'00')||';'||nvl(A.PORTFOY,' ')||';'||
				  nvl(A.BILANCO,0)
	        FROM    CBS_RPT_RP200HS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;

		    Exception
			  When Others Then
		      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  lpad(A.SIRANO,5,' ')||lpad(nvl(A.TURKODU,' '),1,' ')	||lpad(nvl(A.ANAPARA,0),9,' ')||
				  lpad(nvl(to_char(A.ACILISTAR,'DD-MM-YYYY'),' '),10,' ')||
				  lpad(nvl(to_char(A.VADETAR,'DD-MM-YYYY'),' '),10,' ')||
				  trim(to_char(nvl(A.FAIZORN,0),'000.00'))||
				  lpad(nvl(A.TANIM,' '),12,' ')||lpad(nvl(A.TUR,' '),2,' ')||
				  lpad(nvl(A.PORTFOY,' '),1,' ')|| lpad(nvl(A.BILANCO,0),9,' ')
	        FROM    CBS_RPT_RP200HS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

		    Exception
			  When Others Then
		      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_RP200HS;

/***********************************/

PROCEDURE sp_rpt_YY200HS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*YY200HS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  A.SIRANO||';'||nvl(trim(A.KURUKUSADI),' ')||';'||nvl(A.MALIKOD,' ')||';'||nvl(A.SUBEKOD,' ')||';'||
				  nvl(A.YAKINLIKKOD,' ')||';'||nvl(A.ULKEKOD,' ')||';'||nvl(A.GNULKEKOD,' ')||';'||nvl(A.PARAKODU,' ')||';'||
				  nvl(A.TURKODU,' ')||';'||
				  nvl(to_char(A.BORCLANMATAR,'DD'),' ')||';'||nvl(to_char(A.BORCLANMATAR,'MM'),' ')||';'||nvl(to_char(A.BORCLANMATAR,'YYYY'),' ')||';'||
				  nvl(A.VGBORC,0)||';'||nvl(A.ODENENBORC,0)||';'||nvl(A.YBTUTARI,0)||';'||trim(to_char(nvl(A.YBFORAN,0),'0000.00'))||';'||
				  nvl(to_char(A.YBVADETAR,'DD'),' ')||';'|| nvl(to_char(A.YBVADETAR,'MM'),' ')||';'|| nvl(to_char(A.YBVADETAR,'YYYY'),' ')||';'||
				  nvl(A.YABTUTARI,0)||';'|| trim(to_char(nvl(A.YABFORAN,0),'0000.00'))||';'||
				  nvl(to_char(A.YABVADETAR,'DD'),' ')||';'|| nvl(to_char(A.YABVADETAR,'MM'),' ')||';'||nvl(to_char(A.YABVADETAR,'YYYY'),' ')
	        FROM    CBS_RPT_YY200HS a
	        WHERE   a.donem= pd_donem
			order by a.sirano;
 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   			  lpad(A.SIRANO,5,' ')||rpad(nvl(trim(A.KURUKUSADI),' '),50,' ')||lpad(nvl(A.MALIKOD,' '),1,' ')||
				  lpad(nvl(A.SUBEKOD,' '),5,' ')||lpad(nvl(A.YAKINLIKKOD,' '),1,' ')||lpad(nvl(A.ULKEKOD,' '),2,' ')||
				  lpad(nvl(A.GNULKEKOD,' '),2,' ')||lpad(nvl(A.PARAKODU,' '),3,' ')||rpad(nvl(A.TURKODU,' '),2,' ')||
				  lpad(nvl(to_char(A.BORCLANMATAR,'DD-MM-YYYY'),' '),10,' ')||lpad(nvl(A.VGBORC,0),9,' ')||
				  lpad(nvl(A.ODENENBORC,0),9,' ')||lpad(nvl(A.YBTUTARI,0),9,' ')||trim(to_char(nvl(A.YBFORAN,0),'0000.00'))||
				  lpad(nvl(to_char(A.YBVADETAR,'DD-MM-YYYY'),' '),10,' ')||lpad(nvl(A.YABTUTARI,0),9,' ')||
				  trim(to_char(nvl(A.YABFORAN,0),'0000.00'))||lpad(nvl(to_char(A.YABVADETAR,'DD-MM-YYYY'),' '),10,' ')
	        FROM    CBS_RPT_YY200HS A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_YY200HS;

/***********************************/

PROCEDURE sp_rpt_UL200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*UL200HS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  distinct B.ulkekod||';'||B.parakod||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=1 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=2 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=3 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=4 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=5 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=6 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=7 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=8 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=9 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=10 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=11 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=12 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=13 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=14 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=15 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=16 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=17 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=18 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=19 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=20 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=21 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=22 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=23 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=24 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=25 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)
		    from CBS_RPT_UL200AS B
			where B.Donem=pd_donem;


 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  distinct lpad(B.ulkekod,2,' ')|| lpad(B.parakod,3,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=1 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=2 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=3 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=4 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=5 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=6 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=7 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=8 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=9 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=10 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=11 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=12 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=13 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=14 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=15 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=16 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=17 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=18 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=19 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=20 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=21 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=22 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=23 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=24 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL200AS A where  a.sirano=25 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')
		    from CBS_RPT_UL200AS B
			where B.Donem=pd_donem;


 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;
END sp_rpt_UL200AS;

/***********************************/
PROCEDURE sp_rpt_ULAS
(
  pc_rapor      VARCHAR2,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*hesap tip tablosundan rapor koduna g?re hesap adini dondurur*/
        OPEN pRetCur FOR
        SELECT
			  sirano ||'-'|| trim(ad)
	    from CBS_RPT_hesaptip
		where raporkod= pc_rapor
		order by sirano;

	    Exception
		  When Others Then
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_ULAS;

/***********************************/

PROCEDURE sp_rpt_UL201AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*UL201AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  distinct B.ulkekod||';'||B.parakod||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=1 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=2 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=3 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=4 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=5 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=6 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=7 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=8 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=9 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=10 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=11 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=12 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=13 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=14 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=15 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=16 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=17 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=18 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=19 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=20 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=21 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=22 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=23 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=24 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=25 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=26 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=27 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=28 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=29 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=30 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=31 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=32 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=33 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=34 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=35 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=36 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=37 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=38 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=39 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=40 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=41 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=42 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=43 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=44 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)  ||';'||
				  nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=45 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0)

		    from CBS_RPT_UL201AS B
			where B.Donem=pd_donem;


 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  distinct lpad(B.ulkekod,2,' ')|| lpad(B.parakod,3,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=1 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=2 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=3 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=4 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=5 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=6 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=7 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=8 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=9 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=10 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=11 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=12 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=13 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=14 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=15 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=16 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=17 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=18 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=19 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=20 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=21 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=22 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=23 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=24 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=25 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ') ||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=62 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=27 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=28 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=29 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=30 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=31 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=32 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=33 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=34 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=35 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=36 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=37 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=38 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=39 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=40 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=41 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=42 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=43 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=44 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')||
				  lpad(nvl((select nvl(A.tutar,0)  from CBS_RPT_UL201AS A where  a.sirano=45 and A.donem=B.donem and A.ulkekod=B.ulkekod  and A.PARAKOD =B.parakod),0),9,' ')
		    from CBS_RPT_UL201AS B
			where B.Donem=pd_donem;


 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_UL201AS;

/***********************************/

PROCEDURE sp_rpt_NH200HS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*NH200HS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
--Bu raporda sadece BDDK'ya dosya ??k?l?yor
    if  pc_rapor='BDDK' then
        OPEN pRetCur FOR
        SELECT
			  A.SIRANO ||';'||nvl(b.ad,' ')||';'||nvl(A.GIRISTP,0)||';'||
			  nvl(A.GIRISYP,0)||';'||nvl(A.CIKISTP,0)||';'||nvl(A.CIKISYP,0)
        FROM    CBS_RPT_NH200HS a,cbs_rpt_hesaptip b
        WHERE   a.donem= pd_donem
        and     b.sirano = a.sirano
        and     b.raporkod ='NH200HS'
		order by a.sirano;
    end if;

    Exception
	  When Others Then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_NH200HS;

/***********************************/

PROCEDURE sp_rpt_YP200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*YP200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				  A.SIRANO ||';'||nvl(b.ad,' ')||';'||nvl(A.TUTAR,0)
	        FROM    CBS_RPT_YP200AS a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        and     b.sirano = a.sirano
	        and     b.raporkod ='YP200AS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
				lpad(A.SIRANO,3,' ')||
  				 case when nvl(A.TUTAR,0) <0 then lpad(nvl(abs(A.TUTAR),0),9,'-00000000')
				 else lpad(nvl(A.TUTAR,0),9,'000000000')end	||lpad(' ',17,' ')
	        FROM    CBS_RPT_KS100A A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;
END sp_rpt_YP200AS;

/***********************************/

PROCEDURE sp_rpt_YP200HS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*YP200HS Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   		A.SIRANO||';'||nvl(b.ad,' ')||';'||nvl(A.PZTS,0)||';'||nvl(A.SALI,0)||';'||
			nvl(A.CARS,0)||';'||nvl(A.PERS,0)||';'||nvl(A.CUMA,0)||';'||nvl(A.CMTS,0)||';'||
			nvl(A.PAZAR,0)
	        FROM    CBS_RPT_YP200HS a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        and     b.sirano = a.sirano
	        and     b.raporkod ='YP200HS'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			lpad(A.SIRANO,3,' ')||
			case when nvl(A.PZTS,0) <0 then lpad(nvl(abs(A.PZTS),0),9,'-00000000')
			else lpad(nvl(A.PZTS,0),9,'000000000')end	||
			case when nvl(A.SALI,0) <0 then lpad(nvl(abs(A.SALI),0),9,'-00000000')
			else lpad(nvl(A.SALI,0),9,'000000000')end	 ||
			case when nvl(A.CARS,0) <0 then lpad(nvl(abs(A.CARS),0),9,'-00000000')
			else lpad(nvl(A.CARS,0),9,'000000000')end	 ||
			case when nvl(A.PERS,0) <0 then lpad(nvl(abs(A.PERS),0),9,'-00000000')
			else lpad(nvl(A.PERS,0),9,'000000000')end	 ||
			case when nvl(A.CUMA,0) <0 then lpad(nvl(abs(A.CUMA),0),9,'-00000000')
			else lpad(nvl(A.CUMA,0),9,'000000000')end	 ||
			case when nvl(A.CMTS,0) <0 then lpad(nvl(abs(A.CMTS),0),9,'-00000000')
			else lpad(nvl(A.CMTS,0),9,'000000000')end	||
			case when nvl(A.PAZAR,0) <0 then lpad(nvl(abs(A.PAZAR),0),9,'-00000000')
			else lpad(nvl(A.PAZAR,0),9,'000000000')end
	        FROM    CBS_RPT_KS100H A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    end if;

END sp_rpt_YP200HS;

/***********************************/

PROCEDURE sp_rpt_KT100H
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pc_parakod    VARCHAR2,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*KT100H Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   		nvl(A.kur,0)||';'|| b.ad ||';'||nvl(A.KREDITUT1,0)||';'||trim(to_char(nvl(A.AORTFORAN1,0),'000.00'))||';'||
			trim(to_char(nvl(A.DMBAFORAN1,0),'000.00'))||';'||nvl(A.KREDITUT2,0)||';'||
			trim(to_char(nvl(A.AORTFORAN2,0),'000.00'))||';'||trim(to_char(nvl(A.DMBAFORAN2,0),'000.00'))||';'||
			nvl(A.KREDITUT3,0)||';'||trim(to_char(nvl(A.AORTFORAN3,0),'000.00'))||';'||
			trim(to_char(nvl(A.DMBAFORAN3,0),'000.00'))
	        FROM    CBS_RPT_KT100H a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        AND     upper(a.parakodu)= upper(pc_parakod)
	        AND     a.parakodu= pc_parakod
	        and     b.sirano = a.sirano
	        and     b.raporkod ='KT100H'
			order by a.sirano;

			Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	   		lpad(PARAKODU,3,' ')||lpad(nvl(A.kur,0),9,' ')|| lpad(a.SIRANO,2,' ')||lpad(nvl(A.KREDITUT1,0),9,' ')||
			trim(to_char(nvl(A.AORTFORAN1,0),'000.00'))||trim(to_char(nvl(A.DMBAFORAN1,0),'000.00'))||lpad(nvl(A.KREDITUT2,0),9,' ')||
			trim(to_char(nvl(A.AORTFORAN2,0),'000.00'))||trim(to_char(nvl(A.DMBAFORAN2,0),'000.00'))||lpad(nvl(A.KREDITUT3,0),9,' ')||
			trim(to_char(nvl(A.AORTFORAN3,0),'000.00'))||trim(to_char(nvl(A.DMBAFORAN3,0),'000.00'))
	        FROM    CBS_RPT_KT100H A,cbs_rpt_dovizkod b
	        WHERE   a.donem= pd_donem
	        AND     upper(a.parakodu)= upper(b.DOVIZKOD)
			order by b.sirano,a.sirano;


 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_KT100H;
/***********************************/

PROCEDURE sp_rpt_DP100H
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pc_parakod    VARCHAR2,
  pc_bilanco	VARCHAR2,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
  lc_raporkod		  VARCHAR2(7);
BEGIN
	 /*DP100H Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if pc_bilanco ='V' Then /*Bilan?o tipine gore rapor kodu belirleniyor*/
	   lc_raporkod :='DP100HV';
	else
	   lc_raporkod :='DP100HY';
	end if ;

    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			A.SIRANO||';'|| b.ad ||';'||nvl(A.BIRAYKALAN,0)||';'||nvl(A.BIRUCAY,0)||';'||
			nvl(A.UCALTIAY,0)||';'||nvl(A.ALTIONIKIAY,0)||';'||nvl(A.ONIKIDENFAZLA,0)||';'||nvl(A.TOPLAM,0)
	        FROM    CBS_RPT_DP100H a,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
	        AND     upper(a.parakodu)= upper(pc_parakod)
			and		a.BILANCOTIPI =pc_bilanco
	        and     b.sirano = a.sirano
	        and     b.raporkod = lc_raporkod
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		end;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
			lpad(A.PARAKODU,3,' ')||lpad(a.BILANCOTIPI,1,' ')||lpad(A.SIRANO,3,'0')||
			case when nvl(A.BIRAYKALAN,0) <0 then lpad(nvl(abs(A.BIRAYKALAN),0),12,'-00000000000')
			else lpad(nvl(A.BIRAYKALAN,0),12,'000000000000')end	||
			case when nvl(A.BIRUCAY,0) <0 then lpad(nvl(abs(A.BIRUCAY),0),12,'-00000000000')
			else lpad(nvl(A.BIRUCAY,0),12,'000000000000')end	||
			case when nvl(A.UCALTIAY,0) <0 then lpad(nvl(abs(A.UCALTIAY),0),12,'-00000000000')
			else lpad(nvl(A.UCALTIAY,0),12,'000000000000')end	||
			case when nvl(A.ALTIONIKIAY,0) <0 then lpad(nvl(abs(A.ALTIONIKIAY),0),12,'-00000000000')
			else lpad(nvl(A.ALTIONIKIAY,0),12,'000000000000')end	||
			case when nvl(A.ONIKIDENFAZLA,0) <0 then lpad(nvl(abs(A.ONIKIDENFAZLA),0),12,'-00000000000')
			else lpad(nvl(A.ONIKIDENFAZLA,0),12,'000000000000')end	||
			case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),14,'-0000000000000')
			else lpad(nvl(A.TOPLAM,0),14,'00000000000000')end
	        FROM    CBS_RPT_DP100H a,cbs_rpt_dovizkod b
	        WHERE   a.donem= pd_donem
	        AND     upper(a.parakodu)= upper(b.DOVIZKOD)
			order by b.sirano,a.BILANCOTIPI,a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
        End;
    end if;

END sp_rpt_DP100H;
/***********************************/

PROCEDURE sp_rpt_DOVIZTAKIP
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pc_parakod    VARCHAR2,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*DovizTakip Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
	 -- Bu rapor sadece TCMB'ye , Excel format?nda c?kar?l?yor.
    if  pc_rapor='TCMB' then
        OPEN pRetCur FOR
        SELECT
   		upper(a.parakodu)||';'||b.ad ||';'||nvl(A.ALINANUSDTUTR,0)||';'||nvl(A.ALINANTLKARS,0)
		||';'||nvl(A.SATILANUSDTUTR,0)||';'||nvl(A.SATILANTLKARS,0)
        FROM    CBS_RPT_DOVIZTAKIP a,cbs_rpt_hesaptip b
        WHERE   a.donem= pd_donem
        --AND     upper(a.parakodu)= upper(pc_parakod)
        and     b.sirano = a.sirano
        and     b.raporkod ='DOVTAK'
		order by a.parakodu,a.sirano;
    end if;

	Exception
		When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_DOVIZTAKIP;
/***********************************/

PROCEDURE sp_rpt_TUKKREDFRM
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*TUKKREDFRM Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
---- Bu rapor sadece TCMB'ye , Excel format?nda c?kar?l?yor.
    if  pc_rapor='TCMB' then
        OPEN pRetCur FOR
        SELECT
			  nvl(A.kur,0) ||';'||nvl(b.ad,' ')||';'||nvl(A.TP,0)||';'||
			  nvl(A.YP,0)||';'||nvl(A.Toplam,0)
        FROM    CBS_RPT_TUKKREDFRM a,cbs_rpt_hesaptip b
        WHERE   a.donem= pd_donem
        and     b.sirano = a.sirano
        and     b.raporkod ='TUKKRED'
		order by a.sirano;
    end if;
	Exception
		When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_TUKKREDFRM;
 /***********************************/
PROCEDURE sp_rpt_AKTIFFRM
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*AKTIF Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
---- Bu rapor sadece TCMB'ye , Excel format?nda c?kar?l?yor.
    if  pc_rapor='TCMB' then
        OPEN pRetCur FOR
        SELECT
			  A.Sirano||';'||nvl(b.ad,' ')||';'||nvl(A.TP,0)||';'||
			  nvl(A.YP,0)||';'||nvl(A.Toplam,0)
        FROM    CBS_RPT_AKTIFFRM a,cbs_rpt_hesaptip b
        WHERE   a.donem= pd_donem
        and     b.sirano = a.sirano
        and     b.raporkod ='AKTIF'
		order by a.sirano;
    end if;
	Exception
		When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_AKTIFFRM;
/**************************************/
PROCEDURE sp_rpt_PASIFFRM
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)
IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*PASIF Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
---- Bu rapor sadece TCMB'ye , Excel format?nda c?kar?l?yor.
    if  pc_rapor='TCMB' then
        OPEN pRetCur FOR
        SELECT
			  A.Sirano||';'||nvl(b.ad,' ')||';'||nvl(A.YITP,0)||';'||nvl(A.YIYP,0)||';'||
			  nvl(A.YDTP,0)||';'||nvl(A.YDYP,0)||';'||nvl(A.Toplam,0)
        FROM    CBS_RPT_PASIFFRM a,cbs_rpt_hesaptip b
        WHERE   a.donem= pd_donem
        and     b.sirano = a.sirano
        and     b.raporkod ='PASIF'
		order by a.sirano;
    end if;

	Exception
		When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

END sp_rpt_PASIFFRM;
/**************************************/

PROCEDURE sp_rpt_CM100US
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 /*CM100US Raporu i?in uygun formatta kay?t d?nd?r?l?r*/
    if  pc_rapor='BDDK' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
   				  A.SIRANO||';'||nvl(b.ad,' ')||';'||nvl(A.DBBAKIYE,0)||';'||nvl(A.DBMKIF,0)||';'||nvl(A.DIVIGA,0)
				  ||';'||nvl(A.DIIHRAC,0)||';'||nvl(A.DIMKIF,0)||';'||nvl(A.DIITFA,0)||';'||
				  nvl(A.DIKURFARKI,0)||';'||nvl(A.DONEMSONU,0)||';'||nvl(A.FVGREES,0)||';'||
				  trim(to_char(nvl(A.AORTYFORAN,0),'000.00'))||';'||nvl(A.VKAOGUNSAY,0)
	        FROM    CBS_RPT_CM100US A,cbs_rpt_hesaptip b
	        WHERE   a.donem= pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='CM100US'
			order by a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif pc_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
   				  lpad(A.SIRANO,2,' ')||lpad(nvl(A.DBBAKIYE,0),9,' ')||lpad(nvl(A.DBMKIF,0),9,' ')||lpad(nvl(A.DIVIGA,0),9,' ')||
				  lpad(nvl(A.DIIHRAC,0),9,' ')||lpad(nvl(A.DIMKIF,0),9,' ')||lpad(nvl(A.DIITFA,0),9,' ')||
				  lpad(nvl(A.DIKURFARKI,0),9,' ')||lpad(nvl(A.DONEMSONU,0),9,' ')||lpad(nvl(A.FVGREES,0),9,' ')||
				  trim(to_char(nvl(A.AORTYFORAN,0),'000.00'))||lpad(nvl(A.VKAOGUNSAY,0),4,' ')
	        FROM    CBS_RPT_CM100US A
	        WHERE   a.donem= pd_donem
			order by a.sirano;

		   Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    end if;

END sp_rpt_CM100US;
/***********************************/
PROCEDURE sp_rpt_KZ200AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --KZ200AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*
     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	        	  a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||nvl(A.YP,0)||';'||
				  nvl(A.TOPLAM,0)
			FROM    CBS_RPT_KZ200AS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='KZ200AS'
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	        	 lpad(A.SIRANO,2,' ') ||
  				 case when nvl(A.TP,0) <0 then lpad(nvl(abs(A.TP),0),9,'-00000000')
				 else lpad(nvl(A.TP,0),9,'000000000')end	||
  				 case when nvl(A.YP,0) <0 then lpad(nvl(abs(A.YP),0),9,'-00000000')
				 else lpad(nvl(A.YP,0),9,'000000000')end	||
  				 case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				 else lpad(nvl(A.TOPLAM,0),9,'000000000')end
			FROM    CBS_RPT_KZ200AS A
	        WHERE   A.donem   = pd_donem
			ORDER BY a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;

    end if;

END sp_rpt_KZ200AS;

/**********************************/

PROCEDURE sp_rpt_KZ201AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --KZ201AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*
     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	        	  a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||nvl(A.YP,0)||';'||
				  nvl(A.TOPLAM,0)
			FROM    CBS_RPT_KZ201AS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and     b.sirano = a.sirano
			and     b.raporkod ='KZ200AS' --200 olmas? ?a??rtmas?n.De?erler ayn?
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	        	 lpad(A.SIRANO,2,' ') ||
  				 case when nvl(A.TP,0) <0 then lpad(nvl(abs(A.TP),0),9,'-00000000')
				 else lpad(nvl(A.TP,0),9,'000000000')end	||
  				 case when nvl(A.YP,0) <0 then lpad(nvl(abs(A.YP),0),9,'-00000000')
				 else lpad(nvl(A.YP,0),9,'000000000')end	||
  				 case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				 else lpad(nvl(A.TOPLAM,0),9,'000000000')end
			FROM    CBS_RPT_KZ201AS A
	        WHERE   A.donem   = pd_donem
			ORDER BY a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;

    end if;

END sp_rpt_KZ201AS;

/**********************************/


PROCEDURE sp_rpt_KZ202AS
(
  pc_rapor      VARCHAR2,
  pd_donem      DATE,
  pn_subekodu	NUMBER,
  pRetCur       IN OUT Pkg_rapor.Generic_CurType
)

IS
  TYPE Generic_CurType IS REF CURSOR;
  p_err               NUMBER(10):= 0;
BEGIN
	 --KZ202AS Raporu i?in uygun formatta kay?t d?nd?r?l?r*
     if pc_rapor='BDDK' then
	 	Begin
	        OPEN pRetCur FOR
	        SELECT
	        	  a.SIRANO ||';'|| b.ad ||';'|| nvl(A.TP,0) ||';'||nvl(A.YP,0)||';'||
				  nvl(A.TOPLAM,0)
			FROM    CBS_RPT_KZ202AS A ,cbs_rpt_hesaptip B
	        WHERE   A.donem   = pd_donem
			and		a.subekodu = pn_subekodu
			and     b.sirano = a.sirano
			and     b.raporkod ='KZ200AS' --200 olmas? ?a??rtmas?n.De?erler ayn?
			ORDER BY a.sirano;

 		    Exception
			  When Others Then
			    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2009' ||  pkg_hata.getDelimiter || pc_rapor || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;
    elsif PC_rapor='TCMB' then
		Begin
	        OPEN pRetCur FOR
	        SELECT
	        	 lpad( a.subekodu,5,' ') || lpad(A.SIRANO,2,' ') ||
  				 case when nvl(A.TP,0) <0 then lpad(nvl(abs(A.TP),0),9,'-00000000')
				 else lpad(nvl(A.TP,0),9,'000000000')end	||
  				 case when nvl(A.YP,0) <0 then lpad(nvl(abs(A.YP),0),9,'-00000000')
				 else lpad(nvl(A.YP,0),9,'000000000')end	||
  				 case when nvl(A.TOPLAM,0) <0 then lpad(nvl(abs(A.TOPLAM),0),9,'-00000000')
				 else lpad(nvl(A.TOPLAM,0),9,'000000000')end
			FROM    CBS_RPT_KZ202AS A
	        WHERE   A.donem   = pd_donem
			and		a.subekodu = pn_subekodu
			ORDER BY a.sirano;

			Exception
	   			When Others Then
  	  			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2010' ||  pkg_hata.getDelimiter || pc_rapor  || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
		End;

    end if;

END sp_rpt_KZ202AS;

/**********************************/


end pkg_rapor;
/

