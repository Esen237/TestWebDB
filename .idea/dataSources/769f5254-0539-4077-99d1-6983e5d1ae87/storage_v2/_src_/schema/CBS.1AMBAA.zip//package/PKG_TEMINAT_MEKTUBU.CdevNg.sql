create PACKAGE PKG_TEMINAT_MEKTUBU IS

FUNCTION  AlinanGarantiKullanilmismi(pn_referans CBS_VW_AKTIF_TEMINAT.referans%TYPE) RETURN VARCHAR2;
  PROCEDURE kredi_hesap_ac(ps_modul_tur VARCHAR2, ps_urun_tur VARCHAR2, ps_urun_sinif VARCHAR2,
                           pn_musteri_no NUMBER, ps_doviz VARCHAR2, ps_sube VARCHAR2, pd_vade DATE,
						   ps_referans VARCHAR2,pn_kredi_teklif_satir_no NUMBER, pn_hesap_no OUT NUMBER);

PROCEDURE IzlemeAlGarBilgisiAl(ps_referans cbs_tm_alinan_garanti.REFERANS%TYPE,
  								   PS_GON_BANKA_MUSTERI_NO OUT NUMBER,
								   ps_DOVIZ_KODU OUT cbs_tm_alinan_garanti.DOVIZ_KODU%TYPE,
								   ps_TUTAR OUT NUMBER,
								   ps_BAKIYE OUT NUMBER,
								   ps_VADE_TARIHI OUT DATE
								   );

FUNCTION TM_SUBE_LIMIT_BAKIYESI RETURN NUMBER;
FUNCTION TM_SUBE_GMIF_BAKIYESI RETURN NUMBER;
FUNCTION TM_SUBE_TOPLAM_BAKIYESI RETURN NUMBER;
FUNCTION TM_SUBE_BAKIYE_YETERLI(pn_lc_tutar NUMBER) RETURN BOOLEAN;
PROCEDURE TM_BAKIYE_UPDATE(ps_artma_azalma VARCHAR2,pn_lc_tutar NUMBER);
FUNCTION Pasif_Hesap_Adi_Al(ps_dk_no VARCHAR2) RETURN VARCHAR2;
FUNCTION TM_bakiyesi_al(ps_referans VARCHAR2) RETURN NUMBER;
Function TM_Urun_tur return varchar2;
FUNCTION KG_bakiyesi_al(ps_referans VARCHAR2) RETURN NUMBER;
FUNCTION KG_tutari_al(ps_referans VARCHAR2) RETURN NUMBER;
FUNCTION KG_Kullanim_Tutari(ps_referans VARCHAR2) RETURN NUMBER;
FUNCTION KG_Top_Tazmin_Tutari(ps_referans VARCHAR2) RETURN NUMBER;

END;


/

