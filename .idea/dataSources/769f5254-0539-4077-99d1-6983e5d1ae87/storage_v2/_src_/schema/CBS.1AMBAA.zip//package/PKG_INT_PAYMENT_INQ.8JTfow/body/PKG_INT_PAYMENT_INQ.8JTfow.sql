create PACKAGE BODY     PKG_INT_PAYMENT_INQ IS

FUNCTION GetInstantInstitutionGroups(ps_lang varchar2,
                                     pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select grup_kodu as code, 
              case 
                when ps_lang = 'en' then
                   aciklama 
                when ps_lang = 'ru' then
                   aciklama_2
                when ps_lang = 'kg' and aciklama_3 is not null then
                   aciklama_3
                when ps_lang = 'kg' then
                   aciklama_2
                when ps_lang = 'tr' and aciklama_4 is not null then
                   aciklama_4
                else
                   aciklama
              end name,
              case 
                  when (select count(*) from cbs_tahsilat_kurum_altgrup_tan where grup_kodu=a.grup_kodu and gecerlimi = 'E') = 1 then
                   (select alt_grup_kodu from cbs_tahsilat_kurum_altgrup_tan where grup_kodu=a.grup_kodu and gecerlimi = 'E')
              else
                null 
              end sub_group_code
           from cbs_tahsilat_kurum_grup_tanim a where gecerlimi = 'E' 
                 and (select count(*) from cbs_tahsilat_kurum_altgrup_tan where grup_kodu = a.grup_kodu and gecerlimi = 'E') > 0 order by priority;
    
    return ls_returncode;
    
EXCEPTION
   when others then
        raise;
END;

FUNCTION GetInstantInsSubGroups(ps_lang varchar2,
                             ps_group_code varchar2, 
                             pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select alt_grup_kodu as code, 
                case 
                    when ps_lang = 'en' then
                       aciklama 
                    when ps_lang = 'ru' then
                       aciklama_2
                    when ps_lang = 'kg' and aciklama_3 is not null then
                       aciklama_3
                    when ps_lang = 'kg' then
                       aciklama_2
                    when ps_lang = 'tr' and aciklama_4 is not null then
                       aciklama_4
                    else
                       aciklama
                end name
                 from cbs_tahsilat_kurum_altgrup_tan 
                    where gecerlimi = 'E'
                          and grup_kodu = ps_group_code
                           and (select count(*) from cbs_tahsilat_kurum_tanim 
                                    where durum_kodu = 'AKTIF' 
                                          and ib_visible = 'Y' 
                                          and kurum_grup_kod = ps_group_code
                                          and kurum_alt_grup_kod = alt_grup_kodu) > 0
                       order by alt_grup_kodu;
    
    return ls_returncode;
    
EXCEPTION
   when others then
        raise;
END;
FUNCTION GetInstantInstitutions(ps_lang varchar2,
                                ps_group_code varchar2, 
                                ps_sub_group_code varchar2, 
                                pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select service_id,
               kurum_kodu as code, 
               case 
                    when ps_lang = 'en' then
                       kurum_adi 
                    when ps_lang = 'ru' then
                       kurum_adi_2
                    when ps_lang = 'kg' and kurum_adi_3 is not null then
                       kurum_adi_3
                    when ps_lang = 'kg' then
                       kurum_adi_2
                    when ps_lang = 'tr' and kurum_adi_4 is not null then
                       kurum_adi_4
                    else
                       kurum_adi
               end name,
               case 
                 when ps_group_code = 'UTILITY SERVICES' then
                     pkg_soa_common.text_translation('Service number', ps_lang)
                 when ps_group_code = 'MOBILE SERVICE' then
                     pkg_soa_common.text_translation('Phone number', ps_lang)
                 when ps_group_code = 'STATE PAYMENTS' and ps_sub_group_code = 'STATE SERVICES' then
                     pkg_soa_common.text_translation('Payment code', ps_lang)
                 when ps_group_code = 'TUITION FEE' and ps_sub_group_code = 'SCHOOL' and kurum_kodu = 'SCHOOL GAZPROM' then
                     pkg_soa_common.text_translation('Identification number', ps_lang)
                 when ps_group_code = 'TUITION FEE' and ps_sub_group_code = 'UNIVERSITY' then
                     pkg_soa_common.text_translation('Payment code', ps_lang)
                 when ps_group_code = 'TUITION FEE' then
                     pkg_soa_common.text_translation('Requisites', ps_lang)
                 when ps_group_code = 'OTHER SERVICES' and ps_sub_group_code = 'OTHER SERVICES' 
                      and (kurum_kodu = 'INTAL LLC FOR RENT' or kurum_kodu = 'INTAL LLC FOR SECURITY' or kurum_kodu = 'INTAL LLC FOR ELECTRICITY') then
                     pkg_soa_common.text_translation('Container', ps_lang)
                 when ps_group_code = 'DEALER SERVICES' and ps_sub_group_code = 'DEALER SERVICES' and kurum_kodu = 'PAY24 ТЕРМИНАЛ - ПОПОЛНЕНИЕ ТЕРМИНАЛЬНОГО СЧЕТА' then
                     pkg_soa_common.text_translation('Enter terminal number', ps_lang)
                 when ps_group_code = 'DEALER SERVICES' and ps_sub_group_code = 'DEALER SERVICES' and kurum_kodu = 'PAY24 АГЕНТ - ПОПОЛНЕНИЕ АГЕНТСКОГО СЧЕТА' then
                     pkg_soa_common.text_translation('Enter the agent''s wallet number', ps_lang)
                 else
                     pkg_soa_common.text_translation('Service or Phone number', ps_lang)
               end placeholder,
               min_digit_number as min_length, 
               max_digit_number as max_length, 
               min_payment_amount as min_amount, 
               max_payment_amount as max_amount,
               case
                 when ps_group_code in ('MOBILE SERVICE') then
                   'true'
                 else
                   'false'
               end is_numeric,
               case
                 when ib_barcode = 'Y' then
                   'true'
                 else
                   'false'
                end barcode
                from cbs_tahsilat_kurum_tanim 
                   where durum_kodu = 'AKTIF' 
                                and ib_visible = 'Y' 
                                and kurum_grup_kod = ps_group_code 
                                and kurum_alt_grup_kod = ps_sub_group_code;
        
    return ls_returncode;
    
EXCEPTION
   when others then
        raise;
END;

FUNCTION GetInstantInsValidation(ps_lang varchar2,
                                 ps_institution_code varchar2,
                                 pc_ref OUT CursorReferenceType) RETURN varchar2
IS 
ls_returncode varchar2(3) := '000';
BEGIN

   log_at('GetInstantInsValidation', ps_institution_code);
   open pc_ref for
        select service_id,
               kurum_kodu as code, 
               case 
                    when ps_lang = 'en' then
                       kurum_adi 
                    when ps_lang = 'ru' then
                       kurum_adi_2
                    when ps_lang = 'kg' and kurum_adi_3 is not null then
                       kurum_adi_3
                    when ps_lang = 'kg' then
                       kurum_adi_2
                    when ps_lang = 'tr' and kurum_adi_4 is not null then
                       kurum_adi_4
                    else
                       kurum_adi
               end name,
               case 
                 when kurum_grup_kod = 'UTILITY SERVICES' then
                     pkg_soa_common.text_translation('Service number', ps_lang)
                 when kurum_grup_kod = 'MOBILE SERVICE' then
                     pkg_soa_common.text_translation('Phone number', ps_lang)
                 when kurum_grup_kod = 'STATE PAYMENTS' and kurum_alt_grup_kod = 'STATE SERVICES' then
                     pkg_soa_common.text_translation('Payment code', ps_lang)
                 when kurum_grup_kod = 'TUITION FEE' and kurum_alt_grup_kod = 'SCHOOL' and kurum_kodu = 'SCHOOL GAZPROM' then
                     pkg_soa_common.text_translation('Identification number', ps_lang)
                 when kurum_grup_kod = 'TUITION FEE' and kurum_alt_grup_kod = 'UNIVERSITY' then
                     pkg_soa_common.text_translation('Payment code', ps_lang)
                 when kurum_grup_kod = 'TUITION FEE' then
                     pkg_soa_common.text_translation('Requisites', ps_lang)
                 when kurum_grup_kod = 'OTHER SERVICES' and kurum_alt_grup_kod = 'OTHER SERVICES' 
                      and (kurum_kodu = 'INTAL LLC FOR RENT' or kurum_kodu = 'INTAL LLC FOR SECURITY' or kurum_kodu = 'INTAL LLC FOR ELECTRICITY') then
                     pkg_soa_common.text_translation('Container', ps_lang)
                 when kurum_grup_kod = 'DEALER SERVICES' and kurum_alt_grup_kod = 'DEALER SERVICES' and kurum_kodu = 'PAY24 ТЕРМИНАЛ - ПОПОЛНЕНИЕ ТЕРМИНАЛЬНОГО СЧЕТА' then
                     pkg_soa_common.text_translation('Enter terminal number', ps_lang)
                 when kurum_grup_kod = 'DEALER SERVICES' and kurum_alt_grup_kod = 'DEALER SERVICES' and kurum_kodu = 'PAY24 АГЕНТ - ПОПОЛНЕНИЕ АГЕНТСКОГО СЧЕТА' then
                     pkg_soa_common.text_translation('Enter the agent''s wallet number', ps_lang)
                 else
                     pkg_soa_common.text_translation('Service or Phone number', ps_lang)
               end placeholder,
               min_digit_number as min_length, 
               max_digit_number as max_length, 
               min_payment_amount as min_amount, 
               max_payment_amount as max_amount,
               case
                 when kurum_grup_kod in ('MOBILE SERVICE') then
                   'true'
                 else
                   'false'
               end is_numeric,
               case
                 when ib_barcode = 'Y' then
                   'true'
                 else
                   'false'
                end barcode
                from cbs_tahsilat_kurum_tanim 
                   where durum_kodu = 'AKTIF' 
                                and ib_visible = 'Y' 
                                and kurum_kodu = ps_institution_code;
        
        
    return ls_returncode;
    
EXCEPTION
   when others then
       raise;
END;
                    
FUNCTION GetInstantInsNumberExtensions(ps_lang varchar2,
                                       ps_institution_code varchar2,
                                       pc_ref OUT CursorReferenceType) RETURN varchar2
IS 
ls_returncode varchar2(3) := '000';
BEGIN

   open pc_ref for
          select service_kodu as code from cbs_tahsilat_kurum_service_kod where gecerlimi = 'E' 
                            and kurum_kodu = ps_institution_code
          union               
          select alan_kodu as code from cbs_tahsilat_kurum_telalan_kod  where gecerlimi = 'E' 
                                    and kurum_kodu = ps_institution_code;
        
    return ls_returncode;
    
EXCEPTION
   when others then
       raise;
END;

FUNCTION GetInstantInstitutionBarCode(pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
          select kurum_kodu as code
                from cbs_tahsilat_kurum_tanim 
                   where durum_kodu = 'AKTIF' 
                                and ib_visible = 'Y'
                                and ib_barcode = 'Y' ;
        
    return ls_returncode;
    
EXCEPTION
   when others then
       raise;
END;

FUNCTION GetInstantInsServiceNumber(ps_institution_code varchar2) RETURN varchar2
IS
ls_service_number varchar2(500);
BEGIN

          select service_id into ls_service_number
                from cbs_tahsilat_kurum_tanim 
                   where durum_kodu = 'AKTIF' 
                                and ib_visible = 'Y'
                                and kurum_kodu = ps_institution_code;
        
    return ls_service_number;
    
EXCEPTION
   when no_data_found then
       return null;
   when others then
       raise;
END;

FUNCTION GetPayInstCommission(ps_institution_code varchar2,
                              ps_amount varchar2,
                              ps_commission_type_bank OUT varchar2,
                              ps_commission_type_company OUT varchar2,
                              pn_commission_amount_bank OUT number,
                              pn_commission_amount_company OUT number,
                              pn_commission_rate_bank OUT number,
                              pn_commission_rate_company OUT number) RETURN VARCHAR2 IS
ln_amount number := 0;
ln_bank_commission number := 0; 
ln_company_commission number := 0; 

cursor kt_commission
is
   select    a.kurum_kodu,
               a.use_intervals_for_company,
               a.use_intervals_for_bank,
               a.commission_type_bank,
               a.commission_type_company,
               a.commission_rate_bank,
               a.commission_rate_company,
               a.commission_amount_bank,
               a.commission_amount_company
     from    cbs_tahsilat_kurum_tanim a
    where    a.kurum_kodu = ps_institution_code;

cursor kti_commission (for_type varchar2)
is
    select *
      from    cbs_usip_commission_amount a
         where a.company_id = ps_institution_code
                    and a.begining_amount <= ln_amount
                    and a.ending_amount >= ln_amount
                    and a.commission_type_for = for_type;

ktr_commission kt_commission%rowtype;
ktir_commission kti_commission%rowtype;
ls_returncode varchar2 (3) := '000';
BEGIN

    ln_amount := to_number (replace (ps_amount, ',', ''), '99999999999.99');

    open kt_commission;

    fetch kt_commission into ktr_commission;

    close kt_commission;

    if ktr_commission.use_intervals_for_bank = 'E' then
    
        open kti_commission('BANK');

        fetch kti_commission into ktir_commission;

        if kti_commission%found then
            if ktir_commission.commission_type = 'RATE' then
                ln_bank_commission := (ktir_commission.commission_rate * ln_amount) / 100;
            else
                ln_bank_commission := ktir_commission.commission_amount;
            end if;
        end if;

        close kti_commission;
        
    else
        if ktr_commission.commission_type_bank = 'RATE' then
            ln_bank_commission := (ktr_commission.commission_rate_bank * ln_amount) / 100;
        else
            ln_bank_commission := ktr_commission.commission_amount_bank;
        end if;
    end if;

    if ktr_commission.use_intervals_for_company = 'E' then
    
        open kti_commission('COMPANY');

        fetch kti_commission into ktir_commission;

        if kti_commission%found then
            if ktir_commission.commission_type = 'RATE' then
                ln_company_commission := (ktir_commission.commission_rate * ln_amount) / 100;
            else
                ln_company_commission := ktir_commission.commission_amount;
            end if;
        end if;

        close kti_commission;
    else
        if ktr_commission.commission_type_company = 'RATE' then
            ln_company_commission := (ktr_commission.commission_rate_company * ln_amount) / 100;
        else
            ln_company_commission := ktr_commission.commission_amount_company;
        end if;
    end if;

    ps_commission_type_bank := ktr_commission.commission_type_bank;
    ps_commission_type_company := ktr_commission.commission_type_company;
    pn_commission_amount_bank :=  nvl(ln_bank_commission, 0);
    pn_commission_amount_company := nvl(ln_company_commission, 0);
    pn_commission_rate_bank := ktr_commission.commission_rate_bank;
    pn_commission_rate_company := ktir_commission.commission_rate;

    return ls_returncode;
    
EXCEPTION
    when others then
        log_at('newib','GetPayInstCommission', sqlerrm, dbms_utility.format_error_backtrace);
        raise;
END;

--pkg_soa_inquiry CALCULATE_IP_COMMISSION

FUNCTION GetInstantInstitutionPayment(ps_lang varchar2,
                                      ps_iban varchar2,
                                      ps_institution_code varchar2,
                                      ps_ins_number_extension_code varchar2,
                                      ps_institution_account_number varchar2,
                                      ps_amount varchar2,
                                      ps_description varchar2,  
                                      pc_ref OUT CursorReferenceType,
                                      pc_ref2 OUT CursorReferenceType,
                                      pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS
ls_commission_type_bank varchar2 (10);
ls_commission_type_company varchar2 (10);
ln_commission_amount_bank number;
ln_commission_amount_company number;
ln_commission_rate_bank number;
ln_commission_rate_company number;

ln_initial_balance number;
ln_final_balance number;
ln_account number;
ln_customer number;

ls_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);

ln_amount number;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_count_mobile number;
ln_count_service number;
ln_min_digit_number number;
ln_max_digit_number number;
ln_min_payment_amount number;
ln_max_payment_amount number;

ls_returncode varchar2 (3) := '000';

notenoughbalance exception;
error_number_extension exception;
BEGIN

   select hesap_no, musteri_no, doviz_kodu, sube_kodu
      into ln_account, ln_customer, ls_currency_code, ls_branch_code
          from cbs_hesap where external_hesap_no = ps_iban;
          
     select min_digit_number, 
            max_digit_number, 
            min_payment_amount, 
            max_payment_amount
          into 
            ln_min_digit_number,
            ln_max_digit_number,
            ln_min_payment_amount,
            ln_max_payment_amount
          from cbs_tahsilat_kurum_tanim 
                   where durum_kodu = 'AKTIF' 
                                and ib_visible = 'Y' 
                                and kurum_kodu = ps_institution_code;
                                
     
    if length(ps_institution_account_number) < ln_min_digit_number or length(ps_institution_account_number) > ln_max_digit_number then 
        return '459';
    end if;
           
    ln_amount := to_number(ps_amount,'999999999999999.9999');
    
    if ln_amount < ln_min_payment_amount or ln_amount > ln_max_payment_amount then
        return '460';
    end if;
   
    if ps_ins_number_extension_code is not null then
         select count(*) into ln_count_mobile from cbs_tahsilat_kurum_telalan_kod where kurum_kodu = ps_institution_code
                      and alan_kodu = ps_ins_number_extension_code;
                      
         select count(*) into ln_count_service from cbs_tahsilat_kurum_service_kod where kurum_kodu = ps_institution_code
                      and service_kodu = ps_ins_number_extension_code;
     
         if ln_count_mobile = 0 and ln_count_service = 0 then
           raise error_number_extension;
         end if;
    end if;

    ls_returncode := GetPayInstCommission(ps_institution_code => ps_institution_code,
                               ps_amount => ps_amount, 
                               ps_commission_type_bank => ls_commission_type_bank,
                               ps_commission_type_company => ls_commission_type_company,
                               pn_commission_amount_bank => ln_commission_amount_bank,
                               pn_commission_amount_company => ln_commission_amount_company,
                               pn_commission_rate_bank => ln_commission_rate_bank,
                               pn_commission_rate_company => ln_commission_rate_company);
                               
    ln_commission_amount := ln_commission_amount_bank + ln_commission_amount_company;
   
    ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_account); 
                                                                      
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
     if ln_final_balance < 0 then
         raise notenoughbalance;
     end if;
     
     if ln_commission_amount_bank > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount_bank * ln_tax_rate / 100;
     else
       ln_tax_rate := 0;
       ln_tax := 0;   
     end if;  
     
    
     open pc_ref for   
        select ln_amount as amount,
                ls_currency_code as currency_code, 
                ln_initial_balance as initial_balance, 
                ln_final_balance as final_balance,          
                sysdate as transaction_date from dual;
     
     open pc_ref2 for 
            select 
               'commission' as name, 
               'bank' as client, 
               ln_commission_amount_bank + ln_commission_amount_company - ln_tax as amount, 
               pkg_genel.lc_al as currency_code from dual
--          union
--           select 
--               'commission' as name, 
--               'dealer' as client, 
--               ln_commission_amount_company as amount, 
--               pkg_genel.lc_al as currency_code from dual
         union
           select 
               'tax' as name, 
               'bank' as client, 
               ln_tax as amount, 
               pkg_genel.lc_al as currency_code from dual;
               
     open pc_ref3 for
           select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;   

    return ls_returncode;
    
EXCEPTION
    when notenoughbalance then
         rollback;
         return '456';
    when error_number_extension then
         rollback;
         return '455';
    when no_data_found then
         rollback;
         return '454';  
    when others then
         log_at('GetInstantInstitutionPayment', ps_iban, sqlerrm, dbms_utility.format_error_backtrace);
         raise;
END;

FUNCTION GetPay24ErrorCode(ps_transaction_number varchar2) RETURN varchar2
IS
ls_result_code varchar2(100 char);
BEGIN

   select resultcode into ls_result_code 
            from cbs_usip_ws_call_log 
               where transaction_number = ps_transaction_number
                     and tran_type = 'makeWSPaymentRequest';
               
        return ls_result_code;
 
EXCEPTION  
    when too_many_rows then
         return null; 
    when no_data_found then
         return null;  
    when others then
         raise;
END;
FUNCTION GetIntalLlc(ps_row_number varchar2,
                     ps_container_number varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ln_name_count number;
notfoundname exception;
BEGIN

    select count(*) into ln_name_count from cbs.cbs_intal_llc
            where rownumber = ps_row_number 
                  and containernumber = ps_container_number;
    
    if ln_name_count != 1 then
        raise notfoundname;
    end if;
    
    open pc_ref for
        select PKG_INT_CUSTOMER_INQ.GetMaskedName(name) as name from cbs_intal_llc
             where rownumber = ps_row_number 
                   and containernumber = ps_container_number;
    
    return '000';
    
EXCEPTION
    when notfoundname then
      log_at('GetIntalLlc','notFoundName', sqlerrm, dbms_utility.format_error_backtrace);
      return '454';
    when others then
      log_at('GetIntalLlc','OTHERS', sqlerrm, dbms_utility.format_error_backtrace);
      raise;
END;
FUNCTION GetIntalLlcIban(ps_institution_code varchar2) RETURN varchar2 
IS
ln_account number;
ls_external varchar2(16 byte);
BEGIN

   select kurum_hesap_no into ln_account from cbs.cbs_tahsilat_kurum_tanim
        where kurum_kodu = ps_institution_code;


   select external_hesap_no into ls_external from cbs.cbs_hesap
        where hesap_no = ln_account;

    return ls_external;
    
EXCEPTION
    when no_data_found then
        log_at('GetIntalLlcIban',ps_institution_code || ' ' || ln_account, sqlerrm, dbms_utility.format_error_backtrace);
        return null;
    when others then
        log_at('GetIntalLlcIban','OTHERS', sqlerrm, dbms_utility.format_error_backtrace);
        raise;
END;

FUNCTION GetTaxTypes(ps_lang varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select param_val as code, 
               explanation as name,
               case
                 when param_val='1520;11312200' then
                     'true'
                 else
                     'false'
               end vehicle_plate,
               case
                 when param_val='1520;11312200' then
                     '0-9a-zA-Z'
                 else
                     null
               end pattern
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_TYPE'
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG');
    
    return ls_returncode;
    
EXCEPTION
   when others then
          raise;
END;


FUNCTION GetTaxRegions(ps_lang varchar2,
                       pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select param_val as code, 
               explanation as name 
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_REGION'
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG');
    
    return ls_returncode;
    
EXCEPTION
   when others then
        raise;
END;

FUNCTION GetTaxDistricts(ps_lang varchar2,
                         ps_region_code varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select param_val as code, 
               explanation as name 
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_DISTRICT'
                           and parent_code = ps_region_code
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG');
    
    return ls_returncode;
    
EXCEPTION
   when others then
        raise;
END;


FUNCTION GetTaxSubDistricts(ps_lang varchar2,
                         ps_district_code varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select param_val as code, 
               explanation as name 
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_SUB_DISTRICT'
                           and parent_code = ps_district_code
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG');
    
    return ls_returncode;
    
EXCEPTION
   when others then
         raise;
END;

FUNCTION GetTaxTypeName(ps_lang varchar2, ps_code varchar2) RETURN varchar2
IS
ls_returncode varchar2(500 CHAR);
BEGIN

        select explanation into ls_returncode
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_TYPE'
                           and param_val = ps_code
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG')
                           and rownum < 2;
    
    return ls_returncode;
    
EXCEPTION
   when no_data_found then
        return null;
   when others then
        raise;
END;


FUNCTION GetTaxRegionName(ps_lang varchar2, ps_code varchar2) RETURN varchar2
IS
ls_returncode varchar2(500 CHAR);
BEGIN

        select explanation into ls_returncode
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_REGION'
                           and param_val = ps_code
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG')
                           and rownum < 2;
    
    return ls_returncode;
    
EXCEPTION
   when no_data_found then
        return null;
   when others then
         raise;
END;

FUNCTION GetTaxDistrictName(ps_lang varchar2, ps_code varchar2) RETURN varchar2
IS
ls_returncode varchar2(500 CHAR);
BEGIN

        select explanation into ls_returncode
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_DISTRICT'
                           and param_val = ps_code
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG')
                           and rownum < 2;
    
    return ls_returncode;
    
EXCEPTION
   when no_data_found then
          return null;
   when others then
          raise;
END;


FUNCTION GetTaxSubDistrictName(ps_lang varchar2, ps_code varchar2) RETURN varchar2
IS
ls_returncode varchar2(500 CHAR);
BEGIN

        select explanation into ls_returncode
                  from corpint.tbl_int_parametre 
                     where param_code = 'TAX_SUB_DISTRICT'
                           and param_val = ps_code
                           and status_cd = 'sENAB'
                           and lang_cd = decode(ps_lang, 'ru', 'RUS', 'ENG');
    
    return ls_returncode;
    
EXCEPTION
   when no_data_found then
        return null;
   when others then
        raise;
END;


FUNCTION GetWsTaxInfo(ps_tax_number varchar2,
                      pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ls_returncode VARCHAR2(3) := '000';

--ws variables
serviceUrl VARCHAR2(300);
soapAction VARCHAR2(100);
namespace VARCHAR2(100);
methodName VARCHAR2(100);
req pkg_soap.request;
resp pkg_soap.response;
result CLOB;

l_parser  dbms_xmlparser.Parser;
l_doc     dbms_xmldom.DOMDocument;
l_nl      dbms_xmldom.DOMNodeList;
l_n       dbms_xmldom.DOMNode;

ls_osmp_txn_id VARCHAR2(100);
ls_result VARCHAR2(100);
ls_comment VARCHAR2(100);
ls_field1 VARCHAR2(100);
ls_field2 VARCHAR2(100);

url_web VARCHAR2(200 CHAR);
BEGIN

    pkg_parametre.deger('TAX_SERVICE_URL', url_web);
    serviceUrl := url_web;

    BEGIN
        namespace := 'http://services.demirbank.kg/';
        methodName := 'CheckLocTax';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);

        --add parameters to request
        Pkg_Soap.add_parameter(req, 'tin', 'xsd:string', ps_tax_number);

        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
        result := resp.doc.getstringval();
        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newParser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getDocument(l_parser);
        l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'CheckLocTaxResponse/CheckLocTaxResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueOf(l_n,'response/osmp_txn_id',ls_osmp_txn_id);
        dbms_xslprocessor.valueOf(l_n,'response/result',ls_result);
        dbms_xslprocessor.valueOf(l_n,'response/comment',ls_comment);
        dbms_xslprocessor.valueOf(l_n,'response/fields/field1',ls_field1);
        dbms_xslprocessor.valueOf(l_n,'response/fields/field2',ls_field2);

        OPEN pc_ref FOR
            SELECT ls_osmp_txn_id as transaction_no, ls_result as tax_result, ls_comment as commentary, ls_field1 as sur_name, ls_field2 as tax_category FROM DUAL;

    EXCEPTION
        when others then 
            log_at('getWsTaxInfo', result, dbms_utility.format_error_backtrace);
            raise;
    END;

    return ls_returncode;
    
END;

FUNCTION GetTaxPayment(ps_lang varchar2,
                       ps_iban varchar2,
                       ps_tax_number varchar2, 
                       ps_type_code varchar2,
                       ps_region_code varchar2,
                       ps_district_code varchar2,
                       ps_sub_district_code varchar2,
                       ps_vehicle_plate varchar2,
                       ps_amount varchar2,
                       pc_ref OUT CursorReferenceType,
                       pc_ref2 OUT CursorReferenceType,
                       pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS
ls_sur_name varchar2(200);
ls_ws_osmp_txn_id varchar2(100);
ls_ws_result varchar2(100);
ls_ws_comment varchar2(100);
ls_ws_field1 varchar2(100);
ls_ws_field2 varchar2(100); 

ln_transaction_number number;
ln_transaction_code number;  
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);

ln_cash_code number; 
ln_initial_balance number;
ln_final_balance number;
ln_source_account number;
ln_source_customer number;
ls_source_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ln_amount number;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_real_amount number := 0;
ls_description varchar2(500);

pc_result1 CursorReferenceType;
pc_result2 CursorReferenceType;
pc_ref_local CursorReferenceType;

ls_returncode varchar2(3) := '000';

notenoughbalance exception;
daterror exception;
no_data_found_from_ws exception;
BEGIN


   ln_transaction_number := pkg_tx.islem_no_al;
   ln_transaction_code := 3555;
   
    ls_returncode := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', pc_result1);

    if (ls_returncode <> '000') then
        raise daterror;
    end if;
    
    
     select hesap_no, musteri_no, doviz_kodu, sube_kodu
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code
          from cbs_hesap where external_hesap_no = ps_iban;
       
    ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
   
    ln_amount := to_number(ps_amount,'999999999999999.9999');
   
    ls_returncode := PKG_INT_PAYMENT_INQ.GetWsTaxInfo(ps_tax_number, pc_ref_local);
        
     if ls_returncode <> '000' then
        raise no_data_found_from_ws;
     end if; 
                                        
     loop
        fetch pc_ref_local into 
                ls_ws_osmp_txn_id,
                ls_ws_result,
                ls_ws_comment,
                ls_ws_field1,
                ls_ws_field2;
        exit when pc_ref_local%notfound;  
     end loop;
     close pc_ref_local;   
    
     if ls_ws_field1 is not null then
        ls_sur_name := ls_ws_field1;
     else
        raise no_data_found_from_ws;
     end if;
    
    pkg_parametre.deger('G_RIBCLEARING_MODUL_TYPE', ls_module_type_code);
    pkg_parametre.deger('G_RIBCLEARING_PRODUCT_TYPE', ls_product_type_code);
    ls_product_class_code := 'RIBTAXPAY';
    
    ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, ln_transaction_code, ls_module_type_code, ls_product_type_code, ls_product_class_code,
                               ln_amount, ls_branch_code, ls_source_currency_code, ln_source_customer, ln_source_account, ln_cash_code);
    
      if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
    else
       ln_tax_rate := 0;
       ln_tax := 0;   
    end if;
    
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
    if ln_final_balance < 0 then
        raise notenoughbalance;
    end if;
                
    ls_description := GetTaxTypeName(ps_lang, ps_type_code) || ' '  || GetTaxRegionName(ps_lang, ps_region_code) || ' '  || GetTaxDistrictName(ps_lang, ps_district_code) || ' '  || GetTaxSubDistrictName(ps_lang, ps_sub_district_code) || ' ' || ps_vehicle_plate;
    
    
     open pc_ref for   
        select ln_amount as amount,
                ls_source_currency_code as currency_code, 
                ln_initial_balance as initial_balance, 
                ln_final_balance as final_balance,  
                sysdate as transaction_date,
                ls_sur_name as target_full_name,
                ls_description  as description  from dual;
     
     open pc_ref2 for 
        select 'commission' as name, 
               'bank' as client, 
               ln_commission_amount as amount,
               pkg_genel.lc_al as currency_code from dual
        union
        select 'tax' as name, 
               'bank' as client, 
               ln_tax as amount,
               pkg_genel.lc_al as currency_code from dual;
               
     open pc_ref3 for
         select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) - ln_real_amount as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;  
                        
           return ls_returncode;
           
EXCEPTION
      when notenoughbalance then
             return '456';
      when no_data_found_from_ws then
             return '460';
      when daterror then
             return '461';
      when others then 
           log_at('GetTaxPayment', ps_iban, dbms_utility.format_error_backtrace);
           raise;
END;                                          
END;
/

