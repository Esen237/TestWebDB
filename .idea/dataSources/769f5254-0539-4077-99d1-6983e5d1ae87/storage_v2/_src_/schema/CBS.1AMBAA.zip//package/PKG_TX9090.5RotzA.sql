create PACKAGE     PKG_TX9090 IS

 /******************************************************************************
   Name       : PKG_TX9090
   Created By : Chyngyz O.
   Date          : 26.09.2013
   Purpose      : Customer Linkage to Direct Crediting Service (for Coca-Cola Project)
******************************************************************************/
  TYPE GenCurType IS REF CURSOR;

  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir
  
  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir
  
  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  
  Procedure Add_Subscriber(pn_dcs_customer_id CBS_DCS_CUSTOMER_ACCOUNTS.ID%TYPE,
                                                  pn_subscriber_no CBS_DCS_SUBSCRIBER_ACCOUNTS.SUBS_CUST_NO%TYPE,
                                                  pn_subscriber_acc_no CBS_DCS_SUBSCRIBER_ACCOUNTS.SUBS_ACC_NO%TYPE,
                                                  pc_status CBS_DCS_SUBSCRIBER_ACCOUNTS.STATUS%TYPE,
                                                  ps_partial_payment varchar2, --CQ4480
                                                  pn_tx_no number); --Called to add new subscriber
  
  Procedure Get_Subscribers(pn_cust_no IN CBS_MUSTERI.MUSTERI_NO%TYPE, 
                                                     pn_cust_acc_no CBS_HESAP.HESAP_NO%TYPE,  pRetCur IN OUT GenCurType); -- Called to fetch cursor for related customers
  
  Procedure Not_Completed_Tx_Exists(pn_cust_no  CBS_DCS_CUSTOMER_ACCOUNTS.CUST_NO%TYPE, pn_cust_acc_no CBS_DCS_CUSTOMER_ACCOUNTS.ACC_NO%TYPE);
  
END;

/

