create PACKAGE BODY PKG_SENET IS

-------------------------------------------------------------------------------------
 Function Sf_Senet_Tahsil_Tarihi_Al( ps_bolum_kodu cbs_senet_tahsil.bolum_kodu%type,pn_senet_no cbs_senet_tahsil.senet_no%type) return cbs_senet_tahsil.tahsil_tarihi%type
   is
     ld_tahsil_tarihi cbs_senet_tahsil.tahsil_tarihi%type;
   Begin

	  select tahsil_tarihi
	  into  ld_tahsil_tarihi
	  from  cbs_senet_tahsil
	  where bolum_kodu = ps_bolum_kodu
	  and senet_no=pn_senet_no;

    return ld_tahsil_tarihi;

    exception
    	when no_data_found then
          return NULL;
 End Sf_Senet_Tahsil_Tarihi_Al;
-------------------------------------------------------------------------------------

 Function Sf_Senet_Tahsil_TxNo_Al( ps_bolum_kodu cbs_senet_tahsil.bolum_kodu%type,pn_senet_no cbs_senet_tahsil.senet_no%type) return cbs_senet_tahsil.tx_no%type
   is
     ln_tx_no cbs_senet_tahsil.tx_no%type;
   Begin

	  select tx_no
	  into  ln_tx_no
	  from  cbs_senet_tahsil
	  where bolum_kodu = ps_bolum_kodu
	  and senet_no=pn_senet_no;

    return ln_tx_no;

    exception
    	when no_data_found then
          return NULL;

 End Sf_Senet_Tahsil_TxNo_Al;
-------------------------------------------------------------------------------------
 Function Sf_Senet_Kabul_Tarihi_Al( ps_bolum_kodu cbs_senet_kabul.bolum_kodu%type,pn_senet_no cbs_senet_kabul.senet_no%type) return cbs_senet_kabul.kabul_tarihi%type
   is
     ld_kabul_tarihi cbs_senet_kabul.kabul_tarihi%type;
   Begin

	  select kabul_tarihi
	  into  ld_kabul_tarihi
	  from  cbs_senet_kabul
	  where bolum_kodu = ps_bolum_kodu
	  and senet_no=pn_senet_no;

    return ld_kabul_tarihi;

 exception
    when no_data_found then
         return NULL;

 End Sf_Senet_Kabul_Tarihi_Al;
-------------------------------------------------------------------------------------
 Function Sf_Senet_Cikis_Tarihi_Al( ps_bolum_kodu cbs_senet_cikis.bolum_kodu%type,pn_senet_no cbs_senet_cikis.senet_no%type) return cbs_senet_cikis.cikis_tarihi%type
   is
     ld_cikis_tarihi cbs_senet_cikis.cikis_tarihi%type;
   Begin

	  select cikis_tarihi
	  into  ld_cikis_tarihi
	  from  cbs_senet_cikis
	  where bolum_kodu = ps_bolum_kodu
	  and senet_no=pn_senet_no;

    return ld_cikis_tarihi;

 exception
    when no_data_found then
         return NULL;

 End Sf_Senet_Cikis_Tarihi_Al;

-------------------------------------------------------------------------------------
 Function Sf_Senet_Cikis_TxNo_Al( ps_bolum_kodu cbs_senet_cikis.bolum_kodu%type,pn_senet_no cbs_senet_cikis.senet_no%type) return cbs_senet_cikis.tx_no%type
   is
     ln_tx_no cbs_senet_cikis.tx_no%type;
   Begin

	  select tx_no
	  into  ln_tx_no
	  from  cbs_senet_cikis
	  where bolum_kodu = ps_bolum_kodu
	  and senet_no=pn_senet_no;

    return ln_tx_no;

    exception
    	when no_data_found then
          return NULL;


 End Sf_Senet_cikis_TxNo_Al;

 ----------------------------------------------------------------------------------------------------------
   Procedure SenetBilgiAktar(ps_bolum_kodu IN cbs_senet.bolum_kodu%TYPE,pn_senet_no IN NUMBER,pn_txno IN NUMBER) is
  BEGIN
  	    insert into cbs_senet_duzeltme
			(TX_NO,MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, TAHSIL_MUSTERI_NO, TAHSIL_HESAP_NO, TEMINAT_NO, TEMINAT_ALACAK_HESAP_NO, BOLUM_KODU, SENET_NO, MUSTERI_SENET_NO, DOVIZ_KODU, SENET_TUTARI, VADE_TARIHI, BORCLU_ADI, BORCLU_ADRESI, BORCLU_POSTA_KODU, ILCE_KODU, IL_KODU, TALIMAT_KODU, MBANKA_MUSTERI_NO, MBANKA_HESAP_NO, KARSI_SUBE_KODU, SENET_TEMINAT_TURU, KEFIL_ADEDI, MASRAF_HESAP_NO, DURUM_KODU, SENET_GIRIS_TARIHI)
			select pn_txno,MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, TAHSIL_MUSTERI_NO, TAHSIL_HESAP_NO, TEMINAT_NO, TEMINAT_ALACAK_HESAP_NO, BOLUM_KODU, SENET_NO, MUSTERI_SENET_NO, DOVIZ_KODU, SENET_TUTARI, VADE_TARIHI, BORCLU_ADI, BORCLU_ADRESI, BORCLU_POSTA_KODU, ILCE_KODU, IL_KODU, TALIMAT_KODU, MBANKA_MUSTERI_NO, MBANKA_HESAP_NO, KARSI_SUBE_KODU, SENET_TEMINAT_TURU, KEFIL_ADEDI, MASRAF_HESAP_NO, DURUM_KODU, SENET_GIRIS_TARIHI
			from cbs_senet
			where bolum_kodu=ps_bolum_kodu
				  and senet_no=pn_senet_no;

		insert into cbs_teminat_islem
			  (TX_NO, TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO, TEMINAT_HESAP_NO, TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI, KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU, TEMINAT_DURUMU, CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, REF_CEK_NO, BOLUM_KODU, SENET_NO)
			  select pn_txno, TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO, TEMINAT_HESAP_NO, TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI, KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU, TEMINAT_DURUMU, CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, REF_CEK_NO, BOLUM_KODU, SENET_NO
			  from cbs_teminat
			  where bolum_kodu=ps_bolum_kodu
				  and senet_no=pn_senet_no;
  END;
 ----------------------------------------------------------------------------------------------------------
  Function  TeminatGirilmis (pn_txno NUMBER) return boolean is
  ln_count	NUMBER;
  BEGIN
  	   select count(*)
	   into ln_count
	   from cbs_teminat_islem
	   where tx_no=pn_txno;

	   if ln_count=0 then
	   	  return false;
	   else
	   	   return true;
	   end if;

  exception
	   when no_data_found then
  		return false;
  END;
 ----------------------------------------------------------------------------------------------------------

 /***************************************************************************************************************/
 /*   Procedure sp_senet_tahsiltemin_guncelle   																 */
 /*   Teminat olarak kullan?lan senetler teminat t?r? alan?n?n guncellenmesinde kullan?l?r.                      */
 /***************************************************************************************************************/
 procedure sp_senet_tahsiltemin_guncelle ( ps_bolum_kodu cbs_senet.bolum_kodu%type, pn_senet_no cbs_senet.senet_no%type ,ps_tahsil_teminat cbs_senet.urun_tur_kod%type)
  IS
   BEGIN
        update  cbs_senet
        set urun_tur_kod = ps_tahsil_teminat
        WHERE bolum_kodu = ps_bolum_kodu and
			  senet_no =pn_senet_no ;

   EXCEPTION
      WHEN OTHERS   THEN
	  raise_application_error (-20100, pkg_hata.getucpointer || '539' || pkg_hata.getdelimiter || TO_CHAR (SQLCODE)  || ' '  || SQLERRM || pkg_hata.getdelimiter || pkg_hata.getucpointer );

   END;

 /***************************************************************************************************************/
 /*   Function sf_senet_durumu_al 																 */
 /***************************************************************************************************************/
  Function sf_senet_durumu_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  pn_senet_no     cbs_senet.senet_no%TYPE) return cbs_senet.DURUM_KODU%type

  is
  ls_durum_kodu   cbs_senet.durum_kodu%type;
  Begin
	   select durum_kodu
	   into  ls_durum_kodu
	   from  cbs_senet
	   where bolum_kodu =ps_bolum_kodu and
	   		 senet_no =pn_senet_no;

	  return ls_durum_kodu;

   Exception
      when no_data_found then return null;
      when others then
  	     raise_application_error (-20100, pkg_hata.getucpointer || '541' || pkg_hata.getdelimiter|| ps_bolum_kodu || '-' ||to_char(pn_senet_no) ||  pkg_hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

 End ;

 /***************************************************************************************************************/
 /*     Function sf_senet_tutari_al															 */
 /***************************************************************************************************************/
   Function sf_senet_tutari_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  pn_senet_no     cbs_senet.senet_no%TYPE) return cbs_senet.DURUM_KODU%type

  is
  ln_tutar					  number := 0;
  Begin
	   select senet_tutari
	   into  ln_tutar
	   from  cbs_senet
	   where bolum_kodu =ps_bolum_kodu and
	   		 senet_no =pn_senet_no;

	  return ln_tutar;

   Exception
      when no_data_found then return 0;
      when others then
  	     raise_application_error (-20100, pkg_hata.getucpointer || '541' || pkg_hata.getdelimiter|| ps_bolum_kodu || '-' ||to_char(pn_senet_no) ||  pkg_hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

 End ;

 /***************************************************************************************************************/
 /*     Function sf_senet_vadetarihi_al														 */
 /***************************************************************************************************************/
  Function sf_senet_vadetarihi_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  	  pn_senet_no     cbs_senet.senet_no%TYPE) return date
  is
  ld_vade_tarihi date := null;
  Begin
	   select vade_tarihi
	   into  ld_vade_tarihi
	   from  cbs_senet
	   where bolum_kodu =ps_bolum_kodu and
	   		 senet_no =pn_senet_no;

	  return ld_vade_tarihi;

   Exception
      when no_data_found then return null;
      when others then
  	     raise_application_error (-20100, pkg_hata.getucpointer || '541' || pkg_hata.getdelimiter|| ps_bolum_kodu || '-' ||to_char(pn_senet_no) ||  pkg_hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
  End;

 /***************************************************************************************************************/
 /*     Function sf_senet_teminat_turu_al														 */
 /***************************************************************************************************************/
 Function sf_senet_teminat_turu_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  	    pn_senet_no     cbs_senet.senet_no%TYPE) return varchar2
  is
  ls_senet_tur cbs_senet.senet_teminat_turu%type := null;
  Begin
	   select senet_teminat_turu
	   into  ls_senet_tur
	   from  cbs_senet
	   where bolum_kodu =ps_bolum_kodu and
	   		 senet_no =pn_senet_no;

	  return ls_senet_tur;

   Exception
      when no_data_found then return null;
      when others then
  	     raise_application_error (-20100, pkg_hata.getucpointer || '541' || pkg_hata.getdelimiter|| ps_bolum_kodu || '-' ||to_char(pn_senet_no) ||  pkg_hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
  End;
END;
/

