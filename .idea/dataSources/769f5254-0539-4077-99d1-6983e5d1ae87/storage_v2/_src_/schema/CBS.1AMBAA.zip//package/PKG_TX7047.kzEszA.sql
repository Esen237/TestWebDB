create PACKAGE Pkg_Tx7047 IS
/******************************************************************************
Name       : Pkg_Tx7047
Created By : Hakan SAMSA, 20061211
Purpose	  : Charge Fee Criterias
******************************************************************************/
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 	-- Islem giris kontrolden gectikten sonra cagrilir

PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edildikten sonra cagrilir

PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem onaylandiktan sonra cagrilir
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);	-- Islem reddedildikten sonra cagrilir

PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);		-- Islem tamamlandiktan sonra cagrilir
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  	-- Isleme iliskin formlar basildiktan sonra cagrilir
PROCEDURE Muhasebelesme(pn_islem_no NUMBER);		-- Islemin muhasebelesmesi icin cagrilir

PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
PROCEDURE BilgiAktar(pn_txno IN NUMBER) ;
FUNCTION ekstre_siklik_aciklama_al(pn_kod number) RETURN VARCHAR2 ;
FUNCTION musteri_tipi_ind_corp(pn_musteri number) RETURN VARCHAR2 ;
FUNCTION hesap_hareket_gormusmu(pn_hesap number, pd_date1 date, pd_date2 date) RETURN VARCHAR2 ;
FUNCTION hesap_bakiye_goreceli(pn_hesap number, ps_dvz varchar2) RETURN number ;
FUNCTION int_tran_type(pn_musteri number) RETURN VARCHAR2 ;
FUNCTION Karttan_Musteri_Bul(ps_kart varchar2) RETURN number ;
FUNCTION Sube_Zorunlu_mu(ps_charge_code varchar2) RETURN varchar2 ;
FUNCTION charge_code_uygun_mu(ps_charge_code varchar2) RETURN varchar2;
Function Sf_Onay_Bekleyen_Varmi( pn_tx_no cbs_islem.numara%type ,pn_islem_tanim_kod  cbs_islem.islem_kod%type default 7047) return cbs_cek_islem.tx_no%type;
FUNCTION month_name(pn_month number) RETURN varchar2;
END;


/

