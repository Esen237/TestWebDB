create package body     "PKG_DK" is
    g_uc_delimiter    constant varchar2(3) := pkg_hata.getucpointer;
    g_ara_delimiter   constant varchar2(3) := pkg_hata.getdelimiter;
    function isim_al(pc_bolum_kodu in varchar2, pc_numara in varchar2, pc_doviz_kod varchar2)
        return varchar2 is
        pc_aciklama   varchar2(1000);
    begin
        select aciklama
        into pc_aciklama
        from cbs_dkhesap
        where bolum_kodu = pc_bolum_kodu and numara = pc_numara and doviz_kod = pc_doviz_kod;
        return pc_aciklama;
    exception
        when no_data_found then
            raise_application_error(-20100, g_uc_delimiter || '2204' || g_ara_delimiter || pc_bolum_kodu || '-' || pc_numara || '-' || pc_doviz_kod || g_uc_delimiter);
        when others then
            raise_application_error(-20100, g_uc_delimiter || '2205' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
    end;
    function ust_hesap_mi(p_bolum_kodu in varchar2, p_numara in varchar2)
        return boolean is
        p_var     boolean;
        cursor custhesap is
            select numara
            from cbs_dkhesap
            where bolum_kodu = p_bolum_kodu and doviz_kod = 'XXX' and numara = p_numara;
        r_satir   custhesap%rowtype;
    begin
        open custhesap;
        fetch custhesap into r_satir;
        if custhesap%notfound then
            p_var   := false;
        else
            p_var   := true;
        end if;
        close custhesap;
        return p_var;
    exception
        when others then
            return true;
    end;
    function ust_hesap_mi_n(p_bolum_kodu in varchar2, p_numara in varchar2)
        return number is
    begin
        if ust_hesap_mi(p_bolum_kodu, p_numara) then
            return 1;
        else
            return 0;
        end if;
    end;
    function musterili_mi(p_bolum_kodu in varchar2, p_numara in varchar2, p_doviz_kod in varchar2)
        return boolean is
        vn_ret   number;
    begin
        select decode(musterili_hesap_mi, 'E', 1, 0)
        into vn_ret
        from cbs_dkhesap
        where numara = p_numara and bolum_kodu = p_bolum_kodu and doviz_kod = p_doviz_kod;
        if vn_ret = 1 then
            return true;
        else
            return false;
        end if;
    exception
        when others then
            raise_application_error(-20100, g_uc_delimiter || '1139' || g_ara_delimiter || p_bolum_kodu || '-' || p_numara || '-' || p_doviz_kod || g_uc_delimiter);
    end;
    --- B-O-M sevalb 21022011 dk bakiye guncelle  Deadlock probleminden dolayi eski hali kapatildi yenisi eklendi.
    /*
        PROCEDURE bakiye_guncelle( p_bolum_kodu         IN VARCHAR2,
                                                          p_numara                  IN VARCHAR2,
                                                          p_doviz_kod             IN VARCHAR2,
                                                          p_tur                     IN VARCHAR2,
                                                          p_tutar                 IN NUMBER,
                                                          p_lc_tutar           IN NUMBER,
                                p_alt_hesap_kontrolu BOOLEAN DEFAULT TRUE
                              )  IS
      -- return codes :
      -- -2140  : Doviz kurus sorgulamda hata
      -- -2150  : Alackli hesap terse donemez. >0,
      -- -2160  : Borclu hesap terse donemez. <0
      -- -2170  : DK Hesap bulunamadi
      -- -2180  : DK Hesap guncellemede hata olustu

      p_borc_bakiye                                CBS_DKHESAP.borc_bakiye%TYPE;                -- Borc/Alacak Kontrolunde kullanildi
      p_alacak_bakiye                       CBS_DKHESAP.alacak_bakiye%TYPE;            -- Borc/Alacak Kontrolunde kullanildi
      p_bakiye                                        CBS_DKHESAP.borc_bakiye%TYPE;                -- Borc/Alacak Kontrolunde kullanildi
      p_Ba_Kod                                        CBS_DKHESAP.Ba_Kod%TYPE;                        -- Borc/Alacak Kontrolunde kullanildi
      p_temp_bakiye                                CBS_DKHESAP.borc_bakiye%TYPE;                -- Borc/Alacak Kontrolunde kullanildi
      p_dk_kod                                        CBS_DKHESAP.dk_kod%TYPE;                        -- Borc/Alacak Kontrolunde kullanildi
      p_lc_borc_bakiye                        CBS_DKHESAP.lc_borc_bakiye%TYPE;
      p_lc_alacak_bakiye                   CBS_DKHESAP.lc_alacak_bakiye%TYPE;
      p_lc_temp_bakiye                        CBS_DKHESAP.lc_borc_bakiye%TYPE;

      p_baslangic_tarihi          CBS_DKHESAP.baslangic_tarihi%TYPE;
      p_bitis_tarihi              CBS_DKHESAP.bitis_tarihi%TYPE;
      p_althesap_mi               CBS_DKHESAP.althesap_mi%TYPE;

      p_sonuc                                            NUMBER;

      vn_number                   NUMBER;

        BEGIN

         IF ust_hesap_mi(p_bolum_kodu,p_numara) THEN
           SELECT baslangic_tarihi,bitis_tarihi,althesap_mi,Ba_Kod,NVL(borc_bakiye,0),NVL(alacak_bakiye,0),dk_kod, NVL(lc_borc_bakiye,0), NVL(lc_alacak_bakiye,0)
             INTO p_baslangic_tarihi,p_bitis_tarihi,p_althesap_mi,p_Ba_Kod,p_borc_bakiye,p_alacak_bakiye,p_dk_kod, p_lc_borc_bakiye, p_lc_alacak_bakiye
             FROM CBS_DKHESAP
            WHERE bolum_kodu=p_bolum_kodu
                AND numara=p_numara
                AND doviz_kod='XXX'
              FOR UPDATE;
    --log_at('1', 'UST_HESAP');
         ELSE
           SELECT baslangic_tarihi,bitis_tarihi,althesap_mi,Ba_Kod,NVL(borc_bakiye,0),NVL(alacak_bakiye,0),dk_kod, NVL(lc_borc_bakiye,0), NVL(lc_alacak_bakiye,0)
             INTO p_baslangic_tarihi,p_bitis_tarihi,p_althesap_mi,p_Ba_Kod,p_borc_bakiye,p_alacak_bakiye,p_dk_kod, p_lc_borc_bakiye, p_lc_alacak_bakiye
             FROM CBS_DKHESAP
            WHERE bolum_kodu=p_bolum_kodu
                AND numara=p_numara
                AND doviz_kod=p_doviz_kod
              FOR UPDATE;
    --log_at('2', 'UST_HESAP_deg?l');
         END IF;


        IF p_alt_hesap_kontrolu AND ust_hesap_mi(p_bolum_kodu,p_numara) THEN
             RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1127' ||g_uc_delimiter);
        END IF;

        -- Sevil Hanimin talebi uzerine sadece en alt DK'larda tarih kontrolu yapildi : EA-08/2003

        IF p_alt_hesap_kontrolu THEN
          IF ( TRUNC(Pkg_Muhasebe.banka_tarihi_bul) BETWEEN TRUNC(p_baslangic_tarihi) AND TRUNC(NVL(p_bitis_tarihi,TO_DATE('01012100','DDMMYYYY'))) ) THEN
            NULL;
          ELSE
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1128' ||g_ara_delimiter||p_bolum_kodu||'-'||p_numara||'-'||p_doviz_kod||g_uc_delimiter);
          END IF;
        END IF;

        IF ust_hesap_mi(p_bolum_kodu,p_numara) THEN  -- Ust hesaplarda lc_tutar guncellenir

           IF p_tur = 'B' THEN
               p_lc_temp_bakiye := p_lc_borc_bakiye + p_lc_tutar;
               p_temp_bakiye    := p_lc_borc_bakiye + p_lc_tutar;
               UPDATE CBS_DKHESAP
                  SET borc_bakiye    = p_temp_bakiye,
                      lc_borc_bakiye = p_lc_temp_bakiye,
                   bakiye_lc = bakiye_lc - p_lc_tutar,
                   bakiye = bakiye - p_lc_tutar
                WHERE bolum_kodu     = p_bolum_kodu
                  AND numara=p_numara
                  AND doviz_kod='XXX';
    --log_at('3', 'UST_HESAP','B');

           ELSE
               p_lc_temp_bakiye := p_lc_tutar + p_lc_alacak_bakiye;
            p_temp_bakiye    := p_lc_tutar + p_lc_alacak_bakiye;
               UPDATE CBS_DKHESAP
                  SET alacak_bakiye    = p_temp_bakiye,
                      lc_alacak_bakiye = p_lc_temp_bakiye,
                   bakiye_lc = bakiye_lc + p_lc_tutar,
                   bakiye = bakiye + p_lc_tutar
                WHERE bolum_kodu       = p_bolum_kodu
                  AND numara=p_numara
                  AND doviz_kod='XXX';
    --log_at('4', 'UST_HESAP', 'A');

           END IF;

        ELSE

           IF p_tur = 'B' THEN
               p_temp_bakiye    := p_borc_bakiye + p_tutar;
               p_lc_temp_bakiye := p_lc_borc_bakiye + p_lc_tutar;
               UPDATE CBS_DKHESAP
                  SET borc_bakiye    = p_temp_bakiye,
                      lc_borc_bakiye = p_lc_temp_bakiye,
                   bakiye_lc = bakiye_lc - p_lc_tutar,
                   bakiye = bakiye - p_tutar
                WHERE bolum_kodu     = p_bolum_kodu
                  AND numara=p_numara
                  AND doviz_kod=p_doviz_kod;
    --log_at('5', 'UST_HESAP', 'B');
           ELSE
               p_temp_bakiye    := p_tutar + p_alacak_bakiye;
               p_lc_temp_bakiye := p_lc_tutar + p_lc_alacak_bakiye;
               UPDATE CBS_DKHESAP
                  SET alacak_bakiye    = p_temp_bakiye,
                      lc_alacak_bakiye = p_lc_temp_bakiye,
                   bakiye_lc = bakiye_lc + p_lc_tutar,
                   bakiye = bakiye + p_tutar
                WHERE bolum_kodu       = p_bolum_kodu
                  AND numara=p_numara
                  AND doviz_kod=p_doviz_kod;
    --log_at('6', 'UST_HESAP', 'A');
           END IF;

        END IF;

       IF p_dk_kod IS NOT NULL THEN
              Pkg_Dk.bakiye_guncelle(  p_bolum_kodu,
                                                                    p_dk_kod,
                                                                    p_doviz_kod,
                                                                   p_tur,
                                                                    p_tutar,
                                                                    p_lc_tutar,
                                                    FALSE
                                                );
        END IF;

      EXCEPTION
            WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1129' ||g_ara_delimiter||p_bolum_kodu||'-'||p_numara||'-'||p_doviz_kod||g_uc_delimiter);
            WHEN OTHERS THEN
              RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1130' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
        END;
    */
 /****************************************************************************************************************/    
    ---sevalb 21022011  Yeni
    procedure bakiye_guncelle(p_bolum_kodu in varchar2, p_numara in varchar2, p_doviz_kod in varchar2, p_tur in varchar2, p_tutar in number,
                              p_lc_tutar in number, p_alt_hesap_kontrolu boolean default true, p_fis_numara in number default null, p_tarih in date default null, p_muhasebelestigi_tarih in date default null
                              , p_satir_no in number default null, p_islem_numara in number default null, p_islem_kodu in number default null, p_rowid in rowid default null) is
        p_borc_bakiye              cbs_dkhesap.borc_bakiye%type;
        p_alacak_bakiye            cbs_dkhesap.alacak_bakiye%type;
        p_bakiye                   cbs_dkhesap.borc_bakiye%type;
        p_ba_kod                   cbs_dkhesap.ba_kod%type;
        p_temp_bakiye              cbs_dkhesap.borc_bakiye%type;
        p_dk_kod                   cbs_dkhesap.dk_kod%type;
        p_lc_borc_bakiye           cbs_dkhesap.lc_borc_bakiye%type;
        p_lc_alacak_bakiye         cbs_dkhesap.lc_alacak_bakiye%type;
        p_lc_temp_bakiye           cbs_dkhesap.lc_borc_bakiye%type;
        p_baslangic_tarihi         cbs_dkhesap.baslangic_tarihi%type;
        p_bitis_tarihi             cbs_dkhesap.bitis_tarihi%type;
        p_althesap_mi              cbs_dkhesap.althesap_mi%type;
        prevent_deadlock           exception;
        ln_try_count               smallint;
        cn_retry_count_limit       smallint := 10; 
        cn_sleep_interval          smallint := 1;
        ln_sid                     number;
    begin
        select sys_context('USERENV', 'SID') into ln_sid from dual;
        if not p_alt_hesap_kontrolu then
            raise_application_error(-20100, g_uc_delimiter || '1140' || g_uc_delimiter);
        elsif pkg_dk.ust_hesap_mi(p_bolum_kodu, p_numara) then
            raise_application_error(-20100, g_uc_delimiter || '1127' || g_uc_delimiter);
        end if;
        
        pkg_parametre.deger('PKG_DK_BAKIYE_GUNCELLE_TRY_CNT', cn_retry_count_limit);--seval.colak 07.05.2021 cn_retry_count_limit 10>20
        ln_try_count   := 0;
        while ln_try_count < cn_retry_count_limit loop
            begin
                select baslangic_tarihi, bitis_tarihi, althesap_mi, ba_kod, nvl(borc_bakiye, 0),
                       nvl(alacak_bakiye, 0), dk_kod, nvl(lc_borc_bakiye, 0), nvl(lc_alacak_bakiye, 0)
                into p_baslangic_tarihi, p_bitis_tarihi, p_althesap_mi, p_ba_kod, p_borc_bakiye, p_alacak_bakiye,
                                       p_dk_kod, p_lc_borc_bakiye, p_lc_alacak_bakiye
                from cbs_dkhesap
                where bolum_kodu = p_bolum_kodu and numara = p_numara and doviz_kod = p_doviz_kod
                for update nowait;
                exit;
            exception
                when others then
                    ln_try_count   := ln_try_count + 1;
                    dbms_lock.sleep(cn_sleep_interval);
            end;
        end loop;
        if ln_try_count >= cn_retry_count_limit then
            raise prevent_deadlock;
        end if;
        if not (trunc(pkg_muhasebe.banka_tarihi_bul) between trunc(p_baslangic_tarihi) and trunc(nvl(p_bitis_tarihi, to_date('01012100', 'DDMMYYYY')))) then
            raise_application_error(-20100, g_uc_delimiter || '1128' || g_ara_delimiter || p_bolum_kodu || '-' || p_numara || '-' || p_doviz_kod || g_uc_delimiter);
        end if;
        if p_tur = 'B' then
            p_temp_bakiye      := p_borc_bakiye + p_tutar;
            p_lc_temp_bakiye   := p_lc_borc_bakiye + p_lc_tutar;
            update cbs_dkhesap
            set borc_bakiye = nvl(borc_bakiye, 0) + p_tutar, lc_borc_bakiye = nvl(lc_borc_bakiye, 0) + p_lc_tutar, bakiye_lc = bakiye_lc - p_lc_tutar, bakiye = bakiye - p_tutar
            where bolum_kodu = p_bolum_kodu and numara = p_numara and doviz_kod = p_doviz_kod;
        else
            p_temp_bakiye      := p_tutar + p_alacak_bakiye;
            p_lc_temp_bakiye   := p_lc_tutar + p_lc_alacak_bakiye;
            update cbs_dkhesap
            set alacak_bakiye = nvl(alacak_bakiye, 0) + p_tutar, lc_alacak_bakiye = nvl(lc_alacak_bakiye, 0) + p_lc_tutar, bakiye_lc = bakiye_lc + p_lc_tutar, bakiye = bakiye + p_tutar
            where bolum_kodu = p_bolum_kodu and numara = p_numara and doviz_kod = p_doviz_kod;
        end if;       
                               
    exception
        when prevent_deadlock then
            log_at('PKG_DK',
                   'BAKIYE_GUNCELLE : PART-I-prevent_deadlock',
                   p_islem_numara || '*' || p_fis_numara || '*' || p_satir_no || '*' || p_bolum_kodu || '*' || p_numara || '*' || p_doviz_kod || '*' || ln_try_count,
                   ln_sid || '*' || '!!! Rolling back just now');
            rollback;
            raise_application_error(-20100, g_uc_delimiter || '1114' || g_uc_delimiter);
        when no_data_found then
            raise_application_error(-20100, g_uc_delimiter || '1129' || g_ara_delimiter || p_bolum_kodu || '-' || p_numara || '-' || p_doviz_kod || g_uc_delimiter);
        when others then
            log_at('PKG_DK',
                   'BAKIYE_GUNCELLE : PART-III-others',
                   p_islem_numara || '*' || p_fis_numara || '*' || p_satir_no || '*' || p_bolum_kodu || '*' || p_numara || '*' || p_doviz_kod || '*' || ln_try_count,
                   ln_sid || '*' || sqlerrm);
            if sqlcode = -60 then
                log_at('PKG_DK',
                       'BAKIYE_GUNCELLE : PART-IV-others-sqlcode = -60',
                       p_islem_numara || '*' || p_fis_numara || '*' || p_satir_no || '*' || p_bolum_kodu || '*' || p_numara || '*' || p_doviz_kod || '*' || ln_try_count,
                       ln_sid || '*' || sqlerrm);
                rollback;
            end if;
            raise_application_error(-20100, g_uc_delimiter || '1130' || g_ara_delimiter || sqlcode || '-' || sqlerrm || g_uc_delimiter);
    end;
    procedure ust_hesap_yarat(pbolum_kodu varchar2, pnumara varchar2, pdoviz_kod varchar2, pauto_doviz varchar2, pauto_bolum varchar2,
                              pbaslangic_tarihi date, pbitis_tarihi date, paciklama varchar2, pba_kod varchar2, pdk_sinif varchar2,
                              pdk_kisa_isim varchar2, pkarsi_subeye_kapali_mi varchar2, phesap_terse_donsun_mu varchar2, palthesap_mi varchar2, psubeye_kapali_mi varchar2,
                              pkar_zarar_gl varchar2, pgenel_md_kapali_mi varchar2, pmusterili_hesap_mi varchar2, pfaiz_hesaplanacak_mi varchar2, ppersonele_bagli_mi varchar2,
                              psba_kapali_mi varchar2, plevel number) is
        cursor c1 is
            select format_mask
            from cbs_dk_tanim
            order by seviye;
        cursor c2 is
            select doviz_kodu
            from cbs_doviz_kodlari
            where doviz_kodu != pdoviz_kod and doviz_kodu != pkg_genel.lc_al;
        cursor c3 is
            select kodu
            from cbs_bolum
            where kapanis_tarihi is null and kar_merkezi = 'E' and kodu = decode(pauto_bolum, 'E', kodu, pbolum_kodu);
        lc_format_mask   cbs_dk_tanim.format_mask%type;
        ln_top_uzun      number;
        ln_dk_kod        cbs_dkhesap.numara%type;
        ln_doviz_kod     varchar2(3);
        ls_bolum_kodu    varchar2(20);
    begin
        open c3;
        loop
            fetch c3 into ls_bolum_kodu;
            exit when c3%notfound;
            ln_top_uzun   := 0;
            ln_dk_kod     := null;
            open c1;
            loop
                fetch c1 into lc_format_mask;
                exit when c1%notfound;
                ln_top_uzun   := ln_top_uzun + length(lc_format_mask);
                -- En alt hesab? yarat
                if ln_top_uzun = length(pnumara) then
                    begin
                        insert into cbs_dkhesap(bolum_kodu, numara, doviz_kod, dk_kod, baslangic_tarihi,
                                                bitis_tarihi, aciklama, ba_kod, dk_sinif, dk_kisa_isim,
                                                karsi_subeye_kapali_mi, hesap_terse_donsun_mu, althesap_mi, subeye_kapali_mi, kar_zarar_gl,
                                                genel_md_kapali_mi, musterili_hesap_mi, faiz_hesaplanacak_mi, personele_bagli_mi, sba_kapali_mi,
                                                dk_level)
                        values (ls_bolum_kodu, substr(pnumara, 1, ln_top_uzun), pdoviz_kod, ln_dk_kod, pbaslangic_tarihi,
                                pbitis_tarihi, paciklama, pba_kod, pdk_sinif, pdk_kisa_isim,
                                pkarsi_subeye_kapali_mi, phesap_terse_donsun_mu, palthesap_mi, psubeye_kapali_mi, pkar_zarar_gl,
                                pgenel_md_kapali_mi, pmusterili_hesap_mi, pfaiz_hesaplanacak_mi, ppersonele_bagli_mi, psba_kapali_mi,
                                plevel);
                    exception
                        when others then
                            null;                                                                                                                                     -- daha once yaratilmis olabilir
                    end;
                end if;
                -- Ust hesaplari yarat
                if ln_top_uzun < length(pnumara) then
                    begin
                        insert into cbs_dkhesap(bolum_kodu, numara, doviz_kod, dk_kod, baslangic_tarihi,
                                                bitis_tarihi, aciklama, ba_kod, dk_sinif, dk_kisa_isim,
                                                karsi_subeye_kapali_mi, hesap_terse_donsun_mu, althesap_mi, subeye_kapali_mi, kar_zarar_gl,
                                                genel_md_kapali_mi, musterili_hesap_mi, faiz_hesaplanacak_mi, personele_bagli_mi, sba_kapali_mi,
                                                dk_level)
                        values (ls_bolum_kodu, substr(pnumara, 1, ln_top_uzun), 'XXX'                                                                                  -- cinsi olmayan bir doviz kodu
                                                                                     , ln_dk_kod, pbaslangic_tarihi,
                                pbitis_tarihi, paciklama, pba_kod, pdk_sinif, pdk_kisa_isim,
                                pkarsi_subeye_kapali_mi, phesap_terse_donsun_mu, palthesap_mi, psubeye_kapali_mi, pkar_zarar_gl,
                                pgenel_md_kapali_mi, pmusterili_hesap_mi, pfaiz_hesaplanacak_mi, ppersonele_bagli_mi, psba_kapali_mi,
                                plevel);
                    exception
                        when others then
                            null;                                                                                                                                     -- daha once yaratilmis olabilir
                    end;
                end if;
                if ln_top_uzun = length(pnumara) and pauto_doviz = 'E' then                                                                                  -- sadece en alt d?zey i?in d?vizli yarat
                    open c2;
                    loop
                        fetch c2 into ln_doviz_kod;
                        exit when c2%notfound;
                        begin
                            insert into cbs_dkhesap(bolum_kodu, numara, doviz_kod, dk_kod, baslangic_tarihi,
                                                    bitis_tarihi, aciklama, ba_kod, dk_sinif, dk_kisa_isim,
                                                    karsi_subeye_kapali_mi, hesap_terse_donsun_mu, althesap_mi, subeye_kapali_mi, kar_zarar_gl,
                                                    genel_md_kapali_mi, musterili_hesap_mi, faiz_hesaplanacak_mi, personele_bagli_mi, sba_kapali_mi,
                                                    dk_level)
                            values (ls_bolum_kodu, substr(pnumara, 1, ln_top_uzun), ln_doviz_kod, ln_dk_kod, pbaslangic_tarihi,
                                    pbitis_tarihi, paciklama, pba_kod, pdk_sinif, pdk_kisa_isim,
                                    pkarsi_subeye_kapali_mi, phesap_terse_donsun_mu, palthesap_mi, psubeye_kapali_mi, pkar_zarar_gl,
                                    pgenel_md_kapali_mi, pmusterili_hesap_mi, pfaiz_hesaplanacak_mi, ppersonele_bagli_mi, psba_kapali_mi,
                                    plevel);
                        exception
                            when others then
                                null;                                                                                                                                 -- daha once yaratilmis olabilir
                        end;
                    end loop;
                    close c2;
                end if;                                                                                                                                                  --   if auto_doviz = 'E' then
                ln_dk_kod     := substr(pnumara, 1, ln_top_uzun);
            end loop;
            close c1;
        end loop;
        close c3;
    end;
    ----------------------------------------------------------------------------
    procedure plan_kopyala(pkaynakbolum_kodu varchar2, phedefbolum_kodu varchar2) is
        pnumara                   varchar2(200);
        pdk_kod                   varchar2(30);
        pdoviz_kod                varchar2(200);
        pauto_doviz               varchar2(200);
        pauto_bolum               varchar2(200);
        pbaslangic_tarihi         date;
        pbitis_tarihi             date;
        paciklama                 varchar2(200);
        pba_kod                   varchar2(200);
        pdk_sinif                 varchar2(200);
        pdk_kisa_isim             varchar2(200);
        pkarsi_subeye_kapali_mi   varchar2(200);
        phesap_terse_donsun_mu    varchar2(200);
        palthesap_mi              varchar2(200);
        psubeye_kapali_mi         varchar2(200);
        pkar_zarar_gl             varchar2(200);
        pgenel_md_kapali_mi       varchar2(200);
        pmusterili_hesap_mi       varchar2(200);
        pfaiz_hesaplanacak_mi     varchar2(200);
        ppersonele_bagli_mi       varchar2(200);
        psba_kapali_mi            varchar2(200);
        plevel                    number;
        cursor c1 is
            select numara, doviz_kod, dk_kod, baslangic_tarihi, bitis_tarihi,
                   aciklama, ba_kod, dk_sinif, dk_kisa_isim, karsi_subeye_kapali_mi,
                   hesap_terse_donsun_mu, althesap_mi, subeye_kapali_mi, kar_zarar_gl, genel_md_kapali_mi,
                   musterili_hesap_mi, faiz_hesaplanacak_mi, personele_bagli_mi, sba_kapali_mi, dk_level
            from cbs_dkhesap
            where bolum_kodu = pkaynakbolum_kodu;
    begin
        open c1;
        loop
            fetch c1
                into pnumara, pdoviz_kod, pdk_kod, pbaslangic_tarihi, pbitis_tarihi, paciklama,
                     pba_kod, pdk_sinif, pdk_kisa_isim, pkarsi_subeye_kapali_mi, phesap_terse_donsun_mu,
                     palthesap_mi, psubeye_kapali_mi, pkar_zarar_gl, pgenel_md_kapali_mi, pmusterili_hesap_mi,
                     pfaiz_hesaplanacak_mi, ppersonele_bagli_mi, psba_kapali_mi, plevel;
            exit when c1%notfound;
            insert into cbs_dkhesap(numara, bolum_kodu, dk_kod, doviz_kod, baslangic_tarihi,
                                    bitis_tarihi, aciklama, ba_kod, dk_sinif, dk_kisa_isim,
                                    karsi_subeye_kapali_mi, hesap_terse_donsun_mu, althesap_mi, subeye_kapali_mi, kar_zarar_gl,
                                    genel_md_kapali_mi, musterili_hesap_mi, faiz_hesaplanacak_mi, personele_bagli_mi, sba_kapali_mi,
                                    dk_level)
            values (pnumara, phedefbolum_kodu, pdk_kod, pdoviz_kod, pbaslangic_tarihi,
                    pbitis_tarihi, paciklama, pba_kod, pdk_sinif, pdk_kisa_isim,
                    pkarsi_subeye_kapali_mi, phesap_terse_donsun_mu, palthesap_mi, psubeye_kapali_mi, pkar_zarar_gl,
                    pgenel_md_kapali_mi, pmusterili_hesap_mi, pfaiz_hesaplanacak_mi, ppersonele_bagli_mi, psba_kapali_mi,
                    plevel);
        end loop;
        commit;
    end;
    procedure grup_urun_bagla is
        p_grup_kodu        number;
        p_temp_grup_kodu   varchar2(100);
    /*
      cursor c2 is
      select ltrim(rtrim(c11)),ltrim(rtrim(c12)),ltrim(rtrim(c2)),ltrim(rtrim(c14)),ltrim(rtrim(c16)) from hesap_plan_gecici where c11 !='A' and c11!='B' and c11=p_temp_grup_kodu order by c11,c12;

      cursor c1 is
      select dk_grup_kodu from cbs_dk_grup_kodlari order by dk_grup_kodu;

      p_musteri_grup number;
      p_urun_sinif_numara number;
      p_dk_ana varchar2(100);
      p_dk_reeskont varchar2(100);
      p_dk_tahak varchar2(100);
      p_dk_faiz varchar2(100);
      p_modul_tur_kod varchar2(100);
      p_urun_tur_kod varchar2(100);
      p_urun_sinif_kod varchar2(100);

      p_dk_hesabi_1 varchar2(100);
      p_dk_hesabi_4 varchar2(100);
      p_dk_hesabi_2 varchar2(100);


      p_temp_musteri_grup  varchar2(100);
      p_temp_urun_sinif_numara  varchar2(100);
      */
    begin
        null;
    /*
      open c1;
      loop
        fetch c1 into p_temp_grup_kodu;
        exit when c1%notfound;

           dbms_output.put_line('Incelenen grup : '||p_temp_grup_kodu);

          p_grup_kodu:=to_number(ltrim(rtrim(p_temp_grup_kodu)));

           dbms_output.put_line('Incelenen grup numara : '||p_grup_kodu);

          open c2;
          loop
            fetch c2 into p_temp_musteri_grup,p_temp_urun_sinif_numara,p_dk_ana,p_dk_reeskont,p_dk_faiz;
             exit when c2%notfound;

            dbms_output.put_line('Incelenen temp mus ve urun : '||p_temp_musteri_grup||'-'||p_temp_urun_sinif_numara);

            if p_temp_musteri_grup is not null and p_temp_urun_sinif_numara is not null then

                p_musteri_grup:=p_temp_musteri_grup;
              p_urun_sinif_numara:=p_temp_urun_sinif_numara;
                dbms_output.put_line('Incelenen urun_sinif : '||p_temp_musteri_grup||'-'||p_temp_urun_sinif_numara);

              begin
                  select modul_tur_kod,urun_tur_kod,kod
                  into p_modul_tur_kod,p_urun_tur_kod,p_urun_sinif_kod
                  from gecici_cbs_urun_sinif
                 where sinif_numara=p_urun_sinif_numara;
              exception
                when no_data_found then
                  dbms_output.put_line('Bulunamayan urun : '||p_urun_sinif_kod);
                when others then
                  dbms_output.put_line('?r?n se?erken hata olu?tu : '||p_urun_sinif_kod||' '||sqlerrm);
              end;
               begin
                   p_dk_hesabi_1:=p_dk_ana;
                 p_dk_hesabi_4:=p_dk_reeskont;
                 p_dk_hesabi_2:=p_dk_faiz;
                   insert into cbs_grup_urun_sinif (grup_kod,modul_tur_kod,urun_tur_kod,urun_sinif_kod,dk_hesabi_1,dk_hesabi_4,dk_hesabi_2)
                                        values (p_grup_kodu,p_modul_tur_kod,p_urun_tur_kod,p_urun_sinif_kod,p_dk_hesabi_1,p_dk_hesabi_4,p_dk_hesabi_2);
               exception
                 when dup_val_on_index then
                   begin
                   if p_dk_hesabi_1 is not null or p_dk_hesabi_4 is not null or p_dk_hesabi_2 is not null then
                        update cbs_grup_urun_sinif
                         set dk_hesabi_1=nvl(p_dk_hesabi_1,dk_hesabi_1),dk_hesabi_4=nvl(p_dk_hesabi_4,dk_hesabi_4),dk_hesabi_2=nvl(p_dk_hesabi_2,dk_hesabi_2)
                       where grup_kod=p_grup_kodu
                         and modul_tur_kod=p_modul_tur_kod
                         and urun_tur_kod=p_urun_tur_kod
                         and urun_sinif_kod=p_urun_sinif_kod;
                   end if;
                   exception
                     when others then
                          dbms_output.put_line('cbs_grup_urun_sinif update ederken : '||p_grup_kodu||' '||p_modul_tur_kod||''||p_urun_tur_kod||''||p_urun_sinif_kod||''||sqlerrm);
                   end;
                 when others then
                          dbms_output.put_line('cbs_grup_urun_sinif eklerken hata olu?tu : '||p_grup_kodu||' '||p_modul_tur_kod||''||p_urun_tur_kod||''||p_urun_sinif_kod||''||sqlerrm);
                 end;
            end if;
           end loop;
           close c2;
      end loop;
      close c1;
      commit;
      exception
        when others then
           dbms_output.put_line('hata olu?tu : '||p_temp_grup_kodu||' '||sqlerrm);
      */
    end;
    function dkbaslangicbakiyeal(pn_numara cbs_dkhesap.numara%type, pd_date date, ps_doviz cbs_dkhesap.doviz_kod%type)
        return number is
        ln_bakiye   number;
    begin
        select bakiye
        into ln_bakiye
        from cbs_dkhesap
        where numara = pn_numara and doviz_kod = ps_doviz and baslangic_tarihi = pd_date;
        return ln_bakiye;
    end;
    procedure update_upper_dks is
        ln_try_count       smallint;
        cn_wait_interval   smallint := 1;
        prevent_deadlock   exception;
        ls_bolum_kodu      varchar2(10);
        ls_numara          varchar2(30);
        ls_doviz_kod       varchar2(3);
    begin
    --seval.colak 02062021 bu yapi kullanimdan kaldirildi.Yerine eod da calistirilacak olan PKG_BAT_1. DKHESAP_UST_DK_GUNCELLE hazirlandi.
      null; 
    /*
        while 1 = 1 loop
            pkg_parametre.deger('GL_UPDATE_RETRY_WAIT_INTERVAL', cn_wait_interval);
            for cur1 in (select rr.*, rr.rowid
                         from cbs_dk_update_log rr
                         where process_state = 'W'
                         order by log_id) loop
                begin
                    if cur1.tur = 'B' then
                        update cbs_dkhesap
                        set borc_bakiye = lc_borc_bakiye + cur1.lc_tutar, lc_borc_bakiye = lc_borc_bakiye + cur1.lc_tutar, bakiye_lc = bakiye_lc - cur1.lc_tutar, bakiye = bakiye - cur1.lc_tutar
                        where bolum_kodu = cur1.bolum_kodu and doviz_kod = 'XXX' and (numara in (substr(cur1.numara, 1, 7), substr(cur1.numara, 1, 6), substr(cur1.numara, 1, 5), substr(cur1.numara, 1, 4)
                              , substr                                                           (cur1.numara, 1, 3),
                              substr                                                             (cur1.numara, 1, 2), substr(cur1.numara, 1, 1)));
                    else
                        update cbs_dkhesap
                        set alacak_bakiye = lc_alacak_bakiye + cur1.lc_tutar, lc_alacak_bakiye = lc_alacak_bakiye + cur1.lc_tutar, bakiye_lc = bakiye_lc + cur1.lc_tutar, bakiye = bakiye + cur1.lc_tutar
                        where bolum_kodu = cur1.bolum_kodu and doviz_kod = 'XXX' and (numara in (substr(cur1.numara, 1, 7), substr(cur1.numara, 1, 6), substr(cur1.numara, 1, 5), substr(cur1.numara, 1, 4)
                              , substr                                                           (cur1.numara, 1, 3),
                              substr                                                             (cur1.numara, 1, 2), substr(cur1.numara, 1, 1)));
                    end if;
                    update cbs_dk_update_log rr
                    set process_state = 'P', processed_at = sysdate, update_try_count = nvl(update_try_count, 0) + 1
                    where rr.rowid = cur1.rowid;
                    commit;
                exception
                    when others then
                        log_at(
                            'PKG_DK',
                            'UPDATE_UPPER_DKS : PART-VI-Cannot execute multi-update',
                            cur1.islem_numara || '*' || cur1.fis_numara || '*' || cur1.satir_sira_no || '*' || cur1.bolum_kodu || '*' || cur1.numara || '*' || cur1.doviz_kod || '*' || nvl(
                            cur1.update_try_count,
                            0) + 1,
                            '!!! Rolling back just now' || '*' || sqlerrm);
                        rollback;
                        update cbs_dk_update_log rr
                        set processed_at = sysdate, update_try_count = nvl(update_try_count, 0) + 1
                        where rr.rowid = cur1.rowid;
                        commit;
                end;
            end loop;
            dbms_lock.sleep(cn_wait_interval);
        end loop;
          */
    exception
        when others then
            log_at('PKG_DK', 'UPDATE_UPPER_DKS : PART-IX-others', null, '!!! Rolling back just now' || '*' || sqlerrm);
            rollback;
         
    end;
   
end;
/

