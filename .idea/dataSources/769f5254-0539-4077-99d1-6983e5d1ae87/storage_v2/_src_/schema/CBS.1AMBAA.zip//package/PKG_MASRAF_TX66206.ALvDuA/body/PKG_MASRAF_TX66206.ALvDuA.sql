create package body     pkg_masraf_tx66206  is
	p_66206_masraf_tipi_cash		number;
	p_66206_masraf_tipi_acc			number;
	p_66206_lc_masraf_tahsili		number;
	p_66206_fc_masraf_tahsili		number;
	p_66206_islem_sube				number;
	p_66206_banka_aciklama			number;
	p_66206_musteri_aciklama		number;
	p_66206_istatistik_kodu			number;
	p_66206_nakit_kodu				number;
	p_66206_referans				number;
	p_66206_doviz_kodu				number;
	p_66206_hesap_no				number;
	p_66206_hesap_sube				number;
	p_66206_komisyon_gl				number;
	p_66206_lc_toplam_masraf		number;
	p_66206_fc_toplam_masraf		number;
	p_66206_lc_komisyon_tutar		number;
	p_66206_lc_vergi				number;
	p_66206_kur						number;
	p_66206_masraf_gecici_var		number;
	p_66206_masraf_gecici_yok		number;
	p_66206_kom_vergi				number;
	p_66206_kom_vergi_fc			number;

/*--------------------- ?thalat ?hracat masraflari ----------------------------------------------*/
  procedure kontrol_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
   null;
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure dogrulama_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
  	null;
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure dogrulama_iptal_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
   null;
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure onay_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
    pkg_masraf.onay_sonrasi(pn_islem_no, ps_ref, 0, 'A', 'SAFEDEPCOM');
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure reddetme_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
   pkg_masraf.reddetme_sonrasi(pn_islem_no, ps_ref);
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure basim_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
  	null;
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure iptal_onay_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
   pkg_masraf.iptal_onay_sonrasi_grs_guncel(pn_islem_no, ps_ref, 0);
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure muhasebelesme(pn_islem_no number, pn_fis_no in out number) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_eski_tahsil_tutar	  number;
   ln_tahsil_tutar		  number;
   ls_istatistik_kodu     varchar2(2000);
   ls_aciklama			  varchar2(2000);
   ls_nakit_kodu 		  varchar2(2000);
   ln_vergi				  number;
   ln_komisyon			  number;
   ld_gelecek_odeme_tarihi		 date;

   ls_1  varchar2(2000);
   ls_2  varchar2(2000);
   ls_3  varchar2(2000);
   ls_4  varchar2(2000);
   ln_1 boolean;

    CURSOR CUR_MASRAF IS
        SELECT * FROM CBS_MASRAF_ITH_IHR_ISL
        WHERE ISLEM_NO = PN_ISLEM_NO AND DURUM = 'VALID'
        ORDER BY SIRA_NO
        FOR UPDATE;
    ROW_MASRAF CUR_MASRAF%ROWTYPE;    
	LN_TEMP NUMBER;

   cursor cur_kiralik_kasa is
     select * from cbs_kiralik_kasa_acilis_islem
	  where tx_no = pn_islem_no;
	 row_kk cur_kiralik_kasa%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no --referans = ls_referans
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   ln_dk_grup_no     number;

   cursor c_all_taksit is
   select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no; --referans = ls_referans

   cursor c_all_taksit_sayi is
   select count(*) sayi from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no; --referans = ls_referans
  r_taksit_sayi c_all_taksit_sayi%rowtype;
  ld_gecerlilik_tarih date;
  i number;
  ln_odenecek number;
  ln_top_odenecek number;
  ln_temp_kom number;
  begin
    LN_FIS_NO := PN_FIS_NO;
	SELECT COUNT(*) INTO LN_TEMP
	FROM CBS_MASRAF_ITH_IHR_ISL
	WHERE ISLEM_NO = PN_ISLEM_NO AND DURUM = 'VALID';
	IF LN_TEMP <= 0 THEN
	  RETURN;
	END IF;

	BOOLEAN_LIST(P_66206_MASRAF_TIPI_CASH)  := FALSE ;
	BOOLEAN_LIST(P_66206_MASRAF_TIPI_ACC)   := FALSE ;
	BOOLEAN_LIST(P_66206_LC_MASRAF_TAHSILI) := FALSE ;
	BOOLEAN_LIST(P_66206_FC_MASRAF_TAHSILI) := FALSE ;
    BOOLEAN_LIST(P_66206_MASRAF_GECICI_VAR) := FALSE;
    BOOLEAN_LIST(P_66206_MASRAF_GECICI_YOK) := FALSE;

	VARCHAR_LIST(P_66206_DOVIZ_KODU) := PKG_GENEL.LC_AL;
	
	OPEN CUR_KIRALIK_KASA;
	FETCH CUR_KIRALIK_KASA INTO ROW_KK;
	CLOSE CUR_KIRALIK_KASA;
	IF ROW_KK.MASRAF_HESAP_NO IS NOT NULL THEN
    	VARCHAR_LIST(P_66206_HESAP_NO)  := ROW_KK.MASRAF_HESAP_NO;
	    VARCHAR_LIST(P_66206_HESAP_SUBE):= PKG_HESAP.HESAPSUBEAL(ROW_KK.MASRAF_HESAP_NO);
	END IF;
	VARCHAR_LIST(P_66206_ISLEM_SUBE) := ROW_KK.SUBE_KODU;
	LS_REFERANS := ROW_KK.REFERANS_NO;

	VARCHAR_LIST(P_66206_REFERANS) 		:= LS_REFERANS;
	VARCHAR_LIST(P_66206_NAKIT_KODU)    := NVL(TO_CHAR(ROW_KK.NAKIT_KODU),' ');
	LS_ACIKLAMA :=  'Safe Deposit Box Commission' ;
	VARCHAR_LIST(P_66206_BANKA_ACIKLAMA)  := LS_ACIKLAMA ;
	VARCHAR_LIST(P_66206_MUSTERI_ACIKLAMA):= LS_ACIKLAMA ;

    IF VARCHAR_LIST(P_66206_DOVIZ_KODU) = PKG_GENEL.LC_AL THEN
		BOOLEAN_LIST(P_66206_LC_MASRAF_TAHSILI):=TRUE;
		BOOLEAN_LIST(P_66206_FC_MASRAF_TAHSILI):=FALSE;
	ELSE
		BOOLEAN_LIST(P_66206_LC_MASRAF_TAHSILI):=FALSE;
        BOOLEAN_LIST(P_66206_FC_MASRAF_TAHSILI):=TRUE;
	END IF;

	IF ROW_KK.MASRAF_HESABIN_TIPI = 'KASA' THEN
		BOOLEAN_LIST(P_66206_MASRAF_TIPI_CASH) :=TRUE;
	ELSE
		BOOLEAN_LIST(P_66206_MASRAF_TIPI_ACC)  :=TRUE;
	END IF;

	LN_DK_GRUP_NO := PKG_MUSTERI.SF_MUSTERI_DK_GRUP_KOD_AL(ROW_KK.MUSTERI_NO);

	IF LN_DK_GRUP_NO IS NOT NULL THEN
		VARCHAR_LIST(P_66206_KOMISYON_GL) := PKG_MUHASEBE.KOMISYON_DK_BUL( LN_DK_GRUP_NO,'SAFEDEPCOM');
	ELSE
 		VARCHAR_LIST(P_66206_KOMISYON_GL) := NULL;
	END IF;

	NUMBER_LIST(P_66206_LC_TOPLAM_MASRAF) := 0;
	NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF) := 0;
	NUMBER_LIST(P_66206_LC_KOMISYON_TUTAR):= 0;
	NUMBER_LIST(P_66206_LC_VERGI) 		  := 0;
	NUMBER_LIST(P_66206_KOM_VERGI)        := 0;
	NUMBER_LIST(P_66206_KOM_VERGI_FC)     := 0;

	IF ROW_KK.MASRAF_HESAP_NO IS NOT NULL THEN  --masraf hesabi girilmisse
        IF VARCHAR_LIST(P_66206_DOVIZ_KODU) <> PKG_GENEL.LC_AL THEN
            NUMBER_LIST(P_66206_KUR) := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(VARCHAR_LIST(P_66206_DOVIZ_KODU),
						                                         PKG_GENEL.LC_AL, NULL, 1, 1,
														         NULL, NULL, 'N', 'A');
        ELSE
            NUMBER_LIST(P_66206_KUR) := PKG_KOMISYON_KUR.KOM_DOVIZ_DOVIZ_KARSILIK(VARCHAR_LIST(P_66206_DOVIZ_KODU),
						                             PKG_GENEL.LC_AL, NULL, 1, NULL, NULL);
        END IF;
        LN_SON_BAKIYE := PKG_HESAP.KULLANILABILIR_BAKIYE_AL(VARCHAR_LIST(P_66206_HESAP_NO));
    END IF;
    
    OPEN CUR_MASRAF;
    FETCH CUR_MASRAF INTO ROW_MASRAF;
    CLOSE CUR_MASRAF;        
    IF NVL(ROW_MASRAF.TAHSIL_EDILEMEYEN, 0) > 0  THEN
        LN_TAHSIL_TUTAR := ROW_MASRAF.TUTAR - NVL(ROW_MASRAF.TAHSIL_TOPLAM, 0);
        IF ROW_MASRAF.MASRAF_KODU =  'SAFEDEPCOM' THEN
            LN_ESKI_TAHSIL_TUTAR := NVL(ROW_MASRAF.TAHSIL_TOPLAM, 0);
            IF ROW_KK.MASRAF_TIPI = 'TOPLAM' THEN  --toplam tahsilat yap?lacak.....
                LN_TAHSIL_TUTAR := ROW_MASRAF.TAHSIL_EDILEMEYEN;
                IF VARCHAR_LIST(P_66206_DOVIZ_KODU) <> PKG_GENEL.LC_AL THEN
                    LN_TEMP_KOM  := PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, PKG_KUR.MB_DAK_TO_LC(ROW_MASRAF.DVZ, LN_TAHSIL_TUTAR));
                    LN_VERGI     := PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, LN_TEMP_KOM * 15) / (100 + 15);
                    LN_KOMISYON  := LN_TEMP_KOM - LN_VERGI ;
                ELSE
                    LN_TEMP_KOM  := PKG_KUR.MB_DAK_TO_LC(ROW_MASRAF.DVZ, LN_TAHSIL_TUTAR);
                    LN_VERGI     := ROUND((LN_TEMP_KOM * 15) / (100 + 15), 2);
                    LN_KOMISYON  := LN_TEMP_KOM - LN_VERGI;
                END IF;
                IF NVL(ROW_KK.DONEM_BAS_SON,'B') = 'B' THEN
                    BOOLEAN_LIST(P_66206_MASRAF_GECICI_VAR) := TRUE;
                    BOOLEAN_LIST(P_66206_MASRAF_GECICI_YOK) := FALSE;
                    NUMBER_LIST(P_66206_LC_KOMISYON_TUTAR)  := LN_KOMISYON + LN_VERGI;
                    NUMBER_LIST(P_66206_LC_VERGI)     := 0;
                    NUMBER_LIST(P_66206_KOM_VERGI)    := LN_KOMISYON + LN_VERGI;
                    NUMBER_LIST(P_66206_KOM_VERGI_FC) := LN_TAHSIL_TUTAR;
                ELSE
                    BOOLEAN_LIST(P_66206_MASRAF_GECICI_VAR) := FALSE;
                    BOOLEAN_LIST(P_66206_MASRAF_GECICI_YOK) := TRUE;
                    NUMBER_LIST(P_66206_LC_KOMISYON_TUTAR)  := LN_KOMISYON ;
                    NUMBER_LIST(P_66206_LC_VERGI)     := LN_VERGI;
                    NUMBER_LIST(P_66206_KOM_VERGI)    := LN_KOMISYON+LN_VERGI;
                    NUMBER_LIST(P_66206_KOM_VERGI_FC) := LN_TAHSIL_TUTAR;
                END IF;
                LN_BORC_TUTAR := LN_TAHSIL_TUTAR;
                LN_BORC_TRL   := LN_KOMISYON + LN_VERGI;
                IF LN_SON_BAKIYE >= LN_BORC_TUTAR THEN
                    LN_FIS_NO := PKG_MUHASEBE.FIS_KES ( 66206, NULL, PN_ISLEM_NO, VARCHAR_LIST, NUMBER_LIST,
                                                      DATE_LIST, BOOLEAN_LIST, NULL, FALSE, LN_FIS_NO, NULL);
                    UPDATE CBS_MASRAF_ITH_IHR_ISL
                    SET TAHSIL_TOPLAM = NVL(TAHSIL_TOPLAM,0) + LN_TAHSIL_TUTAR,
                        TAHSIL_EDILEMEYEN = TAHSIL_EDILEMEYEN - LN_TAHSIL_TUTAR
                    WHERE ISLEM_NO = ROW_MASRAF.ISLEM_NO;

                    PKG_MASRAF.IPTAL_ICIN_LOG_AT(PN_ISLEM_NO, ROW_MASRAF.REFERANS, ROW_MASRAF.SIRA_NO,
                                                  ROW_MASRAF.MASRAF_KODU, LN_TAHSIL_TUTAR, ROW_MASRAF.VS_NO);

                    UPDATE CBS_MASRAF_TAKSIT_ISLEM
                    SET TAKSIT_ODEME_TARIH = PKG_MUHASEBE.BANKA_TARIHI_BUL,
                        ODENEN_TUTAR = TAKSIT_TUTARI
                    WHERE ISLEM_NO = PN_ISLEM_NO AND NVL(ODENEN_TUTAR,0) = 0;

                    IF NVL(ROW_KK.DONEM_BAS_SON,'B') = 'B' THEN
                        OPEN C_ALL_TAKSIT_SAYI;
                        FETCH C_ALL_TAKSIT_SAYI INTO R_TAKSIT_SAYI;
                        CLOSE C_ALL_TAKSIT_SAYI;
                        I := 1;
                        FOR R_0 IN C_ALL_TAKSIT LOOP
                            IF I = R_TAKSIT_SAYI.SAYI THEN
                                LD_GECERLILIK_TARIH := ROW_KK.GECERLILIK_TARIHI;
                                LN_ODENECEK := LN_KOMISYON - NVL(LN_TOP_ODENECEK,0);
                            ELSE
                                LD_GECERLILIK_TARIH := NULL;
                                LN_ODENECEK := R_0.TAKSIT_TUTARI;
                                IF VARCHAR_LIST(P_66206_DOVIZ_KODU) <> PKG_GENEL.LC_AL THEN
                                    LN_TEMP_KOM  := PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, PKG_KUR.MB_DAK_TO_LC(ROW_MASRAF.DVZ, LN_ODENECEK));
                                    --ln_vergi    := pkg_kur.yuvarla(pkg_genel.lc_al, ln_temp_kom * 15)/(100+15);
                                    LN_ODENECEK := LN_TEMP_KOM; -- ln_vergi ;
                                ELSE
                                    LN_TEMP_KOM := PKG_KUR.MB_DAK_TO_LC(ROW_MASRAF.DVZ, LN_ODENECEK);
                                    --ln_vergi    := round((ln_temp_kom * 15)/(100+15), 2)  ;
                                    LN_ODENECEK := LN_TEMP_KOM; -- ln_vergi ;
                                END IF;
                                LN_TOP_ODENECEK := NVL(LN_TOP_ODENECEK,0) + LN_ODENECEK;
                            END IF;
                            PKG_MASRAF.GECICI_GERCEK_ICIN_KAYDET(PN_ISLEM_NO, R_0.REFERANS,
                                                                R_0.MASRAF_KODU, R_0.VS_NO,
                                                                R_0.TAKSIT_NO, R_0.TAKSIT_TARIHI,
                                                                LN_ODENECEK, ROW_KK.MASRAF_HESAP_NO,
                                                                LD_GECERLILIK_TARIH, 'E', NULL, NULL, 'E');
                        END LOOP;
                    END IF;

                    LN_SON_BAKIYE := LN_SON_BAKIYE - LN_BORC_TUTAR ;

                    NUMBER_LIST(P_66206_LC_TOPLAM_MASRAF) := NUMBER_LIST(P_66206_LC_TOPLAM_MASRAF) + LN_BORC_TRL;
                    NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF) := NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF) + LN_BORC_TUTAR;
                END IF; --ln_son_bakiye >= ln_borc_tutar
            ELSE  --row_kk.masraf_tipi = 'TOPLAM'
                LB_TAKSIT_VAR := TRUE;
                FOR ROW_TAKSIT IN CUR_TAKSITLER LOOP
                    LN_TAHSIL_TUTAR := ROW_TAKSIT.TAKSIT_TUTARI - NVL(ROW_TAKSIT.ODENEN_TUTAR,0);
                    IF VARCHAR_LIST(P_66206_DOVIZ_KODU) <> PKG_GENEL.LC_AL THEN
                        LN_TEMP_KOM := PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, PKG_KUR.MB_DAK_TO_LC(ROW_MASRAF.DVZ, LN_TAHSIL_TUTAR));
                        LN_VERGI    := PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, LN_TEMP_KOM * 15) / (100 + 15);
                        LN_KOMISYON := LN_TEMP_KOM - LN_VERGI;
                    ELSE
                        LN_TEMP_KOM := PKG_KUR.MB_DAK_TO_LC(ROW_MASRAF.DVZ, LN_TAHSIL_TUTAR);
                        LN_VERGI    := ROUND((LN_TEMP_KOM * 15) / (100 + 15), 2);
                        LN_KOMISYON := LN_TEMP_KOM - LN_VERGI;
                    END IF;
                    IF NVL(ROW_KK.DONEM_BAS_SON,'B') = 'B' THEN
                        BOOLEAN_LIST(P_66206_MASRAF_GECICI_VAR) := TRUE;
                        BOOLEAN_LIST(P_66206_MASRAF_GECICI_YOK) := FALSE;
                        NUMBER_LIST(P_66206_LC_KOMISYON_TUTAR)  := LN_KOMISYON + LN_VERGI;
                        NUMBER_LIST(P_66206_LC_VERGI)     := 0;
                        NUMBER_LIST(P_66206_KOM_VERGI)    := LN_KOMISYON + LN_VERGI;
                        NUMBER_LIST(P_66206_KOM_VERGI_FC) := LN_TAHSIL_TUTAR;
                    ELSE
                        BOOLEAN_LIST(P_66206_MASRAF_GECICI_VAR) := FALSE;
                        BOOLEAN_LIST(P_66206_MASRAF_GECICI_YOK) := TRUE;
                        NUMBER_LIST(P_66206_LC_KOMISYON_TUTAR)  := LN_KOMISYON;
                        NUMBER_LIST(P_66206_LC_VERGI)     := LN_VERGI;
                        NUMBER_LIST(P_66206_KOM_VERGI)    := LN_KOMISYON + LN_VERGI;
                        NUMBER_LIST(P_66206_KOM_VERGI_FC) := LN_TAHSIL_TUTAR;
                    END IF;
                    LN_BORC_TUTAR := LN_TAHSIL_TUTAR;
                    LN_BORC_TRL := LN_KOMISYON + LN_VERGI;
                    IF LN_SON_BAKIYE >= LN_BORC_TUTAR  THEN
                        LN_FIS_NO:=PKG_MUHASEBE.FIS_KES ( 66206, NULL, PN_ISLEM_NO, VARCHAR_LIST, NUMBER_LIST,
                                                      DATE_LIST, BOOLEAN_LIST, NULL, FALSE, LN_FIS_NO, NULL);
                        UPDATE CBS_MASRAF_ITH_IHR_ISL
                        SET TAHSIL_TOPLAM = NVL(TAHSIL_TOPLAM,0) + LN_TAHSIL_TUTAR,
                            TAHSIL_EDILEMEYEN = TAHSIL_EDILEMEYEN - LN_TAHSIL_TUTAR
                        WHERE ISLEM_NO = ROW_MASRAF.ISLEM_NO;
                        PKG_MASRAF.IPTAL_ICIN_LOG_AT_TAKSIT(PN_ISLEM_NO, ROW_TAKSIT.REFERANS, ROW_TAKSIT.TAKSIT_NO,
                                    ROW_TAKSIT.TAKSIT_ODEME_TARIH, LN_TAHSIL_TUTAR, ROW_MASRAF.MASRAF_KODU, ROW_MASRAF.VS_NO);

                        UPDATE CBS_MASRAF_TAKSIT_ISLEM
                        SET TAKSIT_ODEME_TARIH = PKG_MUHASEBE.BANKA_TARIHI_BUL,
                            ODENEN_TUTAR = LN_TAHSIL_TUTAR
                        WHERE ISLEM_NO = ROW_TAKSIT.ISLEM_NO AND TAKSIT_NO = ROW_TAKSIT.TAKSIT_NO;
                    
                        IF NVL(ROW_KK.DONEM_BAS_SON,'B') = 'B' THEN
                            PKG_MASRAF.GECICI_GERCEK_ICIN_KAYDET(PN_ISLEM_NO, ROW_TAKSIT.REFERANS,
                                                                ROW_MASRAF.MASRAF_KODU, ROW_MASRAF.VS_NO,
                                                                ROW_TAKSIT.TAKSIT_NO, ROW_TAKSIT.TAKSIT_ODEME_TARIH,
                                                                NUMBER_LIST(P_66206_KOM_VERGI), ROW_KK.MASRAF_HESAP_NO,
                                                                ROW_KK.GECERLILIK_TARIHI, 'E', NULL, NULL, 'E');
                        END IF;
                        LN_SON_BAKIYE := LN_SON_BAKIYE - LN_BORC_TUTAR ;
                        NUMBER_LIST(P_66206_LC_TOPLAM_MASRAF) := NUMBER_LIST(P_66206_LC_TOPLAM_MASRAF) + LN_BORC_TRL;
                        NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF) := NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF) + LN_BORC_TUTAR;
                    ELSE
                        --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
                        RAISE_APPLICATION_ERROR(-20100,PKG_HATA.GETUCPOINTER || '644' ||  PKG_HATA.GETDELIMITER || LTRIM(TO_CHAR(LN_BORC_TUTAR, '999,999,999,999,999,999,999.99')) || PKG_HATA.GETDELIMITER || PKG_HATA.GETDELIMITER || LTRIM(TO_CHAR(LN_SON_BAKIYE, '999,999,999,999,999,999,999.99')) || PKG_HATA.GETUCPOINTER);			     
                    END IF;
                END LOOP;
            END IF;  --tipi toplam
        ELSE
            RAISE_APPLICATION_ERROR(-20100,PKG_HATA.GETUCPOINTER || '341' ||  PKG_HATA.GETDELIMITER || ROW_MASRAF.MASRAF_KODU || PKG_HATA.GETUCPOINTER);
        END IF;
    END IF;  --tahsil edilmeyen var....
	PN_FIS_NO := LN_FIS_NO;
	IF ROW_MASRAF.KOMISYON_TIPI NOT LIKE 'DONEMSEL%' THEN
		UPDATE CBS_KIRALIK_KASA_ACILIS
		SET    TOPLAM_MASRAF		       = NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF),
			   GELIRLERE_ALINAN_MASRAF     = NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF),
			   GECICIYE_ALINACAK_MASRAF    = 0,
			   ILK_MASRAF_ODEME_TARIHI     = NULL,
			   GELECEK_MASRAF_ODEME_TARIHI = NULL
		WHERE  REFERANS_NO = LS_REFERANS
	    AND    SUBE_KODU   = ROW_KK.SUBE_KODU
		AND    SAFE_BOX_NO   = ROW_KK.SAFE_BOX_NO;
	ELSE
	    IF ROW_KK.MASRAF_TIPI = 'TOPLAM' THEN
		    LD_GELECEK_ODEME_TARIHI := ADD_MONTHS(ROW_KK.KONTRAT_TARIHI,1);
			IF PKG_TARIH.GUN_OZELLIK(LD_GELECEK_ODEME_TARIHI) = 1 THEN
		       LD_GELECEK_ODEME_TARIHI := PKG_TARIH.ILERI_IS_GUNU(ADD_MONTHS(ROW_KK.KONTRAT_TARIHI,1));
			END IF;

			UPDATE CBS_KIRALIK_KASA_ACILIS
			SET    TOPLAM_MASRAF		       = NUMBER_LIST(P_66206_LC_TOPLAM_MASRAF),
--TODO				   gelirlere_alinan_masraf     = ln_gelirlere_alinacak,
--				   geciciye_alinacak_masraf    = number_list(p_66206_lc_toplam_masraf) - ln_gelirlere_alinacak,
				   ILK_MASRAF_ODEME_TARIHI     = ROW_KK.KONTRAT_TARIHI,
				   GELECEK_MASRAF_ODEME_TARIHI = LD_GELECEK_ODEME_TARIHI
			WHERE  REFERANS_NO = LS_REFERANS
		    AND    SUBE_KODU   = ROW_KK.SUBE_KODU
			AND    SAFE_BOX_NO   = ROW_KK.SAFE_BOX_NO;

		ELSE
			UPDATE CBS_KIRALIK_KASA_ACILIS
			SET    TOPLAM_MASRAF		       = NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF),
				   GELIRLERE_ALINAN_MASRAF     = NUMBER_LIST(P_66206_FC_TOPLAM_MASRAF),
				   GECICIYE_ALINACAK_MASRAF    = 0,
				   ILK_MASRAF_ODEME_TARIHI     = NULL,
				   GELECEK_MASRAF_ODEME_TARIHI = NULL
			WHERE  REFERANS_NO = LS_REFERANS
		    AND    SUBE_KODU   = ROW_KK.SUBE_KODU
			AND    SAFE_BOX_NO   = ROW_KK.SAFE_BOX_NO;

		END IF;
	END IF;
  END;
/*------------------------------------------------------------------------------------------------------*/
  procedure iptal_muhasebelestir_sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
    null;
   end;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
  procedure muhasebe_sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
    pkg_masraf.muhasebe_sonrasi_grs_guncel(pn_islem_no, ps_ref, null);
  end;
/*------------------------------------------------------------------------------------------------------*/
  procedure eod_muhasebelesme(pn_islem_no number, pn_fis_no in out number, ps_referans varchar2, pn_vs_no number, ps_masraf_kodu varchar2) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_eski_tahsil_tutar	  number;
   ln_tahsil_tutar		  number;
   ls_istatistik_kodu     varchar2(2000);
   ls_aciklama			  varchar2(2000);
   ls_nakit_kodu 		  varchar2(2000);
   ln_vergi				  number;
   ln_komisyon			  number;
   ld_gelecek_odeme_tarihi		 date;

   ls_1  varchar2(2000);
   ls_2  varchar2(2000);
   ls_3  varchar2(2000);
   ls_4  varchar2(2000);
   ln_1 boolean;

   cursor cur_masraf is
    select *
	  from cbs_masraf_ith_ihr
	 where referans = ps_referans
	   and durum = 'VALID'
	 order by sira_no
	for update;
	row_masraf cur_masraf%rowtype;

    cursor cur_masraf_count is
    select count(*)
	  from cbs_masraf_ith_ihr
	 where referans = ps_referans
	   and durum = 'VALID';
	 ln_temp number;

   cursor cur_kiralik_kasa is
     select * from cbs_kiralik_kasa_acilis
	  where referans_no = ps_referans;
	 row_kk cur_kiralik_kasa%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit a
	  where referans = ps_referans
	    AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
	    AND NVL(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;
   ls_acik_tutar_ref varchar2(100);
   ln_dk_grup_no     number;
/*
   cursor c_all_taksit is
   select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no; --referans = ls_referans
  r_all_taksit c_all_taksit%rowtype;

   cursor c_all_taksit_sayi is
   select count(*) sayi from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no; --referans = ls_referans
  r_taksit_sayi c_all_taksit_sayi%rowtype;   */
  ld_gecerlilik_tarih date;
  i number;
  ln_odenecek number;
  ln_top_odenecek number;
  ln_temp_kom number;
  begin
  log_at(4,pn_islem_no, pn_fis_no, ps_referans);
  log_at(5, pn_vs_no, ps_masraf_kodu);

    ln_fis_no := pn_fis_no;
	open cur_masraf_count;
	fetch cur_masraf_count into ln_temp;
	close cur_masraf_count;
	if ln_temp <= 0 then
	  return;
	end if;

	boolean_list(p_66206_masraf_tipi_cash)  := false ;
	boolean_list(p_66206_masraf_tipi_acc)   := false ;
	boolean_list(p_66206_lc_masraf_tahsili) := false ;
	boolean_list(p_66206_fc_masraf_tahsili) := false ;
    boolean_list(p_66206_masraf_gecici_var) := false;
    boolean_list(p_66206_masraf_gecici_yok) := false;

	varchar_list(p_66206_doviz_kodu) := pkg_genel.lc_al;
	open cur_kiralik_kasa;
	fetch cur_kiralik_kasa into row_kk;
	 ls_akr_doviz := pkg_genel.lc_al ; --row_kk.masraf_doviz_kodu;
	 if row_kk.masraf_hesap_no is not null then
    	 varchar_list(p_66206_hesap_no) := row_kk.masraf_hesap_no;
	     varchar_list(p_66206_doviz_kodu):= pkg_hesap.hesaptandovizkodual(row_kk.masraf_hesap_no);
	     varchar_list(p_66206_hesap_sube) := pkg_hesap.hesapsubeal(row_kk.masraf_hesap_no);
	 end if;
	 varchar_list(p_66206_islem_sube) := row_kk.sube_kodu;
	 ls_referans := row_kk.referans_no;
	 ls_nakit_kodu :=  nvl(to_char(row_kk.nakit_kodu),' ');
	 ls_istatistik_kodu := (to_char(nvl(row_kk.prefix_istatistik_kodu,0)) || nvl(row_kk.ist_doviz_kodu,row_kk.masraf_doviz_kodu) || to_char(nvl(row_kk.istatistik_kodu,0)));

	 varchar_list(p_66206_referans) 		:= ls_referans;
	 varchar_list(p_66206_istatistik_kodu)  := ls_istatistik_kodu;
	 varchar_list(p_66206_nakit_kodu)  		:= ls_nakit_kodu;
	 ls_aciklama :=  '???????? ?? ?????? ???????? ?????? ??? ? ??? ????? ' || pkg_musteri.Sf_Musteri_Adi(row_kk.MUSTERI_NO) ;
	 varchar_list(p_66206_banka_aciklama)  := ls_aciklama ;
	 varchar_list(p_66206_musteri_aciklama):= ls_aciklama ;

    if varchar_list(p_66206_doviz_kodu) = pkg_genel.lc_al then
			boolean_list(p_66206_lc_masraf_tahsili):=true;
			boolean_list(p_66206_fc_masraf_tahsili):=false;
	else
			boolean_list(p_66206_lc_masraf_tahsili):=false;
			boolean_list(p_66206_fc_masraf_tahsili):=true;
	end if;

	if row_kk.masraf_hesabin_tipi = 'KASA' then
		boolean_list(p_66206_masraf_tipi_cash) :=true;
		boolean_list(p_66206_masraf_tipi_acc)  :=false;
	else
		boolean_list(p_66206_masraf_tipi_cash) :=false;
		boolean_list(p_66206_masraf_tipi_acc)  :=true;
	end if;

	ln_dk_grup_no :=pkg_musteri.sf_musteri_dk_grup_kod_al( row_kk.musteri_no);

	if ln_dk_grup_no is not null then
		varchar_list(p_66206_komisyon_gl)	:=pkg_muhasebe.komisyon_dk_bul( ln_dk_grup_no,'SAFEDEPCOM');
	else
 		varchar_list(p_66206_komisyon_gl)	:= '' ;
	end if;

	number_list(p_66206_lc_toplam_masraf) := 0;
	number_list(p_66206_fc_toplam_masraf) := 0;
	number_list(p_66206_lc_komisyon_tutar):= 0;
	number_list(p_66206_lc_vergi) 		  := 0;
	number_list(p_66206_kom_vergi) := 0;
	number_list(p_66206_kom_vergi_fc) := 0;

	if row_kk.masraf_hesap_no is not null then  --masraf hesabi girilmisse
	  if varchar_list(p_66206_doviz_kodu) <> pkg_genel.lc_al then
		number_list(p_66206_kur) := pkg_kur.doviz_doviz_karsilik(varchar_list(p_66206_doviz_kodu),
						                                         pkg_genel.lc_al, null, 1, 1,
														         null, null, 'N', 'A');
	  else
		number_list(p_66206_kur) := pkg_komisyon_kur.kom_doviz_doviz_karsilik(varchar_list(p_66206_doviz_kodu),
						                             pkg_genel.lc_al, null, 1, null, null);
	  end if;
		--masraf alinacak hesabin bakiyesini al
	  ln_son_bakiye := pkg_hesap.kullanilabilir_bakiye_al(varchar_list(p_66206_hesap_no));
    end if;

	open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
 log_at(6, nvl(row_masraf.tahsil_edilemeyen,0));
	  if nvl(row_masraf.tahsil_edilemeyen,0) > 0  then
	      ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
 log_at(7, ln_tahsil_tutar,row_masraf.masraf_kodu );
		  if row_masraf.masraf_kodu =  'SAFEDEPCOM' then
		    ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
 log_at(8, ln_eski_tahsil_tutar,nvl(row_masraf.tahsil_edilemeyen,0));
			if nvl(row_masraf.tahsil_edilemeyen,0) <= 0  then
			   ln_tahsil_tutar := 0;
			   log_at(9, ln_eski_tahsil_tutar,nvl(row_masraf.tahsil_edilemeyen,0));
			else
			   log_at(10, row_kk.masraf_tipi);
			   if row_kk.masraf_tipi = 'TOPLAM' then  --toplam tahsilat yap?lacak.....
   			   log_at(11, row_kk.masraf_tipi);
			      null;
			   else  --row_kk.masraf_tipi = 'TOPLAM'
			   log_at(12, row_kk.masraf_tipi);
				  lb_taksit_var := true;
				  open cur_taksitler;
				  loop
				    fetch cur_taksitler into row_taksit;
					exit when cur_taksitler%notfound;

					ln_tahsil_tutar := row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0);
			log_at(13, row_taksit.REFERANS,ln_tahsil_tutar);
				    if varchar_list(p_66206_doviz_kodu) <> pkg_genel.lc_al then
					    ln_temp_kom := pkg_kur.yuvarla(pkg_genel.lc_al, pkg_kur.mb_dak_to_lc(row_masraf.dvz, ln_tahsil_tutar));
						ln_vergi    := pkg_kur.yuvarla(pkg_genel.lc_al, ln_temp_kom * 15)/(100+15)  ;
						ln_komisyon := ln_temp_kom - ln_vergi ;
					else
					    ln_temp_kom := Pkg_Kur.mb_dak_to_lc(row_masraf.dvz, ln_tahsil_tutar);
						ln_vergi    := round((ln_temp_kom * 15)/(100+15), 2)  ;
						ln_komisyon := ln_temp_kom - ln_vergi ;
					end if;
					if nvl(row_kk.donem_bas_son,'B') = 'B' then
					  boolean_list(p_66206_masraf_gecici_var) := true;
					  boolean_list(p_66206_masraf_gecici_yok) := false;
					  number_list(p_66206_lc_komisyon_tutar):= ln_komisyon+ln_vergi ;
					  number_list(p_66206_lc_vergi)  := 0 ;
					  number_list(p_66206_kom_vergi) := ln_komisyon+ln_vergi;
					  number_list(p_66206_kom_vergi_fc) := ln_tahsil_tutar;
					else
					  boolean_list(p_66206_masraf_gecici_var) := false;
					  boolean_list(p_66206_masraf_gecici_yok) := true;
					  number_list(p_66206_lc_komisyon_tutar):= ln_komisyon ;
					  number_list(p_66206_lc_vergi) := ln_vergi ;
					  number_list(p_66206_kom_vergi) := ln_komisyon+ln_vergi;
					  number_list(p_66206_kom_vergi_fc) := ln_tahsil_tutar;
					end if;
					ln_borc_tutar := ln_tahsil_tutar;
					ln_borc_trl := ln_komisyon+ln_vergi;
			log_at(14);
			log_at(15,ln_son_bakiye, ln_borc_tutar );

					if ln_son_bakiye >= ln_borc_tutar then
			log_at(16);
					    ln_fis_no:=pkg_muhasebe.fis_kes ( 66206, null, pn_islem_no, varchar_list, number_list,
									    			  	  date_list, boolean_list, null, false, ln_fis_no, null);
					    update cbs_masraf_ith_ihr
						   set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
						       tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
					     where current of cur_masraf;

						  		pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
	                                                       row_taksit.taksit_odeme_tarih, ln_tahsil_tutar, row_masraf.masraf_kodu, row_masraf.vs_no);

						update cbs_masraf_taksit
						   set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
						       odenen_tutar = ln_tahsil_tutar
						 where current of cur_taksitler;
	                     if nvl(row_kk.donem_bas_son,'B') = 'B' then
							  Pkg_Masraf.gecici_gercek_icin_kaydet_eod(pn_islem_no, row_masraf.sira_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_66206_kom_vergi), row_kk.masraf_hesap_no,
																   row_kk.gecerlilik_tarihi, 'E', row_kk.sube_kodu, null, 'E');

						end if;
						ln_son_bakiye := ln_son_bakiye - ln_borc_tutar ;
						number_list(p_66206_lc_toplam_masraf) := number_list(p_66206_lc_toplam_masraf) + ln_borc_trl;
						number_list(p_66206_fc_toplam_masraf) := number_list(p_66206_fc_toplam_masraf) + ln_borc_tutar;
			log_at(17);
		            else
			log_at(18,row_kk.masraf_tipi || '-');
					 close cur_taksitler;
					 close cur_masraf;
			        --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
					--TA
			         --raise_application_error(-20100,pkg_hata.getucpointer || '644' ||  pkg_hata.getdelimiter || ltrim(to_char(ln_borc_tutar, '999,999,999,999,999,999,999.99')) || pkg_hata.getdelimiter || varchar_list(p_66206_hesap_no) || pkg_hata.getdelimiter || ltrim(to_char(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || pkg_hata.getucpointer);
					end if;
				  end loop;
				  close cur_taksitler;
log_at(20);
			  end if;  --tipi toplam
log_at(21);
			end if;
log_at(22);
		  else
log_at(23);
		    close cur_masraf;
	 	    raise_application_error(-20100,pkg_hata.getucpointer || '341' ||  pkg_hata.getdelimiter || row_masraf.masraf_kodu || pkg_hata.getucpointer);
		  end if;
log_at(24);
	  end if;  --tahsil edilmeyen var....
log_at(25);
	end loop;
	pn_fis_no := ln_fis_no;
	close cur_masraf;
	close cur_kiralik_kasa;
  end;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
BEGIN
	P_66206_MASRAF_TIPI_CASH		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_MASRAF_TIPI_CASH');
	P_66206_MASRAF_TIPI_ACC			:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_MASRAF_TIPI_ACC');
	P_66206_LC_MASRAF_TAHSILI		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_LC_MASRAF_TAHSILI');
	P_66206_FC_MASRAF_TAHSILI		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_FC_MASRAF_TAHSILI');
	P_66206_ISLEM_SUBE				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_ISLEM_SUBE');
	P_66206_BANKA_ACIKLAMA			:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_BANKA_ACIKLAMA');
	P_66206_MUSTERI_ACIKLAMA		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_MUSTERI_ACIKLAMA');
	P_66206_ISTATISTIK_KODU			:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_ISTATISTIK_KODU');
	P_66206_NAKIT_KODU				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_NAKIT_KODU');
	P_66206_REFERANS				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_REFERANS');
	P_66206_DOVIZ_KODU				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_DOVIZ_KODU');
	P_66206_HESAP_NO				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_HESAP_NO');
	P_66206_HESAP_SUBE				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_HESAP_SUBE');
	P_66206_KOMISYON_GL				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_KOMISYON_GL');
	P_66206_LC_TOPLAM_MASRAF		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_LC_TOPLAM_MASRAF');
	P_66206_FC_TOPLAM_MASRAF		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_FC_TOPLAM_MASRAF');
	P_66206_LC_KOMISYON_TUTAR		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_LC_KOMISYON_TUTAR');
	P_66206_LC_VERGI				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_LC_VERGI');
	P_66206_KUR						:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_KUR');
	P_66206_MASRAF_GECICI_VAR		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_MASRAF_GECICI_VAR');
	P_66206_MASRAF_GECICI_YOK		:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_MASRAF_GECICI_YOK');
    P_66206_KOM_VERGI 				:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_KOM_VERGI');
    P_66206_KOM_VERGI_FC			:= PKG_MUHASEBE.PARAMETRE_INDEX_BUL('66206_KOM_VERGI_FC');
END;
/

