create PACKAGE BODY     PKG_INT_ACCOUNT_TRX IS

FUNCTION PostNewCheckingAccount(ps_customer_id varchar2,
                                ps_name varchar2,
                                ps_currency_code varchar2,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER', 
                                pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_channel_code number; 
ln_cash_code number; 
ls_branch_code varchar(10);
ls_checkbook varchar2(1);
ln_account_transaction_code number;
ln_base_number_of_days number;
ls_extract_edition_code varchar2(1);
ls_direct_debit varchar2(1);
ls_direct_debit_annual varchar2(1);
ln_count number; 
ln_account_count number; 
ln_customer_number number; 
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
le_account_limit exception;
le_bad_list exception;
le_blockage exception;
le_passport exception;
le_branch_not_active exception;
BEGIN
      ln_transaction_number := pkg_tx.islem_no_al;
      ln_transaction_code := 2000;
      ln_channel_code := to_number(ps_channel_code);
      ls_module_type_code := 'CURRENT';
      ls_product_type_code := 'DEMAND DEP';
      
      ls_checkbook := 'H';
      ln_account_transaction_code := 1;
      ln_base_number_of_days := 360;
      ls_extract_edition_code := 'X';
      ls_direct_debit := 'H';
      ls_direct_debit_annual := 'H';
      
      if ps_currency_code = pkg_genel.lc_al then
         ls_product_class_code := 'NON INT.BEARING-LC';
      else
         ls_product_class_code := 'NON INT.BEARING-FC';
      end if;
      
      ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
      
      if ln_customer_number is null then
          raise le_customer_not_found;
      end if;
      
      select count(*) into ln_account_count from cbs_vw_checking_account where 
                                                    customer_no = ln_customer_number 
                                                    and currency_code = ps_currency_code
                                                    and status = 'A' 
                                                    and module_type_code = 'CURRENT'
                                                    and product_type_code ='DEMAND DEP'
                                                    and product_class_code in ('NON INT.BEARING-FC', 'NON INT.BEARING-LC');
      
    if ln_account_count > 10 then
         raise le_account_limit;
    end if;
      
    select count(*) into ln_count from cbs_bad_list where 
                                    customer_no = ln_customer_number 
                                    and status_code = 'ACTIVE';
                                    
          
    if ln_count > 0 then
        raise le_bad_list;
    end if;
     
    select count(*) into ln_count from cbs_bloke where musteri_no = ln_customer_number 
                                                   and durum_kodu = 'A' 
                                                   and bloke_neden_kodu in (70, 1);
                                                   
    if ln_count > 0 then
        raise le_blockage;
    end if;
    
    ln_count := pkg_int_customer_inq.CheckForPassportExpiredDate(ps_customer_id); 
    
    if ln_count != 1 then
        raise le_passport;
    end if; 

                                                  
    ls_branch_code  := pkg_musteri.sf_bolum_kodu_al(ln_customer_number);
      
    if PKG_INT_CUSTOMER_INQ.CheckCustBranchIsNotActive(ls_branch_code) then
       raise le_branch_not_active;
    end if;
    
    pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
    
      insert into cbs_hesap_basvuru(tx_no,
                                     musteri_no,
                                     urun_tur_kod,
                                     kisa_isim,
                                     doviz_kodu,
                                     cek_karnesi,
                                     hesap_hareket_kodu,
                                     esas_gun_sayisi,
                                     ekstre_basim_kodu,
                                     sube_kodu,
                                     urun_sinif_kod,
                                     modul_tur_kod,
                                     direct_debit,
                                     direct_debit_annual)
                               values (ln_transaction_number,
                                       ln_customer_number,
                                       ls_product_type_code,
                                       ps_name,
                                       ps_currency_code,
                                       ls_checkbook,
                                       ln_account_transaction_code,
                                       ln_base_number_of_days,
                                       ls_extract_edition_code,
                                       ls_branch_code,
                                       ls_product_class_code,
                                       ls_module_type_code,
                                       ls_direct_debit,
                                       ls_direct_debit_annual);
                                         
       pkg_int_api.create_transaction(ln_transaction_number,
                                       ln_transaction_code,
                                       ls_module_type_code,
                                       ls_product_type_code,
                                       ls_product_class_code,
                                       0,
                                       ls_branch_code,
                                       ls_branch_code, --'INT'
                                       ln_role,
                                       ps_currency_code,
                                       ln_customer_number,
                                       null,
                                       ln_cash_code,
                                       ln_channel_code,
                                       ps_user_code);
                                       
        pkg_int_api.process_transaction(ln_transaction_number);
     
     open pc_ref for
         select external_hesap_no as iban, ln_transaction_number as transaction_number from cbs_hesap_basvuru where tx_no = ln_transaction_number;
     
      commit;
      
      return ls_returncode;

EXCEPTION 
    when le_customer_not_found then
          rollback;
          return '454'; 
    when le_account_limit then
          rollback;
          return '456'; 
    when le_bad_list then
          rollback;
          return '457'; 
    when le_blockage then  
          rollback;
          return '461'; 
    when le_passport then
          return '463'; 
    when le_branch_not_active then
          return '464';   
    when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PostNewCheckingAccount', ps_customer_id || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
         
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         
         return ls_returncode;  
END;

FUNCTION PutCheckingAccountName(ps_iban varchar2,
                                ps_new_name varchar2,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER',   
                                pc_ref out CursorReferenceType) RETURN varchar2
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_channel_code number; 
ln_cash_code number; 
ls_branch_code varchar(10);
ln_account_number number;
ln_customer_number number;
ls_currency_code varchar(10);
ls_returncode varchar2(3) := '000';
BEGIN
   
      ln_transaction_number := pkg_tx.islem_no_al;
      ln_transaction_code := 2002;
      ln_channel_code := to_number(ps_channel_code);
      
      ln_account_number := pkg_int_account_inq.GetAccountNumberByIban(ps_iban);
      ls_currency_code  := pkg_hesap.hesaptandovizkodual(ln_account_number);
      ln_customer_number := pkg_hesap.hesaptanmusterinoal(ln_account_number);
      ls_branch_code  := pkg_hesap.hesapsubeal(ln_account_number);
      
      pkg_hesap.vadesizbilgiaktar(ln_account_number, ln_transaction_number);
      
      update cbs_hesap_g_basvuru 
            set kisa_isim = ps_new_name 
                 where tx_no = ln_transaction_number;
      
      pkg_hesap.urunbilgial(ln_account_number, ls_module_type_code, ls_product_type_code, ls_product_class_code); 

      
      pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
       
      pkg_int_api.create_transaction(ln_transaction_number,
                                       ln_transaction_code,
                                       ls_module_type_code,
                                       ls_product_type_code,
                                       ls_product_class_code,
                                       0,
                                       ls_branch_code,
                                       ls_branch_code, --'INT'
                                       ln_role,
                                       ls_currency_code,
                                       ln_customer_number,
                                       ln_account_number,
                                       ln_cash_code,
                                       ln_channel_code,
                                       ps_user_code);
                                       
      pkg_int_api.process_transaction(ln_transaction_number);

      open pc_ref for
         select ln_transaction_number as transaction_number from dual;

      commit;

      return ls_returncode;

EXCEPTION
    when no_data_found then
          rollback;
          return '454'; 
    when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PutCheckingAccountName', ps_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
         
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         
         return ls_returncode; 
END;            
                                
FUNCTION DeleteCheckingAccount(ps_iban varchar2, 
                                    ps_channel_code varchar2 default '1',
                                    ps_user_code varchar2 default 'CINT_CALLER', 
                                    pc_ref OUT CursorReferenceType) RETURN varchar2 
IS 
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_channel_code number; 
ln_cash_code number; 
ls_branch_code varchar(10);
ln_account_number number;
ln_customer_number number;
ls_currency_code varchar(10);
ls_returncode varchar2(3) := '000';
ls_description  varchar2(100) := 'CLOSING CHECKING ACCOUNT'; 
BEGIN
      --Debit Link Control
       ln_transaction_number := pkg_tx.islem_no_al;
      ln_transaction_code := 2002;
      ln_channel_code := to_number(ps_channel_code);
      
      ln_account_number := pkg_int_account_inq.GetAccountNumberByIban(ps_iban);
      ls_currency_code  := pkg_hesap.hesaptandovizkodual(ln_account_number);
      ln_customer_number := pkg_hesap.hesaptanmusterinoal(ln_account_number);
      ls_branch_code  := pkg_hesap.hesapsubeal(ln_account_number);
      
      pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
      
      pkg_hesap.vadesizbilgiaktar(ln_account_number, ln_transaction_number);
      
      update cbs_hesap_g_basvuru 
            set durum_kodu = 'K' 
                 where tx_no = ln_transaction_number;
      
      pkg_hesap.urunbilgial(ln_account_number, ls_module_type_code, ls_product_type_code, ls_product_class_code); 

      
     pkg_int_api.create_transaction(ln_transaction_number,
                                       ln_transaction_code,
                                       ls_module_type_code,
                                       ls_product_type_code,
                                       ls_product_class_code,
                                       0,
                                       ls_branch_code,
                                       ls_branch_code, --'INT'
                                       ln_role,
                                       ls_currency_code,
                                       ln_customer_number,
                                       ln_account_number,
                                       ln_cash_code,
                                       ln_channel_code,
                                       ps_user_code);
                                       
      pkg_int_api.process_transaction(ln_transaction_number);

      open pc_ref for
         select ln_transaction_number as transaction_number from dual;

        commit;
        
       return ls_returncode;
       
EXCEPTION 
    when no_data_found then
          rollback;
          return '454'; 
    when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('DeleteCheckingAccount', ps_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
         
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         
         return ls_returncode;
END;

FUNCTION PostNewSavingAccount(ps_lang varchar2,
                              ps_source_account varchar2,
                              ps_name varchar2,
                              ps_amount varchar2,
                              ps_day varchar2,
                              ps_due_date varchar2,
                              ps_channel_code varchar2 default '1',
                              ps_user_code varchar2 default 'CINT_CALLER',   
                              pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_channel_code number; 
ln_cash_code number; 
ln_new_account number;
ln_amount number;
ln_interest_rate number := 0;
ln_account_number number;
ls_currency_code varchar(10);
ln_customer_number number;
ls_branch_code varchar2(10);
ld_system_date date;
ld_value_date date;
ln_prefix number;

ls_statistics varchar2(3) := '322';
ln_debit_record number := 1;
ln_maturity_info number := 1;
ln_intermediate_payment number := 1;
ln_intermediate_payment_trx number;
ld_next_start_date date;
ln_base_number_of_days number;
ln_correspondent_account number;
ls_automatic_revalidation varchar2(1 byte);
ls_period_of_time varchar2(1 byte);
ls_period_type varchar2(1 byte);
ls_dk_numara varchar2(30 byte);
ld_due_date date;
ld_due_date2 date;
ls_description varchar2(200 byte);
ln_min_amount_kgs number;
ln_min_amount_usd number;
ln_min_amount_rub number;

ls_returncode varchar2(3) := '000';

le_branch_not_active exception;
le_min_sum exception;
nointerestratesondate exception;
notenoughbalance exception;
begin

    ln_transaction_number := pkg_tx.islem_no_al;
    ln_transaction_code := 2003 ;
    ln_channel_code := to_number(ps_channel_code);
    ln_new_account := pkg_genel.genel_kod_al('HESAP.VDSZ');
    ln_amount := to_number(ps_amount,'999999999999999.999');
    ln_base_number_of_days := 365;
    ls_description := 'OPEN TIME DEPOSIT ACCOUNT THROUGH INTERNET';
    
    ln_account_number := to_number(ps_source_account);
    ls_currency_code  := pkg_hesap.hesaptandovizkodual(ln_account_number);
    ln_customer_number := pkg_hesap.hesaptanmusterinoal(ln_account_number);
    ls_branch_code  := pkg_musteri.sf_bolum_kodu_al(ln_customer_number);
    ld_system_date:= pkg_muhasebe.banka_tarihi_bul;
    ln_prefix := pkg_soa_common.getcustomerprefixcode(ln_customer_number);
    
    pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
    
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_KGS',ln_min_amount_kgs);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_USD',ln_min_amount_usd);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_RUB',ln_min_amount_rub);
    
    if ls_currency_code = 'KGS' then
        if ln_amount < ln_min_amount_kgs then
            raise le_min_sum;
        end if;
    elsif ls_currency_code = 'USD' then
        if ln_amount < ln_min_amount_usd then
            raise le_min_sum;
        end if;
    elsif ls_currency_code = 'RUB' then
        if ln_amount < ln_min_amount_rub then
            raise le_min_sum;
        end if;
    end if;
    
    if PKG_INT_CUSTOMER_INQ.CheckCustBranchIsNotActive(ls_branch_code) then
       raise le_branch_not_active;
    end if;
    
    if pkg_hesap.kullanilabilir_bakiye_al(ln_account_number) < ln_amount then
         raise notenoughbalance;
    end if;
    
     
    if trunc(ld_system_date) <= trunc(sysdate) then
        ld_value_date := ld_system_date + 1;
    else
        ld_value_date := trunc(sysdate + 1);
    end if;
    
    if ps_day > 0 then
    
     select decode(ls_currency_code, 'RUB', rub, 'USD', usd, 'EUR', eur, trl)
        into ln_interest_rate
            from cbs_cari_vadeli_mevduat_fo
                where 
                    tarih = pkg_muhasebe.banka_tarihi_bul 
                    and vade_1 <= to_number(ps_day)
                    and vade_2 >= to_number(ps_day)
                    and musteri_tipi = '1';
        
        select to_date(to_char(sysdate + to_number(ps_day), 'YYYY-MM-DD'), 'YYYY-MM-DD') into ld_due_date from dual;
        
    elsif ps_due_date is not null then
    
      ld_due_date2 := to_date(substr(ps_due_date, 1, 10),'YYYY-MM-DD'); 
    
      if ld_due_date2 < pkg_muhasebe.banka_tarihi_bul then
        raise nointerestratesondate;
      end if;
      
      select decode(ls_currency_code,'RUB',rub,'USD',usd,'EUR',eur,trl)
            into ln_interest_rate
            from cbs_cari_vadeli_mevduat_fo
                where tarih = pkg_muhasebe.banka_tarihi_bul
                    and vade_1 <= ld_due_date2 - sysdate
                    and vade_2 >= ld_due_date2 - sysdate
                    and musteri_tipi = '1';
        
        ld_due_date := ld_due_date2;
    else
      raise nointerestratesondate;
    end if;
    
    ld_due_date := Pkg_Tarih.tarihten_sonraki_isgunu(ld_due_date-1);
    
    if ld_due_date < pkg_muhasebe.banka_tarihi_bul   then
        raise nointerestratesondate;
    end if;
    
    if ls_currency_code = pkg_genel.lc_al then
        ls_product_class_code:='LC';
    else
        ls_product_class_code:='FC';
    end if;
    
    if ld_due_date - pkg_muhasebe.banka_tarihi_bul >= 366 then
        ls_module_type_code := 'TIME DEP.';
        ls_product_type_code := 'LONG TERM';
    else
        ls_module_type_code := 'TIME DEP.';
        ls_product_type_code := 'SHORT TERM';
    end if;
    
    insert into cbs_hesap_vadeli_basvuru(
        tx_no, hesap_numarasi, musteri_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod, kisa_isim,
        doviz_kodu, tutar, valor_tarihi, borc_kaydi, borclu_hesap_no, muhabir_hesap_no, dk_no,
        vade_islem_bilgisi, ara_odeme_bilgisi, otomatik_temdit, period_sure, period_cins, sonraki_baslangic_tarihi,
        ara_odeme_islem_bilgisi, vade_tarihi, geri_donus_hesapno, esas_gun_sayisi, faiz_orani, aciklama,
        ekstre_basim_kodu,ekstre_sikligi, dekont, sube_kodu, acilis_tarihi, min_imza_adedi, musteri_dk_no, muhasebe_tarihi,
        istatistik_kodu_alis, prefix_istatistik_kodu_alis, istatistik_kodu_kapama,
        prefix_istatistik_kodu_kapama, istatistik_kodu_faiz, prefix_istatistik_kodu_faiz,ref_staff)
    values (ln_transaction_number, ln_new_account, ln_customer_number, ls_module_type_code, ls_product_type_code, ls_product_class_code, substr(ps_name,1,20),
            ls_currency_code, ln_amount, ld_value_date, ln_debit_record, ln_account_number, ln_correspondent_account, ls_dk_numara,
            ln_maturity_info, ln_intermediate_payment, ls_automatic_revalidation, ls_period_of_time, ls_period_type, ld_next_start_date,
            ln_intermediate_payment_trx, ld_due_date, ln_account_number, ln_base_number_of_days, ln_interest_rate, ls_description,
            'X', '', '', ls_branch_code, ld_system_date, '', '', ld_system_date,
            ls_statistics, ln_prefix, ls_statistics, 
            322, ls_statistics, ln_prefix, user);

    pkg_int_api.create_transaction(ln_transaction_number, 
                                   ln_transaction_code,
                                   ls_module_type_code, 
                                   ls_product_type_code, 
                                   ls_product_class_code,
                                   ln_amount, 
                                   ls_branch_code, 
                                   ls_branch_code,
                                   ln_role,
                                   ls_currency_code,
                                   ln_customer_number,
                                   ln_account_number,
                                   ln_cash_code,
                                   ln_channel_code,
                                   ps_user_code);

    pkg_int_api.process_transaction(ln_transaction_number);

    open pc_ref for
        select to_char(ln_new_account) as account_number, ln_transaction_number as transaction_number from dual;
    
    commit;
    
    return ls_returncode;
    
EXCEPTION
    when le_branch_not_active then
          return '464'; 
    when le_min_sum then
          return '460'; 
    when notenoughbalance then
          return '456';
    when nointerestratesondate then
          return '461';
    when no_data_found then
         log_at('PostNewSavingAccount', ps_source_account || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
          rollback;
          return '490'; 
    when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PostNewSavingAccount', ps_source_account || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
         
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         
         return ls_returncode; 
END;

FUNCTION PutSavingAccountName(ps_account_number varchar2,
                              ps_new_name varchar2,
                              ps_channel_code varchar2 default '1',
                              ps_user_code varchar2 default 'CINT_CALLER', 
                              pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_channel_code number; 
ln_cash_code number; 
ls_currency_code varchar(10);
ls_branch_code varchar(10);
ln_customer_number number;
ln_account_number number;
ls_returncode varchar2(3) := '000';
BEGIN
   
       ln_transaction_number := pkg_tx.islem_no_al;
       ln_transaction_code := 2005;
       ln_channel_code := to_number(ps_channel_code);
       ln_account_number := to_number(ps_account_number);
       ls_currency_code  := pkg_hesap.hesaptandovizkodual(ln_account_number);
       ln_customer_number := pkg_hesap.hesaptanmusterinoal(ln_account_number);
       ls_branch_code := pkg_hesap.hesapsubeal(ln_account_number);
       
       pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
       
       pkg_hesap.urunbilgial(ln_account_number, ls_module_type_code, ls_product_type_code, ls_product_class_code); 

       pkg_hesap.vadelibilgiaktar(ln_account_number, ln_transaction_number, 'MODIFICATION');
        
       update cbs_hesap_vadeli_g_basvuru 
                  set kisa_isim = ps_new_name
                           where tx_no = ln_transaction_number
                                 and hesap_no = ln_account_number;
    
       pkg_int_api.create_transaction(ln_transaction_number, 
                                   ln_transaction_code,
                                   ls_module_type_code, 
                                   ls_product_type_code, 
                                   ls_product_class_code,
                                   0, --amount
                                   ls_branch_code, 
                                   ls_branch_code,
                                   ln_role,
                                   ls_currency_code,
                                   ln_customer_number,
                                   ln_account_number,
                                   ln_cash_code,
                                   ln_channel_code,
                                   ps_user_code);

       pkg_int_api.process_transaction(ln_transaction_number);
      
         
       open pc_ref for
         select ln_transaction_number as transaction_number from dual;
         
        commit;
        
       return ls_returncode;
      
EXCEPTION
    when no_data_found then
          rollback;
          return '454'; 
    when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('PutSavingAccountName', ln_account_number || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
         
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         
         return ls_returncode; 
END;

FUNCTION DeleteSavingAccount(ps_account_number varchar2,
                                  ps_channel_code varchar2 default '1',
                                  ps_user_code varchar2 default 'CINT_CALLER', 
                                  pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_channel_code number; 
ln_cash_code number; 
ls_currency_code varchar(10);
ls_branch_code varchar(10);
ln_customer_number number;
ln_account_number number;
ln_amount number;
ln_rate number;
ln_last_year_interest number;
ln_accumulated_interest number;
ls_description  varchar2(100) := 'CLOSING TIME DEPOSIT BEFORE MATURITY ';
ls_returncode varchar2(3) := '000';      
BEGIN
  
        ln_transaction_number := pkg_tx.islem_no_al;
        ln_transaction_code := 2004;
        ln_channel_code := to_number(ps_channel_code);
        ln_account_number := to_number(ps_account_number);
        ls_currency_code  := pkg_hesap.hesaptandovizkodual(ln_account_number);
        ln_customer_number := pkg_hesap.hesaptanmusterinoal(ln_account_number);
        ls_branch_code  := pkg_hesap.hesapsubeal(ln_account_number);

        pkg_baglam.yarat(ls_branch_code, ln_role); --temporary

        ln_rate:= pkg_kur.doviz_doviz_karsilik(ls_currency_code, pkg_genel.lc_al, null, 1, 1, null, null,'N', 'A');
        
        ln_amount := pkg_hesap.kullanilabilir_bakiye_al(ps_account_number);

        pkg_hesap.urunbilgial(ln_account_number, ls_module_type_code, ls_product_type_code, ls_product_class_code);

        pkg_hesap.faizbilgial(ln_account_number,ln_amount, ln_last_year_interest, ln_accumulated_interest);

        insert into cbs_hesap_vdli_kapama_basvuru(tx_no, musteri_no, hesap_no, doviz_kodu, dk_no, bakiye_tutari, birikmis_faiz, 
                    gecen_yil_faizi, gecmis_aylarin_faizi, toplam_faiz_tutari, aciklama, 
                    net_odenen_tutar, tl_odeme_tutari, tl_odeme_sekli, 
                    tl_odeme_hesap_no, yp_odeme_tutari, yp_odeme_sekli, 
                    yp_odeme_hesap_no, tl_karsilik, kur, value_date)
        select ln_transaction_number, musteri_no, hesap_no, doviz_kodu, dk_no, ln_amount, ln_accumulated_interest, 
                    ln_last_year_interest, gecmis_aylarin_faizi, ln_accumulated_interest + ln_last_year_interest + gecmis_aylarin_faizi, ls_description, 
                    ln_amount, decode(doviz_kodu,'KGS',ln_amount,null), 2, 
                    decode(doviz_kodu, 'KGS', geri_donus_hesapno,null), decode(doviz_kodu,'KGS', null, ln_amount), 2, 
                    decode(doviz_kodu, 'KGS', null ,geri_donus_hesapno), decode(doviz_kodu,'KGS', ln_amount, null), ln_rate, vade_tarihi
              from cbs_hesap_vadeli
                   where  hesap_no = ln_account_number;
        

        pkg_int_api.create_transaction(ln_transaction_number,
                                       ln_transaction_code,
                                       ls_module_type_code,
                                       ls_product_type_code,
                                       ls_product_class_code,
                                       ln_amount,
                                       ls_branch_code,
                                       ls_branch_code,
                                       ln_role,
                                       ls_currency_code,
                                       ln_customer_number,
                                       ln_account_number,
                                       ln_cash_code,
                                       ln_channel_code,
                                       ps_user_code);
                                       
        pkg_int_api.process_transaction(ln_transaction_number);

        commit;
        
        open pc_ref for
          select ln_transaction_number as transaction_number from dual;
        
        return ls_returncode;
    
EXCEPTION
    when no_data_found then
          rollback;
          return '454'; 
    when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('DeleteSavingAccount', ln_account_number || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
         rollback;
         
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         
         return ls_returncode;
END;
END;
/

