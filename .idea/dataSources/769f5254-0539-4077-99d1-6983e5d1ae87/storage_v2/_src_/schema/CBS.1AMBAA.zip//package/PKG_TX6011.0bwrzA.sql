create PACKAGE Pkg_Tx6011 IS

/******************************************************************************
/*   Name         : PKG_TX6011
/*   Created By   : Gulnihal Cengiz
/*   Date    	  : 29/09/2003
/*   Purpose	  : Menkul Kiymet Banka Alimlarinin Sisteme Tanimlanmasi
******************************************************************************/
  FUNCTION  MenkulBankaAlim_Referansi_Al RETURN VARCHAR2;
  FUNCTION  Menkul_Bnk_Alim_iptal_ctrl(pn_stokno NUMBER) RETURN NUMBER ;
  FUNCTION  Sf_Hesap_Urun_Tipi_Uygunmu(ps_urun_tur_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Menkul_UrunTuru_Uygunmu(ps_urun_tur_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Depo_Turu_Uygunmu_Banka(ps_depo_turu CBS_DEPO_TUR_KODLARI.kod%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Depo_Turu_Uygunmu_Musteri(ps_depo_turu CBS_DEPO_TUR_KODLARI.kod%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Saklama_Yeri_Uygunmu(pn_kod CBS_SAKLAMA_YERI_KODLARI.kod%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Kaynak_Musteri_Uygunmu(ps_musteri_tipi CBS_MUSTERI_TIPI_KODLARI.musteri_tipi%TYPE,
 		  							  pn_grup_kod CBS_MUSTERI.grup_kod%TYPE  ) RETURN VARCHAR2;
  FUNCTION  Sf_Bloke_Hesap_Urunu_Uygunmu(ps_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Uygun_Stok_Kodu(ps_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;


  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

END;


/

