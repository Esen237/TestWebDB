create PACKAGE BODY     "PKG_SUBSCRIPTION" IS

/******************************************************************************
   Name       : FUNCTION encodeBase64
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Encode given string to Base64 encoding scheme
******************************************************************************/   
FUNCTION encodeBase64(str VARCHAR2) RETURN VARCHAR2 IS
BEGIN
    return utl_raw.cast_to_varchar2(utl_encode.base64_encode(utl_raw.cast_to_raw(str)));
END;

/******************************************************************************
   Name       : FUNCTION decodeBase64
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Decode given string from Base64 encoding scheme
******************************************************************************/   
FUNCTION decodeBase64(str VARCHAR2) RETURN VARCHAR2 IS
BEGIN
    return utl_raw.cast_to_varchar2(utl_encode.base64_decode(utl_raw.cast_to_raw(str)));
END;

/******************************************************************************
   Name       : FUNCTION CheckSubscription
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Check given customer link for customer's subscription to the email notification
******************************************************************************/   
FUNCTION CheckSubscription (pn_musteri_no IN NUMBER,ps_email VARCHAR2, ps_hash VARCHAR2) RETURN VARCHAR2 IS
    CURSOR c_customer_list IS    
        SELECT ma.email,
                    ma.musteri_no
        FROM cbs_musteri_adres ma
        WHERE ma.email is not null; 
                    
    r_cust_list c_customer_list%ROWTYPE;
    
    ls_hash VARCHAR2(100);
    ln_musteri_no NUMBER := 0;
    ls_email VARCHAR2(100);
    ls_email_status VARCHAR2(30);
    ls_return_code VARCHAR2(10) := '000';
    ln_count NUMBER := 0;
BEGIN
    log_at('subscription', 0, ls_hash, pn_musteri_no || ' ' || ps_email);
    ls_return_code := pkg_subscription.checkunsubscribelist(ps_hash);
    log_at('subscription', 2, ln_musteri_no, ls_return_code);
    IF ls_return_code <> '000' THEN
        return ls_return_code;
    END IF;
    
    BEGIN
        select musteri_no, email
        into ln_musteri_no, ls_email
        from cbs_musteri_adres
        where musteri_no = pn_musteri_no and
                  email = ps_email and
                  rownum = 1;
    EXCEPTION WHEN OTHERS THEN
        return '222';
    END;
    log_at('subscription', 3, ln_musteri_no || ' ' || ls_email, ls_return_code);
    ls_hash := get_hash(ln_musteri_no || ls_email);
    IF ls_hash <> ps_hash THEN
        return '333';
    END IF;
    log_at('subscription', 4, ls_hash || ' ' || ls_email, ls_return_code);
    BEGIN
        select DECODE(email, 'E', 'A', 'K')
        into ls_email_status
        from cbs_customer_notification
        where customer_no = ln_musteri_no;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        ls_email_status := 'K';
    END;
    log_at('subscription', 5, ls_email_status || ' ' || ls_email, ls_return_code);
    IF ls_email_status = 'A' THEN
        ls_return_code := pkg_subscription.AddToUnsubscribeList(pn_musteri_no, ps_email, ps_hash);
        IF ls_return_code <> '000' THEN
            return ls_return_code;
        ELSE
            return '000';
        END IF;
    ELSE
        return '444';
    END IF;
EXCEPTION WHEN OTHERS THEN    
    log_at('check_subscription', ps_hash, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return '999';    
END;

/******************************************************************************
   Name       : FUNCTION CheckUnsubscribeList
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Check if customer have already been added to unsubscribe list
******************************************************************************/   
FUNCTION CheckUnsubscribeList (ps_hash VARCHAR2) RETURN VARCHAR2 IS
    ln_cnt NUMBER;
BEGIN
    SELECT count(*)
    INTO ln_cnt
    FROM cbs_unsubscription_list
    WHERE hash_value = ps_hash;
    
    IF ln_cnt > 0 THEN
        return '111';
    ELSE
        return '000';
    END IF;
EXCEPTION WHEN OTHERS THEN
    log_at('unsubscription_list', ps_hash, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return '999';    
END;

/******************************************************************************
   Name       : FUNCTION AddToUnsubscribeList
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Add customer to unsubscribe list
******************************************************************************/   
FUNCTION AddToUnsubscribeList (pn_musteri_no NUMBER, ps_email VARCHAR2, ps_hash VARCHAR2) RETURN VARCHAR2 IS
pragma AUTONOMOUS_TRANSACTION;
ls_ret VARCHAR2(3) := '000';
BEGIN
    INSERT INTO cbs_unsubscription_list (customer_no, email, hash_value)
    VALUES (pn_musteri_no, ps_email, ps_hash);
    COMMIT;
    return ls_ret;
EXCEPTION WHEN OTHERS THEN
    log_at('add_unsubscribe_list', pn_musteri_no || ' ' || ps_hash, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ls_ret := '999';
    return ls_ret;
END;

/******************************************************************************
   Name       : PROCEDURE UnsubscribeCustomers
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Unsubscribe customers in an unsubscribe list from email notification
******************************************************************************/   
PROCEDURE UnsubscribeCustomers IS pragma AUTONOMOUS_TRANSACTION;
BEGIN
    UPDATE cbs_customer_notification
    SET status = 'K'
    WHERE customer_no in (SELECT customer_no
                                         FROM cbs_unsubscription_list);
    DELETE FROM cbs_unsubscription_list;
    COMMIT;
EXCEPTION WHEN OTHERS THEN
    log_at('unsubscribeCustomers', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

END;
/

