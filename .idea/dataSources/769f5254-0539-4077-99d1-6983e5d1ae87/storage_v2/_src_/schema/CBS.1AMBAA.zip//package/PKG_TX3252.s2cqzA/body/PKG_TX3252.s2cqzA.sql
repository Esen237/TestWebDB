create PACKAGE BODY     PKG_TX3252 IS
    pn_3252_musteri_aciklama            NUMBER;
    pn_3252_referans                    NUMBER;
    pn_3252_fis_aciklama                NUMBER;
    pn_3252_kur                         NUMBER;
    pn_3252_banka_aciklama              NUMBER;
    pn_3252_kredi_doviz                 NUMBER;
    pn_3252_islem_sube                  NUMBER;
    pn_3252_kredi_tl                    NUMBER;
    pn_3252_kredi_yp                    NUMBER;
    pn_3252_iliskili_faiz_dk            NUMBER;
    pn_3252_kredi_hesap_no              NUMBER;
    pn_3252_kredi_hesap_sube            NUMBER;
    pn_3252_tax_aciklama                NUMBER;
    pn_3252_deferred_interest           NUMBER;
    pn_3252_deferred_interest_lc        NUMBER;
    pn_3252_deferred_tax                NUMBER;
    pn_3252_deferred_tax_lc             NUMBER;
    pn_3252_accrual_gecikme_faiz        NUMBER;
    pn_3252_accrual_gecikme_faiz_lc     NUMBER;
    pn_3252_gecikme_faiz_gl             NUMBER;
    pn_3252_accrual_gecikme_tax         NUMBER;
    pn_3252_accrual_gecikme_tax_lc      NUMBER;
    pn_3252_penalty_amount              NUMBER;
    pn_3252_penalty_amount_lc           NUMBER;
    pn_3252_penalty_tax                 NUMBER;
    pn_3252_penalty_tax_lc              NUMBER;
    pn_3252_anapara                     NUMBER;
    pn_3252_anapara_lc                  NUMBER;
    pn_3252_iliskili_hesap_sube         NUMBER;
    pn_3252_iliskili_hesap_no           NUMBER;
    pn_3252_iliskili_hesap_doviz        NUMBER;
    pn_3252_toplam_faiz                 NUMBER;
    pn_3252_toplam_faiz_lc              NUMBER;
    pn_3252_toplam_vergi                NUMBER;
    pn_3252_toplam_vergi_lc             NUMBER;
    pn_3252_penalty_toplam              NUMBER;
    pn_3252_penalty_toplam_lc           NUMBER;
    pn_3252_deferred_toplam             NUMBER;
    pn_3252_deferred_toplam_lc          NUMBER;
    pn_3252_gecikme_faiz_toplam         NUMBER;
    pn_3252_gecikme_faiz_toplam_lc      NUMBER;
    pn_3252_accrual_int_acct_no         NUMBER;
    pn_3252_accrual_tax_acct_no         NUMBER;
    pn_3252_accrual_delay_int_acct_no   NUMBER;
    pn_3252_nonaccrual_int_acct_no      NUMBER;
    pn_3252_nonaccrual_delay_int_acct   NUMBER;
    pn_3252_accrual_tahsil_faiz         NUMBER;
    pn_3252_nonaccrual_tahsil_faiz      NUMBER;
    pn_3252_accrual_tahsil_vergi        NUMBER;
    pn_3252_nonaccrual_tahsil_vergi     NUMBER;
    pn_3252_accrual_tahsil_faiz_lc      NUMBER;
    pn_3252_nonaccrual_tahsil_faiz_lc   NUMBER;
    pn_3252_accrual_tahsil_vergi_lc     NUMBER;
    pn_3252_nonaccrual_tahsil_vergi_l   NUMBER;
    pn_3252_defer_pen_toplam            NUMBER;
    pn_3252_defer_pen_toplam_lc         NUMBER;
    pn_3252_defer_pen_tax               NUMBER;
    pn_3252_defer_pen_tax_lc            NUMBER;
    pn_3252_defer_penalty               NUMBER;
    pn_3252_defer_penalty_lc            NUMBER;
    pn_3252_nonaccrual_gecikme_faiz     NUMBER;
    pn_3252_nonaccrual_gecikme_faiz_l   NUMBER;
    pn_3252_nonaccrual_gecikme_tax      NUMBER;
    pn_3252_nonaccrual_gecikme_tax_lc   NUMBER;
    pn_3252_accr_defer_int              NUMBER;
    pn_3252_accr_defer_int_lc           NUMBER;
    pn_3252_nonaccr_defer_int           NUMBER;
    pn_3252_nonaccr_defer_int_lc        NUMBER;
    pn_3252_accr_defer_del_int          NUMBER;
    pn_3252_accr_defer_del_int_lc       NUMBER;
    pn_3252_nonaccr_defer_del_int       NUMBER;
    pn_3252_nonaccr_defer_del_int_lc    NUMBER;
    pn_3252_ack_principial              NUMBER;
    pn_3252_ack_int                     NUMBER;
    pn_3252_ack_tax                     NUMBER;
    pn_3252_ack_delay_int               NUMBER;
    pn_3252_ack_delay_int_tax           NUMBER;
    pn_3252_ack_defer_int               NUMBER;
    pn_3252_ack_defer_tax               NUMBER;
    pn_3252_ack_penalty                 NUMBER;
    pn_3252_ack_penalty_tax             NUMBER;
    pn_3252_ack_defer_delay_int         NUMBER;
    pn_3252_nonaccr_defer_int_tax       NUMBER;
    pn_3252_nonaccr_defer_int_tax_lc    NUMBER;
    pn_3252_nonaccr_def_del_int_tax     NUMBER;
    pn_3252_nonaccr_def_del_int_tax_l   NUMBER;
    pn_3252_ack_defer_int_tax           NUMBER;
    pn_3252_ack_defer_delay_int_tax     NUMBER;
    pn_3252_accr_defer_int_tax          NUMBER;
    pn_3252_accr_defer_int_tax_lc       NUMBER;
    pn_3252_accr_def_del_int_tax        NUMBER;
    pn_3252_accr_def_del_int_tax_l      NUMBER;
    -- b-o-m  seval.colak 22092022   
    pn_3252_pdint_total_fc              NUMBER;
    pn_3252_pdint_total_lc              NUMBER;
    pn_3252_pdcapitalize_fc             NUMBER;
    pn_3252_pdcapitalize_lc             NUMBER;
    pn_3252_pdcollection_fc             NUMBER;
    pn_3252_pdcollection_lc             NUMBER;
    pn_3252_pdwriteoff_fc               NUMBER;
    pn_3252_pdwriteoff_lc               NUMBER;
    pn_3252_undueint_total_fc           NUMBER;
    pn_3252_undueint_total_lc           NUMBER;
    pn_3252_unduecapitalize_fc          NUMBER;
    pn_3252_unduecapitalize_lc          NUMBER;
    pn_3252_unduecollection_fc          NUMBER;
    pn_3252_unduecollection_lc          NUMBER;
    pn_3252_unduewriteoff_fc            NUMBER;
    pn_3252_unduewriteoff_lc            NUMBER;
    pn_3252_delayint_total_fc           NUMBER;
    pn_3252_delayint_total_lc           NUMBER;
    pn_3252_delaycapitalize_fc          NUMBER;
    pn_3252_delaycapitalize_lc          NUMBER;
    pn_3252_delaycollection_fc          NUMBER;
    pn_3252_delaycollection_lc          NUMBER;
    pn_3252_delaywriteoff_fc            NUMBER;
    pn_3252_delaywriteoff_lc            NUMBER;
    pn_3252_penaltyint_total_fc         NUMBER;
    pn_3252_penaltyint_total_lc         NUMBER;
    pn_3252_penaltycapitalize_fc        NUMBER;
    pn_3252_penaltycapitalize_lc        NUMBER;
    pn_3252_penaltycollection_fc        NUMBER;
    pn_3252_penaltycollection_lc        NUMBER;
    pn_3252_pdint_total_tax_fc          NUMBER;
    pn_3252_pdcapitalize_tax_fc         NUMBER;
    pn_3252_pdcollection_tax_fc         NUMBER;
    pn_3252_delayint_total_tax_fc       NUMBER;
    pn_3252_delaycapitalize_tax_fc      NUMBER;
    pn_3252_delaycollection_tax_fc      NUMBER;
    pn_3252_penaltyint_total_tax_fc     NUMBER;
    pn_3252_penaltycapitalize_tax_fc    NUMBER;
    pn_3252_penaltycollection_tax_fc    NUMBER;
    pn_3252_undueint_total_tax_fc       NUMBER;
    pn_3252_unduecapitalize_tax_fc      NUMBER;
    pn_3252_unduecollection_tax_fc      NUMBER;
    pn_3252_pdint_total_tax_lc          NUMBER;
    pn_3252_pdcapitalize_tax_lc         NUMBER;
    pn_3252_pdcollection_tax_lc         NUMBER;
    pn_3252_delayint_total_tax_lc       NUMBER;
    pn_3252_delaycapitalize_tax_lc      NUMBER;
    pn_3252_delaycollection_tax_lc      NUMBER;
    pn_3252_penaltyint_total_tax_lc     NUMBER;
    pn_3252_penaltycapitalize_tax_lc    NUMBER;
    pn_3252_penaltycollection_tax_lc    NUMBER;
    pn_3252_undueint_total_tax_lc       NUMBER;
    pn_3252_unduecapitalize_tax_lc      NUMBER;
    pn_3252_unduecollection_tax_lc      NUMBER;
    pn_3252_addition_disbursement_lc    NUMBER;
    pn_3252_addition_disbursement_fc    NUMBER;
    pn_3252_pddeferred_fc               NUMBER;
    pn_3252_pddeferred_lc               NUMBER;
    pn_3252_unduedeferred_fc            NUMBER;
    pn_3252_unduedeferred_lc            NUMBER;
    pn_3252_delaydeferred_fc            NUMBER;
    pn_3252_delaydeferred_lc            NUMBER;
    pn_3252_penaltydeferred_fc          NUMBER;
    pn_3252_penaltydeferred_lc          NUMBER;
    pn_3252_pddeferred_tax_fc           NUMBER;
    pn_3252_delaydeferred_tax_fc        NUMBER;
    pn_3252_penaltydeferred_tax_fc      NUMBER;
    pn_3252_unduedeferred_tax_fc        NUMBER;
    pn_3252_pddeferred_tax_lc           NUMBER;
    pn_3252_delaydeferred_tax_lc        NUMBER;
    pn_3252_penaltydeferred_tax_lc      NUMBER;
    pn_3252_unduedeferred_tax_lc        NUMBER;
    pn_3252_penaltywriteoff_fc          NUMBER;
    pn_3252_penaltywriteoff_lc          NUMBER;
    pn_3252_pdwriteoff_tax_fc           NUMBER;
    pn_3252_delaywriteoff_tax_fc        NUMBER;
    pn_3252_penaltywriteoff_tax_fc      NUMBER;
    pn_3252_unduewriteoff_tax_fc        NUMBER;
    pn_3252_pdwriteoff_tax_lc           NUMBER;
    pn_3252_delaywriteoff_tax_lc        NUMBER;
    pn_3252_penaltywriteoff_tax_lc      NUMBER;
    pn_3252_unduewriteoff_tax_lc        NUMBER;
    pn_3252_llp_var                     NUMBER;
    pn_3252_llp_yok                     NUMBER;
--e-o-m seval.colak 22092022 

--b-o-m seval.colak 03102022
    pn_3252_accr_delay_int_eksi_lc    NUMBER;
    pn_3252_accr_delay_int_eksi_fc    NUMBER;
    pn_3252_accr_delay_int_eksi_tx_lc    NUMBER;
    pn_3252_accr_delay_int_eksi_tx_fc    NUMBER;
    pn_3252_nonaccr_delay_int_eksi_lc    NUMBER;
    pn_3252_nonaccr_delay_int_eksi_fc    NUMBER;
    pn_3252_accr_delay_int_arti_lc    NUMBER;
    pn_3252_accr_delay_int_arti_fc    NUMBER;
    pn_3252_accr_delay_int_arti_tx_lc    NUMBER;
    pn_3252_accr_delay_int_arti_tx_fc    NUMBER;
    pn_3252_nonaccr_delay_int_arti_lc    NUMBER;
    pn_3252_nonaccr_delay_int_arti_fc    NUMBER;
    pn_3252_accr_int_eksi_lc    NUMBER;
    pn_3252_accr_int_eksi_fc    NUMBER;
    pn_3252_accr_int_eksi_tx_lc    NUMBER;
    pn_3252_accr_int_eksi_tx_fc    NUMBER;
    pn_3252_nonaccr_int_eksi_lc    NUMBER;
    pn_3252_nonaccr_int_eksi_fc    NUMBER;
    pn_3252_accr_int_arti_lc    NUMBER;
    pn_3252_accr_int_arti_fc    NUMBER;
    pn_3252_accr_int_arti_tx_lc    NUMBER;
    pn_3252_accr_int_arti_tx_fc    NUMBER;
    pn_3252_nonaccr_int_arti_lc    NUMBER;
    pn_3252_nonaccr_int_arti_fc    NUMBER;
--e-o-m seval.colak 03102022

--b-o-m seval.colak 06102022
    pn_3252_accr_res_int_pmt_lc    NUMBER;
    pn_3252_accr_res_int_pmt_fc    NUMBER;
    pn_3252_nonaccr_res_int_pmt_lc    NUMBER;
    pn_3252_nonaccr_res_int_pmt_fc    NUMBER;
    pn_3252_accr_res_delay_pmt_lc    NUMBER;
    pn_3252_accr_res_delay_pmt_fc    NUMBER;
    pn_3252_nonaccr_res_delay_pmt_lc    NUMBER;
    pn_3252_nonaccr_res_delay_pmt_fc    NUMBER;
    pn_3252_accr_res_int_woff_pmt_lc    NUMBER;
    pn_3252_accr_res_int_woff_pmt_fc    NUMBER;
    pn_3252_naccr_res_int_woff_pmt_lc    NUMBER;
    pn_3252_naccr_res_int_woff_pmt_fc    NUMBER;
    pn_3252_accr_res_del_woff_pmt_lc    NUMBER;
    pn_3252_accr_res_del_woff_pmt_fc    NUMBER;
    pn_3252_naccr_res_del_woff_pmt_lc    NUMBER;
    pn_3252_naccr_res_del_woff_pmt_fc    NUMBER;
    pn_3252_accr_res_int_tax_lc    NUMBER;
    pn_3252_accr_res_int_tax_fc    NUMBER;
    pn_3252_accr_res_delay_tax_lc    NUMBER;
    pn_3252_accr_res_delay_tax_fc    NUMBER;
    pn_3252_accr_res_int_woff_tax_lc    NUMBER;
    pn_3252_accr_res_int_woff_tax_fc    NUMBER;
    pn_3252_accr_res_del_woff_tax_lc    NUMBER;
    pn_3252_accr_res_del_woff_tax_fc    NUMBER;
--e-o-m seval.colak 06102022
--b-o-m seval.colak 06102022
    pn_3252_naccr_res_int_tax_fc    NUMBER;
    pn_3252_naccr_res_int_tax_lc    NUMBER;
    pn_3252_naccr_res_delay_tax_fc    NUMBER;
    pn_3252_naccr_res_delay_tax_lc    NUMBER;
--e-o-m seval.colak 06102022
    pn_3252_penalty_gl    NUMBER;   --seval.colak 01112022


procedure sp_deferred_toplam_kontrol(pn_islem_no number)   -- seval.colak 03062022 
   is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
    ls_plan_degisiklik_secimi               varchar2(2000);
    ln_taksit                               number := 0;
    ln_odeme_plan_no                        number;
    
    ln_isl_tahsil_deferred_interest          number := 0;
    ln_isl_tahsil_deferred_delayed_interest  number := 0;
    ln_isl_tahsil_deferred_tax               number := 0;
    ln_isl_tahsil_deferred_penalty_amount    number := 0;
    ln_isl_tahsil_delayed_interest           number := 0;
    
    ln_hsp_tahsil_deferred_interest          number := 0;
    ln_hsp_tahsil_deferred_delayed_interest  number := 0;
    ln_hsp_tahsil_deferred_tax               number := 0;
    ln_hsp_tahsil_deferred_penalty_amount    number := 0;
    ln_hsp_tahsil_delayed_interest           number := 0;
    
    ls_sum_value_column                      varchar2(200);
    ls_exist_value_column                    varchar2(200);
    ln_new_value                            number := 0;  
    ln_existing_Value                       number := 0;
    ln_pd_int_deferred_amt                  number := 0;
    ln_undue_int_deferred_amt               number := 0; 
    ln_delay_int_deferred_amt               number := 0;
    ln_penalty_int_deferred_amt             number := 0;
     
    restructure_plan_toplam_esit_degil     exception;
    odemeplan_toplam_buyuk_esit_degil  exception;
     Begin
            select a.hesap_no,
                   a.plan_degisiklik_secimi,
                   a.odeme_plan_no ,
                   abs(nvl(pd_int_deferred_amt,0))      pd_int_deferred_amt,
                   abs(nvl(undue_int_deferred_amt,0))   undue_int_deferred_amt,
                   abs(nvl(delay_int_deferred_amt,0))   delay_int_deferred_amt,
                   abs(nvl(penalty_int_deferred_amt,0)) penalty_int_deferred_amt
            into  ln_hesap_no,
                  ls_plan_degisiklik_secimi ,
                  ln_odeme_plan_no  ,
                  ln_pd_int_deferred_amt ,
                  ln_undue_int_deferred_amt, 
                  ln_delay_int_deferred_amt,
                  ln_penalty_int_deferred_amt
            from cbs_hesap_kredi_islem a
            where tx_no=pn_islem_no;
      
    select sum( abs(nvl(b.deferred_interest,0)) - abs( nvl(b.paid_deferred_interest,0) ) )  tahsil_deferred_interest,
           sum( abs(nvl(b.deferred_delayed_interest,0))-  abs(nvl(b.paid_deferred_delayed_interest,0))) tahsil_deferred_delayed_interest,
              sum( abs(nvl(b.deferred_penalty_amount,0))- abs(nvl(b.paid_deferred_penalty_amount,0)  ) )tahsil_deferred_penalty_amount              
     into    ln_isl_tahsil_deferred_interest ,
             ln_isl_tahsil_deferred_delayed_interest,
             ln_isl_tahsil_deferred_penalty_amount             
    from cbs_hesap_kredi_taksit_islem b
    where tx_no = pn_islem_no and
          nvl(durum_kodu,'A') = 'A';          
                
    select 
            sum( abs( nvl(b.paid_deferred_interest,0) ) )  tahsil_deferred_interest,
            sum( abs(nvl(b.paid_deferred_delayed_interest,0))) tahsil_deferred_delayed_interest,
            sum( abs(nvl(b.paid_deferred_penalty_amount,0)  ) )tahsil_deferred_penalty_amount
   into     ln_hsp_tahsil_deferred_interest ,
            ln_hsp_tahsil_deferred_delayed_interest,
            ln_hsp_tahsil_deferred_penalty_amount
     from cbs_hesap_kredi_taksit b
    where hesap_no = ln_hesap_no and
          nvl(durum_kodu,'A') = 'A';                    
                
             ln_new_value := 0;  
             ln_existing_Value := 0;
       IF ls_plan_degisiklik_secimi = 'RESTRUCTURE' Then
           if   nvl(ln_isl_tahsil_deferred_interest,0) <>  nvl(ln_pd_int_deferred_amt ,0) + nvl(ln_undue_int_deferred_amt,0) then  
               ls_sum_value_column   := 'DEFERRED_INTEREST('||to_char(ln_isl_tahsil_deferred_interest)||')'; 
                ls_exist_value_column := 'PD_DEFERRED_INTEREST('||to_char(ln_pd_int_deferred_amt)||') + '||' UNDUE_DEFERRED_INTEREST('||to_char(ln_undue_int_deferred_amt)||')'; 
               ln_new_value         :=  ln_isl_tahsil_deferred_interest;
               ln_existing_Value    :=   nvl(ln_pd_int_deferred_amt ,0) + nvl(ln_undue_int_deferred_amt,0);     
               raise restructure_plan_toplam_esit_degil;         
           end if;   
            if   nvl(ln_isl_tahsil_deferred_delayed_interest,0) <>  nvl(ln_delay_int_deferred_amt,0) then  
               ls_sum_value_column := 'DEFERRED_DELAYED_INTEREST('||to_char(ln_isl_tahsil_deferred_delayed_interest)||')'; 
               ls_exist_value_column := 'DELAY_DEFERRED_INTEREST('||to_char(ln_delay_int_deferred_amt)||')'; 
               ln_new_value         := ln_isl_tahsil_deferred_delayed_interest;
               ln_existing_Value    := nvl(ln_delay_int_deferred_amt,0);      
               raise restructure_plan_toplam_esit_degil;         
           end if;   
         
           if   nvl(ln_isl_tahsil_deferred_penalty_amount,0) <>  nvl(ln_penalty_int_deferred_amt,0)  then  
               ls_sum_value_column  := 'DEFERRED_PENALTY_AMOUNT('||to_char(ln_isl_tahsil_deferred_penalty_amount)||')'; 
               ls_exist_value_column :='PENALTY_DEFERRED_INTEREST('||to_char(ln_penalty_int_deferred_amt)||')';
               ln_new_value         := ln_isl_tahsil_deferred_penalty_amount;
               ln_existing_Value    := nvl(ln_penalty_int_deferred_amt,0); 
               raise restructure_plan_toplam_esit_degil;               
           end if;   
       ELSE         --     'ODEME PLANI' (CHANGE EXISTING PLAN) , 'TAKSIT TARIHI' (RENEW PAYMENT PLAN) Then
          if   nvl(ln_isl_tahsil_delayed_interest,0) <  nvl(ln_hsp_tahsil_delayed_interest,0)   then              
               ls_sum_value_column := 'DELAYED INTEREST';    
               ln_new_value         :=  ln_isl_tahsil_delayed_interest;
               ln_existing_Value    :=  ln_hsp_tahsil_delayed_interest;
                raise odemeplan_toplam_buyuk_esit_degil;   
           end if;   
           
          if   nvl(ln_isl_tahsil_deferred_interest,0) <  nvl(ln_hsp_tahsil_deferred_interest,0) then  
               ls_sum_value_column := 'DEFERRED INTEREST';    
               ln_new_value         :=  ln_isl_tahsil_deferred_interest;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_interest;     
               raise odemeplan_toplam_buyuk_esit_degil;         
           end if;   
            if   nvl(ln_isl_tahsil_deferred_delayed_interest,0) <  nvl(ln_hsp_tahsil_deferred_delayed_interest,0) then  
               ls_sum_value_column := 'DEFERRED DELAYED INTEREST';   
               ln_new_value         := ln_isl_tahsil_deferred_delayed_interest;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_delayed_interest;      
               raise odemeplan_toplam_buyuk_esit_degil;         
           end if;   
           
            if   nvl(ln_isl_tahsil_deferred_tax,0) <  nvl(ln_hsp_tahsil_deferred_tax,0) then  
               ls_sum_value_column := 'DEFERRED TAX'; 
               ln_new_value         := ln_isl_tahsil_deferred_tax;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_tax;
               raise odemeplan_toplam_buyuk_esit_degil;                 
           end if;   
           if   nvl(ln_isl_tahsil_deferred_penalty_amount,0) <  nvl(ln_hsp_tahsil_deferred_penalty_amount,0) then  
               ls_sum_value_column  := 'DEFERRED PENALTY AMOUNT'; 
               ln_new_value         := ln_isl_tahsil_deferred_penalty_amount;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_penalty_amount; 
               raise odemeplan_toplam_buyuk_esit_degil;               
           end if;  
       end if;
       
       
Exception
   When odemeplan_toplam_buyuk_esit_degil then
       raise_application_error(-20100,pkg_hata.getucpointer || '6873' ||  pkg_hata.getDelimiter || to_char(ls_sum_value_column) ||pkg_hata.getDelimiter||to_char(ln_new_value) ||pkg_hata.getDelimiter|| to_char(ln_existing_Value) ||pkg_hata.getDelimiter|| pkg_hata.getucpointer);
   When  restructure_plan_toplam_esit_degil then
       raise_application_error(-20100,pkg_hata.getucpointer || '6878' ||  pkg_hata.getDelimiter || to_char(ls_sum_value_column) ||pkg_hata.getDelimiter||to_char(ls_exist_value_column)  ||pkg_hata.getDelimiter|| pkg_hata.getucpointer);
   When others then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '908' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' ||to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
   End;


Procedure Kontrol_Sonrasi(pn_islem_no number) is
   ln_hesap_no                             cbs_hesap.hesap_no%type;
   ls_endeks_doviz_kodu                    cbs_doviz_kodlari.doviz_kodu%type;
   ln_adet                                 number := 0;
   ln_anapara                              number := 0;
   taksit_islem_yok                        exception;
   ln_tax_rate                             number ;
   ln_tahsil_hesap_no                      number;  --seval.colak 20022023
   ln_iliskili_hesap_no                    number; --seval.colak 20022023
  Begin

    select hesap_no ,tahsil_hesap_no, iliskili_hesap_no           
    into ln_hesap_no ,ln_tahsil_hesap_no, ln_iliskili_hesap_no 
    from cbs_hesap_kredi_islem
    where tx_no = pn_islem_no ;

--b-o-m seval.colak 18022023
 if  nvl(ln_iliskili_hesap_no,0) <> 0 and  nvl(ln_tahsil_hesap_no,0) = 0   and pkg_hesap.badlistflag(ln_iliskili_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;

 if  nvl(ln_tahsil_hesap_no,0) <> 0 and pkg_hesap.badlistflag(ln_tahsil_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;
--b-o-m seval.colak 18022023

    select count(*)
    into ln_adet
    from cbs_hesap_kredi_taksit_islem
    where tx_no = pn_islem_no and
          nvl(durum_kodu,'A') = 'A';


   SELECT  abs( DECODE(endeks_doviz_kodu,NULL, PKG_hesap.HesapBakiyeAl(hesap_no),NVL(endeks_doviz_tutari,0)))
   INTO    ln_anapara
   FROM CBS_HESAP_KREDI
   WHERE hesap_no = ln_hesap_no;


  if nvl(ln_adet,0) = 0 and nvl(ln_anapara,0) <> 0 then
       raise taksit_islem_yok;
  end if;

    sp_taksit_vade_tutar_kontrol(pn_islem_no);
    sp_deferred_toplam_kontrol(pn_islem_no );   -- seval.colak 03062022 

  Exception
   When taksit_islem_yok then
      raise_application_error(-20100,pkg_hata.getucpointer || '914' || pkg_hata.getucpointer);

  End;


 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block    varchar2,ps_rowid   varchar2,
                                 ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2)
 is
 Begin
    --pkg_teminat.sp_TeminatGuncelleme_Kontrolu (pn_islem_no ,ps_block,ps_rowid,ps_column,pd_column ,ps_oldvalue );
    NULL;
 End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'R'
     where tx_no = pn_islem_no;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
       null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
    --Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER); --seval.colak 05102022 kapatildi iptale acilacak.
       null;
  End;
--------------------------------------------------------------------------------------------
  Procedure Onay_Sonrasi(pn_islem_no number)
  is
    ln_hesap_no                         cbs_hesap_kredi.hesap_no%type ;
    ld_maxdate                          date;
    ls_durum                            cbs_hesap_kredi.durum_kodu%type ;
    ln_adet                              number;  
    durumu_kapali                       exception;    

  Begin

     SELECT a.HESAP_NO,
                 b.durum_kodu                     
       into  ln_hesap_no,
             ls_durum                      
       from cbs_hesap_kredi_islem a,
             cbs_hesap_kredi b
       WHERE a.tx_no = pn_islem_no and
                a.hesap_no = b.hesap_no;

       if   ls_durum <> 'A' then
             raise  durumu_kapali;
       end if;

    Pkg_Kredi.sp_onayonce_taksit_sakla(    pn_islem_no ,ln_hesap_no); --seval.colak 20012022
        
       SELECT max(vade_tarih)
       into ld_maxdate
       FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no and nvl(durum_kodu,'A') ='A';

        sp_taksit_vade_tutar_kontrol(pn_islem_no);
        sp_deferred_toplam_kontrol(pn_islem_no );   -- seval.colak 03062022 
    
 Exception
   When  durumu_kapali then
              Raise_application_error(-20100,pkg_hata.getUCPOINTER || '906' || pkg_hata.getDelimiter ||to_char(ls_durum)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

  End;
   Procedure muhasebe_sonrasi_guncelle(pn_islem_no number) --seval.colak 04102022
  is
    ln_hesap_no                         cbs_hesap_kredi.hesap_no%type ;
    ld_maxdate                          date;
    ls_durum                            cbs_hesap_kredi.durum_kodu%type ;
    ls_plan_degisiklik_secimi           varchar2(200);
    ln_adet                              number;
    ln_odeme_turu                        number;
    ld_taksit_baslangic_tarihi           date;
    ln_bsmv_orani                        number;
    ls_bsmv_alinsin                      varchar2(1);
    ls_taksit_once_sonra                 varchar2(20);
    ln_artis_siklik                      number;
    ln_artis_oran                        number;
    ln_ara_odeme_siklik                  number;
    ln_ara_odeme_tutar                   number;
    ln_donem_siklik                      number;
    durumu_kapali                       exception;    
    
    ld_agreement_date    date;-- CQ5318 additinal fields KonstantinJ 26052016
    ld_agreement_no    varchar2(100);-- CQ5318 additinal fields KonstantinJ 26052016
    ln_odeme_plan_no    number := 0;--seval.colak 24012022
    ls_org_repayment_type  varchar2(100);   
  Begin

          SELECT a.HESAP_NO,
                 b.durum_kodu,
              a.PLAN_DEGISIKLIK_SECIMI,
              a.TAKSIT_BASLANGIC_TARIHI,
              a.odeme_turu,
              a.bsmv_orani,
              a.bsmv_alinsin,
              a.taksit_once_sonra,
              a.artis_siklik,
              a.artis_oran,
              a.ara_odeme_siklik,
              a.ara_odeme_tutar,
              a.donem_siklik,
              a.agreement_date,-- CQ5318 additinal fields KonstantinJ 26052016
              a.agreement_no , -- CQ5318 additinal fields KonstantinJ 26052016
              a.odeme_plan_no --seval.colak 24012022             
       into  ln_hesap_no,
                ls_durum,
             ls_plan_degisiklik_secimi,
             ld_taksit_baslangic_tarihi,
             ln_odeme_turu       ,
             ln_bsmv_orani,
             ls_bsmv_alinsin,
             ls_taksit_once_sonra,
             ln_artis_siklik,
             ln_artis_oran,
             ln_ara_odeme_siklik,
             ln_ara_odeme_tutar,
             ln_donem_siklik,
             ld_agreement_date  ,-- CQ5318 additinal fields KonstantinJ 26052016
             ld_agreement_no, -- CQ5318 additinal fields KonstantinJ 26052016 ,
             ln_odeme_plan_no --seval.colak 24012022            
       from cbs_hesap_kredi_islem a,
               cbs_hesap_kredi b
       WHERE a.tx_no = pn_islem_no and
                a.hesap_no = b.hesap_no;
  
     if nvl(ln_odeme_plan_no,0) = 0 then 
      if ls_plan_degisiklik_secimi  =  'TAKSIT TARIHI' Then
            sp_taksitsira_guncel(pn_islem_no);
      else 
           sp_taksit_sira_kalpara_guncel(pn_islem_no);
      end if;
     end if;
     
       select count(*)
       into ln_adet
       from cbs_hesap_kredi_taksit
       where hesap_no = ln_hesap_no
                and nvl(durum_kodu,'A') not in ('R','I');

      if ld_maxdate is not null then
            update cbs_hesap_kredi
            set      kredi_vade = ld_maxdate
            where hesap_no = ln_hesap_no;

         update cbs_hesap_kredi_islem
            set      kredi_vade = ld_maxdate,
                   taksit_sayisi = ln_adet
            where hesap_no = ln_hesap_no;
       end if;
--  b-o-m seval.colak 02122022 bug solution for temp.
    select repayment_type
    into  ls_org_repayment_type
    from  cbs_hesap_kredi
    where hesap_no = ln_hesap_no ;

  if  nvl(ls_org_repayment_type,'XX') not in('INSTALLMENT DATE','MATURITY DATE' ) then 
    ls_org_repayment_type := 'INSTALLMENT DATE';
   end if;
-- e-o-m seval.colak 02122022

    Pkg_Kredi.sp_kredihesap_bilgisi_guncelle(pn_islem_no);  
    
    -- seval.colak 02122022 bug solution for temp.
    update cbs_hesap_kredi
    set repayment_type = ls_org_repayment_type
    where hesap_no =  ln_hesap_no ;
    
    update cbs_hesap_kredi_islem
    set repayment_type = ls_org_repayment_type
    where tx_no = pn_islem_no ;
      -- seval.colak 02122022 bug solution for temp.
      
    if nvl(ln_odeme_plan_no,0) <> 0 then 
        update cbs_odeme_plan
        set kredi_hesap_no = ln_hesap_no,
             durum_kodu ='K',
             kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul 
        where odeme_plan_No = ln_odeme_plan_no;
     end if;
     
 Exception
   When  durumu_kapali then
              Raise_application_error(-20100,pkg_hata.getUCPOINTER || '906' || pkg_hata.getDelimiter ||to_char(ls_durum)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

  End;
--------------------------------------------------------------------------------------------
procedure sp_taksitsira_guncel(pn_islem_no number)
is
    ln_hesap_no             number;
    cursor cur_taksit is
    select sira_no
    from  cbs_hesap_kredi_taksit_islem
    where tx_no = pn_islem_no and
    nvl(durum_kodu,'A') = 'A'
    order by vade_tarih
    for update of sira_no;

    ln_i number := 0;
    ln_adet  number ;
    ln_tahsil number := 0;
begin

    select  nvl(araodeme_tutari,0),
    hesap_no
    into ln_tahsil,
    ln_hesap_no
    from cbs_hesap_kredi_islem
    where tx_no = pn_islem_no ;


    update cbs_hesap_kredi_taksit_islem
    set sira_no = sira_no + 10000
    where tx_no = pn_islem_no and
    nvl(durum_kodu,'A') = 'A';
    select   nvl(max(sira_no),0)
    into    ln_i
    from cbs_hesap_kredi_taksit
    where hesap_no = ln_hesap_no and nvl(durum_kodu,'A') <> 'A';

    for c_taksit in cur_taksit loop
    ln_i:= nvl(ln_i,0) + 1;
    update cbs_hesap_kredi_taksit_islem
    set sira_no = ln_i
    where current of cur_taksit;
    end loop;

end;

----------------------------------------------------------------------------------------------------
 PROCEDURE sp_taksit_sira_kalpara_guncel(pn_islem_no NUMBER)
 IS
  ln_hesap_no             number;
   cursor cur_taksit is
     select sira_no
     from  cbs_hesap_kredi_taksit_islem
     where tx_no = pn_islem_no and
            nvl(durum_kodu,'A') = 'A'
     order by vade_tarih
     for update of sira_no;

   cursor cur_taksit2 is
     select sira_no,
            anapara,
            durum_kodu ,
            kdvli_taksit, tahsil_edilecek_taksit
     from  cbs_hesap_kredi_taksit_islem
     where tx_no = pn_islem_no  and
        nvl(durum_kodu,'A') = 'A'
     order by sira_no
     for update of kal_anapara,kdvli_taksit, tahsil_edilecek_taksit;


     ln_i NUMBER := 0;
     ln_adet  NUMBER ;

     ln_kalpara number := 0;
  BEGIN

    SELECT hesap_no
    INTO ln_hesap_no
    FROM CBS_HESAP_KREDI_ISLEM
    WHERE tx_no = pn_islem_no;


   SELECT   nvl(abs( DECODE(endeks_doviz_kodu,NULL, PKG_hesap.HesapBakiyeAl(hesap_no),NVL(endeks_doviz_tutari,0))),0)
   INTO    ln_kalpara
   FROM CBS_HESAP_KREDI
   WHERE hesap_no = ln_hesap_no;

   SELECT   nvl(max(sira_no),0)
   INTO    ln_i
   FROM CBS_HESAP_KREDI_taksit
   WHERE hesap_no = ln_hesap_no and nvl(durum_kodu,'A') <> 'A';


    SELECT COUNT(*)
    INTO ln_adet
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
    WHERE tx_no = pn_islem_no;

    IF NVL(ln_adet,0) <> 0 THEN
    /* sirano unique oldugundan once farkli numaraya set edilir.*/
       UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
       SET sira_no = sira_no + 10000
       WHERE tx_no = pn_islem_no and
                nvl(durum_kodu,'A') = 'A';
    END IF;

    FOR c_taksit IN cur_taksit LOOP
       ln_i:= nvl(ln_i,0) + 1;

       UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
       SET sira_no = ln_i
       WHERE CURRENT OF cur_taksit;

    END LOOP;

    FOR c_taksit IN cur_taksit2 LOOP
        if nvl(ln_kalpara,0) > nvl(c_taksit.anapara,0) then
            ln_kalpara := nvl(ln_kalpara,0) - nvl(c_taksit.anapara,0) ;
         else
             ln_kalpara := 0;
        end if;

        if c_taksit.durum_kodu  = 'A' then
               update cbs_hesap_kredi_taksit_islem
               set kal_anapara =ln_kalpara ,
                   kdvli_taksit = nvl(kdv,0) + nvl(taksit,0),
                   tahsil_edilecek_taksit  = nvl(taksit,0)
               where current of cur_taksit2;
        end if;

    END LOOP;
  END;
--------------------------------------------------------------------------------------------
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number)
  is
  Begin
   -- Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);--seval.colak 05102022
       pkg_kredi.iptal_onay_sonrasi(pn_islem_no); --seval.colak 05102022
  End;
--------------------------------------------------------------------------------------------
  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'R'
     where tx_no = pn_islem_no;

  End;
--------------------------------------------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------------------

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------------------
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

-------------------------------------------------------------------------------
  Function sf_min_acik_taksit_no_al(pn_islem_no number) return number
   is
   ln_sira_no number :=0;
   Begin

       select min(sira_no)
      into ln_sira_no
      from cbs_hesap_kredi_taksit_islem
      where tx_no = pn_islem_no and
              durum_kodu = 'A';

    return ln_sira_no;
  Exception when others then return 0;
 End;
-------------------------------------------------------------------------------
  Function sf_odeme_turu_al(pn_hesap_no number) return varchar2
  is
      ls_odeme_turu    varchar2(20);
  Begin
         select odeme_turu
       into ls_odeme_turu
       from cbs_hesap_kredi
       where hesap_no = pn_hesap_no;

       return ls_odeme_turu;

   Exception when others then return null;
  End;
-------------------------------------------------------------------------------
 Function sf_acik_taksit_adedi(pn_hesap_no number) return number
 is
   ln_adet number;
 Begin
       select count(*)
      into ln_adet
      from cbs_hesap_kredi_taksit
      where hesap_no = pn_hesap_no and
              durum_kodu = 'A';

      return ln_adet;
 End;
-------------------------------------------------------------------------------
 PROCEDURE sp_taksit_vade_tutar_kontrol(pn_islem_no NUMBER )
 IS
   ln_hesap_no                       number;
   ld_taksit_vade                    date;
   ld_kredi_vade                     date;
   ln_tutar                          number;
   ln_toplam                         number;
   ln_total_add_disburs_capital_amt  number := 0;

    ln_pd_exist_int_total_amt        number := 0;
    ln_undue_exist_int_total_amt     number := 0;
    ln_delay_exist_int_total_amt     number := 0;
    ln_penalty_exist_int_total_amt   number := 0;           
    ln_total_pd_int_sumvalue         number := 0;  
    ln_total_undue_int_sumvalue      number := 0;
    ln_total_delay_int_sumvalue      number := 0;
    ln_total_penalty_int_sumvalue    number := 0; 
             
    ln_tax_Rate                      number;
    ln_exist_int_total_value         number := 0; 
    ln_new_int_sumofValue            number := 0; 
     
   ls_exist_int_total_value_column  varchar2(30);
   taksit_tarihi_ayni                exception;
   taksit_tarihi_vadedenbuyuk        exception;
   taksit_toplam_farkli              exception;
   mevcut_faiz_toplami_ile_Farkli     exception;

   CURSOR cur_taksit_vade IS
       SELECT vade_tarih
       FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no
               AND nvl(durum_kodu,'A')  = 'A'
       GROUP BY vade_tarih
       HAVING COUNT(*) > 1
       ORDER BY vade_tarih ;

   CURSOR cur_kredi_vade IS
       SELECT SIRA_NO,vade_tarih
       FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no AND
                nvl(durum_kodu,'A')  = 'A'
       ORDER BY SIRA_NO;

    CURSOR cur_taksit_toplam IS
       select sum(nvl(anapara,0)) - sum(nvl(tahsil_anapara,0)) toplam --seval.colak 07122022
       from cbs_hesap_kredi_taksit_islem
       where tx_no = pn_islem_no    and
                nvl(durum_kodu,'A') = 'A' ;
  BEGIN
  	pkg_parametre.deger('G_SALES_TAX_RATE',ln_tax_Rate); 
	
    select hesap_no ,
            -- B-O-M seval.colak 220920222
            abs(nvl(additional_disbursement_amount,0)) + --additional_disbursement_amount,
            abs(nvl(pd_int_capitalize_amt,0)) + abs(nvl(undue_int_capitalize_amt,0)) + abs(nvl(delay_int_capitalize_amt,0)) + abs(nvl(penalty_int_capitalize_amt,0)) + --top_int_capitalize_amt,
            round( (abs(nvl(pd_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2)   +  --PD_INT_CAPITALIZE_TAX
            round( (abs(nvl(undue_int_capitalize_amt,0))* nvl(ln_tax_rate,0)   / 100 ),2) + --UNDUE_INT_CAPITALIZE_TAX 
            round( (abs(nvl(delay_int_capitalize_amt,0))* nvl(ln_tax_rate,0)/ 100 ),2) +     --DELAY_INT_CAPITALIZE_TAX     
            round( (abs(nvl(penalty_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2) total_add_disburs_capital_amt_with_tax,--  additional_disbursement_amount + top_int_capitalize_amt + top_int_capitalize_tax 
            abs(nvl(pd_int_total_amt,0)) pd_int_total_amt,
            abs(nvl(undue_int_total_amt,0))   undue_int_total_amt,
            abs(nvl(delay_int_total_amt,0))      delay_int_total_amt,
            abs(nvl(penalty_int_total_amt,0))   penalty_int_total_amt,             
            abs(nvl(pd_int_capitalize_amt,0)) + abs(nvl(pd_int_collection_amt,0)) + abs(nvl(pd_int_deferred_amt,0)) + abs(nvl(pd_int_writeoff_amt,0))  total_pd_int_sumvalue,
            abs(nvl(undue_int_capitalize_amt,0)) + abs(nvl(undue_int_collection_amt,0)) + abs(nvl(undue_int_deferred_amt,0)) + abs(nvl(undue_int_writeoff_amt,0))  total_undue_int_sumvalue,
            abs(nvl(delay_int_capitalize_amt,0)) + abs(nvl(delay_int_collection_amt,0)) +abs(nvl(delay_int_deferred_amt,0)) + abs(nvl(delay_int_writeoff_amt,0))  total_delay_int_sumvalue,
            abs(nvl(penalty_int_capitalize_amt,0)) + abs(nvl(penalty_int_collection_amt,0)) +abs(nvl(penalty_int_deferred_amt,0)) + abs(nvl(penalty_int_writeoff_amt,0))  total_penalty_int_sumvalue
              --e-om seval.colak 22092022 
        into ln_hesap_no ,
        --b-om seval.colak 22092022 
            ln_total_add_disburs_capital_amt,           
            ln_pd_exist_int_total_amt,
            ln_undue_exist_int_total_amt,
            ln_delay_exist_int_total_amt,
            ln_penalty_exist_int_total_amt,             
            ln_total_pd_int_sumvalue,
            ln_total_undue_int_sumvalue,
            ln_total_delay_int_sumvalue,
            ln_total_penalty_int_sumvalue     
             --e-om seval.colak 22092022    
     from cbs_hesap_kredi_islem
     where tx_no = pn_islem_no;

   SELECT  kredi_vade,
          abs( DECODE(endeks_doviz_kodu,NULL, PKG_hesap.HesapBakiyeAl(hesap_no),NVL(endeks_doviz_tutari,0)))
   INTO   ld_kredi_vade,
          ln_tutar
   FROM CBS_HESAP_KREDI
   WHERE hesap_no = ln_hesap_no;

      FOR c_taksit_toplam IN cur_taksit_toplam
       LOOP
              ln_toplam := c_taksit_toplam.toplam;
       END LOOP;

        IF  abs(NVL(ln_toplam,0)) <> abs(nvl(ln_total_add_disburs_capital_amt,0)) + abs(NVL(ln_tutar,0))   THEN   -- seval.colak 22092022 kontrole ln_total_add_disburs_capital_amt eklendi
         RAISE taksit_toplam_farkli;
       END IF;

       FOR  c_taksit_vade IN cur_taksit_vade
       LOOP
              ld_taksit_vade := c_taksit_vade.vade_tarih;
       END LOOP;

        IF ld_taksit_vade IS NOT NULL THEN
          RAISE taksit_tarihi_ayni;
        END IF;
    -- b-o-m seval.colak 22092022
        ls_exist_int_total_value_column :=null;
        ln_exist_int_total_value := 0;
        ln_new_int_sumofValue   := 0;
                
    if   nvl(ln_pd_exist_int_total_amt,0) <> nvl(ln_total_pd_int_sumvalue,0) then 
        ls_exist_int_total_value_column :='Past Due';
        ln_exist_int_total_value := ln_pd_exist_int_total_amt;
        ln_new_int_sumofValue    := ln_total_pd_int_sumvalue;
         RAISE mevcut_faiz_toplami_ile_farkli;
     end if;
    if   nvl(ln_undue_exist_int_total_amt,0) <> nvl(ln_total_undue_int_sumvalue,0) then 
        ls_exist_int_total_value_column :='Undue';
        ln_exist_int_total_value := ln_undue_exist_int_total_amt;
        ln_new_int_sumofValue    := ln_total_undue_int_sumvalue;
            RAISE mevcut_faiz_toplami_ile_farkli;
     end if;
     
      if   nvl(ln_delay_exist_int_total_amt,0) <> nvl(ln_total_delay_int_sumvalue,0) then 
        ls_exist_int_total_value_column :='Delay';
        ln_exist_int_total_value := ln_delay_exist_int_total_amt;
        ln_new_int_sumofValue    := ln_total_delay_int_sumvalue;
            RAISE mevcut_faiz_toplami_ile_farkli;
     end if;
     
      if   nvl(ln_penalty_exist_int_total_amt,0) <> nvl(ln_total_penalty_int_sumvalue,0) then 
        ls_exist_int_total_value_column :='Penalty';
        ln_exist_int_total_value := ln_penalty_exist_int_total_amt;
        ln_new_int_sumofValue    := ln_total_penalty_int_sumvalue;
            RAISE mevcut_faiz_toplami_ile_farkli;
     end if;
       -- e-o-m seval.colak 22092022   

 exception
   when  taksit_tarihi_ayni then
      raise_application_error(-20100,pkg_hata.getucpointer || '972' ||  pkg_hata.getdelimiter ||to_char( ld_taksit_vade,'DD/MM/YYYY') || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   when   taksit_tarihi_vadedenbuyuk then
      raise_application_error(-20100,pkg_hata.getucpointer || '1799' || pkg_hata.getucpointer);
   when  taksit_toplam_farkli then  --seval.colak 29082022
       raise_application_error(-20100,pkg_hata.getucpointer || '6875' || pkg_hata.getdelimiter||to_char(ln_toplam) ||pkg_hata.getdelimiter|| to_char(  abs(nvl(ln_total_add_disburs_capital_amt,0)) + abs(NVL(ln_tutar,0)) ) ||pkg_hata.getdelimiter|| pkg_hata.getucpointer);
    When  mevcut_faiz_toplami_ile_farkli then  --seval.colak 29082022
       raise_application_error(-20100,pkg_hata.getucpointer || '6877' ||  pkg_hata.getDelimiter || to_char(ls_exist_int_total_value_column) ||pkg_hata.getDelimiter||to_char(ln_exist_int_total_value) ||pkg_hata.getDelimiter|| to_char(ln_new_int_sumofValue) ||pkg_hata.getDelimiter|| pkg_hata.getucpointer);
   when others then
           raise_application_error(-20100,pkg_hata.getucpointer || '6876' || pkg_hata.getdelimiter || to_char(sqlcode) || ' ' ||to_char(sqlerrm) || pkg_hata.getdelimiter || pkg_hata.getucpointer);

 END;
 -------------------------------------------------------------------------------
 Procedure Muhasebelesme(pn_islem_no number) is  --seval.colak 22092022 RESTRUCTURE durumunda sadece muhasebe kesilecek
    varchar_list                            Pkg_Muhasebe.varchar_array;
    number_list                             Pkg_Muhasebe.number_array;
    date_list                               Pkg_Muhasebe.date_array;
    boolean_list                            Pkg_Muhasebe.boolean_array;
    ---------------   
    ld_banka_tarihi                         DATE :=Pkg_Muhasebe.Banka_Tarihi_Bul;
    ln_islem_kod                            number := 3252;       
    ln_fis_no                               number := 0;
    ln_pastdue_tax_hesap_no                 number := 0;
    ln_pastdue_faiz_hesap_no                number := 0;
    ls_hata_var                             VARCHAR2(1):= 'H';
    ls_banka_aciklama                       VARCHAR2(2000);
    ls_musteri_aciklama                     VARCHAR2(2000);  
    ls_islem_aciklama                       VARCHAR2(2000);
    ls_fis_aciklama                         VARCHAR2(2000);
    ls_aciklama                             VARCHAR2(2000);    
    ls_doviz_kodu                           VARCHAR2(3);
    ls_bolum_kodu                           CBS_HESAP_KREDI.sube_kodu%TYPE;
    ln_kredi_hesap_no                       number:=0;   
    ld_kredi_vade                           date;
    ls_aciklama_month                       varchar2(100);
    ls_musteri_Adi                          varchar2(200);  
    ls_taksit_durum                         cbs_hesap_kredi_taksit.durum_kodu%type;
    ln_taksit_toplam                        number := 0 ;  
    ln_tahsil_faiz                          number := 0 ;
    ln_tahsil_vergi                         number := 0 ;
    ln_tahakkuk_no                          number;
    ln_kalan_tahsil_faiz                    number := 0 ;
    ln_kalan_tahsil_vergi                   number := 0 ;
    ln_tax_Rate                             number ;
    ln_gecikme_faiz_tutari_toplam           number := 0;
    ln_penalty_amount_toplam                number := 0 ;
    ln_isl_top_tahsil_delay_defer_int       number := 0 ;
    ln_isl_top_tahsil_faiz_defer_int        number := 0 ;
    ln_hsp_top_tahsil_delay_defer_int       number := 0 ;
    ln_hsp_top_tahsil_faiz_defer_int        number := 0 ;
    ln_Fark_top_tahsil_delay_defer_int      number := 0 ;
    ln_Fark_top_tahsil_faiz_defer_int       number := 0 ;
    ln_isl_top_penalty_amount               number := 0 ;
    ln_hsp_top_penalty_amount               number := 0 ;
    ln_Fark_top_penalty_amount              number := 0 ;
    --b-o-m seval.colak 06102022
    ln_top_res_int_pmt                     number := 0 ;  
    ln_top_res_delay_pmt                   number := 0 ; 
    ln_top_res_int_writeoff_pmt            number := 0 ;  
    ln_top_res_delay_writeoff_pmt          number := 0 ; 
    ln_accr_int_acct_bakiye                number := 0 ; 
    ln_top_res_delay_int_pmt               number := 0 ;  
    ln_accr_delay_int_acct_bakiye          number := 0 ;
    ln_top_res_int_woff_pmt                number := 0 ;
    ln_accr_int_woff_acct_bakiye           number := 0 ;
    ln_top_res_del_woff_pmt                number := 0 ;
    ln_accr_del_woff_acct_bakiye           number := 0 ;
     --e-o-m seval.colak 06102022
     ls_accrual_nonaccrual_hesap_urun       varchar2(100);
    iliskili_faiz_dk_yok             exception;
     --  iliskili_faizrees_dk_yok         exception;
    iliskili_kom_dk_yok              exception;
     --  iliskili_komrees_dk_yok          exception;
     gecikme_faiz_dk_yok                exception;
      -- faiz_iliskili_faizrees_dk_yok    exception;
     faiz_tahakkuk_hesapno_yok        exception;
     vergi_tahakkuk_hesapno_yok       exception;
     iliskili_hesapno_yok             exception;
     deferred_interest_dk_yok         exception;
     accrual_nonaccrual_hesap_yok exception ;
    ----
   cursor cur_hesap is
    select a.* ,Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.musteri_no) dk_grup_kod ,
                pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) iliskili_hesap_doviz,
                pkg_hesap.kullanilabilir_bakiye_al(iliskili_hesap_no) iliskili_hesap_bakiye,
                abs(pkg_hesap.hesapbakiyeal(a.hesap_no)) kredi_bakiye   ,
                  -- B-O-M seval.colak 220920222
            abs(nvl(additional_disbursement_amount,0)) + --additional_disbursement_amount,
            abs(nvl(pd_int_capitalize_amt,0)) + abs(nvl(undue_int_capitalize_amt,0)) + abs(nvl(delay_int_capitalize_amt,0)) + abs(nvl(penalty_int_capitalize_amt,0)) + --top_int_capitalize_amt,
            round( (abs(nvl(pd_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2)   +  --PD_INT_CAPITALIZE_TAX
            round( (abs(nvl(undue_int_capitalize_amt,0))* nvl(ln_tax_rate,0)   / 100 ),2) + --UNDUE_INT_CAPITALIZE_TAX 
            round( (abs(nvl(delay_int_capitalize_amt,0))* nvl(ln_tax_rate,0)/ 100 ),2) +     --DELAY_INT_CAPITALIZE_TAX     
            round( (abs(nvl(penalty_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2) total_add_disburs_capital_amt,--  additional_disbursement_amount + top_int_capitalize_amt + top_int_capitalize_tax 
            abs(nvl(pd_int_capitalize_amt,0)) + abs(nvl(pd_int_collection_amt,0)) +abs(nvl(pd_int_deferred_amt,0)) + abs(nvl(pd_int_writeoff_amt,0))  total_pd_int_sumvalue,
            abs(nvl(undue_int_capitalize_amt,0)) + abs(nvl(undue_int_collection_amt,0)) +abs(nvl(undue_int_deferred_amt,0)) + abs(nvl(undue_int_writeoff_amt,0))  total_undue_int_sumvalue,
            abs(nvl(delay_int_capitalize_amt,0)) + abs(nvl(delay_int_collection_amt,0)) +abs(nvl(delay_int_deferred_amt,0)) + abs(nvl(delay_int_writeoff_amt,0))  total_delay_int_sumvalue,
            abs(nvl(penalty_int_capitalize_amt,0)) + abs(nvl(penalty_int_collection_amt,0)) +abs(nvl(penalty_int_deferred_amt,0)) + abs(nvl(penalty_int_writeoff_amt,0))  total_penalty_int_sumvalue             
    from CBS_HESAP_KREDI_islem a
    where tx_No = pn_islem_No ;

    r_hesap  cur_hesap%ROWTYPE;

     cursor cur_tahakkuk is
     select kredi_hesap_no,tahakkuk_no ,
             case when  abs(nvl(b.faiz_tahakkuk_tutar,0)) > abs(nvl(b.faiz_tahakkuk_tutar_tahsil,0)) then    abs(abs(nvl(b.faiz_tahakkuk_tutar,0)) -    abs(nvl(b.faiz_tahakkuk_tutar_tahsil,0))) else 0 end   faiz_tahakkuk_tutar,
             case when  abs(nvl(b.vergi_tahakkuk_tutar,0)) > abs(nvl(b.vergi_tahakkuk_tutar_tahsil,0)) then  abs(abs(nvl(b.vergi_tahakkuk_tutar,0)) -    abs(nvl(b.vergi_tahakkuk_tutar_tahsil,0))) else 0 end   vergi_tahakkuk_tutar
     from cbs_kredi_tahakkuk b
     where  kredi_hesap_no =ln_kredi_hesap_no and 
            BANKA_TARIHI <=ld_banka_tarihi and
            durum_kodu ='A'  
      order by tahakkuk_no ; 
      r_tahakkuk  cur_hesap%ROWTYPE;

  Begin
  pkg_parametre.deger('G_SALES_TAX_RATE',ln_tax_Rate); 
  
   ---------------------------------
        boolean_list(pn_3252_kredi_tl)  := FALSE;
        boolean_list(pn_3252_kredi_yp)  := FALSE;
        
        boolean_list(pn_3252_llp_var)  := FALSE; --seval.colak 22092022
        boolean_list(pn_3252_llp_yok)  := FALSE;

        number_list(pn_3252_anapara)  := 0;
        number_list(pn_3252_anapara_lc)  := 0;
        number_list(pn_3252_deferred_interest)  := 0;
        number_list(pn_3252_deferred_interest_lc)  := 0;
        number_list(pn_3252_deferred_tax)  := 0;
        number_list(pn_3252_deferred_tax_lc)  := 0;
        number_list(pn_3252_deferred_toplam)  := 0;
        number_list(pn_3252_deferred_toplam_lc)  := 0;

        number_list(pn_3252_accrual_gecikme_faiz)  := 0;
        number_list(pn_3252_accrual_gecikme_faiz_lc)  := 0;
        number_list(pn_3252_nonaccrual_gecikme_faiz)  := 0;
        number_list(pn_3252_nonaccrual_gecikme_faiz_l)  := 0;        
        number_list(pn_3252_gecikme_faiz_toplam)  := 0;
        number_list(pn_3252_gecikme_faiz_toplam_lc)  := 0;
        number_list(pn_3252_kur)  := 0;
        number_list(pn_3252_penalty_amount)  := 0;
        number_list(pn_3252_penalty_amount_lc)  := 0;
        number_list(pn_3252_penalty_tax)  := 0;
        number_list(pn_3252_penalty_tax_lc)  := 0;
        number_list(pn_3252_penalty_toplam)  := 0;
        number_list(pn_3252_penalty_toplam_lc)  := 0;

        number_list(pn_3252_toplam_faiz)  := 0;
        number_list(pn_3252_toplam_faiz_lc)  := 0;
        number_list(pn_3252_toplam_vergi)  := 0;
        number_list(pn_3252_toplam_vergi_lc)  := 0;
    
        varchar_list(pn_3252_banka_aciklama)  := NULL; 

        varchar_list(pn_3252_fis_aciklama)  := NULL; 
        varchar_list(pn_3252_gecikme_faiz_gl)  := NULL; 
        
        varchar_list(pn_3252_iliskili_faiz_dk)  := NULL; 
        
        varchar_list(pn_3252_iliskili_hesap_doviz)  := NULL; 
        varchar_list(pn_3252_iliskili_hesap_no)  := NULL; 
        varchar_list(pn_3252_iliskili_hesap_sube)  := NULL; 
        varchar_list(pn_3252_islem_sube)  := NULL; 
        varchar_list(pn_3252_kredi_doviz)  := NULL; 
        varchar_list(pn_3252_kredi_hesap_no)  := NULL; 
        varchar_list(pn_3252_kredi_hesap_sube)  := NULL; 
        varchar_list(pn_3252_musteri_aciklama)  := NULL; 
        varchar_list(pn_3252_referans)  := NULL; 
        varchar_list(pn_3252_tax_aciklama)  := NULL; 
        varchar_list(pn_3252_accrual_int_acct_no)  := NULL; 
        varchar_list(pn_3252_accrual_tax_acct_no)  := NULL; 
        varchar_list(pn_3252_accrual_delay_int_acct_no)  := NULL; 
        varchar_list(pn_3252_nonaccrual_int_acct_no)  := NULL; 
        varchar_list(pn_3252_nonaccrual_delay_int_acct)  := NULL;  
        number_list(pn_3252_accrual_tahsil_faiz)  := 0;
        number_list(pn_3252_nonaccrual_tahsil_faiz)  := 0;
        number_list(pn_3252_accrual_tahsil_vergi)  := 0;
        number_list(pn_3252_nonaccrual_tahsil_vergi)  := 0;
        number_list(pn_3252_accrual_tahsil_faiz_lc)  := 0;
        number_list(pn_3252_nonaccrual_tahsil_faiz_lc)  := 0;
        number_list(pn_3252_accrual_tahsil_vergi_lc)  := 0;
        number_list(pn_3252_nonaccrual_tahsil_vergi_l)  := 0;
        number_list(pn_3252_defer_pen_toplam)  := 0;
        number_list(pn_3252_defer_pen_toplam_lc)  := 0;
        number_list(pn_3252_defer_pen_tax)  := 0;
        number_list(pn_3252_defer_pen_tax_lc)  := 0;
        number_list(pn_3252_defer_penalty)  := 0;
        number_list(pn_3252_defer_penalty_lc)  := 0;
        number_list(pn_3252_accr_defer_int)  := 0;
        number_list(pn_3252_accr_defer_int_lc)  := 0;
        number_list(pn_3252_nonaccr_defer_int)  := 0;
        number_list(pn_3252_nonaccr_defer_int_lc)  := 0;
        number_list(pn_3252_accr_defer_del_int)  := 0;
        number_list(pn_3252_accr_defer_del_int_lc)  := 0;
        number_list(pn_3252_nonaccr_defer_del_int)  := 0;
        number_list(pn_3252_nonaccr_defer_del_int_lc)  := 0;
     
        varchar_list(pn_3252_ack_principial)  := NULL; 
        varchar_list(pn_3252_ack_int)  := NULL; 
        varchar_list(pn_3252_ack_tax)  := NULL; 
        varchar_list(pn_3252_ack_delay_int)  := NULL; 
        varchar_list(pn_3252_ack_delay_int_tax)  := NULL; 
        varchar_list(pn_3252_ack_defer_int)  := NULL; 
        varchar_list(pn_3252_ack_defer_tax)  := NULL; 
        varchar_list(pn_3252_ack_penalty)  := NULL; 
        varchar_list(pn_3252_ack_penalty_tax)  := NULL; 
        varchar_list(pn_3252_ack_defer_delay_int)  := NULL; 
        number_list(pn_3252_nonaccr_defer_int_tax)  := 0;
        number_list(pn_3252_nonaccr_defer_int_tax_lc)  := 0;
        number_list(pn_3252_nonaccr_def_del_int_tax)  := 0;
        number_list(pn_3252_nonaccr_def_del_int_tax_l)  := 0;
        varchar_list(pn_3252_ack_defer_int_tax)  := NULL; 
        varchar_list(pn_3252_ack_defer_delay_int_tax)  := NULL; 
        number_list(pn_3252_accr_defer_int_tax)  := 0;
        number_list(pn_3252_accr_defer_int_tax_lc)  := 0;
        number_list(pn_3252_accr_def_del_int_tax)  := 0;
        number_list(pn_3252_accr_def_del_int_tax_l)  := 0;
        
        --b-o-m seval.colak 22092022
        number_list(pn_3252_pdint_total_fc)  := 0;
        number_list(pn_3252_pdint_total_lc)  := 0;
        number_list(pn_3252_pdcapitalize_fc)  := 0;
        number_list(pn_3252_pdcapitalize_lc)  := 0;
        number_list(pn_3252_pdcollection_fc)  := 0;
        number_list(pn_3252_pdcollection_lc)  := 0;
        number_list(pn_3252_pdwriteoff_fc)  := 0;
        number_list(pn_3252_pdwriteoff_lc)  := 0;
        number_list(pn_3252_undueint_total_fc)  := 0;
        number_list(pn_3252_undueint_total_lc)  := 0;
        number_list(pn_3252_unduecapitalize_fc)  := 0;
        number_list(pn_3252_unduecapitalize_lc)  := 0;
        number_list(pn_3252_unduecollection_fc)  := 0;
        number_list(pn_3252_unduecollection_lc)  := 0;
        number_list(pn_3252_unduewriteoff_fc)  := 0;
        number_list(pn_3252_unduewriteoff_lc)  := 0;
        number_list(pn_3252_delayint_total_fc)  := 0;
        number_list(pn_3252_delayint_total_lc)  := 0;
        number_list(pn_3252_delaycapitalize_fc)  := 0;
        number_list(pn_3252_delaycapitalize_lc)  := 0;
        number_list(pn_3252_delaycollection_fc)  := 0;
        number_list(pn_3252_delaycollection_lc)  := 0;
        number_list(pn_3252_delaywriteoff_fc)  := 0;
        number_list(pn_3252_delaywriteoff_lc)  := 0;
        number_list(pn_3252_penaltyint_total_fc)  := 0;
        number_list(pn_3252_penaltyint_total_lc)  := 0;
        number_list(pn_3252_penaltycapitalize_fc)  := 0;
        number_list(pn_3252_penaltycapitalize_lc)  := 0;
        number_list(pn_3252_penaltycollection_fc)  := 0;
        number_list(pn_3252_penaltycollection_lc)  := 0;
        number_list(pn_3252_pdint_total_tax_fc)  := 0;
        number_list(pn_3252_pdcapitalize_tax_fc)  := 0;
        number_list(pn_3252_pdcollection_tax_fc)  := 0;
        number_list(pn_3252_delayint_total_tax_fc)  := 0;
        number_list(pn_3252_delaycapitalize_tax_fc)  := 0;
        number_list(pn_3252_delaycollection_tax_fc)  := 0;
        number_list(pn_3252_penaltyint_total_tax_fc)  := 0;
        number_list(pn_3252_penaltycapitalize_tax_fc)  := 0;
        number_list(pn_3252_penaltycollection_tax_fc)  := 0;
        number_list(pn_3252_undueint_total_tax_fc)  := 0;
        number_list(pn_3252_unduecapitalize_tax_fc)  := 0;
        number_list(pn_3252_unduecollection_tax_fc)  := 0;
        number_list(pn_3252_pdint_total_tax_lc)  := 0;
        number_list(pn_3252_pdcapitalize_tax_lc)  := 0;
        number_list(pn_3252_pdcollection_tax_lc)  := 0;
        number_list(pn_3252_delayint_total_tax_lc)  := 0;
        number_list(pn_3252_delaycapitalize_tax_lc)  := 0;
        number_list(pn_3252_delaycollection_tax_lc)  := 0;
        number_list(pn_3252_penaltyint_total_tax_lc)  := 0;
        number_list(pn_3252_penaltycapitalize_tax_lc)  := 0;
        number_list(pn_3252_penaltycollection_tax_lc)  := 0;
        number_list(pn_3252_undueint_total_tax_lc)  := 0;
        number_list(pn_3252_unduecapitalize_tax_lc)  := 0;
        number_list(pn_3252_unduecollection_tax_lc)  := 0;
        number_list(pn_3252_addition_disbursement_lc)  := 0;
        number_list(pn_3252_addition_disbursement_fc)  := 0;
        number_list(pn_3252_pddeferred_fc)  := 0;
        number_list(pn_3252_pddeferred_lc)  := 0;
        number_list(pn_3252_unduedeferred_fc)  := 0;
        number_list(pn_3252_unduedeferred_lc)  := 0;
        number_list(pn_3252_delaydeferred_fc)  := 0;
        number_list(pn_3252_delaydeferred_lc)  := 0;
        number_list(pn_3252_penaltydeferred_fc)  := 0;
        number_list(pn_3252_penaltydeferred_lc)  := 0;
        number_list(pn_3252_pddeferred_tax_fc)  := 0;
        number_list(pn_3252_delaydeferred_tax_fc)  := 0;
        number_list(pn_3252_penaltydeferred_tax_fc)  := 0;
        number_list(pn_3252_unduedeferred_tax_fc)  := 0;
        number_list(pn_3252_pddeferred_tax_lc)  := 0;
        number_list(pn_3252_delaydeferred_tax_lc)  := 0;
        number_list(pn_3252_penaltydeferred_tax_lc)  := 0;
        number_list(pn_3252_unduedeferred_tax_lc)  := 0;
        number_list(pn_3252_penaltywriteoff_fc)  := 0;
        number_list(pn_3252_penaltywriteoff_lc)  := 0;
        number_list(pn_3252_pdwriteoff_tax_fc)  := 0;
        number_list(pn_3252_delaywriteoff_tax_fc)  := 0;
        number_list(pn_3252_penaltywriteoff_tax_fc)  := 0;
        number_list(pn_3252_unduewriteoff_tax_fc)  := 0;
        number_list(pn_3252_pdwriteoff_tax_lc)  := 0;
        number_list(pn_3252_delaywriteoff_tax_lc)  := 0;
        number_list(pn_3252_penaltywriteoff_tax_lc)  := 0;
        number_list(pn_3252_unduewriteoff_tax_lc)  := 0;
      --e-o-m seval.colak 22092022
         
      --b-o-m seval.colak 03102022
        number_list(pn_3252_accr_delay_int_eksi_lc)  := 0;
        number_list(pn_3252_accr_delay_int_eksi_fc)  := 0;
        number_list(pn_3252_accr_delay_int_eksi_tx_lc)  := 0;
        number_list(pn_3252_accr_delay_int_eksi_tx_fc)  := 0;
        number_list(pn_3252_nonaccr_delay_int_eksi_lc)  := 0;
        number_list(pn_3252_nonaccr_delay_int_eksi_fc)  := 0;
        number_list(pn_3252_accr_delay_int_arti_lc)  := 0;
        number_list(pn_3252_accr_delay_int_arti_fc)  := 0;
        number_list(pn_3252_accr_delay_int_arti_tx_lc)  := 0;
        number_list(pn_3252_accr_delay_int_arti_tx_fc)  := 0;
        number_list(pn_3252_nonaccr_delay_int_arti_lc)  := 0;
        number_list(pn_3252_nonaccr_delay_int_arti_fc)  := 0;
        number_list(pn_3252_accr_int_eksi_lc)  := 0;
        number_list(pn_3252_accr_int_eksi_fc)  := 0;
        number_list(pn_3252_accr_int_eksi_tx_lc)  := 0;
        number_list(pn_3252_accr_int_eksi_tx_fc)  := 0;
        number_list(pn_3252_nonaccr_int_eksi_lc)  := 0;
        number_list(pn_3252_nonaccr_int_eksi_fc)  := 0;
        number_list(pn_3252_accr_int_arti_lc)  := 0;
        number_list(pn_3252_accr_int_arti_fc)  := 0;
        number_list(pn_3252_accr_int_arti_tx_lc)  := 0;
        number_list(pn_3252_accr_int_arti_tx_fc)  := 0;
        number_list(pn_3252_nonaccr_int_arti_lc)  := 0;
        number_list(pn_3252_nonaccr_int_arti_fc)  := 0;
      --e-o-m seval.colak 03102022
    -- b-o-m seval.colak 06102022
    number_list(pn_3252_accr_res_int_tax_lc)  := 0;
    number_list(pn_3252_accr_res_int_tax_fc)  := 0;
    number_list(pn_3252_accr_res_delay_tax_lc)  := 0;
    number_list(pn_3252_accr_res_delay_tax_fc)  := 0;
    number_list(pn_3252_accr_res_int_woff_tax_lc)  := 0;
    number_list(pn_3252_accr_res_int_woff_tax_fc)  := 0;
    number_list(pn_3252_accr_res_del_woff_tax_lc)  := 0;
    number_list(pn_3252_accr_res_del_woff_tax_fc)  := 0;
    number_list(pn_3252_accr_res_int_pmt_lc)  := 0;
    number_list(pn_3252_accr_res_int_pmt_fc)  := 0;
    number_list(pn_3252_nonaccr_res_int_pmt_lc)  := 0;
    number_list(pn_3252_nonaccr_res_int_pmt_fc)  := 0;
    number_list(pn_3252_accr_res_delay_pmt_lc)  := 0;
    number_list(pn_3252_accr_res_delay_pmt_fc)  := 0;
    number_list(pn_3252_nonaccr_res_delay_pmt_lc)  := 0;
    number_list(pn_3252_nonaccr_res_delay_pmt_fc)  := 0;
    number_list(pn_3252_accr_res_int_woff_pmt_lc)  := 0;
    number_list(pn_3252_accr_res_int_woff_pmt_fc)  := 0;
    number_list(pn_3252_naccr_res_int_woff_pmt_lc)  := 0;
    number_list(pn_3252_naccr_res_int_woff_pmt_fc)  := 0;
    number_list(pn_3252_accr_res_del_woff_pmt_lc)  := 0;
    number_list(pn_3252_accr_res_del_woff_pmt_fc)  := 0;
    number_list(pn_3252_naccr_res_del_woff_pmt_lc)  := 0;
    number_list(pn_3252_naccr_res_del_woff_pmt_fc)  := 0;    
    --e-o-m seval.colak 06102022   
    --b-o-m seval.colak 10102022  
    number_list(pn_3252_naccr_res_int_tax_fc)  := 0;
    number_list(pn_3252_naccr_res_int_tax_lc)  := 0;
    number_list(pn_3252_naccr_res_delay_tax_fc)  := 0;
    number_list(pn_3252_naccr_res_delay_tax_lc)  := 0;
    --e-o-m seval.colak 10102022  
    varchar_list(pn_3252_penalty_gl)  := NULL;      --seval.colak 01112022
  ------------------------------------------------------------------------------------------------------            
    ls_islem_aciklama :=   Pkg_Genel.ISLEM_ADI_AL(ln_islem_kod) ;           
    Pkg_Parametre.deger('3252_BANKA_ACIKLAMA',ls_banka_aciklama);
    Pkg_Parametre.deger('3252_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
    Pkg_Parametre.deger('3252_FIS_ACIKLAMA',ls_fis_aciklama);
    varchar_list(pn_3252_fis_aciklama)    := NVL(ls_fis_aciklama,ls_islem_aciklama);            
------------------------------------------------------------------------------------------------------   
   
   for c_hesap in cur_hesap loop
         r_hesap := c_hesap;
         ln_kredi_hesap_no   := r_hesap.hesap_no;        
         ls_doviz_kodu       := r_hesap.doviz_kodu;
   end loop;     
    
   -- b-o-m seval.colak 22092022
        if ls_doviz_kodu = pkg_genel.lc_al then
        boolean_list(pn_3252_kredi_tl) := true;
        else
        boolean_list(pn_3252_kredi_yp) := true;
        end if;      

        if nvl(r_hesap.llp_amount,0) <> 0  then   
        boolean_list(pn_3252_llp_var) := true;
        else
        boolean_list(pn_3252_llp_yok) := true;
        end if;    

            varchar_list(pn_3252_iliskili_faiz_dk)      := null; 
            varchar_list(pn_3252_islem_sube)            := r_hesap.sube_kodu; 
            varchar_list(pn_3252_kredi_doviz)           := r_hesap.doviz_kodu; 
            varchar_list(pn_3252_kredi_hesap_no)        := r_hesap.hesap_no; 
            varchar_list(pn_3252_kredi_hesap_sube)      := r_hesap.sube_kodu;            
            varchar_list(pn_3252_referans)              := r_hesap.hesap_no; 
            varchar_list(pn_3252_iliskili_hesap_doviz)  := pkg_hesap.hesaptandovizkodual(r_hesap.iliskili_hesap_no);   
            varchar_list(pn_3252_iliskili_hesap_no)     := r_hesap.iliskili_hesap_no; 
            varchar_list(pn_3252_iliskili_hesap_sube)   := pkg_hesap.hesaptansubeal(r_hesap.iliskili_hesap_no);        
            varchar_list(pn_3252_accrual_int_acct_no)    := r_hesap.accrual_int_account_no; 
            varchar_list(pn_3252_accrual_tax_acct_no)    := r_hesap.accrual_tax_account_no; 
            varchar_list(pn_3252_accrual_delay_int_acct_no)  := r_hesap.accrual_delayed_int_account_no; 
            varchar_list(pn_3252_nonaccrual_int_acct_no)  := r_hesap.nonaccrual_int_account_no; 
            varchar_list(pn_3252_nonaccrual_delay_int_acct)  := r_hesap.nonaccrual_delayed_int_account_no;

            -------------------------      
            ls_bolum_kodu   := varchar_list(pn_3252_kredi_hesap_sube);
            ls_aciklama     := substr(ls_bolum_kodu || ' ' || ls_fis_aciklama || ls_islem_aciklama,1,200) ;
            varchar_list(pn_3252_fis_aciklama) := ls_aciklama ;

            ls_doviz_kodu   := varchar_list(pn_3252_kredi_doviz);
            ln_kredi_hesap_no     := varchar_list(pn_3252_kredi_hesap_no);
            varchar_list(pn_3252_banka_aciklama)  := substr(TO_CHAR(ln_kredi_hesap_no) || ' ' || ls_banka_aciklama || ls_islem_aciklama,1,200) ;
            varchar_list(pn_3252_musteri_aciklama):= substr(TO_CHAR(ln_kredi_hesap_no) ||  ' '|| ls_musteri_aciklama || ls_islem_aciklama ,1,200);
            varchar_list(pn_3252_tax_aciklama) :=  varchar_list(pn_3252_musteri_aciklama);  --'Loan Payment - '||TO_CHAR(ln_kredi_hesap_no) ;
            number_list(pn_3252_kur)  :=  Pkg_Kur.doviz_doviz_karsilik(r_hesap.Doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');

            number_list(pn_3252_anapara)                    :=  abs(nvl(r_hesap.tahsil_anapara,0));
            number_list(pn_3252_anapara_lc)                 :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_anapara,0)) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_deferred_interest)          :=  abs(nvl(r_hesap.tahsil_deferred_interest,0));
            number_list(pn_3252_deferred_interest_lc)       :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_deferred_interest,0)) ,1,NULL,NULL,'N','A'),0)));
            --
            number_list(pn_3252_deferred_tax)               :=  abs(nvl(r_hesap.tahsil_deferred_tax,0));
            number_list(pn_3252_deferred_tax_lc)            :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_deferred_tax,0)) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_penalty_amount)             :=  abs(nvl(r_hesap.tahsil_penalty_amount,0));   
            number_list(pn_3252_penalty_amount_lc)          :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_penalty_amount,0)) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_penalty_tax)                :=  abs(nvl(r_hesap.tahsil_penalty_tax,0));   
            number_list(pn_3252_penalty_tax_lc)             :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_penalty_tax,0)) ,1,NULL,NULL,'N','A'),0)));     
            number_list(pn_3252_accr_defer_int)             :=  abs(nvl(r_hesap.accrual_tahsil_deferred_interest,0)); --seval.colak 17122021
            number_list(pn_3252_accr_defer_int_lc)          :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_3252_accr_defer_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
            number_list(pn_3252_nonaccr_defer_int)          :=  abs(nvl(r_hesap.nonaccrual_tahsil_deferred_interest,0)); --seval.colak 17122021
            number_list(pn_3252_nonaccr_defer_int_lc)       :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_3252_nonaccr_defer_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
            number_list(pn_3252_accr_defer_del_int)         :=  abs(nvl(r_hesap.accrual_tahsil_deferred_delayed_int,0)); --seval.colak 17122021
            number_list(pn_3252_accr_defer_del_int_lc)      :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_3252_accr_defer_del_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
            number_list(pn_3252_nonaccr_defer_del_int)      :=  abs(nvl(r_hesap.nonaccrual_tahsil_deferred_delayed_int,0)); --seval.colak 17122021
            number_list(pn_3252_nonaccr_defer_del_int_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_3252_nonaccr_defer_del_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
            number_list(pn_3252_nonaccr_defer_int_tax)      := abs(nvl(r_hesap.tahsil_nonaccrual_deferred_tax,0));--seval.colak 28042022 
            number_list(pn_3252_nonaccr_defer_int_tax_lc)   := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_3252_nonaccr_defer_int_tax),1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_nonaccr_def_del_int_tax)    :=  abs(nvl(r_hesap.tahsil_nonaccrual_deferred_delay_tax,0));
            number_list(pn_3252_nonaccr_def_del_int_tax_l)  := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_3252_nonaccr_def_del_int_tax),1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_accr_defer_int_tax)         := abs(nvl(r_hesap.tahsil_accrual_deferred_tax,0));
            number_list(pn_3252_accr_defer_int_tax_lc)      := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_3252_accr_defer_int_tax),1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_accr_def_del_int_tax)       :=  abs(nvl(r_hesap.tahsil_accrual_deferred_delay_tax,0));
            number_list(pn_3252_accr_def_del_int_tax_l)     := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_3252_accr_def_del_int_tax),1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_deferred_toplam)            := number_list(pn_3252_deferred_tax) + number_list(pn_3252_accr_defer_int) + number_list(pn_3252_accr_defer_del_int)+ number_list(pn_3252_nonaccr_defer_int) + number_list(pn_3252_nonaccr_defer_del_int) + number_list(pn_3252_nonaccr_defer_int_tax) +number_list(pn_3252_nonaccr_def_del_int_tax) + number_list(pn_3252_accr_defer_int_tax) +number_list(pn_3252_accr_def_del_int_tax);  --seval.colak 07062022  number_list(pn_3252_accr_defer_int_tax) +number_list(pn_3252_accr_def_del_int_tax)
            number_list(pn_3252_deferred_toplam_lc)         := number_list(pn_3252_deferred_tax_lc) + number_list(pn_3252_accr_defer_int_lc) + number_list(pn_3252_accr_defer_del_int_lc)+ number_list(pn_3252_nonaccr_defer_int_lc) + number_list(pn_3252_nonaccr_defer_del_int_lc) + number_list(pn_3252_nonaccr_defer_int_tax_lc) +number_list(pn_3252_nonaccr_def_del_int_tax_l) +  number_list(pn_3252_accr_defer_int_tax_lc) +number_list(pn_3252_accr_def_del_int_tax_l) ; --seval.colak 07062022   number_list(pn_3252_accr_defer_int_tax_lc) +number_list(pn_3252_accr_def_del_int_tax_l) 

            number_list(pn_3252_penalty_toplam)             := number_list(pn_3252_penalty_amount) +  number_list(pn_3252_penalty_tax);
            number_list(pn_3252_penalty_toplam_lc)          := number_list(pn_3252_penalty_amount_lc) +  number_list(pn_3252_penalty_tax_lc);
            ------------------------------------------------------------------------------------------------------------------------------------
            number_list(pn_3252_accrual_tahsil_faiz)          :=  abs(nvl(r_hesap.accrual_tahsil_faiz,0));
            number_list(pn_3252_accrual_tahsil_faiz_lc)       :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.accrual_tahsil_faiz,0)) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_nonaccrual_tahsil_faiz)       :=  abs(nvl(r_hesap.nonaccrual_tahsil_faiz,0));
            number_list(pn_3252_nonaccrual_tahsil_faiz_lc)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.nonaccrual_tahsil_faiz,0)) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_accrual_tahsil_vergi)         :=  abs(nvl(r_hesap.accrual_tahsil_vergi,0));
            number_list(pn_3252_accrual_tahsil_vergi_lc)      :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.accrual_tahsil_vergi,0)) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_nonaccrual_tahsil_vergi)      :=  abs(nvl(r_hesap.nonaccrual_tahsil_vergi,0));
            number_list(pn_3252_nonaccrual_tahsil_vergi_l)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.nonaccrual_tahsil_vergi,0)) ,1,NULL,NULL,'N','A'),0)));

            number_list(pn_3252_toplam_faiz)                 := number_list(pn_3252_accrual_tahsil_faiz)  + number_list(pn_3252_nonaccrual_tahsil_faiz) ;
            number_list(pn_3252_toplam_faiz_lc)              := number_list(pn_3252_accrual_tahsil_faiz_lc)  + number_list(pn_3252_nonaccrual_tahsil_faiz_lc);
            number_list(pn_3252_toplam_vergi)                := number_list(pn_3252_accrual_tahsil_vergi) + number_list(pn_3252_nonaccrual_tahsil_vergi) ;
            number_list(pn_3252_toplam_vergi_lc)             := number_list(pn_3252_accrual_tahsil_vergi_lc) + number_list(pn_3252_nonaccrual_tahsil_vergi_l) ;
            number_list(pn_3252_accrual_gecikme_faiz)        :=  abs(nvl(r_hesap.accrual_tahsil_gecikme_faiz,0));
            number_list(pn_3252_accrual_gecikme_faiz_lc)     :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_3252_accrual_gecikme_faiz),0) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_nonaccrual_gecikme_faiz)     :=  abs(nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz,0));
            number_list(pn_3252_nonaccrual_gecikme_faiz_l)   :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_3252_nonaccrual_gecikme_faiz),0) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_accrual_gecikme_tax)         :=  abs(nvl(r_hesap.accrual_tahsil_gecikme_faiz_tax,0));
            number_list(pn_3252_accrual_gecikme_tax_lc)      :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_3252_accrual_gecikme_tax),0) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_nonaccrual_gecikme_tax)      :=  abs(nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz_tax,0));
            number_list(pn_3252_nonaccrual_gecikme_tax_lc)   :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_3252_nonaccrual_gecikme_tax),0) ,1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_gecikme_faiz_toplam)         := number_list(pn_3252_accrual_gecikme_faiz) +  number_list(pn_3252_accrual_gecikme_tax) + number_list(pn_3252_nonaccrual_gecikme_faiz) +  number_list(pn_3252_nonaccrual_gecikme_tax) ;
            number_list(pn_3252_gecikme_faiz_toplam_lc)      := number_list(pn_3252_accrual_gecikme_faiz_lc) +  number_list(pn_3252_accrual_gecikme_tax_lc) + number_list(pn_3252_nonaccrual_gecikme_faiz_l) +  number_list(pn_3252_nonaccrual_gecikme_tax_lc) ;

            number_list(pn_3252_defer_penalty)       :=  abs(nvl(r_hesap.tahsil_deferred_penalty_amount,0));
            number_list(pn_3252_defer_penalty_lc)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,number_list(pn_3252_defer_penalty),1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_defer_pen_tax)       :=  abs(nvl(r_hesap.tahsil_deferred_penalty_tax,0));
            number_list(pn_3252_defer_pen_tax_lc)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_3252_defer_pen_tax),1,NULL,NULL,'N','A'),0)));
            number_list(pn_3252_defer_pen_toplam)    := number_list(pn_3252_defer_penalty)  + number_list(pn_3252_defer_pen_tax);
            number_list(pn_3252_defer_pen_toplam_lc) :=  number_list(pn_3252_defer_penalty_lc)  + number_list(pn_3252_defer_pen_tax_lc);
            number_list(pn_3252_addition_disbursement_fc) := abs(nvl(r_hesap.additional_disbursement_amount,0)) ;
            number_list(pn_3252_addition_disbursement_lc) := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_addition_disbursement_fc),1,null,null,'N','A'),0)));

            --number_list(pn_3252_pdint_total_fc)   :=  abs( nvl( r_hesap.pd_int_total_amt,0));
            --number_list(pn_3252_pdint_total_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdint_total_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pddeferred_fc)      :=   abs( nvl( r_hesap.pd_int_deferred_amt,0)) ; 
            number_list(pn_3252_pddeferred_lc)      :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pddeferred_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pdcapitalize_fc)    :=  abs( nvl( r_hesap.pd_int_capitalize_amt,0)) ; 
            number_list(pn_3252_pdcapitalize_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdcapitalize_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pdcollection_fc)    :=  abs( nvl( r_hesap.pd_int_collection_amt,0)) ; 
            number_list(pn_3252_pdcollection_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdcollection_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pdwriteoff_fc)      :=  abs( nvl( r_hesap.pd_int_writeoff_amt,0)) ; 
            number_list(pn_3252_pdwriteoff_lc)      :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdwriteoff_fc),1,null,null,'N','A'),0)));

            number_list(pn_3252_pdint_total_fc)   :=  number_list(pn_3252_pddeferred_fc) +number_list(pn_3252_pdcapitalize_fc) + number_list(pn_3252_pdcollection_fc) +number_list(pn_3252_pdwriteoff_fc);
            number_list(pn_3252_pdint_total_lc)   :=  number_list(pn_3252_pddeferred_lc) +number_list(pn_3252_pdcapitalize_lc) + number_list(pn_3252_pdcollection_lc) +number_list(pn_3252_pdwriteoff_lc);

            --number_list(pn_3252_undueint_total_fc)   :=  abs( nvl( r_hesap.undue_int_total_amt,0)) ;
            --number_list(pn_3252_undueint_total_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_undueint_total_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduedeferred_fc)  :=  abs( nvl( r_hesap.undue_int_deferred_amt,0)) ; 
            number_list(pn_3252_unduedeferred_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduedeferred_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduecapitalize_fc)  :=  abs( nvl( r_hesap.undue_int_capitalize_amt,0)) ; 
            number_list(pn_3252_unduecapitalize_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduecapitalize_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduecollection_fc)  :=  abs( nvl( r_hesap.undue_int_collection_amt,0)) ; 
            number_list(pn_3252_unduecollection_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduecollection_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduewriteoff_fc)    :=  abs( nvl( r_hesap.undue_int_writeoff_amt,0)) ; 
            number_list(pn_3252_unduewriteoff_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduewriteoff_fc),1,null,null,'N','A'),0)));

            number_list(pn_3252_undueint_total_fc)   :=  number_list(pn_3252_unduedeferred_fc) +number_list(pn_3252_unduecapitalize_fc) + number_list(pn_3252_unduecollection_fc) +number_list(pn_3252_unduewriteoff_fc);
            number_list(pn_3252_undueint_total_lc)   :=  number_list(pn_3252_unduedeferred_lc) +number_list(pn_3252_unduecapitalize_lc) + number_list(pn_3252_unduecollection_lc) +number_list(pn_3252_unduewriteoff_lc);

            --number_list(pn_3252_delayint_total_fc)   :=  abs( nvl( r_hesap.delay_int_total_amt,0)) ;
            --number_list(pn_3252_delayint_total_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delayint_total_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaydeferred_fc)  :=  abs( nvl( r_hesap.delay_int_deferred_amt,0)) ; 
            number_list(pn_3252_delaydeferred_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaydeferred_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaycapitalize_fc)  :=  abs( nvl( r_hesap.delay_int_capitalize_amt,0)) ; 
            number_list(pn_3252_delaycapitalize_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaycapitalize_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaycollection_fc)  :=  abs( nvl( r_hesap.delay_int_collection_amt,0)) ; 
            number_list(pn_3252_delaycollection_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaycollection_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaywriteoff_fc)    :=  abs( nvl( r_hesap.delay_int_writeoff_amt,0)) ; 
            number_list(pn_3252_delaywriteoff_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaywriteoff_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delayint_total_fc)   :=  number_list(pn_3252_delaydeferred_fc) +number_list(pn_3252_delaycapitalize_fc) + number_list(pn_3252_delaycollection_fc) +number_list(pn_3252_delaywriteoff_fc);
            number_list(pn_3252_delayint_total_lc)   :=  number_list(pn_3252_delaydeferred_lc) +number_list(pn_3252_delaycapitalize_lc) + number_list(pn_3252_delaycollection_lc) +number_list(pn_3252_delaywriteoff_lc);

            -- number_list(pn_3252_penaltyint_total_fc)   :=  abs( nvl( r_hesap.penalty_int_total_amt,0)) ;
            --number_list(pn_3252_penaltyint_total_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltyint_total_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltydeferred_fc)  :=  abs( nvl( r_hesap.penalty_int_deferred_amt,0)) ; 
            number_list(pn_3252_penaltydeferred_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltydeferred_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltycapitalize_fc)  :=  abs( nvl( r_hesap.penalty_int_capitalize_amt,0)) ; 
            number_list(pn_3252_penaltycapitalize_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltycapitalize_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltycollection_fc)  :=  abs( nvl( r_hesap.penalty_int_collection_amt,0)) ; 
            number_list(pn_3252_penaltycollection_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltycollection_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltywriteoff_fc)    :=  abs( nvl( r_hesap.penalty_int_writeoff_amt,0)) ; 
            number_list(pn_3252_penaltywriteoff_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltywriteoff_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltyint_total_fc)   :=  number_list(pn_3252_penaltydeferred_fc) +number_list(pn_3252_penaltycapitalize_fc) + number_list(pn_3252_penaltycollection_fc) +number_list(pn_3252_penaltywriteoff_fc);
            number_list(pn_3252_penaltyint_total_lc)   :=  number_list(pn_3252_penaltydeferred_lc) +number_list(pn_3252_penaltycapitalize_lc) + number_list(pn_3252_penaltycollection_lc) +number_list(pn_3252_penaltywriteoff_lc);

            -- TAX
            -- number_list(pn_3252_pdint_total_tax_fc)   :=  round( (abs(nvl(r_hesap.pd_int_total_amt,0))* nvl(ln_tax_rate,0) / 100 ),2)  ;-- abs( nvl( r_hesap.pd_int_total_amt,0)) ;
            -- number_list(pn_3252_pdint_total_tax_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdint_total_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pdwriteoff_tax_fc)  :=  round( (abs(nvl(r_hesap.pd_int_writeoff_amt,0))* nvl(ln_tax_rate,0) / 100 ),2)  ; --abs( nvl( r_hesap.pd_int_writeoff_amt,0)) ; 
            number_list(pn_3252_pdwriteoff_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdwriteoff_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pddeferred_tax_fc)  :=  round( (abs(nvl(r_hesap.pd_int_deferred_amt,0))* nvl(ln_tax_rate,0) / 100 ),2)  ; --abs( nvl( r_hesap.pd_int_deferred_amt,0)) ; 
            number_list(pn_3252_pddeferred_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pddeferred_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pdcapitalize_tax_fc)  :=  round( (abs(nvl(r_hesap.pd_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2)  ; --abs( nvl( r_hesap.pd_int_capitalize_amt,0)) ; 
            number_list(pn_3252_pdcapitalize_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdcapitalize_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_pdcollection_tax_fc)  :=  round( (abs(nvl(r_hesap.pd_int_collection_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.pd_int_collection_amt,0)) ; 
            number_list(pn_3252_pdcollection_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_pdcollection_tax_fc),1,null,null,'N','A'),0)));

            number_list(pn_3252_pdint_total_tax_fc)   :=  number_list(pn_3252_pddeferred_tax_fc) + number_list(pn_3252_pdcapitalize_tax_fc) + number_list(pn_3252_pdcollection_tax_fc) + number_list(pn_3252_pdwriteoff_tax_fc);
            number_list(pn_3252_pdint_total_tax_lc)   :=  number_list(pn_3252_pddeferred_tax_lc) + number_list(pn_3252_pdcapitalize_tax_lc) + number_list(pn_3252_pdcollection_tax_lc) + number_list(pn_3252_pdwriteoff_tax_lc);

            --  number_list(pn_3252_undueint_total_tax_fc)   :=  round( (abs(nvl(r_hesap.undue_int_total_amt,0))* nvl(ln_tax_rate,0) / 100 ),2); --abs( nvl( r_hesap.undue_int_total_amt,0)) ;
            -- number_list(pn_3252_undueint_total_tax_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_undueint_total_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduewriteoff_tax_fc)  :=  round( (abs(nvl(r_hesap.undue_int_writeoff_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.undue_int_writeoff_amt,0)) ; 
            number_list(pn_3252_unduewriteoff_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduewriteoff_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduedeferred_tax_fc)  :=  round( (abs(nvl(r_hesap.undue_int_deferred_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.undue_int_deferred_amt,0)) ; 
            number_list(pn_3252_unduedeferred_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduedeferred_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduecapitalize_tax_fc)  :=  round( (abs(nvl(r_hesap.undue_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.undue_int_capitalize_amt,0)) ; 
            number_list(pn_3252_unduecapitalize_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduecapitalize_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_unduecollection_tax_fc)  :=  round( (abs(nvl(r_hesap.undue_int_collection_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.undue_int_collection_amt,0)) ; 
            number_list(pn_3252_unduecollection_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_unduecollection_tax_fc),1,null,null,'N','A'),0)));

            number_list(pn_3252_undueint_total_tax_fc)   :=  number_list(pn_3252_unduedeferred_tax_fc) + number_list(pn_3252_unduecapitalize_tax_fc) + number_list(pn_3252_unduecollection_tax_fc) +  number_list(pn_3252_unduewriteoff_tax_fc);
            number_list(pn_3252_undueint_total_tax_lc)   :=  number_list(pn_3252_unduedeferred_tax_lc) + number_list(pn_3252_unduecapitalize_tax_lc) + number_list(pn_3252_unduecollection_tax_lc) +  number_list(pn_3252_unduewriteoff_tax_lc);

            --number_list(pnf_3252_delayint_total_tax_fc)   :=  round( (abs(nvl(r_hesap.delay_int_total_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.delay_int_total_amt,0)) ;
            --number_list(pn_3252_delayint_total_tax_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delayint_total_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaywriteoff_tax_fc)  :=  round( (abs(nvl(r_hesap.delay_int_writeoff_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.delay_int_writeoff_amt,0)) ; 
            number_list(pn_3252_delaywriteoff_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaywriteoff_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaydeferred_tax_fc)  :=  round( (abs(nvl(r_hesap.delay_int_deferred_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.delay_int_deferred_amt,0)) ; 
            number_list(pn_3252_delaydeferred_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaydeferred_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaycapitalize_tax_fc)  :=  round( (abs(nvl(r_hesap.delay_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.delay_int_capitalize_amt,0)) ; 
            number_list(pn_3252_delaycapitalize_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaycapitalize_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_delaycollection_tax_fc)  :=  round( (abs(nvl(r_hesap.delay_int_collection_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.delay_int_collection_amt,0)) ; 
            number_list(pn_3252_delaycollection_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_delaycollection_tax_fc),1,null,null,'N','A'),0)));

            number_list(pn_3252_delayint_total_tax_fc)   :=  number_list(pn_3252_delaydeferred_tax_fc) + number_list(pn_3252_delaycapitalize_tax_fc) + number_list(pn_3252_delaycollection_tax_fc) + number_list(pn_3252_delaywriteoff_tax_fc);
            number_list(pn_3252_delayint_total_tax_lc)   :=  number_list(pn_3252_delaydeferred_tax_lc) + number_list(pn_3252_delaycapitalize_tax_lc) + number_list(pn_3252_delaycollection_tax_lc) + number_list(pn_3252_delaywriteoff_tax_lc);

            -- number_list(pn_3252_penaltyint_total_tax_fc)   :=  round( (abs(nvl(r_hesap.penalty_int_total_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_total_amt,0)) ;
            -- number_list(pn_3252_penaltyint_total_tax_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltyint_total_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltywriteoff_tax_fc)  :=  round( (abs(nvl(r_hesap.penalty_int_writeoff_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_writeoff_amt,0)) ; 
            number_list(pn_3252_penaltywriteoff_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltywriteoff_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltydeferred_tax_fc)  :=  round( (abs(nvl(r_hesap.penalty_int_deferred_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_deferred_amt,0)) ; 
            number_list(pn_3252_penaltydeferred_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltydeferred_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltycapitalize_tax_fc)  :=  round( (abs(nvl(r_hesap.penalty_int_capitalize_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_capitalize_amt,0)) ; 
            number_list(pn_3252_penaltycapitalize_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltycapitalize_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltycollection_tax_fc)  :=  round( (abs(nvl(r_hesap.penalty_int_collection_amt,0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_collection_amt,0)) ; 
            number_list(pn_3252_penaltycollection_tax_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_penaltycollection_tax_fc),1,null,null,'N','A'),0)));
            number_list(pn_3252_penaltyint_total_tax_fc)   :=  number_list(pn_3252_penaltydeferred_tax_fc) + number_list(pn_3252_penaltycapitalize_tax_fc) + number_list(pn_3252_penaltycollection_tax_fc) + number_list(pn_3252_penaltywriteoff_tax_fc) ;
            number_list(pn_3252_penaltyint_total_tax_lc)   :=  number_list(pn_3252_penaltydeferred_tax_lc) + number_list(pn_3252_penaltycapitalize_tax_lc) + number_list(pn_3252_penaltycollection_tax_lc) + number_list(pn_3252_penaltywriteoff_tax_lc) ;
            -- e-o-m seval.colak 22092022

            ---Kontroller 
            if   varchar_list(pn_3252_iliskili_hesap_no)  is null then
            raise iliskili_hesapno_yok;
            end if;

            if  varchar_list(pn_3252_accrual_int_acct_no) is null then   --number_list(pn_3252_toplam_faiz) <> 0 and
            raise faiz_tahakkuk_hesapno_yok;
            end if;

            if  varchar_list(pn_3252_accrual_tax_acct_no) is null then -- number_list(pn_3252_toplam_vergi) <> 0 and
            raise vergi_tahakkuk_hesapno_yok;
            end if;
                  
   --DK faiz ve reeeskont bulunur 
         /*faiz gl dk */
        if  r_hesap.dk_grup_kod is not null and r_hesap.modul_tur_kod is not null and r_hesap.urun_tur_kod is not null and r_hesap.urun_sinif_kod is not null then 
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 2,  null,null, null,varchar_list(pn_3252_iliskili_faiz_dk));
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 10,null,null, null,varchar_list(pn_3252_gecikme_faiz_gl)); --seval.colak 14012022
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 12,null,null, null,varchar_list(pn_3252_penalty_gl)); --seval.colak 01112022
          end if;  

        if  ( nvl(number_list(pn_3252_toplam_faiz),0) <> 0 or 
                (nvl(number_list(pn_3252_nonaccr_defer_int),0) +  nvl(number_list(pn_3252_nonaccrual_tahsil_faiz) ,0) <> 0  )) --seval.colak 14012022
             and  varchar_list(pn_3252_iliskili_faiz_dk) is null  then
                 raise iliskili_faiz_dk_yok;               
         end if;
             
        /*DELAY interest penalty deferred dk */
          if   (  number_list(pn_3252_penalty_amount) + number_list(pn_3252_defer_penalty) + number_list(pn_3252_nonaccr_defer_del_int) +number_list(pn_3252_nonaccrual_gecikme_faiz) <>0 )  and (varchar_list(pn_3252_gecikme_faiz_gl) is null )  then
                  raise gecikme_faiz_dk_yok;
         end if;

    --b-o-m seval.colak 03102022
     select sum( abs(nvl(b.gecikme_faiz_tutari,0)) - abs( nvl(b.tahsil_gecikme_faiz_tutari,0) ) )  +
            sum( abs(nvl(b.deferred_delayed_interest,0))-  abs(nvl(b.paid_deferred_delayed_interest,0))) top_delay_defer_int,
            sum(  case when vade_tarih <= pkg_muhasebe.banka_tarihi_Bul then abs(nvl(b.faiz,0))- abs(nvl(b.tahsil_faiz,0)) else 0 end    ) + sum( abs(nvl(b.deferred_interest,0)) - abs( nvl(b.paid_deferred_interest,0) ) )  top_faiz_defer_int, --seval.colak 05012023 faiz de tarih kontrolu eklendi.
            sum(  abs(nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) )+ abs(nvl(deferred_penalty_amount,0) - nvl(paid_deferred_penalty_amount,0)) ) top_penalty_amount            
     into    ln_isl_top_tahsil_delay_defer_int,
             ln_isl_top_tahsil_faiz_defer_int,
             ln_isl_top_penalty_amount
    from cbs_hesap_kredi_taksit_islem b
    where tx_no = pn_islem_no and
          nvl(durum_kodu,'A') = 'A';          
                
     select sum( abs(nvl(b.gecikme_faiz_tutari,0)) - abs( nvl(b.tahsil_gecikme_faiz_tutari,0) ) )  +
            sum( abs(nvl(b.deferred_delayed_interest,0))-  abs(nvl(b.paid_deferred_delayed_interest,0))) top_delay_defer_int,
            sum( case when vade_tarih <= pkg_muhasebe.banka_tarihi_Bul then abs(nvl(b.faiz,0))- abs(nvl(b.tahsil_faiz,0)) else 0 end    ) +   sum( abs(nvl(b.deferred_interest,0)) - abs( nvl(b.paid_deferred_interest,0) ) ) top_faiz_defer_int,  --seval.colak 05012023 faiz de tarih kontrolu eklendi.
            sum( abs(nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) )+ abs(nvl(deferred_penalty_amount,0) - nvl(paid_deferred_penalty_amount,0)) ) top_penalty_amount                
     into    ln_hsp_top_tahsil_delay_defer_int,
             ln_hsp_top_tahsil_faiz_defer_int,
             ln_hsp_top_penalty_amount
     from cbs_hesap_kredi_taksit b
    where hesap_no = ln_kredi_hesap_no and
          nvl(durum_kodu,'A') = 'A';    
       

 ln_accr_int_acct_bakiye := abs(pkg_hesap.hesapbakiyeal(varchar_list(pn_3252_accrual_int_acct_no)));                 --seval.colak 21122022
 ln_accr_delay_int_acct_bakiye := abs(pkg_hesap.hesapbakiyeal(varchar_list(pn_3252_accrual_delay_int_acct_no)));    --seval.colak 21122022
 
  if  nvl(r_hesap.plan_Degisiklik_secimi,'X') <> 'RESTRUCTURE'  then   -- seval.colak 14102022
    ln_Fark_top_penalty_amount   := nvl(ln_isl_top_penalty_amount,0)  - nvl (ln_hsp_top_penalty_amount,0) ; 
 
    --   islemdeki deger mevcut taksitlerin toplamindan az ise azaltim  nvl(ln_isl_top_tahsil_delay_defer_int,0)  < nvl (ln_hsp_top_tahsil_delay_defer_int,0)
   ln_Fark_top_tahsil_delay_defer_int :=   nvl(ln_isl_top_tahsil_delay_defer_int,0)  - nvl (ln_hsp_top_tahsil_delay_defer_int,0) ; 
   if  ln_Fark_top_tahsil_delay_defer_int < 0  then 
        if   nvl(r_hesap.non_accrual_status,'N') ='Y' THEN    
                 if ln_accr_delay_int_acct_bakiye > 0 then  ----seval.colak 21122022  pozitifse tamami non accrual 
                      number_list(pn_3252_nonaccr_delay_int_eksi_fc)  := abs(ln_Fark_top_tahsil_delay_defer_int) ; 
                 else     
                     number_list(pn_3252_nonaccr_delay_int_eksi_fc)  := abs(abs(nvl(ln_accr_delay_int_acct_bakiye,0)  - abs(ln_Fark_top_tahsil_delay_defer_int))) ;
                 end if; 
              number_list(pn_3252_nonaccr_delay_int_eksi_lc)  := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_nonaccr_delay_int_eksi_fc),1,null,null,'N','A'),0)));
          
        else
           number_list(pn_3252_accr_delay_int_eksi_fc)  :=  abs(ln_Fark_top_tahsil_delay_defer_int) ;
           number_list(pn_3252_accr_delay_int_eksi_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_delay_int_eksi_fc),1,null,null,'N','A'),0)));
           number_list(pn_3252_accr_delay_int_eksi_tx_fc)  :=  round( (abs(nvl( number_list(pn_3252_accr_delay_int_eksi_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_writeoff_amt,0)) ; 
           number_list(pn_3252_accr_delay_int_eksi_tx_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_delay_int_eksi_tx_fc),1,null,null,'N','A'),0)));
          end if;
    else
      if   nvl(r_hesap.non_accrual_status,'N') ='Y' THEN         
             number_list(pn_3252_nonaccr_delay_int_arti_fc)  :=  abs(ln_Fark_top_tahsil_delay_defer_int) ;
             number_list(pn_3252_nonaccr_delay_int_arti_lc)  := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_nonaccr_delay_int_arti_fc),1,null,null,'N','A'),0)));
          
        else
           number_list(pn_3252_accr_delay_int_arti_fc)  :=  abs(ln_Fark_top_tahsil_delay_defer_int) ;
           number_list(pn_3252_accr_delay_int_arti_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_delay_int_arti_fc),1,null,null,'N','A'),0)));
           number_list(pn_3252_accr_delay_int_arti_tx_fc)  :=  round( (abs(nvl( number_list(pn_3252_accr_delay_int_arti_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_writeoff_amt,0)) ; 
           number_list(pn_3252_accr_delay_int_arti_tx_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_delay_int_arti_tx_fc),1,null,null,'N','A'),0)));
          end if;
    end if;

    ln_Fark_top_tahsil_faiz_defer_int :=   nvl(ln_isl_top_tahsil_faiz_defer_int,0)  - nvl (ln_hsp_top_tahsil_faiz_defer_int,0) ; 
   if  ln_Fark_top_tahsil_faiz_defer_int < 0  then 
        if   nvl(r_hesap.non_accrual_status,'N') ='Y' THEN         
                if ln_accr_int_acct_bakiye > 0 then  ----seval.colak 21122022  pozitifse tamami non accrual 
                      number_list(pn_3252_nonaccr_int_eksi_fc)  := abs(ln_Fark_top_tahsil_faiz_defer_int) ; 
                 else     
                     number_list(pn_3252_nonaccr_int_eksi_fc)  := abs( abs(nvl(ln_accr_int_acct_bakiye,0)  - abs(ln_Fark_top_tahsil_faiz_defer_int))) ;
                 end if; 
               number_list(pn_3252_nonaccr_int_eksi_lc)  := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_nonaccr_int_eksi_fc),1,null,null,'N','A'),0)));
        else
           number_list(pn_3252_accr_int_eksi_fc)  :=  abs(ln_Fark_top_tahsil_faiz_defer_int) ;
           number_list(pn_3252_accr_int_eksi_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_int_eksi_fc),1,null,null,'N','A'),0)));
           number_list(pn_3252_accr_int_eksi_tx_fc)  :=  round( (abs(nvl( number_list(pn_3252_accr_int_eksi_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_writeoff_amt,0)) ; 
           number_list(pn_3252_accr_int_eksi_tx_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_int_eksi_tx_fc),1,null,null,'N','A'),0)));
         end if;
    else
      if   nvl(r_hesap.non_accrual_status,'N') ='Y' THEN         
             number_list(pn_3252_nonaccr_int_arti_fc)  :=  abs(ln_Fark_top_tahsil_faiz_defer_int) ;
             number_list(pn_3252_nonaccr_int_arti_lc)  := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_nonaccr_int_arti_fc),1,null,null,'N','A'),0)));
          
        else
           number_list(pn_3252_accr_int_arti_fc)  :=  abs(ln_Fark_top_tahsil_faiz_defer_int) ;
           number_list(pn_3252_accr_int_arti_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_int_arti_fc),1,null,null,'N','A'),0)));
           number_list(pn_3252_accr_int_arti_tx_fc)  :=  round( (abs(nvl( number_list(pn_3252_accr_int_arti_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_writeoff_amt,0)) ; 
           number_list(pn_3252_accr_int_arti_tx_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_int_arti_tx_fc),1,null,null,'N','A'),0)));
          end if;
    end if;
   end if ; --seval.colak 14102022   
    --e-o-m seval.colak 03102022    
    
-- b-o-m seval.colak 06102022
 IF  nvl(r_hesap.plan_Degisiklik_secimi,'X') = 'RESTRUCTURE'  then   -- seval.colak 21122022 sadece RESTRUCTURE icin calisacak 
            ln_top_res_int_pmt := abs(nvl(number_list(pn_3252_pdcollection_fc),0)) +  abs(nvl(number_list(pn_3252_pdcapitalize_fc),0))  + abs(nvl(number_list(pn_3252_unduecollection_fc),0)) + abs(nvl(number_list(pn_3252_unduecapitalize_fc),0)) ;
            ln_accr_int_acct_bakiye := abs(pkg_hesap.hesapbakiyeal(varchar_list(pn_3252_accrual_int_acct_no)));
              
             if nvl(ln_top_res_int_pmt,0) <> 0 then 
              if   nvl(r_hesap.non_accrual_status,'N') ='N' then  
                    number_list(pn_3252_accr_res_int_pmt_fc)  := ln_top_res_int_pmt;    
               else
                  if  nvl(ln_top_res_int_pmt,0) > nvl(ln_accr_int_acct_bakiye,0) then
                        number_list(pn_3252_accr_res_int_pmt_fc)  := ln_accr_int_acct_bakiye;
                        number_list(pn_3252_nonaccr_res_int_pmt_fc)  :=  nvl(ln_top_res_int_pmt,0) - nvl(ln_accr_int_acct_bakiye,0) ;
                  else 
                        number_list(pn_3252_accr_res_int_pmt_fc)  := ln_top_res_int_pmt;  
                 end if;
             end if;
            end if;
        /*  
        DELAY INTEREST
        “3252_DELAYCOLLECTION_FC + 3252_DELAY_FC  “ degeri  Accrual_Res_delay_payment,Nonacc_Res_delay_payment olarak ayr?st?r?lacak
        kredinin nonaccrual status.u H ise tamam?  Accrual_Res_?nt_payment.a atanacak ; E ise ve bu deger  > 3252_ACCRUAL_DELAY_INT_ACCT_NO  bakiye (abs) ise bakiye kadarl?k k?sm? Accrual_Res_delay_payment.a ;kalan? Nonacc_Res_delay_payment.a atanacakt?r.  
        Accrual_Res_delay_payment * tax rate /100 (rounded) degeri de Accrual_Res_delay_payment _tax e atanacak.
        */

        ln_top_res_delay_int_pmt :=  abs(nvl(number_list(pn_3252_delaycollection_fc),0)) + abs(nvl(number_list(pn_3252_delaycapitalize_fc),0)) ; 
        ln_accr_delay_int_acct_bakiye := abs(pkg_hesap.hesapbakiyeal(varchar_list(pn_3252_accrual_delay_int_acct_no)));

        if nvl(ln_top_res_delay_int_pmt,0) <> 0 then 
            if   nvl(r_hesap.non_accrual_status,'N') ='N' then  
                number_list(pn_3252_accr_res_delay_pmt_fc)  := ln_top_res_delay_int_pmt;    
            else
              if   nvl(ln_top_res_delay_int_pmt,0) > nvl(ln_accr_delay_int_acct_bakiye,0) then
                    number_list(pn_3252_accr_res_delay_pmt_fc)  := nvl(ln_accr_delay_int_acct_bakiye,0);
                    number_list(pn_3252_nonaccr_res_delay_pmt_fc)  :=  nvl(ln_top_res_delay_int_pmt,0) - nvl(ln_accr_delay_int_acct_bakiye,0) ;
              else 
                    number_list(pn_3252_accr_res_delay_pmt_fc)  := ln_top_res_delay_int_pmt;  
             end if;
          end if;
         end if; 
         
        /*
        WRITE-OFF
        “3252_PDWRITEOFF_FC + 3252_UNDUEWRITEOFF_FC “ total write off degeri  Accrual_Res_?nt_writeoff,Nonacc_Res_?nt_writeoff olarak ayr?st?r?lacak
        kredinin nonaccrual status.u H ise tamam? Accrual_Res_?nt_writeoff a atanacak ; E ise ve “3252_ACCRUAL_INT_ACCT_NO  bakiye (abs)  (-) Accrual_Res_?nt_payment “ degeri ( A degeri) > “3252_PDWRITEOFF_FC + 3252_UNDUEWRITEOFF_FC “ ise A degeri Accrual_Res_?nt_writeoff a atanacak  ; kalan? da (Total write off (-) Accrual_Res_?nt_writeoff)   Nonacc_Res_?nt_writeoff a atanacak
        */
        ln_top_res_int_woff_pmt := abs(nvl(number_list(pn_3252_pdwriteoff_fc),0)) + abs(nvl(number_list(pn_3252_unduewriteoff_fc),0));
        ln_accr_int_woff_acct_bakiye := abs(nvl(ln_accr_delay_int_acct_bakiye,0) -  number_list(pn_3252_accr_res_int_pmt_fc)) ;

        if nvl(ln_top_res_int_woff_pmt,0) <> 0 then 
          if   nvl(r_hesap.non_accrual_status,'N') ='N' then  
                number_list(pn_3252_accr_res_int_woff_pmt_fc)  := ln_top_res_int_woff_pmt;    
           else
              if  nvl(ln_top_res_int_woff_pmt,0) > nvl(ln_accr_int_woff_acct_bakiye,0) then
                    number_list(pn_3252_accr_res_int_woff_pmt_fc)  :=  ln_accr_int_woff_acct_bakiye;
                    number_list(pn_3252_naccr_res_int_woff_pmt_fc)  :=  nvl(ln_top_res_int_woff_pmt,0) - nvl(ln_accr_int_woff_acct_bakiye,0) ;
              else 
                      number_list(pn_3252_accr_res_int_woff_pmt_fc)  := ln_top_res_int_woff_pmt;  
             end if;
         end if;
         end if;
          
         /*
         “3252_DELAYWRITEOFF_FC “ degeri Accrual_Res_delay_writeoff,Nonacc_Res_delay_writeoff olarak ayr?st?r?lacak 
        kredinin nonaccrual status.u H ise tamam? Accrual_Res_delay_writeoff a atanacak ; E ise ve “3252_ACCRUAL_DELAY_INT_ACCT_NO  bakiye (abs)  (-) Accrual_Res_delay_payment “ degeri ( B degeri) > “3252_DELAYWRITEOFF_FC “ ise A degeri Accrual_Res_delay_writeoff a atanacak  ; kalan? da Nonacc_Res_?nt_writeoff a atanacak
         */
         --number_list(pn_3252_accr_delay_int_arti_tx_fc)  :=  round( (abs(nvl( number_list(pn_3252_accr_delay_int_arti_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);--abs( nvl( r_hesap.penalty_int_writeoff_amt,0)) ; 
         --number_list(pn_3252_accr_delay_int_arti_tx_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_delay_int_arti_tx_fc),1,null,null,'N','A'),0)));
         
        ln_top_res_del_woff_pmt := abs(nvl(number_list(pn_3252_delaywriteoff_fc),0));
        ln_accr_del_woff_acct_bakiye := abs(nvl(ln_accr_delay_int_acct_bakiye,0) - number_list(pn_3252_accr_res_delay_pmt_fc)) ;

        if nvl(ln_top_res_del_woff_pmt,0) <> 0 then 
          if   nvl(r_hesap.non_accrual_status,'N') ='N' then  
                number_list(pn_3252_accr_res_del_woff_pmt_fc)  := ln_top_res_del_woff_pmt;    
           else
              if  nvl(ln_top_res_del_woff_pmt,0) > nvl(ln_accr_del_woff_acct_bakiye,0) then
                    number_list(pn_3252_accr_res_del_woff_pmt_fc)  :=  ln_accr_del_woff_acct_bakiye;
                    number_list(pn_3252_naccr_res_del_woff_pmt_fc)  :=  nvl(ln_top_res_del_woff_pmt,0) - nvl(ln_accr_del_woff_acct_bakiye,0) ;
              else 
                      number_list(pn_3252_accr_res_del_woff_pmt_fc)  := ln_top_res_del_woff_pmt;  
             end if;
         end if; 
         end if;
         
        number_list(pn_3252_accr_res_int_tax_fc)        := round( (abs(nvl( number_list(pn_3252_accr_res_int_pmt_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);
        number_list(pn_3252_accr_res_delay_tax_fc)      := round( (abs(nvl( number_list(pn_3252_accr_res_delay_pmt_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);
        number_list(pn_3252_accr_res_int_woff_tax_fc)   := round( (abs(nvl( number_list(pn_3252_accr_res_int_woff_pmt_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);
        number_list(pn_3252_accr_res_del_woff_tax_fc)   := round( (abs(nvl( number_list(pn_3252_accr_res_del_woff_pmt_fc),0))* nvl(ln_tax_rate,0) / 100 ),2);

        number_list(pn_3252_accr_res_int_pmt_lc)        := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_int_pmt_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_nonaccr_res_int_pmt_lc)     := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_nonaccr_res_int_pmt_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_accr_res_delay_pmt_lc)      := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_delay_pmt_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_nonaccr_res_delay_pmt_lc)   := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_nonaccr_res_delay_pmt_fc),1,null,null,'N','A'),0)));

        number_list(pn_3252_accr_res_int_woff_pmt_lc)   := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_int_woff_pmt_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_naccr_res_int_woff_pmt_lc)  := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_naccr_res_int_woff_pmt_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_accr_res_del_woff_pmt_lc)   := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_del_woff_pmt_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_naccr_res_del_woff_pmt_lc)  := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_naccr_res_del_woff_pmt_fc),1,null,null,'N','A'),0)));

        number_list(pn_3252_accr_res_int_tax_lc)        := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_int_tax_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_accr_res_delay_tax_lc)      := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_delay_tax_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_accr_res_int_woff_tax_lc)   := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_int_woff_tax_fc),1,null,null,'N','A'),0)));
        number_list(pn_3252_accr_res_del_woff_tax_lc)   := pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null,number_list(pn_3252_accr_res_del_woff_tax_fc),1,null,null,'N','A'),0)));
        --b-o-m  seval.colak 10102022
         if   nvl(r_hesap.non_accrual_status,'N') ='Y' then  
            number_list(pn_3252_naccr_res_int_tax_fc)  := abs((abs(nvl(number_list(pn_3252_pdcollection_tax_fc),0)) +  abs(nvl(number_list(pn_3252_pdcapitalize_tax_fc),0))  + abs(nvl(number_list(pn_3252_unduecollection_tax_fc),0)) + abs(nvl(number_list(pn_3252_unduecapitalize_tax_fc),0)) ) - number_list(pn_3252_accr_res_int_tax_fc)) ;
            number_list(pn_3252_naccr_res_int_tax_lc)  := abs((abs(nvl(number_list(pn_3252_pdcollection_tax_lc),0)) +  abs(nvl(number_list(pn_3252_pdcapitalize_tax_lc),0))  + abs(nvl(number_list(pn_3252_unduecollection_tax_lc),0)) + abs(nvl(number_list(pn_3252_unduecapitalize_tax_lc),0)) ) - number_list(pn_3252_accr_res_int_tax_lc)) ;
            number_list(pn_3252_naccr_res_delay_tax_fc) := abs((abs(nvl(number_list(pn_3252_delaycollection_tax_fc),0)) +  abs(nvl(number_list(pn_3252_delaycapitalize_tax_fc),0)))  - number_list(pn_3252_accr_res_delay_tax_fc)) ;
            number_list(pn_3252_naccr_res_delay_tax_lc) := abs((abs(nvl(number_list(pn_3252_delaycollection_tax_lc),0)) +  abs(nvl(number_list(pn_3252_delaycapitalize_tax_lc),0)))  - number_list(pn_3252_accr_res_delay_tax_lc)) ;
         end if;
 --e-o-m  seval.colak 10102022
 -- muhasebe oncesi genel kontroller 
     if varchar_list(pn_3252_accrual_int_acct_no) = 0 and 
         abs(nvl(number_list(pn_3252_pdcollection_lc),0)) +
         abs(nvl(number_list(pn_3252_pdcapitalize_lc),0)) +
         abs(nvl(number_list(pn_3252_pdwriteoff_lc),0)) +
         abs(nvl(number_list(pn_3252_unduecollection_lc),0))+
         abs(nvl(number_list(pn_3252_unduewriteoff_lc),0))+
         abs(nvl(number_list(pn_3252_unduecapitalize_lc),0)) +
         abs(nvl(number_list(pn_3252_accr_int_arti_lc),0)) +
         abs(nvl(number_list(pn_3252_accr_int_eksi_lc),0)) <> 0 then 
             ls_accrual_nonaccrual_hesap_urun := 'Accrual Int' ; 
             raise  accrual_nonaccrual_hesap_yok;
     end if;
      if varchar_list(pn_3252_accrual_tax_acct_no) = 0 and 
         abs(nvl(number_list(pn_3252_pdcollection_lc),0)) +
         abs(nvl(number_list(pn_3252_pdcapitalize_lc),0)) +
         abs(nvl(number_list(pn_3252_pdwriteoff_lc),0)) +
         abs(nvl(number_list(pn_3252_unduecollection_lc),0))+
         abs(nvl(number_list(pn_3252_unduewriteoff_lc),0))+
         abs(nvl(number_list(pn_3252_unduecapitalize_lc),0)) +
         abs(nvl(number_list(pn_3252_accr_int_arti_lc),0)) +
         abs(nvl(number_list(pn_3252_accr_int_eksi_lc),0)) <> 0 then 
             ls_accrual_nonaccrual_hesap_urun := 'Accrual Tax' ; 
             raise  accrual_nonaccrual_hesap_yok;
     end if;

     if varchar_list(pn_3252_nonaccrual_int_acct_no) = 0 and 
      abs( nvl(number_list(pn_3252_nonaccr_res_int_pmt_fc),0)) +  
      abs( nvl(number_list(pn_3252_nonaccr_int_arti_lc),0)) +
      abs( nvl(number_list(pn_3252_nonaccr_int_eksi_lc),0)) <> 0  
     then 
         ls_accrual_nonaccrual_hesap_urun := 'NonAccrual Int' ; 
         raise  accrual_nonaccrual_hesap_yok;
     end if;
     
      if varchar_list(pn_3252_accrual_delay_int_acct_no) = 0 and 
      abs( nvl(number_list(pn_3252_delaycollection_lc),0)) + 
      abs( nvl(number_list(pn_3252_delaywriteoff_lc),0)) + 
      abs( nvl(number_list(pn_3252_delaycapitalize_lc),0)) + 
      abs( nvl(number_list(pn_3252_accr_delay_int_arti_lc),0)) + 
      abs( nvl(number_list(pn_3252_accr_delay_int_eksi_lc),0))  <> 0 then 
         ls_accrual_nonaccrual_hesap_urun := 'Accrual Delay' ; 
         raise  accrual_nonaccrual_hesap_yok;
     end if;

     if varchar_list(pn_3252_nonaccrual_delay_int_acct) = 0 and  
        abs( nvl(number_list(pn_3252_nonaccr_res_delay_pmt_fc),0))+
        abs( nvl(number_list(pn_3252_nonaccr_delay_int_arti_lc),0))+
        abs( nvl(number_list(pn_3252_nonaccr_delay_int_eksi_lc),0))  <> 0
     then 
         ls_accrual_nonaccrual_hesap_urun := 'NonAccrual Delay' ; 
         raise  accrual_nonaccrual_hesap_yok;
     end if;
 
 END IF;        -- seval.colak 21122022 
--e-o-m seval.colak 06102022   

       
------------------------------------------------------------------------------------------------------------------------------------      
 --seval.colak 24122021
 /*
 Principal –                   ПОГАШЕНИЕ СУММЫ КРЕДИТА (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME
Interest –                      ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME
Tax –                              НАЛОГ С ПРОДАЖ ПО ПРОЦЕНТАМ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME
Delayed interest –       ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (NUMBER OF PAST DUE DAYS, FOR EXAMPLE 1 ДЕНЬ/DAY) ИМЯ ФАМИЛИЯ/NAME SURNAME
Delayed interest tax – НАЛОГ С ПРОДАЖ НА ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) ИМЯ ФАМИЛИЯ/NAME SURNAME
Deferred interest –     ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА
Deferred tax –             НАЛОГ С ПРОДАЖ НА ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА
Penalty amount –        ПЕНИ ЗА 1 ДЕНЬ/NUMBER OF PAST DUE DAYS НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) ИМЯ ФАМИЛИЯ/NAME SURNAME
Penalty tax –                НАЛОГ С ПРОДАЖ НА ПЕНИ ЗА 1 ДЕНЬ/NUMBER OF PAST DUE DAYS НА ПРОСР. ПРОЦЕНТЫ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) ИМЯ ФАМИЛИЯ/NAME SURNAME
Deferred Delayed interest – ОТСРОЧЕННЫЕ ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ   ЛЬГОТНОГО ПЕРИОДА
*/
    
    ls_aciklama_month :=null;
    ls_musteri_Adi :=  substr(trim(upper(Pkg_Musteri.Sf_Musteri_Adi(r_hesap.musteri_No))),1,100);
    if nvl(r_hesap.tahsil_taksit_no,0) <> 0 then 
        select to_char(vade_tarih,'MM/YYYY')
        into ls_aciklama_month
        from cbs_hesap_kredi_Taksit
        where hesap_No = r_hesap.hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0);        
    end if;

        varchar_list(pn_3252_ack_principial)  := substr('ПОГАШЕНИЕ СУММЫ КРЕДИТА '||r_hesap.hesap_no ||' '||ls_aciklama_month || ' '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3252_ack_int)         := substr('ПРОЦЕНТЫ ПО КРЕДИТУ '||r_hesap.hesap_no ||' '||ls_aciklama_month || ' '||ls_musteri_Adi,1,200);
        varchar_list(pn_3252_ack_tax)         := substr('НАЛОГ С ПРОДАЖ ПО ПРОЦЕНТАМ ПО КРЕДИТУ '||r_hesap.hesap_no ||' '||ls_aciklama_month || ' '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3252_ack_delay_int)   := substr('ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ + НСП ('||r_hesap.hesap_no ||' ('|| nvl(r_hesap.faiz_gecikme_gun_sayisi,0) || ' ДН) '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3252_ack_delay_int_tax):= substr('НАЛОГ С ПРОДАЖ НА ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ '||r_hesap.hesap_no ||' '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3252_ack_defer_int)   := substr('ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ '||r_hesap.hesap_no ||ls_aciklama_month || ' '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА',1,200); 
        varchar_list(pn_3252_ack_defer_tax)   := substr('НАЛОГ С ПРОДАЖ НА ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ '||r_hesap.hesap_no ||ls_aciklama_month || ' '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА',1,200);
        varchar_list(pn_3252_ack_penalty)     := substr('ПЕНИ ЗА ('||nvl(r_hesap.ap_gecikme_gun_sayisi,0)||' ДН) '||'НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ '||r_hesap.hesap_no || ' '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3252_ack_penalty_tax) := substr('НАЛОГ С ПРОДАЖ НА ПЕНИ ЗА ('||nvl(r_hesap.ap_gecikme_gun_sayisi,0)||' ДН) '||'НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ '||r_hesap.hesap_no ||' '||ls_musteri_Adi,1,200);
        varchar_list(pn_3252_ack_defer_delay_int):= substr('ОТСРОЧЕННЫЕ ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ '||r_hesap.hesap_no ||' '||ls_aciklama_month || ' '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ   ЛЬГОТНОГО ПЕРИОДА',1,200);
        --seval.colak 24122021
    
        --b-o-m seval.colak 10012022  UNUTMAAAA alttaki degiskenlerin degerlerini ogrendikten sonra duzeltecegiz .Simdilik varchar_list(pn_3252_ack_delay_int_tax) degerini koydum.
        varchar_list(pn_3252_ack_defer_int_tax)  := varchar_list(pn_3252_ack_delay_int_tax);
        varchar_list(pn_3252_ack_defer_delay_int_tax)  := varchar_list(pn_3252_ack_delay_int_tax); 
        --e-o-m seval.colak 10012022 

------------------------------------------------------------------------------------------------------------------------------------
     ln_fis_no:=pkg_muhasebe.fis_kes(ln_islem_kod,
                                       null,
                                       pn_islem_no,
                                       varchar_list ,
                                       number_list  ,
                                       date_list    ,
                                       boolean_list ,
                                       null,
                                       false,
                                       0,
                                       null);
    
         if nvl(ln_fis_no,0 ) <> 0 then
             pkg_muhasebe.muhasebelestir(ln_fis_no);           
         end if;  
    
   -- e-o-m seval.colak 22092022 
   
       -- muhasebe sonrasi guncellemeler
    -- b-o-m seval.colak 27092022
     /*
     Birikmis faiz tutar?  “Past due int capitalize + Past due int collection + Past due int write off + Undue Int capitalize + Undue Int collection +Undue Int write off “ tutar? kadar azalt?lacak
    Birikmis gecikme faiz tutar?  “Delay int capitalize + Delay int collection + Delay int write off “ tutar? kadar azalt?lacak
    PAID Penalty amount “Penalty capitalize + Penalty collection + Penalty write off “ tutar? kadar ARRTIRMA
         */
-- 1. pd 
 
    muhasebe_sonrasi_guncelle(pn_islem_no); --seval.colak 04102022
      
        update CBS_HESAP_KREDI_ISLEM
        set         birikmis_faiz_tutari         =  nvl(birikmis_faiz_tutari,0) + nvl(ln_Fark_top_tahsil_faiz_defer_int,0) -  (  number_list(pn_3252_pdcapitalize_fc) + number_list(pn_3252_pdcollection_fc) + number_list(pn_3252_pdwriteoff_fc) + number_list(pn_3252_unduecapitalize_fc) + number_list(pn_3252_unduecollection_fc) + number_list(pn_3252_unduewriteoff_fc) ) , 
                    birikmis_faiz_tutari_round   =  round(nvl(birikmis_faiz_tutari,0),2) + nvl(ln_Fark_top_tahsil_faiz_defer_int,0) - (  number_list(pn_3252_pdcapitalize_fc) + number_list(pn_3252_pdcollection_fc) + number_list(pn_3252_pdwriteoff_fc) + number_list(pn_3252_unduecapitalize_fc) + number_list(pn_3252_unduecollection_fc) + number_list(pn_3252_unduewriteoff_fc) ), 
                    birikmis_gecikme_faiz_tutari =  nvl(birikmis_gecikme_faiz_tutari,0) +  nvl(ln_Fark_top_tahsil_delay_defer_int,0)  -  (  number_list(pn_3252_delaycapitalize_fc) + number_list(pn_3252_delaycollection_fc) + number_list(pn_3252_delaywriteoff_fc)  ) ,
                    penalty_amount               =  nvl(penalty_amount,0) + nvl(ln_Fark_top_penalty_amount,0) - number_list(pn_3252_penaltywriteoff_fc),
                    paid_penalty_amount          =  nvl(paid_penalty_amount,0) +  (  number_list(pn_3252_penaltycapitalize_fc) + number_list(pn_3252_penaltycollection_fc) ),
                    tahsiledilen_faiz_tutari     =  nvl(tahsiledilen_faiz_tutari,0)    +  (  number_list(pn_3252_pdcapitalize_fc) + number_list(pn_3252_pdcollection_fc) +  number_list(pn_3252_unduecapitalize_fc) + number_list(pn_3252_unduecollection_fc)  ) ,
                    tahsiledilen_faiz_tutari_lc  =  nvl(tahsiledilen_faiz_tutari_lc,0) +  (  number_list(pn_3252_pdcapitalize_LC) + number_list(pn_3252_pdcollection_LC) +  number_list(pn_3252_unduecapitalize_LC) + number_list(pn_3252_unduecollection_LC)  )  ,
                    tahsil_gecikme_faiz_tutari   =  nvl(tahsil_gecikme_faiz_tutari,0)  +  (  number_list(pn_3252_delaycapitalize_fc) + number_list(pn_3252_delaycollection_fc)  )                     
      where tx_no = pn_islem_no and hesap_no = ln_kredi_hesap_no ;  
      
       update CBS_HESAP_KREDI
       set         birikmis_faiz_tutari         =  nvl(birikmis_faiz_tutari,0) + nvl(ln_Fark_top_tahsil_faiz_defer_int,0) -  (  number_list(pn_3252_pdcapitalize_fc) + number_list(pn_3252_pdcollection_fc) + number_list(pn_3252_pdwriteoff_fc) + number_list(pn_3252_unduecapitalize_fc) + number_list(pn_3252_unduecollection_fc) + number_list(pn_3252_unduewriteoff_fc) ) , 
                    birikmis_faiz_tutari_round   =  round(nvl(birikmis_faiz_tutari,0),2) + nvl(ln_Fark_top_tahsil_faiz_defer_int,0) - (  number_list(pn_3252_pdcapitalize_fc) + number_list(pn_3252_pdcollection_fc) + number_list(pn_3252_pdwriteoff_fc) + number_list(pn_3252_unduecapitalize_fc) + number_list(pn_3252_unduecollection_fc) + number_list(pn_3252_unduewriteoff_fc) ), 
                    birikmis_gecikme_faiz_tutari =  nvl(birikmis_gecikme_faiz_tutari,0) +  nvl(ln_Fark_top_tahsil_delay_defer_int,0)  -  (  number_list(pn_3252_delaycapitalize_fc) + number_list(pn_3252_delaycollection_fc) + number_list(pn_3252_delaywriteoff_fc)  ) ,
                    penalty_amount               =  nvl(penalty_amount,0) + nvl(ln_Fark_top_penalty_amount,0) - number_list(pn_3252_penaltywriteoff_fc),
                    paid_penalty_amount          =  nvl(paid_penalty_amount,0) +  (  number_list(pn_3252_penaltycapitalize_fc) + number_list(pn_3252_penaltycollection_fc) ),
                    tahsiledilen_faiz_tutari     =  nvl(tahsiledilen_faiz_tutari,0)    +  (  number_list(pn_3252_pdcapitalize_fc) + number_list(pn_3252_pdcollection_fc) +  number_list(pn_3252_unduecapitalize_fc) + number_list(pn_3252_unduecollection_fc)  ) ,
                    tahsiledilen_faiz_tutari_lc  =  nvl(tahsiledilen_faiz_tutari_lc,0) +  (  number_list(pn_3252_pdcapitalize_LC) + number_list(pn_3252_pdcollection_LC) +  number_list(pn_3252_unduecapitalize_LC) + number_list(pn_3252_unduecollection_LC)  )  ,
                    tahsil_gecikme_faiz_tutari   =  nvl(tahsil_gecikme_faiz_tutari,0)  +  (  number_list(pn_3252_delaycapitalize_fc) + number_list(pn_3252_delaycollection_fc)  )                     
      where hesap_no = ln_kredi_hesap_no ;  
                    
 
 Exception
 when iliskili_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6828' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when faiz_tahakkuk_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6826' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when vergi_tahakkuk_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6827' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when iliskili_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '700' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter || r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||   r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  --when iliskili_faizrees_dk_yok then
  --  raise_application_error(-20100,pkg_hata.getucpointer || '701' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when iliskili_kom_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '702' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 -- when iliskili_komrees_dk_yok then
  --  raise_application_error(-20100,pkg_hata.getucpointer || '703' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when deferred_interest_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6851' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 when accrual_nonaccrual_hesap_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6879' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 when others then
    raise_application_error(-20100,pkg_hata.getucpointer || '6862' || pkg_hata.getdelimiter || to_char(sqlerrm) || pkg_hata.getdelimiter || pkg_hata.getucpointer);  
 End;
 -------------------------------------------------------------------------------

BEGIN
    pn_3252_musteri_aciklama    := Pkg_Muhasebe.parametre_index_bul('3252_MUSTERI_ACIKLAMA');
    pn_3252_referans    := Pkg_Muhasebe.parametre_index_bul('3252_REFERANS');
    pn_3252_fis_aciklama    := Pkg_Muhasebe.parametre_index_bul('3252_FIS_ACIKLAMA');
    pn_3252_kur    := Pkg_Muhasebe.parametre_index_bul('3252_KUR');
    pn_3252_banka_aciklama    := Pkg_Muhasebe.parametre_index_bul('3252_BANKA_ACIKLAMA');
    pn_3252_kredi_doviz    := Pkg_Muhasebe.parametre_index_bul('3252_KREDI_DOVIZ');
    pn_3252_islem_sube    := Pkg_Muhasebe.parametre_index_bul('3252_ISLEM_SUBE');
    pn_3252_kredi_tl    := Pkg_Muhasebe.parametre_index_bul('3252_KREDI_TL');
    pn_3252_kredi_yp    := Pkg_Muhasebe.parametre_index_bul('3252_KREDI_YP');
    pn_3252_iliskili_faiz_dk    := Pkg_Muhasebe.parametre_index_bul('3252_ILISKILI_FAIZ_DK');
    pn_3252_kredi_hesap_no    := Pkg_Muhasebe.parametre_index_bul('3252_KREDI_HESAP_NO');
    pn_3252_kredi_hesap_sube    := Pkg_Muhasebe.parametre_index_bul('3252_KREDI_HESAP_SUBE');
    pn_3252_tax_aciklama    := Pkg_Muhasebe.parametre_index_bul('3252_TAX_ACIKLAMA');
    pn_3252_iliskili_hesap_sube    := Pkg_Muhasebe.parametre_index_bul('3252_ILISKILI_HESAP_SUBE');
    pn_3252_iliskili_hesap_no    := Pkg_Muhasebe.parametre_index_bul('3252_ILISKILI_HESAP_NO');
    pn_3252_iliskili_hesap_doviz    := Pkg_Muhasebe.parametre_index_bul('3252_ILISKILI_HESAP_DOVIZ');
    pn_3252_deferred_interest    := Pkg_Muhasebe.parametre_index_bul('3252_DEFERRED_INTEREST');
    pn_3252_deferred_interest_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DEFERRED_INTEREST_LC');
    pn_3252_deferred_tax    := Pkg_Muhasebe.parametre_index_bul('3252_DEFERRED_TAX');
    pn_3252_deferred_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DEFERRED_TAX_LC');
    pn_3252_accrual_gecikme_faiz    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_GECIKME_FAIZ');
    pn_3252_accrual_gecikme_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_GECIKME_FAIZ_LC');
    pn_3252_gecikme_faiz_gl    := Pkg_Muhasebe.parametre_index_bul('3252_GECIKME_FAIZ_GL');
    pn_3252_accrual_gecikme_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_GECIKME_TAX');
    pn_3252_accrual_gecikme_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_GECIKME_TAX_LC');
    pn_3252_penalty_amount    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTY_AMOUNT');
    pn_3252_penalty_amount_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTY_AMOUNT_LC');
    pn_3252_penalty_tax    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTY_TAX');
    pn_3252_penalty_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTY_TAX_LC');
    pn_3252_anapara    := Pkg_Muhasebe.parametre_index_bul('3252_ANAPARA');
    pn_3252_anapara_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ANAPARA_LC');
    pn_3252_toplam_faiz    := Pkg_Muhasebe.parametre_index_bul('3252_TOPLAM_FAIZ');
    pn_3252_toplam_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3252_TOPLAM_FAIZ_LC');
    pn_3252_toplam_vergi    := Pkg_Muhasebe.parametre_index_bul('3252_TOPLAM_VERGI');
    pn_3252_toplam_vergi_lc    := Pkg_Muhasebe.parametre_index_bul('3252_TOPLAM_VERGI_LC');
    pn_3252_penalty_toplam    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTY_TOPLAM');
    pn_3252_penalty_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTY_TOPLAM_LC');
    pn_3252_deferred_toplam    := Pkg_Muhasebe.parametre_index_bul('3252_DEFERRED_TOPLAM');
    pn_3252_deferred_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DEFERRED_TOPLAM_LC');
    pn_3252_gecikme_faiz_toplam    := Pkg_Muhasebe.parametre_index_bul('3252_GECIKME_FAIZ_TOPLAM');
    pn_3252_gecikme_faiz_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3252_GECIKME_FAIZ_TOPLAM_LC');
    pn_3252_accrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_INT_ACCT_NO');
    pn_3252_accrual_tax_acct_no    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_TAX_ACCT_NO');
    pn_3252_accrual_delay_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_DELAY_INT_ACCT_NO');
    pn_3252_nonaccrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_INT_ACCT_NO');
    pn_3252_nonaccrual_delay_int_acct    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_DELAY_INT_ACCT');
    pn_3252_accrual_tahsil_faiz    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_TAHSIL_FAIZ');
    pn_3252_nonaccrual_tahsil_faiz    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_TAHSIL_FAIZ');
    pn_3252_accrual_tahsil_vergi    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_TAHSIL_VERGI');
    pn_3252_nonaccrual_tahsil_vergi    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_TAHSIL_VERGI');
    pn_3252_accrual_tahsil_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_TAHSIL_FAIZ_LC');
    pn_3252_nonaccrual_tahsil_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_TAHSIL_FAIZ_LC');
    pn_3252_accrual_tahsil_vergi_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCRUAL_TAHSIL_VERGI_LC');
    pn_3252_nonaccrual_tahsil_vergi_l    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_TAHSIL_VERGI_L');
    pn_3252_defer_pen_toplam    := Pkg_Muhasebe.parametre_index_bul('3252_DEFER_PEN_TOPLAM');
    pn_3252_defer_pen_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DEFER_PEN_TOPLAM_LC');
    pn_3252_defer_pen_tax    := Pkg_Muhasebe.parametre_index_bul('3252_DEFER_PEN_TAX');
    pn_3252_defer_pen_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DEFER_PEN_TAX_LC');
    pn_3252_defer_penalty    := Pkg_Muhasebe.parametre_index_bul('3252_DEFER_PENALTY');
    pn_3252_defer_penalty_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DEFER_PENALTY_LC');
    pn_3252_nonaccrual_gecikme_faiz    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_GECIKME_FAIZ');
    pn_3252_nonaccrual_gecikme_faiz_l    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_GECIKME_FAIZ_L');
    pn_3252_nonaccrual_gecikme_tax    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_GECIKME_TAX');
    pn_3252_nonaccrual_gecikme_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCRUAL_GECIKME_TAX_LC');
    pn_3252_accr_defer_int    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEFER_INT');
    pn_3252_accr_defer_int_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEFER_INT_LC');
    pn_3252_nonaccr_defer_int    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEFER_INT');
    pn_3252_nonaccr_defer_int_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEFER_INT_LC');
    pn_3252_accr_defer_del_int    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEFER_DEL_INT');
    pn_3252_accr_defer_del_int_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEFER_DEL_INT_LC');
    pn_3252_nonaccr_defer_del_int    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEFER_DEL_INT');
    pn_3252_nonaccr_defer_del_int_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEFER_DEL_INT_LC');
    pn_3252_ack_principial    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_PRINCIPIAL');
    pn_3252_ack_int    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_INT');
    pn_3252_ack_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_TAX');
    pn_3252_ack_delay_int    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_DELAY_INT');
    pn_3252_ack_delay_int_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_DELAY_INT_TAX');
    pn_3252_ack_defer_int    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_DEFER_INT');
    pn_3252_ack_defer_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_DEFER_TAX');
    pn_3252_ack_penalty    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_PENALTY');
    pn_3252_ack_penalty_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_PENALTY_TAX');
    pn_3252_ack_defer_delay_int    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_DEFER_DELAY_INT');
    pn_3252_nonaccr_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEFER_INT_TAX');
    pn_3252_nonaccr_defer_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEFER_INT_TAX_LC');
    pn_3252_nonaccr_def_del_int_tax    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEF_DEL_INT_TAX');
    pn_3252_nonaccr_def_del_int_tax_l    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DEF_DEL_INT_TAX_L');
    pn_3252_ack_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_DEFER_INT_TAX');
    pn_3252_ack_defer_delay_int_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACK_DEFER_DELAY_INT_TAX');
    pn_3252_accr_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEFER_INT_TAX');
    pn_3252_accr_defer_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEFER_INT_TAX_LC');
    pn_3252_accr_def_del_int_tax    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEF_DEL_INT_TAX');
    pn_3252_accr_def_del_int_tax_l    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DEF_DEL_INT_TAX_L');
    pn_3252_pdint_total_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDINT_TOTAL_FC');
    pn_3252_pdint_total_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDINT_TOTAL_LC');
    pn_3252_pdcapitalize_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCAPITALIZE_FC');
    pn_3252_pdcapitalize_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCAPITALIZE_LC');
    pn_3252_pdcollection_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCOLLECTION_FC');
    pn_3252_pdcollection_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCOLLECTION_LC');
    pn_3252_pdwriteoff_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDWRITEOFF_FC');
    pn_3252_pdwriteoff_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDWRITEOFF_LC');
    pn_3252_undueint_total_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEINT_TOTAL_FC');
    pn_3252_undueint_total_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEINT_TOTAL_LC');
    pn_3252_unduecapitalize_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECAPITALIZE_FC');
    pn_3252_unduecapitalize_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECAPITALIZE_LC');
    pn_3252_unduecollection_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECOLLECTION_FC');
    pn_3252_unduecollection_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECOLLECTION_LC');
    pn_3252_unduewriteoff_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEWRITEOFF_FC');
    pn_3252_unduewriteoff_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEWRITEOFF_LC');
    pn_3252_delayint_total_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYINT_TOTAL_FC');
    pn_3252_delayint_total_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYINT_TOTAL_LC');
    pn_3252_delaycapitalize_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCAPITALIZE_FC');
    pn_3252_delaycapitalize_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCAPITALIZE_LC');
    pn_3252_delaycollection_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCOLLECTION_FC');
    pn_3252_delaycollection_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCOLLECTION_LC');
    pn_3252_delaywriteoff_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYWRITEOFF_FC');
    pn_3252_delaywriteoff_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYWRITEOFF_LC');
    pn_3252_penaltyint_total_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYINT_TOTAL_FC');
    pn_3252_penaltyint_total_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYINT_TOTAL_LC');
    pn_3252_penaltycapitalize_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCAPITALIZE_FC');
    pn_3252_penaltycapitalize_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCAPITALIZE_LC');
    pn_3252_penaltycollection_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCOLLECTION_FC');
    pn_3252_penaltycollection_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCOLLECTION_LC');
    pn_3252_pdint_total_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDINT_TOTAL_TAX_FC');
    pn_3252_pdcapitalize_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCAPITALIZE_TAX_FC');
    pn_3252_pdcollection_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCOLLECTION_TAX_FC');
    pn_3252_delayint_total_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYINT_TOTAL_TAX_FC');
    pn_3252_delaycapitalize_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCAPITALIZE_TAX_FC');
    pn_3252_delaycollection_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCOLLECTION_TAX_FC');
    pn_3252_penaltyint_total_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYINT_TOTAL_TAX_FC');
    pn_3252_penaltycapitalize_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCAPITALIZE_TAX_FC');
    pn_3252_penaltycollection_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCOLLECTION_TAX_FC');
    pn_3252_undueint_total_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEINT_TOTAL_TAX_FC');
    pn_3252_unduecapitalize_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECAPITALIZE_TAX_FC');
    pn_3252_unduecollection_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECOLLECTION_TAX_FC');
    pn_3252_pdint_total_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDINT_TOTAL_TAX_LC');
    pn_3252_pdcapitalize_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCAPITALIZE_TAX_LC');
    pn_3252_pdcollection_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDCOLLECTION_TAX_LC');
    pn_3252_delayint_total_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYINT_TOTAL_TAX_LC');
    pn_3252_delaycapitalize_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCAPITALIZE_TAX_LC');
    pn_3252_delaycollection_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYCOLLECTION_TAX_LC');
    pn_3252_penaltyint_total_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYINT_TOTAL_TAX_LC');
    pn_3252_penaltycapitalize_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCAPITALIZE_TAX_LC');
    pn_3252_penaltycollection_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYCOLLECTION_TAX_LC');
    pn_3252_undueint_total_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEINT_TOTAL_TAX_LC');
    pn_3252_unduecapitalize_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECAPITALIZE_TAX_LC');
    pn_3252_unduecollection_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUECOLLECTION_TAX_LC');
    pn_3252_addition_disbursement_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ADDITION_DISBURSEMENT_LC');
    pn_3252_addition_disbursement_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ADDITION_DISBURSEMENT_FC');
    pn_3252_pddeferred_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDDEFERRED_FC');
    pn_3252_pddeferred_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDDEFERRED_LC');
    pn_3252_delaydeferred_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYDEFERRED_FC');
    pn_3252_delaydeferred_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYDEFERRED_LC');
    pn_3252_penaltydeferred_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYDEFERRED_FC');
    pn_3252_penaltydeferred_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYDEFERRED_LC');
    pn_3252_pddeferred_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDDEFERRED_TAX_FC');
    pn_3252_delaydeferred_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYDEFERRED_TAX_FC');
    pn_3252_penaltydeferred_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYDEFERRED_TAX_FC');
    pn_3252_unduedeferred_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEDEFERRED_TAX_FC');
    pn_3252_unduedeferred_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEDEFERRED_FC');
    pn_3252_unduedeferred_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEDEFERRED_LC');
    pn_3252_pddeferred_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDDEFERRED_TAX_LC');
    pn_3252_delaydeferred_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYDEFERRED_TAX_LC');
    pn_3252_penaltydeferred_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYDEFERRED_TAX_LC');
    pn_3252_unduedeferred_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEDEFERRED_TAX_LC');
    pn_3252_penaltywriteoff_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYWRITEOFF_FC');
    pn_3252_penaltywriteoff_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYWRITEOFF_LC');
    pn_3252_pdwriteoff_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PDWRITEOFF_TAX_FC');
    pn_3252_delaywriteoff_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYWRITEOFF_TAX_FC');
    pn_3252_penaltywriteoff_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYWRITEOFF_TAX_FC');
    pn_3252_unduewriteoff_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEWRITEOFF_TAX_FC');
    pn_3252_pdwriteoff_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PDWRITEOFF_TAX_LC');
    pn_3252_delaywriteoff_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_DELAYWRITEOFF_TAX_LC');
    pn_3252_penaltywriteoff_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTYWRITEOFF_TAX_LC');
    pn_3252_unduewriteoff_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_UNDUEWRITEOFF_TAX_LC');
    pn_3252_llp_var    := Pkg_Muhasebe.parametre_index_bul('3252_LLP_VAR');
    pn_3252_llp_yok    := Pkg_Muhasebe.parametre_index_bul('3252_LLP_YOK');
    pn_3252_accr_delay_int_eksi_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_EKSI_LC');
    pn_3252_accr_delay_int_eksi_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_EKSI_FC');
    pn_3252_accr_delay_int_eksi_tx_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_EKSI_TX_LC');
    pn_3252_accr_delay_int_eksi_tx_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_EKSI_TX_FC');
    pn_3252_nonaccr_delay_int_eksi_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DELAY_INT_EKSI_LC');
    pn_3252_nonaccr_delay_int_eksi_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DELAY_INT_EKSI_FC');
    pn_3252_accr_delay_int_arti_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_ARTI_LC');
    pn_3252_accr_delay_int_arti_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_ARTI_FC');
    pn_3252_accr_delay_int_arti_tx_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_ARTI_TX_LC');
    pn_3252_accr_delay_int_arti_tx_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_DELAY_INT_ARTI_TX_FC');
    pn_3252_nonaccr_delay_int_arti_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DELAY_INT_ARTI_LC');
    pn_3252_nonaccr_delay_int_arti_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_DELAY_INT_ARTI_FC');
    pn_3252_accr_int_eksi_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_EKSI_LC');
    pn_3252_accr_int_eksi_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_EKSI_FC');
    pn_3252_accr_int_eksi_tx_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_EKSI_TX_LC');
    pn_3252_accr_int_eksi_tx_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_EKSI_TX_FC');
    pn_3252_nonaccr_int_eksi_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_INT_EKSI_LC');
    pn_3252_nonaccr_int_eksi_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_INT_EKSI_FC');
    pn_3252_accr_int_arti_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_ARTI_LC');
    pn_3252_accr_int_arti_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_ARTI_FC');
    pn_3252_accr_int_arti_tx_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_ARTI_TX_LC');
    pn_3252_accr_int_arti_tx_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_INT_ARTI_TX_FC');
    pn_3252_nonaccr_int_arti_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_INT_ARTI_LC');
    pn_3252_nonaccr_int_arti_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_INT_ARTI_FC');
    pn_3252_accr_res_int_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_PMT_LC');
    pn_3252_accr_res_int_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_PMT_FC');
    pn_3252_nonaccr_res_int_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_RES_INT_PMT_LC');
    pn_3252_nonaccr_res_int_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_RES_INT_PMT_FC');
    pn_3252_accr_res_delay_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DELAY_PMT_LC');
    pn_3252_accr_res_delay_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DELAY_PMT_FC');
    pn_3252_nonaccr_res_delay_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_RES_DELAY_PMT_LC');
    pn_3252_nonaccr_res_delay_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NONACCR_RES_DELAY_PMT_FC');
    pn_3252_accr_res_int_woff_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_WOFF_PMT_LC');
    pn_3252_accr_res_int_woff_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_WOFF_PMT_FC');
    pn_3252_naccr_res_int_woff_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_INT_WOFF_PMT_LC');
    pn_3252_naccr_res_int_woff_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_INT_WOFF_PMT_FC');
    pn_3252_accr_res_del_woff_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DEL_WOFF_PMT_LC');
    pn_3252_accr_res_del_woff_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DEL_WOFF_PMT_FC');
    pn_3252_naccr_res_del_woff_pmt_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_DEL_WOFF_PMT_LC');
    pn_3252_naccr_res_del_woff_pmt_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_DEL_WOFF_PMT_FC');
    pn_3252_accr_res_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_TAX_LC');
    pn_3252_accr_res_int_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_TAX_FC');
    pn_3252_accr_res_delay_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DELAY_TAX_LC');
    pn_3252_accr_res_delay_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DELAY_TAX_FC');
    pn_3252_accr_res_int_woff_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_WOFF_TAX_LC');
    pn_3252_accr_res_int_woff_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_INT_WOFF_TAX_FC');
    pn_3252_accr_res_del_woff_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DEL_WOFF_TAX_LC');
    pn_3252_accr_res_del_woff_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_ACCR_RES_DEL_WOFF_TAX_FC');
    pn_3252_naccr_res_int_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_INT_TAX_FC');
    pn_3252_naccr_res_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_INT_TAX_LC');
    pn_3252_naccr_res_delay_tax_fc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_DELAY_TAX_FC');
    pn_3252_naccr_res_delay_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3252_NACCR_RES_DELAY_TAX_LC');
    pn_3252_penalty_gl    := Pkg_Muhasebe.parametre_index_bul('3252_PENALTY_GL');   --seval.colak 01112022
END ;
/

