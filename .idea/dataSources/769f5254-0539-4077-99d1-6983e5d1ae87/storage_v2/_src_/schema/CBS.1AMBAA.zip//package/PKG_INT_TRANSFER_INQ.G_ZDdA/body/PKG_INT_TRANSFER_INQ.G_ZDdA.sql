create PACKAGE BODY     PKG_INT_TRANSFER_INQ IS

FUNCTION GetDateByChannelCode(ps_channel_code varchar2,
                              pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

     open pc_ref for 
       select pkg_muhasebe.banka_tarihi_bul() as r_date from dual;
       
     return ls_returncode;   
      
EXCEPTION 
    when others then
          raise;          
END;

FUNCTION GetNextBusinessDate(ps_channel_code varchar2,
                             pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for 
       select Pkg_Tarih.ileri_is_gunu() as r_date from dual;
       
     return ls_returncode;   
      
EXCEPTION 
    when others then
          raise;          
END;

FUNCTION GetPreviousBusinessDate(ps_channel_code varchar2,
                                 pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for 
       select Pkg_Tarih.geri_is_gunu() as r_date from dual;
       
     return ls_returncode;   
      
EXCEPTION 
    when others then
          raise;          
END;


FUNCTION GetPaymentDestCode(ps_lang varchar2,
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select stat_code as code, 
               case 
                   when ps_lang = 'en' then
                       code_name
                   else
                       code_name_rus
               end as name
           from cbs_swift_codes_uae_cib where stat_code is not null;
      
     return ls_returncode;   
      
EXCEPTION 
    when others then
          raise;          
END;
FUNCTION GetPurposeCodes(ps_lang varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select kod as code, 
           pkg_int_translation_inq.gettranslate(ps_lang, kod, label_type) as name from cbs.cbs_purpose_code;
     
    return ls_returncode;  
      
EXCEPTION 
    when others then
           raise;                   
END; 
FUNCTION GetPaymentCodes(ps_lang varchar2,
                         ps_customer_type varchar2,
                         ps_transfer_type varchar2, 
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType) RETURN varchar2 
IS
ls_channel_code varchar2(50);
ls_returncode varchar2(3) := '000';
BEGIN
    
    select decode(ps_customer_type, 'corporate', 'cDKBCIB', 'cDKBRIB') into ls_channel_code from dual;
    

    if ps_transfer_type='swift' then
         open pc_ref for
            select id as code, 
                  'swift' as name from cbs_payment_code_group 
                        where parent_group_id is null 
                              and status_cd = 'sENAB' 
                              and tran_code = 'SWIFT';
                        
         open pc_ref2 for
            select id as code, 
                   'swift' as name, 
                   parent_group_id as parent_id from cbs_payment_code_group 
                        where parent_group_id is not null 
                              and status_cd = 'sENAB' 
                              and tran_code = 'SWIFT';
                        
         open pc_ref3 for
            select istatistik_kodu as code,  
                        case 
                          when ps_lang = 'en' then
                             aciklama2
                          else
                             aciklama
                        end as name,
                        (select id from cbs_payment_code_group 
                           where parent_group_id is not null 
                              and status_cd = 'sENAB' 
                              and tran_code = 'SWIFT') as parent_id
                             from cbs_istatistik_kodlari;                           
              
    else
         open pc_ref for
             select id as code, 
                case 
                   when ps_lang = 'en' then
                       description_eng
                   else
                       description_rus
                 end as name
                  from cbs_payment_code_group 
                     where parent_group_id is null 
                           and description_eng is not null 
                           and description_rus is not null 
                           and status_cd = 'sENAB' 
                           and tran_code = upper(ps_transfer_type)
                           and channel_code = ls_channel_code;
                         
                         
       open pc_ref2 for
            select id as code, 
            case 
               when ps_lang = 'en' then
                   description_eng
               else
                   description_rus
            end as name,
            parent_group_id as parent_id
              from cbs_payment_code_group 
                  where parent_group_id is not null 
                        and description_eng is not null 
                        and description_rus is not null 
                        and status_cd = 'sENAB' 
                        and tran_code = upper(ps_transfer_type) 
                        and channel_code = ls_channel_code;  
                     
       open pc_ref3 for                
                 select kod as code, 
                 case 
                   when ps_lang = 'en' then
                       aciklama_ing
                   else
                       aciklama_rus
                 end as name,
                 id as parent_id
                   from cbs_payment_code inner join 
                          cbs_payment_code_group on  children like '%' || kod || '%'
                          where parent_group_id is not null 
                                and description_eng is not null 
                                and description_rus is not null 
                                and status_cd = 'sENAB' 
                                and tran_code = upper(ps_transfer_type)
                                and channel_code = ls_channel_code;      
                               
    end if;

     return ls_returncode;
     
EXCEPTION 
    when others then
           raise;          
END; 
FUNCTION GetClearingBicCodes(ps_lang varchar2, 
                             pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref 
        for
            select banka_kodu as code, case
                when ps_lang = 'en' then pkg_musteri.gettranslit(banka_adi)
                when ps_lang = 'ru' then banka_adi
                else banka_adi
            end   as name from cbs_banka_kodlari order by banka_kodu;
        
    return ls_returncode;

EXCEPTION 
    when others then
           RAISE;          
END;
FUNCTION GetSwiftCountries(ps_lang varchar2, 
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000'; 
BEGIN

    open pc_ref for
        select  distinct bic.bic_ulke_kodu as code,
                bic.country_name as name 
                from cbs_bic_kodlari bic 
                   left join cbs_ulke_kodlari ulke on ulke.ulke_kodu=bic.bic_ulke_kodu
                       where country_name is not null
                           and bic_ulke_kodu not in (select ulke_kodu from cbs_ulke_kodlari where ib_restricted = 'Y')
                           and bic_ulke_kodu not in (select country_code from cbs_swift_bank_restrictions where country_block_flag = 'Y')
                           order by bic_ulke_kodu;
                       
    return ls_returncode;

EXCEPTION 
    when others then
           raise;          
END;
FUNCTION GetSwiftBicCodes(ps_lang varchar2, 
                           ps_country_code varchar2, 
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_count number := 0;
ls_returncode varchar2(3):='000'; 
nobankfound exception;
BEGIN
      select count(*)
                into ln_count
                from cbs_bic_kodlari
                        where bic_ulke_kodu = upper(ps_country_code)
                              and length(ulke_adi) > 0
                              and substr(bic_kodu, 8, 1) <> '1'
                              and bic_sube_kodu = 'XXX';

        if ln_count = 0 then
           raise nobankfound;
        end if;

        if (upper(ps_country_code) <> 'TR') then
            open pc_ref for
               select bic_kodu as code, banka_adi as name
                   from cbs_bic_kodlari
                          where bic_ulke_kodu = upper(ps_country_code)
                                and length(ulke_adi) > 0
                                and bic_sube_kodu = 'XXX'
                                and substr(bic_kodu, 8, 1) <> '1'
                                order by bic_kodu;
        else
            open pc_ref for
                 select bic_kodu as code, banka_adi as name
                     from cbs_bic_kodlari
                        where bic_ulke_kodu = upper(ps_country_code)
                                and length(ulke_adi) > 0
                                and bic_sube_kodu = 'XXX'
                                and substr(bic_kodu, 8, 1) <> '1'
                                and bic_kodu not in ('HSBYTRISXXX', 'ISISTRISXXX', 'LBMDTRISXXX', 'MSMDTRISXXX', 'PMKATRISXXX', 'TCMBTR2AXXX', 'TVSBTRISXXX')
                                order by bic_kodu;
        end if;

    return ls_returncode;
    
EXCEPTION    
    when nobankfound then
          return '454';  
    when others then
            raise;          
END;
FUNCTION GetBankInfoBySwiftCode(ps_swift_code varchar2, 
                                pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_count number;
ls_swift_code varchar2(15);
ls_returncode varchar2(3) := '000'; 
swift_code_not_found exception;
BEGIN

  
   if length(ps_swift_code) = 11 then
        ls_swift_code := substr(ps_swift_code, 1 , length(ps_swift_code) - 3) || 'XXX';
   else
        ls_swift_code := ps_swift_code || 'XXX';
   end if;
 
        
   select count(*)
            into ln_count
                from cbs_bic_kodlari
                        where bic_kodu = ls_swift_code;
--                        and substr(bic_kodu,1,4) in (select substr(sbkekd,1,4) from swtbkepf);
                        
   if ln_count = 0 then
        raise swift_code_not_found;
   end if;
        
  open pc_ref for
     select  distinct bic.bic_kodu as swift_code,
            bic.bic_ulke_kodu as country_code,
             bic.bic_sehir_kodu as city_code,
            bic.sehir_adi as city_name,
            bic.ulke_adi as country_name,
            bic.bic_banka_kodu as bank_code,
            bic.banka_adi as bank_name
                from cbs_bic_kodlari bic 
                   left join cbs_ulke_kodlari ulke on ulke.ulke_kodu = bic.bic_ulke_kodu
                       where bic.bic_kodu = ls_swift_code
                           and country_name is not null
                           and bic_ulke_kodu not in (select ulke_kodu from cbs_ulke_kodlari where ib_restricted = 'Y')
                           and bic_ulke_kodu not in (select country_code from cbs_swift_bank_restrictions where country_block_flag = 'Y')
                           and bic_sube_kodu = 'XXX'
                           and substr(bic_kodu, 8, 1) <> '1'
                           order by bic_ulke_kodu;

   
  return ls_returncode;

EXCEPTION    
    when swift_code_not_found then
          return '454';
    when no_data_found then
          return '454';
    when others then
          raise;          
END;
FUNCTION GetTransferIsFirst(ps_source_iban varchar2, 
                            ps_target_iban varchar2, 
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_count number;
ls_returncode varchar2(3) := '452';
BEGIN

    select count(*) into ln_count from 
       (select v.alacak_external_hesap as account_no
             from cbs_islem i join cbs_virman_islem v on i.numara = v.tx_no 
                  where i.durum='P' 
                        and v.borc_external_hesap = ps_source_iban
                        and v.alacak_external_hesap = ps_target_iban
                        and i.kayit_sistem_tarihi >= add_months(sysdate, -3)
         union
         select c.to_account_external_number as account_no
               from cbs_islem i join cbs_clearing c on i.numara = c.yaratan_tx_no 
                    where i.durum='P'
                         and c.from_account_external_number = ps_source_iban
                         and c.to_account_external_number = ps_target_iban
                         and i.kayit_sistem_tarihi >= add_months(sysdate, -3) 
        union
         select s.bc_hesap_no_n as account_no
               from cbs_islem i join cbs_yphavale_giden_acilis s on i.numara = s.tx_no 
                    where i.durum='P'
                         and s.oc_hesap_no_k = ps_source_iban
                         and s.bc_hesap_no_n = ps_target_iban
                         and i.kayit_sistem_tarihi >= add_months(sysdate, -3) 
        union
         --kart odemesi
         select c.pseudopan as account_no
               from cbs_islem i join cbs_int_card_finansal_islem c on i.numara = c.tx_no 
                    where i.durum='P'
                         and c.from_account_number = pkg_int_account_inq.getaccountnumberbyiban(ps_source_iban)
                         and c.pseudopan = ps_target_iban
                         and i.kayit_sistem_tarihi >= add_months(sysdate, -3)) a;      
                         
     if ln_count = 0 then
       ls_returncode := '000';
     end if;    
     
     return ls_returncode; 
                    
EXCEPTION     
    when others then
          raise;                      
END;
FUNCTION GetIbanToAccount(ps_lang varchar2,  
                          ps_iban varchar2,
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000'; 
BEGIN

   open pc_ref for
      select pkg_int_customer_inq.getcustomermaskedname(ps_lang, customer.musteri_no) as masked_name,
       account.hesap_no as account_number,
       case
            when account.urun_tur_kod = 'L/G' and account.modul_tur_kod= 'LOAN' then 'Guarantee' 
            when account.urun_tur_kod != 'LEASING' and account.modul_tur_kod= 'LOAN' and pkg_genel.urun_sinif_nakdimi('LOAN', account.urun_tur_kod, account.urun_sinif_kod) ='E' then 'Cash Credits'
            when account.modul_tur_kod= 'TIME DEP.' then pkg_int.getaccounttypename(account.modul_tur_kod)
            when account.modul_tur_kod= 'CURRENT' and account.urun_tur_kod in ('CURRENT','DEMAND DEP','COLLETERAL') then pkg_int.getaccounttypename(account.modul_tur_kod)
       else 'NULL'
       end account_name, 
       doviz_kodu as currency_code, 
       address.ulke_kod as country_code,
       pkg_genel.ulke_adi_al(address.ulke_kod) as country_name,
       account.durum_kodu as status,
       account.sube_kodu as branch_code,
       Pkg_Genel.bolum_adi_al(account.sube_kodu) as branch_name
       from cbs_musteri customer
           inner join cbs_hesap account on customer.musteri_no = account.musteri_no 
           inner join cbs_musteri_adres address on address.musteri_no = account.musteri_no
               where external_hesap_no = ps_iban; 
    
    return ls_returncode;

EXCEPTION     
    when others then
            raise;          
END;

FUNCTION GetAccountToIban(ps_lang varchar2, 
                          ps_account_number varchar2, 
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000'; 
BEGIN

    open pc_ref 
        for
          select pkg_int_customer_inq.getcustomermaskedname(ps_lang, musteri_no) as masked_name,
            external_hesap_no as iban 
            from cbs_hesap  
            where hesap_no = to_number(ps_account_number);
        
        return ls_returncode;

EXCEPTION     
    when others then
           raise;          
END;

FUNCTION GetRecentTransfers(ps_lang varchar2, 
                            ps_customer_id varchar2,
                            ps_transfer_type varchar2,
                            pn_page_index number,
                            pn_page_size number, 
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_number number;
ln_customer_number_second number;
ls_returncode varchar2(3) := '000'; 
le_customer_not_found exception;
BEGIN

  ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
  
  if ln_customer_number is null then
    raise le_customer_not_found;
  end if;
  
  ln_customer_number_second := pkg_int_customer_inq.GetCustomerNoForTheSecondType(ps_customer_id);
  
  if ps_transfer_type='swift' then
  
    open pc_ref 
        for
           select transactions.numara as transaction_number,
                   'swift' as transfer_type,
                   transactions.kayit_sistem_tarihi as transaction_date, 
                   transactions.tutar as amount, 
                   transfer.transfer_doviz_kodu as currency_code, 
                   transfer.oc_hesap_no_k as source_account_iban,
                   transfer.bc_hesap_no_n as target_account_iban, 
                   transfer.bc_isim_adres_1 as target_name,
                   transfer.awi_bic as target_bic_code,
                   transfer.ulke_kodu as target_country_code,
                   bank.bic_sehir_kodu as target_bank_city_code, 
                   bank.bic_sube_kodu as target_bank_branch_code,
                   transfer.istatistik_kodu as payment_code,
                   replace(replace(transfer.rr_1, '/BENEFRES/AE//', ''), '/', '') as payment_destination_code,
                   transfer.aciklama as description
                 from cbs_islem transactions
                     join cbs_yphavale_giden_acilis transfer on transactions.numara = transfer.tx_no
                     inner join cbs_bic_kodlari bank on bank.bic_kodu = transfer.awi_bic
                        where transactions.islem_kod = 4003
                              and transactions.musteri_numara in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                              and transactions.durum = 'P'
                              and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                              order by transactions.numara desc 
                              offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
                
  elsif ps_transfer_type='clearing' then
  
    open pc_ref 
        for
            select transactions.numara as transaction_number,
                   'clearing' as transfer_type,
                   transactions.kayit_sistem_tarihi as transaction_date, 
                    transactions.tutar as amount, 
                   'KGS' as currency_code, 
                   transfer.from_account_external_number as source_account_iban,
                   transfer.to_account_external_number as target_account_iban, 
                   transfer.to_name as target_name,
                   transfer.to_bank_bic as target_bic_code,
                   null as target_country_code,
                   region.no as target_bank_city_code, 
                   null as target_bank_branch_code,
                   transfer.code_of_payment as payment_code,
                   null as payment_destination_code,
                   transfer.explanation as description
                 from cbs_islem transactions
                     join cbs_clearing transfer on transactions.numara = transfer.yaratan_tx_no
                     inner join cbs_banka_kodlari bank on  bank.banka_kodu = to_number(transfer.to_bank_bic)
                     inner join cbs_kg_regions region on region.no = bank.region_no
                        where transactions.islem_kod = 3555
                              and transactions.musteri_numara in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                              and transactions.durum = 'P'
                              and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                              order by transactions.numara desc 
                              offset ((pn_page_index-1) * pn_page_size)  rows fetch next pn_page_size rows only;

  elsif ps_transfer_type='b2ob' then
  
    open pc_ref 
        for
            select transactions.numara as transaction_number,
                'b2ob' as transfer_type,
                transactions.kayit_sistem_tarihi as transaction_date,
                transactions.tutar as amount, 
                transfer.doviz_kodu as currency_code, 
                transfer.borc_external_hesap as source_account_iban,
                transfer.alacak_external_hesap as target_account_iban, 
                account.isim_unvan as target_name,
                'DEMIRBANK' as target_bic_code,
                 null as target_country_code,
                region.il_kodu as target_bank_city_code, 
                branch.kodu as target_bank_branch_code,
                transfer.istatistik_kodu as payment_code,
                null as payment_destination_code,
                transfer.aciklama as description
                      from cbs_islem transactions
                          join cbs_virman_islem transfer on transactions.numara = transfer.tx_no
                             inner join cbs_vw_hesap_izleme account on account.hesap_no = transfer.alacak_hesap_no
                             inner join cbs_bolum branch on branch.kodu = account.sube_kodu
                             inner join cbs_il_kodlari region on region.il_kodu = branch.il_kodu
                                where transactions.islem_kod = 1203
                                      and transactions.musteri_numara in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                                      and transactions.durum = 'P'
                                      and pkg_hesap.hesaptanmusterinoal(transfer.borc_hesap_no) <> pkg_hesap.hesaptanmusterinoal(transfer.alacak_hesap_no)
                                      and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                      order by transactions.numara desc 
                                      offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
                                      
  elsif ps_transfer_type='b2b' then
  
    open pc_ref 
        for
            select transactions.numara as transaction_number,
                'b2b' as transfer_type,
                transactions.kayit_sistem_tarihi as transaction_date,
                transactions.tutar as amount, 
                transfer.doviz_kodu as currency_code, 
                transfer.borc_external_hesap as source_account_iban,
                transfer.alacak_external_hesap as target_account_iban, 
                account.isim_unvan as target_name,
                'DEMIRBANK' as target_bic_code,
                 null as target_country_code,
                region.il_kodu as target_bank_city_code, 
                branch.kodu as target_bank_branch_code,
                transfer.istatistik_kodu as payment_code,
                null as payment_destination_code,
                transfer.aciklama as description
                      from cbs_islem transactions
                          join cbs_virman_islem transfer on transactions.numara = transfer.tx_no
                             inner join cbs_vw_hesap_izleme account on account.hesap_no = transfer.alacak_hesap_no
                             inner join cbs_bolum branch on branch.kodu = account.sube_kodu
                             inner join cbs_il_kodlari region on region.il_kodu = branch.il_kodu
                                where transactions.islem_kod = 1203
                                      and transactions.musteri_numara in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                                      and transactions.durum = 'P'
                                      and pkg_hesap.hesaptanmusterinoal(transfer.borc_hesap_no) = pkg_hesap.hesaptanmusterinoal(transfer.alacak_hesap_no)
                                      and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                      order by transactions.numara desc 
                                      offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
                                      
  else  
  
   open pc_ref for                 
          select * from (select transactions.numara as transaction_number,
                   'swift' as transfer_type,
                   transactions.kayit_sistem_tarihi as transaction_date, 
                   transactions.tutar as amount, 
                   transfer.transfer_doviz_kodu as currency_code, 
                   transfer.oc_hesap_no_k as source_account_iban,
                   transfer.bc_hesap_no_n as target_account_iban, 
                   transfer.bc_isim_adres_1 as target_name,
                   transfer.awi_bic as target_bic_code,
                   transfer.ulke_kodu as target_country_code,
                   bank.bic_sehir_kodu as target_bank_city_code, 
                   bank.bic_sube_kodu as target_bank_branch_code,
                   transfer.istatistik_kodu as payment_code,
                   replace(replace(transfer.rr_1, '/BENEFRES/AE//', ''), '/', '') as payment_destination_code,
                   transfer.aciklama as description
                 from cbs_islem transactions
                     join cbs_yphavale_giden_acilis transfer on transactions.numara = transfer.tx_no
                     inner join cbs_bic_kodlari bank on bank.bic_kodu = transfer.awi_bic
                        where transactions.islem_kod = 4003
                              and transactions.musteri_numara in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                              and transactions.durum = 'P'
                              and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                union
                select transactions.numara as transaction_number,
                                   case
                                    when payment_type = 'CLEARING' then
                                      'clearing'
                                    else
                                      'gross'
                                   end transfer_type,
                                   transactions.kayit_sistem_tarihi as transaction_date, 
                                    transactions.tutar as amount, 
                                   'KGS' as currency_code, 
                                   transfer.from_account_external_number as source_account_iban,
                                   transfer.to_account_external_number as target_account_iban, 
                                   transfer.to_name as target_name,
                                   transfer.to_bank_bic as target_bic_code,
                                   null as target_country_code,
                                   to_char(region.no) as target_bank_city_code, 
                                   null as target_bank_branch_code,
                                   to_char(transfer.code_of_payment) as payment_code,
                                   null as payment_destination_code,
                                   transfer.explanation as description
                                 from cbs_islem transactions
                                     join cbs_clearing transfer on transactions.numara = transfer.yaratan_tx_no
                                     inner join cbs_banka_kodlari bank on  bank.banka_kodu = transfer.to_bank_bic
                                     inner join cbs_kg_regions region on region.no = bank.region_no
                                        where transactions.islem_kod = 3555
                                              and transactions.musteri_numara in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                                              and transactions.durum = 'P'
                                              and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)      
                union
                select transactions.numara as transaction_number,
                                case
                                    when pkg_hesap.hesaptanmusterinoal(transfer.borc_hesap_no) <> pkg_hesap.hesaptanmusterinoal(transfer.alacak_hesap_no) then
                                      'b2ob'
                                    else
                                      'b2b'
                                end transfer_type,
                                transactions.kayit_sistem_tarihi as transaction_date,
                                transactions.tutar as amount, 
                                transfer.doviz_kodu as currency_code, 
                                transfer.borc_external_hesap as source_account_iban,
                                transfer.alacak_external_hesap as target_account_iban, 
                                account.isim_unvan as target_name,
                                'DEMIRBANK' as target_bic_code,
                                 null as target_country_code,
                                region.il_kodu as target_bank_city_code, 
                                branch.kodu as target_bank_branch_code,
                                transfer.istatistik_kodu as payment_code,
                                null as payment_destination_code,
                                transfer.aciklama as description
                                      from cbs_islem transactions
                                          join cbs_virman_islem transfer on transactions.numara = transfer.tx_no
                                             inner join cbs_vw_hesap_izleme account on account.hesap_no = transfer.alacak_hesap_no
                                             inner join cbs_bolum branch on branch.kodu = account.sube_kodu
                                             inner join cbs_il_kodlari region on region.il_kodu = branch.il_kodu
                                                where transactions.islem_kod = 1203
                                                      and transactions.musteri_numara in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                                                      and transactions.durum = 'P'
                                                      and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)) 
                                  order by transaction_number desc 
                                  offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;   
  end if;
  
   return ls_returncode;
  
EXCEPTION 
    when le_customer_not_found then
          return '454'; 
    when others then
           raise;          
END;

FUNCTION GetFrequentTransfers(ps_lang varchar2, 
                              ps_customer_id varchar2,
                              pn_page_index number,
                              pn_page_size number, 
                              pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_number number;
ln_frequency number;
ls_returncode varchar2(3) := '000'; 
le_customer_not_found exception;
BEGIN

  ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
  
  if ln_customer_number is null then
    raise le_customer_not_found;
  end if;
  
  pkg_parametre.deger('TRANSFER_FREQUENCY', ln_frequency);
     
  open pc_ref for 
     select * from (select  transfer.bc_isim_adres_1 as target_name,
            'swift' as transfer_type,
            count(*) as frequency,
            transfer.awi_bic as target_bic_code,
            bank.banka_adi as target_bic_name,
            transfer.bc_hesap_no_n as target_account_iban
                     from cbs_islem transactions
                         join cbs_yphavale_giden_acilis transfer on transactions.numara = transfer.tx_no
                         inner join cbs_bic_kodlari bank on bank.bic_kodu = transfer.awi_bic
                            where transactions.islem_kod = 4003
                                  and transactions.musteri_numara = ln_customer_number 
                                  and transactions.durum = 'P'
                                  and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                  group by transfer.bc_isim_adres_1, transfer.awi_bic, bank.banka_adi, transfer.bc_hesap_no_n
                                  having count(*) >= ln_frequency
    union                           
     select transfer.to_name as target_name,
            'clearing' as transfer_type,
             count(*) as frequency, 
             transfer.to_bank_bic as target_bic_code,
             bank.banka_adi as target_bic_name,
             transfer.to_account_external_number as target_account_iban
                     from cbs_islem transactions
                         join cbs_clearing transfer on transactions.numara = transfer.yaratan_tx_no
                         inner join cbs_banka_kodlari bank on  bank.banka_kodu = to_number(transfer.to_bank_bic)
                            where transactions.islem_kod = 3555
                                  and transactions.musteri_numara = ln_customer_number
                                  and transactions.durum = 'P'   
                                  and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)                
                                  group by transfer.to_name, transfer.to_account_external_number, transfer.to_bank_bic, bank.banka_adi 
                                  having count(*) >= ln_frequency
    union
     select account.isim_unvan as target_name,
                    'b2ob' as transfer_type,
                     count(*) as frequency,
                    'DEMIRBANK' as target_bic_code,
                    'DKIB' as target_bic_name,
                    transfer.alacak_external_hesap as target_account_iban
                          from cbs_islem transactions
                              join cbs_virman_islem transfer on transactions.numara = transfer.tx_no
                                 inner join cbs_vw_hesap_izleme account on account.hesap_no = transfer.alacak_hesap_no
                                 inner join cbs_bolum branch on branch.kodu = account.sube_kodu
                                 inner join cbs_il_kodlari region on region.il_kodu = branch.il_kodu
                                    where transactions.islem_kod = 1203
                                          and transactions.musteri_numara = ln_customer_number 
                                          and transactions.durum = 'P'
                                          and pkg_hesap.hesaptanmusterinoal(transfer.borc_hesap_no) <> pkg_hesap.hesaptanmusterinoal(transfer.alacak_hesap_no)
                                          and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                          group by account.isim_unvan, transfer.alacak_external_hesap
                                          having count(*) >= ln_frequency
      union
       select account.isim_unvan as target_name,
                    'b2b' as transfer_type,
                     count(*) as frequency,
                    'DEMIRBANK' as target_bic_code,
                    'DKIB' as target_bic_name,
                    transfer.alacak_external_hesap as target_account_iban
                          from cbs_islem transactions
                              join cbs_virman_islem transfer on transactions.numara = transfer.tx_no
                                 inner join cbs_vw_hesap_izleme account on account.hesap_no = transfer.alacak_hesap_no
                                 inner join cbs_bolum branch on branch.kodu = account.sube_kodu
                                 inner join cbs_il_kodlari region on region.il_kodu = branch.il_kodu
                                    where transactions.islem_kod = 1203
                                          and transactions.musteri_numara = ln_customer_number 
                                          and transactions.durum = 'P'
                                          and pkg_hesap.hesaptanmusterinoal(transfer.borc_hesap_no) = pkg_hesap.hesaptanmusterinoal(transfer.alacak_hesap_no)
                                          and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                          group by account.isim_unvan, transfer.alacak_external_hesap
                                          having count(*) >= ln_frequency) 
          order by transfer_type,  frequency desc 
          offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
  
   return ls_returncode;
  
EXCEPTION  
    when le_customer_not_found then
          return '454'; 
    when others then
           raise;          
END;  
FUNCTION GetFrequentTransfersByAccount(ps_lang varchar2, 
                                       ps_customer_id varchar2,
                                       ps_target_iban varchar2,
                                       ps_transfer_type varchar2,
                                       pn_page_index number,
                                       pn_page_size number,
                                       ps_from_date varchar2, 
                                       ps_to_date varchar2, 
                                       pc_ref OUT CursorReferenceType) RETURN varchar2
IS 
ln_customer_number number;
ld_from_date date;
ld_to_date date;
le_customer_not_found exception;
ls_returncode varchar2(3) := '000';
BEGIN

    ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
  
    if ln_customer_number is null then
        raise le_customer_not_found;
    end if;
  
    if ps_from_date is not null and ps_to_date is not null then
        ld_from_date := to_date(substr(ps_from_date, 1, 10), 'YYYY-MM-DD');
        ld_to_date := to_date(substr(ps_to_date, 1, 10), 'YYYY-MM-DD');
    end if;

    
    if ps_transfer_type='swift' then
        open pc_ref 
        for
            select transactions.numara as transaction_number,
                   'swift' as transfer_type,
                   transactions.kayit_sistem_tarihi as transaction_date, 
                   transactions.tutar as amount, 
                   transfer.transfer_doviz_kodu as currency_code, 
                   transfer.oc_hesap_no_k as source_account_iban,
                   transfer.bc_hesap_no_n as target_account_iban, 
                   transfer.bc_isim_adres_1 as target_name,
                   transfer.awi_bic as target_bic_code,
                   transfer.ulke_kodu as target_country_code,
                   bank.bic_sehir_kodu as target_bank_city_code, 
                   bank.bic_sube_kodu as target_bank_branch_code,
                   transfer.istatistik_kodu as payment_code,
                   replace(replace(transfer.rr_1, '/BENEFRES/AE//', ''), '/', '') as payment_destination_code,
                   transfer.aciklama as description
                 from cbs_islem transactions
                     join cbs_yphavale_giden_acilis transfer on transactions.numara = transfer.tx_no
                     inner join cbs_bic_kodlari bank on bank.bic_kodu = transfer.awi_bic
                        where transactions.islem_kod = 4003
                              and transfer.bc_hesap_no_n = ps_target_iban
                              and transactions.musteri_numara = ln_customer_number 
                              and transactions.durum = 'P'
                              and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                              and transactions.kayit_tarih between nvl(ld_from_date, transactions.kayit_tarih) and nvl(ld_to_date, transactions.kayit_tarih) 
                              order by transactions.numara desc 
                              offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
        
    elsif ps_transfer_type='clearing' then
        open pc_ref 
            for
               select transactions.numara as transaction_number,
                   'clearing' as transfer_type,
                   transactions.kayit_sistem_tarihi as transaction_date, 
                    transactions.tutar as amount, 
                   'KGS' as currency_code, 
                   transfer.from_account_external_number as source_account_iban,
                   transfer.to_account_external_number as target_account_iban, 
                   transfer.to_name as target_name,
                   transfer.to_bank_bic as target_bic_code,
                   null as target_country_code,
                   to_char(region.no) as target_bank_city_code, 
                   null as target_bank_branch_code,
                   to_char(transfer.code_of_payment) as payment_code,
                   null as payment_destination_code,
                   transfer.explanation as description
                     from cbs_islem transactions
                         join cbs_clearing transfer on transactions.numara = transfer.yaratan_tx_no
                         inner join cbs_banka_kodlari bank on  bank.banka_kodu = transfer.to_bank_bic
                         inner join cbs_kg_regions region on region.no = bank.region_no
                            where transactions.islem_kod = 3555
                                  and transfer.to_account_external_number = ps_target_iban
                                  and transactions.musteri_numara = ln_customer_number 
                                  and transactions.durum = 'P'
                                  and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                  and transactions.kayit_tarih between nvl(ld_from_date, transactions.kayit_tarih) and nvl(ld_to_date, transactions.kayit_tarih) 
                                  order by transactions.numara desc
                                  offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
                                  
    elsif ps_transfer_type='b2ob' then
    
          open pc_ref 
            for
               select transactions.numara as transaction_number,
                'b2ob' as transfer_type,
                transactions.kayit_sistem_tarihi as transaction_date,
                transactions.tutar as amount, 
                transfer.doviz_kodu as currency_code, 
                transfer.borc_external_hesap as source_account_iban,
                transfer.alacak_external_hesap as target_account_iban, 
                account.isim_unvan as target_name,
                'DEMIRBANK' as target_bic_code,
                 null as target_country_code,
                region.il_kodu as target_bank_city_code, 
                branch.kodu as target_bank_branch_code,
                transfer.istatistik_kodu as payment_code,
                null as payment_destination_code,
                transfer.aciklama as description
                      from cbs_islem transactions
                          join cbs_virman_islem transfer on transactions.numara = transfer.tx_no
                             inner join cbs_vw_hesap_izleme account on account.hesap_no = transfer.alacak_hesap_no
                             inner join cbs_bolum branch on branch.kodu = account.sube_kodu
                             inner join cbs_il_kodlari region on region.il_kodu = branch.il_kodu
                                where transactions.islem_kod = 1203
                                      and transfer.alacak_external_hesap = ps_target_iban
                                      and transactions.musteri_numara = ln_customer_number 
                                      and transactions.durum = 'P'
                                      and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                      and transactions.kayit_tarih between nvl(ld_from_date, transactions.kayit_tarih) and nvl(ld_to_date, transactions.kayit_tarih)   
                                      order by transactions.numara desc 
                                      offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
    else
    
         open pc_ref 
            for
               select transactions.numara as transaction_number,
                'b2b' as transfer_type,
                transactions.kayit_sistem_tarihi as transaction_date,
                transactions.tutar as amount, 
                transfer.doviz_kodu as currency_code, 
                transfer.borc_external_hesap as source_account_iban,
                transfer.alacak_external_hesap as target_account_iban, 
                account.isim_unvan as target_name,
                'DEMIRBANK' as target_bic_code,
                 null as target_country_code,
                region.il_kodu as target_bank_city_code, 
                branch.kodu as target_bank_branch_code,
                transfer.istatistik_kodu as payment_code,
                null as payment_destination_code,
                transfer.aciklama as description
                      from cbs_islem transactions
                          join cbs_virman_islem transfer on transactions.numara = transfer.tx_no
                             inner join cbs_vw_hesap_izleme account on account.hesap_no = transfer.alacak_hesap_no
                             inner join cbs_bolum branch on branch.kodu = account.sube_kodu
                             inner join cbs_il_kodlari region on region.il_kodu = branch.il_kodu
                                where transactions.islem_kod = 1203
                                      and transfer.alacak_external_hesap = ps_target_iban
                                      and transactions.musteri_numara = ln_customer_number 
                                      and transactions.durum = 'P'
                                      and transactions.kayit_tarih >= add_months(trunc(sysdate), -12)
                                      and transactions.kayit_tarih between nvl(ld_from_date, transactions.kayit_tarih) and nvl(ld_to_date, transactions.kayit_tarih)      
                                      order by transactions.numara desc 
                                      offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
    end if;
    
    return ls_returncode;
         
EXCEPTION 
    when le_customer_not_found then
          return '454'; 
    when others then
            raise;          
END;                      
FUNCTION GetSwiftCommission(ps_source_iban varchar2,
                            ps_amount varchar2,
                            ps_commission_type varchar2,
                            ps_execution_type varchar2,
                            ps_swift_code varchar2,
                            pc_ref OUT CursorReferenceType) RETURN varchar2  
IS
ln_transaction_number number;
ln_transaction_code number;  
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ls_target_product_class varchar2(20);
ln_cash_code number; 
ln_initial_balance number;
ln_final_balance number;
ln_source_account number;
ln_source_customer number;
ls_source_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ls_source_name varchar2(150);
ln_amount number;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_staff_count number;
ln_insider_count number;
ln_count number := 0;
ls_returncode varchar2(3):='000';

notenoughbalance exception;
BEGIN

      
   ln_transaction_number := pkg_tx.islem_no_al;
   ln_transaction_code := 4003;
   
   select hesap_no, musteri_no, doviz_kodu, sube_kodu
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code
          from cbs_hesap where external_hesap_no = ps_source_iban;      
 
   ln_amount := to_number(ps_amount,'999999999999999.9999');
   
   ls_module_type_code  :='FCTRANSFER';
   ls_product_type_code   :='OUTGOING';
   ls_product_class_code := upper(upper(ps_commission_type) || ' ' ||  ps_execution_type || ' ' || ls_source_currency_code);
   

    select count(*) into ln_staff_count
            from cbs_musteri
                where musteri_no = ln_source_customer
                    and personel_sicil_no is not null;

    select count(*) into ln_insider_count
            from corpint.tbl_swift_insiders
                where person_id in (select person_id from corpint.tbl_person where customer_id=ln_source_customer);

    if (ln_staff_count > 0) and (ln_insider_count = 0) then
           ls_product_class_code := 'STAFF SWIFT';
    end if;
                                                  
   ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, 
                                                   ln_transaction_code, 
                                                   ls_module_type_code, 
                                                   ls_product_type_code, 
                                                   ls_product_class_code,
                                                   ln_amount,  
                                                   ls_branch_code, 
                                                   ls_source_currency_code, 
                                                   ln_source_customer, 
                                                   ln_source_account, 
                                                   ln_cash_code); 
                                                   
                                                     
    select count(*) into ln_count from cbs_bic_kodlari where bic_ulke_kodu = 'TR' and bic_kodu = ps_swift_code;
    
    if ln_count > 0 and pkg_kur.yuvarla('USD', pkg_kur.doviz_doviz_karsilik(ls_source_currency_code, 'USD', null,  ln_amount, 1, null, null, 'N', 'S')) < 5000 then
        ln_commission_amount := 0;
    end if;

    
    open pc_ref for 
        select 'SWIFT' as name, 
               'customer' as client, 
               ln_commission_amount + ln_tax as amount,
               ln_commission_amount as commission_amount,
               ln_tax as tax_amount,
               ls_source_currency_code as currency_code from dual;

     return ls_returncode;
     
EXCEPTION
    when notenoughbalance then
          return '456'; 
    when others then
          raise;          
END;
FUNCTION GetOwnAccountTransfer(ps_lang varchar2,
                               ps_source_iban varchar2, 
                               ps_target_iban varchar2, 
                               ps_amount varchar2,
                               ps_description varchar2,
                               pc_ref OUT CursorReferenceType,
                               pc_ref2 OUT CursorReferenceType,
                               pc_ref3 OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;  
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ls_source_product_class varchar2(20);
ls_target_product_class varchar2(20);
ln_cash_code number; 
ln_initial_balance number;
ln_final_balance number;
ln_source_account number;
ln_target_account number;
ln_source_customer number;
ln_target_customer number;
ls_source_currency_code varchar2(3 byte);
ls_target_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ls_target_masked_name varchar2(150);
ln_amount number;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ls_returncode varchar2(3):='000';

currencymismatch exception;
notenoughbalance exception;
notownaccount exception;
le_target_elcard exception;
BEGIN

   ln_transaction_number := pkg_tx.islem_no_al;
   ln_transaction_code := 1203;
   
   select hesap_no, musteri_no, doviz_kodu, sube_kodu, urun_sinif_kod
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code, ls_source_product_class
          from cbs_hesap where external_hesap_no = ps_source_iban;
       
   select hesap_no, musteri_no, doviz_kodu, urun_sinif_kod
      into ln_target_account, ln_target_customer, ls_target_currency_code, ls_target_product_class  
          from cbs_hesap where external_hesap_no = ps_target_iban;

    if (ls_source_currency_code != ls_target_currency_code) then
         raise currencymismatch;
    end if;
    
    if (PKG_INT_CUSTOMER_INQ.GetCustomerIdByIban(ps_source_iban) != PKG_INT_CUSTOMER_INQ.GetCustomerIdByIban(ps_target_iban)) then
         raise notownaccount;
    end if;


    if (ls_target_product_class = 'ELCARD NON INT.BR-LC') then
         raise le_target_elcard;
    end if;
   
          
   ln_amount := to_number(ps_amount,'999999999999999.9999');
   
   cbs.pkg_tx1203.sp_urun_tur_sinif_al(ln_source_account,
                                       ln_target_account  ,
                                       ls_source_currency_code ,
                                       'E',
                                       ls_module_type_code,
                                       ls_product_type_code,
                                       ls_product_class_code);                                  
                                             
   ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, 
                                                       ln_transaction_code, 
                                                       ls_module_type_code, 
                                                       ls_product_type_code, 
                                                       ls_product_class_code,
                                                       ln_amount,  
                                                       ls_branch_code, 
                                                       ls_source_currency_code, 
                                                       ln_source_customer, 
                                                       ln_source_account, 
                                                       ln_cash_code);  
                                                                                                      
    if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
    else
       ln_tax_rate := 0;
       ln_tax := 0;   
    end if;  
    
    if ls_source_product_class = 'ELCARD NON INT.BR-LC' then
         ln_initial_balance := pkg_elcard.getelcardipcbalance(ln_source_account);
      
         --if source elcard check cbs balance also
         if (pkg_hesap.kullanilabilir_bakiye_al(ln_source_account) - ln_amount - ln_commission_amount - ln_tax) < 0 then
             raise notenoughbalance;
         end if;
    
    else
      ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
    end if;
                                                                 
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
    if ln_final_balance < 0 then
         raise notenoughbalance;
    end if;
    
    ls_target_masked_name := pkg_int_customer_inq.getcustomermaskedname(ps_lang, ln_target_customer);
    
    open pc_ref for   
        select ls_target_masked_name as target_masked_name, 
                ln_amount as amount,
                ls_source_currency_code as currency_code, 
                ln_initial_balance as initial_balance, 
                ln_final_balance as final_balance,          
                sysdate  as transaction_date from dual;
                
     open pc_ref2 for
        select 'commission' as name, 
                'bank' as client, 
                ln_commission_amount as amount,
                pkg_genel.lc_al as currency_code from dual
         union
         select 'tax' as name, 
                'bank' as client, 
                ln_tax as amount,
                pkg_genel.lc_al as currency_code from dual;
               
    open pc_ref3 for
             select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;        

     return ls_returncode;
         
EXCEPTION
        when currencymismatch then
             return '453';
        when notenoughbalance then
             return '456';
        when notownaccount then
             return '457';
        when le_target_elcard then
             return '461';
        when others then
         log_at('GetOwnAccountTransfer', ps_source_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
           raise;          
END;

FUNCTION GetAnotherAccountTransfer(ps_lang varchar2,
                                   ps_source_iban varchar2, 
                                   ps_target_iban varchar2, 
                                   ps_amount varchar2,
                                   ps_description varchar2,
                                   pc_ref OUT CursorReferenceType,
                                   pc_ref2 OUT CursorReferenceType,
                                   pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS
ln_transaction_number number;
ln_transaction_code number;  
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ls_source_product_class varchar2(20);
ls_target_product_class varchar2(20);
ln_cash_code number; 
ln_initial_balance number;
ln_final_balance number;
ln_source_account number;
ln_target_account number;
ln_source_customer number;
ln_target_customer number;
ls_source_currency_code varchar2(3 byte);
ls_target_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ls_target_masked_name varchar2(150);
ln_amount number;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ls_returncode varchar2(3) := '000';

currencymismatch exception;
notenoughbalance exception;
le_target_elcard exception;
BEGIN

   ln_transaction_number := pkg_tx.islem_no_al;
   ln_transaction_code := 1203;
   
   select hesap_no, musteri_no, doviz_kodu, sube_kodu, urun_sinif_kod
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code, ls_source_product_class
          from cbs_hesap where external_hesap_no = ps_source_iban;
       
   select hesap_no, musteri_no, doviz_kodu, urun_sinif_kod
      into ln_target_account, ln_target_customer, ls_target_currency_code, ls_target_product_class  
          from cbs_hesap where external_hesap_no = ps_target_iban;
   
    if ls_source_currency_code != ls_target_currency_code then
         raise currencymismatch;
    end if;
    
    if ls_target_product_class = 'ELCARD NON INT.BR-LC' then
         raise le_target_elcard;
    end if;
   
   ln_amount := to_number(ps_amount,'999999999999999.9999');
   
   cbs.pkg_tx1203.sp_urun_tur_sinif_al(ln_source_account,
                                       ln_target_account  ,
                                       ls_source_currency_code ,
                                       'E',
                                       ls_module_type_code,
                                       ls_product_type_code,
                                       ls_product_class_code);
                                             
   ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, 
                                                       ln_transaction_code, 
                                                       ls_module_type_code, 
                                                       ls_product_type_code, 
                                                       ls_product_class_code,
                                                       ln_amount,  
                                                       ls_branch_code, 
                                                       ls_source_currency_code, 
                                                       ln_source_customer, 
                                                       ln_source_account, 
                                                       ln_cash_code);   
                                                   
    if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
    else
       ln_tax_rate := 0;
       ln_tax := 0;   
    end if;                                              
           
    if ls_source_product_class = 'ELCARD NON INT.BR-LC' then
         ln_initial_balance := pkg_elcard.getelcardipcbalance(ln_source_account);
      
         --if source elcard check cbs balance also
         if (pkg_hesap.kullanilabilir_bakiye_al(ln_source_account) - ln_amount - ln_commission_amount - ln_tax) < 0 then
             raise notenoughbalance;
         end if;
    
    else
      ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
    end if;
                                                                     
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
    if ln_final_balance < 0 then
         raise notenoughbalance;
    end if;
    
    ls_target_masked_name := pkg_int_customer_inq.getcustomermaskedname(ps_lang, ln_target_customer);
       
    open pc_ref for   
        select ls_target_masked_name as target_masked_name, 
                ln_amount as amount,
                ls_source_currency_code as currency_code, 
                ln_initial_balance as initial_balance, 
                ln_final_balance as final_balance,    
                sysdate as transaction_date from dual;
                
   open pc_ref2 for            
     select 'commission' as name, 
                'bank' as client, 
                ln_commission_amount as amount,
                pkg_genel.lc_al as currency_code from dual
         union
         select 'tax' as name, 
                'bank' as client, 
                ln_tax as amount,
                pkg_genel.lc_al as currency_code from dual;
     
    open pc_ref3 for
             select 
              pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;  

     return ls_returncode;
     
EXCEPTION
        when currencymismatch then
             return '453';
        when notenoughbalance then
             return '456';
        when le_target_elcard then
             return '461';
        when others then
         log_at('GetAnotherAccountTransfer', ps_source_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
           raise;          
END;
            
FUNCTION GetClearingTransfer(ps_lang varchar2,
                             ps_source_iban varchar2,
                             ps_target_full_name varchar2,
                             ps_target_iban varchar2,
                             ps_bic_code varchar2,
                             ps_payment_code varchar2,
                             ps_amount varchar2,
                             ps_description varchar2,
                             ps_transfer_type varchar2,
                             pc_ref OUT CursorReferenceType,
                             pc_ref2 OUT CursorReferenceType,
                             pc_ref3 OUT CursorReferenceType) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;  
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ls_source_product_class varchar2(20);
ln_cash_code number; 
ln_initial_balance number;
ln_final_balance number;
ln_source_account number;
ln_source_customer number;
ls_source_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ln_amount number;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_max_amount number;

ls_returncode varchar2(3):='000';

lc_result  CursorReferenceType;

currencymismatch exception;
notenoughbalance exception;
daterror exception;
maxamount exception;
BEGIN

   ln_transaction_number := pkg_tx.islem_no_al;
   ln_transaction_code := 3555;
   ln_amount := to_number(ps_amount,'999999999999999.9999');
      
   select hesap_no, musteri_no, doviz_kodu, sube_kodu, urun_sinif_kod
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code, ls_source_product_class
          from cbs_hesap where external_hesap_no = ps_source_iban;
   
   if pkg_genel.lc_al !=  ls_source_currency_code then
        raise currencymismatch;
   end if;
   
   ln_max_amount := pkg_clearing.get_clearing_max_tutar;
    
   if ps_transfer_type = 'clearing' and ln_amount > ln_max_amount then
      raise maxamount;
   end if;
   
   ls_returncode := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', lc_result);
  
   if ls_returncode <> '000' then
       raise daterror;
    end if;
  
   if ps_transfer_type = 'clearing' then
        pkg_parametre.deger('G_RIBCLEARING_MODUL_TYPE', ls_module_type_code);
        pkg_parametre.deger('G_RIBCLEARING_PRODUCT_TYPE', ls_product_type_code);
        pkg_parametre.deger('G_RIBCLEARING_PRODUCT_CLASS', ls_product_class_code);
   else
       ls_module_type_code  :='CLEARING';
       ls_product_type_code   :='OUTGOING';
       ls_product_class_code := 'CIBGROSS';
   end if;    
                                        
   ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, 
                                                       ln_transaction_code, 
                                                       ls_module_type_code, 
                                                       ls_product_type_code, 
                                                       ls_product_class_code,
                                                       ln_amount,  
                                                       ls_branch_code, 
                                                       ls_source_currency_code, 
                                                       ln_source_customer, 
                                                       ln_source_account, 
                                                       ln_cash_code);   
                                                   
    if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
    else
       ln_tax_rate := 0;
       ln_tax := 0;   
    end if;  
    
    if ls_source_product_class = 'ELCARD NON INT.BR-LC' then
         ln_initial_balance := pkg_elcard.getelcardipcbalance(ln_source_account);
      
         --if source elcard check cbs balance also
         if (pkg_hesap.kullanilabilir_bakiye_al(ln_source_account) - ln_amount - ln_commission_amount - ln_tax) < 0 then
             raise notenoughbalance;
         end if;
    
    else
      ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
    end if;                                            
                                                                            
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
    if ln_final_balance < 0 then
         raise notenoughbalance;
    end if;
    
    
     open pc_ref for   
        select ln_amount as amount,
                ls_source_currency_code as currency_code, 
                ln_initial_balance as initial_balance, 
                ln_final_balance as final_balance,          
                sysdate as transaction_date from dual;
     
     
     open pc_ref2 for 
         select 'commission' as name, 
                'bank' as client, 
                ln_commission_amount as amount,
                pkg_genel.lc_al as currency_code from dual
         union
         select 'tax' as name, 
                'bank' as client, 
                ln_tax as amount,
                pkg_genel.lc_al as currency_code from dual;
               
     open pc_ref3 for
           select 
               pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;  

     return ls_returncode;
     
EXCEPTION
      when currencymismatch then
             return '453';
      when notenoughbalance then
             return '456';
      when daterror then
             return '461';
      when maxamount then
             return '467';
      when others then
         log_at('GetClearingTransfer', ps_source_iban || ' ' || ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
           raise;          
END;
FUNCTION GetSwiftTransfer(ps_lang varchar2, 
                          ps_source_iban varchar2,
                          ps_currency_code varchar2,
                          ps_country_code varchar2,
                          ps_swift_code varchar2,
                          ps_amount varchar2,       
                          ps_commission_type varchar2, 
                          ps_execution_type varchar2, 
                          ps_target_iban varchar2,
                          ps_target_bank_city_name varchar2,     
                          ps_target_full_name varchar2,  
                          ps_target_address varchar2, 
                          ps_target_phone_number varchar2,  
                          ps_target_passport varchar2,  
                          ps_payment_dest_code varchar2,                   
                          ps_purpose_code varchar2,
                          ps_payment_code varchar2,
                          ps_payment_details varchar2,
                          pc_ref OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS                  
ln_transaction_number number;
ln_transaction_code number;  
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ls_target_product_class varchar2(20);
ln_cash_code number; 
ln_initial_balance number;
ln_final_balance number;
ln_source_account number;
ln_source_customer number;
ls_source_currency_code varchar2(3 byte);
ls_branch_code varchar2(10);
ls_source_name varchar2(150);
ln_amount number;
ln_commission_amount number;
ln_tax_rate number;
ln_tax number := 0;
ln_staff_count number;
ln_insider_count number;
ls_returncode varchar2(3) := '000';

l_cursor CursorReferenceType;

notenoughbalance exception;
daterror exception;
begin

   ln_transaction_number := pkg_tx.islem_no_al;
   ln_transaction_code := 4003;
   
   select hesap_no, musteri_no, doviz_kodu, sube_kodu
      into ln_source_account, ln_source_customer, ls_source_currency_code, ls_branch_code
          from cbs_hesap where external_hesap_no = ps_source_iban;      
 
   ls_source_name := pkg_musteri.sf_musteri_adi(ln_source_customer);
   
   ln_amount := to_number(ps_amount,'999999999999999.9999');
   ln_initial_balance := pkg_hesap.kullanilabilir_bakiye_al(ln_source_account); 
   
   ls_module_type_code  :='FCTRANSFER';
   ls_product_type_code   :='OUTGOING';
   ls_product_class_code := upper(ps_commission_type || ' ' ||  ps_execution_type || ' ' || ls_source_currency_code);
   
    select count(*) into ln_staff_count
            from cbs_musteri
                where musteri_no = ln_source_customer
                    and personel_sicil_no is not null;

    select count(*) into ln_insider_count
            from corpint.tbl_swift_insiders
                where person_id in (select person_id from corpint.tbl_person where customer_id=ln_source_customer);

    if ln_staff_count > 0 and ln_insider_count = 0 then
          ls_product_class_code := 'STAFF SWIFT';
    end if;
  
    ls_returncode := pkg_soa_inquiry.geteftdate(to_char(pkg_muhasebe.banka_tarihi_bul, 'YYYYMMDD'), 'CLEARING', l_cursor);
        
        if ls_returncode <> '000' then
            raise daterror;
        end if;
                      
                                               
   ln_commission_amount := pkg_aps.chargeautocalculate(ln_transaction_number, 
                                                   ln_transaction_code, 
                                                   ls_module_type_code, 
                                                   ls_product_type_code, 
                                                   ls_product_class_code,
                                                   ln_amount,  
                                                   ls_branch_code, 
                                                   ls_source_currency_code, 
                                                   ln_source_customer, 
                                                   ln_source_account, 
                                                   ln_cash_code);   
                                                   
    if ln_commission_amount > 0 then
       pkg_parametre.deger ('G_SALES_TAX_RATE', ln_tax_rate);
       ln_tax := ln_commission_amount * ln_tax_rate / 100;
    else
       ln_tax_rate := 0;
       ln_tax := 0;   
    end if;                                              
                                                                            
    ln_final_balance := ln_initial_balance - ln_amount - ln_commission_amount - ln_tax;
    
    if ln_final_balance < 0 then
         raise notenoughbalance;
    end if;
    
    
     open pc_ref for   
        select ln_amount as amount,
                ls_source_currency_code as currency_code, 
                ln_initial_balance as initial_balance, 
                ln_final_balance as final_balance,          
                sysdate as transaction_date from dual;
     
     open pc_ref2 for 
         select 'commission' as name, 
                'bank' as client, 
                ln_commission_amount as amount,
                pkg_genel.lc_al as currency_code from dual
         union
         select 'tax' as name, 
                'bank' as client, 
                ln_tax as amount,
                pkg_genel.lc_al as currency_code from dual;
               
     open pc_ref3 for
         select 
              pkg_kredi.sf_kredi_turu_aciklamasi_al(a.urun_grub_no) as name,                                                 
               a.fc_limit - nvl(a.fc_risk, 0) as amount, 
               c.ovd_faiz_orani as interest_rate,
               a.fc_doviz_kodu as currency_code
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = ln_source_account             
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;  

     return ls_returncode;
    
EXCEPTION
        when notenoughbalance then
            return '456';
        when daterror then
            return '461';
        when others then
         log_at('GetOwnAccountTransfer', ln_transaction_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
            
           raise;          
END;
FUNCTION CheckClearingIban(ps_target_iban varchar2,
                           pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ls_count number := 0;
ls_error varchar2(1);
ls_status varchar2(2);
ln_accountno1 number;
ln_accountno2 number;
ln_value1 number;
ln_value2 number;
ls_returncode varchar2(3) := '000';
noaccoutfound exception;
BEGIN

     ln_accountno1 := substr(ps_target_iban, 0, 14);
     ln_accountno2 := substr(ps_target_iban, 0, 3);
     
      begin
            select 'OK'
            into ls_status
            from dual
            where ln_accountno2 in (select substr(banka_kodu,0,3) from  cbs_banka_kodlari );

      exception 
         when no_data_found then
              ls_returncode := '454';
      end;

      if ls_status='OK' then

        ln_value1 := mod(ln_accountno1, 97);
        if length(ln_value1) = 2 then
             ln_value2 := ln_accountno1 || ln_value1;
        elsif length(ln_value1) = 1 and ln_value1 = 0 then
             ln_value2 := ln_accountno1 || 97;
        elsif length(ln_value1) = 1 then
             ln_value2 := ln_accountno1 || 0 || ln_value1;
        end if;
      else
         ls_returncode := '454';
      end if;

      if to_number(ps_target_iban) = ln_value2 then
         ls_returncode := '000';
      else
         ls_returncode := '454';
      end if ;

      open pc_ref for
        select ln_value2 from dual;

      return ls_returncode;

EXCEPTION
     when others then
           raise;          
END;

FUNCTION GetPaymentCodeDesc(ps_lang varchar2, 
                            ps_kod varchar2) RETURN varchar2
IS
descripton varchar2(1000);
BEGIN

      select descripton into descripton from (
        select  
            case 
                when ps_lang='en' then aciklama_ing
                when ps_lang='ru' then aciklama_rus
            else aciklama_rus end descripton    
            from cbs.cbs_payment_code 
                where kod = ps_kod
        union
         select  
            case 
                when ps_lang='en' then aciklama2
                when ps_lang='ru' then aciklama
            else aciklama end descripton    
            from cbs.cbs_istatistik_kodlari 
                where istatistik_kodu = ps_kod) where rownum < 2;
    
    return descripton;
    
EXCEPTION
   when others then
        raise;          
END;

END PKG_INT_TRANSFER_INQ;
/

