create PACKAGE BODY     PKG_INT_TEMPLATE_TRX IS

FUNCTION PostTemplate(pn_id number, 
                        pn_customer_number number, 
                        pc_template nclob, 
                        ps_operation_type varchar2) RETURN varchar2 
IS
ls_returncode varchar2(3) := '000';
BEGIN

    if pn_id = 0 then
    
        insert into cbs.cbs_int_customer_template (
            template_id, 
            customer_number,
            operation_type,
            template_info,
            created_at) 
        values (
            cbs.seq_template.nextval,
            pn_customer_number,
            ps_operation_type,
            pc_template,
            sysdate
            );

    else
        update cbs.cbs_int_customer_template
        set customer_number = pn_customer_number,
            template_info = pc_template
        where template_id = pn_id;
    end if;

    return ls_returncode;
    
EXCEPTION
    when others then
       cbs.log_at('PostTemplate',ls_returncode, sqlerrm, dbms_utility.format_error_backtrace );
       raise;
END;


FUNCTION DeleteTemplate(pn_id number, 
                        pn_customer_number number) RETURN varchar2 
IS
ls_returncode varchar2(3) := '000';
BEGIN

    delete from cbs.cbs_int_customer_template
            where template_id = pn_id
                  and customer_number = pn_customer_number;

    return ls_returncode;
    
EXCEPTION
    when others then
       cbs.log_at('DeleteTemplate',ls_returncode, sqlerrm, dbms_utility.format_error_backtrace );
       raise;
END;  
END;
/

