create PACKAGE BODY     PKG_INT_TEMPLATE_TRX IS

FUNCTION PostTemplate(pn_id number, 
                        pn_customer_number number, 
                        pc_template nclob, 
                        ps_operation_type varchar2) RETURN varchar2 
IS
ls_iban varchar2(50);
ls_currency_code varchar2(50);
lc_template nclob;
js json_object_t;
ls_returncode varchar2(3) := '000';
BEGIN

    js := json_object_t(pc_template);
    ls_iban := nvl(js.get_string('sourceIban'), js.get_string('iban'));
    
    ls_currency_code := pkg_int_account_inq.getcurrencycodebyiban(ls_iban);
    select to_nclob(json_mergepatch(pc_template, '{"currencyCode":"' || ls_currency_code || '"}')) into lc_template from dual;
    
    
    if pn_id = 0 then
    
        insert into cbs.cbs_int_customer_template (
            template_id, 
            customer_number,
            operation_type,
            template_info,
            created_at) 
        values (
            cbs.seq_template.nextval,
            pn_customer_number,
            ps_operation_type,
            lc_template,
            sysdate
            );

    else
        update cbs.cbs_int_customer_template
        set customer_number = pn_customer_number,
            template_info = lc_template
        where template_id = pn_id;
    end if;

    return ls_returncode;
    
EXCEPTION
    when others then
       cbs.log_at('PostTemplate',ls_returncode, sqlerrm, dbms_utility.format_error_backtrace );
       raise;
END;


FUNCTION DeleteTemplate(pn_id number, 
                        pn_customer_number number) RETURN varchar2 
IS
ls_returncode varchar2(3) := '000';
BEGIN

    delete from cbs.cbs_int_customer_template
            where template_id = pn_id
                  and customer_number = pn_customer_number;

    return ls_returncode;
    
EXCEPTION
    when others then
       cbs.log_at('DeleteTemplate',ls_returncode, sqlerrm, dbms_utility.format_error_backtrace );
       raise;
END;  
END;
/

