create trigger REPORT_ID_TRIG
    before insert
    on REPORT
    for each row
    when (new.report_id is null)
BEGIN 
    SELECT report_id_seq.NEXTVAL
    INTO :new.report_id
    FROM dual;
END;


/

