create trigger WORKFLOW_TRIG
    before insert
    on WORKFLOW
    for each row
    when (new.id is null)
BEGIN 
    SELECT WORKFLOW_seq.NEXTVAL
    INTO :new.id
    FROM dual;
END;


/

