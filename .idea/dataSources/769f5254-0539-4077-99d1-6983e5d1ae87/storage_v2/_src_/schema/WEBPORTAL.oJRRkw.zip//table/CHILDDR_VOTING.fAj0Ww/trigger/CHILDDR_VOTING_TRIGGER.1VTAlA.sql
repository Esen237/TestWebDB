create trigger CHILDDR_VOTING_TRIGGER
    before insert
    on CHILDDR_VOTING
    for each row
    when (new.CHILDDR_VOTING_ID IS NULL)
BEGIN
    SELECT CHILDDR_VOTING_SEQ.NEXTVAL
    INTO :new.CHILDDR_VOTING_ID
    FROM dual;
END;


/

