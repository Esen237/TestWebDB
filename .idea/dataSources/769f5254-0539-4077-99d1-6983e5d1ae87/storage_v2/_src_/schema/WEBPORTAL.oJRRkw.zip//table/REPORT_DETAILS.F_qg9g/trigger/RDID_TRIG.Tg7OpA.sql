create trigger RDID_TRIG
    before insert
    on REPORT_DETAILS
    for each row
    when (new.report_details_id is null)
BEGIN 
    SELECT rdid_seq.NEXTVAL
    INTO :new.report_details_id
    FROM dual;
END;


/

