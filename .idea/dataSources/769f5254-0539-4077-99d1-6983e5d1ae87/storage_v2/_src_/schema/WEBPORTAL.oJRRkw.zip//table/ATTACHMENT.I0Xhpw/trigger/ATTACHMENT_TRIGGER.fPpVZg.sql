create trigger ATTACHMENT_TRIGGER
    before insert
    on ATTACHMENT
    for each row
    when (new.ATTACHMENT_ID IS NULL)
BEGIN
    SELECT ATTACHMENT_SEQ.NEXTVAL
    INTO :new.ATTACHMENT_ID
    FROM dual;
END;


/

