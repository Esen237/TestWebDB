create trigger CUSTOMER_ANNOUNCE_BIR
    before insert
    on CUSTOMER_ANNOUNCE
    for each row
BEGIN
  SELECT CUSTOMER_ANNOUNCE_SEQ.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;


/

