create trigger VIEW_ID_TRIG
    before insert
    on VIEW_TBL
    for each row
    when (new.view_id is null)
BEGIN 
    SELECT view_seq.NEXTVAL
    INTO :new.view_id
    FROM dual;
END;


/

