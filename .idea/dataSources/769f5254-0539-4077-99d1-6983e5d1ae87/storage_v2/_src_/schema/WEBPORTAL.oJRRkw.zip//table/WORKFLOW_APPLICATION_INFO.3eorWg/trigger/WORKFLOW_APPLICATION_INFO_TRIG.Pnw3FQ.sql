create trigger WORKFLOW_APPLICATION_INFO_TRIG
    before insert
    on WORKFLOW_APPLICATION_INFO
    for each row
    when (new.id is null)
BEGIN 
    SELECT WORKFLOW_seq.NEXTVAL
    INTO :new.id
    FROM dual;
END;


/

