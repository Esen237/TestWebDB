create trigger CUSTOMER_INQUIRY_ARCHIVE_TRG
    before insert
    on CUSTOMER_INQUIRY
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ARCHIVE_ID
  Select CUSTOMER_INQUIRY_ARCHIVE5_SEQ.nextval into n from dual;
  :new.ARCHIVE_ID := N;
END CUSTOMER_INQUIRY_ARCHIVE_TRG;

/

