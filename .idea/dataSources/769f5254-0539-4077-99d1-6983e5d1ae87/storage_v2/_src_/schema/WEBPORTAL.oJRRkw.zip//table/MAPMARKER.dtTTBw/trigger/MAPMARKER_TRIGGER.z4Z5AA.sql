create trigger MAPMARKER_TRIGGER
    before insert
    on MAPMARKER
    for each row
    when (new.MAPMARKER_ID IS NULL)
BEGIN
    SELECT MAPMARKER_SEQ.NEXTVAL
    INTO :new.MAPMARKER_ID
    FROM dual;
END;


/

