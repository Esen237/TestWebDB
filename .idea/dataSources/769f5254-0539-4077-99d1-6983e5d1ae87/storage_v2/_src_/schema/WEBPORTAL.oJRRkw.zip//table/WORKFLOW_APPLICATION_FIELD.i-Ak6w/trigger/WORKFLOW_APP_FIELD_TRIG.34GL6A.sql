create trigger WORKFLOW_APP_FIELD_TRIG
    before insert
    on WORKFLOW_APPLICATION_FIELD
    for each row
    when (new.id is null)
BEGIN 
    SELECT WORKFLOW_seq.NEXTVAL
    INTO :new.id
    FROM dual;
END;


/

