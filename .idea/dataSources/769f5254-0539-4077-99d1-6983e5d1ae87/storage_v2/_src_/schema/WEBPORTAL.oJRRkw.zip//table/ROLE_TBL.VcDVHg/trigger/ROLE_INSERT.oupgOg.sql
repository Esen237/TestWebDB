create trigger ROLE_INSERT
    before insert
    on ROLE_TBL
    for each row
    when (new.role_id is null)
begin
SELECT role_seq.NEXTVAL 
  INTO :new.role_id
  FROM dual;
    
end;


/

