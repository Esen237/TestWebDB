create trigger USER_INSERT
    before insert
    on USER_TBL
    for each row
    when (new.user_id is null)
begin
SELECT user_seq.NEXTVAL 
  INTO :new.USER_id
  FROM dual;
    
end;


/

