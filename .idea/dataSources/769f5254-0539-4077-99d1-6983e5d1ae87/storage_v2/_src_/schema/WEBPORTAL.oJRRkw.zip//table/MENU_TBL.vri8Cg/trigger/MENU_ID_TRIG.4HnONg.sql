create trigger MENU_ID_TRIG
    before insert
    on MENU_TBL
    for each row
    when (new.menu_id is null)
BEGIN 
    SELECT menu_seq.NEXTVAL
    INTO :new.menu_id
    FROM dual;
END;


/

