create PROCEDURE             "MERGE_VIEW" (
  view_title in varchar2,
  view_name in varchar2,
  status_id in integer,
  view_path in varchar2
)
is
begin
  merge into view_tbl e
  using (select view_title, view_name, status_id, view_path from dual) s
  on (e.view_name = s.view_name)
  when matched then update set view_title = s.view_title, view_name = s.view_name, status_id = 1, view_path = s.view_path 
  when not matched then insert (view_title, view_name, status_id, view_path) 
    values ('CQ Requests', 'cq_request_list1', 1, '/cq/request/list');
end;


/

