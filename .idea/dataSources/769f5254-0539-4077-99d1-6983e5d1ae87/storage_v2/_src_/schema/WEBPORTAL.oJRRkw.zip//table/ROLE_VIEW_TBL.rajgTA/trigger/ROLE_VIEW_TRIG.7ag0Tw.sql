create trigger ROLE_VIEW_TRIG
    before insert
    on ROLE_VIEW_TBL
    for each row
    when (new.role_view_id is null)
BEGIN 
    SELECT role_view_seq.NEXTVAL
    INTO :new.role_view_id
    FROM dual;
END;


/

