create FUNCTION             "VALID_USER" (pstrUsername IN VARCHAR2,
                        pstrPassword IN VARCHAR2) RETURN NUMBER IS
      lstrLink   VARCHAR2(15);
      lnumDummy  NUMBER;
      lblnAnswer NUMBER;
      xBadUserPw EXCEPTION;
      PRAGMA EXCEPTION_INIT(xBadUserPw,-1017);
   BEGIN
      -- Create the database link
      EXECUTE IMMEDIATE 'ALTER DATABASE LINK TEMP_LINK'||
                       ' CONNECT TO '||pstrUsername||
                       ' IDENTIFIED BY '||pstrPassword;

      BEGIN
         -- Try using the link...
         EXECUTE IMMEDIATE 'SELECT 99 FROM dual@'||lstrLink
                           INTO lnumDummy;
         lblnAnswer := 1;     -- ... it worked!
      EXCEPTION
         WHEN xBadUserPw THEN
            lblnAnswer := 0; -- ... it didn't
         WHEN OTHERS THEN
            lblnAnswer := -1;
      END;

      -- Drop the link
      EXECUTE IMMEDIATE 'ALTER DATABASE LINK TEMP_LINK CONNECT TO nonexisting IDENTIFIED BY notimportant ';

      RETURN lblnAnswer;
   END;


/

