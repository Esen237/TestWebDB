create trigger MENU_VIEW_TRIG
    before insert
    on MENU_VIEW_TBL
    for each row
    when (new.menu_view_id is null)
BEGIN 
    SELECT menu_view_seq.NEXTVAL
    INTO :new.menu_view_id
    FROM dual;
END;


/

