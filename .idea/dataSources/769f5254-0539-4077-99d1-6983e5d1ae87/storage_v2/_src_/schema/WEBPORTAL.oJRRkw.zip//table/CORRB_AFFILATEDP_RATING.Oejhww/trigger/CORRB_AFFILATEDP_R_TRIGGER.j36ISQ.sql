create trigger CORRB_AFFILATEDP_R_TRIGGER
    before insert
    on CORRB_AFFILATEDP_RATING
    for each row
    when (new.id IS NULL)
BEGIN
    SELECT CORRB_AFFILATEDP_RATING_SEQ.NEXTVAL
    INTO :new.id
    FROM dual;
END;


/

