create trigger TABLE_ID_TRIG
    before insert
    on SELECTABLE_TABLE
    for each row
    when (new.TABLE_id is null)
BEGIN 
    SELECT TABLE_seq.NEXTVAL
    INTO :new.TABLE_id
    FROM dual;
END;


/

