create trigger LEGAL_REPORT_LOG_INSERT
    before insert
    on LEGAL_REPORT_LOG
    for each row
    when (new.log_id is null)
begin
SELECT legal_report_log_SEQ.NEXTVAL 
  INTO :new.log_id
  FROM dual;
    
end;


/

