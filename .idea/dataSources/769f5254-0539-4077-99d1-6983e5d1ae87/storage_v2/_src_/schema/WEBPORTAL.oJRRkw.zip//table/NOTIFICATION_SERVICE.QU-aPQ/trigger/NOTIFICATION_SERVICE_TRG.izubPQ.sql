create trigger NOTIFICATION_SERVICE_TRG
    before insert
    on NOTIFICATION_SERVICE
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column NOTIFICATION_ID
  Select NOTIFICATION_SERVICE2_SEQ.nextval into n from dual;
  :new.NOTIFICATION_ID := N;
END NOTIFICATION_SERVICE_TRG;

/

