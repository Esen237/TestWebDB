create trigger INQUIRY_LIST_TRG
    before insert
    on INQUIRY_LIST
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column INQUIRY_NO
    Select max(INQUIRY_NO)+1 into n  from INQUIRY_LIST;
  :new.INQUIRY_NO := N;
END INQUIRY_LIST_TRG;

/

