create trigger APP_STATUS_TRIGGER
    before insert
    on APP_STATUS
    for each row
    when (new.APP_STATUS_ID IS NULL)
BEGIN
    SELECT APP_STATUS_SEQ.NEXTVAL
    INTO :new.APP_STATUS_ID
    FROM dual;
END;


/

