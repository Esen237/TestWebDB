create trigger WORKFLOW_APPLICATION_TRIG
    before insert
    on WORKFLOW_APPLICATION
    for each row
    when (new.id is null)
BEGIN 
    SELECT WORKFLOW_seq.NEXTVAL
    INTO :new.id
    FROM dual;
END;


/

