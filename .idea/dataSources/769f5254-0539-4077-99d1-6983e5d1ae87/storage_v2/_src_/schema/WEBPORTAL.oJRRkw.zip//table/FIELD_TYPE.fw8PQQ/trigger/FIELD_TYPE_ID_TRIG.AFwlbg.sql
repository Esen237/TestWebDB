create trigger FIELD_TYPE_ID_TRIG
    before insert
    on FIELD_TYPE
    for each row
    when (new.field_type_id is null)
BEGIN
    SELECT field_type_id_seq.NEXTVAL
    INTO :new.field_type_id
    FROM dual;
END;


/

