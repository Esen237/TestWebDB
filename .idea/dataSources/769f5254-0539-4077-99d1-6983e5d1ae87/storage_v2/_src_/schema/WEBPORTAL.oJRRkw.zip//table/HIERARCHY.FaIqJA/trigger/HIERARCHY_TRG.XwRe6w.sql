create trigger HIERARCHY_TRG
    before insert
    on HIERARCHY
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select HIERARCHY2_SEQ.nextval into n from dual;
  :new.ID := N;
END HIERARCHY_TRG;

/

