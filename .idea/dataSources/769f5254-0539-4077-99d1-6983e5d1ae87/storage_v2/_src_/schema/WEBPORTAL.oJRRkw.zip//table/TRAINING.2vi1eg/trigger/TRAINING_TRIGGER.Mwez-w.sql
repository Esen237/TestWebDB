create trigger TRAINING_TRIGGER
    before insert
    on TRAINING
    for each row
    when (NEW.TRAINING_ID IS NULL)
BEGIN
    SELECT TRAINING_SEQ.NEXTVAL
    INTO :NEW.TRAINING_ID
    FROM DUAL;
END;


/

