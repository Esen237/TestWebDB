create trigger USER_ROLE_INSERT
    before insert
    on USER_ROLE_TBL
    for each row
    when (new.user_role_id is null)
begin
SELECT user_role_seq.NEXTVAL 
  INTO :new.user_role_id
  FROM dual;
    
end;


/

