create trigger BIR_TBL_INQUIRY_REPORT
    before insert
    on TBL_INQUIRY_REPORT
    for each row
    when (NEW.repprt_id IS NULL)
DECLARE
    L_ID NUMBER;
BEGIN
    SELECT WEBPORTAL.SQ_TBL_INQUIRY_REPORT.NEXTVAL INTO L_ID FROM DUAL;
    :NEW.repprt_id := L_ID;
END;
/

