create trigger APP_COMMENT_TRIGGER
    before insert
    on APP_COMMENT
    for each row
    when (new.APP_COMMENT_ID IS NULL)
BEGIN
    SELECT APP_COMMENT_SEQ.NEXTVAL
    INTO :new.APP_COMMENT_ID
    FROM dual;
END;


/

