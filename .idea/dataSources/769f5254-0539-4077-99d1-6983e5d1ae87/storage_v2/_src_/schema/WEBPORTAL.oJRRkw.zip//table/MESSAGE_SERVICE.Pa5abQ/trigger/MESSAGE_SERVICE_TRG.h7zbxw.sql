create trigger MESSAGE_SERVICE_TRG
    before insert
    on MESSAGE_SERVICE
    for each row
DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column MSG_ID
  Select MESSAGE_SERVICE5_SEQ.nextval into n from dual;
  :new.MSG_ID := N;
END MESSAGE_SERVICE_TRG;

/

