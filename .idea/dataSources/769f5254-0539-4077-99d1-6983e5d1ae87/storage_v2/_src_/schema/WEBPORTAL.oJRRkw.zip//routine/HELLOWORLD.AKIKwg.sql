create FUNCTION             "HELLOWORLD" RETURN VARCHAR2 AS
LANGUAGE JAVA NAME 'Hello.world () return java.lang.String';


/

