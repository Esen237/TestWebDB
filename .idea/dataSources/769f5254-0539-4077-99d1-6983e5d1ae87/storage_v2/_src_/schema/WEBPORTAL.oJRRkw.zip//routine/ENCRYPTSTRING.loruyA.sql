create FUNCTION             "ENCRYPTSTRING" (p_id in varchar2, p_guid in varchar2)  RETURN VARCHAR2 AS
LANGUAGE JAVA NAME 'CryptUtil.encrypt(java.lang.String, java.lang.String) return java.lang.String';


/

