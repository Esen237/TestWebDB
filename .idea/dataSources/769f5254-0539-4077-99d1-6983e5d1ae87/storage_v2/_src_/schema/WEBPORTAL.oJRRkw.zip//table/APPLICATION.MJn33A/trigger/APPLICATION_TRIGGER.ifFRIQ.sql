create trigger APPLICATION_TRIGGER
    before insert
    on APPLICATION
    for each row
    when (new.APPLICATION_ID IS NULL)
BEGIN
    SELECT APPLICATION_SEQ.NEXTVAL
    INTO :new.APPLICATION_ID
    FROM dual;
END;


/

