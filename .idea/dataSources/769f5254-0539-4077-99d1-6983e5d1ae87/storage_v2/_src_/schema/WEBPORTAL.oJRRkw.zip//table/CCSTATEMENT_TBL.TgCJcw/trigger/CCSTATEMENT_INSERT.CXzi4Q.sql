create trigger CCSTATEMENT_INSERT
    before insert
    on CCSTATEMENT_TBL
    for each row
begin
SELECT seq_CCSTATEMENT.NEXTVAL 
  INTO :new.id
  FROM dual;
    
end;


/

