create FUNCTION             "TOTALCUSTOMERS" 
RETURN number IS 
   total number(11) := 0; 
BEGIN 
   SELECT count(*) into total 
   FROM view_tbl WHERE view_name = 'cq_request_list'; 
    
   RETURN total; 
END;


/

