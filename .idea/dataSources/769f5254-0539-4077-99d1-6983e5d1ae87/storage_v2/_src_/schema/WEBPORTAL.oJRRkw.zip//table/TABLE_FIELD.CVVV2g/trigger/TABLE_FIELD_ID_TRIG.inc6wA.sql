create trigger TABLE_FIELD_ID_TRIG
    before insert
    on TABLE_FIELD
    for each row
    when (new.TABLE_FIELD_id is null)
BEGIN 
    SELECT TABLE_FIELD_seq.NEXTVAL
    INTO :new.TABLE_FIELD_id
    FROM dual;
END;


/

