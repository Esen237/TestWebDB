create trigger CONFIG_TRIG
    before insert
    on CONFIG
    for each row
    when (new.CONFIG_ID IS NULL)
BEGIN
    SELECT CONFIG_SEQ.NEXTVAL
    INTO :new.CONFIG_ID
    FROM dual;
end;


/

