create trigger INSERT_CQ
    before insert
    on CQREQUEST_TBL
    for each row
begin
    select cqrequest_seq.nextval into :new.cqrequest_id from dual;
    :new.status_id := 21;
end;


/

