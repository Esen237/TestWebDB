create FUNCTION             "ISEXIST" (v_name in varchar2) 
RETURN number IS 
   total number(11) := 0; 
BEGIN 
   SELECT count(*) into total 
   FROM view_tbl WHERE view_name = v_name; 
   RETURN total; 
END;


/

