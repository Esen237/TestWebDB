create PACKAGE       sdo_ols_presentation AUTHID current_user AS

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  FUNCTION makeOpenLS10Request(
    request XMLTYPE)
      RETURN XMLTYPE;

  FUNCTION specify_theme_for_mapviewer(
    openls_layer    XMLTYPE,
    openls_version  VARCHAR2)
      RETURN XMLTYPE;

  FUNCTION specify_poi_for_mapviewer(
    openls_poi      XMLTYPE,
    openls_version  VARCHAR2)
      RETURN XMLTYPE;

END sdo_ols_presentation;
/

