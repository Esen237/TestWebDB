create package       opg_log as

  NEWLINE      constant char(1) := chr(10);

  DEFAULT_LOG_LEVEL constant integer := 0;

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  --
  -- By default, log goes to trace files
  --
  procedure set_log_output(vcDest varchar2);
  procedure set_log_level(i integer);
  function  get_log_level return integer;

  function is_fatal_enabled     return boolean;
  function is_error_enabled     return boolean;
  function is_warning_enabled   return boolean;
  function is_assertion_enabled return boolean;
  function is_info_enabled      return boolean;
  function is_debug_enabled     return boolean;

  function get_caller_info return varchar2;


  /**
   * The following two methods (fatal, error) will un-ambiguously record
   * the error message, plus line number for this method call,
   * plus exception location if applicable,
   * plus call stack trace.
   * e.g.
   *
   * Case 1: there is no exception. Just an unexpected error condition.
   *    if (...) then
   *      opg_log.error('test3: should never be true');
   *    end if;
   *  ==>
   *    "110015, MDSYS" @time: 0  [error] test3: should never be true
   *    Line# 349 in package body MDSYS.OPG_LOG
   *    Line# 358 in package body MDSYS.OPG_LOG
   *    Line# 367 in package body MDSYS.OPG_LOG
   *    Line# 1 in anonymous block
   *
   * Case 2: there is exception caught in the exception block
   *    begin
   *      ...
   *    exception
   *      when others then
   *        opg_log.error('test1: Caught exception');
   *        raise;
   *    end;
   *  ==>
   *    "110015, MDSYS" @time: 0  [error] test1: Caught exception
   *    ORA-20000: test2 error happened
   *    ORA-06512: at "MDSYS.OPG_LOG", line 342
   *    ORA-06512: at "MDSYS.OPG_LOG", line 352
   *    ORA-06512: at "MDSYS.OPG_LOG", line 358
   *    Line# 361 in package body MDSYS.OPG_LOG
   *    Line# 367 in package body MDSYS.OPG_LOG
   *    Line# 1 in anonymous block
   */
  procedure fatal(vcMsg varchar2);
  procedure error(vcMsg varchar2);

  procedure warning(vcMsg varchar2) ;
  procedure info   (vcMsg varchar2) ;

  procedure debug   (vcMsg varchar2) ;
  procedure debug_nh(vcMsg varchar2) ;

  procedure assert(b boolean, vcMsg varchar2);

  /** Testing (Unit Testing) Code Starts Next. TODO: to be removed before
      production **/
  procedure test;
end;
/

