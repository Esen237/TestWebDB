create PACKAGE       SDO_NDM_TRAFFIC AUTHID current_user AS

TYPE cursor_type IS REF CURSOR;

-- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

PROCEDURE set_log_info(file      IN UTL_FILE.FILE_TYPE);
PROCEDURE log_message(message IN VARCHAR2, show_time IN BOOLEAN);

--  Creates traffic metadata
PROCEDURE create_traffic_metadata;

--  Inserts traffic metadata
PROCEDURE insert_traffic_metadata(network_name IN varchar2,
                                  data_provider IN varchar2,
                                  sampling_id in number,
                                  link_length_column IN varchar2 ,
                                  link_speed_limit_column IN varchar2,
                                  link_traf_attr_name IN varchar2,
                                  traf_attr_unit IN varchar2,
                                  num_time_intervals IN number,
                                  number_of_patterns IN number);

-- Generates traffic user data blob using Java stored procedures
PROCEDURE generate_traffic_user_data(network_name IN varchar2,
                                     sampling_id in number,
                                     link_speed_table in varchar2,
                                     link_const_speed_table in varchar2,
                                     output_table in varchar2,
                                     overwrite_blobs in boolean,
                                     log_loc IN varchar2,
                                     log_file IN varchar2,
                                     open_mode IN varchar2);

PROCEDURE generate_traffic_user_data(network_name IN varchar2,
                                     sampling_id in number,
                                     startOfPeriod IN varchar2,
                                     endOfPeriod IN varchar2,
                                     link_speed_table in varchar2,
                                     link_const_speed_table in varchar2,
                                     output_table in varchar2,
                                     overwrite_blobs in boolean,
                                     log_loc IN varchar2,
                                     log_file IN varchar2,
                                     open_mode IN varchar2);

-- Generates traffic user data blob for one partition
PROCEDURE generate_traf_data_one_part(network_name IN varchar2,
                                      partition_id in number,
                                      sampling_id in number,
                                      link_speed_table in varchar2,
                                      link_const_speed_table in varchar2,
                                      output_table in varchar2,
                                      log_loc IN varchar2,
                                      log_file IN varchar2,
                                      open_mode IN varchar2);

-- Creates views that conform with schema required by NDM
PROCEDURE create_NDM_network(network_name in varchar2,
                             log_loc IN varchar2,
                             log_file IN varchar2,
                             open_mode IN varchar2);


-- Create traffic raw data tables in NDM schema
-- Entry point for all data providers
PROCEDURE create_ndm_traffic_tables(data_provider in varchar2,
                                    network_name in varchar2,
                                    link_pattern_table in varchar2,
                                    speed_pattern_table in varchar2,
                                    ndm_traf_patt_table in varchar2,
                                    ndm_constant_traf_patt_table in varchar2,
                                    sampling_id in number,
                                    log_loc in varchar2,
                                    log_file in varchar2,
                                    open_mode in varchar2);

-- Translate  traffic user data blob for a partition and
-- persist in a table
PROCEDURE translate_user_data(network_name in varchar2,
                              user_data_table_name in varchar2,
                              partition_id in number,
                              sampling_id in number,
                              output_table_name in varchar2,
                              batch_size in number,
                              overwrite in boolean,
                              log_loc IN varchar2,
                              log_file IN varchar2,
                              open_mode IN varchar2);

PROCEDURE translate_user_data_blobs(network_name in varchar2,
                                    user_data_table_name in varchar2,
                                    output_table_name in varchar2,
                                    const_output_table_name in varchar2,
                                    sampling_id in number,
                                    batch_size in number,
                                    log_loc IN varchar2,
                                    log_file IN varchar2,
                                    open_mode IN varchar2);

PROCEDURE translate_user_data_blobs(network_name in varchar2,
                                    user_data_table_name in varchar2,
                                    output_table_name in varchar2,
                                    sampling_id in number,
                                    batch_size in number,
                                    log_loc IN varchar2,
                                    log_file IN varchar2,
                                    open_mode IN varchar2);

PROCEDURE translate_user_data_blobs_part(network_name in varchar2,
                                         user_data_table_name in varchar2,
                                         output_table_name in varchar2,
                                         const_output_table_name in varchar2,
                                         start_partition_id in number,
                                         end_partition_id in number,
                                         sampling_id in number,
                                         batch_size in number,
                                         drop_table in boolean,
                                         log_loc IN varchar2,
                                         log_file IN varchar2,
                                         open_mode IN varchar2);

PROCEDURE generate_traffic_data_blobs(network_name IN varchar2,
                                      sampling_id in number,
                                      link_speed_table_name in varchar2,
                                      output_table_name in varchar2,
                                      overwrite_blobs in boolean,
                                      log_loc IN varchar2,
                                      log_file IN varchar2,
                                      open_mode IN varchar2);

PROCEDURE generate_traffic_data_blobs(network_name IN varchar2,
                                      sampling_id in number,
                                      link_speed_table_name in varchar2,
                                      link_const_speed_table_name in varchar2,
                                      output_table_name in varchar2,
                                      overwrite_blobs in boolean,
                                      log_loc IN varchar2,
                                      log_file IN varchar2,
                                      open_mode IN varchar2);

PROCEDURE set_max_memory_size(bytes NUMBER);

--PROCEDURE grant_file_permissions(log_loc varchar2, log_file varchar2);

PROCEDURE grant_file_permissions(username varchar2 DEFAULT SYS_CONTEXT('userenv', 'CURRENT_USER'),
                                 log_loc varchar2, log_file varchar2);

END SDO_NDM_TRAFFIC;
/

