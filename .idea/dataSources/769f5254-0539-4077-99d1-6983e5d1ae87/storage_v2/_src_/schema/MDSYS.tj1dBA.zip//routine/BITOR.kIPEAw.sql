create procedure bitor wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
6e 9a
FxCZWeN3hoKbOTB03mfyWQPm4cwwg5nnm7+fMr2ywFxal1b6liW4UrLLzKXSXqUossylmYEy
wLIlzKUydDM59DXO7J5Br3Hc4rlBP3GennBDK2Evo/1RCeqv+oLbs3JEfm+ixOgqnApPbSod
pod3/dc=
/

