create type extruded_geom as object(
        geom mdsys.sdo_geometry, min  number, max  number)
/

