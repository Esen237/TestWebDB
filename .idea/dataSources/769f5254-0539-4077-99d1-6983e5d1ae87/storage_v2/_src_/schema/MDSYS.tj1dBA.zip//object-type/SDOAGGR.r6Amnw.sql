create type SDOAggr AUTHID current_user as Object
(
  Geometry mdsys.sdo_geometry,
  Diminfo mdsys.sdo_dim_array,
  call_count  number,
  call_method varchar2(128),
  call_type   number,
  call_value  number,
  static function odciaggregateinitialize(sctx OUT SDOAggr) return number,
  member function odciaggregateiterate(self IN OUT SDOAggr,
               geom IN mdsys.SDOAggrType) return number,
  member function odciaggregateterminate(self IN SDOAggr,
                                         returnValue OUT mdsys.sdo_geometry,
                                          flags IN number)
                     return number,
  member function odciaggregatemerge(self IN OUT SDOAggr,
                    valueB IN  SDOAggr) return number)
/

