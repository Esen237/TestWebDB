create package sdo_sem_downgrade as

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  /**
   * This method will save all model data, rulebase data before an actual
   * database downgrade.
   */
  procedure prepare_downgrade_from_11(
    user_name varchar2
  );

END;
/

