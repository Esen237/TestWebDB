create PROCEDURE       CREATE_SDO_TTS_METADATA(
  tbl_space IN varchar2 default NULL)
IS
  table_not_found exception;
  pragma exception_init(table_not_found, -00942);
BEGIN
  execute immediate 'alter session set current_schema=MDSYS';

  begin
    execute immediate 'DROP TABLE MDSYS.SDO_TTS_METADATA_TABLE FORCE';
    exception
      when table_not_found then NULL;
      when others then
        SYS.DBMS_SYSTEM.KSDWRT(SYS.DBMS_SYSTEM.TRACE_FILE,
                               'EXCEPTION[prvtimd.sql(' || $$PLSQL_LINE || ')1]: ' || SQLERRM);
        RAISE;
  end;

  begin
    execute immediate 'alter session set "_ORACLE_SCRIPT" = true';
    execute immediate
    ' CREATE GLOBAL TEMPORARY TABLE MDSYS.SDO_TTS_METADATA_TABLE AS
      (SELECT * FROM MDSYS.SDO_INDEX_METADATA_TABLE WHERE 1 <> 2) ';
    execute immediate 'alter session set "_ORACLE_SCRIPT" = false';
    exception
      when others then
        SYS.DBMS_SYSTEM.KSDWRT(SYS.DBMS_SYSTEM.TRACE_FILE,
                               'EXCEPTION[prvtimd.sql(' || $$PLSQL_LINE || ')2]: ' || SQLERRM);
        RAISE;
  end;

  execute immediate 'grant select, insert, delete, update on MDSYS.SDO_TTS_METADATA_TABLE to public';

end;
/

