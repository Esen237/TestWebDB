create TYPE sdo_rdf_rowtype
      AS OBJECT
        (tri sdo_rdf_triple_s)
/

