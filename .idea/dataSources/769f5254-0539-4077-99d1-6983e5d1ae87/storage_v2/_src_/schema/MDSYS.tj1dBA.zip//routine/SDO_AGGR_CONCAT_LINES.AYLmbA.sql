create function       SDO_Aggr_Concat_Lines wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
92 be
S4HgxVjBtKe0VH3kL2YdkMxFs4Mwg3kY2ssVfHRnWBKe0Eu4+xu3dRbxhsoFiHvp52sYY42p
+Ar8UPAIEEgurMHFcC2fbuiuKNnkz+R7ncGx/nVNb8Cka6L9zTQumHuypvIZw/mi410abAzf
cvu5TYVZaKGllyFw8vK9kA6Tpzb9B8X7c8BU+7B2xSo=
/

