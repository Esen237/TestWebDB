create TYPE ndm_vector_2d wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
34 65
/mcSmEoB5pm1hTGqmFIghjBEYm0wg5n0dLhchQz68JYMLtH6lhh48sy4dCulv5vAMsvMUGnj
aaWZgTLAsiXM40bCITuIpuV/y2Q=
/

