create package sdo_sem_inf_internal AUTHID CURRENT_USER as

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE copy_network_info_to_pkg_vars;

  procedure get_uid(vcName      in varchar2,
                    vcLitType   in varchar2,
                    vcValueType in varchar2,
                    iID   out int);

  --table containing two number columns (M and G)
  procedure W_create_rules_index(user_name_in      varchar2,
                               index_name_in     varchar2,
                               models_in         mdsys.rdf_models,
                               rulebases_in      mdsys.rdf_rulebases,
                               passes            integer  default 0,
                               inf_components_in varchar2 default null,
                               options           varchar2 default null,
                               delta_in          mdsys.rdf_models default null,
                               ng_tab_name       varchar2,
                               ng_tab_schema     varchar2 default null,
                               inf_ng_name       varchar2 default null,
                               inf_ext_user_func_name varchar2 default null,
                               ols_ladder_inf_lbl_seq varchar2 default null  -- A string a numeric labels
                                                                             -- delimited by a space
                               );

  procedure create_rules_index(user_name_in      varchar2,
                               index_name_in     varchar2,
                               models_in         mdsys.rdf_models,
                               rulebases_in      mdsys.rdf_rulebases,
                               passes            integer  default 0,
                               inf_components_in varchar2 default null,
                               options           varchar2 default null,
                               delta_in          mdsys.rdf_models default null,
                               ng_tab_name       varchar2,
                               ng_tab_schema     varchar2 default null,
                               inf_ng_name       varchar2 default null,
                               inf_ext_user_func_name varchar2 default null,
                               ols_ladder_inf_lbl_seq varchar2 default null  -- A string a numeric labels
                                                                             -- delimited by a space
                               );

  procedure create_ent_views(index_name_in       varchar2,
                             ptn_name_in         varchar2);

  procedure create_clique_views(vcIdx            varchar2,
                                vcCliquePtnName  varchar2);

  function m(i int) return varchar2;
  function build_models_union_clause(models            mdsys.rdf_models,
                                     bJustModels       boolean,
                                     bDefaultGraphOnly boolean) return varchar2;

  function satisfy_restriction_datatype(literal_type         varchar2,
                                        restriction_datatype varchar2,
                                        lax_check            integer default 0)
  return int deterministic PARALLEL_ENABLE;
  pragma restrict_references (satisfy_restriction_datatype,WNDS,WNPS,RNDS);

 end;
/

