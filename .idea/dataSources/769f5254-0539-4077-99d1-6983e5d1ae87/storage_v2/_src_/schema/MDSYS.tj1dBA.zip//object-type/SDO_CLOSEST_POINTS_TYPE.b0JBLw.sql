create TYPE SDO_CLOSEST_POINTS_TYPE
TYPE SDO_CLOSEST_POINTS_TYPE
                                                                      
                                                                      
AS OBJECT (
AS OBJECT (
        dist  NUMBER,
        dist  NUMBER,
        geoma MDSYS.SDO_GEOMETRY,
        geoma MDSYS.SDO_GEOMETRY,
        geomb MDSYS.SDO_GEOMETRY)        geomb MDSYS.SDO_GEOMETRY)
/

