create type sdo_bt_handle
    as object
    (
     btree RAW(4),
     shd   RAW(4)
    )
/

