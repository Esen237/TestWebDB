create TYPE BODY       SDO_INTERACT_LINE_FEAT AS
  MAP MEMBER FUNCTION get_id RETURN VARCHAR2 IS
  BEGIN
    return feature_layer_id || ''-'' || feature_id || ''-'' || link_id;
  END;
END;
/

