create PACKAGE       SDO_GEOR_GDAL AUTHID CURRENT_USER AS

   -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
   PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

   -- NAME:
   --      TRANSLATE
   --
   -- DESCRIPTION:
   --      Translate data and metadata between raster storage formats
   --
   -- ARGUMENTS:
   --
   --  inDirectory     - The name of a Directory object related to the
   --                    file system folder where the input files is.
   --
   --  inFilename      - A file name or any GDAL compatible raster data source
   --                    specification.
   --
   --  inGeoRaster     - A valid initialized sdo_georaster object.
   --
   --
   --  outDirectory    - The name of a Directory object related to the
   --                    file system folder where the output files will be.
   --
   --  outFilename     - A file name or any GDAL compatible raster data source
   --                    specification, same to inFilename.
   --
   --  outGeoRaster    - A valid initialized sdo_georaster object.
   --
   --  options         - Options for GDAL Translate operation. Format 'name=value'
   --                    per options separated by space, " ".
   --      Options       Description
   --      ------------- ------------------------------------------------------------------
   --      format        Output format ("GTiff", etc...)
   --      outputType    Output type {Byte/Int16/UInt16/UInt32/Int32/Float32/Float64/
   --                                 CInt16/CInt32/CFloat32/CFloat64}
   --      bandList      Array of band numbers (index start at 1), ex.: bandList=4,3,2
   --      maskBandList  Array of mask band to generate or not {none,auto,mask,1,...)
   --      srcWin        Subwindow in pixels to extract: [left_x, top_y, width, height]
   --                    ex.: srcWin=10,31,400,800
   --      outsize       Set the size of the output file. Outsize is in pixels and lines
   --                    unless '%' is attached in which case it is as a fraction of the
   --                    input image size.  ex.: outsize=50%,50% ex.: outsize=1024,512
   --      xyRes         Output horizontal resolution, ex.: xyRes=30.0,30.0
   --      projWin       Subwindow in projected coordinates to extract: [ulx, uly, lrx, lry]
   --                    ex.: projWin=-180,-90,0,0
   --      projWinSRS    SRS in which projWin is expressed, ex.: projWinSRS=EPSG:4326
   --      epo           Error when projWin is partially outside. Default is false.
   --      eco           Error when projWin is completely outside. Default is false.
   --      strict        Don't be forgiving of mismatches and lost data when translating
   --                    to the output format.
   --      scale         List of scale parameters, each of the form [src_min,src_max] or
   --                    [src_min,src_max,dst_min,dst_max]
   --      exponentList  Apply non-linear scaling with a power function. Must be positive.
   --                    Used with the scale option. ex.: exponent=10,100
   --      outputBounds  Assigned output bounds: [ulx, uly, lrx, lry]
   --                    ex.: outputBounds=-2933944.992,6435313.447,3619661.104,-118292.648
   --      outputSRS     Assigned output SRS, ex.: outputSRS=EPSG:4326
   --      GCP           Groud Control Points. May be provided multiple times to provide
   --                    a set of GCPs. [pixel line easting northing [elevation]]
   --      noData        List of Nodata value (or "none" to unset it) for each output band.
   --      rgbExpand     Translate a dataset with 1 band with a color table as a dataset
   --                    with 3 (RGB) or 4 (RGBA) bands. Expand a dataset with a color
   --                    table that only contains gray levels to a gray indexed dataset.
   --                    {gray|rgb|rgba}, ex.: rgbExpand=rgb
   --      stats         Calcule statistics. Default is false, ex.: stats=true
   --      rat           Write source RAT. Default is true, ex.: rat=false
   --      resampleAlg   Resampling mode {nearest(default),bilinear,cubic,cubicspline,
   --                                     lanczos,average,mode}, ex.: resample=cubic
   --  createOptions   - Options specific to the output driver. Format 'name=value'
   --                    per options separated by space, " ".
   --                    ex.: "COMPRESS=JPEG-F,GENPYRAMID=NN"
   --
   --  metadataOptions - Assign metadata values specific to the output driver.
   --                    Format 'name=value' per options separated by space, " ".
   --                    ex.: "TIFFTAG_POINTAREA=AREA"
   --
   --  openOptions     - Options specifc for the input driver format.
   --

   PROCEDURE translate -- File to GeoRaster
   (
       inDirectory     IN      VARCHAR2,
       inFilename      IN      VARCHAR2,
       outGeoRaster    IN OUT  MDSYS.SDO_GEORASTER,
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

   PROCEDURE translate -- GeoRaster to File
   (
       inGeoRaster     IN      MDSYS.SDO_GEORASTER,
       outDirectory    IN      VARCHAR2,
       outFilename     IN      VARCHAR2,
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

   PROCEDURE translate -- GeoRaster to GeoRaster
   (
       inGeoRaster     IN      MDSYS.SDO_GEORASTER,
       outGeoRaster    IN OUT  MDSYS.SDO_GEORASTER,
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

   -- NAME:
   --      INFO
   --
   -- DESCRIPTION:
   --      Extract information from a dataset
   --
   -- ARGUMENTS:
   --
   --  inDirectory     - The name of a Directory object related to the
   --                    file system directory where the input files is.
   --
   --  inFilename      - A file name or any GDAL compatible raster data source
   --                    specification.
   --
   --  inGeoRaster     - A valid initialized sdo_georaster object.
   --
   --  options         - Options for GDAL Info operation. Format 'name=value'
   --                    per options separated by space, " ".
   --      Options       Description
   --      ------------- ------------------------------------------------------------------
   --      json          Display the output in json format.
   --      mm            Force computation of the actual min/max values for each band.
   --      stats         Force computation if no statistics are stored in an image.
   --      approx_stats  Force computation if no approximated statistics.
   --      hist          Report histogram information for all bands.
   --      nogcp         Suppress ground control points list printing.
   --      nomd          Suppress metadata printing.
   --      norat         Suppress printing of raster attribute table.
   --      noct          Suppress printing of color table.
   --      checksum      Force computation of the checksum for each band in the dataset.
   --      listmdd       (GDAL >= 1.11) List all metadata domains available for the dataset.
   --      mdd           Report metadata for the specified domain.
   --      sd            Select one subdataset by the sequential oder starting by 1.
   --      proj4         Show SRS in PROJ.4 string style.
   --
   --  openOptions     - Options specifc for the input driver format.
   --                    See comments on TRANSLATE.

   FUNCTION info       -- File
   (
       inDirectory     IN      VARCHAR2,
       inFilename      IN      VARCHAR2,
       options         IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   )
   RETURN VARCHAR2;

   FUNCTION info       -- GeoRaster
   (
       inGeoRaster     IN      MDSYS.SDO_GEORASTER,
       options         IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   )
   RETURN VARCHAR2;

   -- NAME:
   --      DEM
   --
   -- DESCRIPTION:
   --      Process Digital Elevation Models
   --
   -- ARGUMENTS:
   --
   --  inGeoRaster     - A valid initialized sdo_georaster object.
   --
   --  outGeoRaster    - A valid initialized sdo_georaster object.
   --
   --  options         - Options for gdal_translate operation
   --                    Informe name=value for each entering options
   --                    separated by space, " ".
   --
   --  processing      - DEM processing to apply {"hillshade", "slope", "aspect",
   --                    "color-relief", "TRI", "TPI", "Roughness"}:
   --       hillshade    generate shaded relief map from any GDAL-supported elevation raster
   --       slope        generate slope map from any GDAL-supported elevation raster
   --       aspect       generate aspect map from any GDAL-supported elevation raster
   --       color-relief generate color relief map from any GDAL-supported elevation raster
   --       TRI          generate map of Terrain Ruggedness Index from any GDAL-supported
   --                    elevation raster
   --       TPI          generate map of Topographic Position Index from any GDAL-supported
   --                    elevation raster
   --       roughness    generate map of roughness from any GDAL-supported elevation raster
   --
   --  colorDirectory  - The name of a Directory object related to the
   --                    file system directory where the color files is.
   --
   --  colorFilename   - Color file name. Mandatory for "color-relief" processing.
   --
   --  options         - Options for GDAL DEM operation. Format 'name=value'
   --      Options       Description
   --      ------------- ------------------------------------------------------------------
   --      format        Output format ("GTiff", etc...)
   --      computeEdges  Whether to compute values at raster edges.
   --      alg           Select 'ZevenbergenThorne' or 'Horn'
   --      band          Source band number to use
   --      zFactor       (hillshade only) vertical exaggeration used to pre-multiply
   --                    The elevations.
   --      scale         Ratio of vertical units to horizontal.
   --      azimuth       (hillshade only) azimuth of the light, in degrees. 0 if it comes
   --                    from the top of the raster, 90 from the east, ... The default value,
   --                    315, should rarely be changed as it is the value generally used
   --                    to generate shaded maps.
   --      altitude      Hillshade only) altitude of the light, in degrees. 90 if the light
   --                    comes from above the DEM, 0 if it is raking light.
   --      combined      (hillshade only) whether to compute combined shading, a combination
   --                    of slope and oblique shading.
   --      slopeValue    (slope only) "degree" or "percent".
   --      trigonometric (aspect only) whether to return trigonometric angle instead of
   --                    azimuth. 0deg means East, 90deg North, 180deg West, 270deg South.
   --      zeroForFlat   (aspect only) whether to return 0 for flat areas with slope=0,
   --                    instead of -9999.
   --
   --  createOptions   - Options specific to the output driver. Format 'name=value'
   --                    per options separated by space, " ".
   --                    ex.: "COMPRESS=JPEG-F,GENPYRAMID=NN"
   --
   --  metadataOptions - Assign metadata values specific to the output driver.
   --                    Format 'name=value' per options separated by space, " ".
   --                    ex.: "TIFFTAG_POINTAREA=AREA"
   --
   --  openOptions     - Options specifc for the input driver format.
   --

   PROCEDURE dem       -- GeoRaster to GeoRaster
   (
       inGeoRaster     IN      MDSYS.SDO_GEORASTER,
       outGeoRaster    IN OUT  MDSYS.SDO_GEORASTER,
       processing      IN      VARCHAR2 DEFAULT '',
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       colorDirectory  IN      VARCHAR2 DEFAULT '',
       colorFilename   IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

/********** No fylly implemented and/or test yet ********

   -- NAME:
   --      RASTERIZE
   --
   -- DESCRIPTION:
   --      Burns vector geometries into a raster
   --
   -- ARGUMENTS:
   --
   --  inDirectory     - The name of a Directory object related to the
   --                    file system directory where the input files is.
   --  inFilename      - A file name or any GDAL compatible vector data source
   --                    specification.
   --  inGeometry      - A file name or any GDAL compatible raster data source
   --                    specification, see example on TRANSLATE procedure
   --  options         - Options for gdal_translate operation
   --                    Informe name=value for each entering options
   --                    separated by space, " ".
   --
   --      Options       Description
   --      ------------- ------------------------------------------------------------------
   --      bandList      The band(s) to burn values into. Multiple -b arguments may be used
   --                    to burn into a list of bands. The default is to burn into band 1.
   --      invert        Invert rasterization. Burn the fixed burn value, or the burn value
   --                    associated with the first feature into all parts of the image not
   --                    inside the provided a polygon.
   --      allTouched    Enables the ALL_TOUCHED rasterization option so that all pixels
   --                    touched by lines or polygons will be updated, not just those on
   --                    the line render path, or whose center point is within the polygon.
   --                    Defaults to disabled for normal rendering rules.
   --      burnValues    A fixed value to burn into a band for all objects. A list of burn
   --                    values can be supplied, one per band being written to.
   --      attribute     Identifies an attribute field on the features to be used for a
   --                    burn-in value. The value will be burned into all output bands.
   --      3d            Indicates that a burn value should be extracted from the "Z" values
   --                    of the feature. These values are added to the burn value given by
   --                    "burnvalues" or "attribute" if provided. As of now, only points
   --                    and lines are drawn in 3D.
   --      add           Instead of burning a new value, this adds the new value to the
   --                    existing raster. Suitable for heatmaps for instance.
   --      layerName     Indicates the layer(s) from the datasource that will be used for
   --                    input features. May be specified multiple times, but at least one
   --                    layer name or a -sql option must be specified.
   --      format        Same as in TRANSLATE
   --      outputType    Same as in TRANSLATE
   --      nodata        Same as in TRANSLATE
   --      outputSRS     Same as in TRANSLATE
   --      initValue     Pre-initialize the output image bands with these values. However,
   --                    it is not marked as the nodata value in the output file. If only
   --                    one value is given, the same value is used in all the bands.
   --      outputBounds  Same as outbounds in TRANSLATE
   --      xyRes         Same as in TRANSLATE
   --      tap           (target aligned pixels) Align the coordinates of the extent of the
   --                    output file to the values of the -tr, such that the aligned extent
   --                    includes the minimum extent.
   --      outsize       Same as in TRANSLATE
   --
   --  openOptions     - Options specifc for the input driver format.
   --                    See comments on TRANSLATE.

   PROCEDURE rasterize -- Geometry to GeoRaster
   (
       inGeometry      IN      MDSYS.SDO_GEOMETRY,
       outGeoRaster    IN OUT  MDSYS.SDO_GEORASTER,
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

   PROCEDURE rasterize -- Table to GeoRaster
   (
       inTablename     IN      VARCHAR2,
       inColumnname    IN      VARCHAR2,
       outGeoRaster    IN OUT  MDSYS.SDO_GEORASTER,
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

   -- NAME:
   --      CONTOUR
   --
   -- DESCRIPTION:
   --      Builds vector contour lines from a raster elevation model
   --
   -- ARGUMENTS:
   --
   --  inDirectory     - The name of a Directory object related to the
   --                    file system directory where the input files is.
   --  inFilename      - A file name or any GDAL compatible raster data source
   --                    specification.
   --  inGeoRaster     - A valid initialized sdo_georaster object.
   --  outGeometry     - A GEOJson text geometry
   --  outDirectory    - The name of a Directory object related to the
   --                    file system directory where the output files will be.
   --  outFilename     - A file name or any GDAL compatible vector data source
   --  options         - Options for gdal_translate operation
   --                    Informe name=value for each entering options
   --                    separated by space, " ".
   --
   --      Options       Description
   --      ------------- ------------------------------------------------------------------
   --      band          Band to get the DEM from. Defaults to band 1.
   --      attribute     Name for the attribute in which to put the elevation.
   --                    If not provided no elevation attribute is attached.
   --      3d            Force production of 3D vectors instead of 2D.
   --                    Includes elevation at every vertex. Default is false.
   --      inodata       Ignore any nodata value implied in the dataset
   --                    Treat all values as valid. Default is false.
   --      snodata       Input pixel value to treat as "nodata".
   --      format        Create output in a particular file format.
   --                    Default is a GeoJson string as output.
   --      interval      Elevation interval between contours.
   --      offset        Offset from zero relative to which to interpret intervals.
   --      fixlevel      Name one or more "fixed levels" to extract.
   --      layername     Provide a name for the output vector layer. Defaults to "contour".
   --  openOptions     - Options specifc for the input driver format.
   --                    See comments on TRANSLATE.

   PROCEDURE contour -- GeoRaster to Geometry
   (
       outGeoRaster    IN      MDSYS.SDO_GEORASTER,
       outTablename    IN      VARCHAR2,
       inColumnname    IN      VARCHAR2,
       options         IN      VARCHAR2 DEFAULT '',
       datasetOptions  IN      VARCHAR2 DEFAULT '',
       layerOptions    IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

   -- NAME:
   --      GRID
   --
   -- DESCRIPTION:
   --      Creates regular grid from the scattered data
   --
   -- ARGUMENTS:
   --
   --  inGeometry      - A file name or any GDAL compatible raster data source
   --                    specification, see example on TRANSLATE procedure
   --  options         - Options for gdal_translate operation
   --                    Informe name=value for each entering options
   --                    separated by space, " ".
   --
   --      Options       Description
   --      ------------- ------------------------------------------------------------------
   --      format        Output format ("GTiff", etc...)
   --      outputType    Output type {Byte/Int16/UInt16/UInt32/Int32/Float32/Float64/
   --                                 CInt16/CInt32/CFloat32/CFloat64}
   --      outsize       Same as in TRANSLATE
   --      outputSRS     Same as in TRANSLATE
   --      zfield        Identifies an attribute field on the features to be used to get
   --                    a Z value from. This value overrides Z value read from feature
   --                    geometry record (naturally, if you have a Z value in geometry,
   --                    otherwise you have no choice and should specify a field name
   --                    containing Z value).
   --      z_increase    Addition to the attribute field on the features to be used to
   --                    get a Z value from. The addition should be the same unit as Z value.
   --                    The result value will be Z value + Z increase value.
   --                    The default value is 0.
   --      z_multiply    This is multiplication ratio for Z field. This can be used for
   --                    shift from e.g. foot to meters or from elevation to deep. The
   --                    result value will be (Z value + Z increase value) * Z multiply
   --                    value. The default value is 1.
   --      algorithm     Set the interpolation algorithm or data metric name and (optionally)
   --                    its parameters. See INTERPOLATION ALGORITHMS and DATA METRICS
   --                    sections for further discussion of available options.
   --                    Format: [algorithm[:parameter1=value1][:parameter2=value2]...]:
   --                    Example: invdist:power=2.0:smothing=1.0
   --                    Algorithms and parameters:
   --          invdist   Inverse distance to a power. This is default algorithm.
   --              power: Weighting power (default 2.0).
   --              smoothing: Smoothing parameter (default 0.0).
   --              radius1: The first radius (X axis if rotation angle is 0) of
   --                    search ellipse. Set this parameter to zero to use whole point
   --                    array. Default is 0.0.
   --              radius2: The second radius (Y axis if rotation angle is 0) of
   --                    search ellipse. Set this parameter to zero to use whole point
   --                    array. Default is 0.0.
   --              angle: Angle of search ellipse rotation in degrees (counter
   --                    clockwise, default 0.0).
   --              max_points: Maximum number of data points to use. Do not search
   --                    for more points than this number. This is only used if search
   --                    ellipse is set (both radii are non-zero). Zero means that all
   --                    found points should be used. Default is 0.
   --              min_points: Minimum number of data points to use. If less amount
   --                    of points found the grid node considered empty and will be filled
   --                    with NODATA marker. This is only used if search ellipse is set --                    (both radii are non-zero). Default is 0.
   --              nodata: NODATA marker to fill empty points (default 0.0).
   --          invdistnn Inverse distance to a power with nearest neighbor searching,
   --                    ideal when max_points is used. It has following parameters:
   --              power: Weighting power (default 2.0).
   --              radius: The radius of the search circle, which should be non-zero.
   --                    Default is 1.0.
   --              max_points: Maximum number of data points to use. Do not search for
   --                    more points than this number. Found points will be ranked from
   --                    nearest to furthest distance when weighting. Default is 12.
   --              min_points: Minimum number of data points to use. If less amount of
   --                    points found the grid node is considered empty and will be
   --                    filled with NODATA marker. Default is 0.
   --              nodata: NODATA marker to fill empty points (default 0.0).
   --          average   Moving average algorithm. It has following parameters:
   --              radius1: The first radius (X axis if rotation angle is 0) of search
   --                    ellipse. Set this parameter to zero to use whole point array.
   --                    Default is 0.0.
   --              radius2: The second radius (Y axis if rotation angle is 0) of search
   --                    ellipse. Set this parameter to zero to use whole point array.
   --                    Default is 0.0.
   --              angle: Angle of search ellipse rotation in degrees (counter clockwise,
   --                    default 0.0).
   --              min_points: Minimum number of data points to use. If less amount of
   --                    points found the grid node considered empty and will be filled
   --                    with NODATA marker. Default is 0.
   --              nodata: NODATA marker to fill empty points (default 0.0).
   --
   --         Note, that it is essential to set search ellipse for moving average method.
   --         It is a window that will be averaged when computing grid nodes values.
   --
   --          nearest   Nearest neighbor algorithm. It has following parameters:
   --              radius1: The first radius (X axis if rotation angle is 0) of search
   --                    ellipse. Set this parameter to zero to use whole point array.
   --                    Default is 0.0.
   --              radius2: The second radius (Y axis if rotation angle is 0) of search
   --                    ellipse. Set this parameter to zero to use whole point array.
   --                    Default is 0.0.
   --              angle: Angle of search ellipse rotation in degrees (counter clockwise,
   --                    default 0.0).
   --              nodata: NODATA marker to fill empty points (default 0.0).
   --          linear    Linear interpolation algorithm.  The Linear method performs linear
   --                    interpolation by computing a Delaunay triangulation of the point
   --                    cloud, finding in which triangle of the triangulation the point
   --                    is, and by doing linear interpolation from its barycentric
   --                    coordinates within the triangle. If the point is not in any
   --                    triangle, depending on the radius, the algorithm will use the
   --                    value of the nearest point or the nodata value.
   --              radius: In case the point to be interpolated does not fit into a
   --                    triangle of the Delaunay triangulation, use that maximum
   --                    distance to search a nearest neighbour, or use nodata otherwise.
   --                    If set to -1, the search distance is infinite. If set to 0,
   --                    nodata value will be always used. Default is -1.
   --              nodata: NODATA marker to fill empty points (default 0.0).
   --      txe           Set georeferenced X extents of output file to be created.
   --                    Format: txe=xmin,xmax
   --      tye           Set georeferenced Y extents of output file to be created.
   --                    Format: tye=ymin,yman
   --  openOptions     - Options specifc for the input driver format.
   --                    See comments on TRANSLATE.

   PROCEDURE grid -- Geometry to GeoRaster
   (
       inGeometry      IN      MDSYS.SDO_GEOMETRY,
       outGeoRaster    IN OUT  MDSYS.SDO_GEORASTER,
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

   PROCEDURE grid -- Geometry to GeoRaster
   (
       inTablename     IN      VARCHAR2,
       inColumnname    IN      VARCHAR2,
       outGeoRaster    IN OUT  MDSYS.SDO_GEORASTER,
       options         IN      VARCHAR2 DEFAULT '',
       createOptions   IN      VARCHAR2 DEFAULT '',
       metadataOptions IN      VARCHAR2 DEFAULT '',
       openOptions     IN      VARCHAR2 DEFAULT ''
   );

********** No fylly implemented and/or test yet ********/

END SDO_GEOR_GDAL;
/

