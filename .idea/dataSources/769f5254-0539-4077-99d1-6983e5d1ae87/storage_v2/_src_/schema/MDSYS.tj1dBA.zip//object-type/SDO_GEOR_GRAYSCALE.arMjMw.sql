create TYPE       SDO_GEOR_GRAYSCALE
                                                                      
AS OBJECT
(
   cellValue     SDO_NUMBER_ARRAY,
   gray          SDO_NUMBER_ARRAY)
/

