create package       opg_graphop  authid current_user
is
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  procedure create_sub_graph(
                    graph_owner      varchar2,
                    orgGraph         varchar2,
                    newGraph         varchar2,
                    nSrc             number,
                    depth            integer,
                    dop              integer   default 4,
                    nPQThreshold     integer   default 10000,
                    tbs              varchar2  default null,
                    options       in varchar2  default null
                    );

  /**
   * This API makes a clone of the original graph
   */
  procedure clone_graph(
                    orgGraph         varchar2,
                    newGraph         varchar2,
                    dop              integer   default 4,
                    num_hash_ptns    integer   default 8,
                    tbs              varchar2  default null,
                    options       in varchar2  default null
                    );

  /**
   * This API sparsifies a graph. The remaining edges will be stored in
   * the wt_out_tab.
   */
  procedure sparsify_graph(
                    edge_tab_name        varchar2,
                    threshold            number    default 0.5,
                    min_keep             integer   default 1,
                    dop                  integer   default 4,
                    wt_out_tab    in out varchar2,
                    wt_und_tab    in out varchar2,
                    wt_hsh_tab    in out varchar2,
                    wt_mch_tab    in out varchar2,
                    tbs                  varchar2  default null,
                    options       in     varchar2  default null
                    );



  /**
   * This procedure populates the skeletop table (GT$).
   * By default, the content in the existing GT$ table will be removed.
   */
  procedure populate_skeleton_tab(
                    graph            varchar2,
                    dop              integer   default 4,
                    tbs              varchar2  default null,
                    options       in varchar2  default null
                    )
  ;


  /**
   * This API finds connected components in the original graph.
   * All connected components will be stored in the given wt_clusters.
   * The wt_clusters is supposed to have these two columns: (vid, cluster_id)
   * Note that the original graph will be treated as undirected.
   */
  procedure find_cc_mapping_based(
                    edge_tab_name         varchar2,
                    wt_clusters   in out  varchar2,
                    wt_undir      in out  varchar2,
                    wt_cluas      in out  varchar2,
                    wt_newas      in out  varchar2,
                    wt_delta      in out  varchar2,
                    dop                   integer   default 4,
                    rounds                integer   default 0,  -- continue till all CC founds
                    tbs                   varchar2  default null,
                    options       in      varchar2  default null
                    );

  /**
   * This API finds connected components in the original graph.
   * All connected components will be stored in the given wt_clusters.
   * The wt_clusters is supposed to have these two columns: (vid, cluster_id)
   * Note that the original graph will be treated as undirected.
   *
   * TODO: apply the techniques used in incremental inference to
   * speed up joins.
   */
  procedure find_cc(
                    edge_tab_name         varchar2,
                    wt_clusters   in out  varchar2,
                    wt_undir      in out  varchar2,
                    wt_cluas      in out  varchar2,
                    wt_newas      in out  varchar2,
                    wt_delta      in out  varchar2,
                    dop                   integer   default 4,
                    rounds                integer   default 0,  -- continue till all CC founds
                    tbs                   varchar2  default null,
                    options       in      varchar2  default null
                    );
end;
/

