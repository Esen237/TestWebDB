create Type location_msg as object (
        object_id INTEGER,
        time      TIMESTAMP,
        x         NUMBER,
        y         NUMBER)
/

