create TYPE       sdo_geor_stat AS OBJECT(
    m_max        NUMBER,
    m_min        NUMBER,
    m_pix        NUMBER,
    m_sum        NUMBER,
    m_sum2       NUMBER
   )
/

