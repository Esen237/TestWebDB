create package sem_rdfsa_const authid current_user is
   --- secure options passed to APPLY_OLS_POLICY API --
   --
   SECURE_SUBJECT             CONSTANT SIMPLE_INTEGER := 1;

   SECURE_PREDICATE           CONSTANT SIMPLE_INTEGER := 2;
   SECURE_OBJECT              CONSTANT SIMPLE_INTEGER := 4;

   --
   --- Additional options for OLS enable RDF data --
   --
   -- DEFINE_BEFORE_USE: subject or predicate, when secured should be
   -- pre-defined with a label (set_resource_label/set_predicate_label)
   -- before they can be used in a triple -
   OPT_DEFINE_BEFORE_USE      CONSTANT SIMPLE_INTEGER := 16;
   -- RELAX_TRIPLE_LABEL: The default behavior is that the Triple's label
   -- dominates the labels associated with each of its components.
   -- With this option, a triple label is set to user's initial row
   -- label and the only check performed at the time of triple insertion
   -- is that the user has READ access to its components.
   OPT_RELAX_TRIPLE_LABEL     CONSTANT SIMPLE_INTEGER := 32;

   --Added by Vlad
   TRIPLE_LEVEL_ONLY          CONSTANT SIMPLE_INTEGER := 64;

   --
   --- Resource options for Inference Label Generators
   --
   USE_SUBJECT_LABEL          CONSTANT SIMPLE_INTEGER := 128;
   USE_PREDICATE_LABEL        CONSTANT SIMPLE_INTEGER := 512;
   USE_OBJECT_LABEL           CONSTANT SIMPLE_INTEGER := 1024;
   USE_RULE_LABEL             CONSTANT SIMPLE_INTEGER := 2048;
   USE_DOMINATING_LABEL       CONSTANT SIMPLE_INTEGER := 4096;
   USE_ANTECED_LABELS         CONSTANT SIMPLE_INTEGER := 8192;
   CUSTOM_LABELGEN            CONSTANT SIMPLE_INTEGER := 16384;

   --
   ---  Predefined label generators for inference. To be used with
   ---  create_entailment API.
   --
   LABELGEN_SUBJECT           CONSTANT mdsys.rdfsa_labelgen :=
                                 mdsys.rdfsa_labelgen(USE_SUBJECT_LABEL);
   LABELGEN_PREDICATE         CONSTANT mdsys.rdfsa_labelgen :=
                                 mdsys.rdfsa_labelgen(USE_PREDICATE_LABEL);
   LABELGEN_OBJECT            CONSTANT mdsys.rdfsa_labelgen :=
                                 mdsys.rdfsa_labelgen(USE_OBJECT_LABEL);
   LABELGEN_RULE              CONSTANT mdsys.rdfsa_labelgen :=
                                 mdsys.rdfsa_labelgen(USE_RULE_LABEL);
   LABELGEN_DOMINATING        CONSTANT mdsys.rdfsa_labelgen :=
                                 mdsys.rdfsa_labelgen(USE_DOMINATING_LABEL);

   VPD_FULL_ACCESS            CONSTANT VARCHAR2(32) := 'RDFVPD$FULLACCESS';

end sem_rdfsa_const;
/

