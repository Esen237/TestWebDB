create procedure       rdf$grant_ols_privs authid current_user  is
begin
execute immediate 'grant select on lbacsys.DBA_SA_TABLE_POLICIES to mdsys';
execute immediate 'grant select on lbacsys.DBA_SA_LABELS to mdsys';
execute immediate 'grant select on lbacsys.DBA_SA_GROUPS to mdsys';
execute immediate 'grant select on lbacsys.DBA_SA_LEVELS to mdsys';
execute immediate 'grant select on lbacsys.DBA_SA_COMPARTMENTS to mdsys';
execute immediate 'grant execute on lbacsys.NUMERIC_DOMINATES to mdsys';
end;
/

