create PROCEDURE ElocationSetJVMHeapSize(sz NUMBER)  IS
BEGIN
    SDO_JAVA_STP.ElocationSetJVMHeapSize(sz);
END;
/

