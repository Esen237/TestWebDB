create type AggrConcat AUTHID current_user as Object
(
  -- context mdsys.SDOAggr,
  -- use PL/SQL instead of Safe-C
  -- bug 31844560: sdo_aggr_concat_line with group by
  context raw(4),
  static function odciaggregateinitialize(sctx IN OUT AggrConcat)
              return number,
  member function odciaggregateiterate(self IN OUT AggrConcat,
               geom IN mdsys.SDO_GEOMETRY) return number,
  member function odciaggregateterminate(self IN AggrConcat,
                                 returnValue OUT mdsys.sdo_geometry,
                                 flags IN number)
                     return number,
  member function odciaggregatemerge(self IN OUT AggrConcat,
                    sctx2 IN  AggrConcat) return number);
/

