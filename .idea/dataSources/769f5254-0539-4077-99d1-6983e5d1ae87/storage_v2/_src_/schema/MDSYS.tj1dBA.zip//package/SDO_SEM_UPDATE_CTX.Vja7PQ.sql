create package sdo_sem_update_ctx as

   SDO_SEM_UPDATE_CTX constant varchar2(20) := 'SDO_SEM_UPDATE_CTX';

   -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
   PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

   procedure set_param(name in varchar2,
                       value in varchar2);

   function get_param( name in varchar2) return varchar2;

end sdo_sem_update_ctx;
/

