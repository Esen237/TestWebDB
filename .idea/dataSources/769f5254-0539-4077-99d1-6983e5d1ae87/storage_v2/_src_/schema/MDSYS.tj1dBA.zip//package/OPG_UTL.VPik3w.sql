create package       opg_utl as

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  function get_scn return number;


   GET_STATS constant varchar2(1000) := '
    select name, value from (
      select ''stat.. '' || n.name name, t.value  value
        from v$mystat   t join v$statname n on t.statistic# = n.statistic#
       where n.name in (''redo size'', ''db block gets'', ''consistent gets'',
                        ''physical reads'',''sorts (memory)'',''sorts (disk)'',
                        ''recursive calls'',''redo write time'',
                        ''physical writes'',''rows processed'',
                        ''bytes sent via SQL*Net to client'',
                        ''bytes received via SQL*Net from client'',
                        ''SQL*Net roundtrips to/from client'')
          or (n.name like ''%ga %'')
          or (n.name like ''%direct temp%'')
    union all
      select ''latch. '' || n.name name, n.gets  value
        from v$latch n
       where n.name in (''library cache pin'', ''library cache pin allocation'',
                        ''library cache'', ''shared pool'')
     )
     order by name
  ';


  -- v$sesstat does not help much
  GET_STATS_NEW constant varchar2(1000) := '
    select name, value from (
      select ''stat.. '' || n.name name, t.value  value
        from v$sesstat   t join v$statname n on t.statistic# = n.statistic#
       where t.sid = sys_context(''userenv'',''sid'')  and
          (n.name in (''redo size'', ''db block gets'', ''consistent gets'',
                        ''physical reads'',''sorts (memory)'',''sorts (disk)'',
                        ''recursive calls'',''redo write time'',
                        ''physical writes'',''rows processed'',
                        ''bytes sent via SQL*Net to client'',
                        ''bytes received via SQL*Net from client'',
                        ''SQL*Net roundtrips to/from client'')
          or (n.name like ''%ga %'')
          or (n.name like ''%direct temp%''))
    union all
      select ''latch. '' || n.name name, n.gets  value
        from v$latch n
       where n.name in (''library cache pin'', ''library cache pin allocation'',
                        ''library cache'', ''shared pool'')
     )
     order by name
  ';


  procedure exe_plan_prepare;

  procedure exe_plan_dump;

  function get_elapsed_time_in_sec(nStart number) return varchar2;

  function bool_to_str(b in boolean) return varchar2;

  /**
   * Get the value of the iPos'th number out from
   * the given string that is delimited by a single space ' '
   *
   * @param iPos MUST be a positive integer.
   */
  function get_number_in_pos(vcVal in varchar2,
                             iPos  in int ) return number;


  function get_columnar_compress_syn return varchar2;


  function get_parameter(vcOptions in varchar2,
                            vcMark in varchar2,
                             vcEnd in varchar2 default null) return varchar2;


  function get_string_parameter(vcOptions in varchar2,
                                   vcMark in varchar2,
                                    vcEnd in varchar2 default null) return varchar2;


  function get_int_parameter(vcOptions in varchar2,
                                vcMark in varchar2) return int;



  /**
   * If returns NULL, it means that MDSYS has no privilege to read
   */
  function get_session_parallel_query_dop return number;


  /**
   * If returns NULL, it means that MDSYS has no privilege to read
   */
  function get_session_parallel_dml_dop return number;


    -- This function is added because we have observed negative rowcounts returned during inference.
  -- We noticed that in cases when more than 2^31 rows are returned,
  -- sql%rowcount overflows and we need to add 2^32 to the end result to get the right count.
  -- See bug 8585355 for details.
  -- Vlad, 6/9/2009
  function get_safe_rowcount(cnt int) return int;


  /**
   * This procedure configures the trace setting
   */
  procedure process_trace_setting(options varchar2);


  /**
   * This function returns a unique name
   * that can be used to create an intermediate
   * working table
   * Note that session ID will be used as part of the
   * table name.
   * Also, marker will be included in the name to differentiate
   * different categories of tables.
   */
  function generate_graph_tmp_work_tab(
   graph  in varchar2,
   marker in varchar2 default '$TW'
   )
  return varchar2;


  /**
   * This function returns a unique name
   * that can be used to create an intermediate
   * working table
   * Note that session ID will be used as part of the
   * table name.
   * Also, marker will be included in the name to differentiate
   * different categories of tables.
   */
  function generate_graph_tmp_work_tab(
   graph  in varchar2,
   sid    in integer,
   marker in varchar2 default '$TW'
   )
  return varchar2;

  /**
   * This function returns " compress nologging " when
   * options is null and tbs is null.
   * When there are tablespace setting, a "tablespace ..." clause
   * will be added.
   *
   * This function is to be used when create a table.
   */
  function get_compress_nolog_tbs(
    tbs in varchar2, options in varchar2) return varchar2;


  /**
   * This function returns " compress nologging " when
   * options is null and tbs is null.
   * When there are tablespace setting, a "tablespace ..." clause
   * will be added.
   *
   * This function is to be used when create a table.
   */
  function get_compress_nolog_tbs_set(
    tbs in varchar2, options in varchar2) return varchar2;

  /**
   * This function returns either an empty string or something
   * like "tablespace ...." clause
   *
   * This function is to be used when create an index.
   */
  function get_tbs_clause(
    tbs in varchar2) return varchar2;


  /**
   * This function returns storage clause to be used in CREATE TABLE or INDEX
   */
  function get_storage_clause return varchar2;
end;
/

