create type       sdo_geom_path_elem as object ( path mdsys.StringList, geom mdsys.sdo_geometry, arrIndex number )
/

