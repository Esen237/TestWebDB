create PACKAGE BODY       SDO_CSWADM AS

--------------------------------------------------------------------------------
-- Description:
-- Registers an XSD
--------------------------------------------------------------------------------

procedure register_xsd
(
    xsd_url      IN VARCHAR2,
    xsd_doc_lob  IN CLOB
)
AS

    m            NUMBER := 0;
    stmt         VARCHAR2(1000);

BEGIN

    NULL;
/*
    --dbms_output.put_line('Checking DBA_XML_SCHEMAS table...');
    stmt :=
        'select count(*) from SYS.DBA_XML_SCHEMAS where owner=''MDSYS'' AND SCHEMA_URL = :1';
    execute immediate stmt into m using xsd_url;
    --dbms_output.put_line('Is XSD Schema ' || xsd_url || ' registered?: ' || m);

    IF (m = 0) THEN
        --dbms_output.put_line('Registering XSD Schema ' || xsd_url);
        DBMS_XMLSCHEMA.registerSchema(
            SCHEMAURL  => xsd_url,
            SCHEMADOC  => xsd_doc_lob,
            LOCAL      => TRUE,
            GENTYPES   => FALSE,
            GENBEAN    => FALSE,
            -- This parameter does not exist when registering CLOB: GENTABLES  => FALSE,
            FORCE      => TRUE,
            -- This parameter does not exist when registering CLOB: CSID       => nls_charset_id('AL32UTF8'),
            OWNER      => 'MDSYS', -- Added to use full signature with CLOB register
            OPTIONS    => DBMS_XMLSCHEMA.REGISTER_BINARYXML);
        --dbms_output.put_line('Registered XSD Schema ' || xsd_url);

    END IF;
    */

END;


--------------------------------------------------------------------------------
-- Description:
-- Registers the XSDS corresponding to the xsd_type where each XSD is fetched
-- from MDSYS.SDO_XSD_TABLE (old name MDSYS.CSW_XSD_TABLE$).
-- xsd_type could be DCMI, ISO19139 or INSPIRE.
--------------------------------------------------------------------------------

procedure register_xsds
(
    --record_type_name      IN VARCHAR2,
    --record_type_namespace IN VARCHAR2,
    xsd_type              IN VARCHAR2

)
AS

    dmlStr    VARCHAR2(1000);
    type      cursor_type is REF CURSOR;
    query_crs cursor_type;

BEGIN

    BEGIN
        dmlStr := 'select XSD_ID, XSD_DOC, XSD_NAME, XSD_URL' ||
                  ' from MDSYS.SDO_XSD_TABLE where XSD_NAME = :1';
        OPEN query_crs FOR dmlStr USING xsd_type;
        LOOP
        DECLARE
           XSD_ID     NUMBER;
           XSD_DOC    CLOB;
           XSD_NAME   VARCHAR2(80);
           XSD_URL    VARCHAR2(1000);
        BEGIN
           FETCH query_crs INTO XSD_ID, XSD_DOC, XSD_NAME, XSD_URL;
           EXIT WHEN query_crs%NOTFOUND ;
               BEGIN
                   --dbms_output.put_line('Registering: ' || xsd_url);
                   register_xsd(XSD_URL, XSD_DOC);
                   --EXCEPTION WHEN OTHERS THEN NULL;
               END;
        END;
        END LOOP;
        CLOSE query_crs;
        --EXCEPTION WHEN OTHERS THEN NULL;
    END;

    -- COMMIT;
END;


--------------------------------------------------------------------------------
-- Cleanup MDSYS.SDO_XSD_TABLE (old name MDSYS.CSW_XSD_TABLE$) for a specific
-- XSD type i.e., DCMI, ISO19139 or INSPIRE.
-- owner is MDSYS by default.
--------------------------------------------------------------------------------

procedure delete_from_SDO_XSD_TABLE
(
    xsd_type IN VARCHAR2,
    owner    IN VARCHAR2 DEFAULT 'MDSYS'
)
AS

BEGIN

   IF (xsd_type NOT IN ('DCMI', 'ISO19139', 'INSPIRE')) THEN
       MDSYS.MDERR.raise_md_error(
             'MD', 'SDO', -55161, 'wrong XSD Type parameter.');
   END IF;

   DELETE FROM MDSYS.SDO_XSD_TABLE WHERE XSD_NAME = xsd_type;
   COMMIT;

END;


--------------------------------------------------------------------------------
-- Delete XSD schema corresponding to the xsd_url if it exists.
--------------------------------------------------------------------------------

procedure delete_schema
(
    xsd_url IN VARCHAR2

)
AS

   stmt VARCHAR2(1000);
   m    NUMBER := 0;

BEGIN

    NULL;
    /*
   --dbms_output.put_line('Checking DBA_XML_SCHEMAS table...');
   stmt :=
        'select count(*) from SYS.DBA_XML_SCHEMAS where owner=''MDSYS'' AND SCHEMA_URL = :1';
    execute immediate stmt into m using xsd_url;
    --dbms_output.put_line('Is XSD Schema ' || xsd_url || ' registered?: ' || m);

    IF (m > 0) THEN
        --dbms_output.put_line('Deleting registered XSD schema with URL:' || xsd_url);
        DBMS_XMLSCHEMA.deleteSchema(xsd_url, DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE);
        --dbms_output.put_line('Deleted registered XSD schema with URL:' || xsd_url);
    END IF;
    */
END;


END; -- End of SDO_CSWADM package
/

