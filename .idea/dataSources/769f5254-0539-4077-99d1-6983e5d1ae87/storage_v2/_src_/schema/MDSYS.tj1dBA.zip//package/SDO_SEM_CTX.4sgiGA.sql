create package sdo_sem_ctx as
  --
  -- Constants
  --

  -- Note: this context should be created using
  -- create context SDO_SEM_CTX using mdsys.SDO_SEM_CTX accessed globally;
  SDO_SEM_CTX constant varchar2(20) := 'SDO_SEM_CTX';

  LOG_LEVEL   constant varchar2(20) := 'LOG_LEVEL';

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  --
  -- APIs
  --
  procedure set_param( name in varchar2,
                      value in varchar2);


  function get_param( name in varchar2) return varchar2;

  --
  -- APIs: convenient wrappers
  --
  procedure set_log_level(value in varchar2);
  function get_log_level return varchar2;
end;
/

