create FUNCTION OGC_SRID(
  g ST_Geometry)
    RETURN Integer IS
BEGIN
  RETURN g.ST_SRID();
END OGC_SRID;
/

