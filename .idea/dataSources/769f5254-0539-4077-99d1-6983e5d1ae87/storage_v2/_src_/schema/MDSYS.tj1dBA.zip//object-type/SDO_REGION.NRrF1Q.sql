create TYPE SDO_REGION
TYPE SDO_REGION
                                                                      
                                                                      
AS OBJECT (
AS OBJECT (
        id number,
        id number,
        geometry mdsys.sdo_geometry)         geometry mdsys.sdo_geometry)
/

