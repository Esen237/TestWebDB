create procedure georenabledisable wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
81 b6
iE8/gBkXX+t1zrQs6Pj0zV06Kdswg5nnm7+fMr2ywFxarteW8tcMWZehLvpWOcyrQa//HJ5B
P544SjX/HEo1YHue4j9K3CLi0co1nWkPSbHKLkTGcETRSeq/riTRRAJwH7Uwv+q1DjCunS8A
Lx3lGYIEojfX1hNr3tdD/MHg16amGAbvKw==
/

