create type       sdo_geom_path_info_elem as object (pathInfo mdsys.sdo_geom_path_info, pkcol varchar2(4000), tableName varchar2(61))
  alter type       sdo_geom_path_info_elem modify attribute (tableName varchar2(257)) cascade including table data
/

