create view WORKFLOWINSTANCEAUTOMATEDTASKVIEW as
select distinct wi.Id as WORKFLOWINSTANCEID from WORKFLOWINSTANCE wi 
                    join WORKFLOWINSTANCETASK wit on wi.LASTEXECUTEDTASKID=wit.ID
                    join WORKFLOWTASKDEFINITION wtd on wtd.ID=wit.TASKDEFINITIONID
                    join WORKFLOWTASKDEFINITIONACTION wtda on wtda.SOURCETASKDEFINITIONID=wtd.Id and wtda.ISRETRYACTION=1 and wtda.ISREENTRY=1
                    where wi.STATUS=10 and wi.CREATEDAT> sysdate-120 and wit.STATUS=10 and wtd.TASKTYPE=30  and wit.AUTORETRYCOUNTEXCEEDED!=1
/

