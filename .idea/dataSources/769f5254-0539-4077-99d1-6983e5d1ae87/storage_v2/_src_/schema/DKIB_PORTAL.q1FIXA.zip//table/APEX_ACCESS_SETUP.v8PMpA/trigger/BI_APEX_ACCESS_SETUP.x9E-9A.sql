create trigger BI_APEX_ACCESS_SETUP
    before insert or update
    on APEX_ACCESS_SETUP
    for each row
begin
if inserting and :new.id is null then
select apex_access_control_seq.nextval into :new.id from dual;
end if;
if :new.application_id is null then
:new.application_id := v('APP_ID');
end if;
end;


/

