create view CBS_DAILY_GL_BALANCES as
select to_Date(lpad(gun,2,0)||lpad(ay,2,0)||yil,'DDMMYYYY') report_date,bolum_kodu,numara,doviz_kod,bakiye,bakiye_lc from cbs_dkhesap_gunluk_bakiye 
order by numara

/

