create view CBS_DAILY_GL_BALANCES_KG005 (REPORT_DATE, FILIAL, NBS, SUMA) as
select to_Date(lpad(gun,2,0)||lpad(ay,2,0)||yil,'DDMMYYYY') report_date, 
       substr(numara,1,5),bakiye,bakiye_lc from cbs_dkhesap_gunluk_bakiye 
order by numara
/

