create view CBS_DAILY_GL_TURNOVER as
select satir_hesap_numara, 
fis_muhasebelestigi_tarih, 
satir_doviz_kod, 
sum(decode(satir_tur,'A',SATIR_LC_TUTAR,0)) satir_lc_tutar_Credit, 
sum(decode(satir_tur,'A',SATIR_DV_TUTAR,0)) satir_DV_tutar_CREDIT, 
sum(decode(satir_tur,'B',SATIR_LC_TUTAR,0)) satir_lc_tutar_DEBIT, 
sum(decode(satir_tur,'B',SATIR_DV_TUTAR,0)) satir_DV_tutar_DEBIT 
 from cbs_vw_fis_satir 
where satir_hesap_tur_kodu='DK' 
group by satir_hesap_numara, 
fis_muhasebelestigi_tarih, 
satir_doviz_kod 
order by satir_hesap_numara

/

