create PACKAGE Pkg_Int_Account IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION GetCustomerInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetCustomerAccounts(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetAccountTypeName(ps_modul_tur_kod VARCHAR2 ) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetCustomerAccountDetails(pn_account_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetAccountHistory(pn_account_no IN VARCHAR2,
						   pd_start_date 	IN VARCHAR2,
						   pd_end_date 		IN VARCHAR2,
						   pd_islem_tur		IN VARCHAR2 DEFAULT '%',
						   pd_hareket		IN VARCHAR2 DEFAULT '%',
						   pd_alt_sinir     IN VARCHAR2,
						   pd_ust_sinir     IN VARCHAR2,
						   pd_lang     IN VARCHAR2,
		 				   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetAccountSort(ps_modul IN VARCHAR2,ps_urun IN VARCHAR2,ps_sinif IN VARCHAR2) RETURN NUMBER ;
-----------------------------------------------------------------------------------
FUNCTION GetAccountPaymentPolicyInfo(pn_account_no IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetAccountType(ps_tur IN NUMBER,ps_urun IN VARCHAR2,ps_sinif IN VARCHAR2) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION GetStaffInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetTranAccounts(pn_musteri_no IN VARCHAR2,ps_currcode IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetBranchCodes(ps_langcd IN VARCHAR2,ps_bankcd IN VARCHAR2,ps_citycd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetInterestRate(ps_trantype IN VARCHAR2,
		 					ps_vade1 IN VARCHAR2,
		 					pn_vade2 IN VARCHAR2,
							ps_currency	 IN VARCHAR2,
		 					pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION CreateCurrentAccount(ps_customerid IN VARCHAR2,
		 					ps_modul_tur IN VARCHAR2,
		 					pn_urun_tur IN VARCHAR2,
							ps_urun_sinif IN VARCHAR2,
							ps_doviz_kod IN VARCHAR2,
							ps_bolum_kodu IN VARCHAR2,
							ps_nickname IN VARCHAR2,
							ps_cek_karnesi IN VARCHAR2,
							ps_hesap_hareket_kodu IN VARCHAR2,
							ps_dekont IN VARCHAR2,
							ps_ekstre_kodu IN VARCHAR2,
							ps_esas_gun_sayisi IN VARCHAR2,
		 					pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetCreditClc(ps_amount IN VARCHAR2,
		 			  ps_currencycode IN VARCHAR2,
                      ps_loannumber IN VARCHAR2,
					  ps_taksit_index IN VARCHAR2,
					  ps_startdate IN VARCHAR2,
					  ps_credittype IN VARCHAR2,
					  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetCustomerIdFromAccount(ps_account_no IN VARCHAR2,
					  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetVirmanHesapInfo(ps_account_no IN VARCHAR2,
		 					ps_currency IN VARCHAR2,
					        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetSonrakiIsGunu(ps_date IN VARCHAR2,
					        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetSureSonra(ps_date IN VARCHAR2,
					        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetUygunVadeOraniforDate(ps_date IN VARCHAR2,
                                  ps_currcode IN VARCHAR2,
      			                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetUygunVadeOraniforExactDate(ps_date IN VARCHAR2,
                                  ps_currcode IN VARCHAR2,
      			                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION CreateTimeDepositeAccount(ps_customerid IN VARCHAR2,
                                   ps_modultur IN VARCHAR2,
                                   ps_uruntur IN VARCHAR2,
                                   ps_urunsinif IN VARCHAR2,
                                   ps_nickname IN VARCHAR2,
								   ps_currcode IN VARCHAR2,
                                   ps_anapara IN VARCHAR2,
                                   ps_valortarihi IN VARCHAR2,
								   ps_borckaydi IN VARCHAR2,
								   ps_borcluhesapnumarasi IN VARCHAR2,
								   ps_muhabirhesapnumarasi IN VARCHAR2,
								   ps_dknumarasi IN VARCHAR2,
								   ps_vade_islem_bilgisi IN VARCHAR2,
								   ps_ara_odeme_bilgisi IN VARCHAR2,
                                   ps_otomatik_temdit IN VARCHAR2,
                                   ps_periodsure IN VARCHAR2,
                                   ps_periodcins IN VARCHAR2,
                                   ps_sonraki_baslangic_tarihi IN VARCHAR2,
                                   ps_ara_odeme_islem_bilgisi IN VARCHAR2,
                                   ps_vade_tarihi IN VARCHAR2,
                                   ps_geri_donus_hesap_numarasi IN VARCHAR2,
                                   ps_esas_gun_sayisi IN VARCHAR2,
                                   ps_faiz_orani IN VARCHAR2,
                                   ps_aciklama IN VARCHAR2,
                                   ps_sube IN VARCHAR2,
								   ps_acilistarihi IN VARCHAR2,
      			                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetTranAccountsForCurrcode(pn_musteri_no IN VARCHAR2,ps_currcode IN VARCHAR2,pc_ref OUT CursorReferenceType)
RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetBankDate(dummyvalue IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetCustomerTDAccountCount(ps_customerid IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION CloseTimeDepositAcount(ps_customerid IN VARCHAR2,
		 						ps_hesapnumarasi IN VARCHAR2,
								ps_dovizkodu IN VARCHAR2,
								ps_aciklama IN VARCHAR2,
								ps_odemesekli IN VARCHAR2,
								ps_odenecekhesap IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION ControlSameCurrecyAccount
(pn_musteri_no IN VARCHAR2,ps_currcode IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------------
FUNCTION SetEkstreInfo(ps_accountNo IN VARCHAR2,
		               p_hesapEkstre IN VARCHAR2,
		               p_dovizEkstre IN VARCHAR2,
					   p_ekstreEMail IN VARCHAR2,
                       p_hesapekstreperiod IN VARCHAR2,
 					   p_kurekstreperiod IN VARCHAR2,
   					   p_kurEMail IN VARCHAR2,
   					   p_personID IN VARCHAR2,
   					   p_varlik IN VARCHAR2,
     		   	       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetEkstreInfo(ps_accountNo IN VARCHAR2,
                       ps_type IN VARCHAR2,
     		   	       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetTRYValue(ps_YtlValue IN VARCHAR2,
     		   	       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION TXDecont(pn_txno IN VARCHAR2,
                  ps_accountno IN VARCHAR2,
			           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION HesapMusteriKontrol(pn_accountNo  IN VARCHAR2,
                             pn_customerNo IN VARCHAR2,
			                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION HesapEkstreleriSil(pn_customerNo IN VARCHAR2,
			                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION FinSumHoldingsList(pn_customerNo IN VARCHAR2,
			                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION FinSumHoldings(pn_customerNo IN VARCHAR2,
			                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION FinSumLiabilities(pn_customerNo IN VARCHAR2,
			              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION FinSumTotalHoldings(pn_customerNo IN VARCHAR2,
			              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION FinSumTotalLiabilities(pn_customerNo IN VARCHAR2,
			              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION BakiyeYeterlimi(pn_hesapNumarasi IN VARCHAR2,
					pn_miktar IN VARCHAR2,
	                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
------------------------------------------------------------------------------------
FUNCTION GetCustomerExtAccountDetails(pn_extaccount_no IN VARCHAR2,
		 							  ps_doviz IN VARCHAR2,
		 							  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION GetTranStatement(pn_txno IN VARCHAR2,
		 				  pn_custno IN VARCHAR2,
		 				  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION GetTxDate (pn_islem_no IN NUMBER) RETURN DATE;
------------------------------------------------------------------------------------
FUNCTION GetIntStatementHeader(pn_hesapno IN VARCHAR2,
		 					   pd_startdate IN VARCHAR2,
							   pd_enddate IN VARCHAR2,
 							   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION GetIntStatementBalance(pn_hesapno IN VARCHAR2,
		 					   pd_startdate IN VARCHAR2,
							   pd_enddate IN VARCHAR2,
 							   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION JoinAccounts (ps_custno VARCHAR2,
      	 			   ps_relcustno VARCHAR2,
      				   ps_relaccounts VARCHAR2,
	  				   ps_channelcd VARCHAR2,
					   ps_trantype VARCHAR2,
					   pc_ref OUT   cursorreferencetype) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------
FUNCTION GetCustomerJoinAccounts (ps_custno VARCHAR2,
	  				   			  ps_channelcd VARCHAR2,
					   			  pc_ref OUT   cursorreferencetype) RETURN VARCHAR2;
---------------------------------------------------------------------------------------
FUNCTION DeleteCustomerJoinAccounts (ps_custno  IN VARCHAR2,
		 							 ps_relcustno IN VARCHAR2,
									 ps_relaccountno IN VARCHAR2,
	  				   			  	 ps_channelcd IN VARCHAR2,
									 ps_newstatus IN VARCHAR2,
									 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetExtAccountDetails(pn_extaccount_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION SumLoanAmount(pn_customerno IN VARCHAR2,
		 			   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetRetailLoans(pn_customerno IN VARCHAR2,
		 			    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetLoansInfo(pn_accountno IN VARCHAR2,
		 			    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetTxStatement(pn_txno IN VARCHAR2,
		 				pn_custno IN VARCHAR2,
		 				pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetNonResidentDetail(pn_customerno IN VARCHAR2,
		 			    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION ExtAccountControl(pn_currency      IN VARCHAR2,
		 				   pn_accountno  IN VARCHAR2,
			               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetCustTranAccounts(pn_musteri_no IN VARCHAR2,
		 					 ps_currcode IN VARCHAR2,
							 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION ArbitrageControl(ps_customerid IN VARCHAR2,
					      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION ExtAccControl(pn_extaccno      IN VARCHAR2,
			                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetAllCustomerAccounts(pn_musteri_no IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetDailyFXandB2OBStatement(pn_islemkod IN VARCHAR2,
		 				    		  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetB2OBStatementDate(pn_txno IN VARCHAR2) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION FXandB2OBStatementInquiry(pn_islemkod IN VARCHAR2,
									pd_startdate	   IN VARCHAR2,
									pd_enddate      IN VARCHAR2,
		 				    		pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetCurrentCurrency(ps_currency IN VARCHAR2, ps_fxtype IN VARCHAR2) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION CheckAccountNo(pn_accountno IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
END;

/

