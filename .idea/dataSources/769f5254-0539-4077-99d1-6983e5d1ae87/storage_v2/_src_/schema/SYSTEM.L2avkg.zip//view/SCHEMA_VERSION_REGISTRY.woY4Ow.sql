create view SCHEMA_VERSION_REGISTRY as
SELECT comp_id,  comp_name,  mrc_name,  mr_name,  mr_type,  owner,  version,  status,  upgraded,  start_time,  modified,  edition  FROM SYSTEM.SCHEMA_VERSION_REGISTRY$ ORDER BY comp_id
/

