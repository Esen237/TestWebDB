create function        wm$_check_install return boolean is begin return true ; end;
/

