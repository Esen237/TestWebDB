create trigger GET_NEXT_VAL_LOG
    before insert
    on TBL_AUTOPAYMENT_LOG
    for each row
    when (NEW.LOG_ID IS NULL)
BEGIN
  select LOG_AUTOPAYMENT.NEXTVAL
   INTO :NEW.LOG_ID from dual;
END;

/

