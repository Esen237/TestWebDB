create PACKAGE         PKG_HELPER IS
TYPE CursorReferenceType IS REF CURSOR;
-------------------------------------------------------------------
FUNCTION getNumberFromVarchar2(ps_number IN VARCHAR2, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN NUMBER;
-------------------------------------------------------------------
FUNCTION getVarchar2FromNumber(ps_number IN NUMBER, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN VARCHAR2;
-------------------------------------------------------------------
END PKG_HELPER;
/

