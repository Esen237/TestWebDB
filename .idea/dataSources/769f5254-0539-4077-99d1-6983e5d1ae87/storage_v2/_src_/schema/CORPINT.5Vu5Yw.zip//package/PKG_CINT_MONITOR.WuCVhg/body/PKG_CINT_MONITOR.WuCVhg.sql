create PACKAGE BODY         PKG_CINT_MONITOR IS
-----------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  GetUserInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Return User Information and last login date
******************************************************************************/

FUNCTION GetUserInfo(pn_SessionID  IN VARCHAR2,
                     pn_CustomerID IN VARCHAR2,
                     pn_PersonID   IN VARCHAR2,
                     pc_ref  OUT CursorReferenceType,
                     pc_ref2 OUT CursorReferenceType,
                     pc_ref3 OUT CursorReferenceType,
                     pc_ref4 OUT CursorReferenceType,
                     pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    cursor cursor_session is
        select * from tbl_session
        where person_id=pn_personid
        and status_cd='sCLOSED'
        order by session_id desc;

    row_session cursor_session%rowtype;
    ls_returncode varchar2(3):='000';
    ld_last_login_date date := sysdate;
    
    ln_dummy varchar2(3):='000' ; --chyngyzo cq509 dummy variable for function return
	
    ln_session_id	   number;
BEGIN

	select max(session_id)
	into ln_session_id
	from corpint.tbl_session
	where person_id=pn_personid
	  and status_cd='sCLOSED';
    
    select min(dlm)
	into ld_last_login_date
	from corpint.tbl_ticket_history
	where Person_ID = pn_PersonID
      and session_id=nvl(ln_session_id,pn_SessionID);
    
    
    
     open cursor_session;
     fetch cursor_session into row_session;
     if  cursor_session%FOUND then
          if (ld_last_login_date<row_session.DLM) then
            ld_last_login_date:=ld_last_login_date;
          else
            ld_last_login_date:=row_session.DLM;
          end if;
     else
          ld_last_login_date:=ld_last_login_date;
     end if;
     close cursor_session;
    
    
    OPEN pc_ref FOR
        SELECT trim(p.FIRSTNAME || p.MIDDLENAME || p.LASTNAME) UNVAN
        FROM TBL_PERSON p
        WHERE P.PERSON_ID=TO_NUMBER(pn_PersonID);
    
    OPEN pc_ref2 FOR
        SELECT to_char(ld_last_login_date,'DD.MM.YYYY HH24:MI:SS')
        FROM DUAL;
log_at('pkg_cint_monitor',ln_session_id);
    -- B-O-M chyngyzo cq509 set flag for popup show 10.02.2015 -------------------------
        ln_dummy := pkg_customer.showSwiftPopupToUser( pn_CustomerID, pn_PersonID, 'N',  pc_ref3);                                                             
    -- E-O-M chyngyzo cq509 set flag for popup show ------------------------------------------
log_at('pkg_cint_monitor',ld_last_login_date);
 OPEN pc_ref4 FOR SELECT '-' FROM dual;
 OPEN pc_ref5 FOR SELECT '-' FROM dual;

 RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS THEN
     pkg_log.AddCustomLog('Pkg_Soa_Common.GetUserInfo',SQLERRM);
     ls_returncode:= '999';
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;
  RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  DisplayLimitInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.12.07
   Purpose   : Display Limit Info
******************************************************************************/
FUNCTION DisplayLimitInfo(ps_channelcd  IN VARCHAR2,
                          ps_customerid    IN VARCHAR2,
                          ps_personid    IN VARCHAR2,
                          ps_langid        IN VARCHAR2,
                          pc_ref  OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType,
                          pc_ref4 OUT CursorReferenceType,
                          pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         ln_isPresent NUMBER:=0;
BEGIN
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

    IF ps_channelcd='cDKBRIB' THEN
        OPEN pc_ref FOR
          SELECT t.DEFINITION,d.DAILY_LIMIT, d.CURRENCY_CODE,Pkg_Limit.GetUsedLimit(NULL,ps_personid,d.TRAN_CD,d.CHANNEL_CD) used,
                (select CC.DAILY_LIMIT from corpint.TBL_RETAIL_LIMITS cc where cc.TRAN_CD=d.TRAN_CD) BankDailyLimit, T.TRAN_CD
                FROM TBL_LIMIT_DEFAULTS d,TBL_TRANSACTION t
                WHERE d.TRAN_CD=t.TRAN_CD
                AND d.CHANNEL_CD=ps_channelcd
                AND t.LANGUAGE_CD=ps_langid
                and d.PERSON_ID=ps_personid;
    ELSE--cDKBCIB
        OPEN pc_ref FOR
            SELECT
                t.DEFINITION, a.DAILY_LIMIT, nvl(a.LIMIT_CURRENCY,'KGS'), DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0) used,
                (select CC.DAILY_LIMIT from corpint.TBL_CORP_LIMITS cc where cc.TRAN_CD=t.TRAN_CD) BankDailyLimit,
                t.TRAN_CD, p.FIRSTNAME || p.MIDDLENAME || p.LASTNAME USERNAME, c.ISLEM_LIMIT, c.ISLEM_LIMIT_CY
                FROM TBL_APPROVAL_TRAN a,TBL_TRANSACTION t,TBL_COMPANY c, TBL_PERSON p
                WHERE a.customer_id=ps_customerid
                AND a.CHANNEL_CD=ps_channelcd
                AND t.LANGUAGE_CD = ps_langid
                AND t.TRAN_CD=a.TRAN_CD
                AND c.customer_no = ps_customerid
                AND c.customer_no = a.customer_id
                AND c.person_id = ps_personid
                AND p.customer_id = a.customer_id
                AND p.person_id = c.person_id
                ORDER BY a.ORDER_ID;
            /*SELECT
                p.FIRSTNAME || p.MIDDLENAME || p.LASTNAME USERNAME,
                a.TRAN_CD,    t.DEFINITION,c.ISLEM_LIMIT,    c.ISLEM_LIMIT_CY, a.DAILY_LIMIT,a.LIMIT_CURRENCY,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used
                FROM TBL_APPROVAL_TRAN a,TBL_TRANSACTION t,TBL_COMPANY c, TBL_PERSON p
                WHERE a.customer_id=ps_customerid
                AND a.CHANNEL_CD=ps_channelcd
                AND t.LANGUAGE_CD = ps_langid
                AND t.TRAN_CD=a.TRAN_CD
                AND c.customer_no = ps_customerid
                AND c.customer_no = a.customer_id
                AND c.person_id = ps_personid
                AND p.customer_id = a.customer_id
                AND p.person_id = c.person_id
                ORDER BY a.ORDER_ID;*/
     END IF;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;
END;
/******************************************************************************
   NAME       : FUNCTION  GetTokenSerial
   Created By : Muzaffar Khalyknazarov
   Date       : 09.12.07
   Purpose    : Get Token Serial
******************************************************************************/
FUNCTION GetTokenSerial(ps_person_id IN VARCHAR2,
                            pc_ref  OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType)RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    noSerialFound   EXCEPTION;
    ln_count NUMBER;
BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

    SELECT COUNT(TOKEN_ID)
    INTO ln_count
    FROM TBL_IDENTIFICATION
    WHERE PERSON_ID=TO_NUMBER(ps_person_id);

    IF ln_count=0 THEN
       RAISE noSerialFound;
    END IF;

    OPEN pc_ref FOR
    SELECT TOKEN_ID
    FROM TBL_IDENTIFICATION
    WHERE PERSON_ID=TO_NUMBER(ps_person_id);

    RETURN ls_returncode;
EXCEPTION
    WHEN noSerialFound THEN
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
        ls_returncode:= '122';
    RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  GetTokenData
   Created By : Muzaffar Khalyknazarov
   Date       : 09.12.07
   Purpose    : Get Token Serial
******************************************************************************/
FUNCTION GetTokenData(ps_DIGIPASS IN VARCHAR2,
                      pc_ref  OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType,
                      pc_ref4 OUT CursorReferenceType,
                      pc_ref5 OUT CursorReferenceType)RETURN VARCHAR2 IS

    ls_digidata VARCHAR2(255);
    ls_digipass VARCHAR2(22);
    ls_dptype VARCHAR2(5);
    otp_validity_period NUMBER;
    ls_returncode   VARCHAR2(3):='000';
    TransactionError EXCEPTION;

BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

    SELECT DP_DATA,DIGIPASS,OTP_VALIDITY_PERIOD,DP_TYPE
    INTO ls_digidata,ls_digipass,otp_validity_period,ls_dptype
    FROM TBL_TOKEN
    WHERE INSTR(DIGIPASS,ps_DIGIPASS)>0;

    OPEN pc_ref FOR SELECT ls_digidata,ls_digipass,otp_validity_period,ls_dptype FROM dual;

    RETURN ls_returncode;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ls_returncode:='112';--token no found
    OPEN pc_ref FOR
    SELECT ls_digidata,ls_digipass FROM dual;
    RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  GetLabelInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 28.12.07
   Purpose   : Get Label Info
******************************************************************************/
FUNCTION  GetLabelInfo(ps_channelcd IN VARCHAR2,
                       ps_trancd    IN VARCHAR2,
                       ps_pageid    IN VARCHAR2,
                       ps_langcd    IN VARCHAR2,
                       ps_personid  IN VARCHAR2,
                       pc_ref  OUT CursorReferenceType,
                       pc_ref2 OUT CursorReferenceType,
                       pc_ref3 OUT CursorReferenceType,
                       pc_ref4 OUT CursorReferenceType,
                       pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_name VARCHAR2(100);
        ls_returncode   VARCHAR2(3):='000';
BEGIN
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;

        Pkg_Cint_Authority.GetLabelInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langcd, ps_personid, pc_ref4);

    RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME          : FUNCTION GetPayeeInfo
   Prepared By   : Almas Nurhozhaev
   Date          : 27.12.2007
   Purpose       : Get Payee Info
   Modified By   : Tastan Zhaylibayev
   Modified Date : 03.01.2008
******************************************************************************/
FUNCTION GetPayeeInfo(ps_PERSON_ID IN VARCHAR2,
                      ps_PAYEE_TYPE IN VARCHAR2 DEFAULT NULL,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
        ls_returncode          VARCHAR2(3):='000';
BEGIN
    IF ps_PAYEE_TYPE = 'HVL'
    THEN
         OPEN pc_ref FOR
            SELECT NVL(PAYEE_ID,0),
                   NVL(PERSON_ID,0),
                   NVL(PAYEE_TYPE,' '),
                   NVL(PAYEE_KIND,' '),
                   NVL(SENDERNAME,' '),

                   NVL(PAYEENAME,' '),
                   NVL(TOACCOUNT,' '),
                   NVL(NICKNAME,' '),
                   NVL(CURRCODE,' ')

            FROM TBL_PAYEE
            WHERE person_id=NVL(TO_NUMBER(ps_PERSON_ID),PERSON_ID)
            AND PAYEE_TYPE=NVL(ps_PAYEE_TYPE,PAYEE_TYPE)
            ORDER BY PAYEE_KIND,NICKNAME,PAYEENAME;
    ELSE
         OPEN pc_ref FOR
            SELECT NVL(PAYEE_ID,0),
                   NVL(PERSON_ID,0),
                   NVL(PAYEE_TYPE,' '),
                   NVL(PAYEE_KIND,' '),
                   NVL(SENDERNAME,' '),

                   NVL(BANKCD,' '),
                   NVL(PAYEENAME,' '),
                   NVL(TOACCOUNT,' '),
                   NVL(PAYMENTCD,' '),
                   NVL(NICKNAME,' '),

                   NVL(CURRCODE,' '),
                   NVL(SENDERPHONE,' '),
                   NVL(SENDERADDRESS,' '),
                   NVL(PAYEEPHONE,' '),
                   NVL(RNN,' '),

                   NVL(STAT,0),
                   NVL(INCOME_CODE,0),
                   NVL(DOC_NO,0)

            FROM TBL_PAYEE
            WHERE person_id=NVL(TO_NUMBER(ps_PERSON_ID),PERSON_ID)
            AND PAYEE_TYPE=NVL(ps_PAYEE_TYPE,PAYEE_TYPE)
            ORDER BY PAYEE_KIND,NICKNAME,PAYEENAME;
    END IF;

     RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME          : FUNCTION AddPayeeInfo
   Prepared By   : Almas Nurhozhaev
   Date          : 27.12.2007
   Purpose       : Add Payee Info
   Modified By   : Tastan Zhaylibayev
   Modified Date : 03.01.2008
******************************************************************************/
FUNCTION AddPayeeInfo(ps_option    IN VARCHAR2,
                      ps_PAYEE_ID IN VARCHAR2,
                      ps_PERSON_ID IN VARCHAR2,
                      ps_PAYEE_TYPE IN VARCHAR2,--EFT/MO
                      ps_SENDERNAME IN VARCHAR2,
                      ps_BANKCD IN VARCHAR2,
                      ps_PAYEENAME IN VARCHAR2,
                      ps_TOACCOUNT IN VARCHAR2,
                      ps_PAYMENTCD IN VARCHAR2,
                      ps_NICKNAME IN VARCHAR2,
                      ps_CURRCODE IN VARCHAR2,
                      ps_SENDERPHONE IN VARCHAR2 DEFAULT ' ',
                      ps_PAYEEPHONE IN VARCHAR2 DEFAULT ' ',
                      ps_rnn IN VARCHAR2,
                      ps_stat IN VARCHAR2,
                      ps_income IN VARCHAR2,
                      ps_docno IN VARCHAR2) RETURN VARCHAR2 IS
    ln_payeeid NUMBER;
BEGIN

IF ps_option='I' THEN
         ln_payeeid:=Pkg_Common.GetSequenceID('PAYEEID');
        INSERT INTO TBL_PAYEE
        (PAYEE_ID, PERSON_ID, PAYEE_TYPE, PAYEE_KIND, SENDERNAME,
         BANKCD, CITYCD, BRANCHCD, PAYEENAME, TOACCOUNT,
         PAYMENTCD, NICKNAME, CURRCODE, SENDERPHONE, SENDERADDRESS,
         PAYEEPHONE, RNN, STAT, INCOME_CODE, DOC_NO)
        VALUES
        (ln_payeeid, ps_PERSON_ID, ps_PAYEE_TYPE, 'TO_ACCOUNT', SUBSTR(ps_SENDERNAME,0,80),
         ps_BANKCD, NULL, NULL, SUBSTR(ps_PAYEENAME,0,80), NVL(ps_TOACCOUNT,' '),
         ps_PAYMENTCD, SUBSTR(ps_NICKNAME,0,35), ps_CURRCODE, ps_SENDERPHONE, NULL,
         ps_PAYEEPHONE, ps_rnn, ps_stat, ps_income, ps_docno);
     ELSIF ps_option='SWIFT_PAYEE_I' THEN
         ln_payeeid:=Pkg_Common.GetSequenceID('PAYEEID');
        INSERT INTO TBL_PAYEE
        (PAYEE_ID, PERSON_ID, PAYEE_TYPE, PAYEE_KIND, SENDERNAME,
         BANKCD, CITYCD, BRANCHCD, PAYEENAME, TOACCOUNT,
         PAYMENTCD, NICKNAME, CURRCODE, SENDERPHONE, SENDERADDRESS,
         PAYEEPHONE, RNN, STAT, INCOME_CODE, DOC_NO)
        VALUES
        (ln_payeeid, ps_PERSON_ID, ps_PAYEE_TYPE, 'TO_ACCOUNT', pkg_cint_main.GetPersonName(ps_PERSON_ID),
         CORPINT.PKG_CINT_MAIN.SPLIT(ps_BANKCD, '###', 0), CORPINT.PKG_CINT_MAIN.SPLIT(ps_BANKCD, '###', 1) , NVL(ps_docno,' '), SUBSTR(ps_PAYEENAME,0,80), NVL(ps_TOACCOUNT,' '),
         ps_PAYMENTCD, SUBSTR(ps_NICKNAME,0,35), ps_CURRCODE, ps_SENDERPHONE, ps_SENDERNAME,
         ps_PAYEEPHONE, ps_rnn, ps_stat, NULL, NULL);
     ELSIF ps_option='PAYMENTS' THEN
         ln_payeeid:=Pkg_Common.GetSequenceID('PAYEEID');
        INSERT INTO TBL_PAYEE
        (PAYEE_ID, PERSON_ID, PAYEE_TYPE, PAYEE_KIND, SENDERNAME,
         TOACCOUNT, PAYMENTCD, CURRCODE, NICKNAME, PAYEEPHONE, SENDERPHONE)
        VALUES
        (ln_payeeid, ps_PERSON_ID, ps_PAYEE_TYPE, 'TO_ACCOUNT', pkg_cint_main.GetPersonName(ps_PERSON_ID),
         NVL(ps_TOACCOUNT,' '), ps_PAYMENTCD, ps_CURRCODE, SUBSTR(ps_NICKNAME,0,35), ps_PAYEEPHONE, ps_SENDERPHONE);
     ELSIF  ps_option='U' THEN
         UPDATE TBL_PAYEE p
         SET p.BANKCD=ps_BANKCD,
             p.PAYEENAME=SUBSTR(ps_PAYEENAME,0,80),
             p.TOACCOUNT=NVL(ps_TOACCOUNT,' '),
             p.NICKNAME=ps_NICKNAME,
             p.RNN=ps_rnn,
             p.CURRCODE=ps_CURRCODE
         WHERE PAYEE_ID=TO_NUMBER(ps_PAYEE_ID);
     ELSIF  ps_option='D' THEN
        DELETE FROM TBL_PAYEE
        WHERE PAYEE_ID=TO_NUMBER(ps_PAYEE_ID);
     END IF;
     RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
        Pkg_Log.AddCustomLog('AddPayeeInfo', SQLERRM);
        RETURN '990';
END;
/******************************************************************************
   NAME       : FUNCTION  GetSecurityInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 15.04.08
   Purpose    : Get Security Info
******************************************************************************/
FUNCTION GetSecurityInfo(pn_Person_id IN VARCHAR2,
                         pc_ref  OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType,
                         pc_ref4 OUT CursorReferenceType,
                         pc_ref5 OUT CursorReferenceType)RETURN VARCHAR2 IS
    ls_returncode   VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

    OPEN pc_ref FOR
    SELECT PERSON_ID, IP_1_1, IP_1_2, IP_2_1, IP_2_2,
           IP_STATUS, START_TIME, END_TIME, TIME_STATUS, MONDAY,
           TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
    FROM TBL_IBSECURITY
    WHERE PERSON_ID=TO_NUMBER(pn_Person_id);

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
         PKG_LOG.ADDCUSTOMLOG('GetSecurityInfo',SQLERRM);
             OPEN pc_ref FOR SELECT '-' FROM dual;
            OPEN pc_ref2 FOR SELECT '-' FROM dual;
            OPEN pc_ref3 FOR SELECT '-' FROM dual;
            OPEN pc_ref4 FOR SELECT '-' FROM dual;
            OPEN pc_ref5 FOR SELECT '-' FROM dual;
    RETURN '999';
END;

/******************************************************************************
   NAME        : FUNCTION GetPersonAgenda
   Prepared By : Almas Adilbek
   Date        : 21.04.08
   Purpose     : Get Person Agenda DAtas
******************************************************************************/
FUNCTION GetPersonAgenda(pn_personCD IN VARCHAR2,
                         ps_langCD IN VARCHAR2,
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType,
                         pc_ref4 OUT CursorReferenceType,
                         pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
     OPEN pc_ref  FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

      OPEN pc_ref FOR
           SELECT EVENT_ID, PERSON_ID, EVENT_TYPE, TITLE, DESCRIPTION, TO_CHAR(EVENT_DATE,'DD-MM-YYYY') FROM corpint.TBL_AGENDA_PERSON
                   WHERE person_id = pn_personCD
                 AND status_cd = 'sENAB' ORDER BY EVENT_DATE ASC;

     OPEN pc_ref2 FOR
        SELECT EVENT_ID, EVENT_TYPE, TITLE, DESCRIPTION, TO_CHAR(EVENT_DATE,'DD-MM-YYYY') FROM corpint.TBL_AGENDA_COMMON
            WHERE lang_cd = ps_langCD
            AND status_cd = 'sENAB' ORDER BY EVENT_DATE ASC;

     OPEN pc_ref3 FOR
         SELECT EVENT_TYPE, TITLE, DESCRIPTION, MARK_COLOR, EVENT_ICON_IMG FROM corpint.TBL_AGENDA_EVENTS
             WHERE lang_cd = ps_langCD;

  RETURN ls_returncode;

  EXCEPTION
    WHEN OTHERS THEN
      ls_returncode:= '999';
    RETURN ls_returncode;
END;
/******************************************************************************
   NAME        : FUNCTION GetAllAgendaEvents
   Prepared By : Almas Adilbek
   Date        : 13.05.08
   Purpose     : Get All Agenda Events
******************************************************************************/
FUNCTION GetAllAgendaEvents(pn_personCD IN VARCHAR2,
                            ps_langCD IN VARCHAR2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
     OPEN pc_ref  FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

      OPEN pc_ref FOR
        select * from
            (SELECT a.EVENT_ID, a.EVENT_TYPE, a.TITLE, a.DESCRIPTION,TO_CHAR(a.EVENT_DATE,'DD-MM-YYYY'), 'eCOMMON'  FROM corpint.TBL_AGENDA_COMMON a
                WHERE a.lang_cd = ps_langCD
                AND TO_DATE(a.EVENT_DATE,'DD-MM-YYYY')>=TO_DATE(SYSDATE,'DD-MM-YYYY')
                AND a.status_cd = 'sENAB'
            UNION
            SELECT b.EVENT_ID, b.EVENT_TYPE, b.TITLE, b.DESCRIPTION, TO_CHAR(b.EVENT_DATE,'DD-MM-YYYY'), 'ePERSON' FROM corpint.TBL_AGENDA_PERSON b
                WHERE b.PERSON_ID = pn_personCD
                AND TO_DATE(b.EVENT_DATE,'DD-MM-YYYY')>=TO_DATE(SYSDATE,'DD-MM-YYYY')
                AND b.status_cd = 'sENAB') order by 5    ;

     OPEN pc_ref2 FOR
         SELECT EVENT_TYPE, TITLE, DESCRIPTION, MARK_COLOR, EVENT_ICON_IMG FROM corpint.TBL_AGENDA_EVENTS
             WHERE lang_cd = ps_langCD;

  RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
      ls_returncode:= '999';
    RETURN ls_returncode;
END;
-------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  UpdatePersonLimitInfo
   Created By : Almas Nurkhozhayev
   Date       : 05.11.09
   Purpose   : Update Personal Limit Info
******************************************************************************/
FUNCTION UpdatePersonLimitInfo(ps_channelcd   IN VARCHAR2,
                               ps_trancd      IN VARCHAR2,
                               ps_personid    IN VARCHAR2,
                               ps_daily_limit IN VARCHAR2,
                               ps_langid      IN VARCHAR2,
                               ps_customerid  IN VARCHAR2) RETURN VARCHAR2 IS
         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         ln_isPresent NUMBER:=0;
         ln_BankLimit NUMBER:=0;
BEGIN

    IF ps_channelcd='cDKBRIB' THEN
        select to_number(DAILY_LIMIT) into ln_BankLimit
        from corpint.TBL_RETAIL_LIMITS
        where TRAN_CD=ps_trancd
        and rownum=1;

        if (to_number(ps_daily_limit,'999999999999999.9999')<=ln_BankLimit) then
            UPDATE TBL_LIMIT_DEFAULTS
            SET DAILY_LIMIT = to_number(ps_daily_limit,'999999999999999.9999')
            WHERE TRAN_CD=ps_trancd
            AND CHANNEL_CD=ps_channelcd
            AND PERSON_ID=ps_personid;
        else
            RETURN '700';
        end if;
    ELSE--cDKBCIB
        null;
    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
         pkg_log.addcustomlog('UpdatePersonLimitInfo', sqlerrm);
         RETURN '999';
END;
-------------------------------------------------------------------------------------
END Pkg_CINT_Monitor;
/

