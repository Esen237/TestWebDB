create view CBS_VW_RAP_CUSTOMER_ACTIVITY as
select  Trunc(max(DLM)) TARIH, 
		SESSION_ID, 
		PERSON_ID, 
        (select FIRSTNAME||' '||MIDDLENAME||' '||LASTNAME 
         from tbl_person 
         where PERSON_ID=t.PERSON_ID) PERSON_NAME, 
		(max(DLM) -min(DLM))*24*60*60 SECOND, 
	    to_char(trunc( ((max(DLM) -min(DLM))-trunc(max(DLM)-min(DLM))) *24 ),'00')||':'|| 
		to_char(trunc((((max(DLM) -min(DLM))-trunc(max(DLM)-min(DLM))) *24 - trunc( ((max(DLM) -min(DLM))-trunc(max(DLM)-min(DLM))) *24 )  ) *60),'00') ||':'|| 
		to_char(trunc(( (((max(DLM) -min(DLM))-trunc(max(DLM)-min(DLM))) *24 - trunc( ((max(DLM) -min(DLM))-trunc(max(DLM)-min(DLM))) *24 )  ) *60 - 
		         trunc((((max(DLM) -min(DLM))-trunc(max(DLM)-min(DLM))) *24 - trunc( ((max(DLM) -min(DLM))-trunc(max(DLM)-min(DLM))) *24 )  ) *60) )*60),'00') DURATION 
from tbl_activity t 
where SESSION_ID<>0 
group by SESSION_ID,PERSON_ID

/

