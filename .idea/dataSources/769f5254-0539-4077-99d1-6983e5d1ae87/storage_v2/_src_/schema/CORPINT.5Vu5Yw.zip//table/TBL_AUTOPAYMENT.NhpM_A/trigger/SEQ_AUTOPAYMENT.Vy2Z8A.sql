create trigger SEQ_AUTOPAYMENT
    before insert
    on TBL_AUTOPAYMENT
    for each row
    when (NEW.SEQ_ID IS NULL)
BEGIN
  select SEQ_AUTOPAYMENT.NEXTVAL
   INTO :NEW.SEQ_ID from dual;
END;

/

