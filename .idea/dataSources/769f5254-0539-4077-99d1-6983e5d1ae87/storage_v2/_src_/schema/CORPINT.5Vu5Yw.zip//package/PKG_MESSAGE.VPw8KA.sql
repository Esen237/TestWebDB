create PACKAGE Pkg_Message IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
FUNCTION Write2File(ps_filename IN VARCHAR2,ps_inputtext IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION ReadFile(ps_filename IN VARCHAR2,ps_outputtext OUT VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION SPLIT(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION PrepareField(ps_str IN VARCHAR2,pn_length IN NUMBER,
		 					 	ps_padchar IN VARCHAR2,ps_justification IN VARCHAR2,ps_fieldtype IN VARCHAR2 DEFAULT 'CHAR')  RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetReferenceID RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION PrepareInputHeader(ps_messageid IN VARCHAR2,ps_reference IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
/*Function SendMessage(pn_sessionid in number, ps_messageid in varchar2,
		  							  	 ps_inputstr in varchar2,ps_outputstr out varchar2) return varchar2;*/
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
END;

/

