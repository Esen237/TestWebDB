create PACKAGE         "PKG_CUSTOMER" IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
FUNCTION GetPersonInfo(ps_customerid IN NUMBER,
                        ps_channel IN VARCHAR2,
                        ps_personid     OUT VARCHAR2,
                           ps_channelcd     OUT VARCHAR2,
                        ps_customername    OUT VARCHAR2,
                       ps_birthdate OUT VARCHAR2,
                       ps_sex OUT VARCHAR2,
                       ps_pfc OUT VARCHAR2,
                       ps_expiredate OUT VARCHAR2,
                       ps_personstatus OUT VARCHAR2,
                       ps_identitystatus OUT VARCHAR2
                       ) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetPersonID(pn_customerid IN NUMBER,ps_channel VARCHAR2) RETURN NUMBER;
-----------------------------------------------------------------------------------
FUNCTION GetCustomerID(pn_personrid IN NUMBER) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetUserInfo(pn_customerid IN NUMBER,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION AddPayeeInfo(ps_option    IN VARCHAR2,
                       ps_PAYEE_ID IN VARCHAR2,
                       ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2,--EFT/MO
                      ps_SENDERNAME IN VARCHAR2,
                      ps_BANKCD IN VARCHAR2,
                      ps_PAYEENAME IN VARCHAR2,
                      ps_TOACCOUNT IN VARCHAR2,
                      ps_PAYMENTCD IN VARCHAR2,
                      ps_NICKNAME IN VARCHAR2,
                      ps_CURRCODE IN VARCHAR2,
                      ps_SENDERPHONE IN VARCHAR2 DEFAULT ' ',
                      ps_PAYEEPHONE IN VARCHAR2 DEFAULT ' ',
                      ps_rnn IN VARCHAR2,
                      ps_stat IN VARCHAR2,
                      ps_income IN VARCHAR2,
                      ps_docno IN VARCHAR2,
                        ps_PAYEE_NAME IN VARCHAR2,
                      ps_SUBACCOUNT_NO IN VARCHAR2,
                      ps_PAY_SUBNAME IN VARCHAR2
                      ) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION GetPayeeInfo(ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2 DEFAULT NULL,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

-----------------------------------------------------------------------------------
FUNCTION SetUserMessage(ps_STARTDATE IN VARCHAR2,
                         ps_ENDDATE IN VARCHAR2,
                        ps_MESSAGE IN VARCHAR2,
                        ps_CHANNELCD IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetUserMessages(ps_PERSONID IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION CancelUserMessage(ps_PERSONID IN VARCHAR2,
                            ps_MESSAGEID IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION DisableUserMessage(ps_MESSAGEID IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION SetEkstreInfo(ps_customerid IN VARCHAR2,
                       ps_password IN VARCHAR2,
                       ps_hatirlatmasoru IN VARCHAR2,
                       ps_hatirlatmacevap IN VARCHAR2,
                       ps_birthdate IN VARCHAR2,
                       ps_cinsiyet IN VARCHAR2,
                       ps_email IN VARCHAR2,
                       ps_firstname IN VARCHAR2,
                       ps_secondname IN VARCHAR2,
                       ps_surname IN VARCHAR2,
                       ps_accountid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION CheckEkstreInfo(ps_customerid IN VARCHAR2,
                         ps_password IN VARCHAR2,
                         ps_hatirlatmasoru IN VARCHAR2,
                         ps_hatirlatmacevap IN VARCHAR2,
                         ps_accountid IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION ChangePwdforEkstre(ps_oldpassword IN VARCHAR2,
                            ps_newpassword IN VARCHAR2,
                            ps_customerid IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION ChangeAnsforEkstre(ps_question IN VARCHAR2,
                            ps_newanswer IN VARCHAR2,
                            ps_customerid IN VARCHAR2,
                            ps_accountid IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetUygunModulTurforExactDate(ps_date IN VARCHAR2,
                            ps_bankdate IN VARCHAR2,
                            ps_currcode IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetUygunModulTurforDate(ps_date IN VARCHAR2,
                            ps_currcode IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetAgendaInfo(ps_personid IN VARCHAR2,
                       ps_channelid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------------
FUNCTION SetAgendaInfo(ps_personid IN VARCHAR2,
                       ps_channelid IN VARCHAR2,
                       ps_message IN VARCHAR2,
                       ps_messagedate IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION ShowAgendaInfo(ps_personid IN VARCHAR2,
                       ps_channelid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

------------------------------------------------------------------------------------
FUNCTION DelAgendaInfo(ps_messageid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION CreateIslemParola(
           ps_customerid VARCHAR2,
           ps_personid VARCHAR2,
           ps_islemtur VARCHAR2,
           ps_parola VARCHAR2,
           ps_raw_parola VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION  CheckIslemParola(
           ps_parolaid IN VARCHAR2,
           ps_parola IN VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION  CheckTokenPresent(
           ps_personid VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION  CheckparolaKilitlimi(
           ps_personid VARCHAR2,
           ps_chanelcd VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION  GetCustomerNo(
           ps_personid VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetPersonName(pn_personid IN NUMBER) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION  GetPersonName2(
          ps_personid NUMBER,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------------------
          
-------------------------------------------------------------------------------------
FUNCTION CheckLimit(pn_musteri_no IN VARCHAR2,
                         ps_trancd IN VARCHAR2,
                         pn_amount IN VARCHAR2,
                        pn_personid IN VARCHAR2,
                        ps_channel  IN VARCHAR2,
                           ps_rates    IN VARCHAR2,
                           ps_cycode   IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------------------
FUNCTION UpdateLimit(pn_musteri_no IN VARCHAR2,
                      ps_trancd IN VARCHAR2,
                      pn_amount IN VARCHAR2,
                     ps_currcode IN VARCHAR2,
                     ps_personid IN VARCHAR2,
                     ps_channel IN VARCHAR2,
                     ps_rates IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------------------
FUNCTION SetVerifyUpdateFlag(ps_txNo IN VARCHAR2,
                        ps_customerid IN VARCHAR2,
                        ps_verifiedapprovedid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------------------
FUNCTION GetMakerInfo(ps_customerid     IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetPersonInfo1(pn_customerid IN NUMBER,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION GetPaymentCodes(ps_langcd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION GetEmailStatementRates(ps_personid IN VARCHAR2,
                      pn_customerno IN VARCHAR2,
                      ps_channelcd IN VARCHAR2,
                       ps_rate IN VARCHAR2,
                       ps_move IN VARCHAR2,
                       ps_period1 IN VARCHAR2 ,
                      ps_period2 IN VARCHAR2 ,
                      ps_email1 IN VARCHAR2 ,
                        ps_email2 IN VARCHAR2 ,
                      pn_accountno IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION GetPaymentCodesForB2OBHVL(ps_langcd IN VARCHAR2,
                                   ps_channelcd IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION UpdatePaymentCode4B2OBHVL(ps_option        IN VARCHAR2,
                                   ps_langcd        IN VARCHAR2,
                                   pn_paymentcode   IN VARCHAR2,
                                   pn_parentcode    IN VARCHAR2,
                                   ps_paynameeng    IN VARCHAR2,
                                   ps_paynamerus    IN VARCHAR2,
                                   ps_trancode      IN VARCHAR2,
                                   ps_channelcode   IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION Beneficiaries(ps_option    IN VARCHAR2,
                       ps_PAYEE_ID IN VARCHAR2,
                       ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2,
                       ps_SENDERNAME IN VARCHAR2,
                       ps_BANKCD IN VARCHAR2,
                       ps_PAYEENAME IN VARCHAR2,
                       ps_TOACCOUNT IN VARCHAR2,
                       ps_PAYMENTCD IN VARCHAR2,
                       ps_NICKNAME IN VARCHAR2,
                       ps_CURRCODE IN VARCHAR2,
                       ps_SENDERPHONE IN VARCHAR2 DEFAULT ' ',
                       ps_PAYEEPHONE IN VARCHAR2 DEFAULT ' ',
                       ps_rnn IN VARCHAR2,
                       ps_stat IN VARCHAR2,
                       ps_income IN VARCHAR2,
                       ps_docno IN VARCHAR2,
                       ps_PAYEE_NAME IN VARCHAR2,
                       ps_SUBACCOUNT_NO IN VARCHAR2,
                       ps_PAY_SUBNAME IN VARCHAR2,
                       ps_CUSTOMER_NO IN VARCHAR2,
                       ps_ADDRESS IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION PayeeRestrictions(ps_option    IN VARCHAR2,
                           ps_CUSTOMER_NO IN VARCHAR2,
                           ps_TRAN_TYPE IN VARCHAR2,
                           ps_PAYEE_RESTRICTED IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
--B-O-M ernestk cqdb00000498 to get payee info by payee id
/*******************************************************************************
    Name: GetPayeeInfoByPayeeId
    Author: Ernest Kuttubaev
    Modify Date: 16.10.2013
    
    Desc: Returns cursot to payee data that is retrieved by payee id
*******************************************************************************/
FUNCTION getPayeeInfoByPayeeId( ps_person_id    IN  varchar2,
                                ps_payee_id     IN  varchar2,
                                pc_ref          OUT CursorReferenceType) RETURN VARCHAR2;
--E-O-M ernestk cqdb00000498 to get payee info by payee id

/*******************************************************************************
    Name        :setSwiftOption
    Prepared By :Chyngyz Omurov  (cq509)
    Modify Date :10.02.2015
    Pupose      : To set swift option ON/OFF
*******************************************************************************/
FUNCTION setSwiftOption( ps_customerid VARCHAR2,
                                               ps_personid VARCHAR2,
                                               ps_status VARCHAR2,
                                               pc_ref OUT  cursorreferencetype ) RETURN VARCHAR2;

/*******************************************************************************
    Name            :showSwiftPopupToUser
    Prepared By :Chyngyz Omurov (cq509)
    Modify Date :10.02.2015
    Pupose      : return flag to show swift pop-up or not
*******************************************************************************/                                               
FUNCTION showSwiftPopupToUser( ps_customerid VARCHAR2,
                                                               ps_personid VARCHAR2,
                                                               ps_forceToShow VARCHAR2,
                                                               pc_ref OUT cursorreferencetype) RETURN VARCHAR2;


/*******************************************************************************
    Name        :showMessageToMaker
    Prepared By :Chyngyz Omurov  (cq509)
    Modify Date :10.02.2015
    Pupose      : return flag to show swift option related message to the maker
*******************************************************************************/
FUNCTION showMessageToMaker(  ps_customerid VARCHAR2,
                                                              ps_personid VARCHAR2,
                                                              pc_ref OUT cursorreferencetype) RETURN VARCHAR2;      
                                                              
                                                              
-----------------------------------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION GetPersonNameAndChannel
   Prepared By : Nursultan Mukhambet uulu
   Date        : 15.12.2021
******************************************************************************/
FUNCTION  GetPersonNameAndChannel(ps_personid NUMBER,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
          
-------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION GetPersonNamesHistory
   Prepared By : Nursultan Mukhambet uulu
   Date        : 15.12.2021
******************************************************************************/
FUNCTION  GetPersonNamesHistory(ps_personid NUMBER,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------- 

/******************************************************************************
   NAME        : FUNCTION GetPayeeInfoForSwift
   Prepared By : Omurchiev Esen
   Date        : 15.12.2021
******************************************************************************/
FUNCTION GetPayeeInfoForSwift(ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2 DEFAULT NULL,
                       ps_currency IN VARCHAR2 DEFAULT NULL,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;                                                                            
END PKG_CUSTOMER;
/

