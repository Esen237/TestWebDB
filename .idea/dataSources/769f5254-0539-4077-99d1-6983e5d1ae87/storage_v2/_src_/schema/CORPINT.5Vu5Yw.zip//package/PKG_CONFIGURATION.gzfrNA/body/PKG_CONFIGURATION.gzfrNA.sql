create PACKAGE BODY           "PKG_CONFIGURATION" AS
FUNCTION getValueByKey(ps_key in  varchar2,
                     ps_value out varchar2) RETURN varchar2
IS
    ls_return_code  varchar2(3):='000';
    
BEGIN
    select  TBL.VALUE into ps_value
    from    tbl_configuration tbl
    where   TBL.KEY=ps_key;
    
    if (ps_value is null or ps_value = '') then
        return '888';
    end if;
    
    return ls_return_code;
    
    exception
    when others then
        PKG_LOG.ADDCUSTOMLOG('pkg_configuration.getValueByKey', sqlerrm);
        return '999';
END;
END PKG_CONFIGURATION;
/

