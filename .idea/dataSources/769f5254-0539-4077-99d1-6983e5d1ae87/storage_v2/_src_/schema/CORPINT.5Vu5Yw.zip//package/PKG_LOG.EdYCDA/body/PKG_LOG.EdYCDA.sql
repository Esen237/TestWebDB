create PACKAGE BODY         Pkg_Log IS

-----------------------------------------------------------------------------
FUNCTION LogTransaction(ps_channelcd IN VARCHAR2,
                        pn_sessionid    IN NUMBER,
                        pn_personid    IN NUMBER,
                        ps_trancd    IN VARCHAR2,
                        pn_pageid    IN NUMBER,
                        ps_systemcd    IN VARCHAR2,
                        ps_errorcd    IN VARCHAR2,
                       ps_langcd    IN VARCHAR2,
                          ps_errordesc    IN VARCHAR2,
                        ps_actvtime    IN VARCHAR2,
                        pn_amount    IN VARCHAR2,
                        ps_currency    IN VARCHAR2,
                        ps_servername    IN VARCHAR2,
                       ps_ipaddress    IN VARCHAR2,
                       ps_field1 IN VARCHAR2 DEFAULT NULL,
                       ps_field2 IN VARCHAR2 DEFAULT NULL,
                       ps_field3 IN VARCHAR2 DEFAULT NULL,
                       ps_field4 IN VARCHAR2 DEFAULT NULL,
                       ps_field5 IN VARCHAR2 DEFAULT NULL,
                       ps_field6 IN VARCHAR2 DEFAULT NULL,
                       ps_field7 IN VARCHAR2 DEFAULT NULL,
                       ps_field8 IN VARCHAR2 DEFAULT NULL,
                       ps_field9 IN VARCHAR2 DEFAULT NULL,
                       ps_field10 IN VARCHAR2 DEFAULT NULL,
                       ps_field11 IN VARCHAR2 DEFAULT NULL,
                       ps_field12 IN VARCHAR2 DEFAULT NULL,
                       ps_field13 IN VARCHAR2 DEFAULT NULL,
                       ps_field14 IN VARCHAR2 DEFAULT NULL,
                       ps_field15 IN VARCHAR2 DEFAULT NULL,
                          ps_userdesc        OUT VARCHAR2) RETURN VARCHAR2 IS

         ls_errortype   VARCHAR2(10);
         ls_userdesc   VARCHAR2(1000);

         TransactionError      EXCEPTION;
         ls_tatement VARCHAR2(2000);
         ln_actvnbr      NUMBER;
         ls_returncode VARCHAR2(3):='000';
         ln_amount       NUMBER;

         CURSOR cursor_error IS
             SELECT error_type, user_desc
             FROM TBL_ERROR
             WHERE system_cd=RTRIM(LTRIM(ps_systemcd))
             AND error_cd=RTRIM(LTRIM(ps_errorcd))
             AND lang_cd=RTRIM(LTRIM(ps_langcd));

         row_error                   cursor_error%ROWTYPE;
         ld_actvitydate               DATE;
         to_much_numer_after_dot   EXCEPTION;
         PRAGMA EXCEPTION_INIT(to_much_numer_after_dot,-06502); -- yanl?? rakam girilmesi durumunda
BEGIN

     --Get Activity number
     ln_actvnbr:=Pkg_Common.GetSequenceID('sqACTIVITY');

     ld_actvitydate:=TO_DATE(ps_actvtime,'DDMMYYYY HH24:MI:SS');

    OPEN cursor_error;
    FETCH cursor_error INTO row_error;
    IF  cursor_error%NOTFOUND THEN
        ls_errortype:='SYS';
        ls_userdesc:='Please Try Again.';
    ELSE
        ls_errortype:=row_error.error_type;
        ls_userdesc:=row_error.user_desc;
    END IF;
    CLOSE cursor_error;

     --ln_amount:=TO_NUMBER(replace(REPLACE(pn_amount,',',''),'.',','),'9999999999999999999D999999999999999999999999','nls_numeric_characters = ''.,''');
     ln_amount:=TO_NUMBER(pn_amount,'99999999999.99');

--pkg_log.AddCustomLog(1,ls_errortype,ls_userdesc,pn_amount);

     INSERT INTO TBL_ACTIVITY
     (ACTV_NBR, CHANNEL_CD, SESSION_ID, PERSON_ID, TRAN_CD, PAGE_ID, SYSTEM_CD, ERROR_CD, ERROR_TYPE, AMOUNT, CURRENCY, ACTV_TIME, DLM, SERVERNAME, ERROR_DESC,CLIENT_IP_ADDRESS,
     FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,FIELD11,FIELD12,FIELD13,FIELD14,FIELD15)
--     FIELD16,FIELD17,FIELD18,FIELD19,FIELD20)
     VALUES
     (ln_actvnbr, ps_channelcd, pn_sessionid,pn_personid, ps_trancd, pn_pageid, ps_systemcd, ps_errorcd, ls_errortype, ln_amount, ps_currency, ld_actvitydate, SYSDATE, ps_servername, ps_errordesc,ps_ipaddress,
     ps_field1,ps_field2,ps_field3,ps_field4,ps_field5,ps_field6,ps_field7,ps_field8,ps_field9,ps_field10,ps_field11,ps_field12,ps_field13,ps_field14,ps_field15);
--     ps_field16,ps_field17,ps_field18,ps_field19,ps_field20);

     ls_tatement:= 'select ' || TO_CHAR(ln_actvnbr)
                                 || ls_userdesc || ' from dual';

     --OPEN pc_ref for ls_tatement;
     ps_userdesc:=ls_userdesc;
     RETURN ls_returncode;
EXCEPTION
      WHEN to_much_numer_after_dot THEN
      ls_returncode:='712';
       pkg_log.AddCustomLog(sqlerrm);
      RETURN ls_returncode;

      WHEN OTHERS THEN
      ls_returncode:='999';
      pkg_log.AddCustomLog(sqlerrm);
      RETURN ls_returncode;


END;
-----------------------------------------------------------------------------------
PROCEDURE AddCustomLog(pid1 VARCHAR2,
                   pid2 VARCHAR2 DEFAULT NULL,
                 pid3 VARCHAR2 DEFAULT NULL,
                 pid4 VARCHAR2 DEFAULT NULL) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO TBL_CUSTOMLOG
    (FIELD1, FIELD2, FIELD3, FIELD4)
    VALUES
    (pid1, pid2, pid3, pid4);

    COMMIT;
  END;
-----------------------------------------------------------------------------------

PROCEDURE addAutopaymentLog(ps_operation IN VARCHAR2,
                                               ps_payment_name IN VARCHAR2,
                                               pn_person_id    IN NUMBER,
                                               pn_customer_id IN NUMBER,
                                               pn_tran_code IN NUMBER,
                                               ps_tran_cd IN VARCHAR2,
                                               ps_channel_cd IN VARCHAR2,
                                               ps_payment_type IN VARCHAR2,
                                               ps_status    IN VARCHAR2,
                                               ps_payment_details IN CLOB,
                                               ps_defined_date IN VARCHAR2,
                                               ps_execution_time IN VARCHAR2,
                                               ps_period IN VARCHAR2,
                                               ps_user_created IN VARCHAR2 ,
                                               pd_created_date IN DATE,
                                               ps_user_approved IN VARCHAR2 DEFAULT NULL,
                                               pd_approved_date IN DATE DEFAULT NULL,
											   pn_seq_id IN NUMBER DEFAULT NULL,
											   ps_next_date   IN VARCHAR2 DEFAULT NULL,
                                               pn_account_no IN NUMBER DEFAULT NULL,
                                               ps_prev_date IN VARCHAR2 DEFAULT NULL,
                                               ps_prev_code IN VARCHAR2 DEFAULT NULL,
                                               ps_prev_err IN VARCHAR2 DEFAULT NULL,
                                               ps_details IN VARCHAR2 DEFAULT NULL,
                                               ps_upd_info IN CLOB DEFAULT NULL) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    INSERT INTO TBL_AUTOPAYMENT_LOG
    (seq_id, operation, payment_name, person_id, customer_id, tran_code, tran_cd,
    channel_cd, payment_type, status, payment_details, defined_date, execution_time, 
     next_date_time, period, created_by, created_date, approved_by, approved_date,
     account_no, prev_date, prev_ret_code, prev_err_details, details, upd_info)
    VALUES
    (pn_seq_id, ps_operation, ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd,
    ps_channel_cd, ps_payment_type, ps_status, ps_payment_details, ps_defined_date, ps_execution_time,
      ps_next_date, ps_period, ps_user_created, pd_created_date, ps_user_approved, pd_approved_date,
      pn_account_no, ps_prev_date, ps_prev_code, ps_prev_err,  ps_details, ps_upd_info);

    COMMIT;    
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_log.addAutopaymentLog', pn_seq_id || ' ' || ps_operation ||  ' ' || pn_tran_code || ' ' || pn_person_id || ' ' || ps_details, SQLERRM);
END;

END;
/

