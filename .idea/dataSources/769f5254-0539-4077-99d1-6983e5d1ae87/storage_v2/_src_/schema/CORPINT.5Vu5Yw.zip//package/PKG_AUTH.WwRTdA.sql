create PACKAGE         pkg_auth IS

TYPE CursorReferenceType IS REF CURSOR;

-------------------------------------------------------------------
FUNCTION CheckUser(ps_channelcd IN VARCHAR2,
       ps_username IN VARCHAR2,
          ps_passcode IN VARCHAR2,
          ps_pincode IN VARCHAR2,
      pn_sessionid OUT NUMBER,
      ps_ticketid OUT VARCHAR2,
      pn_personid OUT NUMBER,
      ps_pwdforcechange OUT VARCHAR2,
      ps_tokenid OUT VARCHAR2
      ) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION CheckTicket(pn_sessionid   IN NUMBER,
                     ps_ticketid    IN VARCHAR2,
                       ps_channelcd   IN VARCHAR2,
                        ps_trancd      IN VARCHAR2,
                     ps_pageid      IN VARCHAR2,
                       ps_newticketid OUT VARCHAR2,
                       pn_personid    OUT NUMBER,
                       pn_customerid  OUT VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION SafeExit(pn_sessionid IN NUMBER) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION ChangeAlias(ps_channelcd IN VARCHAR2,
       pn_personid IN NUMBER,
      ps_newusername IN VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION ChangePwdPin(ps_option IN VARCHAR2,
        ps_channelcd IN VARCHAR2,
        pn_personid IN NUMBER,
           ps_oldcode IN VARCHAR2,
           ps_newcode IN VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION LastLoginDate(pn_personid IN NUMBER,ps_lastlogindate OUT VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION CreatePassID(ps_uid IN VARCHAR2,
        ps_pwd IN VARCHAR2,
        ps_pin IN VARCHAR2,
           ps_passid OUT VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION AssignPassID(ps_option IN VARCHAR2,
                                        ps_channelcd IN VARCHAR2,
                                        ps_assignedby IN VARCHAR2,
                                        pn_passid IN VARCHAR2,
                                        ps_customerid IN VARCHAR2,
                                        ps_customername IN VARCHAR2,
                                        ps_control IN VARCHAR2,
                                        ps_superuser IN VARCHAR2,
                                        ps_ImzaAmnt IN VARCHAR2,
                                        ps_rnn IN VARCHAR2,
                                        ps_imzacy IN VARCHAR2,
                                        ps_create IN VARCHAR2,
                                        ps_activate IN VARCHAR2,
                                        ps_person IN VARCHAR2,
                                        ps_appupdlmt IN VARCHAR2,
                                        pd_enddate IN VARCHAR2,
                                        ps_printpassid IN VARCHAR2,
                                        ps_appupdsplmt IN VARCHAR2,
                                        ps_otpChoice  IN VARCHAR2) RETURN VARCHAR2;
/*
FUNCTION AssignPassID(ps_option IN VARCHAR2,
                                        ps_channelcd IN VARCHAR2,
                                        ps_assignedby IN VARCHAR2,
                                        pn_passid IN VARCHAR2,
                                        ps_customerid IN VARCHAR2,
                                        ps_customername IN VARCHAR2,
                                        ps_control IN VARCHAR2,
                                        ps_superuser IN VARCHAR2,
                                        ps_ImzaAmnt IN VARCHAR2,
                                        ps_rnn IN VARCHAR2,
                                        ps_imzacy IN VARCHAR2,
                                        ps_create IN VARCHAR2,
                                        ps_activate IN VARCHAR2,
                                        ps_person IN VARCHAR2,
                                        ps_appupdlmt IN VARCHAR2,
                                        pd_enddate IN VARCHAR2,
                                        ps_printpassid IN VARCHAR2) RETURN VARCHAR2;
                                        */
--------------------------------------------------------------------
FUNCTION CheckToken(ps_channelcd IN VARCHAR2,
      pn_sessionid IN NUMBER,
      ps_ticketid IN VARCHAR2,
      ps_tokenid IN VARCHAR2) RETURN VARCHAR2;
--------------------------------------------------------------------
FUNCTION UploadTokenData(ps_DIGIPASS IN VARCHAR2,
                         ps_ALGO_TYPE IN VARCHAR2,
       ps_DP_TYPE IN VARCHAR2,
       ps_DP_DATA IN VARCHAR2,
       ps_OTP_VALIDATION_PERIOD IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION GetTokenData(ps_DIGIPASS IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
----------------------------------------------------------------------------
FUNCTION GetTokenSerial(ps_person_id IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION SetTokenData(ps_DIGIPASS IN VARCHAR2,
        ps_DIGIDATA IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION GetCustomerTokenData(ps_sessionID IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION SetSessionStatus(ps_sessionID IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION SetNewPassword(ps_password IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION GetLastSessionInfo(pn_personid IN VARCHAR2,
                            pn_customerid IN VARCHAR2,
       ps_channelcd IN VARCHAR2,
       ps_langid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION GetTodayProcessInfo(pn_personid IN VARCHAR2,
                            pn_customerid IN VARCHAR2,
       ps_channelcd IN VARCHAR2,
       ps_bankdate IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION WrongAttempCount(pn_personid IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION ChangePrl(ps_channelcd IN VARCHAR2,
                   ps_personid IN VARCHAR2,
       ps_oldparola IN VARCHAR2,
       ps_newparola IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION VerifyParola(ps_parola IN VARCHAR2,
                   ps_personid IN VARCHAR2,
                   ps_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION CheckParola( ps_channelcd IN VARCHAR2,
                      ps_sessionid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION SetCustomerParola(
                      ps_sessionid IN VARCHAR2,
                      ps_channelcd IN VARCHAR2,
                      ps_parola IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
   FUNCTION ClearingToDo (
                    p_from_acc                VARCHAR2,
                    ps_payee_info              VARCHAR2,
                    pd_trandate                VARCHAR2,
                    ps_sender_name             VARCHAR2,
                    ps_sender_phone            VARCHAR2,
                    ps_bank_code               VARCHAR2,
                    ps_payee_name              VARCHAR2,
                    ps_to_account              VARCHAR2,
                    pn_amount                  VARCHAR2,
                    ps_description             VARCHAR2,
                    ps_save_payee_flag         VARCHAR2,
                    ps_payee_nick              VARCHAR2,
                    pn_paycode                 VARCHAR2,
                    ps_status                  VARCHAR2,
                    pn_person                  VARCHAR2,
                    ps_subaccount                 VARCHAR2,
                    ps_subname                 VARCHAR2,
                    ps_payforservice             VARCHAR2,
                    ps_commision              VARCHAR2,
                    ps_transfer_option          VARCHAR2, --ernestk 14022014 cqdb00000504 to make gross or clearing
                    ps_order_number             VARCHAR2 DEFAULT '', --ernestk 12062014 cqdb864 add order number
                    pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION SetVerifyUpdateFlag(ps_txNo IN VARCHAR2,
                        ps_customerid IN VARCHAR2,
      ps_verifiedapprovedid IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION SetVerifyMaker(ps_txNo IN VARCHAR2,
      ps_personno IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------
FUNCTION SetCheckMaker(ps_txNo IN VARCHAR2,
      ps_personno IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------
FUNCTION SetApproveMaker(ps_txNo IN VARCHAR2,
      ps_personno IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------
FUNCTION DeleteTxToDo(ps_txNo IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-----------------------------------------------------------------
FUNCTION RejectTxToDo(ps_txNo IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------
FUNCTION GetTxToDoHistory(ps_customerID IN VARCHAR2,
      ps_channelCD IN VARCHAR2,
      ps_startdate IN VARCHAR2,
      ps_enddate IN VARCHAR2,
           ps_status IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------
FUNCTION FXBuySellToDo (
    ps_trantype IN VARCHAR2,
    pn_BORC_HESAP_NO IN VARCHAR2,
    ps_DOVIZ_KODU IN VARCHAR2,
    pn_KUR IN VARCHAR2,
    pn_TUTAR IN VARCHAR2,
    pn_ALACAK_HESAP_NO IN VARCHAR2,
    ps_ISTATISTIK_KODU IN VARCHAR2,
    ps_ACIKLAMA IN VARCHAR2,
    pn_REZERVASYON_NO IN VARCHAR2,
    ps_MASRAF IN VARCHAR2,
    ps_TAHSIL_ADILEN_TOPLAM_TUTAR IN VARCHAR2,
       ps_status                  VARCHAR2,
       pn_person                  VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------
FUNCTION UpdateCustomerInfoToDo (
    ps_custno IN VARCHAR2,
    ps_adres IN VARCHAR2,
    ps_zipcode IN VARCHAR2,
    ps_mphone1 IN VARCHAR2,
    ps_mphone2 IN VARCHAR2,
    ps_hphone1 IN VARCHAR2,
    ps_hphone2 IN VARCHAR2,
    ps_email IN VARCHAR2,
    ps_country IN VARCHAR2,
       ps_status                  VARCHAR2,
       ps_person                  VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------
FUNCTION GetPersonInfoIR(ps_custno IN VARCHAR2,
            ps_person IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------
FUNCTION GetSpecPersonInfoIR(ps_custno IN VARCHAR2,
            ps_person IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------
FUNCTION UpdateSignature(ps_UserID IN VARCHAR2,
            ps_customer IN VARCHAR2,
            ps_ImzaAmnt IN VARCHAR2,
            ps_imzacy IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------
FUNCTION UpdateSpecSignature(ps_UserID IN VARCHAR2,
            ps_customer IN VARCHAR2,
            ps_ImzaAmnt IN VARCHAR2,
            ps_imzacy IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------
FUNCTION BooktoBookTransferToDo (
                                                        ps_fromaccount IN VARCHAR2,
                                                        ps_toaccount IN VARCHAR2,
                                                        ps_amount IN VARCHAR2,
                                                        ps_description IN VARCHAR2,
                                                        ps_currencycode IN VARCHAR2,
                                                        ps_decontistiyormu IN VARCHAR2,
                                                        ps_stat IN VARCHAR2,
                                                        ps_personid IN VARCHAR2,
                                                        ps_trancd IN VARCHAR2,
                                                        ps_payeename IN VARCHAR2,
                                                        ps_internalacc IN VARCHAR2,
                                                        ps_paymentcode IN VARCHAR2,
                                                        ps_fromirsseco IN VARCHAR2,
                                                        ps_toirsseco IN VARCHAR2,
                                                        ps_commision IN VARCHAR2,
                                                        ps_order_number IN VARCHAR2 DEFAULT '', --chyngyzo 10122014 cq1264 add order number
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------
FUNCTION CheckUserNameandPassword(
                      ps_channelcd IN VARCHAR2,
                      ps_username IN VARCHAR2,
                      ps_password IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------
FUNCTION CheckUserPinCode(
                      ps_channelcd IN VARCHAR2,
                      ps_pincode IN VARCHAR2,
                      ps_sessionid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------
FUNCTION SetWrongTokenAttemp(
                      ps_channelcd IN VARCHAR2,
                      ps_sessionid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION ChechandClearWrongAttempt(
                      ps_personid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------
FUNCTION AddUtilityPaymentToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
                p_FromAccount IN VARCHAR2,
    p_SenderName IN VARCHAR2,
    p_InstitutionCD IN VARCHAR2,
    p_Description IN VARCHAR2,
    p_Amount IN VARCHAR2,
    p_AreaCD IN VARCHAR2,
    p_PhoneNo IN VARCHAR2,
    p_SubscriptionNo IN VARCHAR2,
    p_InvoiceNo IN VARCHAR2,
    p_KeyNo IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION AddClearingCancelToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
                p_TxNo IN VARCHAR2,
    p_SenderAccount IN VARCHAR2,
    p_SenderName IN VARCHAR2,
    p_SenderRNN IN VARCHAR2,
    p_PayeeBranch IN VARCHAR2,
    p_PayeeAccount IN VARCHAR2,
    p_PayeeName IN VARCHAR2,
    p_PayeeRNN IN VARCHAR2,
    p_Amount IN VARCHAR2,
    p_TranDate IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION SetCurrencyController(ps_txNo IN VARCHAR2,
    ps_personno IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION AddPensionPaymentToDo (p_PersonID    IN VARCHAR2,
           p_StatusCD    IN VARCHAR2,
                    p_FileName     IN VARCHAR2,
        p_FromAccount  IN VARCHAR2,
        p_FromRNN    IN VARCHAR2,
        p_32A_Date     IN VARCHAR2,
        p_32A_Amount   IN VARCHAR2,
        p_ToAccount    IN VARCHAR2,
        p_ToNBAccount  IN VARCHAR2,
        p_ToBranch     IN VARCHAR2,
        p_ToRNN       IN VARCHAR2,
        p_KNP       IN VARCHAR2,
        p_ValueDate    IN VARCHAR2,
        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION AddCardPaymentToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
                p_FromAccount IN VARCHAR2,
    p_ToCard IN VARCHAR2,
    p_Description IN VARCHAR2,
    p_Amount IN VARCHAR2,
    P_CurCode IN VARCHAR2,
    p_AccountOwner IN VARCHAR2,
    p_CardOwner IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION AddSwiftPaymentToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
    p_StartDate    IN VARCHAR2,
    p_EndDate    IN VARCHAR2,
    p_FromAccount  IN VARCHAR2,
                p_BankCountry IN VARCHAR2,
    p_BankCity IN VARCHAR2,
    p_BankName    IN VARCHAR2,
    p_BankCode    IN VARCHAR2,
                p_BranchName IN VARCHAR2,
    p_BenAccount IN VARCHAR2,
    p_BenName IN VARCHAR2,
    p_BenAddress IN VARCHAR2,
    p_Description IN VARCHAR2,
    p_Amount IN VARCHAR2,
    P_CurCode IN VARCHAR2,
    p_Commission IN VARCHAR2,
    p_PaymentCode IN VARCHAR2,
    p_StatisticCode IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
 FUNCTION AddTransferPaymentToDo (
      p_from_acc                VARCHAR2,
      ps_payee_info              VARCHAR2,
      pd_trandate                VARCHAR2,
      ps_sender_name             VARCHAR2,
      ps_sender_phone            VARCHAR2,
      ps_bank_code               VARCHAR2,
      ps_payee_name              VARCHAR2,
      ps_to_account              VARCHAR2,
      pn_amount                  VARCHAR2,
      ps_description             VARCHAR2,
      ps_save_payee_flag         VARCHAR2,
      ps_payee_nick              VARCHAR2,
      ps_senderirsseco             VARCHAR2,
      pn_rnn                     VARCHAR2,
      pn_doc_no                  VARCHAR2,
      pn_stat                    VARCHAR2,
      pn_paycode                 VARCHAR2,
      pn_income                  VARCHAR2,
      ps_status                  VARCHAR2,
      pn_person                  VARCHAR2,
      pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2;
---------------------------------------------------------------------------------------
FUNCTION PaymentOrderToDo (
      pn_from_acc                VARCHAR2,
      pd_startdate               VARCHAR2,
      ps_sender_name             VARCHAR2,
      ps_bank_code               VARCHAR2,
      ps_payee_name              VARCHAR2,
      ps_to_account              VARCHAR2,
      pn_total_amount            VARCHAR2,
      ps_description             VARCHAR2,
      ps_senderirsseco           VARCHAR2,
      pn_rnn                     VARCHAR2,
      pn_doc_no                  VARCHAR2,
      pn_stat                    VARCHAR2,
      pn_income                  VARCHAR2,
   ps_currency                VARCHAR2,
   pn_payee_internal_acc      VARCHAR2,
   pn_payment_code            VARCHAR2,
   pn_institution_cd          VARCHAR2,
   pn_area_cd                 VARCHAR2,
   pn_phone_no                VARCHAR2,
   ps_tran_type               VARCHAR2,
   ps_payment_type            VARCHAR2,
   pn_informing               VARCHAR2,
   pn_payment_period          VARCHAR2,
   pn_endofweek               VARCHAR2,
   pn_personid                VARCHAR2,
   pd_end_date                VARCHAR2,
   ps_status                  VARCHAR2,
   pn_payment_no              VARCHAR2,
      pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION PaymentOrderCancelToDo (ps_person_id      VARCHAR2,
         ps_status         VARCHAR2,
         ps_txno           VARCHAR2,
          pn_order_id       VARCHAR2,
         ps_tran_type      VARCHAR2,
         pn_from_acc       VARCHAR2,
         ps_amount         VARCHAR2,
         ps_payment_date   VARCHAR2,
         ps_currency       VARCHAR2,
              pc_ref        OUT   cursorreferencetype) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------
FUNCTION AddSalaryPaymentToTableToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
    p_FileName IN VARCHAR2,
                p_FromAccount IN VARCHAR2,
    p_TXNO IN VARCHAR2,
    p_TotalAmount IN VARCHAR2,
    p_TotalCount IN VARCHAR2,
    p_CurrencyCode IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------
FUNCTION AddFXOrdersToDo (
     p_PersonID      VARCHAR2,
    p_StatusCD      VARCHAR2,
    ps_trantype      VARCHAR2,
                pn_fromaccount   VARCHAR2,
    ps_currency      VARCHAR2,
    pn_to_account    VARCHAR2,
    ps_irsseco       VARCHAR2,
    ps_description   VARCHAR2,
    pn_fxamount      VARCHAR2,
    pn_totalamount   VARCHAR2,
    ps_periodtype    VARCHAR2,
    ps_periodlength  VARCHAR2,
    ps_rate          VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------
FUNCTION AddFXOrdersCancelToDo (p_PersonID      VARCHAR2,
           p_StatusCD      VARCHAR2,
           pn_txno          VARCHAR2,
                       pn_orderid       VARCHAR2,
           ps_trantype      VARCHAR2,
           pn_fromaccount   VARCHAR2,
           pn_toaccount   VARCHAR2,
           pn_rate      VARCHAR2,
           pn_amount        VARCHAR2,
           ps_currency     VARCHAR2,
           ps_periodtype    VARCHAR2,
           pn_periodlength  VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------
FUNCTION AddArbitrageToDo (p_PersonID      VARCHAR2,
         p_StatusCD      VARCHAR2,
                     pn_fromaccountno  VARCHAR2,
         pn_toaccountno    VARCHAR2,
         ps_fromcurrency   VARCHAR2,
         ps_tocurrency     VARCHAR2,
         ps_parity         VARCHAR2,
         pn_fromamount     VARCHAR2,
         pn_toamount       VARCHAR2,
         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------
FUNCTION AddPayToAnotherCardToDo (p_PersonID    IN VARCHAR2,
          p_StatusCD    IN VARCHAR2,
                      p_FromAccount    IN VARCHAR2,
          p_ToCard      IN VARCHAR2,
          p_Description    IN VARCHAR2,
          p_Amount      IN VARCHAR2,
          P_CurCode     IN VARCHAR2,
          p_AccountOwner   IN VARCHAR2,
          p_CardOwner     IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION DDSToDo(pn_PersonID       IN VARCHAR2,
                 ps_StatusCD       IN VARCHAR2,
                 pn_SupplierAccNo  IN VARCHAR2,
                 ps_SupplierName   IN VARCHAR2,
                   pn_PartnerAccNo   IN VARCHAR2,
                 ps_PartnerName    IN VARCHAR2,
                 pn_InvoiceNo      IN VARCHAR2,
                   ps_Description    IN VARCHAR2,
                   pn_Amount         IN VARCHAR2,
                   ps_CurrencyCd     IN VARCHAR2,
                 pd_InvoiceDate    IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------
FUNCTION AssignCustomerAccounts(ps_CustomerNo IN VARCHAR2,
                                 ps_PersonID      IN VARCHAR2,
                                ps_Params      IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--B-O-M ernestk 24032014 cqdb00000862 function to add card debt payment transaction for todo
/*******************************************************************************
    Name:           CardDebtPaymentToDo
    Prepared By:    Ernest Kuttubaev
    Modify Date:    24.03.2014
    Purpose:        To add card debt payment transaction for todo
*******************************************************************************/
FUNCTION CardDebtPaymentToDo (
                    ps_customer_id              VARCHAR2,
                    ps_person_id                VARCHAR2,
                    ps_from_acc                 VARCHAR2,
                    ps_amount                   VARCHAR2,
                    ps_card_no                  VARCHAR2,
                    ps_hashed_card_no           VARCHAR2,--ernestk 16062014 cqdb864 add hashed card no
                    ps_stat                     VARCHAR2,
                    ps_description              VARCHAR2,
                    ps_pseudopan            VARCHAR2,
                    pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2;
--E-O-M ernestk 24032014 cqdb00000862 function to add card debt payment transaction for todo
-----------------------------------------------------------------------------------------------
/*******************************************************************************
    Name:           ServicePaymentToDo
    Prepared By:    Almas Nurkhozhayev
    Modify Date:    14.04.2015
    Purpose:        To do service payments
*******************************************************************************/
FUNCTION ServicePaymentToDo(ps_fromaccountno   IN VARCHAR2,
                            ps_amount          IN VARCHAR2,
                            ps_person_id       IN VARCHAR2,
                            ps_description     IN VARCHAR2,
                            ps_institution     IN VARCHAR2,
                            ps_phone_area_code IN VARCHAR2,
                            ps_phone_no        IN VARCHAR2,
                            ps_service_code    IN VARCHAR2,
                            ps_service_no      IN VARCHAR2,
                            ps_status          IN VARCHAR2,
                            pc_ref             OUT   cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  SwiftToDo
   Created By :  Chyngyz Omurov, cq509
   Date       : 10.03.2015
   Purpose   : Save SWIFT info to table TBL_TXTODO
******************************************************************************/
FUNCTION SwiftToDo(
                                           ps_sender_acc_no IN VARCHAR2,
                                           ps_country_code IN VARCHAR2,
                                           ps_currency IN VARCHAR2,
                                           ps_amount IN VARCHAR2,
                                           ps_value_date IN VARCHAR2,
                                           ps_charge_party IN VARCHAR2, --who pays charge,  (BEN, OUR, GOUR)
                                           ps_stat_code IN VARCHAR2,
                                           ps_description IN VARCHAR2,
                                           ps_comm_acc_no IN VARCHAR2,
                                           ps_charge_amount IN VARCHAR2,
                                           ps_ben_acc_no IN VARCHAR2,
                                           ps_ben_name IN VARCHAR2,
                                           ps_ben_address IN VARCHAR2,
                                           ps_ben_swiftcode IN VARCHAR2, --bic code of beneficiary bank
                                           ps_ii_bic IN VARCHAR2,                 --intermediary institution bic code

                                           ps_person        IN VARCHAR2,
                                           ps_tran_status    IN VARCHAR2,
                                           ps_contract_date IN VARCHAR2,
                                           ps_contract_no IN VARCHAR2,
                                           ps_corrbank_name IN VARCHAR2,
                                           ps_filename IN VARCHAR2,
                                           ps_ben_bank_branch IN VARCHAR2,

                                           ps_invoice_date IN VARCHAR2,
                                           ps_invoice_no IN VARCHAR2,
                                           
                                           ps_UAE_stat_code IN VARCHAR2, --Bakdoolot ibc-52 25.01.22
                                           
                                           ps_Inn_and_Kpp IN VARCHAR2, --Esen Omurchiev ibc-74 01.04.2022

                                           pc_ref           OUT cursorreferencetype) RETURN VARCHAR2;


/*******************************************************************************
    Name        : FUNCTION AddSalaryPaymentList
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Add Salary Payment List
*******************************************************************************/
FUNCTION AddSalaryPaymentList(pn_tx_no NUMBER,
                                                            pn_company_acc_no NUMBER,
                                                            ps_staff_acc_no VARCHAR2,
                                                            ps_name VARCHAR2,
                                                            ps_surname VARCHAR2,
                                                            ps_patronymic VARCHAR2,
                                                            ps_order NUMBER,
                                                            ps_status VARCHAR2,
                                                            pn_amount NUMBER,
                                                            ps_currency VARCHAR2,
                                                            pn_company_cust_no NUMBER,
                                                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/*******************************************************************************
    Name        : FUNCTION AddSalaryPaymentToDo
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Add Salary Payment To Do
*******************************************************************************/
 FUNCTION AddSalaryPaymentToDo(pn_tx_no NUMBER,
                                                               ps_type VARCHAR2,
                                                               pn_fromAccount NUMBER,
                                                               pn_totalAmount NUMBER,
                                                               ps_currency VARCHAR2,
                                                               ps_commType VARCHAR2,
                                                               ps_commAmount VARCHAR2,
                                                               ps_description VARCHAR2,
                                                               ps_fileName VARCHAR2,
                                                               pn_staffCount NUMBER,
                                                               ps_transStatus  VARCHAR2,
                                                               ps_personId VARCHAR2,
                                                               ps_paymentCode VARCHAR2,
                                                               ps_valueDate VARCHAR2,
                                                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

END Pkg_Auth;
/

