create PACKAGE         PKG_CINT_MONITOR IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  GetUserInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Return User Information and last login date
******************************************************************************/
FUNCTION  GetUserInfo(pn_SessionID  IN VARCHAR2,
                      pn_CustomerID IN VARCHAR2,
                      pn_PersonID   IN VARCHAR2,
                      pc_ref  OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType,
                      pc_ref4 OUT CursorReferenceType,
                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  DisplayLimitInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.12.07
   Purpose   : Display Limit Info
******************************************************************************/
FUNCTION DisplayLimitInfo(ps_channelcd  IN VARCHAR2,
                           ps_customerid    IN VARCHAR2,
                           ps_personid    IN VARCHAR2,
                           ps_langid        IN VARCHAR2,
                              pc_ref  OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType,
                          pc_ref4 OUT CursorReferenceType,
                          pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetTokenSerial
   Created By : Muzaffar Khalyknazarov
   Date       : 09.12.07
   Purpose    : Get Token Serial
******************************************************************************/
FUNCTION GetTokenSerial(ps_person_id IN VARCHAR2,
                            pc_ref  OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType)RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetTokenData
   Created By : Muzaffar Khalyknazarov
   Date       : 09.12.07
   Purpose    : Get Token Serial
******************************************************************************/
FUNCTION GetTokenData(ps_DIGIPASS IN VARCHAR2,
                      pc_ref  OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType,
                      pc_ref4 OUT CursorReferenceType,
                      pc_ref5 OUT CursorReferenceType)RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetLabelInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 28.12.07
   Purpose   : Get Label Info
******************************************************************************/
FUNCTION  GetLabelInfo(ps_channelcd IN VARCHAR2,
                       ps_trancd    IN VARCHAR2,
                       ps_pageid    IN VARCHAR2,
                       ps_langcd    IN VARCHAR2,
                       ps_personid  IN VARCHAR2,
                       pc_ref  OUT CursorReferenceType,
                       pc_ref2 OUT CursorReferenceType,
                       pc_ref3 OUT CursorReferenceType,
                       pc_ref4 OUT CursorReferenceType,
                       pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME          : FUNCTION GetPayeeInfo
   Prepared By   : Almas Nurhozhaev
   Date          : 27.12.2007
   Purpose       : Get Payee Info
   Modified By   : Tastan Zhaylibayev
   Modified Date : 03.01.2008
******************************************************************************/
FUNCTION GetPayeeInfo(ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2 DEFAULT NULL,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME          : FUNCTION AddPayeeInfo
   Prepared By   : Almas Nurhozhaev
   Date          : 27.12.2007
   Purpose       : Add Payee Info
   Modified By   : Tastan Zhaylibayev
   Modified Date : 03.01.2008
******************************************************************************/
FUNCTION AddPayeeInfo(ps_option    IN VARCHAR2,
                       ps_PAYEE_ID IN VARCHAR2,
                       ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2,--EFT/MO
                      ps_SENDERNAME IN VARCHAR2,
                      ps_BANKCD IN VARCHAR2,
                      ps_PAYEENAME IN VARCHAR2,
                      ps_TOACCOUNT IN VARCHAR2,
                      ps_PAYMENTCD IN VARCHAR2,
                      ps_NICKNAME IN VARCHAR2,
                      ps_CURRCODE IN VARCHAR2,
                      ps_SENDERPHONE IN VARCHAR2 DEFAULT ' ',
                      ps_PAYEEPHONE IN VARCHAR2 DEFAULT ' ',
                      ps_rnn IN VARCHAR2,
                      ps_stat IN VARCHAR2,
                      ps_income IN VARCHAR2,
                      ps_docno IN VARCHAR2
                      ) RETURN VARCHAR2;
FUNCTION GetSecurityInfo(pn_Person_id IN VARCHAR2,
                         pc_ref  OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType,
                         pc_ref4 OUT CursorReferenceType,
                         pc_ref5 OUT CursorReferenceType)RETURN VARCHAR2;
                         
/******************************************************************************
   NAME        : FUNCTION GetPersonAgenda
   Prepared By : Almas Adilbek
   Date        : 21.04.08
   Purpose     : Get Person Agenda DAtas
******************************************************************************/
FUNCTION GetPersonAgenda(pn_personCD IN VARCHAR2,                               
                            ps_langCD IN VARCHAR2,
                             pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;    
/******************************************************************************
   NAME        : FUNCTION GetAllAgendaEvents
   Prepared By : Almas Adilbek
   Date        : 13.05.08
   Purpose     : Get All Agenda Events
******************************************************************************/
FUNCTION GetAllAgendaEvents(pn_personCD IN VARCHAR2,                               
                            ps_langCD IN VARCHAR2,
                             pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  UpdatePersonLimitInfo
   Created By : Almas Nurkhozhayev
   Date       : 05.11.09
   Purpose   : Update Personal Limit Info
******************************************************************************/
FUNCTION UpdatePersonLimitInfo(ps_channelcd   IN VARCHAR2,
                               ps_trancd      IN VARCHAR2,
                               ps_personid    IN VARCHAR2,
                               ps_daily_limit IN VARCHAR2,
                               ps_langid      IN VARCHAR2,
                               ps_customerid  IN VARCHAR2) RETURN VARCHAR2;
                                               
END Pkg_CINT_Monitor;
/

