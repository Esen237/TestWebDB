create PACKAGE BODY         "PKG_CINT_AUTHORITY" IS
-----------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  CheckTicket
   Created By : Muzaffar Khalyknazarov
   Date       : 04.12.07
   Purpose   : Check Ticket
******************************************************************************/

FUNCTION CheckTicket(pn_sessionid   IN NUMBER,
                     ps_ticketid    IN VARCHAR2,
                     ps_channelcd   IN VARCHAR2,
                     ps_trancd      IN VARCHAR2,
                     ps_pageid      IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    CURSOR cursor_session IS
        SELECT * FROM TBL_SESSION s
        WHERE s.CHANNEL_CD=ps_channelcd
        AND s.SESSION_ID=pn_sessionid
        AND s.STATUS_CD='sACTIVE';

    CURSOR cursor_ticket(pn_personid NUMBER) IS
        SELECT * FROM TBL_TICKET_HISTORY t
        WHERE t.SESSION_ID=pn_sessionid
        AND t.TICKET_ID=(select ticket_id from (select aa.ticket_id from corpint.tbl_ticket_history aa where aa.session_id=pn_sessionid order by aa.dlm desc) where rownum=1)
        AND t.PERSON_ID=pn_personid
        AND (t.DLM+(8/(24*60))) > SYSDATE;

    CURSOR cursor_authtran(pn_personid NUMBER) IS
        SELECT TRAN_CD FROM TBL_AUTH_TRAN a
        WHERE  a.TRAN_CD=ps_trancd
        AND a.AUTH_CD IN (SELECT AUTH_CD FROM TBL_PERSON_AUTH p
        WHERE p.PERSON_ID=pn_personid
        AND p.CHANNEL_CD=ps_channelcd);

    CURSOR cursor_person(pn_personid NUMBER) IS
        SELECT * FROM TBL_PERSON p
        WHERE p.PERSON_ID=pn_personid;

        row_session cursor_session%ROWTYPE;
        row_ticket cursor_ticket%ROWTYPE;
        row_authtran cursor_authtran%ROWTYPE;
        row_person cursor_person%ROWTYPE;

        TransactionError EXCEPTION;
        ls_statement     VARCHAR2(2000);
        ls_returncode    VARCHAR2(3):='000';
        ln_ticketindx    NUMBER:=0;
        ln_personid      NUMBER:=0;
        ls_ticketid      VARCHAR2(40):=' ';
        ln_customerid    VARCHAR2(13):='0';
        ls_cusmomername  VARCHAR2(200):=' ';
        ps_newticketid   VARCHAR2(50);
        pn_personid      VARCHAR2(50);
        pn_customerid    VARCHAR2(50);
        ls_forcechange   VARCHAR2(1):='H';

        li_id integer;
        ls_tran_cd varchar2(10):='';
        ls_required varchar2(1);
        ls_block_menu varchar2(1);
        ls_redirect_page varchar2(20);
        ln_times number;
        ln_person_times number;
        ld_start_date date;
        ld_end_date date;
        ld_create_date date;
        ln_repeat_in_months number;
        ln_count number:=0;
        ls_last_tran_cd varchar2(10);
        ls_person_type varchar2(10);
        ln_insider_count number;
        ln_staff_count number;

        ls_4003_CIB_SWITCH VARCHAR2(5); --chyngyzo cq509 10/07/2015
      --  ls_4003_TEST_CUSTOMER_NOS VARCHAR2(2000);  --chyngyzo cq509 10/07/2015 CBS-620 14.05.2022
        ln_count3 NUMBER;
BEGIN
    IF TO_NUMBER(ps_pageid)<>0 THEN

        UPDATE TBL_SESSION
        SET DOUBLE_CLICK=0
        WHERE CHANNEL_CD=ps_channelcd
        AND SESSION_ID=TO_NUMBER(pn_sessionid)
        AND STATUS_CD='sACTIVE';
    END IF;

    --0)Initialize the outparams
    ps_newticketid:=ls_ticketid;
    pn_personid:=ln_personid;
    pn_customerid:=ln_customerid;

    --1)Person has valid session
    OPEN cursor_session;
    FETCH cursor_session INTO row_session;

        IF  cursor_session%NOTFOUND THEN
            ls_returncode:='005';
            RAISE TransactionError;
        ELSE
            ln_personid:=row_session.PERSON_ID;
            pn_personid:=ln_personid;
        END IF;

        IF row_session.double_click=1 THEN
            ls_returncode:='030';
            RAISE TransactionError;
        END IF;

    CLOSE cursor_session;

    --x) it this cusotmer is not swift insider or staff then take off authority
    select count(*) into ln_insider_count
    from CORPINT.TBL_SWIFT_INSIDERS
    where PERSON_ID=pn_personid;

    select count(*) into ln_staff_count
    from cbs_musteri
    where MUSTERI_NO in (select customer_id from corpint.tbl_person where person_id=pn_personid)
    and PERSONEL_SICIL_NO is not null;
    
    --check Swift country 13-01-2022 Esen Omurchiev
    SELECT count(*) 
        INTO ln_count3 
        FROM CBS_SWIFT_BANK_RESTRICTIONS 
                                  WHERE (COUNTRY_CODE in (select upper(UYRUK_KOD) from CBS.CBS_MUSTERI 
                                                                                   WHERE MUSTERI_NO in(SELECT CUSTOMER_ID FROM CORPINT.TBL_PERSON 
                                                                                                                           WHERE PERSON_ID = pn_personid))  
                                                                                                                           AND  CITIZEN_BLOCK_FLAG = 'Y');
    if ln_count3 > 0 and  (ps_trancd='SWIFT') then
         ls_returncode:='007';
         RAISE TransactionError;
    end if;

    if (ln_insider_count <= 0) and (ln_staff_count <= 0) and (ps_trancd='SWIFT') and (ps_channelcd <>'cDKBCIB') then --chyngyzo cq509 do not make this check for cDKBCIB channel
        ls_returncode:='007';
        RAISE TransactionError;
    end if;
    ---------------------------------------------------------------------------

    --2)Person has valid ticket TicketDate+7min>sysdate
    OPEN cursor_ticket(ln_personid);
    FETCH cursor_ticket INTO row_ticket;

        IF  cursor_ticket%NOTFOUND THEN
            ls_returncode:='006';
            RAISE TransactionError;
        ELSE
            ln_ticketindx:=row_ticket.TICKET_INDX;
        END IF;

    CLOSE cursor_ticket;

     /* B-O-M chyngyzo 13.02.2015 cq509 moved here because customer id is not set in session if authorization error occurs */
    OPEN cursor_person(ln_personid);
    FETCH cursor_person INTO row_person;

        IF  cursor_person%FOUND THEN
            ln_customerid:=row_person.CUSTOMER_ID;
            pn_customerid:=ln_customerid;
        END IF;

    CLOSE cursor_person;
    /* E-O-M chyngyzo 13.02.2015 cq509 moved here because customer id is not set in session if authorization error occurs */
    
     --B-O-M chyngyzo cq509 10/07/2015
     CBS.PKG_PARAMETRE.DEGER('4003_CIB_SWITCH', ls_4003_CIB_SWITCH);
     
    -- CBS.PKG_PARAMETRE.DEGER('4003_SWIFT_TEST_CUSTOMER_NOS', ls_4003_TEST_CUSTOMER_NOS);
      
      SELECT COUNT(*) INTO ln_count 
         FROM cbs_swift_access
        WHERE CUSTOMER_NO = ln_customerid AND SWIFT_STATUS='OPEN';--CBS-620 14.05.2022
        
     if ps_trancd='SWIFT' and  ps_channelcd='cDKBCIB' and nvl(ls_4003_CIB_SWITCH,'OFF') = 'OFF' AND  ln_count = 0 then--CBS-620 14.05.2022
           ls_returncode:='007';
           RAISE TransactionError;
     end if;
    --E-O-M chyngyzo cq509 10/07/2015

    --3)Person has authority to execute transaction
    OPEN cursor_authtran(ln_personid);
    FETCH cursor_authtran INTO row_authtran;

        IF  cursor_authtran%NOTFOUND THEN
            ls_returncode:='007';
            RAISE TransactionError;
        END IF;

    CLOSE cursor_authtran;

    --4)Get New Ticket
    ls_ticketid:=Pkg_Common.GetTicketID;

    IF ls_ticketid IS NULL THEN
        ls_returncode:='004';
        RAISE TransactionError;
    ELSE
        INSERT INTO TBL_TICKET_HISTORY
        (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID,DLM)
        VALUES
        (ln_personid, ls_ticketid, ln_ticketindx+1, pn_sessionid,SYSDATE);
    END IF;

        ps_newticketid:=ls_ticketid;

 /* chyngyzo 13.02.2015 cq509 moved up. customer id is not set in session if authorization error occurs
    --5)Get Customer Info
    OPEN cursor_person(ln_personid);
    FETCH cursor_person INTO row_person;

        IF  cursor_person%FOUND THEN
            ln_customerid:=row_person.CUSTOMER_ID;
            pn_customerid:=ln_customerid;
        END IF;

    CLOSE cursor_person;*/

    SELECT PWDFORCECHANGE,
           case when TOKEN_ID is null then 'NORMAL' else 'TOKEN' end
    INTO ls_forcechange, ls_person_type
    FROM TBL_IDENTIFICATION
    WHERE PERSON_ID=ln_personid;

    BEGIN
        select ID, TRAN_CD, REQUIRED, BLOCK_MENU, REDIRECT_PAGE, TIMES, START_DATE, END_DATE, CREATE_DATE, REPEAT_IN_MONTHS, LAST_TRAN_CD
        into li_id, ls_tran_cd, ls_required, ls_block_menu, ls_redirect_page, ln_times, ld_start_date, ld_end_date, ld_create_date, ln_repeat_in_months, ls_last_tran_cd
        from corpint.tbl_warning_modules
        where CHANNEL_CD=ps_channelcd
        and STATUS_CD='sENAB'
        and rownum=1;

        select count(*) into ln_count
        from corpint.tbl_warning_module_person
        where person_id = pn_personid
        and module_id = li_id;

        if (ln_count=0) then
            insert into corpint.tbl_warning_module_person
            (PERSON_ID, MODULE_ID, TIMES)
            values
            (pn_personid, li_id, 0);
        end if;

        if (sysdate>ld_create_date) then
            --update corpint.tbl_warning_module_person
            --set TIMES=0;

            update corpint.tbl_warning_modules
            set CREATE_DATE=sysdate
            where ID=li_id;
        end if;

        select count(*) into ln_count
        from corpint.tbl_warning_modules aa, corpint.tbl_warning_module_person bb
        where nvl(bb.session_id,0)<>pn_sessionid
        and AA.ID = BB.MODULE_ID
        and AA.TIMES+1 > BB.TIMES
        and BB.PERSON_ID = pn_personid;

        select times into ln_person_times
        from corpint.tbl_warning_module_person
        where MODULE_ID=li_id
        and PERSON_ID=pn_personid;

        if (ln_count=0) then
            ls_tran_cd:='';
        else
            if (ln_times=ln_person_times) then
                ls_tran_cd:=ls_last_tran_cd;
            end if;
        end if;
    EXCEPTION
        WHEN Others then
            ls_tran_cd:='';
    END;

    OPEN pc_ref FOR
    SELECT pn_sessionid, ps_newticketid, pn_personid, pn_customerid, ls_forcechange, ls_tran_cd, ls_person_type FROM dual;

     IF TO_NUMBER(ps_pageid)=0 THEN
         UPDATE TBL_SESSION
         SET DOUBLE_CLICK=1
         WHERE CHANNEL_CD=ps_channelcd
         AND SESSION_ID=TO_NUMBER(pn_sessionid)
         AND STATUS_CD='sACTIVE';
     END IF;

     RETURN ls_returncode;
EXCEPTION
  WHEN TransactionError THEN
    OPEN pc_ref FOR SELECT pn_sessionid, ps_newticketid, pn_personid, pn_customerid, 'H', '', '' FROM dual;
    RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  MultipleCheckCustomerSession
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : MultipleCheckCustomerSession
******************************************************************************/
FUNCTION MultipleCheckCustomerSession(ps_channelcd IN VARCHAR2,
                                      ps_sessionid IN VARCHAR2,
                                      ps_ticketid  IN VARCHAR2,
                                      ps_langid    IN VARCHAR2,
                                      ps_personid  IN VARCHAR2,
                                      ps_trancd    IN VARCHAR2,
                                      ps_pageid    IN VARCHAR2,
                                      pc_ref  OUT CursorReferenceType,
                                      pc_ref2 OUT CursorReferenceType,
                                      pc_ref3 OUT CursorReferenceType,
                                      pc_ref4 OUT CursorReferenceType,
                                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode      VARCHAR2(3):='000';
    ln_personid     NUMBER;
    ln_sessionid     NUMBER;
    ls_ticketid     VARCHAR2(40);
    ls_customername    VARCHAR2(250):='';
    TransactionError    EXCEPTION;

BEGIN
    --CheckCustomerSession
    ls_returncode:=Pkg_Cint_Authority.CheckTicket(ps_sessionid, ps_ticketid, ps_channelcd, ps_trancd, ps_pageid, pc_ref);

    --Get Main Menu
    Pkg_Cint_Authority.GetMainMenuInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref2);

    --Get Sub Menu
    Pkg_Cint_Authority.GetSubMenuInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref3);

    --Get Labels of the page
    Pkg_Cint_Authority.GetLabelInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref4);

    --Get Right/Left News
    Pkg_Cint_Authority.GetNewsInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref5);

    RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  GetLabelInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Get Label Info
******************************************************************************/
PROCEDURE  GetLabelInfo(ps_channelcd IN VARCHAR2,
                        ps_trancd    IN VARCHAR2,
                        ps_pageid    IN VARCHAR2,
                        ps_langcd    IN VARCHAR2,
                        ps_personid  IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) IS

        ls_name VARCHAR2(100);
BEGIN
    OPEN pc_ref FOR
        SELECT TRAN_CD ||'_'|| PAGE_ID ||'_'|| LABEL_ID LABEL_NAME, EXPLANATION
        FROM TBL_LANG_LABELS
        WHERE TRAN_CD=ps_trancd
        AND    PAGE_ID=ps_pageid
        AND    LANG_CD=ps_langcd
        ORDER BY SORT_ORDER;

END;
/******************************************************************************
   NAME       : FUNCTION  GetMainMenuInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Get Main Menu
******************************************************************************/
PROCEDURE  GetMainMenuInfo(ps_channelcd IN VARCHAR2,
                           ps_trancd    IN VARCHAR2,
                           ps_pageid    IN VARCHAR2,
                           ps_langcd    IN VARCHAR2,
                           ps_personid  IN VARCHAR2,
                           pc_ref OUT CursorReferenceType)IS

        ls_name VARCHAR2(100);
        ln_tab_count          NUMBER;
        ln_ord_count          NUMBER;
BEGIN

     OPEN pc_ref FOR
        SELECT d.EXPLANATION, m.ACTION_URL, NVL(m.MENU_TYPE,'ORD'), m.TRAN_CD, m.PAGE_CD,
                               DECODE(m.TRAN_CD,DECODE(Pkg_Cint_Authority.GetParentMenuID(ps_trancd,m.CHANNEL_CD),'TOP',ps_trancd,Pkg_Cint_Authority.GetParentMenuID(ps_trancd,m.CHANNEL_CD)),'1','0'),'-'
        --d.EXPLANATION,m.ACTION_URL,NVL(m.MENU_TYPE,'ORD'),m.TRAN_CD,m.PAGE_CD
        FROM TBL_MENU m,TBL_MENU_DESCRIPTION d
        WHERE m.CHANNEL_CD=d.CHANNEL_CD AND m.TRAN_CD=d.TRAN_CD
        AND m.PARENT_CD='TOP'
        AND d.LANG_CD=ps_langcd
        AND m.CHANNEL_CD=ps_channelcd
        and m.F_VISIBLE='Y'
        ORDER BY m.SORT_ORDER;

END;
/******************************************************************************
   NAME       : FUNCTION  GetSubMenuInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Get sub menu
******************************************************************************/
PROCEDURE  GetSubMenuInfo(ps_channelcd IN VARCHAR2,
                          ps_trancd    IN VARCHAR2,
                          ps_pageid    IN VARCHAR2,
                          ps_langcd    IN VARCHAR2,
                          ps_personid  IN VARCHAR2,
                          pc_ref OUT CursorReferenceType)IS

     ls_name VARCHAR2(100);
     ln_count NUMBER;
     ls_parentcd     VARCHAR2(10);
BEGIN

    OPEN pc_ref FOR SELECT '-' FROM DUAL;
   /* SELECT COUNT(*)
    INTO ln_count
    FROM TBL_MENU
    WHERE PARENT_CD=ps_trancd
    AND CHANNEL_CD=ps_channelcd;

    IF ln_count=0 THEN
        SELECT PARENT_CD
        INTO ls_parentcd
        FROM TBL_MENU
        WHERE TRAN_CD=ps_trancd
        AND CHANNEL_CD=ps_channelcd;
    ELSE
       ls_parentcd:=ps_trancd;
    END IF;

    OPEN pc_ref FOR
        SELECT d.EXPLANATION,m.ACTION_URL,NVL(m.MENU_TYPE,'ORD'),m.PARENT_CD,m.PAGE_CD
        FROM TBL_MENU m,TBL_MENU_DESCRIPTION d
        WHERE  m.CHANNEL_CD=d.CHANNEL_CD AND m.TRAN_CD=d.TRAN_CD
        AND m.PARENT_CD=ls_parentcd
        AND d.LANG_CD=ps_langcd
        AND m.CHANNEL_CD=ps_channelcd
        AND m.F_VISIBLE='Y'
        ORDER BY m.SORT_ORDER; */

END;

/******************************************************************************
   NAME       : FUNCTION  GetNewsInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Get News Info
******************************************************************************/
PROCEDURE  GetNewsInfo(ps_channelcd IN VARCHAR2,
                       ps_trancd    IN VARCHAR2,
                       ps_pageid    IN VARCHAR2,
                       ps_langcd    IN VARCHAR2,
                       ps_personid  IN VARCHAR2,
                       pc_ref OUT CursorReferenceType)IS

        ls_name VARCHAR2(100);
        ln_tab_count          NUMBER;
        ln_ord_count          NUMBER;
        ln_count1 NUMBER;
        ln_count2 NUMBER;
        ln_count3 NUMBER;
BEGIN


        SELECT count(*)
        INTO ln_count1
        FROM TBL_CUSTOMIZE_PERSON r
        WHERE r.PERSON_ID = TO_NUMBER(ps_personid);

        SELECT count(*)
        INTO ln_count2
        FROM TBL_CUSTOMIZE;
        
        --check Swift country 13-01-2022 Esen Omurchiev
        SELECT count(*) 
        INTO ln_count3 
        FROM CBS_SWIFT_BANK_RESTRICTIONS 
                                  WHERE (COUNTRY_CODE in (select upper(UYRUK_KOD) from CBS.CBS_MUSTERI 
                                                                                   WHERE MUSTERI_NO in(SELECT CUSTOMER_ID FROM CORPINT.TBL_PERSON 
                                                                                                                           WHERE PERSON_ID = ps_personid))  
                                                                                                                           AND  CITIZEN_BLOCK_FLAG = 'Y');


        IF ln_count1<ln_count2 THEN

            INSERT INTO tbl_customize_person(ELEMENT_ID, PERSON_ID, STATUS_CD, ELEMENT_LOCATION, SORT_ORDER)
            select ELEMENT_ID, TO_NUMBER(ps_personid), STATUS_CD, DEFAULT_LOCATION, DEFAULT_ORDER from tbl_customize
            where element_id not in (select element_id from tbl_customize_person where person_id=TO_NUMBER(ps_personid));

        END IF;

     OPEN pc_ref FOR
        SELECT n.NEWS_ID, n.CHANNEL_CD, n.TRAN_CD, n.IMAGE_URL, n.LINK_URL, n.STATUS_CD, n.NEWS_LOCATION,
               d.LANG_CD, d.SUBJECT_TEXT, d.BODY_TEXT, d.LINK_TEXT,n.NEWS_TYPE, n.SORT_ORDER,n.BOX_COLOR, n.BOX_ICON,d.SECOND_BODY
        FROM TBL_NEWS n,TBL_NEWS_DESCRIPTION d
        WHERE n.NEWS_ID=d.NEWS_ID
        AND d.LANG_CD=ps_langcd
        AND n.CHANNEL_CD=ps_channelcd
        AND n.TRAN_CD IS NULL
        AND STATUS_CD='sENAB'
        UNION
        --B-O-M ernestk cqdb00000824 return only menu's that the user have authority for
        select  n.NEWS_ID, n.CHANNEL_CD, n.TRAN_CD, n.IMAGE_URL, n.LINK_URL, n.STATUS_CD, n.NEWS_LOCATION,
               d.LANG_CD, d.SUBJECT_TEXT, d.BODY_TEXT, d.LINK_TEXT,n.NEWS_TYPE, n.SORT_ORDER,n.BOX_COLOR, n.BOX_ICON,d.SECOND_BODY 
        from    tbl_news n, tbl_news_description d 
        where   n.news_id = d.news_id
        and     n.channel_cd=ps_channelcd
        and     d.lang_cd = ps_langcd
        and     N.STATUS_CD='sENAB'
        and     n.tran_cd in (
                    select  distinct(auth.tran_cd)
                    from    tbl_auth_tran auth, tbl_person_auth pa
                    where   auth.auth_cd = pa.auth_cd
                    and     PA.CHANNEL_CD = ps_channelcd
                    and     PA.PERSON_ID = to_number(ps_personid)
                    )
        and     n.news_id in (
                            select  nt.news_id 
                            from    tbl_news_tran nt
                            where   NT.CHANNEL_CD=ps_channelcd
                            and     nt.tran_cd = ps_trancd
                            and     ps_trancd in (
                                                select  distinct(auth.tran_cd)
                                                from    tbl_auth_tran auth, tbl_person_auth pa
                                                where   auth.auth_cd = pa.auth_cd
                                                and     PA.CHANNEL_CD=ps_channelcd
                                                and     PA.PERSON_ID = to_number(ps_personid)
                            )
                            and ((ln_count3 >=1 and nt.news_id not in(263)) or not ln_count3 >=1) ----check Swift country 13-01-2022 Esen Omurchiev
        )
        --E-O-M ernestk cqdb00000824 return only menu's that the user have authority for
        UNION
        SELECT d.ELEMENT_ID, d.CHANNEL_CD, d.TRAN_CD, d.IMAGE_URL, d.LINK_URL, r.STATUS_CD, r.ELEMENT_LOCATION,
                d.LANG_CD, TO_CHAR(d.SUBJECT_TEXT), TO_CHAR(d.BODY_TEXT), '', c.ELEMENT_TYPE, r.SORT_ORDER, d.BOX_COLOR, d.BOX_ICON,''
        FROM TBL_CUSTOMIZE c, TBL_CUSTOMIZE_DESCRIPTION d, TBL_CUSTOMIZE_PERSON r
        WHERE d.ELEMENT_ID=r.ELEMENT_ID
        AND r.ELEMENT_ID=c.ELEMENT_ID
        AND d.LANG_CD = ps_langcd
        AND d.CHANNEL_CD = ps_channelcd
        AND d.TRAN_CD = ps_trancd
        AND c.STATUS_CD = 'sENAB'
        AND r.STATUS_CD = 'sENAB'
        AND r.PERSON_ID = TO_NUMBER(ps_personid)
        ORDER BY NEWS_LOCATION,SORT_ORDER;
END;
/******************************************************************************
   NAME       : FUNCTION  ChangeAlias
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Change Alias
******************************************************************************/
FUNCTION ChangeAlias(ps_channelcd   IN VARCHAR2,
                     pn_personid    IN VARCHAR2,
                     ps_newusername IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode VARCHAR2(3):='000';
   TransactionError    EXCEPTION;
   CURSOR cursor_alias IS
     SELECT *
     FROM TBL_IDENTIFICATION
     WHERE (UPPER(username)=UPPER(ps_newusername) OR UPPER(useralias)=UPPER(ps_newusername));

   row_alias   cursor_alias%ROWTYPE;

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM DUAL;

    OPEN cursor_alias;
    FETCH cursor_alias INTO row_alias;
        IF  cursor_alias%NOTFOUND THEN
            UPDATE TBL_IDENTIFICATION
            SET USERALIAS=ps_newusername
            WHERE PERSON_ID=TO_NUMBER(pn_personid);
        ELSE
            ls_returncode:='011';
            RAISE TransactionError;
        END IF;

    CLOSE cursor_alias;
--Pkg_Cint_Log.addcustomlog('test',ps_channelcd,pn_personid,ps_newusername);
    RETURN ls_returncode;

EXCEPTION
    WHEN TransactionError THEN
        RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  ChangePwdPin
   Created By : Muzaffar Khalyknazarov
   Date       : 07.12.07
   Purpose    : Change Pin and Password
******************************************************************************/
FUNCTION ChangePwdPin(ps_option    IN VARCHAR2,
                      ps_channelcd IN VARCHAR2,
                      pn_personid  IN VARCHAR2,
                      ps_oldcode   IN VARCHAR2,
                      ps_newcode   IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS


  CURSOR cursor_person IS
    SELECT *
    FROM TBL_IDENTIFICATION
    WHERE PERSON_ID=TO_NUMBER(pn_personid)
    AND  ps_oldcode=DECODE(ps_option,'PWD',PASSCODE,'PIN',PINCODE);

  row_person cursor_person%ROWTYPE;

  CURSOR cursor_passwd(p_newpasswd VARCHAR2) IS
    SELECT *
    FROM TBL_PWD_HISTORY
    WHERE PERSON_ID=TO_NUMBER(pn_personid)
    AND PASSTYPE=ps_option
    AND p_newpasswd IN (SELECT PASSWD
                        FROM( SELECT ROWNUM, a.DLM tarih,PASSWD
                              FROM TBL_PWD_HISTORY a
                              WHERE PERSON_ID=TO_NUMBER(pn_personid)
                              AND PASSTYPE=ps_option
                              ORDER BY dlm DESC)
                        WHERE ROWNUM < 4 -- son 3 ?ifreden biri olmamaly
                        );

  row_passwd cursor_passwd%ROWTYPE;


  ls_returncode VARCHAR2(3):='000';
  TransactionError    EXCEPTION;
   n BOOLEAN;
   m INTEGER;
   differ INTEGER;
   isdigit BOOLEAN;
   ischar  NUMBER ;
   ispunct BOOLEAN;
   digitarray VARCHAR2(20);
   punctarray VARCHAR2(25);
   chararray VARCHAR2(52);

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM DUAL;

    IF ps_option='PWD' THEN
        IF LENGTH(ps_newcode)<>32 THEN
            ls_returncode:='014';
            RAISE TransactionError;
        END IF;
    ELSIF  ps_option='PIN' THEN
       IF LENGTH(ps_newcode)<>32 THEN
        ls_returncode:='015';
        RAISE TransactionError;
        END IF;
    END IF;

  OPEN cursor_person;
  FETCH cursor_person INTO row_person;
    IF  cursor_person%NOTFOUND THEN
        IF ps_option='PWD' THEN
            ls_returncode:='002';
        ELSIF  ps_option='PIN' THEN
            ls_returncode:='003';
        END IF;

        RAISE TransactionError;

    END IF;

  CLOSE cursor_person;

  OPEN cursor_passwd(ps_newcode);
  FETCH cursor_passwd INTO row_passwd;
    IF  cursor_passwd%FOUND THEN
        IF ps_option='PWD' THEN
            ls_returncode:='012';
        ELSIF  ps_option='PIN' THEN
            ls_returncode:='013';
        END IF;

        RAISE TransactionError;

    END IF;

  CLOSE cursor_passwd;

  IF ps_option='PWD' THEN
    UPDATE TBL_IDENTIFICATION
    SET PASSCODE=ps_newcode, PWDFORCECHANGE='H',EXPIREDATE=SYSDATE+60
    WHERE PERSON_ID=TO_NUMBER(pn_personid);

  ELSIF  ps_option='PIN' THEN
    UPDATE TBL_IDENTIFICATION
    SET PINCODE=ps_newcode
    WHERE PERSON_ID=TO_NUMBER(pn_personid);

  END IF;

  INSERT INTO TBL_PWD_HISTORY
  (PERSON_ID, PASSWD, PASSTYPE)
  VALUES
  (pn_personid,ps_newcode,ps_option);

  RETURN ls_returncode;

EXCEPTION
  WHEN TransactionError THEN
    RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  SetTokenData
   Created By : Muzaffar Khalyknazarov
   Date       : 07.12.07
   Purpose    : Change Pin and Password
******************************************************************************/
FUNCTION SetTokenData(ps_DIGIPASS IN VARCHAR2,
                      ps_DIGIDATA IN VARCHAR2,
                      pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

    ls_digipass VARCHAR2(22);
    TransactionError EXCEPTION;
    ls_returncode   VARCHAR2(3):='000';
    ln_sessionid NUMBER;
    ln_personid NUMBER;
    ls_channelcd VARCHAR2(10);
    ls_sessionStatus VARCHAR2(10) := 'sACTIVE';

BEGIN

    SELECT DIGIPASS
    INTO ls_digipass
    FROM TBL_TOKEN
    WHERE INSTR(DIGIPASS,ps_DIGIPASS)>0;

    UPDATE TBL_TOKEN
    SET DP_DATA=ps_DIGIDATA
    WHERE RTRIM(DIGIPASS)=RTRIM(ls_digipass);

    OPEN pc_ref FOR
    SELECT ls_digipass FROM dual;

    RETURN ls_returncode;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ls_returncode:='112';--token no found
    RETURN ls_returncode;

 END;
/******************************************************************************
   NAME       : FUNCTION  SafeExit
   Created By : Muzaffar Khalyknazarov
   Date       : 11.12.07
   Purpose    : Safe Exit
******************************************************************************/
FUNCTION SafeExit(pn_sessionid IN NUMBER,
                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode      VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR SELECT '-' FROM DUAL;

    UPDATE TBL_SESSION
    SET STATUS_CD='sCLOSED'
    WHERE SESSION_ID=pn_sessionid;

    RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  CheckUserNameandPassword
   Created By : Muzaffar Khalyknazarov
   Date       : 12.12.07
   Purpose    : Check username and password
******************************************************************************/
FUNCTION CheckUserNameandPassword(ps_channelcd IN VARCHAR2,
                                  ps_username IN VARCHAR2,
                                  ps_password IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode   VARCHAR2(3):='000';
    ln_personid NUMBER := 0;
    ln_attemptcount NUMBER;
    ps_tokenid VARCHAR2(100);

    CURSOR cursor_identity IS
    SELECT * FROM TBL_IDENTIFICATION i
    WHERE i.USERNAME = ps_username
    AND i.CHANNEL_CD=ps_channelcd;

    row_identity cursor_identity%ROWTYPE;

    CURSOR cursor_alias IS
    SELECT * FROM TBL_IDENTIFICATION i
    WHERE i.USERALIAS = ps_username
    AND i.CHANNEL_CD=ps_channelcd;

    row_alias cursor_alias%ROWTYPE;

    CURSOR cursor_passcode(pn_personid NUMBER) IS
    SELECT * FROM TBL_IDENTIFICATION i
    WHERE i.PERSON_ID=pn_personid
    AND i.CHANNEL_CD=ps_channelcd
    AND i.STATUS_CD='sENAB'
    AND i.PASSCODE=ps_password;

    row_passcode cursor_passcode%ROWTYPE;

    CURSOR cursor_expire(pn_personid NUMBER) IS
    SELECT * FROM TBL_IDENTIFICATION i
    WHERE i.PERSON_ID=pn_personid
    AND i.EXPIREDATE>SYSDATE;

    TransactionError    EXCEPTION;
    ls_sessionStatus VARCHAR2(10) := 'sACTIVE';
    ls_personstatus VARCHAR2(20) := 'sENAB';
    ln_sessionid NUMBER;
    ls_ticketid   VARCHAR2(40):='';

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
     -- ?nce b?yle bir kullan?c? var m?

    OPEN cursor_identity;
    FETCH cursor_identity INTO row_identity;
        IF  cursor_identity%NOTFOUND THEN
            OPEN cursor_alias;
            FETCH cursor_alias INTO row_alias;
                IF  cursor_alias%NOTFOUND THEN
                    ls_returncode:='001';
                RAISE TransactionError;
                ELSE
                    ln_personid:=row_alias.PERSON_ID;
                    ln_attemptcount:=row_alias.ATTEMPT_COUNT;
                    ps_tokenid:=NVL(row_alias.TOKEN_ID,' ');
                    ls_personstatus:=row_alias.STATUS_CD;
                END IF;
            CLOSE cursor_alias;
        ELSE
            ln_personid:=row_identity.PERSON_ID;
            ln_attemptcount:=row_identity.ATTEMPT_COUNT;
            ps_tokenid:=NVL(row_identity.TOKEN_ID,' ');
            ls_personstatus:=row_identity.STATUS_CD;
        END IF;
  CLOSE cursor_identity;

  IF (ls_personstatus <> 'sENAB') THEN
    ls_returncode:='459';
  RAISE TransactionError;
  END IF;

     -- Lock the user if attem count exceed 3
  OPEN cursor_passcode(ln_personid);
  FETCH cursor_passcode INTO row_passcode;
    IF  cursor_passcode%NOTFOUND THEN
        ls_returncode:='002';
    IF ln_attemptcount+1>3 THEN
        UPDATE TBL_IDENTIFICATION i
        SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1,
            i.STATUS_CD='sLOCKED'
        WHERE i.PERSON_ID=ln_personid;
            ls_returncode:='008';
    ELSE
        UPDATE TBL_IDENTIFICATION i
        SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1
        WHERE i.PERSON_ID=ln_personid;
    END IF;
    RAISE TransactionError;
    END IF;
  CLOSE cursor_passcode;

  IF LENGTH(ps_tokenid) > 1 THEN
     ls_sessionStatus:='sTOKEN';
  END IF;

  --4) Create an Active Session
  ln_sessionid:=Pkg_Common.GetSequenceID('sqSESSIONID');

  --Close old sessions
  UPDATE TBL_SESSION
  SET status_cd='sCLOSED'
  WHERE person_id=ln_personid;

  --Create new session
  INSERT INTO TBL_SESSION
  (SESSION_ID, PERSON_ID, CHANNEL_CD, STATUS_CD)
  VALUES
  (ln_sessionid, ln_personid, ps_channelcd, ls_sessionStatus);

  --5) Get Ticket
   ls_ticketid:=Pkg_Common.GetTicketID;

  IF ls_ticketid IS NULL THEN
     ls_returncode:='004';
     RAISE TransactionError;
  ELSE
     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
     VALUES
     (ln_personid, ls_ticketid, 1, ln_sessionid);
  END IF;

  OPEN pc_ref FOR
  SELECT ln_sessionid,ln_personid,ps_tokenid,ls_ticketid FROM dual;

  RETURN ls_returncode;
 EXCEPTION
        WHEN TransactionError THEN
   RETURN ls_returncode;
  WHEN OTHERS THEN
  ls_returncode:='999';
  RETURN ls_returncode;
 END;
/******************************************************************************
   NAME       : FUNCTION  CheckUserPinCode
   Created By : Muzaffar Khalyknazarov
   Date       : 12.12.07
   Purpose    : Check pin code
******************************************************************************/
FUNCTION CheckUserPinCode(ps_channelcd IN VARCHAR2,
                          ps_pincode   IN VARCHAR2,
                          ps_sessionid IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS

    ls_returncode   VARCHAR2(3):='000';
    ln_personid NUMBER := 0;
    ls_ticketid   VARCHAR2(40):='';

    CURSOR cursor_pincode(pn_personid NUMBER) IS
    SELECT * FROM TBL_IDENTIFICATION i
    WHERE i.PERSON_ID=pn_personid
    AND i.CHANNEL_CD=ps_channelcd
    AND i.STATUS_CD='sENAB'
    AND i.PINCODE=ps_pincode;

    row_pincode cursor_pincode%ROWTYPE;

    CURSOR cursor_expire(pn_personid NUMBER) IS
    SELECT * FROM TBL_IDENTIFICATION i
    WHERE i.PERSON_ID=pn_personid
    AND i.EXPIREDATE>SYSDATE;

    row_expire cursor_expire%ROWTYPE;

    ln_attemptcount NUMBER:=0;
    ps_pwdforcechange VARCHAR2(100);
    TransactionError    EXCEPTION;

BEGIN

   OPEN pc_ref FOR SELECT '-' FROM dual;

   SELECT s.PERSON_ID
   INTO ln_personid
   FROM TBL_SESSION s
   WHERE s.SESSION_ID=TO_NUMBER(ps_sessionid);

   SELECT i.ATTEMPT_COUNT,i.PWDFORCECHANGE
   INTO ln_attemptcount,ps_pwdforcechange
   FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=ln_personid;


   OPEN cursor_pincode(ln_personid);
   FETCH cursor_pincode INTO row_pincode;
    IF  cursor_pincode%NOTFOUND THEN
        ls_returncode:='003';
        IF ln_attemptcount+1>3 THEN
            UPDATE TBL_IDENTIFICATION i
            SET i.attempt_count=i.attempt_count+1,
                i.STATUS_CD='sLOCKED'
            WHERE i.PERSON_ID=ln_personid;
                ls_returncode:='008';
        ELSE
            UPDATE TBL_IDENTIFICATION i
            SET i.attempt_count=i.attempt_count+1
            WHERE i.PERSON_ID=ln_personid;
        END IF;

    RAISE TransactionError;
    END IF;
  CLOSE cursor_pincode;

  --4) Authentication OK Clear Attemp Count
  UPDATE TBL_IDENTIFICATION i
  SET i.attempt_count=0
  WHERE i.PERSON_ID=ln_personid
  AND i.CHANNEL_CD=ps_channelcd;

  --5) Get Ticket
   ls_ticketid:=Pkg_Common.GetTicketID;

  IF ls_ticketid IS NULL THEN
     ls_returncode:='004';
     RAISE TransactionError;
  ELSE
     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
     VALUES
     (ln_personid, ls_ticketid, 2, ps_sessionid); -- ilk ekranda zaten bir ticket ?retmi?tim bu iki oldu..
  END IF;

 --6) Expire Check
  OPEN cursor_expire(ln_personid);
  FETCH cursor_expire INTO row_expire;
    IF  cursor_expire%NOTFOUND THEN
        ps_pwdforcechange:='E';
    END IF;
  CLOSE cursor_expire;

  OPEN pc_ref FOR
  SELECT ps_sessionid,ls_ticketid,ln_personid,ps_pwdforcechange,ln_attemptcount FROM dual;

  RETURN ls_returncode;

EXCEPTION
  WHEN TransactionError THEN
    RETURN ls_returncode;

  WHEN OTHERS THEN
   LOG_AT('CheckPinCode','999 line ', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ls_returncode:='999';
  RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------------------------
FUNCTION GetParentMenuID(ps_trancd VARCHAR2,ps_channelcd VARCHAR2) RETURN VARCHAR2 IS
    ls_parentcd VARCHAR2(10);
BEGIN
    SELECT c.PARENT_CD
    INTO ls_parentcd
    FROM TBL_MENU c
    WHERE  c.TRAN_CD=ps_trancd
    AND c.CHANNEL_CD=ps_channelcd ;

    RETURN ls_parentcd;
END;
/******************************************************************************
   NAME          : FUNCTION  CheckUser
   Created By    : Muzaffar Khalyknazarov
   Date          : 24.12.07
   Purpose       : Check User
******************************************************************************/
FUNCTION CheckUser( ps_channelcd IN VARCHAR2,
                    ps_username IN VARCHAR2,
                    ps_passcode IN VARCHAR2,
                    ps_pincode IN VARCHAR2,
                    pn_ClientIP IN VARCHAR2,
                    pn_sessionid OUT NUMBER,
                    ps_ticketid OUT VARCHAR2,
                    pn_personid OUT NUMBER,
                    ps_pwdforcechange OUT VARCHAR2,
                    ps_tokenid OUT VARCHAR2) RETURN VARCHAR2 IS

    CURSOR cursor_identity IS
        SELECT * FROM TBL_IDENTIFICATION i
        WHERE i.USERNAME = ps_username
        AND i.CHANNEL_CD=ps_channelcd;

    CURSOR cursor_alias IS
        SELECT * FROM TBL_IDENTIFICATION i
        WHERE i.USERALIAS = ps_username
        AND i.CHANNEL_CD=ps_channelcd;

    CURSOR cursor_passcode(pn_personid NUMBER) IS
        SELECT * FROM TBL_IDENTIFICATION i
        WHERE i.PERSON_ID=pn_personid
        AND i.CHANNEL_CD=ps_channelcd
        AND i.STATUS_CD='sENAB'
        AND i.PASSCODE=ps_passcode;

    CURSOR cursor_pincode(pn_personid NUMBER) IS
        SELECT * FROM TBL_IDENTIFICATION i
        WHERE i.PERSON_ID=pn_personid
        AND i.CHANNEL_CD=ps_channelcd
        AND i.STATUS_CD='sENAB'
        AND i.PINCODE=ps_pincode;

    CURSOR cursor_expire(pn_personid NUMBER) IS
        SELECT * FROM TBL_IDENTIFICATION i
        WHERE i.PERSON_ID=pn_personid
        AND i.EXPIREDATE>SYSDATE;

    CURSOR cursor_security(pn_personid NUMBER) IS
        SELECT * FROM TBL_IBSECURITY i
        WHERE i.PERSON_ID=pn_personid;

    row_identity cursor_identity%ROWTYPE;
    row_alias cursor_alias%ROWTYPE;
    row_passcode cursor_passcode%ROWTYPE;
    row_pincode cursor_pincode%ROWTYPE;
    row_expire cursor_expire%ROWTYPE;
    row_security cursor_security%ROWTYPE;
    ls_statement VARCHAR2(2000);
    ls_returncode VARCHAR2(3):='000';
    ln_attemptcount NUMBER:=0;
    ln_sessionid  NUMBER:=0;
    ls_ticketid   VARCHAR2(40):='';
    ln_personid   NUMBER:=0;
    ls_pwdforcechange   VARCHAR2(1):='';
    TransactionError    EXCEPTION;
    TokenPresent EXCEPTION;
    ls_sessionStatus VARCHAR2(10) := 'sACTIVE';
    ls_personstatus VARCHAR2(20) := 'sENAB';
    ls_systime VARCHAR2(5):=TO_CHAR(SYSDATE,'HH24:MI');
    ls_sysday VARCHAR2(1):=TO_CHAR(SYSDATE,'D');

    ls_pwd_type VARCHAR2(15 CHAR) :='PWD_PIN';
    ln_count NUMBER;
BEGIN
        --0)Initialize outputs
        pn_sessionid:=0;
        ps_ticketid:=' ';
        pn_personid:=0;
        ps_pwdforcechange:=' ';
        ps_tokenid:=' ';

    --1) Check for username,status,expiredate
    OPEN cursor_identity;
    FETCH cursor_identity INTO row_identity;
    IF  cursor_identity%NOTFOUND THEN
        OPEN cursor_alias;
        FETCH cursor_alias INTO row_alias;
        IF  cursor_alias%NOTFOUND THEN
            ls_returncode:='001';
            RAISE TransactionError;
        ELSE
            ln_personid:=row_alias.PERSON_ID;
            ls_pwdforcechange:=row_alias.PWDFORCECHANGE;
            ln_attemptcount:=row_alias.ATTEMPT_COUNT;
            pn_personid:=ln_personid;
            ps_pwdforcechange:=ls_pwdforcechange;
            ps_tokenid:=NVL(row_alias.TOKEN_ID,' ');
            ls_personstatus:=row_alias.STATUS_CD;
        END IF;
        CLOSE cursor_alias;
    ELSE
        ln_personid:=row_identity.PERSON_ID;
        ls_pwdforcechange:=row_identity.PWDFORCECHANGE;
        ln_attemptcount:=row_identity.ATTEMPT_COUNT;
        pn_personid:=ln_personid;
        ps_pwdforcechange:=ls_pwdforcechange;
        ps_tokenid:=NVL(row_identity.TOKEN_ID,' ');
        ls_personstatus:=row_identity.STATUS_CD;
    END IF;
    CLOSE cursor_identity;

    -- account disable olmu? ise kullan?c?y? uyarmak laz?m..
    --
    IF (ls_personstatus <> 'sENAB') THEN
        ls_returncode:='459';
        RAISE TransactionError;
    END IF;


    --2) Check for passcode
    -- Lock the user if attem count exceed 3
    OPEN cursor_passcode(ln_personid);
    FETCH cursor_passcode INTO row_passcode;
    IF  cursor_passcode%NOTFOUND THEN
        ls_returncode:='002';
        IF ln_attemptcount+1>3 THEN
            UPDATE TBL_IDENTIFICATION i
            SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1,
            i.STATUS_CD='sLOCKED'
            WHERE i.PERSON_ID=ln_personid;

            ls_returncode:='008';
        ELSE
            UPDATE TBL_IDENTIFICATION i
            SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1
            WHERE i.PERSON_ID=ln_personid;
        END IF;
        RAISE TransactionError;
    END IF;
    CLOSE cursor_passcode;

    SELECT count(1) into ln_count
    FROM TBL_IDENTIFICATION
    WHERE CHANNEL_CD=ps_channelcd
    AND (USERNAME = ps_username or USERALIAS = ps_username)
    AND STATUS_CD='sENAB'
    AND PASSCODE=ps_passcode;

    IF (ln_count>0) THEN
        SELECT PWD_TYPE into ls_pwd_type
        FROM TBL_IDENTIFICATION
        WHERE CHANNEL_CD=ps_channelcd
        AND (USERNAME = ps_username or USERALIAS = ps_username)
        AND STATUS_CD='sENAB'
        AND PASSCODE=ps_passcode
        AND ROWNUM=1;
    END IF;

    --3) Check for pincode
    -- Lock the user if attem count exceed 3
    OPEN cursor_pincode(ln_personid);
    FETCH cursor_pincode INTO row_pincode;
    IF  cursor_pincode%NOTFOUND THEN
        ls_returncode:='003';
        IF ln_attemptcount+1>3 THEN
            UPDATE TBL_IDENTIFICATION i
            SET i.attempt_count=i.attempt_count+1,
            i.STATUS_CD='sLOCKED'
            WHERE i.PERSON_ID=ln_personid;

            ls_returncode:='008';
        ELSE
            UPDATE TBL_IDENTIFICATION i
            SET i.attempt_count=i.attempt_count+1
            WHERE i.PERSON_ID=ln_personid;
        END IF;
        RAISE TransactionError;
    END IF;
    CLOSE cursor_pincode;

    IF (ls_pwd_type = 'PWD_SMS') THEN
        ls_sessionStatus := 'sDISAB';
    END IF;

    --4) Authentication OK Clear Attemp Count
    UPDATE TBL_IDENTIFICATION i
    SET i.attempt_count=0
    WHERE i.PERSON_ID=ln_personid
    AND i.CHANNEL_CD=ps_channelcd;

    IF LENGTH(ps_tokenid) > 1 THEN
        ls_sessionStatus:='sTOKEN';
    END IF;

    --4) Create an Active Session
    ln_sessionid:=Pkg_Common.GetSequenceID('sqSESSIONID');

    --Close old sessions
    UPDATE TBL_SESSION
    SET status_cd='sCLOSED'
    WHERE person_id=ln_personid;

    --Create new session
    INSERT INTO TBL_SESSION
    (SESSION_ID, PERSON_ID, CHANNEL_CD, STATUS_CD)
    VALUES
    (ln_sessionid, ln_personid, ps_channelcd, ls_sessionStatus);

    pn_sessionid:=ln_sessionid;

    --5) Get Ticket
    ls_ticketid:=Pkg_Common.GetTicketID;

    IF ls_ticketid IS NULL THEN
        ls_returncode:='004';
        RAISE TransactionError;
    ELSE
        INSERT INTO TBL_TICKET_HISTORY
        (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
        VALUES
        (ln_personid, ls_ticketid, 1, ln_sessionid);
    END IF;

    ps_ticketid:=ls_ticketid;

    --6) Expire Check
    OPEN cursor_expire(ln_personid);
    FETCH cursor_expire INTO row_passcode;
    IF  cursor_expire%NOTFOUND THEN
        ps_pwdforcechange:='E';
    END IF;
    CLOSE cursor_expire;


    --7) Security Check
    OPEN cursor_security(ln_personid);
    FETCH cursor_security INTO row_security;
    IF  cursor_security%FOUND THEN
        IF row_security.IP_STATUS='E' THEN
            ls_returncode:=pkg_cint_main.IpCheck(pn_ClientIP,row_security.IP_1_1,row_security.IP_1_2,row_security.IP_2_1,row_security.IP_2_2);
            IF ls_returncode<>'000' THEN
                RAISE TransactionError;
            END IF;
        END IF;

        IF row_security.TIME_STATUS='E' THEN
            ls_returncode:=pkg_cint_main.TimeCheck(row_security.START_TIME,row_security.END_TIME);
            IF ls_returncode<>'000' THEN
                RAISE TransactionError;
            END IF;
        END IF;

        IF (ls_sysday='1' and row_security.MONDAY='E') or (ls_sysday='2' and row_security.TUESDAY='E') or (ls_sysday='3' and row_security.WEDNESDAY='E') or (ls_sysday='4' and row_security.THURSDAY='E') or (ls_sysday='5' and row_security.FRIDAY='E') or (ls_sysday='6' and row_security.SATURDAY='E') or (ls_sysday='7' and row_security.SUNDAY='E') then
            ls_returncode:='000';
        ELSE
            ls_returncode:='102';
            RAISE TransactionError;
        END IF;
    END IF;
    CLOSE cursor_security;

  RETURN ls_returncode;
EXCEPTION
    WHEN TokenPresent THEN
        RETURN ls_returncode;
    WHEN TransactionError THEN
        RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  CheckAvailableEtoken
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Check Available Etoken & Password Type
******************************************************************************/
FUNCTION CheckAvailableEtoken(ps_channelcd IN VARCHAR2,
                              ps_username IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_returncode VARCHAR2(3):='000';
     ln_count      NUMBER;
     ls_etoken       VARCHAR2(1):='N';
     pwd_type VARCHAR2(15 CHAR) := 'PWD_PIN';

BEGIN
    SELECT  COUNT(TOKEN_ID)
    INTO ln_count
    FROM TBL_IDENTIFICATION
    WHERE CHANNEL_CD=ps_channelcd
    AND (USERNAME = ps_username or USERALIAS = ps_username);

    IF ln_count>0 THEN
        ls_etoken:='Y';
    ELSE
        ls_etoken:='N';
    END IF;

    SELECT count(1) into ln_count
    FROM TBL_IDENTIFICATION
    WHERE CHANNEL_CD=ps_channelcd
    AND (USERNAME = ps_username or USERALIAS = ps_username);

    IF (ln_count>0) THEN
        SELECT PWD_TYPE into pwd_type
        FROM TBL_IDENTIFICATION
        WHERE CHANNEL_CD=ps_channelcd
        AND (USERNAME = ps_username or USERALIAS = ps_username)
        AND ROWNUM=1;
    END IF;

    OPEN pc_ref FOR SELECT ls_etoken, pwd_type FROM dual;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        OPEN pc_ref FOR SELECT ls_etoken, pwd_type FROM dual;

    RETURN ls_etoken;
END;
-------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  GetCustomerTokenData
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Get Customer Token Data
******************************************************************************/
FUNCTION GetCustomerTokenData(ps_username IN VARCHAR2,
                              pc_ref OUT CursorReferenceType
                              )RETURN VARCHAR2 IS

      ls_digidata VARCHAR2(255);
      ls_digipass VARCHAR2(22);
      otp_validity_period NUMBER;
      ls_returncode   VARCHAR2(3):='000';
      ls_tokenid VARCHAR2(22);
      TransactionError EXCEPTION;
      ln_personid   NUMBER;
      ls_dptype VARCHAR2(5);
BEGIN

  SELECT TOKEN_ID, PERSON_ID
  INTO ls_tokenid, ln_personid
  FROM TBL_IDENTIFICATION
  WHERE USERNAME = ps_username or useralias = ps_username;

  SELECT DP_DATA,DIGIPASS,OTP_VALIDITY_PERIOD, DP_TYPE
  INTO ls_digidata,ls_digipass,otp_validity_period, ls_dptype
  FROM TBL_TOKEN
  WHERE RTRIM(DIGIPASS)=RTRIM(ls_tokenid);

  OPEN pc_ref FOR
  SELECT ls_digidata,ls_digipass,otp_validity_period,ln_personid, ls_dptype FROM dual;

  RETURN ls_returncode;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  ls_returncode:='112';--token no found

  OPEN pc_ref FOR
  SELECT ls_digidata,ls_digipass FROM dual;

  RETURN ls_returncode;
END;

-------------------------------------------------------------------------------

/******************************************************************************
   NAME       : FUNCTION  SetWrongTokenAttemp
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Set Wrong Token Attemp
******************************************************************************/
FUNCTION SetWrongTokenAttemp(ps_channelcd IN VARCHAR2,
                             ps_username IN VARCHAR2,
                             pc_ref OUT CursorReferenceType
                             )RETURN VARCHAR2 IS

       ls_returncode      VARCHAR2(3):='000';
       ps_personID NUMBER;
       ln_attemptcount NUMBER;
BEGIN

 OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

 SELECT t.ATTEMPT_COUNT
 INTO ln_attemptcount
 FROM TBL_IDENTIFICATION t
 WHERE (t.USERNAME =ps_username or t.USERALIAS =ps_username)
 AND t.CHANNEL_CD=ps_channelcd;

 IF ln_attemptcount+1>3 THEN
 UPDATE TBL_IDENTIFICATION i
 SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1,
 i.STATUS_CD='sLOCKED'
  WHERE (i.USERNAME =ps_username or i.USERALIAS =ps_username);
 ls_returncode:='008';

 ELSE

 UPDATE TBL_IDENTIFICATION i
 SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1
 WHERE (i.USERNAME =ps_username or i.USERALIAS =ps_username);
 END IF;

 RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
     RETURN '111';
END;

-------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  SetSessionStatus
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Set Session Status
******************************************************************************/
FUNCTION SetSessionStatus(ps_DIGIPASS IN VARCHAR2,
                             pc_ref OUT CursorReferenceType
                          )RETURN VARCHAR2 IS
    TransactionError EXCEPTION;
    ls_returncode   VARCHAR2(3):='000';
    ln_personid NUMBER;
    ls_channelcd VARCHAR2(10);
    ls_sessionStatus VARCHAR2(10) := 'sACTIVE';
    ln_sessionid NUMBER;
    ls_ticketid VARCHAR2(50);

 BEGIN

    SELECT PERSON_ID, CHANNEL_CD
    INTO ln_personid, ls_channelcd
    FROM TBL_IDENTIFICATION
    WHERE trim(TOKEN_ID)=trim(ps_DIGIPASS);

     -- Create an Active Session
     ln_sessionid:=Pkg_Common.GetSequenceID('sqSESSIONID');

    INSERT INTO TBL_SESSION
    (SESSION_ID, PERSON_ID, CHANNEL_CD, STATUS_CD)
    VALUES
    (ln_sessionid, ln_personid, ls_channelcd, ls_sessionStatus);

    --Get Ticket
    ls_ticketid:=Pkg_Common.GetTicketID;

     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
     VALUES
     (ln_personid, ls_ticketid, 1, ln_sessionid);

   OPEN pc_ref FOR
   SELECT ln_sessionid, ln_personid, ls_channelcd, ls_ticketid FROM dual;

   RETURN ls_returncode;
 EXCEPTION
  WHEN OTHERS THEN
  ls_returncode:='126';--update edilemedi
  RETURN ls_returncode;

 END;

/******************************************************************************
   NAME       : FUNCTION  AssignCustomerAccounts
   Created By : Muzaffar Khalyknazarov
   Date       : 22.04.08
   Purpose    : Assign Customer Accounts
******************************************************************************/
FUNCTION AssignCustomerAccounts(ps_CustomerNo IN VARCHAR2,
                                 ps_PersonID      IN VARCHAR2,
                                ps_Params      IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  ls_counter NUMBER := 0;
  ls_hesap_no VARCHAR2(10);
  ns_hesap_no NUMBER;

BEGIN
     DELETE FROM  TBL_ACCOUNT_ASSIGN
         WHERE PERSON_ID = ps_PersonID;

     INSERT INTO TBL_ACCOUNT_ASSIGN (PERSON_ID,HESAP_NO,CUSTOMER_NO)
     (SELECT TO_NUMBER(ps_PersonID), HESAP_NO, TO_NUMBER(ps_CustomerNo)
     FROM CBS.CBS_vw_hesap_izleme
     WHERE MUSTERI_NO=TO_NUMBER(ps_CustomerNo)
     AND HESAP_NO NOT IN (SELECT HESAP_NO
            FROM CBS.CBS_vw_hesap_izleme
            WHERE (ps_Params='ALL' OR  HESAP_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_Params, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_Params, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) ) ));

			--INSTR(DECODE(ps_Params,'ALL',',' || TO_CHAR(HESAP_NO) || ',',ps_Params), ',' || TO_CHAR(HESAP_NO) || ',')>0));

     OPEN PC_REF FOR SELECT '-' FROM DUAL;
      RETURN ls_returncode;

 EXCEPTION WHEN OTHERS THEN
    OPEN PC_REF FOR SELECT '-' FROM DUAL;
    RETURN '000';
END;
--******************************************************************************/
FUNCTION CheckUserForPartner( ps_channelcd IN VARCHAR2,
                    ps_username IN VARCHAR2,
                    ps_passcode IN VARCHAR2,
                    ps_pincode IN VARCHAR2,
                    pn_sessionid OUT NUMBER,
                    ps_ticketid OUT VARCHAR2,
                    pn_personid OUT NUMBER,
                    ps_pwdforcechange OUT VARCHAR2,
                    ps_tokenid OUT VARCHAR2) RETURN VARCHAR2 IS

   CURSOR cursor_identity IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.USERNAME = ps_username
   AND i.CHANNEL_CD=ps_channelcd;
   --and i.EXPIREDATE>sysdate;

  CURSOR cursor_alias IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.USERALIAS = ps_username
   AND i.CHANNEL_CD=ps_channelcd;
   --and i.EXPIREDATE>sysdate;

   CURSOR cursor_passcode(pn_personid NUMBER) IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=pn_personid
   AND i.CHANNEL_CD=ps_channelcd
   AND i.STATUS_CD='sENAB'
   AND i.PASSCODE=ps_passcode;

   CURSOR cursor_pincode(pn_personid NUMBER) IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=pn_personid
   AND i.CHANNEL_CD=ps_channelcd
   AND i.STATUS_CD='sENAB'
   AND i.PINCODE=ps_pincode;

    CURSOR cursor_expire(pn_personid NUMBER) IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=pn_personid
   AND i.EXPIREDATE>SYSDATE;

   CURSOR cursor_security(pn_personid NUMBER) IS
      SELECT * FROM TBL_IBSECURITY i
   WHERE i.PERSON_ID=pn_personid;

   row_identity cursor_identity%ROWTYPE;
   row_alias cursor_alias%ROWTYPE;
   row_passcode cursor_passcode%ROWTYPE;
   row_pincode cursor_pincode%ROWTYPE;
   row_expire cursor_expire%ROWTYPE;
   row_security cursor_security%ROWTYPE;
   ls_statement VARCHAR2(2000);
   ls_returncode VARCHAR2(3):='000';
   ln_attemptcount NUMBER:=0;
   ln_sessionid  NUMBER:=0;
   ls_ticketid   VARCHAR2(40):='';
   ln_personid   NUMBER:=0;
   ls_pwdforcechange   VARCHAR2(1):='';
   TransactionError    EXCEPTION;
   TokenPresent EXCEPTION;
   ls_sessionStatus VARCHAR2(10) := 'sACTIVE';
   ls_personstatus VARCHAR2(20) := 'sENAB';
   ls_systime VARCHAR2(5):=TO_CHAR(SYSDATE,'HH24:MI');
   ls_sysday VARCHAR2(1):=TO_CHAR(SYSDATE,'D');

 BEGIN
 --0)Initialize outputs
  pn_sessionid:=0;
  ps_ticketid:=' ';
  pn_personid:=0;
  ps_pwdforcechange:=' ';
  ps_tokenid:=' ';

  --1) Check for username,status,expiredate
  -- EXPIREDATE>sysdate and STATUS='sENAB'
  OPEN cursor_identity;
  FETCH cursor_identity INTO row_identity;
  IF  cursor_identity%NOTFOUND THEN
   OPEN cursor_alias;
   FETCH cursor_alias INTO row_alias;
   IF  cursor_alias%NOTFOUND THEN
    ls_returncode:='001';
    RAISE TransactionError;
   ELSE
    ln_personid:=row_alias.PERSON_ID;
    ls_pwdforcechange:=row_alias.PWDFORCECHANGE;
    ln_attemptcount:=row_alias.ATTEMPT_COUNT;
    pn_personid:=ln_personid;
    ps_pwdforcechange:=ls_pwdforcechange;
    ps_tokenid:=NVL(row_alias.TOKEN_ID,' ');
    ls_personstatus:=row_alias.STATUS_CD;
   END IF;
   CLOSE cursor_alias;
  ELSE
   ln_personid:=row_identity.PERSON_ID;
   ls_pwdforcechange:=row_identity.PWDFORCECHANGE;
   ln_attemptcount:=row_identity.ATTEMPT_COUNT;
   pn_personid:=ln_personid;
   ps_pwdforcechange:=ls_pwdforcechange;
   ps_tokenid:=NVL(row_identity.TOKEN_ID,' ');
   ls_personstatus:=row_identity.STATUS_CD;
  END IF;
  CLOSE cursor_identity;

  -- account disable olmu? ise kullan?c?y? uyarmak laz?m..
  --
  IF (ls_personstatus <> 'sENAB') THEN
  ls_returncode:='459';
  RAISE TransactionError;
  END IF;


  --2) Check for passcode
  -- Lock the user if attem count exceed 3
   OPEN cursor_passcode(ln_personid);
  FETCH cursor_passcode INTO row_passcode;
  IF  cursor_passcode%NOTFOUND THEN
   ls_returncode:='002';
   IF ln_attemptcount+1>3 THEN
    UPDATE TBL_IDENTIFICATION i
    SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1,
     i.STATUS_CD='sLOCKED'
    WHERE i.PERSON_ID=ln_personid;
    ls_returncode:='008';
   ELSE
    UPDATE TBL_IDENTIFICATION i
    SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1
    WHERE i.PERSON_ID=ln_personid;
   END IF;
   RAISE TransactionError;
  END IF;
  CLOSE cursor_passcode;

  --3) Check for pincode
  -- Lock the user if attem count exceed 3
   OPEN cursor_pincode(ln_personid);
  FETCH cursor_pincode INTO row_pincode;
  IF  cursor_pincode%NOTFOUND THEN
   ls_returncode:='003';
   IF ln_attemptcount+1>3 THEN
    UPDATE TBL_IDENTIFICATION i
    SET i.attempt_count=i.attempt_count+1,
     i.STATUS_CD='sLOCKED'
    --where i.USERNAME = ps_username
    --and i.CHANNEL_CD=ps_channelcd;
    WHERE i.PERSON_ID=ln_personid;
    ls_returncode:='008';
   ELSE
    UPDATE TBL_IDENTIFICATION i
    SET i.attempt_count=i.attempt_count+1
    --where i.USERNAME = ps_username
    --and i.CHANNEL_CD=ps_channelcd;
    WHERE i.PERSON_ID=ln_personid;
   END IF;
   RAISE TransactionError;
  END IF;
  CLOSE cursor_pincode;

  --4) Authentication OK Clear Attemp Count
  UPDATE TBL_IDENTIFICATION i
  SET i.attempt_count=0
  WHERE i.PERSON_ID=ln_personid
  AND i.CHANNEL_CD=ps_channelcd;


     IF LENGTH(ps_tokenid) > 1 THEN
     ls_sessionStatus:='sTOKEN';
  END IF;

  --4) Create an Active Session
   ln_sessionid:=Pkg_Common.GetSequenceID('sqSESSIONID');

  --Close old sessions
  UPDATE TBL_SESSION
  SET status_cd='sCLOSED'
  WHERE person_id=ln_personid;

  --Create new session
  INSERT INTO TBL_SESSION
  (SESSION_ID, PERSON_ID, CHANNEL_CD, STATUS_CD)
  VALUES
  (ln_sessionid, ln_personid, ps_channelcd, ls_sessionStatus);

   pn_sessionid:=ln_sessionid;

  --5) Get Ticket
   ls_ticketid:=Pkg_Common.GetTicketID;

  IF ls_ticketid IS NULL THEN
     ls_returncode:='004';
     RAISE TransactionError;
  ELSE
     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
     VALUES
     (ln_personid, ls_ticketid, 1, ln_sessionid);
  END IF;

  ps_ticketid:=ls_ticketid;

 --6) Expire Check
  OPEN cursor_expire(ln_personid);
  FETCH cursor_expire INTO row_passcode;
  IF  cursor_expire%NOTFOUND THEN
   ps_pwdforcechange:='E';
  END IF;
  CLOSE cursor_expire;


  --7) Security Check
   OPEN cursor_security(ln_personid);
   FETCH cursor_security INTO row_security;
   IF  cursor_security%FOUND THEN
       IF row_security.IP_STATUS='E' THEN
             ls_returncode:=pkg_cint_main.IpCheck('',row_security.IP_1_1,row_security.IP_1_2,row_security.IP_2_1,row_security.IP_2_2);
       END IF;
       IF row_security.TIME_STATUS='E' THEN
             ls_returncode:=pkg_cint_main.TimeCheck(row_security.START_TIME,row_security.END_TIME);
       END IF;
       --pkg_log.AddCustomLog('test_111',ls_sysday,row_security.TUESDAY);
       IF (ls_sysday='1' and row_security.MONDAY='E') or (ls_sysday='2' and row_security.TUESDAY='E') or (ls_sysday='3' and row_security.WEDNESDAY='E') or (ls_sysday='4' and row_security.THURSDAY='E') or (ls_sysday='5' and row_security.FRIDAY='E') or (ls_sysday='6' and row_security.SATURDAY='E') or (ls_sysday='7' and row_security.SUNDAY='E') then
             pkg_log.AddCustomLog('control');
          ls_returncode:='000';
       ELSE
             ls_returncode:='102';
       END IF;
         --pkg_log.AddCustomLog('test-end',ls_returncode);
       IF ls_returncode<>'000' THEN
             RAISE TransactionError;
       END IF;
   END IF;
   CLOSE cursor_security;
  --tbl_ibsecurity

  RETURN ls_returncode;

EXCEPTION
 WHEN TokenPresent THEN
   RETURN ls_returncode;
 WHEN TransactionError THEN
   RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  IBCheckTicket
   Created By : Muzaffar Khalyknazarov
   Date       : 03.05.08
   Purpose   : Check Ticket
******************************************************************************/

FUNCTION IBCheckTicket(pn_sessionid   IN NUMBER,
                       ps_ticketid    IN VARCHAR2,
                         ps_channelcd   IN VARCHAR2,
                          ps_trancd      IN VARCHAR2,
                       ps_pageid      IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    CURSOR cursor_session IS
        SELECT * FROM TBL_SESSION s
        WHERE s.CHANNEL_CD=ps_channelcd
        AND s.SESSION_ID=pn_sessionid
        AND s.STATUS_CD='sACTIVE';

    CURSOR cursor_ticket(pn_personid NUMBER) IS
        SELECT * FROM TBL_TICKET_HISTORY t
        WHERE t.SESSION_ID=pn_sessionid
        AND t.TICKET_ID=ps_ticketid
        AND t.PERSON_ID=pn_personid
        AND DECODE(ps_channelcd,'cPARTNER',(t.DLM+(60/(24*60))),(t.DLM+(8/(24*60)))) > SYSDATE;

    CURSOR cursor_authtran(pn_personid NUMBER) IS
        SELECT TRAN_CD,TRAN_AUTH FROM TBL_PERSON_AUTHORITY a
        WHERE  a.TRAN_CD=ps_trancd
        AND a.PERSON_ID=pn_personid;

    CURSOR cursor_person(pn_personid NUMBER) IS
        SELECT * FROM TBL_PERSON p
        WHERE p.PERSON_ID=pn_personid;


        row_session cursor_session%ROWTYPE;
        row_ticket cursor_ticket%ROWTYPE;
        row_authtran cursor_authtran%ROWTYPE;
        row_person cursor_person%ROWTYPE;

        TransactionError EXCEPTION;
        ls_statement     VARCHAR2(2000);
        ls_returncode    VARCHAR2(3):='000';
        ln_ticketindx    NUMBER:=0;
        ln_personid      NUMBER:=0;
        ls_ticketid      VARCHAR2(40):=' ';
        ln_customerid    VARCHAR2(13):='0';
        ls_cusmomername  VARCHAR2(200):=' ';
        ps_newticketid   VARCHAR2(50);
        pn_personid      VARCHAR2(50);
        pn_customerid    VARCHAR2(50);
        ls_forcechange   VARCHAR2(1):='H';
BEGIN
    IF TO_NUMBER(ps_pageid)<>0 THEN

        UPDATE TBL_SESSION
        SET DOUBLE_CLICK=0
        WHERE CHANNEL_CD=ps_channelcd
        AND SESSION_ID=TO_NUMBER(pn_sessionid)
        AND STATUS_CD='sACTIVE';
    END IF;

    --0)Initialize the outparams
    ps_newticketid:=ls_ticketid;
    pn_personid:=ln_personid;
    pn_customerid:=ln_customerid;

    --1)Person has valid session
    OPEN cursor_session;
    FETCH cursor_session INTO row_session;

        IF  cursor_session%NOTFOUND THEN
            ls_returncode:='005';
            RAISE TransactionError;
        ELSE
            ln_personid:=row_session.PERSON_ID;
            pn_personid:=ln_personid;
        END IF;

        IF row_session.double_click=1 THEN
            ls_returncode:='030';
            RAISE TransactionError;
        END IF;

    CLOSE cursor_session;

    --2)Person has valid ticket TicketDate+7min>sysdate
    OPEN cursor_ticket(ln_personid);
    FETCH cursor_ticket INTO row_ticket;

        IF  cursor_ticket%NOTFOUND THEN
            ls_returncode:='006';
            RAISE TransactionError;
        ELSE
            ln_ticketindx:=row_ticket.TICKET_INDX;
        END IF;

    CLOSE cursor_ticket;


    --4)Get New Ticket
    ls_ticketid:=Pkg_Common.GetTicketID;

    IF ls_ticketid IS NULL THEN
        ls_returncode:='004';
        RAISE TransactionError;
    ELSE
        INSERT INTO TBL_TICKET_HISTORY
        (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID,DLM)
        VALUES
        (ln_personid, ls_ticketid, ln_ticketindx+1, pn_sessionid,SYSDATE);
    END IF;

        ps_newticketid:=ls_ticketid;

    --5)Get Customer Info
    OPEN cursor_person(ln_personid);
    FETCH cursor_person INTO row_person;

        IF  cursor_person%FOUND THEN
            ln_customerid:=row_person.CUSTOMER_ID;
            pn_customerid:=ln_customerid;
        END IF;

    CLOSE cursor_person;

     --3)Person has authority to execute transaction
    OPEN cursor_authtran(ln_personid);
    FETCH cursor_authtran INTO row_authtran;

        IF cursor_authtran%NOTFOUND or row_authtran.TRAN_AUTH='N' THEN
            ls_returncode:='007';
            RAISE TransactionError;
        END IF;

    CLOSE cursor_authtran;

    SELECT PWDFORCECHANGE INTO ls_forcechange
    FROM TBL_IDENTIFICATION
    WHERE PERSON_ID=ln_personid;


    OPEN pc_ref FOR
    SELECT pn_sessionid,ps_newticketid,pn_personid,pn_customerid,ls_forcechange FROM dual;

     IF TO_NUMBER(ps_pageid)=0 THEN
         UPDATE TBL_SESSION
         SET DOUBLE_CLICK=1
         WHERE CHANNEL_CD=ps_channelcd
         AND SESSION_ID=TO_NUMBER(pn_sessionid)
         AND STATUS_CD='sACTIVE';
     END IF;


     RETURN ls_returncode;


EXCEPTION
  WHEN TransactionError THEN
  OPEN pc_ref FOR
  SELECT pn_sessionid,ps_newticketid,pn_personid,pn_customerid,'H' FROM dual;
  RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  IBMultipleCheckCustomerSession
   Created By : Muzaffar Khalyknazarov
   Date       : 03.06.08
   Purpose   : MultipleCheckCustomerSession
******************************************************************************/
FUNCTION IBMultipleCheckCustomerSession(ps_channelcd IN VARCHAR2,
                                        ps_sessionid IN VARCHAR2,
                                        ps_ticketid  IN VARCHAR2,
                                        ps_langid    IN VARCHAR2,
                                        ps_personid  IN VARCHAR2,
                                        ps_trancd    IN VARCHAR2,
                                        ps_pageid    IN VARCHAR2,
                                        pc_ref  OUT CursorReferenceType,
                                        pc_ref2 OUT CursorReferenceType,
                                        pc_ref3 OUT CursorReferenceType,
                                        pc_ref4 OUT CursorReferenceType,
                                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode      VARCHAR2(3):='000';
    ln_personid     NUMBER;
    ln_sessionid     NUMBER;
    ls_ticketid     VARCHAR2(40);
    ls_customername    VARCHAR2(250):='';
    TransactionError    EXCEPTION;

BEGIN
    --CheckCustomerSession
    ls_returncode:=Pkg_Cint_Authority.IBCheckTicket(ps_sessionid, ps_ticketid, ps_channelcd, ps_trancd, ps_pageid, pc_ref);

    --Get Main Menu
    Pkg_Cint_Authority.GetMainMenuInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref2);

    --Get Sub Menu
    Pkg_Cint_Authority.GetSubMenuInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref3);

    --Get Labels of the page
    Pkg_Cint_Authority.GetLabelInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref4);

    --Get Right/Left News
    Pkg_Cint_Authority.GetNewsInfo(ps_channelcd, ps_trancd, ps_pageid, ps_langid, ps_personid, pc_ref5);

    RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  SetStatus
   Created By : Muzaffar Khalyknazarov
   Date       : 13.06.08
   Purpose   : SetStatus
******************************************************************************/
FUNCTION SetStatus(ps_txNo                IN VARCHAR2,
                   ps_customerid          IN VARCHAR2,
                   ps_verifiedapprovedid  IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode  VARCHAR2(3):='000';
   ls_status VARCHAR2(30):='';
   ls_verify VARCHAR2(20):='Y';
   ls_check VARCHAR2(20):='Y';
   ls_approve VARCHAR2(20):='Y';
   ls_trancd VARCHAR2(20);

BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

    SELECT d.STATUS_CD,t.VERIFY_AUTH,t.CHECK_AUTH,t.APPROVE_AUTH,d.TRAN_CD
    INTO ls_status,ls_verify,ls_check,ls_approve,ls_trancd
    FROM TBL_COMPANY_AUTHORITY T,TBL_TXTRAN D
    WHERE d.TX_NO = TO_NUMBER(ps_txNo)
    AND d.TRAN_CD = t.TRAN_CD
    AND t.CUSTOMER_ID = TO_NUMBER(ps_customerid);

 IF (ls_status = 'sVERIFY') THEN
   IF ls_check = 'Y' THEN

       UPDATE TBL_TXTRAN D
       SET d.STATUS_CD='sCHECK',
           d.VERIFIER_ID = TO_NUMBER(ps_verifiedapprovedid),
           d.VERIFY_DATE=SYSDATE
       WHERE d.TX_NO=TO_NUMBER(ps_txNo);

       ls_returncode:='001'; -- verify tamam check edilmeli
   ELSIF ls_approve = 'Y' THEN

       UPDATE TBL_TXTRAN D
       SET d.STATUS_CD='sAPPROVE',
           d.VERIFIER_ID = TO_NUMBER(ps_verifiedapprovedid),
           d.VERIFY_DATE=SYSDATE
       WHERE d.TX_NO=TO_NUMBER(ps_txNo);

       ls_returncode:='002'; -- verify tamam check edilmeyecek approve edilmeli
   ELSE
       ls_returncode:='003'; -- verify tamam baska bisey yok islemi yaratabilir
   END IF;
 END IF;

 IF (ls_status = 'sCHECK') THEN
   IF ls_approve = 'Y' THEN

       UPDATE TBL_TXTRAN D
       SET d.STATUS_CD='sAPPROVE',
           d.CHECKER_ID = TO_NUMBER(ps_verifiedapprovedid),
           d.CHECK_DATE=SYSDATE
       WHERE d.TX_NO=TO_NUMBER(ps_txNo);

       ls_returncode:='004'; -- check approve edilmeli
   ELSE
     ls_returncode:='005'; -- Check tamam baska bisey yok islemi yaratabilir
   END IF;
 END IF;

 IF (ls_status = 'sAPPROVE') THEN
    ls_returncode:='006'; -- Approve tamam islemi yaratabilir
 END IF;

 RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  SetVerifyUpdateFlag
   Created By : Muzaffar Khalyknazarov
   Date       : 13.06.08
   Purpose   : SetVerifyUpdateFlag
******************************************************************************/
FUNCTION SetVerifyUpdateFlag(ps_txNo               IN VARCHAR2,
                             ps_customerid         IN VARCHAR2,
                             ps_verifiedapprovedid IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 is
 ls_returncode        varchar2(3);
begin

     ls_returncode:=pkg_cint_authority.SetStatus(ps_txNo,ps_customerid,ps_verifiedapprovedid,pc_ref);

     if ls_returncode='003' then
          UPDATE TBL_TXTRAN T
         SET T.VERIFIER_ID = TO_NUMBER(ps_verifiedapprovedid),
             T.VERIFY_DATE = SYSDATE,
             T.STATUS_CD='sDONE'
         WHERE t.TX_NO = TO_NUMBER(ps_txNo);
     elsif ls_returncode='005' then--check
         UPDATE TBL_TXTRAN T
        SET T.CHECKER_ID = TO_NUMBER(ps_verifiedapprovedid),
            T.CHECK_DATE = SYSDATE,
            T.STATUS_CD='sDONE'
        WHERE t.TX_NO=TO_NUMBER(ps_txNo);
     elsif ls_returncode='006' then--approve
         UPDATE TBL_TXTRAN T
        SET T.APPROVER_ID = TO_NUMBER(ps_verifiedapprovedid),
            T.APPROVE_DATE = SYSDATE,
            T.STATUS_CD='sDONE'
        WHERE t.TX_NO = TO_NUMBER(ps_txNo);
     end if;

     return ls_returncode;
end;

FUNCTION CheckTicketAlert(ps_count      IN VARCHAR2,
                          ps_sessionid  IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode varchar2(3):='000';
begin

    OPEN pc_ref FOR
        SELECT count(*)
        FROM corpint.tbl_activity
        where session_id=ps_sessionid
        and tran_cd='TIKETALERT';

    return ls_returncode;
exception
    when others then
        OPEN pc_ref FOR SELECT '0' FROM dual;
        return '000';
end;


/******************************************************************************
   NAME       : FUNCTION  SWIFTTODO
   Created By : Almas NURKHOZHAYEV
   Date       : 23.01.11
   Purpose   : Save SWIFT info to ToDo List
******************************************************************************/
FUNCTION SWIFTTODO(pn_amount        IN VARCHAR2,
                   ps_currency      IN VARCHAR2,
                   pn_accountid     IN VARCHAR2,
                   ps_ulkekodu      IN VARCHAR2,
                   pd_valor_tarihi  IN VARCHAR2,
                   ps_aciklama      IN VARCHAR2,
                   ps_acilistarihi  IN VARCHAR2,
                   ps_PayeeName     IN VARCHAR2,
                   ps_PayeeAddress  IN VARCHAR2,
                   pn_toAccountNo   IN VARCHAR2,
                   ps_muhabirmasraf IN VARCHAR2,
                   pn_paymentno     IN VARCHAR2,
                   ps_swiftcode     IN VARCHAR2,
                   ps_statcode      IN VARCHAR2,
                   ps_BankName      IN VARCHAR2,
                   pn_CHARGE_AMOUNT IN VARCHAR2,
                   ps_telpass       IN VARCHAR2,
                   ps_RecDesc       IN VARCHAR2,
                   ps_Recvisite     IN VARCHAR2,
                   ps_CityName      IN VARCHAR2,
                   pn_person        IN VARCHAR2,
                   ps_TranStatus    IN VARCHAR2,
                   pn_CommAccount   IN VARCHAR2,
                   pc_ref           OUT cursorreferencetype) RETURN VARCHAR2 IS

    ln_txid NUMBER;
    ls_returncode  VARCHAR2 (3)  := '000';

    TimeException    EXCEPTION;
BEGIN

    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

    /*ls_returncode:=cbs.pkg_int_limit.CheckTimeLimit('SWIFT');

    IF ls_returncode<>'000' THEN
        ls_returncode := '059';
        RAISE TimeException;
    ELSE
        ls_returncode:='000';
    END IF;*/

    ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

    INSERT INTO TBL_TXTODO
    (TX_NO, TRANCD, MAKERID, MAKEDATE, STATUS,
     FIELD1, FIELD2, FIELD3, FIELD4, FIELD5,
     FIELD6, FIELD7, FIELD8, FIELD9, FIELD10,
     FIELD11, FIELD12, FIELD13, FIELD14, FIELD15,
     FIELD16, FIELD17, FIELD18, FIELD19, FIELD20,
     AUTHCD)
    VALUES
    (ln_txid, 'SWIFT', pn_person, SYSDATE, ps_TranStatus,
     ps_PayeeAddress, ps_aciklama, pn_paymentno, ps_ulkekodu, pd_valor_tarihi,
     ps_CityName, ps_acilistarihi, ps_statcode, pn_amount, pn_toAccountNo,
     ps_muhabirmasraf, pn_accountid||'###'||pn_CommAccount, ps_swiftcode, ps_PayeeName, ps_BankName,
     ps_Recvisite, ps_telpass, ps_RecDesc, pn_CHARGE_AMOUNT, ps_currency,
     DECODE(ps_TranStatus,'sVERIFY','aVRFYSWIFT','sCHECK','aCHCKSWIFT','sAPPROVE','aAPPRSWIFT','sCONTROL','aAPPRSWIFT'));

    RETURN ls_returncode;
EXCEPTION
    WHEN TimeException THEN
        pkg_log.addcustomlog('SWIFTTODO',SQLERRM);
        RETURN ls_returncode;
    WHEN OTHERS THEN
        pkg_log.addcustomlog('SWIFTTODO',SQLERRM);
        RETURN '708';
END;

FUNCTION OTPPassword(ps_option        IN VARCHAR2,
                     pn_pwd_id        IN VARCHAR2,
                     pn_person_id     IN VARCHAR2,
                     ps_mobile_number IN VARCHAR2,
                     ps_otp_pwd       IN VARCHAR2,
                     ps_session_id    IN VARCHAR2,
                     ps_result        IN VARCHAR2,
                     pc_ref           OUT cursorreferencetype) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2 (3)  := '000';
    ls_otp_pwd VARCHAR2(35);
    ln_customer_no NUMBER;

    ln_otp_id NUMBER := 0;
    ln_count NUMBER:=0;
    ln_try NUMBER := 2;
BEGIN
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

    IF ps_option = 'WITHOUT_OTP' THEN
        SELECT COUNT(1) INTO ln_count
        FROM TBL_IDENTIFICATION
        WHERE PERSON_ID = pn_person_id;

        IF ln_count>0 THEN
            UPDATE TBL_IDENTIFICATION
            SET PWD_TYPE = 'PWD_PIN_ALWAYS'
            WHERE PERSON_ID = pn_person_id;
        END IF;

        UPDATE TBL_SESSION
        SET STATUS_CD = 'sACTIVE'
        WHERE SESSION_ID=ps_session_id;

    ELSIF ps_option = 'CHECK_OTP' THEN
        SELECT PWD_HASHED INTO ls_otp_pwd
        FROM TBL_OTP_PWDS
        WHERE ID = pn_pwd_id;
        --AND RESULT IS NULL;

        IF ls_otp_pwd <> ps_otp_pwd THEN
            RETURN '062';
        END IF;

        SELECT COUNT(1) INTO ln_count
        FROM TBL_OTP_PWDS
        WHERE ID = pn_pwd_id
        AND CREATED_AT+3/1440>SYSDATE;

        IF ln_count=0 THEN
            RETURN '063';
        END IF;

        SELECT COUNT(1) INTO ln_count
        FROM TBL_IDENTIFICATION
        WHERE PERSON_ID = pn_person_id
        AND (PWD_TYPE='PWD_PIN' OR PWD_TYPE IS NULL);

        IF ln_count>0 THEN
            UPDATE TBL_IDENTIFICATION
            SET PWD_TYPE = 'PWD_SMS'
            WHERE PERSON_ID = pn_person_id;
        END IF;

        UPDATE TBL_SESSION
        SET STATUS_CD = 'sACTIVE'
        WHERE SESSION_ID=ps_session_id;

        UPDATE TBL_TICKET_HISTORY
        SET DLM = SYSDATE
        WHERE SESSION_ID=ps_session_id;

    ELSIF ps_option = 'ADD_OTP' THEN

        SELECT CUSTOMER_ID INTO ln_customer_no
        FROM TBL_PERSON
        WHERE PERSON_ID = pn_person_id;

        ln_otp_id := Pkg_Common.GetSequenceID('pqSMSOTP');

        INSERT INTO TBL_OTP_PWDS
        (ID, PWD_HASHED, CUSTOMER_NO, PERSON_ID, MOBILE_NUMBER, TRY)
        VALUES
        (ln_otp_id, ps_otp_pwd, ln_customer_no, pn_person_id, ps_mobile_number, ln_try);

        OPEN pc_ref FOR
            SELECT ln_otp_id, ps_otp_pwd FROM DUAL;

    ELSIF ps_option = 'SET_OTP_DATA' THEN

        UPDATE TBL_OTP_PWDS
        SET SESSION_ID = ps_session_id,
            RESULT = ps_result
        WHERE ID = pn_pwd_id;

        OPEN pc_ref FOR
            SELECT pn_pwd_id FROM DUAL;
    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addcustomlog('OTPPasswords',SQLERRM);
        RETURN '999';
END;

FUNCTION ChngPinbyID(ps_tokenid IN VARCHAR2,
                     ps_pincode IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2(3):='000';
    ls_count      NUMBER:=0;
BEGIN
    OPEN PC_REF FOR SELECT SYSDATE FROM DUAL;

    UPDATE TBL_IDENTIFICATION
    SET PINCODE=ps_pincode
    WHERE TOKEN_ID = ps_tokenid;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
    ls_returncode:='999';
    Pkg_Log.AddCustomLog('ChngPinbyID',SQLERRM);
    RETURN ls_returncode;
END;
FUNCTION GetRetailClientPwdType (ps_customerId IN VARCHAR2)
   RETURN VARCHAR2
IS
   ls_pwd_type   VARCHAR2 (15);
BEGIN
   SELECT   i.PWD_TYPE
     INTO   ls_pwd_type
     FROM   TBL_IDENTIFICATION i, TBL_PERSON p
    WHERE       i.person_id = p.person_id
            AND p.customer_id = ps_customerid
            AND i.channel_cd = 'cDKBRIB'
            AND i.status_cd = 'sENAB'
            AND p.status_cd = 'sENAB';

   RETURN ls_pwd_type;
EXCEPTION
   WHEN OTHERS
   THEN
      ls_pwd_type := '';
      Pkg_Log.AddCustomLog ('GetRetailClientPwdType', SQLERRM);
      RETURN ls_pwd_type;
END;
 
FUNCTION UpdateRetailClientPwdType (ps_customerId   IN VARCHAR2,
                                    ps_personId   IN VARCHAR2,
                                    ps_otpChoice    IN VARCHAR2)
   RETURN VARCHAR2
IS
   ls_pwd_type      VARCHAR2 (15);
   ls_return_code   VARCHAR2 (3) := '000';
   ls_personId      NUMBER;
BEGIN
   IF ps_otpChoice = 'Y'
   THEN
      ls_pwd_type := 'PWD_SMS';
   ELSE
      ls_pwd_type := 'PWD_PIN_ALWAYS';
   END IF; 
   IF ps_personId IS NULL THEN 
       SELECT   i.person_id
         INTO   ls_personId
         FROM   TBL_IDENTIFICATION i, TBL_PERSON p
        WHERE       i.person_id = p.person_id
                AND p.customer_id = ps_customerid
                AND i.channel_cd = 'cDKBRIB'
                AND i.status_cd = 'sENAB'
                AND p.status_cd = 'sENAB';
   ELSE  
      ls_personId :=TO_NUMBER(ps_personId);
   END IF;
    
   UPDATE   TBL_IDENTIFICATION
      SET   PWD_TYPE = ls_pwd_type
    WHERE   person_id = ls_personId;

   RETURN ls_return_code;
EXCEPTION
   WHEN OTHERS
   THEN
      ls_return_code := '999';
      Pkg_Log.AddCustomLog ('UpdateRetailClientPwdType', SQLERRM);
      RETURN ls_return_code;
END;
END Pkg_Cint_Authority;
/

