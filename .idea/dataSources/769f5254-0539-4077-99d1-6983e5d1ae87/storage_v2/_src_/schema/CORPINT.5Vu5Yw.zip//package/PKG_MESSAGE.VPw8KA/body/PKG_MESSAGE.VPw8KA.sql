create PACKAGE BODY Pkg_Message IS

	   INPUT_PATH VARCHAR2(100):='C:\MAESTRO\INTDATA\INBOX';
	   OUTPUT_PATH VARCHAR2(100):='C:\MAESTRO\INTDATA\OUTBOX';
-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  Write2File(ps_filename IN VARCHAR2, ps_inputtext IN VARCHAR2) RETURN VARCHAR2 IS
	 f	  UTL_FILE.FILE_TYPE;
BEGIN

	 f:=UTL_FILE.FOPEN('C:\MAESTRO\INTDATA\INBOX',ps_filename,'w',2100);
	 UTL_FILE.PUT(f, ps_inputtext);
	 UTL_FILE.FCLOSE(f);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  Pkg_Log.AddCustomLog('WRITE',SQLERRM);
	 	  UTL_FILE.FCLOSE(f);
	 	  RETURN '997';
END;
-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  ReadFile( ps_filename IN VARCHAR2, ps_outputtext OUT VARCHAR2) RETURN VARCHAR2 IS
	 f	  UTL_FILE.FILE_TYPE;
	 ls_outstr		VARCHAR2(2000);

BEGIN

	 f:=UTL_FILE.FOPEN('C:\MAESTRO\INTDATA\OUTBOX', ps_filename, 'r',2100);
	 UTL_FILE.GET_LINE(f, ps_outputtext);
	 --utl_file.get_line_nchar(f,ps_outputtext,2000);
	 UTL_FILE.FCLOSE(f);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  UTL_FILE.FCLOSE(f);
		  --pkg_log.AddCustomLog('READ',sqlerrm);
	 	  RETURN '998' || SQLERRM;
END;
-------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE  DeleteFile(ps_path VARCHAR2, ps_filename IN VARCHAR2) IS
	 f	  UTL_FILE.FILE_TYPE;
BEGIN

	 UTL_FILE.fremove(ps_path, ps_filename);

EXCEPTION
	 WHEN OTHERS THEN
	 	--pkg_log.AddCustomLog('DELETE',sqlerrm);
		NULL;
END;
------------------------------------------------------------------------------------------
FUNCTION SPLIT(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2 IS
		ln_i				NUMBER:=1;
		ln_itemindx	   NUMBER:=0;
		ls_strOut		VARCHAR2(100);
BEGIN

	   LOOP
	   EXIT WHEN NOT (ln_i<=LENGTH(ps_str) OR INSTR(ps_str,ps_delimeter,ln_i)>0);
			IF ln_itemindx=pn_valindx THEN
			    IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
				   ls_strOut:=SUBSTR(ps_str,ln_i,INSTR(ps_str,ps_delimeter,ln_i)-ln_i);
				ELSE
				   ls_strOut:=SUBSTR(ps_str,ln_i);
				END IF;
			   RETURN ls_strOut;
			END IF;
			IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
			   ln_i:=INSTR(ps_str,ps_delimeter,ln_i)+LENGTH(ps_delimeter);
			ELSE
				ln_i:=LENGTH(ps_str)+1;
			END IF;
			ln_itemindx:=ln_itemindx+1;

	   END LOOP;

	   RETURN '';
END;
-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION PrepareMoneyField(ps_money IN VARCHAR2) RETURN VARCHAR2 IS
		 ls_money VARCHAR2(19);
		 ls_digit VARCHAR2(15);
		 ls_decimal	VARCHAR2(2);
		 ls_sign	VARCHAR2(1);
BEGIN
	 IF INSTR(ps_money,'.')>0 THEN
	 	ls_digit:=LPAD(SUBSTR(REPLACE(REPLACE(ps_money,',',''),'.',','),0,INSTR(REPLACE(REPLACE(ps_money,',',''),'.',','),'.')-1),15,'0');
		ls_decimal:=RPAD(SUBSTR(REPLACE(REPLACE(ps_money,',',''),'.',','),INSTR(REPLACE(REPLACE(ps_money,',',''),'.',','),'.')+1),2,'0');
	 ELSE
	 	ls_digit:=LPAD(REPLACE(REPLACE(ps_money,',',''),'.',','),15,'0');
	 	ls_decimal:='00';
	 END IF;

	 IF SUBSTR(REPLACE(REPLACE(ps_money,',',''),'.',','),0,1)='-' THEN
	 	ls_sign:='-';
	 ELSE
	 	ls_sign:='+';
	 END IF;

	 ls_money:=ls_sign || ls_digit||'.'||ls_decimal;

	 RETURN ls_money;
END;
---------------------------------------------------------------------------------------
FUNCTION PrepareField(ps_str IN VARCHAR2,pn_length IN NUMBER,
		 					 	ps_padchar IN VARCHAR2,ps_justification IN VARCHAR2,ps_fieldtype IN VARCHAR2 DEFAULT 'CHAR')  RETURN VARCHAR2 IS
		 ls_outstr			 VARCHAR2(3000);
		 ls_padchar			 VARCHAR2(1):=' ';
BEGIN
	 IF ps_padchar IS NOT NULL THEN
	 	ls_padchar:=ps_padchar;
	 END IF;

	 IF ps_fieldtype='MONEY' THEN
	 	ls_outstr:=PrepareMoneyField(ps_str);
	 ELSE
		 IF ps_justification='R' THEN
		 	ls_outstr:=LPAD(NVL(ps_str,ps_padchar),pn_length,ps_padchar);
		 ELSIF ps_justification='L' THEN
		 	ls_outstr:=RPAD(NVL(ps_str,ps_padchar),pn_length,ps_padchar);
		 END IF;
	 END IF;

	 RETURN ls_outstr;
END;
-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION GetReferenceID RETURN VARCHAR2 IS
		 ln_refnbr		NUMBER;
BEGIN

	 ln_refnbr:=Pkg_Common.GetSequenceID('MAESTRO_MSGREF');

	 RETURN LPAD(TO_CHAR(ln_refnbr),17,'0');

END;
-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION PrepareInputHeader(ps_messageid IN VARCHAR2,ps_reference IN VARCHAR2) RETURN VARCHAR2 IS
		 ls_header						 VARCHAR2(38):='';
BEGIN
	 --messageid
	 ls_header:=LPAD(ps_messageid,4,'0');
	 --auth-rev
	 ls_header:=ls_header || 'A';
	 --source
	 ls_header:=ls_header || '01';
	 --trandate
	 ls_header:=ls_header || TO_CHAR(SYSDATE,'YYYYMMDD');
	 --trantime
	 ls_header:=ls_header || TO_CHAR(SYSDATE,'HH24MISS');
	 --refnbr
	 ls_header:=ls_header || ps_reference;
	 --brach
	 --ls_header:=ls_header || '010';

	 RETURN ls_header;
END;
-------------------------------------------------------------------------------------------------------------------------------------------
/*FUNCTION  SendMessage(pn_sessionid IN NUMBER, ps_messageid IN VARCHAR2,
		  							  	 ps_inputstr IN VARCHAR2,ps_outputstr OUT VARCHAR2) RETURN VARCHAR2  IS

		 CURSOR cursor_message(p_type VARCHAR2) IS
		    SELECT c.MESSAGE_ID, c.PARAM_INDX, c.PARAM_TYPE, c.PARAM_KIND, c.PARAM_DESC, c.FIELD_CD,
			f.FIELD_LENGTH, f.FIELD_JUSTIFY, f.FIELD_PAD, f.PARENT_CD, f.FIELD_TYPE
			FROM TBL_MAESTRO_MSG_CONF c, TBL_MAESTRO_MSG_FIELDS f
			WHERE c.FIELD_CD=f.FIELD_CD
			AND c.MESSAGE_ID=ps_messageid
			AND c.PARAM_TYPE=p_type
			ORDER BY c.PARAM_INDX ASC;

		 CURSOR cursor_repeat(p_parent VARCHAR2) IS
		    SELECT 	f.FIELD_CD,f.FIELD_LENGTH, f.FIELD_JUSTIFY, f.FIELD_PAD, f.PARENT_CD, f.FIELD_TYPE
			FROM TBL_MAESTRO_MSG_FIELDS f
			WHERE f.PARENT_CD=p_parent
			ORDER BY f.PARENT_INDX ASC;

		row_message cursor_message%ROWTYPE;
		row_repeat cursor_repeat%ROWTYPE;
		ls_inmsg	VARCHAR2(3000):='';
		ls_outmsg		VARCHAR2(3000):='';
		ls_paramval		VARCHAR2(3000);
		ln_paramindx	NUMBER:=0;
		ln_paramlength			  NUMBER;
		ls_paramjust	VARCHAR2(10);
		ls_parampad		VARCHAR2(1);
		ls_paramkind	VARCHAR2(20);
		ls_reference	VARCHAR2(17);
		ls_delimeter					 VARCHAR2(3):='###';
		ls_delimeter2					 VARCHAR2(3):='***';
 		ls_returncode					VARCHAR2(3):='000';
		TransactionError 			  EXCEPTION;
		TimeoutError 			  EXCEPTION;
		ln_outindx					  NUMBER:=1;
		ln_count						  NUMBER:=0;
		ls_outstr						  VARCHAR2(3000):=' ';
		ls_infilename					  varchar2(50);
		ls_outfilename					  varchar2(50);
		ld_senddate						  date;
		ld_receivedate					  date;
		ls_outreferece					  VARCHAR2(17);
		ls_outdesc						  varchar2(37);
BEGIN
	    --0) Initialize
		ps_outputstr:=' ';

	 	--1) Get Input Format
		OPEN cursor_message('IN');
		FETCH cursor_message INTO row_message;
			IF cursor_message%NOTFOUND THEN
				ls_reference:=GetReferenceID;
				ls_inmsg:=PrepareInputHeader(ps_messageid,ls_reference);
			ELSE
				--2) Prepare input Message
				ls_reference:=GetReferenceID;
				ls_inmsg:=PrepareInputHeader(ps_messageid,ls_reference);
				WHILE  cursor_message%FOUND
				LOOP
					ls_paramval:=Split(ps_inputstr,ls_delimeter,ln_paramindx);
					ln_paramlength:=row_message.FIELD_LENGTH;
					ls_parampad:=NVL(row_message.FIELD_PAD,' ');
					ls_paramjust:=row_message.FIELD_JUSTIFY;
					ls_inmsg:=ls_inmsg || PrepareField(ls_paramval,ln_paramlength,ls_parampad,ls_paramjust,row_message.FIELD_TYPE);
				FETCH cursor_message INTO row_message;
				ln_paramindx:=ln_paramindx+1;
				END LOOP;
			END IF;
		CLOSE cursor_message;

		--3) Write to file
		--ls_infilename:='INB' || to_char(sysdate,'YYYYMMDD') || to_char(sysdate,'HHMISS') || lpad(to_char(pkg_common.GetSequenceID(to_char(sysdate,'YYYYMMDD'))),4,'0') || '.txt';
		ls_infilename:='INB' || to_char(sysdate,'MMDD') || to_char(sysdate,'HHMISS') || lpad(to_char(pkg_common.GetSequenceID(to_char(sysdate,'YYYYMMDD'))),4,'0') || '.txt';
		ls_returncode:=Write2File(ls_infilename,ls_inmsg);
		if ls_returncode!='000' then
		   raise TransactionError;
		end if;
		ld_senddate:=sysdate;


		--4) Wait For Response
		ls_outfilename:=replace(ls_infilename,'INB','OUTB');
		--ls_outfilename:=replace(ls_outfilename,'.txt',' ');
		WHILE '000'<>ReadFile(rtrim(ls_outfilename), ls_outmsg)
		LOOP
			dbms_lock.sleep(0.1);
			if (sysdate-ld_senddate)>0.00023 then
			   --Timeout occured 20 seconds
			   ls_returncode:='500';
			   raise TimeoutError;
			end if;
		END LOOP;
		ld_receivedate:=sysdate;

		--5) Get Output Format
		--ls_outmsg:='0000195165Timucin Alt?np?nar  SAnkara  USA00603 IS11 EV22 AHA33';

		ln_outindx:=1;
		--out header
		ls_outreferece:=SUBSTR(ls_outmsg,ln_outindx,17);
		ln_outindx:=ln_outindx+LENGTH(ls_outreferece);
		ls_returncode:=SUBSTR(ls_outmsg,ln_outindx,3);
		ln_outindx:=ln_outindx+LENGTH(ls_returncode);
		ls_outdesc:=SUBSTR(ls_outmsg,ln_outindx,37);
		ln_outindx:=ln_outindx+LENGTH(ls_outdesc);

		if ls_outreferece<>ls_reference then
		   ls_returncode:='501';
		   raise TimeoutError;
		end if;

		IF ls_returncode='000' THEN
			OPEN cursor_message('OUT');
			FETCH cursor_message INTO row_message;
				IF cursor_message%FOUND THEN
					--6) Prepare output string
					WHILE  cursor_message%FOUND
					LOOP
						ln_paramlength:=row_message.FIELD_LENGTH;
						ls_parampad:=NVL(row_message.FIELD_PAD,' ');
						ls_paramjust:=row_message.FIELD_JUSTIFY;
						ls_paramkind:=row_message.PARAM_KIND;
						if ls_paramkind='R' then
						--ls_outstr:=ls_outstr || ls_delimeter2;
							While ln_count>0
							LOOP
								OPEN cursor_repeat(row_message.FIELD_CD);
								FETCH cursor_repeat INTO row_repeat;
									while cursor_repeat%found
									LOOP
										ln_paramlength:=row_repeat.FIELD_LENGTH;
										ls_parampad:=NVL(row_repeat.FIELD_PAD,' ');
										ls_paramjust:=row_repeat.FIELD_JUSTIFY;
										--pkg_log.AddCustomLog('B',ln_count,length(ls_outstr),row_repeat.FIELD_CD);
									    --pkg_log.AddCustomLog(ln_count,row_repeat.FIELD_CD,SUBSTR(ls_outmsg,ln_outindx,ln_paramlength));
										ls_paramval:=SUBSTR(ls_outmsg,ln_outindx,ln_paramlength);
										ln_outindx:=ln_outindx+ln_paramlength;
										ls_outstr:=ls_outstr || ls_paramval || ls_delimeter2;
										--pkg_log.AddCustomLog('STR',ls_outstr);
									FETCH cursor_repeat INTO row_repeat;
									END LOOP;
								CLOSE cursor_repeat;
							ls_outstr:=ls_outstr || ls_delimeter;
							ln_count:=ln_count-1;
							END LOOP;
						elsif ls_paramkind='C' then
							ln_count:=to_number(SUBSTR(ls_outmsg,ln_outindx,ln_paramlength));
							ln_outindx:=ln_outindx+ln_paramlength;
					 	else
							ls_paramval:=SUBSTR(ls_outmsg,ln_outindx,ln_paramlength);
							ln_outindx:=ln_outindx+ln_paramlength;
							ls_outstr:=ls_outstr || ls_paramval || ls_delimeter;
						end if;
						--append the value
					FETCH cursor_message INTO row_message;
					END LOOP;
				END IF;
			CLOSE cursor_message;
		END IF;--if errorcd=000

		--set out message
		ps_outputstr:=ls_outstr;


		--7) Log the message
		insert into TBL_MAESTRO_MSG
		(MESSAGE_NBR, SESSION_ID, MESSAGE_ID, SEND_MSG, RECEIVED_MSG, SEND_TIME, RECEIVE_TIME, REF_NBR,ORIG_SEND_MSG, ORIG_RECEIVED_MSG,RETURNCODE)
		values
		(pkg_common.GetSequenceID('MESSAGE_NBR'), pn_sessionid, ps_messageid, ls_inmsg, ls_outmsg, ld_senddate, ld_receivedate, ls_reference,ps_inputstr,ps_outputstr,ls_returncode);

		--8) Delete Message File
		DeleteFile(OUTPUT_PATH,ls_outfilename);

		RETURN ls_returncode;

EXCEPTION
		 when TimeoutError then
 	 		begin
				insert into TBL_MAESTRO_MSG
				(MESSAGE_NBR, SESSION_ID, MESSAGE_ID, SEND_MSG, RECEIVED_MSG, SEND_TIME, RECEIVE_TIME, REF_NBR,ORIG_SEND_MSG, ORIG_RECEIVED_MSG,RETURNCODE)
				values
				(pkg_common.GetSequenceID('MESSAGE_NBR'), pn_sessionid, ps_messageid, ls_inmsg, ls_outmsg, ld_senddate, ld_receivedate, ls_reference,ps_inputstr,ps_outputstr,ls_returncode);

				--Delete Input Message File
				DeleteFile(INPUT_PATH,ls_infilename);

				RETURN ls_returncode;
			end;

		 WHEN TransactionError THEN
   	 		begin
				insert into TBL_MAESTRO_MSG
				(MESSAGE_NBR, SESSION_ID, MESSAGE_ID, SEND_MSG, RECEIVED_MSG, SEND_TIME, RECEIVE_TIME, REF_NBR,ORIG_SEND_MSG, ORIG_RECEIVED_MSG,RETURNCODE)
				values
				(pkg_common.GetSequenceID('MESSAGE_NBR'), pn_sessionid, ps_messageid, ls_inmsg, ls_outmsg, ld_senddate, ld_receivedate, ls_reference,ps_inputstr,ps_outputstr,ls_returncode);

				RETURN ls_returncode;
			end;
		When others then
			 begin
				insert into TBL_MAESTRO_MSG
				(MESSAGE_NBR, SESSION_ID, MESSAGE_ID, SEND_MSG, RECEIVED_MSG, SEND_TIME, RECEIVE_TIME, REF_NBR,ORIG_SEND_MSG, ORIG_RECEIVED_MSG,RETURNCODE)
				values
				(pkg_common.GetSequenceID('MESSAGE_NBR'), pn_sessionid, ps_messageid, ls_inmsg, ls_outmsg, ld_senddate, ld_receivedate, ls_reference,ps_inputstr,ps_outputstr,ls_returncode);

				--Delete Input Message File
				DeleteFile(INPUT_PATH,ls_infilename);

				pkg_log.AddCustomLog(sqlerrm);

				RETURN '199';
			end;
END;*/
-------------------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------------------
END;
/

