create PACKAGE         "PKG_AUTOPAYMENT" IS
TYPE CursorReferenceType IS REF CURSOR;                                          
/******************************************************************************
   Name       : FUNCTION createAutopayment
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : create/update automatic payment
******************************************************************************/   
FUNCTION createAutopayment(ps_payment_name VARCHAR2,
                                              pn_person_id VARCHAR2,
                                              pn_tran_code NUMBER,
                                              ps_tran_cd VARCHAR2,
                                              ps_payment_type VARCHAR2,
                                              ps_status VARCHAR2,
                                              ps_payment_details CLOB,
                                              ps_user_created VARCHAR2,
											  ps_option VARCHAR2,
                                              ps_seq_id VARCHAR2 DEFAULT NULL,
                                              ps_defined_date VARCHAR2 DEFAULT NULL,
                                              ps_exec_time VARCHAR2 DEFAULT NULL,
                                              ps_period VARCHAR2 DEFAULT NULL,
                                              pn_account_no NUMBER DEFAULT NULL,
                                              pn_customer_id NUMBER DEFAULT NULL,
                                              ps_channel_cd VARCHAR2 DEFAULT NULL, 
											  ps_next_date VARCHAR2 DEFAULT NULL) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION modifyAutopayment
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : modify automatic payment
******************************************************************************/   
FUNCTION modifyAutopayment(pn_seq_id IN NUMBER,
                                               ps_operation IN VARCHAR2,
                                               ps_maker IN VARCHAR2,
                                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION createPmntToDo
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : make preliminary create/update automatic payment
******************************************************************************/   
FUNCTION createPmntToDo(ps_payment_name VARCHAR2,
                                              pn_person_id VARCHAR2,
                                              pn_tran_code NUMBER,
                                              ps_tran_cd VARCHAR2,
                                              ps_payment_type VARCHAR2,
                                              ps_status VARCHAR2,
                                              ps_payment_details CLOB,
                                              ps_user_created VARCHAR2,
                                              ps_option VARCHAR2,
                                              ps_seq_id VARCHAR2 DEFAULT NULL,
                                              ps_defined_date VARCHAR2 DEFAULT NULL,
                                              ps_exec_time VARCHAR2 DEFAULT NULL,
                                              ps_period VARCHAR2 DEFAULT NULL,
                                              pn_account_no NUMBER DEFAULT NULL,
                                              pn_customer_id NUMBER DEFAULT NULL,
                                              ps_channel_cd VARCHAR2 DEFAULT NULL, 
                                              ps_upd_info CLOB DEFAULT NULL) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION approvePmntToDo
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : approve preliminary created/updated automatic payment
******************************************************************************/   
FUNCTION approvePmntToDo(ps_seq_id VARCHAR2,
                                            pn_customer_id NUMBER,
                                            pn_person_id NUMBER,
                                            ps_channel_cd VARCHAR2,
                                            ps_user_approved VARCHAR2,
                                            pc_ref  OUT CursorReferenceType) RETURN VARCHAR2;
                                            
/******************************************************************************
   Name       : FUNCTION declinePmntToDo
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : decline preliminary created/updated automatic payment
******************************************************************************/   
FUNCTION declinePmntToDo(ps_seq_id VARCHAR2,
                                            pn_customer_id NUMBER,
                                            pn_person_id NUMBER,
                                            ps_channel_cd VARCHAR2,
                                            ps_user_approved VARCHAR2,
                                            pc_ref  OUT CursorReferenceType) RETURN VARCHAR2;                                            

/******************************************************************************
   Name       : FUNCTION makeAutopayment
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : make automatic payment
******************************************************************************/   
FUNCTION makeAutopayment(pn_person_id IN NUMBER,
                                             pn_customer_id IN NUMBER,
                                             pn_tran_code IN NUMBER,
                                             ps_tran_cd IN VARCHAR2,
                                             ps_channel_cd IN VARCHAR2,
						                     ps_payment_details IN CLOB,
                                             ps_trig_amount IN VARCHAR2,
                                             ps_trig_curr IN VARCHAR2,
                                             ps_error OUT VARCHAR2) RETURN VARCHAR2;
											  
/******************************************************************************
   Name       : PROCEDURE processAutopayments
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : process automatic payments
******************************************************************************/   
PROCEDURE processAutopayments(pd_start_date DATE);

/******************************************************************************
   Name       : PROCEDURE processTrigAutopayments
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : process triggered automatic payments
******************************************************************************/   
PROCEDURE processTrigAutopayments(pd_start_date DATE);

/******************************************************************************
   Name       : FUNCTION getWaitPmnts
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get waiting automatic payments
******************************************************************************/   
FUNCTION getWaitPmnts(ps_option IN VARCHAR2,
                                     ps_seq_id IN VARCHAR2,
                                     ps_channel_cd IN VARCHAR2,
                                     ps_customer_id IN VARCHAR2,
                                     ps_person_id IN VARCHAR2,
                                     pc_ref   OUT   CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION parseDetails
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : parse clob containing payment details
******************************************************************************/   
FUNCTION parseDetails(ps_details CLOB,
                                   pn_order NUMBER) RETURN VARCHAR2;
                                   
/******************************************************************************
   Name       : FUNCTION extractClob
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : extract clob containing payment details
******************************************************************************/   
FUNCTION extractClob(ps_details CLOB,
                                   pn_order NUMBER) RETURN VARCHAR2;                                   

/******************************************************************************
   Name       : FUNCTION getExchangeRatesIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange rates for IB transactions
******************************************************************************/   
FUNCTION getExchangeRatesIB(pd_date IN DATE,
                                                pn_option IN NUMBER,
                                                ps_result OUT VARCHAR2) RETURN VARCHAR2;
                                                
/******************************************************************************
   Name       : FUNCTION getExchangeRatioIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange ratios for currencies
******************************************************************************/   
FUNCTION getExchangeRatioIB(pc_ref IN CursorReferenceType,
                                               rate_type IN VARCHAR2,
                                               ps_fc_amount OUT VARCHAR2,
                                               ps_total_amount OUT VARCHAR2,
                                               ps_rate OUT VARCHAR2) RETURN VARCHAR2;
                                               
/******************************************************************************
   Name       : FUNCTION getExchangeParityIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange parity for currencies
******************************************************************************/   
FUNCTION getExchangeParityIB(pc_ref IN CursorReferenceType,
                                                pc_ref2 IN CursorReferenceType,
                                                ps_amount_currency IN VARCHAR2,
                                                ps_parity OUT VARCHAR2,
                                                ps_from_amount OUT VARCHAR2,
                                                ps_to_amount OUT VARCHAR2) RETURN VARCHAR2;                                               

/******************************************************************************
   Name       : FUNCTION getCommissionIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get commission amounts for IB transactions
******************************************************************************/   
FUNCTION getCommissionIB(ps_TranCd     IN VARCHAR2,
                                           pn_FromAccNo  IN VARCHAR2,
                                           pn_ToAccNo    IN VARCHAR2,
                                           pn_Amount     IN VARCHAR2,
                                           ps_CurrCd     IN VARCHAR2,
                                           ps_ChannelCd IN VARCHAR2,
                                           ps_amountComm OUT VARCHAR2,
                                           ps_taxComm OUT VARCHAR2) RETURN VARCHAR2;
                                           
/******************************************************************************
   Name       : FUNCTION getMaturityDate
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get maturity date for clearing and swift
******************************************************************************/   
FUNCTION getMaturityDate(ps_tran_date IN VARCHAR2,
                                          ps_tran_cd IN VARCHAR2,
                                          ps_type IN VARCHAR2,
                                          ps_maturity_date OUT VARCHAR2) RETURN VARCHAR2;                                           

END;
/

