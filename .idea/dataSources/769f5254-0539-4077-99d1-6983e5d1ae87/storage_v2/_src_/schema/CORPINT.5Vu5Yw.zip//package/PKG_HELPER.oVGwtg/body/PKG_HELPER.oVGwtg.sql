create PACKAGE BODY         PKG_HELPER IS
-------------------------------------------------------------------
FUNCTION getNumberFromVarchar2(ps_number IN VARCHAR2, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN NUMBER IS
    ls_decimal_point varchar2(1);
    ls_thousand_point varchar2(1);
    
    ls_number varchar2(100) := substr(ps_number, 1, 100);
BEGIN
    SELECT SUBSTR(VALUE, 1, 1), SUBSTR(VALUE, 2, 1) INTO ls_decimal_point, ls_thousand_point
    FROM nls_session_parameters
    WHERE parameter = 'NLS_NUMERIC_CHARACTERS';
    
    ls_number := replace(ps_number, SUBSTR(ps_numeric_chars, 2, 1), ''); --remove thousands point
    ls_number := replace(ls_number, SUBSTR(ps_numeric_chars, 1, 1), ls_decimal_point); --replace decimal point to nls one
    
    RETURN to_number(ls_number);
EXCEPTION
	WHEN OTHERS THEN
		return null;
END;
-------------------------------------------------------------------
FUNCTION getVarchar2FromNumber(ps_number IN NUMBER, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN VARCHAR2 IS
    ls_decimal_point varchar2(1);
    ls_thousand_point varchar2(1);

    ls_number varchar2(100);
BEGIN
    SELECT SUBSTR(VALUE, 1, 1), SUBSTR(VALUE, 2, 1) INTO ls_decimal_point, ls_thousand_point
    FROM nls_session_parameters
    WHERE parameter = 'NLS_NUMERIC_CHARACTERS';

    ls_number := trim(to_char(ps_number, '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_decimal_point || '99'));
    
    IF (length(ps_numeric_chars)=1) THEN
        ls_number := replace(ls_number, ls_thousand_point, ''); --remove thousands point
        return replace(ls_number, ls_decimal_point, ps_numeric_chars);
    ELSIF (length(ps_numeric_chars)=2) THEN
        ls_number := replace(ls_number, ls_thousand_point, 'X'); --change thousands point to X temporarily
        ls_number := replace(ls_number, ls_decimal_point, SUBSTR(ps_numeric_chars, 1, 1)); --change real decimal point to param
        return replace(ls_number, 'X', SUBSTR(ps_numeric_chars, 2, 1));
    ELSE
        return ls_number;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        return null;
END;
-------------------------------------------------------------------
END PKG_HELPER;
/

