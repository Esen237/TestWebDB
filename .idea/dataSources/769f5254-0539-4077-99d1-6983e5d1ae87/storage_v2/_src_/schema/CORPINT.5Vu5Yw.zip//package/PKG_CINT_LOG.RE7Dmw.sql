create PACKAGE           "PKG_CINT_LOG" IS

TYPE CursorReferenceType IS REF CURSOR;

/******************************************************************************
   NAME       : FUNCTION  LogTransaction
   Created By : Muzaffar Khalyknazarov
   Date       : 04.12.07
   Purpose    : LogTransaction
******************************************************************************/
FUNCTION LogTransaction(ps_channelcd    IN VARCHAR2,
                        pn_sessionid    IN NUMBER,
                        pn_personid     IN NUMBER,
                        ps_trancd       IN VARCHAR2,
                        pn_pageid       IN NUMBER,
                        ps_systemcd     IN VARCHAR2,
                        ps_errorcd      IN VARCHAR2,
                        ps_langcd       IN VARCHAR2,
                        ps_errordesc    IN VARCHAR2,
                        ps_actvtime     IN VARCHAR2,
                        pn_amount       IN VARCHAR2,
                        ps_currency     IN VARCHAR2,
                        ps_servername   IN VARCHAR2,
                        ps_ipaddress    IN VARCHAR2,
                        ps_jspduration  IN VARCHAR2 DEFAULT 0,
                        ps_beanduration IN VARCHAR2 DEFAULT 0,
                        ps_field1       IN VARCHAR2 DEFAULT NULL,
                        ps_field2       IN VARCHAR2 DEFAULT NULL,
                        ps_field3       IN VARCHAR2 DEFAULT NULL,
                        ps_field4       IN VARCHAR2 DEFAULT NULL,
                        ps_field5       IN VARCHAR2 DEFAULT NULL,
                        ps_field6       IN VARCHAR2 DEFAULT NULL,
                        ps_field7       IN VARCHAR2 DEFAULT NULL,
                        ps_field8       IN VARCHAR2 DEFAULT NULL,
                        ps_field9       IN VARCHAR2 DEFAULT NULL,
                        ps_field10      IN VARCHAR2 DEFAULT NULL,
                        ps_field11      IN VARCHAR2 DEFAULT NULL,
                        ps_field12      IN VARCHAR2 DEFAULT NULL,
                        ps_field13      IN VARCHAR2 DEFAULT NULL,
                        ps_field14      IN VARCHAR2 DEFAULT NULL,
                        ps_field15      IN VARCHAR2 DEFAULT NULL,
                        ps_userdesc     OUT VARCHAR2) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetUserInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Return User Information and last login date
******************************************************************************/
PROCEDURE AddCustomLog(pid1 VARCHAR2,
                         pid2 VARCHAR2 DEFAULT NULL,
                       pid3 VARCHAR2 DEFAULT NULL,
                       pid4 VARCHAR2 DEFAULT NULL);
                       
FUNCTION GetErrorDescByCode (ps_systemcd   IN VARCHAR2,
                             ps_langcd     IN VARCHAR2,
                             ps_errorcd    IN VARCHAR2) RETURN VARCHAR2;
 
END Pkg_Cint_Log;
/

