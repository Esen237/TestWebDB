create PACKAGE         Pkg_Log IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
FUNCTION LogTransaction(ps_channelcd IN VARCHAR2,
                        pn_sessionid    IN NUMBER,
                        pn_personid    IN NUMBER,
                        ps_trancd    IN VARCHAR2,
                        pn_pageid    IN NUMBER,
                        ps_systemcd    IN VARCHAR2,
                        ps_errorcd    IN VARCHAR2,
                       ps_langcd    IN VARCHAR2,
                          ps_errordesc    IN VARCHAR2,
                        ps_actvtime    IN VARCHAR2,
                        pn_amount    IN VARCHAR2,
                        ps_currency    IN VARCHAR2,
                        ps_servername    IN VARCHAR2,
                       ps_ipaddress    IN VARCHAR2,
                       ps_field1 IN VARCHAR2 DEFAULT NULL,
                       ps_field2 IN VARCHAR2 DEFAULT NULL,
                       ps_field3 IN VARCHAR2 DEFAULT NULL,
                       ps_field4 IN VARCHAR2 DEFAULT NULL,
                       ps_field5 IN VARCHAR2 DEFAULT NULL,
                       ps_field6 IN VARCHAR2 DEFAULT NULL,
                       ps_field7 IN VARCHAR2 DEFAULT NULL,
                       ps_field8 IN VARCHAR2 DEFAULT NULL,
                       ps_field9 IN VARCHAR2 DEFAULT NULL,
                       ps_field10 IN VARCHAR2 DEFAULT NULL,
                       ps_field11 IN VARCHAR2 DEFAULT NULL,
                       ps_field12 IN VARCHAR2 DEFAULT NULL,
                       ps_field13 IN VARCHAR2 DEFAULT NULL,
                       ps_field14 IN VARCHAR2 DEFAULT NULL,
                       ps_field15 IN VARCHAR2 DEFAULT NULL,
                          ps_userdesc        OUT VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
PROCEDURE AddCustomLog(pid1 VARCHAR2,
                   pid2 VARCHAR2 DEFAULT NULL,
                 pid3 VARCHAR2 DEFAULT NULL,
                 pid4 VARCHAR2 DEFAULT NULL);
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
PROCEDURE addAutopaymentLog(ps_operation IN VARCHAR2,
                                               ps_payment_name IN VARCHAR2,
                                               pn_person_id    IN NUMBER,
                                               pn_customer_id IN NUMBER,
                                               pn_tran_code IN NUMBER,
                                               ps_tran_cd IN VARCHAR2,
                                               ps_channel_cd IN VARCHAR2,
                                               ps_payment_type IN VARCHAR2,
                                               ps_status    IN VARCHAR2,
                                               ps_payment_details IN CLOB,
                                               ps_defined_date IN VARCHAR2,
                                               ps_execution_time IN VARCHAR2,
                                               ps_period IN VARCHAR2,
                                               ps_user_created IN VARCHAR2 ,
                                               pd_created_date IN DATE,
                                               ps_user_approved IN VARCHAR2 DEFAULT NULL,
                                               pd_approved_date IN DATE DEFAULT NULL,
											   pn_seq_id IN NUMBER DEFAULT NULL,
											   ps_next_date   IN VARCHAR2 DEFAULT NULL,
                                               pn_account_no IN NUMBER DEFAULT NULL,
                                               ps_prev_date IN VARCHAR2 DEFAULT NULL,
                                               ps_prev_code IN VARCHAR2 DEFAULT NULL,
                                               ps_prev_err IN VARCHAR2 DEFAULT NULL,
                                               ps_details IN VARCHAR2 DEFAULT NULL,
                                               ps_upd_info IN CLOB DEFAULT NULL);
END;
/

