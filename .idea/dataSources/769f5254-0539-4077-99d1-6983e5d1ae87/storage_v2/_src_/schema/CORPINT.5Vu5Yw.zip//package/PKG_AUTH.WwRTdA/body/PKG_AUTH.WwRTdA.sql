create PACKAGE BODY         pkg_auth IS
-------------------------------------------------------------------
FUNCTION CheckUser(ps_channelcd IN VARCHAR2,
       ps_username IN VARCHAR2,
          ps_passcode IN VARCHAR2,
          ps_pincode IN VARCHAR2,
      pn_sessionid OUT NUMBER,
      ps_ticketid OUT VARCHAR2,
      pn_personid OUT NUMBER,
      ps_pwdforcechange OUT VARCHAR2,
      ps_tokenid OUT VARCHAR2
      ) RETURN VARCHAR2 IS

   CURSOR cursor_identity IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.USERNAME = ps_username
   AND i.CHANNEL_CD=ps_channelcd;
   --and i.EXPIREDATE>sysdate;

  CURSOR cursor_alias IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.USERALIAS = ps_username
   AND i.CHANNEL_CD=ps_channelcd;
   --and i.EXPIREDATE>sysdate;

   CURSOR cursor_passcode(pn_personid NUMBER) IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=pn_personid
   AND i.CHANNEL_CD=ps_channelcd
   AND i.STATUS_CD='sENAB'
   AND i.PASSCODE=ps_passcode;

   CURSOR cursor_pincode(pn_personid NUMBER) IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=pn_personid
   AND i.CHANNEL_CD=ps_channelcd
   AND i.STATUS_CD='sENAB'
   AND i.PINCODE=ps_pincode;

    CURSOR cursor_expire(pn_personid NUMBER) IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=pn_personid
   AND i.EXPIREDATE>SYSDATE;

   row_identity cursor_identity%ROWTYPE;
   row_alias cursor_alias%ROWTYPE;
   row_passcode cursor_passcode%ROWTYPE;
   row_pincode cursor_pincode%ROWTYPE;
   row_expire cursor_expire%ROWTYPE;
    ls_statement VARCHAR2(2000);
   ls_returncode VARCHAR2(3):='000';
   ln_attemptcount NUMBER:=0;
   ln_sessionid  NUMBER:=0;
   ls_ticketid   VARCHAR2(40):='';
   ln_personid   NUMBER:=0;
   ls_pwdforcechange   VARCHAR2(1):='';
   TransactionError    EXCEPTION;
   TokenPresent EXCEPTION;
   ls_sessionStatus VARCHAR2(10) := 'sACTIVE';
   ls_personstatus VARCHAR2(20) := 'sENAB';

 BEGIN
 --0)Initialize outputs
  pn_sessionid:=0;
  ps_ticketid:=' ';
  pn_personid:=0;
  ps_pwdforcechange:=' ';
  ps_tokenid:=' ';

  --1) Check for username,status,expiredate
  -- EXPIREDATE>sysdate and STATUS='sENAB'
  OPEN cursor_identity;
  FETCH cursor_identity INTO row_identity;
  IF  cursor_identity%NOTFOUND THEN
   OPEN cursor_alias;
   FETCH cursor_alias INTO row_alias;
   IF  cursor_alias%NOTFOUND THEN
    ls_returncode:='001';
    RAISE TransactionError;
   ELSE
    ln_personid:=row_alias.PERSON_ID;
    ls_pwdforcechange:=row_alias.PWDFORCECHANGE;
    ln_attemptcount:=row_alias.ATTEMPT_COUNT;
    pn_personid:=ln_personid;
    ps_pwdforcechange:=ls_pwdforcechange;
    ps_tokenid:=NVL(row_alias.TOKEN_ID,' ');
    ls_personstatus:=row_alias.STATUS_CD;
   END IF;
   CLOSE cursor_alias;
  ELSE
   ln_personid:=row_identity.PERSON_ID;
   ls_pwdforcechange:=row_identity.PWDFORCECHANGE;
   ln_attemptcount:=row_identity.ATTEMPT_COUNT;
   pn_personid:=ln_personid;
   ps_pwdforcechange:=ls_pwdforcechange;
   ps_tokenid:=NVL(row_identity.TOKEN_ID,' ');
   ls_personstatus:=row_identity.STATUS_CD;
  END IF;
  CLOSE cursor_identity;

  -- account disable olmu? ise kullan?c?y? uyarmak laz?m..
  --
  IF (ls_personstatus <> 'sENAB') THEN
  ls_returncode:='459';
  RAISE TransactionError;
  END IF;


  --2) Check for passcode
  -- Lock the user if attem count exceed 3
   OPEN cursor_passcode(ln_personid);
  FETCH cursor_passcode INTO row_passcode;
  IF  cursor_passcode%NOTFOUND THEN
   ls_returncode:='002';
   IF ln_attemptcount+1>3 THEN
    UPDATE TBL_IDENTIFICATION i
    SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1,
     i.STATUS_CD='sLOCKED'
    WHERE i.PERSON_ID=ln_personid;
    ls_returncode:='008';
   ELSE
    UPDATE TBL_IDENTIFICATION i
    SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1
    WHERE i.PERSON_ID=ln_personid;
   END IF;
   RAISE TransactionError;
  END IF;
  CLOSE cursor_passcode;

  --3) Check for pincode
  -- Lock the user if attem count exceed 3
   OPEN cursor_pincode(ln_personid);
  FETCH cursor_pincode INTO row_pincode;
  IF  cursor_pincode%NOTFOUND THEN
   ls_returncode:='003';
   IF ln_attemptcount+1>3 THEN
    UPDATE TBL_IDENTIFICATION i
    SET i.attempt_count=i.attempt_count+1,
     i.STATUS_CD='sLOCKED'
    --where i.USERNAME = ps_username
    --and i.CHANNEL_CD=ps_channelcd;
    WHERE i.PERSON_ID=ln_personid;
    ls_returncode:='008';
   ELSE
    UPDATE TBL_IDENTIFICATION i
    SET i.attempt_count=i.attempt_count+1
    --where i.USERNAME = ps_username
    --and i.CHANNEL_CD=ps_channelcd;
    WHERE i.PERSON_ID=ln_personid;
   END IF;
   RAISE TransactionError;
  END IF;
  CLOSE cursor_pincode;

  --4) Authentication OK Clear Attemp Count
  UPDATE TBL_IDENTIFICATION i
  SET i.attempt_count=0
  WHERE i.PERSON_ID=ln_personid
  AND i.CHANNEL_CD=ps_channelcd;


     IF LENGTH(ps_tokenid) > 1 THEN
     ls_sessionStatus:='sTOKEN';
  END IF;

  --4) Create an Active Session
   ln_sessionid:=Pkg_Common.GetSequenceID('sqSESSIONID');

  --Close old sessions
  UPDATE TBL_SESSION
  SET status_cd='sCLOSED'
  WHERE person_id=ln_personid;

  --Create new session
  INSERT INTO TBL_SESSION
  (SESSION_ID, PERSON_ID, CHANNEL_CD, STATUS_CD)
  VALUES
  (ln_sessionid, ln_personid, ps_channelcd, ls_sessionStatus);

   pn_sessionid:=ln_sessionid;

  --5) Get Ticket
   ls_ticketid:=Pkg_Common.GetTicketID;

  IF ls_ticketid IS NULL THEN
     ls_returncode:='004';
     RAISE TransactionError;
  ELSE
     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
     VALUES
     (ln_personid, ls_ticketid, 1, ln_sessionid);
  END IF;

  ps_ticketid:=ls_ticketid;

 --6) Expire Check
  OPEN cursor_expire(ln_personid);
  FETCH cursor_expire INTO row_passcode;
  IF  cursor_expire%NOTFOUND THEN
   ps_pwdforcechange:='E';
  END IF;
  CLOSE cursor_expire;

     RETURN ls_returncode;

EXCEPTION
 WHEN TokenPresent THEN
   RETURN ls_returncode;
 WHEN TransactionError THEN
   RETURN ls_returncode;

END;
-------------------------------------------------------------------
FUNCTION CheckTicket(pn_sessionid   IN NUMBER,
                     ps_ticketid    IN VARCHAR2,
                       ps_channelcd   IN VARCHAR2,
                        ps_trancd      IN VARCHAR2,
                     ps_pageid      IN VARCHAR2,
                       ps_newticketid OUT VARCHAR2,
                       pn_personid    OUT NUMBER,
                       pn_customerid  OUT VARCHAR2) RETURN VARCHAR2 IS

   CURSOR cursor_session IS
      SELECT * FROM TBL_SESSION s
   WHERE s.CHANNEL_CD=ps_channelcd
   AND s.SESSION_ID=pn_sessionid
   AND s.STATUS_CD='sACTIVE';

-- This package uses only admin, so ticket timeout will be 3 hours
   CURSOR cursor_ticket(pn_personid NUMBER) IS
     SELECT * FROM TBL_TICKET_HISTORY t
     WHERE t.SESSION_ID=pn_sessionid
     AND t.TICKET_ID=(select ticket_id from (select aa.ticket_id from corpint.tbl_ticket_history aa where aa.session_id=pn_sessionid order by aa.dlm desc) where rownum=1)
     AND t.PERSON_ID=pn_personid
     AND (t.DLM+(3/(24))) > SYSDATE;

  CURSOR cursor_authtran(pn_personid NUMBER) IS
      SELECT TRAN_CD FROM TBL_AUTH_TRAN a
   WHERE  a.TRAN_CD=ps_trancd
   AND a.AUTH_CD IN (SELECT AUTH_CD FROM TBL_PERSON_AUTH p
       WHERE p.PERSON_ID=pn_personid
       AND p.CHANNEL_CD=ps_channelcd);

   CURSOR cursor_person(pn_personid NUMBER) IS
      SELECT * FROM TBL_PERSON p
   WHERE p.PERSON_ID=pn_personid;

   row_session cursor_session%ROWTYPE;
   row_ticket cursor_ticket%ROWTYPE;
   row_authtran cursor_authtran%ROWTYPE;
   row_person cursor_person%ROWTYPE;

   TransactionError EXCEPTION;
   ls_statement   VARCHAR2(2000);
   ls_returncode   VARCHAR2(3):='000';
   ln_ticketindx   NUMBER:=0;
   ln_personid   NUMBER:=0;
   ls_ticketid   VARCHAR2(40):=' ';
   ln_customerid   VARCHAR2(13):='0';
   ls_cusmomername  VARCHAR2(200):=' ';
BEGIN
    IF TO_NUMBER(ps_pageid)<>0 THEN

        UPDATE TBL_SESSION
      SET DOUBLE_CLICK=0
           WHERE CHANNEL_CD=ps_channelcd
           AND SESSION_ID=TO_NUMBER(pn_sessionid)
           AND STATUS_CD='sACTIVE';
  END IF;

  --0)Initialize the outparams
   ps_newticketid:=ls_ticketid;
   pn_personid:=ln_personid;
   pn_customerid:=ln_customerid;

  --1)Person has valid session
   OPEN cursor_session;
  FETCH cursor_session INTO row_session;
  IF  cursor_session%NOTFOUND THEN
   ls_returncode:='005';
   RAISE TransactionError;
  ELSE
   ln_personid:=row_session.PERSON_ID;
   pn_personid:=ln_personid;
  END IF;
  IF row_session.double_click=1 THEN
       ls_returncode:='031';
     RAISE TransactionError;
  END IF;
  CLOSE cursor_session;

  --2)Person has valid ticket TicketDate+7min>sysdate
   OPEN cursor_ticket(ln_personid);
  FETCH cursor_ticket INTO row_ticket;
  IF  cursor_ticket%NOTFOUND THEN
   ls_returncode:='006';
   RAISE TransactionError;
  ELSE
   ln_ticketindx:=row_ticket.TICKET_INDX;
  END IF;
  CLOSE cursor_ticket;

  --3)Person has authority to execute transaction
    OPEN cursor_authtran(ln_personid);
  FETCH cursor_authtran INTO row_authtran;
  IF  cursor_authtran%NOTFOUND THEN
   ls_returncode:='007';
   RAISE TransactionError;
  END IF;
  CLOSE cursor_authtran;
  --4)Get New Ticket
   ls_ticketid:=Pkg_Common.GetTicketID;
  IF ls_ticketid IS NULL THEN
     ls_returncode:='004';
     RAISE TransactionError;
  ELSE
     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID,DLM)
     VALUES
     (ln_personid, ls_ticketid, ln_ticketindx+1, pn_sessionid,SYSDATE);
  END IF;
     ps_newticketid:=ls_ticketid;
  --5)Get Customer Info
   OPEN cursor_person(ln_personid);
  FETCH cursor_person INTO row_person;
  IF  cursor_person%FOUND THEN
   ln_customerid:=row_person.CUSTOMER_ID;
   pn_customerid:=ln_customerid;
  END IF;
  CLOSE cursor_person;

  IF TO_NUMBER(ps_pageid)=0 THEN
    UPDATE TBL_SESSION
      SET DOUBLE_CLICK=1
           WHERE CHANNEL_CD=ps_channelcd
           AND SESSION_ID=TO_NUMBER(pn_sessionid)
           AND STATUS_CD='sACTIVE';
  END IF;
     RETURN ls_returncode;

EXCEPTION
  WHEN TransactionError THEN
    pkg_log.AddCustomLog('Error',ls_returncode);
    RETURN ls_returncode;
END;
-------------------------------------------------------------------
FUNCTION SafeExit(pn_sessionid IN NUMBER) RETURN VARCHAR2 IS
 ls_returncode      VARCHAR2(3):='000';
BEGIN
  UPDATE TBL_SESSION
  SET STATUS_CD='sCLOSED'
  WHERE SESSION_ID=pn_sessionid;

  RETURN ls_returncode;
END;
-------------------------------------------------------------------
FUNCTION ChangeAlias(ps_channelcd IN VARCHAR2,
       pn_personid IN NUMBER,
      ps_newusername IN VARCHAR2) RETURN VARCHAR2 IS

   ls_returncode VARCHAR2(3):='000';
   TransactionError    EXCEPTION;
   CURSOR cursor_alias IS
     SELECT *
    FROM TBL_IDENTIFICATION
    WHERE (UPPER(username)=UPPER(ps_newusername) OR UPPER(useralias)=UPPER(ps_newusername));

   row_alias   cursor_alias%ROWTYPE;
 BEGIN

  OPEN cursor_alias;
 FETCH cursor_alias INTO row_alias;
 IF  cursor_alias%NOTFOUND THEN
   UPDATE TBL_IDENTIFICATION
   SET USERALIAS=ps_newusername
   WHERE PERSON_ID=pn_personid;
 ELSE
  ls_returncode:='011';
  RAISE TransactionError;
 END IF;
 CLOSE cursor_alias;


     RETURN ls_returncode;

EXCEPTION
 WHEN TransactionError THEN
   RETURN ls_returncode;

END;
-------------------------------------------------------------------
FUNCTION ChangePwdPin(ps_option IN VARCHAR2,
        ps_channelcd IN VARCHAR2,
        pn_personid IN NUMBER,
           ps_oldcode IN VARCHAR2,
           ps_newcode IN VARCHAR2) RETURN VARCHAR2 IS


  CURSOR cursor_person IS
     SELECT * FROM TBL_IDENTIFICATION
  WHERE PERSON_ID=pn_personid
  AND  ps_oldcode=DECODE(ps_option,'PWD',PASSCODE,'PIN',PINCODE);

  row_person cursor_person%ROWTYPE;

CURSOR cursor_passwd(p_newpasswd VARCHAR2) IS

          SELECT * FROM TBL_PWD_HISTORY
            WHERE PERSON_ID=pn_personid
            AND PASSTYPE=ps_option
            AND p_newpasswd IN
            (
                  SELECT PASSWD FROM
                  (
                  SELECT ROWNUM, a.DLM tarih,PASSWD FROM TBL_PWD_HISTORY a
                  WHERE PERSON_ID=pn_personid
                  AND PASSTYPE=ps_option
                  ORDER BY dlm DESC
                  ) WHERE ROWNUM < 4 -- son 3 ?ifreden biri olmamaly
            );

  row_passwd cursor_passwd%ROWTYPE;


  ls_returncode VARCHAR2(3):='000';
  TransactionError    EXCEPTION;
   n BOOLEAN;
   m INTEGER;
   differ INTEGER;
   isdigit BOOLEAN;
   ischar  NUMBER ;
   ispunct BOOLEAN;
   digitarray VARCHAR2(20);
   punctarray VARCHAR2(25);
   chararray VARCHAR2(52);
 BEGIN
 IF ps_option='PWD' THEN
    IF LENGTH(ps_newcode)<>32 THEN
       ls_returncode:='014';
    RAISE TransactionError;
    END IF;
 ELSIF  ps_option='PIN' THEN
       IF LENGTH(ps_newcode)<>32 THEN
       ls_returncode:='015';
    RAISE TransactionError;
    END IF;
 END IF;

  OPEN cursor_person;
  FETCH cursor_person INTO row_person;
  IF  cursor_person%NOTFOUND THEN
   IF ps_option='PWD' THEN
     ls_returncode:='002';
  ELSIF  ps_option='PIN' THEN
     ls_returncode:='003';
  END IF;
  RAISE TransactionError;
  END IF;
  CLOSE cursor_person;

   OPEN cursor_passwd(ps_newcode);
  FETCH cursor_passwd INTO row_passwd;
  IF  cursor_passwd%FOUND THEN
   IF ps_option='PWD' THEN
     ls_returncode:='012';
  ELSIF  ps_option='PIN' THEN
     ls_returncode:='013';
  END IF;
  RAISE TransactionError;
  END IF;
  CLOSE cursor_passwd;

   IF ps_option='PWD' THEN
   UPDATE TBL_IDENTIFICATION
   SET PASSCODE=ps_newcode, PWDFORCECHANGE='H',EXPIREDATE=SYSDATE+90
   WHERE PERSON_ID=pn_personid;

  ELSIF  ps_option='PIN' THEN
   UPDATE TBL_IDENTIFICATION
   SET PINCODE=ps_newcode
   WHERE PERSON_ID=pn_personid;

  END IF;

 INSERT INTO TBL_PWD_HISTORY
 (PERSON_ID, PASSWD, PASSTYPE)
 VALUES
 (pn_personid,ps_newcode,ps_option);


     RETURN ls_returncode;

EXCEPTION
 WHEN TransactionError THEN
   RETURN ls_returncode;

END;
-------------------------------------------------------------------
FUNCTION LastLoginDate(pn_personid IN NUMBER,ps_lastlogindate OUT VARCHAR2) RETURN VARCHAR2 IS

 CURSOR cursor_session IS
  SELECT * FROM TBL_SESSION
  WHERE person_id=pn_personid
  AND status_cd='sCLOSED'
  ORDER BY session_id DESC;

 row_session cursor_session%ROWTYPE;
 ls_returncode VARCHAR2(3):='000';

BEGIN

   OPEN cursor_session;
  FETCH cursor_session INTO row_session;
  IF  cursor_session%FOUND THEN
    ps_lastlogindate:=TO_CHAR(row_session.DLM,'DD.MM.YYYY HH24:MI:SS');
  ELSE
    ps_lastlogindate:=' ';
  END IF;
  CLOSE cursor_session;

  RETURN '000';
END;
-------------------------------------------------------------------
FUNCTION WrongAttempCount(pn_personid IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';
BEGIN
     OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;

     OPEN pc_ref FOR
  SELECT t.ATTEMPT_COUNT FROM TBL_IDENTIFICATION t
  WHERE t.PERSON_ID=TO_NUMBER(pn_personid);

  RETURN '000';
END;
-------------------------------------------------------------------
FUNCTION CreatePassID(ps_uid IN VARCHAR2,
        ps_pwd IN VARCHAR2,
        ps_pin IN VARCHAR2,
           ps_passid OUT VARCHAR2) RETURN VARCHAR2 IS
 ln_passid    NUMBER;
BEGIN
  ln_passid:=Pkg_Common.GetSequenceID('PASSID');

  INSERT INTO corpint.TBL_DUMMY_PASSID
  (PASSID, USERNAME, PASSCODE, PINCODE, CREATEDBY, ASSIGNEDBY, ASSIGNEDTO, ASSIGNDATE, STATUSCD)
  VALUES
  (ln_passid, ps_uid, ps_pwd, ps_pin, NULL, NULL, NULL, NULL, 'sNEW');
  
 
  INSERT INTO corpint2.TBL_DUMMY_PASSID
  (PASSID, USERNAME, PASSCODE, PINCODE, CREATEDBYADMIN, ASSIGNEDBYADMIN, ASSIGNEDTO, ASSIGNDATE, STATUSCD)
  VALUES
  (ln_passid, ps_uid, ps_pwd, ps_pin, NULL, NULL, NULL, NULL, 'sNEW');
  
  ps_passid:=TO_CHAR(ln_passid);
  

  RETURN '000';
EXCEPTION
   WHEN OTHERS THEN
      RETURN '021';
END;

-------------------------------------------------------------------
FUNCTION AssignPassID(ps_option IN VARCHAR2,
                                        ps_channelcd IN VARCHAR2,
                                        ps_assignedby IN VARCHAR2,
                                        pn_passid IN VARCHAR2,
                                        ps_customerid IN VARCHAR2,
                                        ps_customername IN VARCHAR2,
                                        ps_control IN VARCHAR2,
                                        ps_superuser IN VARCHAR2,
                                        ps_ImzaAmnt IN VARCHAR2,
                                        ps_rnn IN VARCHAR2,
                                        ps_imzacy IN VARCHAR2,
                                        ps_create IN VARCHAR2,
                                        ps_activate IN VARCHAR2,
                                        ps_person IN VARCHAR2,
                                        ps_appupdlmt IN VARCHAR2,
                                        pd_enddate IN VARCHAR2,
                                        ps_printpassid IN VARCHAR2,
                                        ps_appupdsplmt IN VARCHAR2,
                                        ps_otpChoice  IN VARCHAR2) RETURN VARCHAR2 IS

  CURSOR cursor_customerid IS
    SELECT p.*
   FROM TBL_PERSON p,TBL_IDENTIFICATION i
   WHERE CUSTOMER_ID=ps_customerid
   AND i.PERSON_ID=p.PERSON_ID
   AND i.CHANNEL_CD=ps_channelcd;

  row_customerid   cursor_customerid%ROWTYPE;

  CURSOR cursor_alias(ps_alias VARCHAR2) IS
    SELECT *
   FROM TBL_IDENTIFICATION
   WHERE (username=ps_alias OR useralias=ps_alias);

  row_alias   cursor_alias%ROWTYPE;

  CURSOR cursor_passid IS
    SELECT *
   FROM TBL_DUMMY_PASSID
   WHERE PASSID=pn_passid AND STATUSCD='sNEW';

  row_passid   cursor_passid%ROWTYPE;

  ls_returncode      VARCHAR2(3):='000';
  TransactionError    EXCEPTION;
  ln_personid     NUMBER;
  ls_authcd      VARCHAR2(10);
  ls_digipass     VARCHAR2(22);
  ln_count     NUMBER;
  ls_channel_cd VARCHAR2(10) := ps_channelcd;
  ls_pwd_type      VARCHAR2 (15);
 BEGIN
    IF ps_otpChoice = 'Y'
    THEN
      ls_pwd_type := 'PWD_SMS';
    ELSE
      ls_pwd_type := 'PWD_PIN_ALWAYS';
    END IF;
 if ps_channelcd = 'cDKBRIBVW' or ps_channelcd = 'cDKBCIBVW' then
    ls_channel_cd := substr(ps_channelcd, 1, 7);
 end if;

 --get the passid info
    OPEN cursor_passid;
 FETCH cursor_passid INTO row_passid;
 IF  cursor_passid%NOTFOUND THEN
  ls_returncode:='019';--passid not found
  RAISE TransactionError;
 END IF;
 CLOSE cursor_passid;

  --check if the alias
 OPEN cursor_alias(row_passid.USERNAME);
 FETCH cursor_alias INTO row_alias;
 IF  cursor_alias%FOUND THEN
  ls_returncode:='020';--alias found
  RAISE TransactionError;
 END IF;
 CLOSE cursor_alias;

 IF ps_option='N' THEN
   --1) Get Person ID
   ln_personid:=Pkg_Common.GetSequenceID('pqPERSONID');

   --2) Insert Personal Info
   INSERT INTO TBL_PERSON
   (PERSON_ID, FIRSTNAME, BIRTH_DATE, SEX, EMAIL, CUSTOMER_ID, STATUS_CD,MOMMAIDENNAME)
   VALUES
   (ln_personid, ps_customername, SYSDATE, NULL, NULL, ps_customerid, 'sDISAB',ps_rnn);

   --3) Insert Identification Info
   INSERT INTO TBL_IDENTIFICATION
   (PERSON_ID, CHANNEL_CD, USERNAME, USERALIAS, PASSCODE, PINCODE, EXPIREDATE, STATUS_CD, PWDFORCECHANGE,END_DATE,PWD_TYPE)
   VALUES
   (ln_personid, ls_channel_cd,row_passid.USERNAME,NULL, row_passid.PASSCODE, row_passid.PINCODE, SYSDATE, 'sDISAB', 'E',TO_DATE(pd_enddate,'YYYYMMDD'),ls_pwd_type);

   --4) Insert Identification Info
   IF ps_channelcd = 'cDKBRIB'  THEN

   INSERT INTO TBL_LIMIT_DEFAULTS(TRAN_CD, CHANNEL_CD, DAILY_LIMIT, ONETIME_LIMIT, CURRENCY_CODE, PERSON_ID)
   SELECT t.TRAN_CD, 'cDKBRIB', t.DAILY_LIMIT, t.TRAN_LIMIT, t.CURRENCY_CD, ln_personid FROM TBL_RETAIL_LIMITS t;

        /*INSERT INTO TBL_LIMIT_DEFAULTS(TRAN_CD, CHANNEL_CD, DAILY_LIMIT, ONETIME_LIMIT, CURRENCY_CODE, PERSON_ID)
     VALUES('CLEARING','cDKBRIB','500000','500000','KGS',ln_personid);
        INSERT INTO TBL_LIMIT_DEFAULTS(TRAN_CD, CHANNEL_CD, DAILY_LIMIT, ONETIME_LIMIT, CURRENCY_CODE, PERSON_ID)
     VALUES('CLEARCNCL','cDKBRIB','500000','500000','KGS',ln_personid);
     INSERT INTO TBL_LIMIT_DEFAULTS(TRAN_CD, CHANNEL_CD, DAILY_LIMIT, ONETIME_LIMIT, CURRENCY_CODE, PERSON_ID)
     VALUES('B2OBHVL','cDKBRIB','500000','500000','KGS',ln_personid);
     INSERT INTO TBL_LIMIT_DEFAULTS(TRAN_CD, CHANNEL_CD, DAILY_LIMIT, ONETIME_LIMIT, CURRENCY_CODE, PERSON_ID)
     VALUES('EXCHNGBUY','cDKBRIB','100000','100000','KGS',ln_personid);
     INSERT INTO TBL_LIMIT_DEFAULTS(TRAN_CD, CHANNEL_CD, DAILY_LIMIT, ONETIME_LIMIT, CURRENCY_CODE, PERSON_ID)
     VALUES('EXCHNGSELL','cDKBRIB','100000','100000','KGS',ln_personid);*/

   ELSIF ps_channelcd = 'cDKBCIB'  THEN
    INSERT INTO TBL_COMPANY
    (CUSTOMER_NO, PERSON_ID, IMZA_SIRKULERI_IMZA_LIMIT, ISLEM_LIMIT,ISLEM_LIMIT_CY,IMZA_SIRKULERI_CY)
    VALUES (ps_customerid,ln_personid,TO_NUMBER(REPLACE(REPLACE(ps_ImzaAmnt,',',''),'.',',')),0,ps_imzacy,ps_imzacy);

    INSERT INTO TBL_SPEC_COMPANY
    (CUSTOMER_NO, PERSON_ID, IMZA_SIRKULERI_IMZA_LIMIT, ISLEM_LIMIT,ISLEM_LIMIT_CY,IMZA_SIRKULERI_CY)
    VALUES (ps_customerid,ln_personid,TO_NUMBER(REPLACE(REPLACE(ps_ImzaAmnt,',',''),'.',',')),0,ps_imzacy,ps_imzacy);

--210408----------------------------------
        select count(*) into ln_count from TBL_FXTRANSFER
    where CUSTOMER_ID=TO_NUMBER(ps_customerid);

    if (ln_count=0) then
        INSERT INTO TBL_FXTRANSFER(CUSTOMER_ID, FLAG, CREATE_DATE)
        VALUES(TO_NUMBER(ps_customerid),'Y',SYSDATE);
    end if;

    --INSERT INTO TBL_FXTRANSFER(CUSTOMER_ID, FLAG, CREATE_DATE)
--    VALUES(TO_NUMBER(ps_customerid),'Y',SYSDATE);
    --5) Assign Max. Limits
----------------------------------------------

    SELECT COUNT(*)
    INTO ln_count
    FROM TBL_APPROVAL_TRAN_MAX_LIMIT
    WHERE customer_no = ps_customerid
      AND channel_cd = ps_channelcd ;

    IF ln_count = 0 THEN
    INSERT INTO TBL_APPROVAL_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
    SELECT ps_customerid, t.TRAN_CD, t.DAILY_LIMIT, t.CURRENCY_CD, ps_channelcd
    FROM TBL_CORP_LIMITS t;

    INSERT INTO TBL_SPECAPP_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
    SELECT ps_customerid, t.TRAN_CD, t.DAILY_LIMIT, t.CURRENCY_CD, ps_channelcd
    FROM TBL_CORP_LIMITS t;
       /* INSERT INTO TBL_APPROVAL_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
      VALUES (ps_customerid,'CLEARING',0,'KGS',ps_channelcd);
        INSERT INTO TBL_APPROVAL_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
      VALUES (ps_customerid,'EXCHNGBUY',0,'KGS',ps_channelcd);
        INSERT INTO TBL_APPROVAL_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
      VALUES (ps_customerid,'EXCHNGSELL',0,'KGS',ps_channelcd);
        INSERT INTO TBL_APPROVAL_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
      VALUES (ps_customerid,'B2OBHVL',0,'KGS',ps_channelcd);
        INSERT INTO TBL_APPROVAL_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
      VALUES (ps_customerid,'B2BHVL',0,'KGS',ps_channelcd);
        INSERT INTO TBL_APPROVAL_TRAN_MAX_LIMIT
      (CUSTOMER_NO, TRAN_CD, MAX_DAILY_LIMIT, CURRENCY_CODE, CHANNEL_CD)
      VALUES (ps_customerid,'CLEARCNCL',0,'KGS',ps_channelcd);*/
     END IF;--count=0

   ELSIF ps_channelcd = 'cCORPADM'  THEN

    IF ps_superuser='Y' THEN
      INSERT INTO TBL_PERSON_AUTH
     (PERSON_ID, CHANNEL_CD, AUTH_CD)
     VALUES
     (ln_personid, ps_channelcd, 'aAUTHORITY');
    END IF;
    IF ps_create='Y' THEN
      INSERT INTO TBL_PERSON_AUTH
     (PERSON_ID, CHANNEL_CD, AUTH_CD)
     VALUES
     (ln_personid, ps_channelcd, 'aADMUSRCRT');
    END IF;
    IF ps_activate='Y' THEN
      INSERT INTO TBL_PERSON_AUTH
     (PERSON_ID, CHANNEL_CD, AUTH_CD)
     VALUES
     (ln_personid, ps_channelcd, 'aADMUSRACT');
    END IF;

    IF ps_control='Y' THEN
      INSERT INTO TBL_PERSON_AUTH
     (PERSON_ID, CHANNEL_CD, AUTH_CD)
     VALUES
     (ln_personid, ps_channelcd, 'aADMCCONT');
    END IF;

    IF ps_appupdlmt='Y' THEN
    INSERT INTO TBL_PERSON_AUTH
    (PERSON_ID, CHANNEL_CD, AUTH_CD)
    VALUES
    (ln_personid, ps_channelcd, 'aAPPLMT');
    END IF;

    IF ps_appupdsplmt='Y' THEN
    INSERT INTO TBL_PERSON_AUTH
    (PERSON_ID, CHANNEL_CD, AUTH_CD)
    VALUES
    (ln_personid, ps_channelcd, 'aAPPSPLMT');
    END IF;

    IF ps_printpassid='Y' THEN
    INSERT INTO TBL_PERSON_AUTH
    (PERSON_ID, CHANNEL_CD, AUTH_CD)
    VALUES
    (ln_personid, ps_channelcd, 'aPRTPASSID');
    END IF;
   END IF;--channelcd

   --give auth to person
   IF ps_channelcd='cDKBCIB' THEN
    ls_authcd:='aDKBCIB';--Corporate
   ELSIF ps_channelcd='cDKBVIEW' THEN
    ls_authcd:='aDKBVIEW';--Corporate View
   ELSIF ps_channelcd='cDKBRIBVW' THEN
    ls_authcd:='aDKBVIEW';--Corporate View Only
   ELSIF ps_channelcd='cDKBCIBVW' THEN
    ls_authcd:='aDKBVIEW';--Retail View Only
   ELSIF ps_channelcd='cDKBRIB' THEN
    ls_authcd:='aDKBRIB';--Retail
   ELSIF ps_channelcd='cCORPADM' THEN
    ls_authcd:='aCORPADM';--Administration
   ELSIF ps_channelcd='cEMBASSY' THEN
    ls_authcd:='aEMBASSY';--Embassy
   END IF;

   INSERT INTO TBL_PERSON_AUTH
   (PERSON_ID, CHANNEL_CD, AUTH_CD)
   VALUES
   (ln_personid, ls_channel_cd, ls_authcd);
  
   IF ps_channelcd='cDKBRIB' THEN
   	INSERT INTO TBL_PERSON_AUTH
   (PERSON_ID, CHANNEL_CD, AUTH_CD)
   VALUES
   (ln_personid, ls_channel_cd, 'aDKBRIBSWF');
   END IF;

 ELSIF ps_option='U' THEN--update
    UPDATE TBL_IDENTIFICATION
    SET USERNAME=row_passid.USERNAME,
       PASSCODE=row_passid.PASSCODE,
     PINCODE=row_passid.PINCODE,
     EXPIREDATE=SYSDATE,
     STATUS_CD='sDISAB'
    WHERE PERSON_ID=ps_person;
 END IF;

  --4 update the assigner of the passid
  UPDATE TBL_DUMMY_PASSID
  SET STATUSCD='sASSIGN',
    ASSIGNEDBY=ps_assignedby,
    ASSIGNEDTO=ps_customerid,
   ASSIGNDATE=SYSDATE
 WHERE PASSID=pn_passid;

  --Update View Only User for Corporate Channel
  IF ps_channelcd='cDKBVIEW' or ps_channelcd='cDKBRIBVW' or ps_channelcd='cDKBCIBVW' THEN

      BEGIN
        if ps_channelcd='cDKBRIBVW' then
            update corpint.tbl_identification set CHANNEL_CD='cDKBRIB' where PERSON_ID = ln_personid;
            update corpint.tbl_approval_tran_max_limit set CHANNEL_CD='cDKBRIB' where CUSTOMER_NO = ps_customerid;
            update corpint.tbl_specapp_tran_max_limit set CHANNEL_CD='cDKBRIB' where CUSTOMER_NO = ps_customerid;
            update corpint.tbl_person_auth set CHANNEL_CD='cDKBRIB' where PERSON_ID = ln_personid;
        else
            update corpint.tbl_identification set CHANNEL_CD='cDKBCIB' where PERSON_ID = ln_personid;
            update corpint.tbl_approval_tran_max_limit set CHANNEL_CD='cDKBCIB' where CUSTOMER_NO = ps_customerid;
            update corpint.tbl_specapp_tran_max_limit set CHANNEL_CD='cDKBCIB' where CUSTOMER_NO = ps_customerid;
            update corpint.tbl_person_auth set CHANNEL_CD='cDKBCIB' where PERSON_ID = ln_personid;
        end if;

      Exception
        when others then
            Null;
      END;
  END IF;

     RETURN ls_returncode;

EXCEPTION
  WHEN TransactionError THEN
    RETURN ls_returncode;
END;
-------------------------------------------------------------------
FUNCTION CheckToken(ps_channelcd IN VARCHAR2,
      pn_sessionid IN NUMBER,
      ps_ticketid IN VARCHAR2,
      ps_tokenid IN VARCHAR2) RETURN VARCHAR2 IS

         ls_returncode      VARCHAR2(3):='000';

    CURSOR cursor_identity IS
      SELECT * FROM TBL_IDENTIFICATION i
   WHERE i.TOKEN_ID =ps_tokenid;

   row_identity   cursor_identity%ROWTYPE;
   ln_personid   NUMBER:=0;
   ps_personid   VARCHAR2(20) := '';

   TokenIdError    EXCEPTION;

BEGIN

        OPEN cursor_identity;
  FETCH cursor_identity INTO row_identity;

  IF  cursor_identity%NOTFOUND THEN
  ls_returncode:='012';-- buraya ne yaz?lacak
  RAISE TokenIdError;
  END IF;




RETURN ls_returncode;
EXCEPTION
  WHEN TokenIdError THEN
    RETURN ls_returncode;
END;
-------------------------------------------------------------------
FUNCTION UploadTokenData(ps_DIGIPASS IN VARCHAR2,
                         ps_ALGO_TYPE IN VARCHAR2,
       ps_DP_TYPE IN VARCHAR2,
       ps_DP_DATA IN VARCHAR2,
       ps_OTP_VALIDATION_PERIOD IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

  ls_returncode      VARCHAR2(3):='000';
BEGIN

 OPEN pc_ref FOR
        SELECT ps_DIGIPASS FROM dual;

 INSERT INTO TBL_TOKEN
 (DIGIPASS, DP_TYPE, ALGO_TYPE, DP_DATA,TOKEN_STATUS,OTP_VALIDITY_PERIOD)
 VALUES
 (ps_DIGIPASS,ps_DP_TYPE,ps_ALGO_TYPE,ps_DP_DATA,'sNEW',ps_OTP_VALIDATION_PERIOD);

  RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
     RETURN '111';
 END;
--------------------------------------------------------------------------
 FUNCTION GetTokenData(ps_DIGIPASS IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

                        ls_digidata VARCHAR2(255);
         ls_digipass VARCHAR2(22);
      otp_validity_period NUMBER;
      ls_returncode   VARCHAR2(3):='000';
      TransactionError EXCEPTION;
BEGIN

  SELECT DP_DATA,DIGIPASS,OTP_VALIDITY_PERIOD
  INTO ls_digidata,ls_digipass,otp_validity_period
  FROM TBL_TOKEN
  WHERE INSTR(DIGIPASS,ps_DIGIPASS)>0;

        OPEN pc_ref FOR
  SELECT ls_digidata,ls_digipass,otp_validity_period FROM dual;

  RETURN ls_returncode;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  ls_returncode:='112';--token no found

  OPEN pc_ref FOR
  SELECT ls_digidata,ls_digipass FROM dual;

  RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------
FUNCTION GetTokenSerial(ps_person_id IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

  ls_returncode VARCHAR2(3):='000';
  noSerialFound   EXCEPTION;
  ln_count NUMBER;
BEGIN

 --OPEN pc_ref FOR select '-' from dual;

 SELECT COUNT(TOKEN_ID)
 INTO ln_count
 FROM TBL_IDENTIFICATION
 WHERE PERSON_ID=TO_NUMBER(ps_person_id);

 IF ln_count=0 THEN
    RAISE noSerialFound;
 END IF;

 OPEN pc_ref FOR
   SELECT TOKEN_ID FROM TBL_IDENTIFICATION
     WHERE PERSON_ID=TO_NUMBER(ps_person_id);

  RETURN ls_returncode;

 EXCEPTION

  WHEN noSerialFound THEN
  OPEN pc_ref FOR SELECT '-' FROM dual;
     ls_returncode:= '122';
    RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------------
FUNCTION SetTokenData(ps_DIGIPASS IN VARCHAR2,
        ps_DIGIDATA IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

ls_digipass VARCHAR2(22);
TransactionError EXCEPTION;
ls_returncode   VARCHAR2(3):='000';

 BEGIN
      SELECT DIGIPASS
  INTO ls_digipass
  FROM TBL_TOKEN
  WHERE INSTR(DIGIPASS,ps_DIGIPASS)>0;


      UPDATE TBL_TOKEN
   SET DP_DATA=ps_DIGIDATA
   WHERE RTRIM(DIGIPASS)=RTRIM(ls_digipass);

   OPEN pc_ref FOR
   SELECT ls_digipass FROM dual;

   RETURN ls_returncode;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  ls_returncode:='112';--token no found
  RETURN ls_returncode;

 END;
--------------------------------------------------------------------
FUNCTION GetCustomerTokenData(ps_sessionID IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

                        ls_digidata VARCHAR2(255);
         ls_digipass VARCHAR2(22);
      otp_validity_period NUMBER;
      ls_returncode   VARCHAR2(3):='000';
      ls_tokenid VARCHAR2(22);
      TransactionError EXCEPTION;
      ln_personid   NUMBER;
BEGIN

  SELECT PERSON_ID
  INTO ln_personid
  FROM TBL_SESSION
  WHERE SESSION_ID=TO_NUMBER(ps_sessionID);

  SELECT TOKEN_ID INTO ls_tokenid
  FROM TBL_IDENTIFICATION
  WHERE person_id=ln_personid;

  SELECT DP_DATA,DIGIPASS,OTP_VALIDITY_PERIOD
  INTO ls_digidata,ls_digipass,otp_validity_period
  FROM TBL_TOKEN
  WHERE RTRIM(DIGIPASS)=RTRIM(ls_tokenid);

        OPEN pc_ref FOR
  SELECT ls_digidata,ls_digipass,otp_validity_period,ln_personid FROM dual;

  RETURN ls_returncode;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  ls_returncode:='112';--token no found

  OPEN pc_ref FOR
  SELECT ls_digidata,ls_digipass FROM dual;

  RETURN ls_returncode;
END;

------------------------------------------------------------------------------------------
FUNCTION SetSessionStatus(ps_sessionID IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
TransactionError EXCEPTION;
ls_returncode   VARCHAR2(3):='000';

 BEGIN
      OPEN pc_ref FOR
   SELECT 'lala' FROM dual;

   UPDATE TBL_SESSION
   SET STATUS_CD='sACTIVE'
   WHERE SESSION_ID=TO_NUMBER(ps_sessionID);

   RETURN ls_returncode;
 EXCEPTION
  WHEN OTHERS THEN
  ls_returncode:='126';--update edilemedi
  RETURN ls_returncode;

 END;
--------------------------------------------------------------------
FUNCTION SetNewPassword(ps_password IN VARCHAR2,
       pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
 ls_returncode   VARCHAR2(3):='000';
 ps_username        VARCHAR2(10):='corpint';
 BEGIN
     OPEN pc_ref FOR
  SELECT 'lala' FROM dual;


   EXECUTE IMMEDIATE 'ALTER USER ' || ps_username || ' IDENTIFIED BY ' ||  ps_password ;

   RETURN ls_returncode;
 EXCEPTION
  WHEN OTHERS THEN
  ls_returncode:='999';
  RETURN ls_returncode;

 END;
--------------------------------------------------------------------
FUNCTION GetLastSessionInfo(pn_personid IN VARCHAR2,
                            pn_customerid IN VARCHAR2,
       ps_channelcd IN VARCHAR2,
       ps_langid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 CURSOR cursor_session IS
  SELECT * FROM TBL_SESSION
  WHERE person_id=pn_personid
  AND status_cd='sCLOSED'
  ORDER BY session_id DESC;

 row_session cursor_session%ROWTYPE;
 ls_returncode VARCHAR2(3):='000';
 ls_sessionid NUMBER:= 0;
BEGIN
   OPEN cursor_session;
  FETCH cursor_session INTO row_session;
  IF  cursor_session%FOUND THEN
    ls_sessionid:=row_session.SESSION_ID;
  ELSE
    ls_sessionid:='0';
  END IF;
  CLOSE cursor_session;

    OPEN pc_ref FOR
 SELECT Pkg_Customer.GetCustomerID(a.PERSON_ID) PERSONID,
 a.SESSION_ID,
 DECODE(a.FIELD15,'1','<b>?leri Tarihli EFT</b>',NVL(t.DEFINITION,' ')),
 -- burada bir i?lem ileri tarihli eft ise bunu eft yaparken
 -- field15 nolu alana 1 girerek belirtmi?tim
 -- e?er eft ileri tarihli ise bu alana bak?yorum ve ekranda g?steriyorum
 a.PAGE_ID,
 a.SYSTEM_CD,
 a.ERROR_CD,
 a.ERROR_TYPE,
 e.USER_DESC, --ieri tarihli eft ise bunu belirt de?il ise aynen koy
 a.ACTV_TIME,
 NVL(a.AMOUNT,0),
 NVL(a.CURRENCY,'-')
 FROM TBL_ACTIVITY a,TBL_ERROR e,TBL_TRANSACTION t
 WHERE a.SYSTEM_CD=e.SYSTEM_CD
 AND a.ERROR_CD=e.ERROR_CD
 AND a.CHANNEL_CD=ps_channelcd
 AND a.TRAN_CD=t.TRAN_CD
 AND e.LANG_CD= ps_langid
 AND t.LANGUAGE_CD= ps_langid
 AND a.PERSON_ID=TO_NUMBER(pn_personid)
 AND a.SESSION_ID= ls_sessionid
 AND a.PAGE_ID=0  -- biten i?lemler
 AND a.ERROR_CD='000'
 ORDER BY a.ACTV_TIME;
  RETURN '000';
END;
-----------------------------------------------------------------
FUNCTION GetTodayProcessInfo(pn_personid IN VARCHAR2,
                            pn_customerid IN VARCHAR2,
       ps_channelcd IN VARCHAR2,
       ps_bankdate IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';

BEGIN

    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

  OPEN pc_ref FOR
  SELECT Pkg_Customer.GetCustomerID(a.PERSON_ID) PERSONID,
  a.SESSION_ID,
     DECODE(a.FIELD15,'1','<b>?leri Tarihli EFT</b>',NVL(t.DEFINITION,' ')),
  -- burada bir i?lem ileri tarihli eft ise bunu eft yaparken
  -- field15 nolu alana 1 girerek belirtmi?tim
  -- e?er eft ileri tarihli ise bu alana bak?yorum ve ekranda g?steriyorum
  a.PAGE_ID,
  a.SYSTEM_CD,
  a.ERROR_CD,
  a.ERROR_TYPE,
  e.USER_DESC,
  TO_CHAR(a.ACTV_TIME,'HH24:MI:SS'),
  NVL(a.AMOUNT,0),NVL(a.CURRENCY,'-')

  FROM TBL_ACTIVITY a,TBL_ERROR e,TBL_TRANSACTION t,TBL_SESSION s
  WHERE a.SYSTEM_CD=e.SYSTEM_CD
  AND a.ERROR_CD=e.ERROR_CD
  AND a.CHANNEL_CD=ps_channelcd
  AND a.TRAN_CD=t.TRAN_CD
  AND e.LANG_CD='ENG'
  AND t.LANGUAGE_CD='ENG'
  AND a.PERSON_ID=TO_NUMBER(pn_personid)
  AND s.PERSON_ID=a.PERSON_ID
  AND s.SESSION_ID=a.SESSION_ID
  AND s.CHANNEL_CD=a.CHANNEL_CD
  AND TRUNC(a.ACTV_TIME) = TRUNC(SYSDATE)
  AND a.PAGE_ID=0  -- biten i?lemler
  AND a.ERROR_CD='000'
  ORDER BY a.ACTV_TIME DESC;

  RETURN '000';
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  ls_returncode:='277';
  RETURN ls_returncode;
END;
-----------------------------------------------------------------------
FUNCTION ChangePrl(ps_channelcd IN VARCHAR2,
                   ps_personid IN VARCHAR2,
       ps_oldparola IN VARCHAR2,
       ps_newparola IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
       ls_returncode   VARCHAR2(3):='000';
       ls_count NUMBER:=0;
       ls_countislocked NUMBER:=0;
 BEGIN
   OPEN pc_ref FOR
   SELECT 'lala' FROM dual;

  SELECT COUNT(*)
  INTO ls_countislocked
  FROM TBL_PAROLA P
  WHERE P.PERSONID=ps_personid
  AND p.CHANNELCD=ps_channelcd
  AND p.STATUS='sLOCKED';

  IF (ls_countislocked > 0) THEN
     RETURN '634'; -- kilitli parola
  END IF;

  SELECT COUNT(*)
  INTO ls_count
  FROM TBL_PAROLA P
  WHERE P.PERSONID=ps_personid
  AND p.CHANNELCD=ps_channelcd
  AND p.PAROLA=ps_oldparola
  AND p.STATUS='sACTIVE';

  IF (ls_count = 0) THEN
     RETURN '631'; -- yanl?? parola
  ELSE

  UPDATE TBL_PAROLA P
  SET p.PAROLA=ps_newparola
  WHERE P.PERSONID=ps_personid
  AND p.CHANNELCD=ps_channelcd
  AND p.PAROLA=ps_oldparola
  AND p.STATUS='sACTIVE';
  END IF;

   RETURN ls_returncode;
 EXCEPTION
  WHEN OTHERS THEN
  ls_returncode:='999';
  RETURN ls_returncode;

 END;
----------------------------------------------------------------
FUNCTION VerifyParola(ps_parola IN VARCHAR2,
                   ps_personid IN VARCHAR2,
                   ps_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
       ls_returncode   VARCHAR2(3):='000';
       ls_count NUMBER:=0;
       ls_countislocked NUMBER:=0;
       ls_attemptcount NUMBER:=0;

 BEGIN
   OPEN pc_ref FOR
   SELECT 'lala' FROM dual;

       SELECT COUNT(*)
    INTO ls_countislocked
       FROM TBL_PAROLA P
    WHERE P.PERSONID=ps_personid
    AND p.CHANNELCD=ps_channelcd
    AND p.STATUS='sLOCKED';

        IF (ls_countislocked > 0) THEN
     RETURN '634'; -- kilitli parola
    END IF;

       SELECT COUNT(*)
    INTO ls_count
       FROM TBL_PAROLA P
    WHERE P.PERSONID=ps_personid
    AND p.CHANNELCD=ps_channelcd
    AND p.PAROLA=ps_parola
    AND p.STATUS='sACTIVE';

          IF (ls_count = 0) THEN

         SELECT P.ATTEMPTCOUNT
    INTO ls_attemptcount
       FROM TBL_PAROLA P
    WHERE P.PERSONID=ps_personid
    AND p.CHANNELCD=ps_channelcd;

     IF (ls_attemptcount < 4) THEN
         UPDATE  TBL_PAROLA P
      SET P.ATTEMPTCOUNT = P.ATTEMPTCOUNT +1
               WHERE P.PERSONID=ps_personid
      AND p.CHANNELCD=ps_channelcd;
     RETURN '631'; -- yanl?? parola
     ELSE
         UPDATE  TBL_PAROLA P
      SET P.ATTEMPTCOUNT = P.ATTEMPTCOUNT +1,
          P.STATUS = 'sLOCKED'
               WHERE P.PERSONID=ps_personid
      AND p.CHANNELCD=ps_channelcd;
      RETURN '633';-- kilitledik arkada?
     END IF;

          ELSE
        UPDATE  TBL_PAROLA P
     SET P.ATTEMPTCOUNT = 0
              WHERE P.PERSONID=ps_personid
     AND p.CHANNELCD=ps_channelcd;
    END IF;

   RETURN ls_returncode;
 EXCEPTION
  WHEN OTHERS THEN
  ls_returncode:='999';
  RETURN ls_returncode;
 END;

-------------------------------------------------------------------------
FUNCTION CheckParola( ps_channelcd IN VARCHAR2,
                      ps_sessionid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
       ls_returncode   VARCHAR2(3):='000';
       ls_count NUMBER:=0;
       ps_personid NUMBER:=0;

 BEGIN
   OPEN PC_REF FOR
   SELECT 'lala' FROM DUAL;

  SELECT S.PERSON_ID
  INTO ps_personid
  FROM TBL_SESSION S
  WHERE S.SESSION_ID=PS_SESSIONID;

  SELECT COUNT(*)
  INTO ls_count
  FROM TBL_PAROLA P
  WHERE P.PERSONID=ps_personid
  AND p.CHANNELCD=ps_channelcd;

  IF (ls_count = 0) THEN
  RETURN '111'; -- parola yok
  END IF;

   RETURN ls_returncode;
 EXCEPTION
  WHEN OTHERS THEN
  ls_returncode:='999';
  RETURN ls_returncode;
 END;
------------------------------------------------------------------------
FUNCTION SetCustomerParola(
                      ps_sessionid IN VARCHAR2,
                      ps_channelcd IN VARCHAR2,
                      ps_parola IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
             ls_returncode   VARCHAR2(3):='000';
       ps_personid VARCHAR2(3):='000';
 BEGIN
   OPEN pc_ref FOR
   SELECT 'lala' FROM dual;

   SELECT S.PERSON_ID
   INTO ps_personid
   FROM TBL_SESSION S
   WHERE S.SESSION_ID=ps_sessionid;

   INSERT INTO TBL_PAROLA(PERSONID, PAROLA, STATUS, ATTEMPTCOUNT, CHANNELCD)
   VALUES(ps_personid,ps_parola,'sACTIVE',0,ps_channelcd);

   RETURN ls_returncode;
 EXCEPTION
  WHEN OTHERS THEN
  ls_returncode:='999';
  RETURN ls_returncode;
 END;
------------------------------------------------------------------
   FUNCTION ClearingToDo (
                    p_from_acc                VARCHAR2,
                    ps_payee_info              VARCHAR2,
                    pd_trandate                VARCHAR2,
                    ps_sender_name             VARCHAR2,
                    ps_sender_phone            VARCHAR2,
                    ps_bank_code               VARCHAR2,
                    ps_payee_name              VARCHAR2,
                    ps_to_account              VARCHAR2,
                    pn_amount                  VARCHAR2,
                    ps_description             VARCHAR2,
                    ps_save_payee_flag         VARCHAR2,
                    ps_payee_nick              VARCHAR2,
                    pn_paycode                 VARCHAR2,
                    ps_status                  VARCHAR2,
                    pn_person                  VARCHAR2,
                    ps_subaccount                 VARCHAR2,
                    ps_subname                 VARCHAR2,
                    ps_payforservice             VARCHAR2,
                    ps_commision              VARCHAR2,
                    ps_transfer_option          VARCHAR2, --ernestk 14022014 cqdb00000504 gross or clearing payment
                    ps_order_number             VARCHAR2 DEFAULT '', --ernestk 12062014 cqdb864 add order number
                    pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2
   IS

 ln_txid NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
 ls_paycode VARCHAR2(500);

 ls_status VARCHAR (10); --ernestk 14022014 cqdb00000504 status to save the payment with

 TimeException    EXCEPTION;
BEGIN

    /*
    --ernestk 14022014 cqdb00000504 remove time check, time is checked before call
    ls_returncode:=cbs.pkg_int_limit.CheckTimeLimit(ps_transfer_option);
 IF ls_returncode<>'000' AND pd_trandate=TO_CHAR(SYSDATE,'YYYYMMDD') THEN
    RAISE TimeException;
 ELSE
    ls_returncode:='000';
 END IF;
    */

 OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  IF LENGTH(pn_paycode)=3 THEN
    ls_paycode:=pn_paycode||';'||cbs.pkg_int_tx.istatistik_adi_al(pn_paycode);
  ELSE
    ls_paycode:=pn_paycode;
  END IF;
  --B-O-M ernestk 14022014 cqdb00000504 in which status to save the payment with
  select DECODE(ps_status,'sVERIFY','aVRFYEFT','sCHECK','aCHCKEFT','sAPPROVE','aAPPREFT') into ls_status from dual;

  IF ps_transfer_option = 'GROSS' THEN
    select DECODE(ps_status,'sVERIFY','aVRFYGRS','sCHECK','aCHCKGRS','sAPPROVE','aAPPRGRS') into ls_status from dual;
  END IF;
  --E-O-M ernestk 14022014 cqdb00000504 in which status to save the payment with
log_at('tx-todo', 1,ln_txid );
  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
   FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
   FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
   FIELD11,FIELD12,field14, field15,
   AUTHCD,FIELD17,FIELD18, FIELD19,FIELD20)  /* FIELD 19 IS FOR COMM */ --ernestk 12062014 cqdb864 write order number to field18

   VALUES
   (ln_txid,decode(ps_transfer_option,'GROSS', 'GROSS', 'CLEARING'),pn_person,SYSDATE,ps_status,
   p_from_acc,ps_payee_info,pd_trandate,ps_sender_name,ps_sender_phone,
   ps_bank_code,ps_payee_name,ps_to_account,pn_amount,ps_description||' '||ps_payforservice,
   ps_save_payee_flag,ps_payee_nick, ps_subaccount, ps_subname,
   ls_status,--ernestk 14022014 cqdb00000504 status of the todo payment
   ls_paycode,ps_order_number, ps_commision,'KGS');--ernestk 12062014 cqdb864 add order number

   OPEN pc_ref FOR select ln_txid from dual;--ernestk cqdb00000824 return transaction no of transfer  --ernestk 14022014 cqdb00000504 return transaction no with which payment was saved


   RETURN ls_returncode;

EXCEPTION
    WHEN TimeException THEN
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
        --B-O-M ernestk 14022014 cqdb00000504 time exception status for gross
        IF ps_transfer_option = 'GROSS' THEN
            ls_returncode := '059';
        END IF;
        --E-O-M ernestk 14022014 cqdb00000504 time exception status for gross
        RETURN ls_returncode;

 WHEN OTHERS THEN
    pkg_log.addcustomlog('clearingtodo', sqlerrm);
    RETURN '708';
END;
------------------
FUNCTION FXBuySellToDo (
    ps_trantype IN VARCHAR2,
    pn_BORC_HESAP_NO IN VARCHAR2,
    ps_DOVIZ_KODU IN VARCHAR2,
    pn_KUR IN VARCHAR2,
    pn_TUTAR IN VARCHAR2,
    pn_ALACAK_HESAP_NO IN VARCHAR2,
    ps_ISTATISTIK_KODU IN VARCHAR2,
    ps_ACIKLAMA IN VARCHAR2,
    pn_REZERVASYON_NO IN VARCHAR2,
    ps_MASRAF IN VARCHAR2,
    ps_TAHSIL_ADILEN_TOPLAM_TUTAR IN VARCHAR2,
       ps_status                  VARCHAR2,
       pn_person                  VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ln_txid NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
BEGIN
  OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

 IF ps_trantype = 'A' THEN

   INSERT INTO TBL_TXTODO
   (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
    FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
    FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
    FIELD11,FIELD20,AUTHCD)
    VALUES
    (ln_txid,'EXCHNGBUY',pn_person,SYSDATE,ps_status,
    ps_trantype,pn_BORC_HESAP_NO,ps_DOVIZ_KODU,pn_REZERVASYON_NO,pn_KUR,
    pn_ALACAK_HESAP_NO,ps_ISTATISTIK_KODU,ps_ACIKLAMA,pn_TUTAR,ps_MASRAF,
    ps_TAHSIL_ADILEN_TOPLAM_TUTAR,ps_DOVIZ_KODU,DECODE(ps_status,'sVERIFY','aVRFYBFX','sCHECK','aCHCKBFX','sAPPROVE','aAPPRBFX'));

  ELSIF ps_trantype = 'S' THEN

   INSERT INTO TBL_TXTODO
   (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
    FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
    FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
    FIELD11,FIELD20,AUTHCD)
    VALUES
    (ln_txid,'EXCHNGSELL',pn_person,SYSDATE,ps_status,
    ps_trantype,pn_BORC_HESAP_NO,ps_DOVIZ_KODU,pn_REZERVASYON_NO,pn_KUR,
    pn_ALACAK_HESAP_NO,ps_ISTATISTIK_KODU,ps_ACIKLAMA,pn_TUTAR,ps_MASRAF,
    ps_TAHSIL_ADILEN_TOPLAM_TUTAR,ps_DOVIZ_KODU,DECODE(ps_status,'sVERIFY','aVRFYSFX','sCHECK','aCHCKSFX','sAPPROVE','aAPPRSFX'));

  END IF;

   RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS THEN
 RETURN '710';
END;
---------------------------------------------------------------------------------------------
FUNCTION UpdateCustomerInfoToDo (
    ps_custno IN VARCHAR2,
    ps_adres IN VARCHAR2,
    ps_zipcode IN VARCHAR2,
    ps_mphone1 IN VARCHAR2,
    ps_mphone2 IN VARCHAR2,
    ps_hphone1 IN VARCHAR2,
    ps_hphone2 IN VARCHAR2,
    ps_email IN VARCHAR2,
    ps_country IN VARCHAR2,
       ps_status                  VARCHAR2,
       ps_person                  VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ln_txid NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
BEGIN
 OPEN pc_ref FOR
 SELECT SYSDATE
 FROM DUAL;
  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
   FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
   FIELD6,FIELD7,FIELD8,FIELD9,AUTHCD)
   VALUES
   (ln_txid,'CUSTUPDATE',ps_person,TRUNC(SYSDATE),ps_status,
   ps_custno,ps_adres,ps_zipcode,ps_mphone1,ps_mphone2,
   ps_hphone1,ps_hphone2,ps_email,ps_country,DECODE(ps_status,'sVERIFY','aVRFYUPDC','sCHECK','aCHCKUPDC','sAPPROVE','aAPPRUPDC'));
   RETURN ls_returncode;
EXCEPTION
 WHEN OTHERS THEN
 RETURN '710';
END;
------------------
FUNCTION SetVerifyMaker(ps_txNo IN VARCHAR2,
      ps_personno IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 UPDATE TBL_TXTODO T
 SET T.VERIFYID = TO_NUMBER(ps_personno),
  t.VERIFYDATE = SYSDATE,
  T.STATUS='sDONE'
 WHERE t.TX_NO = TO_NUMBER(ps_txNo);

 ls_returncode :=Pkg_Admin.GetVerifyApproveTranInfo(ps_txNo,pc_ref);

 RETURN ls_returncode;

  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
-------------------------------------------------------------
FUNCTION SetCheckMaker(ps_txNo IN VARCHAR2,
      ps_personno IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 UPDATE TBL_TXTODO T
 SET T.CHECKID = TO_NUMBER(ps_personno),
  t.CHECKDATE = SYSDATE,
  T.STATUS='sDONE'
 WHERE t.TX_NO=TO_NUMBER(ps_txNo);

 ls_returncode :=Pkg_Admin.GetVerifyApproveTranInfo(ps_txNo,pc_ref);

 RETURN ls_returncode;

  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
-------------------------------------------------------------
FUNCTION SetApproveMaker(ps_txNo IN VARCHAR2,
      ps_personno IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 UPDATE TBL_TXTODO T
 SET T.APPROVALID = TO_NUMBER(ps_personno),
  t.APPROVALDATE = SYSDATE,
  T.STATUS='sDONE'
 WHERE t.TX_NO = TO_NUMBER(ps_txNo);

 ls_returncode :=Pkg_Admin.GetVerifyApproveTranInfo(ps_txNo,pc_ref);

 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
-------------------------------------------------------------
FUNCTION SetVerifyUpdateFlag(ps_txNo IN VARCHAR2,
                        ps_customerid IN VARCHAR2,
      ps_verifiedapprovedid IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
   ls_status VARCHAR2(30):='';
   ls_verify VARCHAR2(20):='Y';
   ls_check VARCHAR2(20):='Y';
   ls_approve VARCHAR2(20):='Y';
   ls_authcd VARCHAR2(20):='';
   ls_approvestr VARCHAR2(20):='';
   ls_fromirsseco VARCHAR2(500); --chyngyzo cq509 13/03/2015 changed string length from 20 to 500
   ls_toirsseco VARCHAR2(500); --chyngyzo cq509 13/03/2015 changed string length from 10 to 500
   ls_trancd VARCHAR2(10);
   ls_tmpret VARCHAR2(3);
   ls_content      VARCHAR2(500);
   ls_control VARCHAR2(1):='N';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

    SELECT d.STATUS,t.VERIFY,t.CHECKER,t.APPROVE,d.FIELD13,d.FIELD16,d.TRANCD
 INTO ls_status,ls_verify,ls_check,ls_approve,ls_fromirsseco,ls_toirsseco,ls_trancd
 FROM TBL_APPROVAL_TRAN T,TBL_TXTODO D
 WHERE d.TX_NO = TO_NUMBER(ps_txNo)
   AND d.TRANCD = t.TRAN_CD
   AND t.CUSTOMER_ID = ps_customerid;

 IF (ls_status = 'sVERIFY') THEN
   IF ls_check = 'Y' THEN
   SELECT d.AUTHCD
   INTO ls_authcd
   FROM TBL_TXTODO D
   WHERE D.TX_NO = TO_NUMBER(ps_txNo);

   IF (ls_authcd = 'aVRFYBFX') THEN ls_approvestr := 'aCHCKBFX';
   ELSIF (ls_authcd = 'aVRFYEFT') THEN ls_approvestr := 'aCHCKEFT';
   ELSIF (ls_authcd = 'aVRFYSFX') THEN ls_approvestr := 'aCHCKSFX';
   ELSIF (ls_authcd = 'aVRFYUPDC') THEN ls_approvestr := 'aCHCKUPDC';
   ELSIF (ls_authcd = 'aVRFYTOY') THEN ls_approvestr := 'aCHCKTOY';
   ELSIF (ls_authcd = 'aVRFYTMY') THEN ls_approvestr := 'aCHCKTMY';
   ELSIF (ls_authcd = 'aVRFYUTIL') THEN ls_approvestr := 'aCHCKUTIL';
   ELSIF (ls_authcd = 'aVRFYCNCL') THEN ls_approvestr := 'aCHCKCNCL';
   ELSIF (ls_authcd = 'aVRFYPENS') THEN ls_approvestr := 'aCHCKPENS';
   ELSIF (ls_authcd = 'aVRFYCPYM') THEN ls_approvestr := 'aCHCKCPYM';
   ELSIF (ls_authcd = 'aVRFYSAL') THEN ls_approvestr := 'aCHCKSAL';
   ELSIF (ls_authcd = 'aVRFYSWIFT') THEN ls_approvestr := 'aCHCKSWIFT';
   ELSIF (ls_authcd = 'aVRFYRDEM') THEN ls_approvestr := 'aCHCKRDEM';
   ELSIF (ls_authcd = 'aVRFYTRPYM') THEN ls_approvestr := 'aCHCKTRPYM';
   ELSIF (ls_authcd = 'aVRFYPORD') THEN ls_approvestr := 'aCHCKPORD';
   ELSIF (ls_authcd = 'aVRFYPCNCL') THEN ls_approvestr := 'aCHCKPCNCL';
   ELSIF (ls_authcd = 'aVRFYSALTB') THEN ls_approvestr := 'aCHCKSALTB';
   ELSIF (ls_authcd = 'aVRFYFXORD') THEN ls_approvestr := 'aCHCKFXORD';
   ELSIF (ls_authcd = 'aVRFYFXCL') THEN ls_approvestr := 'aCHCKFXCL';
   ELSIF (ls_authcd = 'aVRFYARBIT') THEN ls_approvestr := 'aCHCKARBIT';
   ELSIF (ls_authcd = 'aVRFYP2OC') THEN ls_approvestr := 'aCHCKP2OC';
   ELSIF (ls_authcd = 'aVRFYDDS') THEN ls_approvestr := 'aCHCKDDS';
   ELSIF (ls_authcd = 'aVRFYGRS') THEN ls_approvestr := 'aCHCKGRS';--ernestk 14022014 cqdb00000504 to include gross verify
   ELSIF (ls_authcd = 'aVRFYCDP') THEN ls_approvestr := 'aCHCKCDP';--ernestk 24032014 cqdb00000862 to include CARDDEBT verify
   ELSIF (ls_authcd = 'aVRFYPYM') THEN ls_approvestr := 'aCHCKPYM';
   ELSIF (ls_authcd = 'aVRFYSLRY') THEN ls_approvestr := 'aCHCKSLRY'; --ChyngyzO cq4960 28.12.15
   END IF;

   UPDATE TBL_TXTODO D
   SET d.STATUS='sCHECK',
     d.AUTHCD=ls_approvestr,
    d.VERIFYID = TO_NUMBER(ps_verifiedapprovedid),
    d.VERIFYDATE=SYSDATE
   WHERE d.TX_NO=TO_NUMBER(ps_txNo);
     ls_returncode:='001'; -- verify tamam check edilmeli

     ELSIF ls_approve = 'Y' THEN

   SELECT d.AUTHCD
   INTO ls_authcd
   FROM TBL_TXTODO D
   WHERE D.TX_NO = TO_NUMBER(ps_txNo);
   IF (ls_authcd = 'aVRFYBFX') THEN ls_approvestr := 'aAPPRBFX';
   ELSIF (ls_authcd = 'aVRFYEFT') THEN ls_approvestr := 'aAPPREFT';
   ELSIF (ls_authcd = 'aVRFYSFX') THEN ls_approvestr := 'aAPPRSFX';
   ELSIF (ls_authcd = 'aVRFYUPDC') THEN ls_approvestr := 'aAPPRUPDC';
   ELSIF (ls_authcd = 'aVRFYTOY') THEN ls_approvestr := 'aAPPRTOY';
   ELSIF (ls_authcd = 'aVRFYTMY') THEN ls_approvestr := 'aAPPRTMY';
   ELSIF (ls_authcd = 'aVRFYUTIL') THEN ls_approvestr := 'aAPPRUTIL';
   ELSIF (ls_authcd = 'aVRFYCNCL') THEN ls_approvestr := 'aAPPRCNCL';
   ELSIF (ls_authcd = 'aVRFYPENS') THEN ls_approvestr := 'aAPPRPENS';
   ELSIF (ls_authcd = 'aVRFYCPYM') THEN ls_approvestr := 'aAPPRCPYM';
   ELSIF (ls_authcd = 'aVRFYSAL') THEN ls_approvestr := 'aAPPRSAL';
   ELSIF (ls_authcd = 'aVRFYSWIFT') THEN ls_approvestr := 'aAPPRSWIFT';
   ELSIF (ls_authcd = 'aVRFYRDEM') THEN ls_approvestr := 'aAPPRRDEM';
   ELSIF (ls_authcd = 'aVRFYTRPYM') THEN ls_approvestr := 'aAPPRTRPYM';
   ELSIF (ls_authcd = 'aVRFYPORD') THEN ls_approvestr := 'aAPPRPORD';
   ELSIF (ls_authcd = 'aVRFYPCNCL') THEN ls_approvestr := 'aAPPRPCNCL';
   ELSIF (ls_authcd = 'aVRFYSALTB') THEN ls_approvestr := 'aAPPRSALTB';
   ELSIF (ls_authcd = 'aVRFYFXORD') THEN ls_approvestr := 'aAPPRFXORD';
   ELSIF (ls_authcd = 'aVRFYFXCL') THEN ls_approvestr := 'aAPPRFXCL';
   ELSIF (ls_authcd = 'aVRFYARBIT') THEN ls_approvestr := 'aAPPRARBIT';
   ELSIF (ls_authcd = 'aVRFYP2OC') THEN ls_approvestr := 'aAPPRP2OC';
   ELSIF (ls_authcd = 'aVRFYDDS') THEN ls_approvestr := 'aAPPRDDS';
   ELSIF (ls_authcd = 'aVRFYGRS') THEN ls_approvestr := 'aAPPRGRS';--ernestk 14022014 cqdb00000504 to include gross verify
   ELSIF (ls_authcd = 'aVRFYCDP') THEN ls_approvestr := 'aAPPRCDP';--ernestk 24032014 cqdb00000862 to include CARDDEBT verify
   ELSIF (ls_authcd = 'aVRFYPYM') THEN ls_approvestr := 'aAPPRPYM';
   ELSIF (ls_authcd = 'aVRFYSLRY') THEN ls_approvestr := 'aAPPRSLRY';  --ChyngyzO cq4960 28.12.15
   END IF;

   UPDATE TBL_TXTODO D
   SET d.STATUS='sAPPROVE',
     d.AUTHCD=ls_approvestr,
    d.VERIFYID = TO_NUMBER(ps_verifiedapprovedid),
    d.VERIFYDATE=SYSDATE
   WHERE d.TX_NO=TO_NUMBER(ps_txNo);
     ls_returncode:='002'; -- verify tamam check edilmeyecek approve edilmeli
   ELSE
     ls_returncode:='003'; -- verify tamam baska bisey yok islemi yaratabilir

 /*  IF ls_trancd IN ('CLEARING','B2OBHVL') THEN
   IF SUBSTR(ls_fromirsseco,1,1)='2' OR SUBSTR(ls_toirsseco,1,1) = '2' THEN
    ls_returncode:='007'; -- Control de beklesin

    UPDATE TBL_TXTODO D
    SET d.STATUS='sCONTROL',
     d.APPROVALID = TO_NUMBER(ps_verifiedapprovedid),
     d.APPROVALDATE=SYSDATE
    WHERE d.TX_NO=TO_NUMBER(ps_txNo);

    ls_control:='Y';
     END IF;
   ELSIF ls_trancd IN ('EXCHNGBUY','FXORDER','ARBITRAGE','DDSINVOICE','SWIFT') THEN
     ls_returncode:='007'; -- Control de beklesin

    UPDATE TBL_TXTODO D
    SET d.STATUS='sCONTROL',
     d.APPROVALID = TO_NUMBER(ps_verifiedapprovedid),
     d.APPROVALDATE=SYSDATE
    WHERE d.TX_NO=TO_NUMBER(ps_txNo);

    ls_control:='Y';
   END IF;*/

     END IF;
    END IF;

    IF (ls_status = 'sCHECK') THEN
     IF ls_approve = 'Y' THEN
   SELECT d.AUTHCD
   INTO ls_authcd
   FROM TBL_TXTODO D
   WHERE D.TX_NO = TO_NUMBER(ps_txNo);
   IF (ls_authcd = 'aCHCKBFX') THEN ls_approvestr := 'aAPPRBFX';
   ELSIF (ls_authcd = 'aCHCKEFT') THEN ls_approvestr := 'aAPPREFT';
   ELSIF (ls_authcd = 'aCHCKSFX') THEN ls_approvestr := 'aAPPRSFX';
   ELSIF (ls_authcd = 'aCHCKUPDC') THEN ls_approvestr := 'aAPPRUPDC';
   ELSIF (ls_authcd = 'aCHCKTOY') THEN ls_approvestr := 'aAPPRTOY';
   ELSIF (ls_authcd = 'aCHCKTMY') THEN ls_approvestr := 'aAPPRTMY';
   ELSIF (ls_authcd = 'aCHCKUTIL') THEN ls_approvestr := 'aAPPRUTIL';
   ELSIF (ls_authcd = 'aCHCKCNCL') THEN ls_approvestr := 'aAPPRCNCL';
   ELSIF (ls_authcd = 'aCHCKPENS') THEN ls_approvestr := 'aAPPRPENS';
   ELSIF (ls_authcd = 'aCHCKCPYM') THEN ls_approvestr := 'aAPPRCPYM';
    ELSIF (ls_authcd = 'aCHCKSAL') THEN ls_approvestr := 'aAPPRSAL';
   ELSIF (ls_authcd = 'aCHCKSWIFT') THEN ls_approvestr := 'aAPPRSWIFT';
   ELSIF (ls_authcd = 'aCHCKRDEM') THEN ls_approvestr := 'aAPPRRDEM';
   ELSIF (ls_authcd = 'aCHCKTRPYM') THEN ls_approvestr := 'aAPPRTRPYM';
   ELSIF (ls_authcd = 'aCHCKPORD') THEN ls_approvestr := 'aAPPRPORD';
   ELSIF (ls_authcd = 'aCHCKPCNCL') THEN ls_approvestr := 'aAPPRPCNCL';
   ELSIF (ls_authcd = 'aCHCKSALTB') THEN ls_approvestr := 'aAPPRSALTB';
   ELSIF (ls_authcd = 'aCHCKFXORD') THEN ls_approvestr := 'aAPPRFXORD';
   ELSIF (ls_authcd = 'aCHCKFXCL') THEN ls_approvestr := 'aAPPRFXCL';
   ELSIF (ls_authcd = 'aCHCKARBIT') THEN ls_approvestr := 'aAPPRARBIT';
   ELSIF (ls_authcd = 'aCHCKP2OC') THEN ls_approvestr := 'aAPPRP2OC';
   ELSIF (ls_authcd = 'aCHCKDDS') THEN ls_approvestr := 'aAPPRDDS';
   ELSIF (ls_authcd = 'aCHCKGRS') THEN ls_approvestr := 'aAPPRGRS';--ernestk 14022014 cqdb00000504 to include gross check
   ELSIF (ls_authcd = 'aCHCKCDP') THEN ls_approvestr := 'aAPPRCDP';--ernestk 24032014 cqdb00000862 to include CARDDEBT check
   ELSIF (ls_authcd = 'aCHCKPYM') THEN ls_approvestr := 'aAPPRPYM';
   ELSIF (ls_authcd = 'aCHCKSLRY') THEN ls_approvestr := 'aAPPRSLRY';  --ChyngyzO cq4960 28.12.15
   END IF;

   UPDATE TBL_TXTODO D
   SET d.STATUS='sAPPROVE',
     d.AUTHCD=ls_approvestr,
    d.CHECKID = TO_NUMBER(ps_verifiedapprovedid),
    d.CHECKDATE=SYSDATE
   WHERE d.TX_NO=TO_NUMBER(ps_txNo);
     ls_returncode:='004'; -- check approve edilmeli
   ELSE
     ls_returncode:='005'; -- Check tamam baska bisey yok islemi yaratabilir

 /*  IF ls_trancd IN ('CLEARING','B2OBHVL') THEN
   IF SUBSTR(ls_fromirsseco,1,1)='2' OR SUBSTR(ls_toirsseco,1,1) = '2' THEN
    ls_returncode:='007'; -- Control de beklesin

    UPDATE TBL_TXTODO D
    SET d.STATUS='sCONTROL',
     d.APPROVALID = TO_NUMBER(ps_verifiedapprovedid),
     d.APPROVALDATE=SYSDATE
    WHERE d.TX_NO=TO_NUMBER(ps_txNo);

    ls_control:='Y';
     END IF;
   ELSIF ls_trancd IN ('EXCHNGBUY','FXORDER','ARBITRAGE','DDSINVOICE','SWIFT') THEN
     ls_returncode:='007'; -- Control de beklesin

    UPDATE TBL_TXTODO D
    SET d.STATUS='sCONTROL',
     d.APPROVALID = TO_NUMBER(ps_verifiedapprovedid),
     d.APPROVALDATE=SYSDATE
    WHERE d.TX_NO=TO_NUMBER(ps_txNo);

    ls_control:='Y';
   END IF;
*/
     END IF;
 END IF;

 IF (ls_status = 'sAPPROVE') THEN

    ls_returncode:='006'; -- Approve tamam islemi yaratabilir

 /* IF ls_trancd IN ('CLEARING','B2OBHVL') THEN
   IF SUBSTR(ls_fromirsseco,1,1)='2' OR SUBSTR(ls_toirsseco,1,1) = '2' THEN
    ls_returncode:='007'; -- Control de beklesin

    UPDATE TBL_TXTODO D
    SET d.STATUS='sCONTROL',
     d.APPROVALID = TO_NUMBER(ps_verifiedapprovedid),
     d.APPROVALDATE=SYSDATE
    WHERE d.TX_NO=TO_NUMBER(ps_txNo);

    ls_control:='Y';
   END IF;
   ELSIF ls_trancd IN ('EXCHNGBUY','FXORDER','ARBITRAGE','DDSINVOICE','SWIFT') THEN
     ls_returncode:='007'; -- Control de beklesin

    UPDATE TBL_TXTODO D
    SET d.STATUS='sCONTROL',
     d.APPROVALID = TO_NUMBER(ps_verifiedapprovedid),
     d.APPROVALDATE=SYSDATE
    WHERE d.TX_NO=TO_NUMBER(ps_txNo);

    ls_control:='Y';

  END IF;
*/
   END IF;
/*
 IF (ls_status = 'sCONTROL') THEN

    ls_returncode:='008'; -- Control tamam islemi yaratabilir\
  UPDATE TBL_TXTODO D
  SET d.APPROVALDATE=NVL(d.APPROVALDATE,SYSDATE)
  WHERE d.TX_NO=TO_NUMBER(ps_txNo);

 END IF;

 IF ls_control='Y' THEN
    ls_content:='TX_NO:' || ps_txNo ||'<BR>Customer ID:' || ps_customerid || '<BR>Tran Code:' || ls_trancd || '<BR><BR>Please chec Administration site for approval.';
     cbs.pkg_email.AddToEmailQueue('CURRENCYCONTROL', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz;KuralayZ@demirbank.kz;ainura@demirbank.kz', 'New Transaction for Currency Control',ls_content,'HTML');
 END IF;
*/
 RETURN ls_returncode;

END;
------------------------------------------------------------
FUNCTION DeleteTxToDo(ps_txNo IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

    UPDATE TBL_TXTODO T
 SET T.STATUS='sDELETE'
 WHERE (ps_txNo='ALL' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txNo, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) );

 --INSTR(DECODE(ps_txNo, 'ALL', ',' || TO_CHAR(t.TX_NO) || ',',ps_txNo), ',' || TO_CHAR(t.TX_NO) || ',')>0;
 --WHERE t.TX_NO=TO_NUMBER(ps_txNo);


 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
---------------------------------------------------------------------------
FUNCTION RejectTxToDo(ps_txNo IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

    UPDATE TBL_TXTODO T
 SET T.STATUS='sREJECT',t.CONTROL_DATE=SYSDATE
 WHERE t.TX_NO=TO_NUMBER(ps_txNo);


 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;

--------------------------------------------------------------------------------------
FUNCTION GetTxToDoHistory(ps_customerID IN VARCHAR2,
      ps_channelCD IN VARCHAR2,
      ps_startdate IN VARCHAR2,
      ps_enddate IN VARCHAR2,
           ps_status IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 UPDATE TBL_TXTODO T
 SET T.STATUS='sEXPIRED'
 WHERE T.CUSTOMER_ID = TO_NUMBER(ps_customerID)
 AND TO_DATE(FIELD3,'YYYYMMDD') < TRUNC(SYSDATE)
 AND TRANCD='CLEARING'
 AND ( (t.STATUS ='sVERIFY') OR (t.STATUS ='sCHECK') OR (t.STATUS ='sAPPROVE'));

    OPEN pc_ref FOR
 SELECT

 NVL(Pkg_Customer.GetPersonName(t.MAKERID),' '),
 t.TX_NO,
 NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') ,
 t.AUTHCD,
 DECODE(T.TRANCD,'CLEARING',FIELD3,'CLEARCNCL',FIELD3,TO_CHAR(t.MAKEDATE,'YYYYMMDD')) TRAN_DATE,
 t.MAKERID,
 t.STATUS,
 r.DEFINITION,
 t.TRANCD,
 NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' '),
 t.VERIFYID,
 NVL(t.FIELD1,' '),
 NVL(t.FIELD2,' '),
 NVL(t.FIELD3,' '),
 NVL(t.FIELD4,' '),
 NVL(t.FIELD5,' '),
 NVL(t.FIELD6,' '),
 NVL(t.FIELD7,' '),
 NVL(t.FIELD8,' '),
 NVL(t.FIELD9,' '),
 NVL(t.FIELD10,' '),
 NVL(t.FIELD11,' '),
 NVL(t.FIELD12,' '),
 NVL(t.FIELD13,' '),
 NVL(t.FIELD14,' '),
 NVL(t.FIELD15,' '),
 NVL(t.FIELD16,' '),
 NVL(t.FIELD17,' '),
 NVL(t.FIELD18,' '),
 NVL(t.FIELD19,' '),
 NVL(t.FIELD20,' '),
 NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' '),
 NVL(Pkg_Customer.GetPersonName(t.CHECKID),' '),
 NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' '),
 NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' '),
 t.CHECKID,
 DECODE(T.TRANCD,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3,' ') AMOUNT,
    DECODE(T.TRANCD,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,' ')CURRENCY,
    DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ',' ')PAYEE_NAME
 FROM TBL_TXTODO t,TBL_PERSON P,TBL_TRANSACTION R
 WHERE
 T.MAKERID = P.PERSON_ID AND
 p.CUSTOMER_ID=ps_customerID AND
 t.TRANCD = r.TRAN_CD AND
 r.LANGUAGE_CD = 'ENG' AND
 TO_DATE(ps_startdate,'YYYYMMDD') <= TRUNC(t.MAKEDATE) AND
 TO_DATE(ps_enddate,'YYYYMMDD') >= TRUNC(t.MAKEDATE) AND
 t.STATUS LIKE ps_status

   ORDER BY MAKEDATE;

 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
--------------------------------------------------------------------------------------
FUNCTION GetPersonInfoIR(ps_custno IN VARCHAR2,
            ps_person IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT IMZA_SIRKULERI_IMZA_LIMIT,IMZA_SIRKULERI_CY
 FROM TBL_COMPANY
 WHERE customer_no = ps_custno
   AND person_id = ps_person;

 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
--------------------------------------------------------------------------------------
FUNCTION GetSpecPersonInfoIR(ps_custno IN VARCHAR2,
            ps_person IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT IMZA_SIRKULERI_IMZA_LIMIT,IMZA_SIRKULERI_CY
 FROM TBL_SPEC_COMPANY
 WHERE customer_no = ps_custno
   AND person_id = ps_person;

 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
--------------------------------------------------------------------------------------
FUNCTION UpdateSignature(ps_UserID IN VARCHAR2,
            ps_customer IN VARCHAR2,
            ps_ImzaAmnt IN VARCHAR2,
            ps_imzacy IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 UPDATE TBL_COMPANY
 SET IMZA_SIRKULERI_IMZA_LIMIT = REPLACE(REPLACE(ps_ImzaAmnt,',',''),'.',','),
     IMZA_SIRKULERI_CY = ps_imzacy
 WHERE customer_no = ps_customer
   AND person_id = ps_UserID;

 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
--------------------------------------------------------------------------------------
FUNCTION UpdateSpecSignature(ps_UserID IN VARCHAR2,
            ps_customer IN VARCHAR2,
            ps_ImzaAmnt IN VARCHAR2,
            ps_imzacy IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 UPDATE TBL_SPEC_COMPANY
 SET IMZA_SIRKULERI_IMZA_LIMIT = REPLACE(REPLACE(ps_ImzaAmnt,',',''),'.',','),
     IMZA_SIRKULERI_CY = ps_imzacy
 WHERE customer_no = ps_customer
   AND person_id = ps_UserID;

 RETURN ls_returncode;
  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
--------------------------------------------------------------------------------------
FUNCTION BooktoBookTransferToDo(ps_fromaccount IN VARCHAR2,
                                ps_toaccount IN VARCHAR2,
                                ps_amount IN VARCHAR2,
                                ps_description IN VARCHAR2,
                                ps_currencycode IN VARCHAR2,
                                ps_decontistiyormu IN VARCHAR2,
                                ps_stat IN VARCHAR2,
                                ps_personid IN VARCHAR2,
                                ps_trancd IN VARCHAR2,
                                ps_payeename IN VARCHAR2,
                                ps_internalacc IN VARCHAR2,
                                ps_paymentcode IN VARCHAR2,
                                ps_fromirsseco IN VARCHAR2,
                                ps_toirsseco IN VARCHAR2,
                                ps_commision IN VARCHAR2,
                                ps_order_number IN VARCHAR2 DEFAULT '', --chyngyzo 10122014 cq1264 add order number
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode  VARCHAR2(3):='000';
  ls_paymentcode VARCHAR2(500);
  ln_txid NUMBER;
  ls_payeename VARCHAR2(500):=ps_payeename;
  ln_cond NUMBER;
  is_close_account EXCEPTION;

BEGIN
    OPEN pc_ref FOR SELECT SYSDATE FROM dual;
    ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');
   
    --checking the account closed. Nursultan.K ibc 121
      SELECT COUNT(*) INTO ln_cond FROM CBS_HESAP ch 
      WHERE ch.EXTERNAL_HESAP_NO = ps_toaccount AND ch.HESAP_HAREKET_KODU IN (1,2) and durum_kodu ='A' ;
     IF ln_cond = 0 then
     	raise is_close_account;
     end IF;

  IF LENGTH(ps_paymentcode)=3 THEN
    ls_paymentcode:=ps_paymentcode||';'||cbs.pkg_int_tx.istatistik_adi_al(ps_paymentcode);
  ELSE
    ls_paymentcode:=ps_paymentcode;
  END IF;

  if (length(trim(ls_payeename))=0 or ls_payeename is null) then
    select substr(DECODE(MM.MUSTERI_TIPI_KOD,1,trim(MM.ISIM||' '||MM.IKINCI_ISIM||' '||MM.SOYADI),MM.TICARI_UNVAN),1,500) into ls_payeename
    from cbs_musteri mm
    where MM.MUSTERI_NO in (select hh.musteri_no from cbs_hesap hh where HH.EXTERNAL_HESAP_NO=trim(ps_toaccount) and rownum=1);
  end if;

 IF (UPPER(ps_trancd) = 'B2OBHVL' ) THEN

        INSERT INTO TBL_TXTODO
        (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,FIELD1,FIELD2,FIELD3,FIELD4,
        FIELD5,FIELD6,AUTHCD,FIELD9,FIELD20,FIELD10,FIELD11,FIELD12,FIELD13,FIELD16,FIELD18,FIELD19)  /* FIELD 19 IS FOR COMM */ --chyngyzo 10122014 cq1264 FIELD18 is added for order no
        VALUES
        (ln_txid,'B2OBHVL',ps_personid,SYSDATE,ps_stat,
        ps_fromaccount,ps_toaccount,ps_amount,ps_description,ps_currencycode,
        ps_decontistiyormu,DECODE(ps_stat,'sVERIFY','aVRFYTOY','sCHECK','aCHCKTOY','sAPPROVE','aAPPRTOY','sCONTROL','aAPPRTOY'),ps_amount,
        ps_currencycode,ls_payeename,ps_internalacc,ls_paymentcode,ps_fromirsseco,ps_toirsseco,ps_order_number,ps_commision); --chyngyzo 10122014 cq1264 FIELD18->ps_order_number is added for order no

 ELSIF (UPPER(ps_trancd) = 'B2BHVL') THEN
     INSERT INTO TBL_TXTODO
     (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,FIELD6,AUTHCD,FIELD9,FIELD18,FIELD20)  /* FIELD 19 IS FOR COMM */--chyngyzo 10122014 cq1264 FIELD18 is added for order no
     VALUES
     (ln_txid,'B2BHVL',ps_personid,SYSDATE,ps_stat,
      ps_fromaccount,ps_toaccount,ps_amount,ps_description,ps_currencycode,
      ps_decontistiyormu,DECODE(ps_stat,'sVERIFY','aVRFYTMY','sCHECK','aCHCKTMY','sAPPROVE','aAPPRTMY'),ps_amount,ps_order_number, --chyngyzo 10122014 cq1264 FIELD18->ps_order_number is added for order no
      ps_currencycode);
 END IF;

   OPEN pc_ref FOR select ln_txid from dual;--ernestk cqdb00000824 return transaction no of transfer --ernestk cqdb00000504 return transaction no  payment is made with
   RETURN ls_returncode;
EXCEPTION
WHEN is_close_account THEN
 ROLLBACK;
 ls_returncode := '548';
 RETURN ls_returncode;
 WHEN OTHERS THEN
      Pkg_Log.AddCustomLog(SQLERRM);
   RETURN '999';
END;
---------------------------------------------------------------
FUNCTION CheckUserNameandPassword(
                      ps_channelcd IN VARCHAR2,
                      ps_username IN VARCHAR2,
                      ps_password IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

             ls_returncode   VARCHAR2(3):='000';

       ln_personid NUMBER := 0;
       ln_attemptcount NUMBER;
       ps_tokenid VARCHAR2(100);

       CURSOR cursor_identity IS
       SELECT * FROM TBL_IDENTIFICATION i
       WHERE i.USERNAME = ps_username
       AND i.CHANNEL_CD=ps_channelcd;

       row_identity cursor_identity%ROWTYPE;

       CURSOR cursor_alias IS
       SELECT * FROM TBL_IDENTIFICATION i
       WHERE i.USERALIAS = ps_username
       AND i.CHANNEL_CD=ps_channelcd;

       row_alias cursor_alias%ROWTYPE;

        CURSOR cursor_passcode(pn_personid NUMBER) IS
       SELECT * FROM TBL_IDENTIFICATION i
       WHERE i.PERSON_ID=pn_personid
       AND i.CHANNEL_CD=ps_channelcd
       AND i.STATUS_CD='sENAB'
       AND i.PASSCODE=ps_password;

                      row_passcode cursor_passcode%ROWTYPE;

        CURSOR cursor_expire(pn_personid NUMBER) IS
       SELECT * FROM TBL_IDENTIFICATION i
       WHERE i.PERSON_ID=pn_personid
       AND i.EXPIREDATE>SYSDATE;

                      TransactionError    EXCEPTION;
           ls_sessionStatus VARCHAR2(10) := 'sACTIVE';
       ls_personstatus VARCHAR2(20) := 'sENAB';
       ln_sessionid NUMBER;
       ls_ticketid   VARCHAR2(40):='';

 BEGIN

   OPEN pc_ref FOR
   SELECT 'lala' FROM dual;

     -- ?nce b?yle bir kullan?c? var m?

  OPEN cursor_identity;
  FETCH cursor_identity INTO row_identity;
  IF  cursor_identity%NOTFOUND THEN
   OPEN cursor_alias;
   FETCH cursor_alias INTO row_alias;
   IF  cursor_alias%NOTFOUND THEN
    ls_returncode:='001';
    RAISE TransactionError;
   ELSE
    ln_personid:=row_alias.PERSON_ID;
    ln_attemptcount:=row_alias.ATTEMPT_COUNT;
    ps_tokenid:=NVL(row_alias.TOKEN_ID,' ');
    ls_personstatus:=row_alias.STATUS_CD;
   END IF;
   CLOSE cursor_alias;
  ELSE
   ln_personid:=row_identity.PERSON_ID;
   ln_attemptcount:=row_identity.ATTEMPT_COUNT;
   ps_tokenid:=NVL(row_identity.TOKEN_ID,' ');
   ls_personstatus:=row_identity.STATUS_CD;
  END IF;
  CLOSE cursor_identity;

  -- account disable olmu? ise kullan?c?y? uyarmak laz?m..
  --
  IF (ls_personstatus <> 'sENAB') THEN
  ls_returncode:='459';
  RAISE TransactionError;
  END IF;

     -- Lock the user if attem count exceed 3
   OPEN cursor_passcode(ln_personid);
  FETCH cursor_passcode INTO row_passcode;
  IF  cursor_passcode%NOTFOUND THEN
   ls_returncode:='002';
   IF ln_attemptcount+1>3 THEN
    UPDATE TBL_IDENTIFICATION i
    SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1,
     i.STATUS_CD='sLOCKED'
    WHERE i.PERSON_ID=ln_personid;
    ls_returncode:='008';
   ELSE
    UPDATE TBL_IDENTIFICATION i
    SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1
    WHERE i.PERSON_ID=ln_personid;
   END IF;
   RAISE TransactionError;
  END IF;
  CLOSE cursor_passcode;

  --4) Authentication OK Clear Attemp Count
  --update tbl_identification i
  --set i.attempt_count=0
  --where i.PERSON_ID=ln_personid
  --and i.CHANNEL_CD=ps_channelcd;

     IF LENGTH(ps_tokenid) > 1 THEN
     ls_sessionStatus:='sTOKEN';
  END IF;

  --4) Create an Active Session
   ln_sessionid:=Pkg_Common.GetSequenceID('sqSESSIONID');

  --Close old sessions
  UPDATE TBL_SESSION
  SET status_cd='sCLOSED'
  WHERE person_id=ln_personid;

  --Create new session
  INSERT INTO TBL_SESSION
  (SESSION_ID, PERSON_ID, CHANNEL_CD, STATUS_CD)
  VALUES
  (ln_sessionid, ln_personid, ps_channelcd, ls_sessionStatus);

  --5) Get Ticket
   ls_ticketid:=Pkg_Common.GetTicketID;

  IF ls_ticketid IS NULL THEN
     ls_returncode:='004';
     RAISE TransactionError;
  ELSE
     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
     VALUES
     (ln_personid, ls_ticketid, 1, ln_sessionid);
  END IF;

   OPEN pc_ref FOR
   SELECT ln_sessionid,ln_personid,ps_tokenid,ls_ticketid FROM dual;

   RETURN ls_returncode;
 EXCEPTION
        WHEN TransactionError THEN
   RETURN ls_returncode;
  WHEN OTHERS THEN
  Pkg_Log.AddCustomLog('TIM-1',SQLERRM);
  ls_returncode:='999';
  RETURN ls_returncode;
 END;
----------------------------------------------------------
FUNCTION CheckUserPinCode(
                      ps_channelcd IN VARCHAR2,
                      ps_pincode IN VARCHAR2,
                      ps_sessionid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS
             ls_returncode   VARCHAR2(3):='000';
       ln_personid NUMBER := 0;
       ls_ticketid   VARCHAR2(40):='';

       CURSOR cursor_pincode(pn_personid NUMBER) IS
       SELECT * FROM TBL_IDENTIFICATION i
       WHERE i.PERSON_ID=pn_personid
       AND i.CHANNEL_CD=ps_channelcd
       AND i.STATUS_CD='sENAB'
       AND i.PINCODE=ps_pincode;

       CURSOR cursor_expire(pn_personid NUMBER) IS
       SELECT * FROM TBL_IDENTIFICATION i
       WHERE i.PERSON_ID=pn_personid
       AND i.EXPIREDATE>SYSDATE;

           row_pincode cursor_pincode%ROWTYPE;
          row_expire cursor_expire%ROWTYPE;

       ln_attemptcount NUMBER:=0;
       ps_pwdforcechange VARCHAR2(100);
       TransactionError    EXCEPTION;
 BEGIN
   OPEN pc_ref FOR
   SELECT 'lala' FROM dual;

   SELECT s.PERSON_ID
   INTO ln_personid
   FROM TBL_SESSION s
   WHERE s.SESSION_ID=ps_sessionid;

   SELECT i.ATTEMPT_COUNT,i.PWDFORCECHANGE
   INTO ln_attemptcount,ps_pwdforcechange
   FROM TBL_IDENTIFICATION i
   WHERE i.PERSON_ID=ln_personid;


   OPEN cursor_pincode(ln_personid);
  FETCH cursor_pincode INTO row_pincode;
  IF  cursor_pincode%NOTFOUND THEN
   ls_returncode:='003';
   IF ln_attemptcount+1>3 THEN
    UPDATE TBL_IDENTIFICATION i
    SET i.attempt_count=i.attempt_count+1,
     i.STATUS_CD='sLOCKED'
    WHERE i.PERSON_ID=ln_personid;
    ls_returncode:='008';
   ELSE
    UPDATE TBL_IDENTIFICATION i
    SET i.attempt_count=i.attempt_count+1
    WHERE i.PERSON_ID=ln_personid;
   END IF;
   RAISE TransactionError;
  END IF;
  CLOSE cursor_pincode;

   -- Attemptcountu s?f?rlama i?ini burada yapm?yorum
   -- Welcome.jsp de yap?yorum b?ylece  hatal? giri? say?s?n? da kullan?c? ??reniyor

  --4) Authentication OK Clear Attemp Count
  UPDATE TBL_IDENTIFICATION i
  SET i.attempt_count=0
  WHERE i.PERSON_ID=ln_personid
  AND i.CHANNEL_CD=ps_channelcd;

  --5) Get Ticket
   ls_ticketid:=Pkg_Common.GetTicketID;

  IF ls_ticketid IS NULL THEN
     ls_returncode:='004';
     RAISE TransactionError;
  ELSE
     INSERT INTO TBL_TICKET_HISTORY
     (PERSON_ID, TICKET_ID, TICKET_INDX, SESSION_ID)
     VALUES
     (ln_personid, ls_ticketid, 2, ps_sessionid); -- ilk ekranda zaten bir ticket ?retmi?tim bu iki oldu..
  END IF;

 --6) Expire Check
  OPEN cursor_expire(ln_personid);
  FETCH cursor_expire INTO row_expire;
  IF  cursor_expire%NOTFOUND THEN
   ps_pwdforcechange:='E';
  END IF;
  CLOSE cursor_expire;



   OPEN pc_ref FOR
   SELECT ps_sessionid,ls_ticketid,ln_personid,ps_pwdforcechange,ln_attemptcount
   FROM dual;

   RETURN ls_returncode;
 EXCEPTION
        WHEN TransactionError THEN
   RETURN ls_returncode;

  WHEN OTHERS THEN
  ls_returncode:='999';
  RETURN ls_returncode;
 END;
-----------------------------------------------------------
 FUNCTION SetWrongTokenAttemp(
                      ps_channelcd IN VARCHAR2,
                      ps_sessionid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
                     ls_returncode      VARCHAR2(3):='000';
       ps_personID NUMBER;
       ln_attemptcount NUMBER;
BEGIN

 OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

 SELECT PERSON_ID
 INTO ps_personID
 FROM TBL_SESSION
 WHERE SESSION_ID=TO_NUMBER(ps_sessionID);

 SELECT t.ATTEMPT_COUNT
 INTO ln_attemptcount
 FROM TBL_IDENTIFICATION t
 WHERE t.PERSON_ID=TO_NUMBER(ps_personID)
 AND t.CHANNEL_CD=ps_channelcd;

 IF ln_attemptcount+1>3 THEN
 UPDATE TBL_IDENTIFICATION i
 SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1,
 i.STATUS_CD='sLOCKED'
 WHERE i.PERSON_ID=TO_NUMBER(ps_personID);
 ls_returncode:='008';

 ELSE

    UPDATE TBL_IDENTIFICATION i
 SET i.ATTEMPT_COUNT=i.ATTEMPT_COUNT+1
 WHERE i.PERSON_ID=TO_NUMBER(ps_personID);
 END IF;

 RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
     RETURN '111';
END;
-----------------------------------------------------------
FUNCTION ChechandClearWrongAttempt(
                      ps_personid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
                     ls_returncode      VARCHAR2(3):='000';
       ln_attemptcount NUMBER:=0;
BEGIN

 OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

 -- count
 SELECT t.ATTEMPT_COUNT
 INTO ln_attemptcount
 FROM TBL_IDENTIFICATION t
 WHERE t.PERSON_ID=TO_NUMBER(ps_personid);

 --clear
 UPDATE TBL_IDENTIFICATION i
 SET i.attempt_count=0
 WHERE i.PERSON_ID=TO_NUMBER(ps_personid);

 OPEN pc_ref FOR
    SELECT ln_attemptcount FROM dual;

 RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
     RETURN '999';
END;
------------------------------------------------------------------------------------
FUNCTION AddUtilityPaymentToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
                p_FromAccount IN VARCHAR2,
    p_SenderName IN VARCHAR2,
    p_InstitutionCD IN VARCHAR2,
    p_Description IN VARCHAR2,
    p_Amount IN VARCHAR2,
    p_AreaCD IN VARCHAR2,
    p_PhoneNo IN VARCHAR2,
    p_SubscriptionNo IN VARCHAR2,
    p_InvoiceNo IN VARCHAR2,
    p_KeyNo IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,FIELD11,
  AUTHCD,FIELD19,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'UTILPAY',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  p_FromAccount,p_SenderName,p_InstitutionCD,p_Description,p_Amount,
  p_AreaCD,p_PhoneNo,p_SubscriptionNo,p_Amount,p_InvoiceNo,p_KeyNo,
  DECODE(p_StatusCD,'sVERIFY','aVRFYUTIL','sCHECK','aCHCKUTIL','sAPPROVE','aAPPRUTIL'),
  0,'KGS');

  RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
FUNCTION AddClearingCancelToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
                p_TxNo IN VARCHAR2,
    p_SenderAccount IN VARCHAR2,
    p_SenderName IN VARCHAR2,
    p_SenderRNN IN VARCHAR2,
    p_PayeeBranch IN VARCHAR2,
    p_PayeeAccount IN VARCHAR2,
    p_PayeeName IN VARCHAR2,
    p_PayeeRNN IN VARCHAR2,
    p_Amount IN VARCHAR2,
    p_TranDate IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
  InProcessCanceledClearing    EXCEPTION;
  ln_count        NUMBER;
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  SELECT COUNT(*)
  INTO ln_count
  FROM TBL_TXTODO
  WHERE TRANCD='CLEARCNCL' AND
     TO_NUMBER(p_TxNo)=TO_NUMBER(FIELD1) AND
     status<>'sDELETE';

  IF ln_count<>0 THEN
     ls_returncode:='029';
     RAISE InProcessCanceledClearing;
  END IF;

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
  AUTHCD,FIELD19,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'CLEARCNCL',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  p_TxNo,p_SenderAccount, TO_CHAR(TO_DATE(p_TranDate,'DD.MM.YYYY'),'YYYYMMDD') , p_SenderRNN, p_PayeeBranch,
  p_PayeeAccount,p_PayeeName,p_PayeeRNN, p_Amount, p_SenderName,
  DECODE(p_StatusCD,'sVERIFY','aVRFYCNCL','sCHECK','aCHCKCNCL','sAPPROVE','aAPPRCNCL'),0,'KGS');

  RETURN ls_returncode;
EXCEPTION
    WHEN InProcessCanceledClearing THEN
        RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
FUNCTION SetCurrencyController(ps_txNo IN VARCHAR2,
      ps_personno IN VARCHAR2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
BEGIN

 UPDATE TBL_TXTODO T
 SET CONTROL_ID=TO_NUMBER(ps_personno),
  CONTROL_DATE=SYSDATE,
  STATUS='sDONE'
 WHERE TX_NO=TO_NUMBER(ps_txNo);

 ls_returncode :=Pkg_Admin.GetVerifyApproveTranInfo(ps_txNo,pc_ref);

 RETURN ls_returncode;

  EXCEPTION
 WHEN OTHERS THEN
   RETURN '999';
END;
-------------------------------------------------------------------------------------
FUNCTION AddPensionPaymentToDo (p_PersonID    IN VARCHAR2,
           p_StatusCD    IN VARCHAR2,
                    p_FileName     IN VARCHAR2,
        p_FromAccount  IN VARCHAR2,
        p_FromRNN    IN VARCHAR2,
        p_32A_Date     IN VARCHAR2,
        p_32A_Amount   IN VARCHAR2,
        p_ToAccount    IN VARCHAR2,
        p_ToNBAccount  IN VARCHAR2,
        p_ToBranch     IN VARCHAR2,
        p_ToRNN       IN VARCHAR2,
        p_KNP       IN VARCHAR2,
        p_ValueDate    IN VARCHAR2,
        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
  InProcessCanceledClearing    EXCEPTION;
  ln_count        NUMBER;
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
  AUTHCD,FIELD19,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'CLEARPENS',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  p_FileName,p_FromAccount, p_ValueDate ,p_FromRNN,p_ToAccount,
  p_ToNBAccount,p_ToBranch,p_ToRNN,p_32A_Amount, p_KNP,
  DECODE(p_StatusCD,'sVERIFY','aVRFYPENS','sCHECK','aCHCKPENS','sAPPROVE','aAPPRPENS'),0,'KGS');

  RETURN ls_returncode;
EXCEPTION
    WHEN InProcessCanceledClearing THEN
        RETURN ls_returncode;
END;
------------------------------------------------------------------------------------
FUNCTION AddCardPaymentToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
                p_FromAccount IN VARCHAR2,
    p_ToCard IN VARCHAR2,
    p_Description IN VARCHAR2,
    p_Amount IN VARCHAR2,
    P_CurCode IN VARCHAR2,
    p_AccountOwner IN VARCHAR2,
    p_CardOwner IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  AUTHCD,FIELD9,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'CARDPYM',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  p_FromAccount,p_ToCard,p_Description,p_AccountOwner,p_CardOwner,
  DECODE(p_StatusCD,'sVERIFY','aVRFYCPYM','sCHECK','aCHCKCPYM','sAPPROVE','aAPPRCPYM'),
  p_Amount,p_CurCode);

  RETURN ls_returncode;
END;
----------------------------------------------------------------------------------

FUNCTION AddSwiftPaymentToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
    p_StartDate    IN VARCHAR2,
    p_EndDate    IN VARCHAR2,
    p_FromAccount  IN VARCHAR2,
                p_BankCountry IN VARCHAR2,
    p_BankCity IN VARCHAR2,
    p_BankName    IN VARCHAR2,
    p_BankCode    IN VARCHAR2,
                p_BranchName IN VARCHAR2,
    p_BenAccount IN VARCHAR2,
    p_BenName IN VARCHAR2,
    p_BenAddress IN VARCHAR2,
    p_Description IN VARCHAR2,
    p_Amount IN VARCHAR2,
    p_CurCode IN VARCHAR2,
    p_Commission IN VARCHAR2,
    p_PaymentCode IN VARCHAR2,
    p_StatisticCode IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  FIELD6,FIELD7,FIELD8,FIELD10,FIELD11,
  FIELD12,FIELD14,FIELD15,FIELD16,FIELD17,
  AUTHCD,FIELD9,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'SWIFT',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  p_StartDate,p_EndDate,p_FromAccount,p_BankCountry,p_BankCity,
  p_BankName,p_BankCode,p_BranchName,p_BenAccount,p_BenName,
  p_BenAddress,p_Description,p_Commission,p_StatisticCode,p_PaymentCode,
  DECODE(p_StatusCD,'sVERIFY','aVRFYSWIFT','sCHECK','aCHCKSWIFT','sAPPROVE','aAPPRSWIFT','sCONTROL','aAPPRSWIFT'),
  p_Amount,p_CurCode);

  RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
 FUNCTION AddTransferPaymentToDo (
      p_from_acc                VARCHAR2,
      ps_payee_info              VARCHAR2,
      pd_trandate                VARCHAR2,
      ps_sender_name             VARCHAR2,
      ps_sender_phone            VARCHAR2,
      ps_bank_code               VARCHAR2,
      ps_payee_name              VARCHAR2,
      ps_to_account              VARCHAR2,
      pn_amount                  VARCHAR2,
      ps_description             VARCHAR2,
      ps_save_payee_flag         VARCHAR2,
      ps_payee_nick              VARCHAR2,
      ps_senderirsseco             VARCHAR2,
      pn_rnn                     VARCHAR2,
      pn_doc_no                  VARCHAR2,
      pn_stat                    VARCHAR2,
      pn_paycode                 VARCHAR2,
      pn_income                  VARCHAR2,
      ps_status                  VARCHAR2,
      pn_person                  VARCHAR2,
      pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2
   IS
 ln_txid NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
 TimeException    EXCEPTION;
BEGIN

    --ls_returncode:=cbs.pkg_int_limit.CheckTimeLimit('TRANSPYM');
 IF ls_returncode<>'000' AND pd_trandate=TO_CHAR(SYSDATE,'YYYYMMDD') THEN
    RAISE TimeException;
 ELSE
    ls_returncode:='000';
 END IF;

 OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
   FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
   FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
   FIELD11,FIELD12,FIELD13,FIELD14,FIELD15,
   AUTHCD,FIELD16,FIELD17,FIELD18,FIELD19,FIELD20)  /* FIELD 19 IS FOR COMM */

   VALUES
   (ln_txid,'TRANSPYM',pn_person,SYSDATE,ps_status,
   p_from_acc,ps_payee_info,pd_trandate,ps_sender_name,ps_sender_phone,
   ps_bank_code,ps_payee_name,ps_to_account,pn_amount,ps_description,
   ps_save_payee_flag,ps_payee_nick,ps_senderirsseco,pn_rnn,pn_doc_no,
   DECODE(ps_status,'sVERIFY','aVRFYEFT','sCHECK','aCHCKEFT','sAPPROVE','aAPPREFT','sCONTROL','aAPPREFT'),
   pn_stat,pn_paycode,pn_income,0,'KGS');

   RETURN ls_returncode;

EXCEPTION
    WHEN TimeException THEN
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
         RETURN ls_returncode;

 WHEN OTHERS THEN
 RETURN '708';
END;
------------------------------------------------------------------
FUNCTION PaymentOrderToDo (
      pn_from_acc                VARCHAR2,
      pd_startdate               VARCHAR2,
      ps_sender_name             VARCHAR2,
      ps_bank_code               VARCHAR2,
      ps_payee_name              VARCHAR2,
      ps_to_account              VARCHAR2,
      pn_total_amount            VARCHAR2,
      ps_description             VARCHAR2,
      ps_senderirsseco           VARCHAR2,
      pn_rnn                     VARCHAR2,
      pn_doc_no                  VARCHAR2,
      pn_stat                    VARCHAR2,
      pn_income                  VARCHAR2,
   ps_currency                VARCHAR2,
   pn_payee_internal_acc      VARCHAR2,
   pn_payment_code            VARCHAR2,
   pn_institution_cd          VARCHAR2,
   pn_area_cd                 VARCHAR2,
   pn_phone_no                VARCHAR2,
   ps_tran_type               VARCHAR2,
   ps_payment_type            VARCHAR2,
   pn_informing               VARCHAR2,
   pn_payment_period          VARCHAR2,
   pn_endofweek               VARCHAR2,
   pn_personid                VARCHAR2,
   pd_end_date                VARCHAR2,
   ps_status                  VARCHAR2,
   pn_payment_no              VARCHAR2,
      pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2
   IS
 ln_txid NUMBER;
 ld_payment_date   DATE;
 ls_delimiter   VARCHAR2(1):=';';
 v_LoopCounter BINARY_INTEGER := 0;
 ls_returncode  VARCHAR2 (3)  := '000';
 TimeException    EXCEPTION;
BEGIN

   OPEN pc_ref FOR
   SELECT SYSDATE FROM DUAL;

     IF ps_payment_type='IRREGULAR' THEN
  ld_payment_date:=TO_DATE(Pkg_Message.Split(pd_startdate,ls_delimiter,0),'YYYYMMDD');
  ELSE
  ld_payment_date:=TO_DATE(pd_startdate,'YYYYMMDD');
  END IF;
 IF ls_returncode<>'000' AND ld_payment_date=TO_CHAR(SYSDATE,'YYYYMMDD') THEN
    RAISE TimeException;
 ELSE
    ls_returncode:='000';
 END IF;

   ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

   INSERT INTO TBL_TXTODO
       (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
       FIELD1,FIELD2,FIELD3,FIELD4,
       FIELD5,FIELD6,FIELD7,FIELD8,
       FIELD9,FIELD10,FIELD11,FIELD12,FIELD13,
    FIELD14,FIELD15,FIELD16,FIELD17,
    FIELD18,AUTHCD)
    VALUES
       (ln_txid,'PAYMORD',pn_personid,SYSDATE,ps_status,
       ps_tran_type,pn_from_acc,ps_to_account,ps_payee_name,
    ps_sender_name,ps_description,'KGS',pn_payment_code,
    ps_bank_code,ps_senderirsseco,pn_rnn,pn_doc_no,pn_income,
    pn_payee_internal_acc,pn_institution_cd,pn_area_cd,pn_phone_no,
    pn_payment_no,DECODE(ps_status,'sVERIFY','aVRFYPORD','sCHECK','aCHCKPORD','sAPPROVE','aAPPRPORD')
    );

   IF ps_payment_type='IRREGULAR' THEN
   WHILE  v_LoopCounter<TO_NUMBER(pn_payment_no)
   LOOP


    INSERT INTO TBL_TXTODO_DETAILS
       (TX_NO, INSTALMENT_ID, TRAN_TYPE, PAYMENT_TYPE,
         START_DATE, END_DATE, PERIOD_TYPE, INSTALMENT_AMOUNT,
         STATUS_CD, HOLIDAY_TYPE, INFORMING)
     VALUES
        (ln_txid,v_LoopCounter+1,ps_tran_type,ps_payment_type,
      TO_DATE(Pkg_Message.Split(pd_startdate,ls_delimiter,v_LoopCounter),'YYYYMMDD'),
      '','',
      TO_NUMBER(Pkg_Message.Split(pn_total_amount,ls_delimiter,v_LoopCounter),'99999999999.99'),
      'sNEW',pn_endofweek,pn_informing);
   v_LoopCounter:=v_LoopCounter+1;
   END LOOP;
   ELSE
       INSERT INTO TBL_TXTODO_DETAILS
       (TX_NO, INSTALMENT_ID, TRAN_TYPE, PAYMENT_TYPE,
         START_DATE, END_DATE, PERIOD_TYPE, INSTALMENT_AMOUNT,
         STATUS_CD, HOLIDAY_TYPE,INFORMING)
     VALUES(ln_txid,'',ps_tran_type,ps_payment_type,
      TO_DATE(pd_startdate,'YYYYMMDD'),TO_DATE(pd_end_date,'YYYYMMDD'),pn_payment_period,TO_NUMBER(pn_total_amount,'99999999999.99'),
      'sNEW',pn_endofweek,pn_informing);
 END IF;


   RETURN ls_returncode;

EXCEPTION
    WHEN TimeException THEN
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
         RETURN ls_returncode;

 WHEN OTHERS THEN
 RETURN '708';

END;
---------------------------------------------------------------------------------------------
FUNCTION PaymentOrderCancelToDo (ps_person_id      VARCHAR2,
         ps_status         VARCHAR2,
         ps_txno           VARCHAR2,
          pn_order_id       VARCHAR2,
         ps_tran_type      VARCHAR2,
         pn_from_acc       VARCHAR2,
         ps_amount         VARCHAR2,
         ps_payment_date   VARCHAR2,
         ps_currency       VARCHAR2,
              pc_ref        OUT   cursorreferencetype) RETURN VARCHAR2 IS

   ls_returncode  VARCHAR2 (3)  := '000';
   ln_txid NUMBER;
BEGIN

  OPEN pc_ref FOR
   SELECT SYSDATE FROM DUAL;

 ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
       (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
       FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
    FIELD6,FIELD7,AUTHCD)
    VALUES
       (ln_txid,'PORDCNCL',ps_person_id,SYSDATE,ps_status,
       ps_tran_type,ps_txno,pn_order_id,pn_from_acc,ps_payment_date,
    ps_amount,ps_currency,DECODE(ps_status,'sVERIFY','aVRFYPCNCL','sCHECK','aCHCKPCNCL','sAPPROVE','aAPPRPCNCL'));
  RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------------------------------------
FUNCTION AddSalaryPaymentToTableToDo (
     p_PersonID    IN VARCHAR2,
    p_StatusCD    IN VARCHAR2,
    p_FileName IN VARCHAR2,
                p_FromAccount IN VARCHAR2,
    p_TXNO IN VARCHAR2,
    p_TotalAmount IN VARCHAR2,
    p_TotalCount IN VARCHAR2,
    p_CurrencyCode IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');
  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD9,FIELD5,
  AUTHCD,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'SALPAYTBL',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  p_FromAccount,p_TXNO,p_FileName,p_TotalAmount,p_TotalCount,
  DECODE(p_StatusCD,'sVERIFY','aVRFYSALTB','sCHECK','aCHCKSALTB','sAPPROVE','aAPPRSALTB'),
  p_CurrencyCode);

  RETURN ls_returncode;

END;
-----------------------------------------------------------------------------------------------------------------
FUNCTION AddFXOrdersToDo (
     p_PersonID      VARCHAR2,
    p_StatusCD      VARCHAR2,
    ps_trantype      VARCHAR2,
                pn_fromaccount   VARCHAR2,
    ps_currency      VARCHAR2,
    pn_to_account    VARCHAR2,
    ps_irsseco       VARCHAR2,
    ps_description   VARCHAR2,
    pn_fxamount      VARCHAR2,
    pn_totalamount   VARCHAR2,
    ps_periodtype    VARCHAR2,
    ps_periodlength  VARCHAR2,
    ps_rate          VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

     INSERT INTO TBL_TXTODO
    (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
     FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
     FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
  FIELD11,FIELD20,
  AUTHCD)
  VALUES
  (ln_txid,'FXORDER',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  ps_trantype,pn_fromaccount,ps_currency,ps_rate,pn_to_account,
  ps_irsseco,ps_periodtype,ps_periodlength,pn_fxamount,pn_totalamount,
  ps_description,ps_currency,
  DECODE(p_StatusCD,'sVERIFY','aVRFYFXORD','sCHECK','aCHCKFXORD','sAPPROVE','aAPPRFXORD','sCONTROL','aAPPRFXORD'));

  RETURN ls_returncode;

END;
---------------------------------------------------------------------------------------------
FUNCTION AddFXOrdersCancelToDo (p_PersonID      VARCHAR2,
           p_StatusCD      VARCHAR2,
           pn_txno          VARCHAR2,
                       pn_orderid       VARCHAR2,
           ps_trantype      VARCHAR2,
           pn_fromaccount   VARCHAR2,
           pn_toaccount   VARCHAR2,
           pn_rate      VARCHAR2,
           pn_amount        VARCHAR2,
           ps_currency     VARCHAR2,
           ps_periodtype    VARCHAR2,
           pn_periodlength  VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';

BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

     INSERT INTO TBL_TXTODO
    (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
     FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
     FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,
        FIELD20,
  AUTHCD)
  VALUES
  (ln_txid,'CNCLFXORD',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  pn_txno,pn_orderid,ps_trantype,pn_fromaccount,pn_toaccount,
  pn_rate,pn_amount,ps_currency,ps_periodtype ,pn_periodlength,
  ps_currency,
  DECODE(p_StatusCD,'sVERIFY','aVRFYFXCL','sCHECK','aCHCKFXCL','sAPPROVE','aAPPRFXCL'));

  RETURN ls_returncode;

END;
---------------------------------------------------------------------------------------------
FUNCTION AddArbitrageToDo (p_PersonID      VARCHAR2,
         p_StatusCD      VARCHAR2,
                     pn_fromaccountno  VARCHAR2,
         pn_toaccountno    VARCHAR2,
         ps_fromcurrency   VARCHAR2,
         ps_tocurrency     VARCHAR2,
         ps_parity         VARCHAR2,
         pn_fromamount     VARCHAR2,
         pn_toamount       VARCHAR2,
         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';

BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

     INSERT INTO TBL_TXTODO
    (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
     FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  FIELD6,FIELD7,FIELD20,
  AUTHCD)
  VALUES
  (ln_txid,'ARBITRAGE',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  pn_fromaccountno,pn_toaccountno,ps_fromcurrency,ps_tocurrency,ps_parity,
  pn_fromamount,pn_toamount,ps_tocurrency,
  DECODE(p_StatusCD,'sVERIFY','aVRFYARBIT','sCHECK','aCHCKARBIT','sAPPROVE','aAPPRARBIT','sCONTROL','aAPPRARBIT'));

  RETURN ls_returncode;

END;
------------------------------------------------------------------------------------
FUNCTION AddPayToAnotherCardToDo (p_PersonID    IN VARCHAR2,
          p_StatusCD    IN VARCHAR2,
                      p_FromAccount    IN VARCHAR2,
          p_ToCard      IN VARCHAR2,
          p_Description    IN VARCHAR2,
          p_Amount      IN VARCHAR2,
          P_CurCode     IN VARCHAR2,
          p_AccountOwner   IN VARCHAR2,
          p_CardOwner     IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  AUTHCD,FIELD9,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'P2OCARD',TO_NUMBER(p_PersonID),SYSDATE,p_StatusCD,
  p_FromAccount,p_ToCard,p_Description,p_AccountOwner,p_CardOwner,
  DECODE(p_StatusCD,'sVERIFY','aVRFYP2OC','sCHECK','aCHCKP2OC','sAPPROVE','aAPPRP2OC'),
  p_Amount,p_CurCode);

  RETURN ls_returncode;
END;
------------------------------------------------------------------------------------
FUNCTION DDSToDo(pn_PersonID       IN VARCHAR2,
                 ps_StatusCD       IN VARCHAR2,
                 pn_SupplierAccNo  IN VARCHAR2,
                 ps_SupplierName   IN VARCHAR2,
                   pn_PartnerAccNo   IN VARCHAR2,
                 ps_PartnerName    IN VARCHAR2,
                 pn_InvoiceNo      IN VARCHAR2,
                   ps_Description    IN VARCHAR2,
                   pn_Amount         IN VARCHAR2,
                   ps_CurrencyCd     IN VARCHAR2,
                 pd_InvoiceDate    IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ln_txid     NUMBER;
  ls_returncode  VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
  FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,
  FIELD6,FIELD7,
  AUTHCD,FIELD9,FIELD20)  /* FIELD 19 IS FOR COMM */
  VALUES
  (ln_txid,'DDSINVOICE',TO_NUMBER(pn_PersonID),SYSDATE,ps_StatusCD,
  pn_SupplierAccNo,ps_SupplierName,pn_PartnerAccNo,ps_PartnerName,pn_InvoiceNo,
  ps_Description,pd_InvoiceDate,
  DECODE(ps_StatusCD,'sVERIFY','aVRFYDDS','sCHECK','aCHCKDDS','sAPPROVE','aAPPRDDS','sCONTROL','aAPPRDDS'),
  pn_Amount,ps_CurrencyCd);

  RETURN ls_returncode;
END;
---------------------------------------------------------------------------------------------
FUNCTION AssignCustomerAccounts(ps_CustomerNo IN VARCHAR2,
                                 ps_PersonID      IN VARCHAR2,
                                ps_Params      IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  ls_counter NUMBER := 0;
  ls_hesap_no VARCHAR2(10);
  ns_hesap_no NUMBER;

BEGIN
     ls_counter    := to_number( substr(ps_Params,0,instr(ps_Params,'###',1,1)-1));
     DELETE FROM  TBL_ACCOUNT_ASSIGN
         WHERE PERSON_ID = ps_PersonID;

     FOR i IN 1..ls_counter LOOP
        ls_hesap_no:=substr(ps_Params,instr(ps_Params,'###',1,i)+3, instr(ps_Params,'###',1,i+1)-(instr(ps_Params,'###',1,i))-3);
         ns_hesap_no:=to_number(ls_hesap_no);

         INSERT INTO TBL_ACCOUNT_ASSIGN (PERSON_ID,HESAP_NO,CUSTOMER_NO)
                                   VALUES (ps_PersonID,ns_hesap_no,ps_CustomerNo);
     END LOOP;

     OPEN PC_REF FOR SELECT '-' FROM DUAL;
      RETURN ls_returncode;

 EXCEPTION WHEN OTHERS THEN
    OPEN PC_REF FOR SELECT '-' FROM DUAL;
    RETURN '000';
END;
--B-O-M ernestk 24032014 cqdb00000862 function to add card debt payment transaction for todo
/*******************************************************************************
    Name:           CardDebtPaymentToDo
    Prepared By:    Ernest Kuttubaev
    Modify Date:    24.03.2013
    Purpose:        Add card debt payment transaction for todo
*******************************************************************************/
FUNCTION CardDebtPaymentToDo (
                    ps_customer_id              VARCHAR2,
                    ps_person_id                VARCHAR2,
                    ps_from_acc                 VARCHAR2,
                    ps_amount                   VARCHAR2,
                    ps_card_no                  VARCHAR2,
                    ps_hashed_card_no           VARCHAR2,--ernestk 16062014 cqdb864 add hashed card no
                    ps_stat                     VARCHAR2,
                    ps_description              VARCHAR2,
                    ps_pseudopan            VARCHAR2, -- AdiletK CQ5541 PCI DSS pseudopan
                    pc_ref               OUT   cursorreferencetype) RETURN VARCHAR2
IS

 ln_txid NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
 ls_currency    varchar2 (3)  := cbs.pkg_hesap.hesaptandovizkodual(to_number(ps_from_acc));
BEGIN
 OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

  ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

  INSERT INTO TBL_TXTODO
  (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
   FIELD1,FIELD2,FIELD3,
   FIELD8,FIELD9,FIELD10,
   AUTHCD,FIELD20, FIELD7)  /* FIELD 19 IS FOR COMM */

   VALUES
   (ln_txid,'CARDDEBT',ps_person_id,SYSDATE,ps_stat,
   ps_from_acc,ps_hashed_card_no,to_char(SYSDATE, 'yyyymmdd'),--ernestk 16062014 cqdb864 added hashed_card_no
   ps_card_no,ps_amount,ps_description,
   DECODE(ps_stat,'sVERIFY','aVRFYCDP','sCHECK','aCHCKCDP','sAPPROVE','aAPPRCDP'),ls_currency, ps_pseudopan); -- AdiletK CQ5541 PCI DSS pseudopan

   OPEN pc_ref FOR select ln_txid from dual;


   RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS THEN
 pkg_log.addcustomlog('pkg_auth.carddebtpaymenttodo',sqlerrm);
 RETURN '999';
END;
--E-O-M ernestk 24032014 cqdb00000862 function to add card debt payment transaction for todo
---------------------------------------------------------------------------------------------
/*******************************************************************************
    Name:           ServicePaymentToDo
    Prepared By:    Almas Nurkhozhayev
    Modify Date:    14.04.2015
    Purpose:        To do service payments
*******************************************************************************/
FUNCTION ServicePaymentToDo(ps_fromaccountno   IN VARCHAR2,
                            ps_amount          IN VARCHAR2,
                            ps_person_id       IN VARCHAR2,
                            ps_description     IN VARCHAR2,
                            ps_institution     IN VARCHAR2,
                            ps_phone_area_code IN VARCHAR2,
                            ps_phone_no        IN VARCHAR2,
                            ps_service_code    IN VARCHAR2,
                            ps_service_no      IN VARCHAR2,
                            ps_status          IN VARCHAR2,
                            pc_ref             OUT   cursorreferencetype) RETURN VARCHAR2 IS

    ln_txid NUMBER;
    ls_returncode  VARCHAR2 (3)  := '000';
    ls_currency    varchar2 (3)  := cbs.pkg_hesap.hesaptandovizkodual(to_number(ps_fromaccountno));

    --BOM chyngyzo cq5220 Dealer Payments 09.12.2015
    dealer_payment_error EXCEPTION;
    ls_return VARCHAR2(3);
    ls_result VARCHAR2(100);
    ls_error_code VARCHAR2(100);
    ls_error_desc VARCHAR2(100);
    ls_dealer_name VARCHAR2(100);
    pc_result CursorReferenceType;
    --EOM chyngyzo cq5220 Dealer Payments 09.12.2015
BEGIN
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

    ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');

    --BOM chyngyzo cq5220 Dealer Payments 09.12.2015
    IF PKG_SOA_INQUIRY.isDealerPayment(ps_institution) = 1 THEN
        ls_return := pkg_soa_inquiry.getWsDealerInfo(ps_institution,  ps_service_no, pc_result);
        FETCH pc_result INTO ls_result, ls_error_code, ls_error_desc, ls_dealer_name;
        CLOSE pc_result;
        IF  NVL(ls_result, 'ERROR') <> 'OK' THEN
            RAISE dealer_payment_error;
        END IF;
    END IF;
    --EOM chyngyzo cq5220 Dealer Payments 09.12.2015

    INSERT INTO TBL_TXTODO
    (TX_NO, TRANCD, MAKERID, MAKEDATE, STATUS,
    FIELD10, FIELD9, FIELD2, FIELD20, FIELD5,
    FIELD6, FIELD7, FIELD8, FIELD4,
    AUTHCD)
    VALUES
    (ln_txid, 'PAYMENTS', ps_person_id, SYSDATE, ps_status,
    ps_fromaccountno, ps_amount, ps_description, ls_currency, ps_institution,
    ps_phone_area_code, ps_phone_no, ps_service_code, ps_service_no,
    DECODE(ps_status,'sVERIFY','aVRFYPYM','sCHECK','aCHCKPYM','sAPPROVE','aAPPRPYM'));

    OPEN pc_ref FOR select ln_txid from dual;

   RETURN ls_returncode;
EXCEPTION
    WHEN dealer_payment_error THEN  --chyngyzo cq5220 Dealer Payments 09.12.2015
        pkg_log.addcustomlog('pkg_auth.ServicePaymentToDo',sqlerrm, ls_result||'###'||ls_error_code||'###'||ls_error_desc);
        RETURN (ls_error_code + 450);
    WHEN OTHERS THEN
        pkg_log.addcustomlog('pkg_auth.ServicePaymentToDo',sqlerrm);
        RETURN '999';
END;

/******************************************************************************
   NAME       : FUNCTION  SwiftTodo
   Created By :  Chyngyz Omurov
   Date       : 10.03.2015
   Purpose   : Save SWIFT info to table TBL_TXTODO cq509
******************************************************************************/
FUNCTION SwiftToDo(
                    ps_sender_acc_no IN VARCHAR2,
                    ps_country_code IN VARCHAR2,
                    ps_currency IN VARCHAR2,
                    ps_amount IN VARCHAR2,
                    ps_value_date IN VARCHAR2,
                    ps_charge_party IN VARCHAR2, --who pays charge,  (BEN, OUR, GOUR)
                    ps_stat_code IN VARCHAR2,
                    ps_description IN VARCHAR2,
                    ps_comm_acc_no IN VARCHAR2,
                    ps_charge_amount IN VARCHAR2,
                    ps_ben_acc_no IN VARCHAR2,
                    ps_ben_name IN VARCHAR2,
                    ps_ben_address IN VARCHAR2,
                    ps_ben_swiftcode IN VARCHAR2, --bic code of beneficiary bank
                    ps_ii_bic IN VARCHAR2,                 --intermediary institution bic code

                    ps_person        IN VARCHAR2,
                    ps_tran_status    IN VARCHAR2,
                    ps_contract_date IN VARCHAR2,
                    ps_contract_no IN VARCHAR2,
                    ps_corrbank_name IN VARCHAR2,
                    ps_filename IN VARCHAR2,
                    ps_ben_bank_branch IN VARCHAR2,

                    ps_invoice_date IN VARCHAR2,
                    ps_invoice_no IN VARCHAR2,
                    
                    ps_UAE_stat_code IN VARCHAR2, --Bakdoolot ibc-52 25.01.22
                    
                    ps_Inn_and_Kpp IN VARCHAR2, --Esen Omurchiev ibc-74 01.04.2022

                    pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS

    ln_txid NUMBER;
    ls_returncode  VARCHAR2 (3)  := '000';

    TimeException    EXCEPTION;

     ln_cust_no NUMBER;
    ln_cdf_rate NUMBER := 0;
    ln_cdf_rate_standard NUMBER:=0;
    ln_region NUMBER:=1;

    ln_ben_const NUMBER:=0;
    ln_ben_prop NUMBER:=0;
    ln_ben_min NUMBER:=0;
    ln_ben_max NUMBER:=0;

    ln_our_const NUMBER:=0;
    ln_our_prop NUMBER:=0;
    ln_our_min NUMBER:=0;
    ln_our_max NUMBER:=0;

    ln_gour_const NUMBER:=0;
    ln_gour_prop NUMBER:=0;
    ln_gour_min NUMBER:=0;
    ln_gour_max NUMBER:=0;
BEGIN

   -- OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

    /*ls_returncode:=cbs.pkg_int_limit.CheckTimeLimit('SWIFT');

    IF ls_returncode<>'000' THEN
        ls_returncode := '059';
        RAISE TimeException;
    ELSE
        ls_returncode:='000';
    END IF;*/

    ln_txid:=Pkg_Common.GetSequenceID('TX_TODO');


    BEGIN --save to db cdf rate used for cdf calculations

        BEGIN --get region of the branch in which account was opened
           select decode(B.REGION_NO, 1, 1, 2), H.MUSTERI_NO INTO ln_region, ln_cust_no
            from cbs_hesap h, CBS_BOLUM b
            where H.SUBE_KODU=B.KODU and h.hesap_no= ps_sender_acc_no;
        EXCEPTION WHEN NO_DATA_FOUND THEN
            ln_region := 1; --BISHKEK
        END;

        --get regional standard CDF rate (for all customers)
        CBS.pkg_tx4054.Get_REGION_CDF_Rates(ps_currency, ln_region, ln_cdf_rate_standard);

        --get special CDF rate
        CBS.pkg_tx4052.Get_Special_Cdf_Rates(ps_currency,ln_cust_no, ln_cdf_rate,ln_ben_prop,ln_ben_const,
                                                                    ln_ben_min,ln_ben_max,ln_our_prop,ln_our_const,ln_our_min,
                                                                    ln_our_max,ln_gour_prop,ln_gour_const,ln_gour_min,ln_gour_max);

        ln_cdf_rate := nvl(ln_cdf_rate, ln_cdf_rate_standard); --if cdf rate is not defined for this customer set standard rate

        EXCEPTION
            WHEN OTHERS THEN
                ln_cdf_rate := 0;
    END;

    IF ps_UAE_stat_code IS NOT NULL THEN
        INSERT INTO CORPINT.TBL_TXTODO_UAE_DETAILS(TX_NO, STAT_CODE)
        VALUES(ln_txid, ps_UAE_stat_code); 
    END IF; --Bakdoolot ibc-52 25.01.22
    
    log_at('check bin', ps_Inn_and_Kpp);
    
    INSERT INTO TBL_TXTODO
    (TX_NO, TRANCD, MAKERID, MAKEDATE, STATUS,
     FIELD1, FIELD2, FIELD3, FIELD4, FIELD5,
     FIELD6, FIELD7, FIELD8, FIELD9, FIELD10,
     FIELD11, FIELD12, FIELD13, FIELD14, FIELD15,
     FIELD16, FIELD17, FIELD18, FIELD19, FIELD20,
     AUTHCD,FIELD21)
    VALUES
    (ln_txid, 'SWIFT', ps_person, SYSDATE, ps_tran_status,
     ps_ben_address, ps_description, ps_stat_code, ps_country_code, ps_value_date,
     ps_corrbank_name, to_char(PKG_MUHASEBE.BANKA_TARIHI_BUL, 'DD/MM/YYYY'), ps_filename, ps_amount, ps_ben_acc_no,
     ps_charge_party, ps_sender_acc_no||'###'||ps_comm_acc_no, ps_ben_swiftcode, ps_ben_name, ps_ii_bic,
     ps_contract_no||'###'||ps_contract_date, ps_invoice_no||'###'||ps_invoice_date,  ps_ben_bank_branch, REPLACE(ps_charge_amount||'###'||ln_cdf_rate,',','.'), ps_currency, --esen omurchiev added reaplace()
     DECODE(ps_tran_status,'sVERIFY','aVRFYSWIFT','sCHECK','aCHCKSWIFT','sAPPROVE','aAPPRSWIFT','sCONTROL','aAPPRSWIFT', 'sBANKAPPR', 'sBANKAPPR'),ps_Inn_and_Kpp);

    OPEN pc_ref FOR SELECT ln_txid FROM DUAL;

    RETURN ls_returncode;
EXCEPTION
    WHEN TimeException THEN
        RETURN ls_returncode;
    WHEN OTHERS THEN
        pkg_log.addcustomlog('SWIFTTODO',SQLERRM);
        RETURN '708';
END;



/*******************************************************************************
    Name        : FUNCTION AddSalaryPaymentList
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Add Salary Payment List
*******************************************************************************/
FUNCTION AddSalaryPaymentList(pn_tx_no NUMBER,
                                                            pn_company_acc_no NUMBER,
                                                            ps_staff_acc_no VARCHAR2,
                                                            ps_name VARCHAR2,
                                                            ps_surname VARCHAR2,
                                                            ps_patronymic VARCHAR2,
                                                            ps_order NUMBER,
                                                            ps_status VARCHAR2,
                                                            pn_amount NUMBER,
                                                            ps_currency VARCHAR2,
                                                            pn_company_cust_no NUMBER,
                                                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
    ln_txid NUMBER;
BEGIN
    OPEN pc_ref FOR  SELECT ln_txid FROM dual;

    IF TO_NUMBER(pn_tx_no)=0 THEN
        ln_txid := Pkg_Common.GetSequenceID('TX_TODO');
   ELSE
        ln_txid := pn_tx_no;
   END IF;

   INSERT INTO TBL_SALARY_PAYMENT_TX
   (TODO_TXNO, COMPANY_ACC_NO, COMPANY_CUST_NO, STAFF_ACC_NO, NAME, SURNAME, PATRONYMIC, ORDERING, STATUS, AMOUNT, CURRENCY)
   VALUES
   (ln_txid, pn_company_acc_no, pn_company_cust_no, ps_staff_acc_no, ps_name, ps_surname, ps_patronymic, ps_order, ps_status, pn_amount, ps_currency);

    OPEN pc_ref FOR  SELECT ln_txid FROM dual;

   RETURN '000';
 EXCEPTION
    WHEN OTHERS THEN
      pkg_log.addcustomlog('pkg_auth.AddSalaryPaymentList',sqlerrm);
        RETURN '999';
END;

/*******************************************************************************
    Name        : FUNCTION AddSalaryPaymentToDo
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Add Salary Payment To Do
*******************************************************************************/
 FUNCTION AddSalaryPaymentToDo(pn_tx_no NUMBER,
                                                               ps_type VARCHAR2,
                                                               pn_fromAccount NUMBER,
                                                               pn_totalAmount NUMBER,
                                                               ps_currency VARCHAR2,
                                                               ps_commType VARCHAR2,
                                                               ps_commAmount VARCHAR2,
                                                               ps_description VARCHAR2,
                                                               ps_fileName VARCHAR2,
                                                               pn_staffCount NUMBER,
                                                               ps_transStatus  VARCHAR2,
                                                               ps_personId VARCHAR2,
                                                               ps_paymentCode VARCHAR2,
                                                               ps_valueDate VARCHAR2,
                                                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
    ls_return VARCHAR2(3) := '000';
    ln_islem_no          NUMBER;
BEGIN

    OPEN pc_ref FOR  SELECT ls_return FROM dual;

    IF TO_NUMBER(pn_tx_no)=0 THEN
        pkg_log.addcustomlog('pkg_auth.AddSalaryPaymentToDo','pn_tx_no is not set!');
        RETURN '999';
   END IF;

    ln_islem_no :=  Pkg_Tx.islem_no_al;

   INSERT INTO TBL_TXTODO
   (TX_NO, TRANCD, MAKERID, MAKEDATE, STATUS,
    FIELD1, FIELD2, FIELD3, FIELD4, FIELD5,
    FIELD6, FIELD7, FIELD8, FIELD9, FIELD10,
    FIELD11, FIELD12,
    AUTHCD)
    VALUES
    (pn_tx_no, 'SALARY', ps_personId, SYSDATE, ps_transStatus,
     pn_fromAccount, to_char(pn_totalAmount, '999999999999.99'), ps_currency, ps_commType, NVL(ps_commAmount, 0),
     ps_type, ps_description, ps_fileName, pn_staffCount, ps_paymentCode,
     ps_valueDate, ln_islem_no,
     DECODE(ps_transStatus,'sVERIFY','aVRFYSLRY','sCHECK','aCHCKSLRY','sAPPROVE','aAPPRSLRY','sCONTROL','aAPPRSLRY', 'sBANKAPPR', 'sBANKAPPR'));

    RETURN ls_return;
EXCEPTION
    WHEN OTHERS THEN
      pkg_log.addcustomlog('pkg_auth.AddSalaryPaymentToDo',sqlerrm);
      RETURN '999';
END;

END Pkg_Auth;
/

