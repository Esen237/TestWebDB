create PACKAGE BODY         PKG_CINT_LIMIT IS

/******************************************************************************
   NAME       : FUNCTION  GetLimitInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose    : Display Limit Information
******************************************************************************/
FUNCTION GetLimitInfo(pn_CustomerId IN VARCHAR2,
                      pn_PersonId   IN VARCHAR2,
                      ps_TranCd     IN VARCHAR2,
                      ps_ChannelCd  IN VARCHAR2,
                      pn_Rates      IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode       VARCHAR2(3):='000';
    ln_Count            NUMBER;
    ln_DailyLimit       NUMBER ;
    ls_DailyLimitCurr   VARCHAR2(3) ;
    ln_UsedLimit        NUMBER ;
    ln_PersonLimit      NUMBER;
    ls_PersonLimitCurr  VARCHAR2(3) ;
    ln_Remain           NUMBER;
    ln_DailyLimitKZ    NUMBER ;
    ln_PersonLimitKZ    NUMBER ;
    ln_UsedKZ           NUMBER ;
    ln_RemainKZ         NUMBER;
    ln_DailyLimitRate   NUMBER;
    ln_PersonLimitRate  NUMBER;
    ln_Rate1            NUMBER;
    ln_Rate2            NUMBER;
    LimitErrorException     EXCEPTION;

BEGIN
    IF ps_ChannelCd='cDKBRIB' THEN

        OPEN pc_ref FOR
        SELECT a.DAILY_LIMIT, a.CURRENCY_CODE, Pkg_Limit.GetUsedLimit(pn_CustomerId,pn_PersonId,ps_TranCd,ps_ChannelCd) used,
               a.ONETIME_LIMIT, a.CURRENCY_CODE,(a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_CustomerId,pn_PersonId,ps_TranCd,ps_ChannelCd)) kalan
        FROM TBL_LIMIT_DEFAULTS a
        WHERE a.TRAN_CD    = ps_TranCd
        AND   a.CHANNEL_CD = ps_ChannelCd
        AND   a.PERSON_ID  = pn_personid;

    ELSE --cDKBCIB
        SELECT COUNT(*)
        INTO ln_Count
        FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
        WHERE a.CUSTOMER_ID   = TO_NUMBER(pn_CustomerId)
        AND   a.CUSTOMER_ID   = b.CUSTOMER_NO
        AND   a.TRAN_CD       = ps_TranCd
        AND   a.CHANNEL_CD    = ps_ChannelCd
        AND   b.PERSON_ID     = TO_NUMBER(pn_PersonId);

        IF ln_Count = 0 THEN
            RAISE LimitErrorException;
        END IF;

        SELECT a.DAILY_LIMIT, a.LIMIT_CURRENCY, DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0) used,
               b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY, (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0)) remain
        INTO   ln_DailyLimit, ls_DailyLimitCurr, ln_UsedLimit, ln_PersonLimit, ls_PersonLimitCurr, ln_Remain
        FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
        WHERE a.CUSTOMER_ID   = TO_NUMBER(pn_CustomerId)
        AND   a.CUSTOMER_ID   = b.CUSTOMER_NO
        AND   a.TRAN_CD       = ps_TranCd
        AND   a.CHANNEL_CD    = ps_ChannelCd
        AND   b.PERSON_ID     = TO_NUMBER(pn_PersonId);

        IF ls_DailyLimitCurr = 'USD' THEN
            ln_DailyLimitRate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(pn_Rates,';',0),',',''),'.',','));
        ELSIF ls_DailyLimitCurr = 'EUR' THEN
            ln_DailyLimitRate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(pn_Rates,';',1),',',''),'.',','));
        ELSE
            ln_DailyLimitRate :=1;
        END IF;

        ln_DailyLimitKZ := ln_DailyLimit * ln_DailyLimitRate;
        ln_RemainKZ     := ln_Remain * ln_DailyLimitRate;
        ln_UsedKZ       := ln_UsedLimit * ln_DailyLimitRate;

        IF ls_PersonLimitCurr = 'USD' THEN
            ln_PersonLimitRate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(pn_Rates,';',0),',',''),'.',','));
        ELSIF ls_PersonLimitCurr = 'EUR' THEN
            ln_PersonLimitRate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(pn_Rates,';',1),',',''),'.',','));
        ELSE
            ln_PersonLimitRate:=1;
        END IF;

        ln_PersonLimitKZ:= ln_PersonLimit * ln_PersonLimitRate;

        OPEN pc_ref FOR
        SELECT ln_DailyLimitKZ, PKG_GENEL.LC_AL, DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
        ln_PersonLimitKZ, PKG_GENEL.LC_AL, ln_RemainKZ
        FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
        WHERE a.CUSTOMER_ID   = TO_NUMBER(pn_CustomerId)
        AND   a.CUSTOMER_ID   = b.CUSTOMER_NO
        AND   a.TRAN_CD       = ps_TranCd
        AND   a.CHANNEL_CD    = ps_ChannelCd
        AND   b.PERSON_ID     = TO_NUMBER(pn_PersonId);

    END IF;--ChannelCD

    RETURN ls_returncode;

EXCEPTION
         WHEN NO_DATA_FOUND THEN
               Pkg_Cint_Log.ADDCUSTOMLOG('CheckLimit',SQLERRM,ls_returncode);
               ls_returncode:='050';
               RETURN ls_returncode;
         WHEN LimitErrorException THEN
               OPEN pc_ref FOR SELECT '-' FROM dual;
               ls_returncode:='053';
               RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  CheckLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose   : Check Limits
******************************************************************************/
FUNCTION CheckLimit(pn_CustomerID  IN VARCHAR2,
                    ps_TranCd      IN VARCHAR2,
                    pn_Amount      IN VARCHAR2,
                    pn_PersonId    IN VARCHAR2,
                    ps_ChannelCd   IN VARCHAR2,
                    pn_Rates       IN VARCHAR2,
                    ps_CurrencyCd  IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode       VARCHAR2(3):='000';
    ln_DailyLimit       NUMBER ;
    ls_DailyLimitCurr   VARCHAR2(3) ;
    ln_UsedLimit        NUMBER ;
    ln_PersonLimit      NUMBER ;
    ls_PersonLimitCurr  VARCHAR2(3) ;
    ln_Remain           NUMBER;
    ln_DailyLimit_kz    NUMBER ;
    ln_PersonLimitKZ    NUMBER ;
    ln_UsedKZ           NUMBER ;
    ln_RemainKZ         NUMBER;
    ln_DailyLimitRate   NUMBER;
    ln_PersonLimitRate  NUMBER;
    ln_Rate1            NUMBER;
    ln_Rate2            NUMBER;
    ln_AmountRate       NUMBER;
    ln_Amount           NUMBER;
    LimitErrorException     EXCEPTION;
    ln_Rates            varchar2(15):=replace(pn_Rates,',','.');

BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;

    IF ps_ChannelCd='cDKBRIB' THEN

        SELECT  a.DAILY_LIMIT, a.CURRENCY_CODE, Pkg_Limit.GetUsedLimit(pn_CustomerId,pn_PersonId,ps_TranCd,ps_ChannelCd) used,
                a.ONETIME_LIMIT, a.CURRENCY_CODE,(a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_CustomerId,pn_PersonId,ps_TranCd,ps_ChannelCd)) kalan
        INTO    ln_DailyLimit, ls_DailyLimitCurr, ln_UsedLimit, ln_PersonLimit, ls_PersonLimitCurr, ln_Remain
        FROM TBL_LIMIT_DEFAULTS a
        WHERE PERSON_ID = TO_NUMBER(pn_PersonId)
        AND TRAN_CD     = ps_TranCd
        AND CHANNEL_CD  = ps_ChannelCd;

    ELSE--cDKBCIB

        SELECT a.DAILY_LIMIT,     a.LIMIT_CURRENCY,     DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
               b.ISLEM_LIMIT,     b.ISLEM_LIMIT_CY,     (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan
        INTO  ln_DailyLimit, ls_DailyLimitCurr, ln_UsedLimit, ln_PersonLimit, ls_PersonLimitCurr, ln_Remain
        FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
        WHERE a.CUSTOMER_ID   = pn_CustomerId
        AND   a.CUSTOMER_ID   = b.CUSTOMER_NO
        AND   a.TRAN_CD       = ps_TranCd
        AND   a.CHANNEL_CD    = ps_ChannelCd
        AND   b.PERSON_ID     = pn_PersonId ;

    END IF;--CHannelCD

    IF ls_DailyLimitCurr = 'USD' THEN
        ln_DailyLimitRate := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'99999999999.99');
    ELSIF ls_DailyLimitCurr = 'EUR' THEN
        ln_DailyLimitRate := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'99999999999.99');
    ELSE
        ln_DailyLimitRate := 1;
    END IF;

    ln_RemainKZ := ln_Remain * ln_DailyLimitRate;

    IF ls_PersonLimitCurr = 'USD' THEN
        ln_PersonLimitRate := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'99999999999.99');
    ELSIF ls_PersonLimitCurr= 'EUR' THEN
        ln_PersonLimitRate := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'99999999999.99');
    ELSE
        ln_PersonLimitRate:= 1;
    END IF;
    
    ln_PersonLimitKZ   := ln_PersonLimit * ln_PersonLimitRate;

    IF ps_CurrencyCd = 'KGS' THEN
        ln_Amount := TO_NUMBER(pn_Amount,'99999999999.99');
    ELSIF ps_CurrencyCd = 'USD'    THEN
        ln_AmountRate := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'99999999999.99');
        ln_Amount := TO_NUMBER(pn_Amount,'99999999999.99') * ln_AmountRate ;
    ELSIF ps_CurrencyCd = 'EUR'    THEN
        ln_AmountRate := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'99999999999.99');
        ln_Amount := TO_NUMBER(pn_Amount,'99999999999.99') * ln_AmountRate ;
    END IF;

    IF ps_TranCd NOT IN ('B2BHVL','CLEARCNCL') THEN
        IF ln_Amount > ln_RemainKZ THEN
           ls_returncode:='051';
           RAISE LimitErrorException;
        END IF;
    END IF;

    IF ln_Amount > ln_PersonLimitKZ THEN
       ls_returncode:='052';
       RAISE LimitErrorException;
    END IF;

  RETURN ls_returncode;

EXCEPTION
         WHEN LimitErrorException THEN
               RETURN ls_returncode;
         WHEN OTHERS THEN
              Pkg_Log.AddCustomLog(substr(SQLERRM, 1,1000),DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, pn_Rates);
              ls_returncode:='050';
              RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  UpdateLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose   : Update Limit
******************************************************************************/
FUNCTION UpdateLimit(pn_CustomerId   IN VARCHAR2,
                     ps_TranCd       IN VARCHAR2,
                     pn_Amount       IN VARCHAR2,
                     ps_CurrencyCd   IN VARCHAR2,
                     ps_PersonId     IN VARCHAR2,
                     ps_ChannelCd    IN VARCHAR2,
                     pn_Rates        IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode       VARCHAR2(3):='000';
    ln_Amount           NUMBER;
    ln_AmountFC         NUMBER;
    ln_AmountKZ         NUMBER;
    ln_Rate1            NUMBER;
    ln_Rate2            NUMBER;
    ln_DailyLimit       NUMBER;
    ls_DailyLimitCurr   VARCHAR2(3);
    ln_UsedLimit        NUMBER;
    ln_PersonLimit      NUMBER;
    ls_PersonLimitCurr  VARCHAR2(3);
    ln_Remain           NUMBER;
    ld_Date             VARCHAR2(8);
    ln_Count            NUMBER;
    ln_Rates            varchar2(15):=replace(pn_Rates,',','.');

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
    
    IF ps_ChannelCd='cDKBRIB' THEN

        SELECT a.DAILY_LIMIT, a.CURRENCY_CODE, Pkg_Limit.GetUsedLimit(pn_CustomerId,ps_PersonId,ps_TranCd,ps_ChannelCd) used,
               a.ONETIME_LIMIT, a.CURRENCY_CODE, (a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_CustomerId,ps_PersonId,ps_TranCd,ps_ChannelCd)) kalan
        INTO   ln_DailyLimit, ls_DailyLimitCurr, ln_UsedLimit, ln_PersonLimit, ls_PersonLimitCurr, ln_Remain
        FROM TBL_LIMIT_DEFAULTS a
        WHERE PERSON_ID = TO_NUMBER(ps_PersonId)
        AND TRAN_CD     = ps_TranCd
        AND CHANNEL_CD  = ps_ChannelCd;

        ln_Amount := TO_NUMBER(pn_amount,'999999999999999.9999');
        ld_Date   := TO_CHAR(SYSDATE,'YYYYMMDD');

        IF ps_CurrencyCd = ls_DailyLimitCurr THEN
            ln_Amount := ln_UsedLimit + ln_Amount;
        ELSE
            IF (ps_CurrencyCd NOT IN ('KGS','USD','EUR'))AND(ps_TranCd<>'ARBITRAGE') THEN
                select pkg_kur.yuvarla(ps_CurrencyCd, pkg_kur.doviz_doviz_karsilik (ps_CurrencyCd, 'KGS', NULL, ln_Amount, 1, NULL, NULL, 'O', DECODE(ps_TranCd,'EXCHNGBUY','S','A') ))
                into ln_Amount
                from dual;
                
                ln_Rate1:=1;
            ELSE
                IF ps_CurrencyCd = 'USD'      THEN
                    ln_Rate1 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'999999999999999.9999');
                ELSIF ps_CurrencyCd = 'EUR' THEN
                    ln_Rate1 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'999999999999999.9999');
                ELSE

                    ln_Rate1 := 1;
                END IF;
            END IF;
            
            ln_AmountKZ := ln_Amount * ln_Rate1;

            IF ls_DailyLimitCurr = 'USD'      THEN
                ln_Rate2 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'999999999999999.9999');
            ELSIF ls_DailyLimitCurr = 'EUR' THEN
                ln_Rate2 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'999999999999999.9999');
            ELSE
                ln_Rate2 := 1;
            END IF;

                ln_AmountFC := ln_AmountKZ / ln_Rate2;
                ln_Amount   := ln_UsedLimit + ln_AmountFC;
        END IF;

        SELECT COUNT(*)
        INTO ln_count
        FROM TBL_LIMIT_USED
        WHERE PERSON_ID = TO_NUMBER(ps_PersonId)
        AND TRAN_CD     = ps_TranCd
        AND CHANNEL_CD  = ps_ChannelCd;

        IF ln_count=0 THEN
            INSERT INTO TBL_LIMIT_USED
            (PERSON_ID, USED_DATE, USED_LIMIT, TRAN_CD, CHANNEL_CD)
            VALUES
            (TO_NUMBER(ps_PersonId), TO_DATE(ld_Date,'YYYYMMDD'), ln_Amount, ps_TranCd,ps_ChannelCd);
        ELSE
            UPDATE TBL_LIMIT_USED
            SET USED_LIMIT  = ln_Amount,
                USED_DATE   = TO_DATE(ld_Date,'YYYYMMDD')
            WHERE PERSON_ID = TO_NUMBER(ps_PersonId)
            AND TRAN_CD     = ps_TranCd
            AND CHANNEL_CD  = ps_ChannelCd;
        END IF;

    ELSE--cDKBCIB

        SELECT a.DAILY_LIMIT, a.LIMIT_CURRENCY, DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
               b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY, (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan
        INTO   ln_DailyLimit, ls_DailyLimitCurr, ln_UsedLimit, ln_PersonLimit, ls_PersonLimitCurr, ln_Remain
        FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
        WHERE a.CUSTOMER_ID   = TO_NUMBER(pn_CustomerId)
        AND   a.CUSTOMER_ID   = b.CUSTOMER_NO
        AND   a.TRAN_CD       = ps_TranCd
        AND   a.CHANNEL_CD    = ps_ChannelCd
        AND   b.PERSON_ID     = TO_NUMBER(ps_personid);

        ln_Amount := TO_NUMBER(pn_Amount,'99999999999.99');
        ld_Date   := TO_CHAR(SYSDATE,'YYYYMMDD');

        IF ps_CurrencyCd = ls_DailyLimitCurr THEN
            ln_Amount := ln_UsedLimit + ln_Amount;
        ELSE

            IF (ps_CurrencyCd NOT IN ('KGS','USD','EUR'))AND(ps_TranCd<>'ARBITRAGE') THEN
                select pkg_kur.yuvarla(ps_CurrencyCd, pkg_kur.doviz_doviz_karsilik (ps_CurrencyCd, 'KGS', NULL, ln_Amount, 1, NULL, NULL, 'O', DECODE(ps_TranCd,'EXCHNGBUY','S','A') ))
                into ln_Amount
                from dual;
                
                ln_Rate1:=1;
            ELSE
                IF ps_CurrencyCd = 'USD'      THEN
                    ln_Rate1 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'999999999999999.9999');
                ELSIF ps_CurrencyCd = 'EUR' THEN
                    ln_Rate1 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'999999999999999.9999');
                ELSE

                    ln_Rate1 := 1;
                END IF;
            END IF;

            ln_AmountKZ := ln_Amount * ln_Rate1;

            IF ls_DailyLimitCurr = 'USD'      THEN
                ln_Rate2 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'999999999999999.9999');
            ELSIF ls_DailyLimitCurr = 'EUR' THEN
                ln_Rate2 := TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'999999999999999.9999');
            ELSE
                ln_Rate2 := 1;
            END IF;

                ln_AmountFC := ln_AmountKZ / ln_Rate2;
                ln_Amount   := ln_UsedLimit + ln_AmountFC;
        END IF;

        UPDATE TBL_APPROVAL_TRAN
        SET USED_LIMIT    = case when ln_Amount > 0 then ln_Amount else 0 end,
            LIMIT_DATE    = ld_Date
        WHERE CUSTOMER_ID = TO_NUMBER(pn_CustomerId)
        AND TRAN_CD       = ps_TranCd
        AND CHANNEL_CD    = ps_ChannelCd;

    END IF;--channel

    RETURN ls_returncode;

EXCEPTION
         WHEN OTHERS THEN
                 Pkg_Log.AddCustomLog('LIM-4',SQLERRM);
         RETURN '050';
END;
/******************************************************************************
   NAME       : FUNCTION  CheckLimitForAdminSite
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Check Admin sites limit
******************************************************************************/
FUNCTION CheckLimitForAdminSite(pn_PersonId    IN VARCHAR2,
                                pn_CustomerId  IN VARCHAR2,
                                pn_Amount      IN VARCHAR2,
                                ps_CurrencyCd  IN VARCHAR2,
                                pn_Rates       IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_statement         VARCHAR2(2000);
    ls_returncode        VARCHAR2(3):='000';
    ln_Amount            NUMBER;
    ln_PerTranLimit      NUMBER;
    ls_PerTranLimitCurr  VARCHAR2(3);
    ln_Rate1             NUMBER;
    ln_Rate2             NUMBER;
    ln_AmountKZ          NUMBER;
    ln_PerTranLimitKZ    NUMBER;
    TransactionError     EXCEPTION;
    LimitErrorException  EXCEPTION;
    ln_Rates            varchar2(15):=replace(pn_Rates,',','.');

BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;

    ln_Amount := TO_NUMBER(pn_Amount,'99999999999.99');

    SELECT IMZA_SIRKULERI_IMZA_LIMIT, IMZA_SIRKULERI_CY
    INTO   ln_PerTranLimit, ls_PerTranLimitCurr
    FROM TBL_COMPANY
    WHERE CUSTOMER_NO   = TO_NUMBER(pn_CustomerId)
    AND   PERSON_ID     = TO_NUMBER(pn_PersonId);


    IF ps_CurrencyCd = 'USD' THEN
        ln_Rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'99999999999.99');
    ELSIF ps_CurrencyCd = 'EUR' THEN
        ln_Rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'99999999999.99');
    ELSE
        ln_Rate1:=1;
    END IF;

        ln_AmountKZ := ln_Amount * ln_Rate1;

    IF ls_PerTranLimitCurr = 'USD' THEN
        ln_Rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',0),'99999999999.99');
    ELSIF ls_PerTranLimitCurr = 'EUR' THEN
        ln_Rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ln_Rates,';',1),'99999999999.99');
    ELSE
        ln_Rate2:=1;
    END IF;

        ln_PerTranLimitKZ := ln_PerTranLimit * ln_Rate2;

    IF ln_AmountKZ > ln_PerTranLimitKZ
    THEN
      ls_returncode:='054';
      RAISE LimitErrorException;
    END IF;

    RETURN ls_returncode;

EXCEPTION
         WHEN LimitErrorException THEN
               RETURN ls_returncode;
         WHEN OTHERS THEN
               Pkg_Log.AddCustomLog(SQLERRM,ln_Rates);
               RETURN '050';
END;
/******************************************************************************
   NAME       : FUNCTION  GetUsedLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Display used limit
******************************************************************************/
FUNCTION GetUsedLimit(pn_CustomerId IN NUMBER,
                      pn_PersonId   IN NUMBER,
                       ps_TranCd     IN VARCHAR2,
                       ps_ChannelCd  IN VARCHAR2) RETURN NUMBER IS

    ln_UsedLimit NUMBER;

BEGIN

     SELECT NVL(USED_LIMIT,0)
     INTO ln_UsedLimit
     FROM TBL_LIMIT_USED
     WHERE PERSON_ID   = TO_NUMBER(pn_PersonId)
     AND   TRAN_CD     = ps_TranCd
     AND   CHANNEL_CD  = ps_ChannelCd
     AND   USED_DATE =  TO_DATE(TO_CHAR(SYSDATE,'DD.MM.YYYY'),'DD.MM.YYYY');

     RETURN ln_UsedLimit;

EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN 0;
END;
/******************************************************************************
   NAME       : FUNCTION  GetIBLimitInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 05.06.08
   Purpose    : Display Limit Information
******************************************************************************/
FUNCTION GetIBLimitInfo(pn_CustomerId IN VARCHAR2,
                      pn_PersonId   IN VARCHAR2,
                      ps_TranCd     IN VARCHAR2,
                      ps_ChannelCd  IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode       VARCHAR2(3):='000';
    ln_Count            NUMBER;
    ln_DailyLimit       NUMBER ;
    ls_DailyLimitCurr   VARCHAR2(3) ;
    ln_UsedLimit        NUMBER ;
    ln_PersonLimit      NUMBER ;
    ls_PersonLimitCurr  VARCHAR2(3) ;
    ln_Remain           NUMBER;
    ln_DailyLimitKZ    NUMBER ;
    ln_PersonLimitKZ    NUMBER ;
    ln_UsedKZ           NUMBER ;
    ln_RemainKZ         NUMBER;
    ln_DailyLimitRate   NUMBER;
    ln_PersonLimitRate  NUMBER;
    ln_Rate1            NUMBER;
    ln_Rate2            NUMBER;
    LimitErrorException     EXCEPTION;

BEGIN
    IF ps_ChannelCd='cDKBRIB' THEN

        OPEN pc_ref FOR
        SELECT a.DAILY_LIMIT, a.LIMIT_CURRENCY, LIMIT_PER_TRAN, DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0) used,
               (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0)) remain
        FROM TBL_PERSON_AUTHORITY a
        WHERE PERSON_ID = TO_NUMBER(pn_PersonId)
        AND a.TRAN_CD    = ps_TranCd
        AND a.CHANNEL_CD = ps_ChannelCd;

    ELSE
        OPEN pc_ref FOR
        SELECT a.DAILY_LIMIT, a.LIMIT_CURRENCY, LIMIT_PER_TRAN, DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0) used,
               (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0)) remain
        FROM TBL_PERSON_AUTHORITY a, TBL_COMPANY_AUTHORITY b
        WHERE a.tran_cd=b.tran_cd 
        AND a.PERSON_ID = TO_NUMBER(pn_PersonId)
        AND b.CUSTOMER_ID = TO_NUMBER(pn_CustomerId)
        AND a.TRAN_CD    = ps_TranCd
        AND a.CHANNEL_CD = ps_ChannelCd;
        
    END IF;

    RETURN ls_returncode;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               Pkg_Cint_Log.ADDCUSTOMLOG('GetIBLimitInfo',SQLERRM,ls_returncode);
               ls_returncode:='050';
               RETURN ls_returncode;
         WHEN LimitErrorException THEN
               OPEN pc_ref FOR SELECT '-' FROM dual;
               ls_returncode:='053';
               RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  CheckIBLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 06.06.08
   Purpose   : Check Limits
******************************************************************************/
FUNCTION CheckIBLimit(pn_CustomerID  IN VARCHAR2,
                      ps_TranCd      IN VARCHAR2,
                      pn_Amount      IN VARCHAR2,
                      pn_PersonId    IN VARCHAR2,
                      ps_ChannelCd   IN VARCHAR2,
                      ps_CurrencyCd  IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode           VARCHAR2(3):='000';
    ls_DailyLimitCurr       VARCHAR2(3) ;
    ln_LimitPerTran         NUMBER;
    ln_PersonRemainLimit    NUMBER;
    ln_CompanyRemainLimit   NUMBER;
    ln_PersonRemain         NUMBER;
    ln_CompanyRemain        NUMBER;
    ln_PerTranLimit         NUMBER;
    ln_Rate1                NUMBER;
    ln_Rate2                NUMBER;
    ln_Amount               NUMBER:=TO_NUMBER(pn_Amount,'99999999999.99');
    LimitErrorException     EXCEPTION;

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
    IF ps_ChannelCd='cDKBRIB' THEN

        SELECT a.LIMIT_CURRENCY, LIMIT_PER_TRAN, (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0)) remain
        INTO ls_DailyLimitCurr, ln_LimitPerTran, ln_PersonRemainLimit
        FROM TBL_PERSON_AUTHORITY a
        WHERE PERSON_ID = TO_NUMBER(pn_PersonId)
        AND a.TRAN_CD    = ps_TranCd
        AND a.CHANNEL_CD = ps_ChannelCd;

    ELSE

        SELECT a.LIMIT_CURRENCY, LIMIT_PER_TRAN,(a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0)) PersonRemain, (b.DAILY_LIMIT - DECODE(b.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(b.USED_LIMIT,0),0)) CompanyRemain
        INTO ls_DailyLimitCurr, ln_LimitPerTran, ln_PersonRemainLimit, ln_CompanyRemainLimit
        FROM TBL_PERSON_AUTHORITY a, TBL_COMPANY_AUTHORITY b
        WHERE a.tran_cd=b.tran_cd 
        AND a.PERSON_ID = TO_NUMBER(pn_PersonId)
        AND b.CUSTOMER_ID = TO_NUMBER(pn_CustomerId)
        AND a.TRAN_CD    = ps_TranCd
        AND a.CHANNEL_CD = ps_ChannelCd;
        
    END IF;

    ln_Rate1:=cbs.pkg_soa_common.GetRateForLimit(ls_DailyLimitCurr);
    ln_Rate2:=cbs.pkg_soa_common.GetRateForLimit(ps_CurrencyCd);
    ln_PersonRemain := ln_PersonRemainLimit * ln_Rate1;
    ln_PerTranLimit:= ln_LimitPerTran * ln_Rate1;
    ln_Amount:=ln_Amount * ln_Rate2;
    IF ps_ChannelCd='cDKBCIB' THEN
        ln_CompanyRemain:=ln_CompanyRemainLimit * ln_Rate1;
        IF ln_Amount > ln_CompanyRemain THEN
           ls_returncode:='053';
           RAISE LimitErrorException;
        END IF;
       
    END IF;
    IF ps_TranCd NOT IN ('B2BHVL','CLEARCNCL') THEN
        IF ln_Amount > ln_PersonRemain THEN
           ls_returncode:='051';
           RAISE LimitErrorException;
        END IF;
    END IF;

    IF ln_Amount > ln_PerTranLimit THEN
       ls_returncode:='052';
       RAISE LimitErrorException;
    END IF;

  RETURN ls_returncode;

EXCEPTION
         WHEN LimitErrorException THEN
               RETURN ls_returncode;
         WHEN OTHERS THEN
              Pkg_Log.AddCustomLog('CheckIBLimit',SQLERRM);
              ls_returncode:='050';
              RETURN ls_returncode;
END;
/******************************************************************************
   NAME       : FUNCTION  UpdateLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose   : Update Limit
******************************************************************************/
FUNCTION UpdateIBLimit(pn_CustomerId   IN VARCHAR2,
                       ps_TranCd       IN VARCHAR2,
                       pn_Amount       IN VARCHAR2,
                       ps_CurrencyCd   IN VARCHAR2,
                       pn_PersonId     IN VARCHAR2,
                       ps_ChannelCd    IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode           VARCHAR2(3):='000';
    ls_DailyLimitCurr       VARCHAR2(3) ;
    ln_PersonUsedLimit      NUMBER;
    ln_CompanyUsedLimit     NUMBER;
    ln_PersonAmount         NUMBER;
    ln_CompanyAmount        NUMBER;
    ln_PersonAmountKZ       NUMBER;
    ln_CompanyAmountKZ      NUMBER;
    ln_Rate1                NUMBER;
    ln_Rate2                NUMBER;
    ln_Amount               NUMBER:=TO_NUMBER(pn_Amount,'99999999999.99');
    ln_PersonTotalAmount          NUMBER;
    ln_CompanyTotalAmount          NUMBER;
    LimitErrorException     EXCEPTION;

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
    IF ps_ChannelCd='cDKBRIB' THEN

        SELECT a.LIMIT_CURRENCY, DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0) PersonUsed
        INTO ls_DailyLimitCurr, ln_PersonUsedLimit
        FROM TBL_PERSON_AUTHORITY a
        WHERE PERSON_ID = TO_NUMBER(pn_PersonId)
        AND a.TRAN_CD    = ps_TranCd
        AND a.CHANNEL_CD = ps_ChannelCd;

    ELSE

        SELECT a.LIMIT_CURRENCY, DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(a.USED_LIMIT,0),0) PersonUsed, DECODE(b.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'), NVL(b.USED_LIMIT,0),0) CompanyUsed
        INTO ls_DailyLimitCurr, ln_PersonUsedLimit, ln_CompanyUsedLimit
        FROM TBL_PERSON_AUTHORITY a, TBL_COMPANY_AUTHORITY b
        WHERE a.tran_cd=b.tran_cd 
        AND a.PERSON_ID = TO_NUMBER(pn_PersonId)
        AND b.CUSTOMER_ID = TO_NUMBER(pn_CustomerId)
        AND a.TRAN_CD    = ps_TranCd
        AND a.CHANNEL_CD = ps_ChannelCd;
        
    END IF;

    ln_Rate1:=cbs.pkg_soa_common.GetRateForLimit(ls_DailyLimitCurr);
    ln_Rate2:=cbs.pkg_soa_common.GetRateForLimit(ps_CurrencyCd);
    
    ln_PersonAmountKZ:=ln_Amount * ln_Rate2;
    ln_PersonAmount:=ln_PersonAmountKZ / ln_Rate1;
    ln_PersonTotalAmount:=ln_PersonAmount+ln_PersonUsedLimit;
    
    UPDATE TBL_PERSON_AUTHORITY
    SET USED_LIMIT=ln_PersonTotalAmount,
        LIMIT_DATE=SYSDATE
    WHERE PERSON_ID = TO_NUMBER(pn_PersonId)
    AND TRAN_CD    = ps_TranCd;
    
    
    IF ps_ChannelCd='cDKBCIB' THEN
        ln_CompanyAmountKZ:=ln_Amount * ln_Rate2;
        ln_CompanyAmount:=ln_PersonAmountKZ / ln_Rate1;
        ln_CompanyTotalAmount:=ln_CompanyAmount+ln_CompanyUsedLimit;
        
        UPDATE TBL_COMPANY_AUTHORITY
        SET USED_LIMIT=ln_CompanyTotalAmount,
            LIMIT_DATE=SYSDATE
        WHERE CUSTOMER_ID = TO_NUMBER(pn_CustomerId)
        AND TRAN_CD    = ps_TranCd;
        
    END IF;

    RETURN ls_returncode;

EXCEPTION
         WHEN OTHERS THEN
                 Pkg_Log.AddCustomLog('UpdateIBLimit',SQLERRM);
         RETURN '050';
END;
END Pkg_Cint_Limit;
/

