create PACKAGE         Pkg_Common IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
FUNCTION  GetSequenceID(ps_sequencename IN VARCHAR2) RETURN NUMBER;
-----------------------------------------------------------------------------------
FUNCTION  GetTicketID RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetBankCodes( ps_langcd    IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetPaymentCodes( ps_langcd    IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------------------------
FUNCTION AddBankCodes(ps_option IN VARCHAR2,
                       ps_bankcd IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                      ps_bankdesc    IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION AddPaymentCodes(ps_option IN VARCHAR2,
                         ps_paymentcd IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                      ps_paymentdesc    IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetTheDayAfter(ps_daycount IN NUMBER,returnDate OUT TIMESTAMP) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetTranDescription(ps_trancd IN VARCHAR2, ps_langcd IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetTXTODOInfo(pn_customerno   IN VARCHAR2,
                        ps_trantype     IN VARCHAR2,
                       ps_status       IN VARCHAR2,
                        pd_startdate       IN VARCHAR2,
                       pd_enddate      IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION GetTermInfo(ps_paramid IN VARCHAR2,
                      ps_param1 OUT VARCHAR2,
                      ps_param2 OUT VARCHAR2,
                      ps_param3 OUT VARCHAR2,
                     ps_param4 OUT VARCHAR2,
                     ps_param5 OUT VARCHAR2,
                     ps_param6 OUT VARCHAR2,
                     ps_param7 OUT VARCHAR2,
                     ps_param8 OUT VARCHAR2,
                     ps_param9 OUT VARCHAR2,
                     ps_param10 OUT VARCHAR2,
                     ps_param11 OUT VARCHAR2,
                     ps_param12 OUT VARCHAR2,
                     ps_param13 OUT VARCHAR2,
                     ps_param14 OUT VARCHAR2,
                     ps_param15 OUT VARCHAR2,
                     ps_param16 OUT VARCHAR2,
                     ps_paramstr1 OUT VARCHAR2,
                     ps_paramstr2 OUT VARCHAR2,
                     ps_paramstr3 OUT VARCHAR2,
                     ps_paramstr4 OUT VARCHAR2,
                     ps_paramstr5 OUT VARCHAR2,
                     ps_paramstr6 OUT VARCHAR2,
                     ps_paramstr7 OUT VARCHAR2,
                     ps_paramstr8 OUT VARCHAR2,
                      ps_param1_os OUT VARCHAR2,
                      ps_param2_os OUT VARCHAR2,
                      ps_param3_os OUT VARCHAR2,
                     ps_param4_os OUT VARCHAR2,
                     ps_param5_os OUT VARCHAR2,
                     ps_param6_os OUT VARCHAR2,
                     ps_param7_os OUT VARCHAR2,
                     ps_param8_os OUT VARCHAR2,
                     ps_param9_os OUT VARCHAR2,
                     ps_param10_os OUT VARCHAR2,
                     ps_param11_os OUT VARCHAR2,
                     ps_param12_os OUT VARCHAR2,
                     ps_param13_os OUT VARCHAR2,
                     ps_param14_os OUT VARCHAR2,
                     ps_param15_os OUT VARCHAR2,
                     ps_param16_os OUT VARCHAR2,
                     ps_paramstr9 OUT VARCHAR2,
                     ps_paramstr10 OUT VARCHAR2,
                     ps_paramstr11 OUT VARCHAR2,
                     ps_channelcd OUT VARCHAR2) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION UpdateTermInfo(ps_paramid IN VARCHAR2,
                      ps_param1 IN VARCHAR2,
                      ps_param2 IN VARCHAR2,
                      ps_param3 IN VARCHAR2,
                     ps_param4 IN VARCHAR2,
                     ps_param5 IN VARCHAR2,
                     ps_param6 IN VARCHAR2,
                     ps_param7 IN VARCHAR2,
                     ps_param8 IN VARCHAR2,
                     ps_param9 IN VARCHAR2,
                     ps_param10 IN VARCHAR2,
                     ps_param11 IN VARCHAR2,
                     ps_param12 IN VARCHAR2,
                     ps_param13 IN VARCHAR2,
                     ps_param14 IN VARCHAR2,
                     ps_param15 IN VARCHAR2,
                     ps_param16 IN VARCHAR2,
                     ps_paramstr1 IN VARCHAR2,
                     ps_paramstr2 IN VARCHAR2,
                     ps_paramstr3 IN VARCHAR2,
                     ps_paramstr4 IN VARCHAR2,
                     ps_paramstr5 IN VARCHAR2,
                     ps_paramstr6 IN VARCHAR2,
                     ps_paramstr7 IN VARCHAR2,
                     ps_paramstr8 IN VARCHAR2,
                      ps_param1_os IN VARCHAR2,
                      ps_param2_os IN VARCHAR2,
                      ps_param3_os IN VARCHAR2,
                     ps_param4_os IN VARCHAR2,
                     ps_param5_os IN VARCHAR2,
                     ps_param6_os IN VARCHAR2,
                     ps_param7_os IN VARCHAR2,
                     ps_param8_os IN VARCHAR2,
                     ps_param9_os IN VARCHAR2,
                     ps_param10_os IN VARCHAR2,
                     ps_param11_os IN VARCHAR2,
                     ps_param12_os IN VARCHAR2,
                     ps_param13_os IN VARCHAR2,
                     ps_param14_os IN VARCHAR2,
                     ps_param15_os IN VARCHAR2,
                     ps_param16_os IN VARCHAR2,
                     ps_paramstr9 IN VARCHAR2,
                     ps_paramstr10 IN VARCHAR2,
                     ps_paramstr11 IN VARCHAR2,
                     ps_option IN VARCHAR2,
                     ps_channelcd IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION GetOnlineSubInquary(pn_hesapno   IN VARCHAR2,
                                                   ps_status       IN VARCHAR2,
                                                    pd_startdate       IN VARCHAR2,
                                                   pd_enddate      IN VARCHAR2,
                                                   ps_msg_type    IN VARCHAR2,
                                                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION GetEtokenUsers(pn_hesapno   IN VARCHAR2,
                                                   ps_name    IN VARCHAR2,
                                                     pn_customerid       IN VARCHAR2,
                                                    pd_assigndate       IN VARCHAR2,
                                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION UpdateEmailAdvertisement(ps_option IN VARCHAR2,
       ps_advertisement IN VARCHAR2,
       ps_end_date        in varchar2,
      pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION UpdateEmailSubscription(ps_option IN VARCHAR2,
                                pn_hesapno   IN VARCHAR2,
                                ps_status       IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION GetCustomerNoFromSession(ps_sessionid IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION SendEmailDekont(ps_channel_cd IN VARCHAR2,
                         ps_email IN VARCHAR2,
                         ps_tx_no IN VARCHAR2,
                         ps_lang_cd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION SendAccountHistoryDekont(ps_channel_cd IN VARCHAR2,
                                  ps_lang_cd IN VARCHAR2,
                                  ps_person_id IN VARCHAR2,
                                  ps_email IN VARCHAR2,
                                  ps_start_date IN VARCHAR2,
                                  ps_end_date IN VARCHAR2,
                                  ps_type IN VARCHAR2,
                                  ps_account_no IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION SendCreditCardDekont(ps_TranCD IN VARCHAR2,
                              ps_From IN VARCHAR2,
                              ps_To IN VARCHAR2,
                              ps_Subject IN VARCHAR2,
                              ps_Data IN CLOB,
                              ps_channel_cd IN VARCHAR2,
                              ps_lang_cd IN VARCHAR2,
                              ps_person_id IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------
FUNCTION VCardAgreementWithOption(ps_OptionCD IN VARCHAR2,
                                  ps_AgreementID IN VARCHAR2,
                                  ps_AgreementText IN VARCHAR2,
                                  ps_LangCD IN VARCHAR2,
                                  ps_PersonID IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

END;
/

