create PACKAGE           "PKG_CONFIGURATION" AS
/******************************************************************************
   NAME:       PKG_CONFIGURATION
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        13.03.2014   ErnestK         Created this package.
******************************************************************************/

FUNCTION getValueByKey(ps_key in  varchar2,
                     ps_value out varchar2) RETURN varchar2;--cqdb00000504 ernestk to get the configuration value

END PKG_CONFIGURATION;
/

