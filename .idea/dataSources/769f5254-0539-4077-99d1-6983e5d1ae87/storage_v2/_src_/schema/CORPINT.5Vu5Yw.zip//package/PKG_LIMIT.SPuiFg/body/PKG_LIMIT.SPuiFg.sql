create PACKAGE BODY         "PKG_LIMIT" IS
----------------------------------------------------------------------------------------------
FUNCTION GetLimitInfo(pn_musteri_no IN VARCHAR2,
                      pn_personid   IN VARCHAR2,
                      ps_trancd     IN VARCHAR2,
                      ps_channel    IN VARCHAR2,
                      ps_rates      IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    LimitErrorException     EXCEPTION;
    ln_count VARCHAR2(3):='000';
    l_dl      NUMBER ;
    l_dl_cy   VARCHAR2(3) ;
    l_used    NUMBER ;
    l_pl      NUMBER ;
    l_pl_cy   VARCHAR2(3) ;
    l_kalan   NUMBER;

    l_dl_kz      NUMBER ;
    l_pl_kz      NUMBER ;
    l_used_kz    NUMBER ;
    l_kalan_kz   NUMBER;
    l_dl_rate  NUMBER;
    l_pl_rate  NUMBER;
    l_rate1  NUMBER;
    l_rate2  NUMBER;
    
    ln_DailyLimit           NUMBER;
    ls_DailyLimitCurrency   VARCHAR2(3);
    ln_UsedLimit            NUMBER;
    ln_TranLimit            NUMBER;
    ls_TranLimitCurrency    VARCHAR2(3);
    ln_RemainLimit          NUMBER;

BEGIN

    OPEN pc_ref FOR SELECT 'DUMMY' FROM dual;

    IF ps_channel='cDKBRIB' THEN

        SELECT    a.DAILY_LIMIT, a.CURRENCY_CODE,Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel) used,a.ONETIME_LIMIT, a.CURRENCY_CODE,(a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel)) kalan
        INTO    l_dl,    l_dl_cy,    l_used,    l_pl,    l_pl_cy,    l_kalan
        FROM TBL_LIMIT_DEFAULTS a
        WHERE a.TRAN_CD = ps_trancd
        AND a.CHANNEL_CD = ps_channel
        AND a.PERSON_ID = pn_personid;

        OPEN pc_ref FOR
            SELECT    a.DAILY_LIMIT, a.CURRENCY_CODE,Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel) used,a.ONETIME_LIMIT, a.CURRENCY_CODE,(a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel)) kalan
            FROM TBL_LIMIT_DEFAULTS a
            WHERE a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND a.PERSON_ID = pn_personid;

    ELSE --cDKBCIB
        IF ps_trancd IN ('CLEARING','UTILPAY','CLEARCNCL','CLEARPENS','TRANSPYM','PAYMORD','PORDCNCL', 'GROSS', 'SALARY') THEN --ChyngyzO cq4960 28.12.15 Salary added
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
            a.DAILY_LIMIT, a.LIMIT_CURRENCY,
            DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
            b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
            (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan
            INTO
            l_dl, l_dl_cy,
            l_used,
            l_pl, l_pl_cy,
            l_kalan
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;

            IF l_dl_cy = 'USD' THEN
                l_dl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',0),',',''),'.',','));
            ELSIF l_dl_cy = 'EUR' THEN
                l_dl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',1),',',''),'.',','));
            ELSE
                l_dl_rate :=1;
            END IF;

            l_dl_kz := l_dl * l_dl_rate;
            l_kalan_kz := l_kalan * l_dl_rate;
            l_used_kz := l_used * l_dl_rate;

            IF l_pl_cy = 'USD' THEN
                l_pl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',0),',',''),'.',','));
            ELSIF l_pl_cy = 'EUR' THEN
                l_pl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',1),',',''),'.',','));
            ELSE
                l_pl_rate :=1;
            END IF;

            l_pl_kz := l_pl * l_pl_rate;

        OPEN pc_ref FOR
            SELECT l_dl_kz, 'KGS',
                   DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                   l_pl_kz, 'KGS', l_kalan_kz
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;
        END IF;
    /**************************************************
    *****************   EXCHNGBUY **********************
    ***************************************************/
        IF ps_trancd IN ('EXCHNGBUY','FXORDER') THEN
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT  a.DAILY_LIMIT, a.LIMIT_CURRENCY,
                    DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                    b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
                    (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan
            INTO
                    l_dl, l_dl_cy,
                    l_used,
                    l_pl, l_pl_cy,
                    l_kalan
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;

            OPEN pc_ref FOR
                SELECT  l_dl, l_dl_cy,
                        DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                        l_pl, l_pl_cy, l_kalan
                FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
                WHERE a.CUSTOMER_ID = pn_musteri_no
                AND a.CUSTOMER_ID = b.CUSTOMER_NO
                AND a.TRAN_CD = ps_trancd
                AND a.CHANNEL_CD = ps_channel
                AND b.PERSON_ID = pn_personid ;
        END IF;
    /**************************************************
    *****************   EXCHNGSELL **********************
    ***************************************************/
        IF ps_trancd IN ('EXCHNGSELL','ARBITRAGE') THEN
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
                    a.DAILY_LIMIT, a.LIMIT_CURRENCY,
                    DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                    b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
                    (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan
            INTO
                    l_dl, l_dl_cy,
                    l_used,
                    l_pl, l_pl_cy,
                    l_kalan
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;

            OPEN pc_ref FOR
                SELECT
                l_dl, l_dl_cy,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                l_pl, l_pl_cy, l_kalan
                FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
                WHERE a.CUSTOMER_ID = pn_musteri_no
                AND a.CUSTOMER_ID = b.CUSTOMER_NO
                AND a.TRAN_CD = ps_trancd
                AND a.CHANNEL_CD = ps_channel
                AND b.PERSON_ID = pn_personid ;
        END IF;

    /**************************************************
    *****************  MONEY TRANSFER ****************
    ***************************************************/
        IF ps_trancd IN ('B2OBHVL','CARDPYM','SALARYPAY','P2OCARD','DDSINVOICE', 'CARDDEBT') THEN
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
                a.DAILY_LIMIT, a.LIMIT_CURRENCY,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
                (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan
            INTO
                l_dl, l_dl_cy,
                l_used,
                l_pl, l_pl_cy,
                l_kalan
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid ;


                 
            OPEN pc_ref FOR
                SELECT
                l_dl, l_dl_cy,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                l_pl, l_pl_cy, l_kalan
                FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
                WHERE a.CUSTOMER_ID = pn_musteri_no
                AND a.CUSTOMER_ID = b.CUSTOMER_NO
                AND a.TRAN_CD = ps_trancd
                AND a.CHANNEL_CD = ps_channel
                AND b.PERSON_ID = pn_personid ;
        END IF;

        IF ps_trancd IN ('SWIFT') and false THEN --chyngyzo 14012015 cq509  disabled
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_LIMITS
            WHERE CHANNEL_CD = ps_channel
            AND CUSTOMER_NO = pn_musteri_no
            AND PERSON_ID = pn_personid
            AND TRAN_CD = ps_trancd;

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
                DAILY_LIMIT, DAILY_LIMIT_CURRENCY,
                DECODE(TRUNC(USED_LIMIT_DATE),TO_CHAR(SYSDATE,'YYYYMMDD'),NVL(USED_LIMIT,0),0) used,
                TRAN_LIMIT, TRAN_LIMIT_CURRENCY,
                (DAILY_LIMIT - DECODE(TRUNC(USED_LIMIT_DATE),TO_CHAR(SYSDATE,'YYYYMMDD'),NVL(USED_LIMIT,0),0)) remain
            INTO
                ln_DailyLimit, ls_DailyLimitCurrency,
                ln_UsedLimit,
                ln_TranLimit, ls_TranLimitCurrency,
                ln_RemainLimit
            FROM TBL_LIMITS
            WHERE CHANNEL_CD = ps_channel
            AND CUSTOMER_NO = pn_musteri_no
            AND PERSON_ID = pn_personid
            AND TRAN_CD = ps_trancd;

            OPEN pc_ref FOR
                SELECT
                    ln_DailyLimit, ls_DailyLimitCurrency,
                    ln_UsedLimit,
                    ln_TranLimit, ls_TranLimitCurrency,
                    ln_RemainLimit
                FROM DUAL;
        END IF;
    END IF;--ChannelCD

  RETURN ls_returncode;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '050';
    WHEN LimitErrorException THEN
        OPEN pc_ref FOR
            SELECT SYSDATE FROM dual;
        RETURN '053';
    WHEN OTHERS THEN
        pkg_log.addcustomlog('GetLimitInfo',sqlerrm);
        RETURN '999';
END;
-----------------------------------------------------------------------------
FUNCTION CheckLimit(pn_musteri_no IN VARCHAR2,
                    ps_trancd     IN VARCHAR2,
                    pn_amount     IN VARCHAR2,
                    pn_personid   IN VARCHAR2,
                    ps_channel    IN VARCHAR2,
                    ps_rates      IN VARCHAR2,
                    ps_cycode     IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';

    ln_Amount NUMBER;
    l_max_day_limit NUMBER;

    ln_DailyLimit           NUMBER;
    ls_DailyLimitCurrency   VARCHAR2(3);
    ln_UsedLimit            NUMBER;
    ln_TranLimit            NUMBER;
    ls_TranLimitCurrency    VARCHAR2(3);
    ln_RemainLimit          NUMBER;
    
    ln_CurrencyRate         NUMBER;

    LimitErrorException     EXCEPTION;
BEGIN
    OPEN pc_ref FOR
        SELECT 'DUMMY' FROM dual;

Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','1',pn_amount );
log_at('nurik1543', 'CheckLimit', '1',pn_musteri_no||','||ps_trancd||','||pn_amount||','||pn_personid||','||ps_channel||','||ps_rates||','||ps_cycode);
--15685,SALARY,4980024,99,364,cDKBCIB,82.57;85.57,KGS
    IF ps_channel='cDKBRIB' THEN
        SELECT a.DAILY_LIMIT, a.CURRENCY_CODE,
               Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel) used,
               a.ONETIME_LIMIT, a.CURRENCY_CODE,
               (a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel)) kalan
        INTO ln_DailyLimit, ls_DailyLimitCurrency, 
             ln_UsedLimit,
             ln_TranLimit, ls_TranLimitCurrency,
             ln_RemainLimit
        FROM TBL_LIMIT_DEFAULTS a
        WHERE a.TRAN_CD = ps_trancd
        AND a.CHANNEL_CD = ps_channel
        AND a.PERSON_ID = TO_NUMBER(pn_personid);
    ELSE--cDKBCIB
        /*IF (ps_trancd = 'SWIFT') THEN chyngyzo  cq509 commented
            SELECT
                DAILY_LIMIT, DAILY_LIMIT_CURRENCY,
                DECODE(TRUNC(USED_LIMIT_DATE),TO_CHAR(SYSDATE,'YYYYMMDD'),NVL(USED_LIMIT,0),0) used,
                TRAN_LIMIT, TRAN_LIMIT_CURRENCY,
                (DAILY_LIMIT - DECODE(TRUNC(USED_LIMIT_DATE),TO_CHAR(SYSDATE,'YYYYMMDD'),NVL(USED_LIMIT,0),0)) remain,
                DAILY_LIMIT
            INTO
                ln_DailyLimit, ls_DailyLimitCurrency,
                ln_UsedLimit,
                ln_TranLimit, ls_TranLimitCurrency,
                ln_RemainLimit,
                l_max_day_limit
            FROM TBL_LIMITS
            WHERE CHANNEL_CD = ps_channel
            AND CUSTOMER_NO = pn_musteri_no
            AND PERSON_ID = pn_personid
            AND TRAN_CD = ps_trancd;
        ELSE*/
        Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','2');
        log_at('nurik1543', 'CheckLimit', '2');
        log_at('nurik1543', 'CheckLimit', '2', 'pn_musteri_no = ' || to_char(pn_musteri_no) || '  ps_channel = ' || to_char(ps_channel) || '  ps_trancd = ' || to_char(ps_trancd) || '  pn_personid = ' || to_char(pn_personid));
            SELECT  a.DAILY_LIMIT, a.LIMIT_CURRENCY,
                    DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                    b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY, 
                    (c.MAX_DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan,
                    c.MAX_DAILY_LIMIT
            INTO    ln_DailyLimit, ls_DailyLimitCurrency,
                    ln_UsedLimit,
                    ln_TranLimit, ls_TranLimitCurrency,
                    ln_RemainLimit,
                    l_max_day_limit
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.CHANNEL_CD = ps_channel
            and a.tran_cd=ps_trancd
            and a.TRAN_CD = c.TRAN_CD
            and a.CHANNEL_CD=c.CHANNEL_CD
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            AND b.PERSON_ID = pn_personid ;
        --END IF;
    END IF;--CHannelCD

Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','3');

    IF ls_DailyLimitCurrency = 'USD' THEN
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.9999');
    ELSIF ls_DailyLimitCurrency = 'EUR' THEN
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.9999');
    ELSIF ls_DailyLimitCurrency = 'RUB' THEN                                                --ernestk 21042014 cqdb00000620 check RUB rates
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'99999999999.9999');   --ernestk 21042014 cqdb00000620 get RUB rates
    ELSIF ls_DailyLimitCurrency = 'KZT' THEN                                                --ernestk 21042014 cqdb00000620 check RUB rates
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',3),'99999999999.9999');   
    ELSE
        ln_CurrencyRate := 1;
    END IF;

Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','4');
log_at('nurik1543', 'CheckLimit', '4');

    ln_DailyLimit := ln_DailyLimit * ln_CurrencyRate;
    ln_RemainLimit := ln_RemainLimit * ln_CurrencyRate;
    
    Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','5', ln_DailyLimit, ln_RemainLimit);
    log_at('nurik1543', 'CheckLimid',to_char(ln_DailyLimit), to_char(ln_RemainLimit));
    
    IF ls_TranLimitCurrency = 'USD' THEN
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.9999');
    ELSIF ls_TranLimitCurrency = 'EUR' THEN
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.9999');
    ELSIF ls_TranLimitCurrency = 'RUB' THEN                                                 --ernestk 21042014 cqdb00000620 check RUB rates
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'99999999999.9999');   --ernestk 21042014 cqdb00000620 check RUB rates
    ELSIF ls_TranLimitCurrency = 'KZT' THEN                                                 --ernestk 21042014 cqdb00000620 check RUB rates
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',3),'99999999999.9999');   --ernestk 21042014 cqdb00000620 check RUB rates    
    ELSE
        ln_CurrencyRate := 1;
    END IF;
    
      Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','6', ln_TranLimit);
      log_at('nurik1543', 'CheckLimit', '6', to_char(ln_TranLimit));
      
    ln_TranLimit := ln_TranLimit * ln_CurrencyRate;

    IF ps_cycode = 'KGS'    THEN
        ln_Amount := TO_NUMBER(pn_amount,'99999999999.9999');
    ELSIF ps_cycode = 'USD' THEN
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.9999');
        ln_Amount := TO_NUMBER(pn_amount,'99999999999.9999') * ln_CurrencyRate;
    ELSIF ps_cycode = 'EUR' THEN
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.9999');
        ln_Amount := TO_NUMBER(pn_amount,'99999999999.9999') * ln_CurrencyRate;
    ELSIF ps_cycode = 'RUB' THEN                                                            --ernestk 21042014 cqdb00000620 check RUB rates
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'99999999999.9999');
        ln_Amount := TO_NUMBER(pn_amount,'99999999999.9999') * ln_CurrencyRate;
    ELSIF ps_cycode = 'KZT' THEN                                                            --ernestk 21042014 cqdb00000620 check RUB rates
        ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',3),'99999999999.9999');
        ln_Amount := TO_NUMBER(pn_amount,'99999999999.9999') * ln_CurrencyRate;
    END IF;
    
          Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','7', ln_TranLimit);
          log_at('nurik1543', 'CheckLimit', '7', to_char(ln_TranLimit) || ' ' || to_char(ln_Amount) || ' ' || to_char(ln_DailyLimit));
          
    IF ps_trancd NOT IN ('B2BHVL','CLEARCNCL', 'CARDDEBT') THEN
        IF ln_Amount > ln_DailyLimit THEN
            ls_returncode:='057';
            RAISE LimitErrorException;
        END IF;
        IF ln_Amount > ln_RemainLimit THEN
            IF ps_channel='cDKBRIB' THEN
               ls_returncode:='052';
            else
               ls_returncode:='051';
            end if;
            RAISE LimitErrorException;
        END IF;
    END IF; 

      Pkg_Log.AddCustomLog('CHECK_LIMIT_DBG','8');
      log_at('nurik1543', 'CheckLimit', '8',ln_Amount||','|| ln_TranLimit||','||ls_returncode);
      
    IF ln_Amount > ln_TranLimit THEN
        ls_returncode:='057';
        RAISE LimitErrorException;
    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN LimitErrorException THEN
        RETURN ls_returncode;
    WHEN OTHERS THEN
        Pkg_Log.AddCustomLog('CHECK_LIMIT',SQLERRM);
        RETURN '050';
END;
----------------------------------------------------------------------------------------------
FUNCTION UpdateLimitNew(pn_musteri_no IN VARCHAR2,
                         ps_trancd IN VARCHAR2,
                         pn_amount IN VARCHAR2,
                           ps_cycode   IN VARCHAR2,
                        pn_personid IN VARCHAR2,
                        ps_channel  IN VARCHAR2,
                           ps_rates    IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';

    l_dl      NUMBER ;
    l_dl_cy   VARCHAR2(3) ;
    l_used    NUMBER ;
    l_pl      NUMBER ;
    l_pl_cy   VARCHAR2(3) ;
    l_kalan   NUMBER;
    amo       NUMBER;
    ln_count  number:=0;

    l_dl_kz      NUMBER ;
    l_pl_kz      NUMBER ;
    l_used_kz    NUMBER ;
    l_kalan_kz   NUMBER;
    l_tran_kz     number;
    l_dl_rate  NUMBER;
    l_pl_rate  NUMBER;
    l_amo_rate  NUMBER;
    l_max_day_limit number;
    ld_limit_date date := sysdate;
BEGIN
  OPEN pc_ref FOR
  SELECT 'DUMMY' FROM dual;

IF ps_channel='cDKBRIB' THEN
    SELECT    a.DAILY_LIMIT, a.CURRENCY_CODE,Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel) used,a.ONETIME_LIMIT, a.CURRENCY_CODE,(a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel)) kalan
    INTO l_dl, l_dl_cy, l_used,    l_pl, l_pl_cy, l_kalan
    FROM TBL_LIMIT_DEFAULTS a
    WHERE a.TRAN_CD = ps_trancd
    AND a.CHANNEL_CD = ps_channel
    AND a.PERSON_ID = TO_NUMBER(pn_personid);
ELSE--cDKBCIB

    SELECT
    a.DAILY_LIMIT,     a.LIMIT_CURRENCY,     DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
    b.ISLEM_LIMIT,     b.ISLEM_LIMIT_CY,     (c.MAX_DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan,
    c.MAX_DAILY_LIMIT
    INTO  l_dl,    l_dl_cy, l_used, l_pl, l_pl_cy,    l_kalan, l_max_day_limit
    FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
    WHERE a.CUSTOMER_ID = pn_musteri_no
    AND a.CUSTOMER_ID = b.CUSTOMER_NO
    AND a.CHANNEL_CD = ps_channel
    and a.tran_cd=ps_trancd
    and a.TRAN_CD = c.TRAN_CD
    and a.CHANNEL_CD=c.CHANNEL_CD
    and c.CUSTOMER_NO=a.CUSTOMER_ID
    AND b.PERSON_ID = pn_personid ;

END IF;--CHannelCD

         IF l_dl_cy = 'USD' THEN
            l_dl_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.99');
         ELSIF l_dl_cy = 'EUR' THEN
            l_dl_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.99');
         ELSIF l_dl_cy = 'KZT' THEN
            l_dl_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'99999999999.9999');
         ELSE
              l_dl_rate := 1;
         END IF;
         l_kalan_kz := l_kalan * l_dl_rate;
         l_tran_kz := l_dl * l_dl_rate;

        IF l_pl_cy = 'USD' THEN
            l_pl_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.99');
        ELSIF l_pl_cy = 'EUR' THEN
            l_pl_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.99');
        ELSIF l_pl_cy = 'KZT' THEN
            l_pl_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'99999999999.9999');
        ELSE
             l_pl_rate := 1;
     END IF;
         l_pl_kz    := l_pl * l_pl_rate;

    IF ps_cycode = 'KGS'    THEN
      amo := TO_NUMBER(pn_amount,'99999999999.99');
    ELSIF ps_cycode = 'USD' THEN
      l_amo_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.99');
      amo := TO_NUMBER(pn_amount,'99999999999.99') * l_amo_rate ;
    ELSIF ps_cycode = 'EUR' THEN
      l_amo_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.99');
      amo := TO_NUMBER(pn_amount,'99999999999.99') * l_amo_rate ;
    ELSIF ps_cycode = 'KZT' THEN
      l_amo_rate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'99999999999.9999');
      amo := TO_NUMBER(pn_amount,'99999999999.99') * l_amo_rate ;
    END IF;

-- UPDATE UNSED LIMIT -----------
IF ps_channel='cDKBRIB' THEN
    SELECT COUNT(*)
    INTO ln_count
    FROM TBL_LIMIT_USED
    WHERE PERSON_ID = TO_NUMBER(pn_personid)
    AND TRAN_CD = ps_trancd
    AND CHANNEL_CD = ps_channel;

    IF ln_count=0 THEN
       INSERT INTO TBL_LIMIT_USED
       (PERSON_ID, USED_DATE, USED_LIMIT, TRAN_CD, CHANNEL_CD)
       VALUES
       (TO_NUMBER(pn_personid),TO_DATE(TO_CHAR(SYSDATE,'YYYYMMDD'),'YYYYMMDD'),amo,ps_trancd,ps_channel);
    ELSE
        UPDATE TBL_LIMIT_USED
        SET USED_LIMIT = amo,
            USED_DATE = TO_DATE(TO_CHAR(SYSDATE,'YYYYMMDD'),'YYYYMMDD')
        WHERE PERSON_ID = TO_NUMBER(pn_personid)
        AND TRAN_CD = ps_trancd
        AND CHANNEL_CD = ps_channel;
    END IF;
ELSE
    select to_date(NVL(LIMIT_DATE,TO_CHAR(SYSDATE,'YYYYMMDD')),'yyyymmdd') into ld_limit_date
    from TBL_APPROVAL_TRAN
    WHERE CUSTOMER_ID = pn_musteri_no
    AND CHANNEL_CD = ps_channel
    and tran_cd=ps_trancd
    and rownum=1;

    if (trunc(ld_limit_date)<trunc(sysdate)) then
        update TBL_APPROVAL_TRAN
        set LIMIT_DATE = to_char(sysdate,'yyyymmdd'),
        USED_LIMIT = 0
        WHERE CUSTOMER_ID = pn_musteri_no
        AND CHANNEL_CD = ps_channel
        and tran_cd=ps_trancd;
    end if;

    update TBL_APPROVAL_TRAN
    set USED_LIMIT = case when (l_used + amo) > 0 then (l_used + amo) else 0 end,
        LIMIT_DATE = TO_CHAR(SYSDATE,'YYYYMMDD')
    WHERE CUSTOMER_ID = pn_musteri_no
    AND CHANNEL_CD = ps_channel
    and tran_cd=ps_trancd;
END IF;

  RETURN ls_returncode;

EXCEPTION
         WHEN OTHERS THEN
              Pkg_Log.AddCustomLog('UPDATE LIMIT NEW'||SQLERRM);
               RETURN '050';
END;
----------------------------------------------------------------------------------------------
FUNCTION UpdateLimit(pn_musteri_no IN VARCHAR2,
                     ps_trancd IN VARCHAR2,
                     pn_amount IN VARCHAR2,
                     ps_currcode IN VARCHAR2,
                     ps_personid IN VARCHAR2,
                     ps_channel IN VARCHAR2,
                     ps_rates IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';

    ln_count NUMBER;

    ln_Amount NUMBER;
    ln_TotalAmount NUMBER;
    l_max_day_limit NUMBER;

    ln_DailyLimit           NUMBER;
    ls_DailyLimitCurrency   VARCHAR2(3);
    ln_UsedLimit            NUMBER;
    ln_TranLimit            NUMBER;
    ls_TranLimitCurrency    VARCHAR2(3);
    ln_RemainLimit          NUMBER;
    
    ln_CurrencyRate         NUMBER;
    ls_CurrentDate          VARCHAR2(8);
BEGIN
    OPEN pc_ref FOR
        SELECT 'DUMMY' FROM dual;

    IF ps_channel='cDKBRIB' THEN

        SELECT a.DAILY_LIMIT, a.CURRENCY_CODE,
               Pkg_Limit.GetUsedLimit(pn_musteri_no,ps_personid,ps_trancd,ps_channel) used,
               a.ONETIME_LIMIT, a.CURRENCY_CODE,
               (a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_musteri_no,ps_personid,ps_trancd,ps_channel)) kalan
        INTO ln_DailyLimit, ls_DailyLimitCurrency, 
             ln_UsedLimit, 
             ln_TranLimit, ls_TranLimitCurrency, 
             ln_RemainLimit
        FROM TBL_LIMIT_DEFAULTS a
        WHERE a.TRAN_CD = ps_trancd
        AND a.CHANNEL_CD = ps_channel
        AND a.PERSON_ID = TO_NUMBER(ps_personid);

        ln_Amount := TO_NUMBER(pn_amount,'999999999999999.9999');
        ls_CurrentDate := TO_CHAR(SYSDATE,'YYYYMMDD');

        IF ps_currcode = ls_DailyLimitCurrency THEN
            ln_TotalAmount := ln_UsedLimit + ln_Amount;
        ELSE
            IF ps_currcode = 'USD'      THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'999999999999999.9999');
            ELSIF ps_currcode = 'EUR' THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'999999999999999.9999');
            ELSIF ps_currcode = 'RUB' THEN                                                           --ernestk 22042014 cqdb00000620 check RUB currency
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'999999999999999.9999');--ernestk 22042014 cqdb00000620 set RUB rate    
            ELSE
                ln_CurrencyRate := 1;
            END IF;

            ln_Amount := ln_Amount * ln_CurrencyRate;

            IF ls_DailyLimitCurrency = 'USD'      THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'999999999999999.9999');
            ELSIF ls_DailyLimitCurrency = 'EUR' THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'999999999999999.9999');
            ELSIF ls_DailyLimitCurrency = 'RUB' THEN                                                --ernestk 22042014 cqdb00000620 check RUB currency
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'999999999999999.9999');--ernestk 22042014 cqdb00000620 set RUB rate
            ELSE
                ln_CurrencyRate := 1;
            END IF;

            ln_Amount := ln_Amount / ln_CurrencyRate ;
            ln_TotalAmount := ln_UsedLimit + ln_Amount ;
        END IF;

        SELECT COUNT(*)
        INTO ln_count
        FROM TBL_LIMIT_USED
        WHERE PERSON_ID = TO_NUMBER(ps_personid)
        AND TRAN_CD = ps_trancd
        AND CHANNEL_CD = ps_channel;

        IF ln_count=0 THEN
           INSERT INTO TBL_LIMIT_USED
           (PERSON_ID, USED_DATE, USED_LIMIT, TRAN_CD, CHANNEL_CD)
           VALUES
           (TO_NUMBER(ps_personid),TO_DATE(ls_CurrentDate,'YYYYMMDD'),ln_TotalAmount,ps_trancd,ps_channel);
        ELSE
            UPDATE TBL_LIMIT_USED
            SET USED_LIMIT = ln_TotalAmount,
                USED_DATE = TO_DATE(ls_CurrentDate,'YYYYMMDD')
            WHERE PERSON_ID = TO_NUMBER(ps_personid)
            AND TRAN_CD = ps_trancd
            AND CHANNEL_CD = ps_channel;
        END IF;
    ELSE--cDKBCIB

        SELECT
            a.DAILY_LIMIT, a.LIMIT_CURRENCY,
            DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
            b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
            (a.DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan
        INTO
            ln_DailyLimit, ls_DailyLimitCurrency,
            ln_UsedLimit,
            ln_TranLimit, ls_TranLimitCurrency,
            ln_RemainLimit
        FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b
        WHERE a.CUSTOMER_ID = TO_NUMBER(pn_musteri_no)
        AND a.CUSTOMER_ID = b.CUSTOMER_NO
        AND a.TRAN_CD = ps_trancd
        AND a.CHANNEL_CD = ps_channel
        AND b.PERSON_ID = ps_personid ;

        ln_Amount := TO_NUMBER(pn_amount,'999999999999999.9999');
        ls_CurrentDate := TO_CHAR(SYSDATE,'YYYYMMDD');

        IF ps_currcode = ls_DailyLimitCurrency THEN
            ln_TotalAmount := ln_UsedLimit + ln_Amount;
        ELSE
            IF ps_currcode = 'USD' THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'999999999999999.9999');
            ELSIF ps_currcode = 'EUR' THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'999999999999999.9999');
            ELSIF ps_currcode = 'RUB' THEN --ernestk cqdb00000620 check for RUB currency
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'999999999999999.9999');
            ELSE
                ln_CurrencyRate := 1;
            END IF;

            ln_Amount := ln_Amount * ln_CurrencyRate;

            IF ls_DailyLimitCurrency = 'USD' THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'999999999999999.9999');
            ELSIF ls_DailyLimitCurrency = 'EUR' THEN
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'999999999999999.9999');
            ELSIF ls_DailyLimitCurrency = 'RUB' THEN --ernestk cqdb00000620 check for RUB currency
                ln_CurrencyRate := TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',2),'999999999999999.9999');
            ELSE
                ln_CurrencyRate := 1;
            END IF;

            ln_Amount := ln_Amount / ln_CurrencyRate ;
            ln_TotalAmount := ln_UsedLimit + ln_Amount ;
        END IF;

        UPDATE TBL_APPROVAL_TRAN
        SET USED_LIMIT = case when ln_TotalAmount > 0 then ln_TotalAmount else 0 end,
            LIMIT_DATE = ls_CurrentDate
        WHERE CUSTOMER_ID = TO_NUMBER(pn_musteri_no)
        AND TRAN_CD = ps_trancd
        AND CHANNEL_CD = ps_channel;

    END IF;--channel

  RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        Pkg_Log.AddCustomLog('UpdateLimit',SQLERRM);
        RETURN '050';
END;
----------------------------------------------------------------------------------------------
FUNCTION CheckLimitForAdminSite(ps_personid IN VARCHAR2,
                                pn_cust     IN VARCHAR2,
                                pn_amount   IN VARCHAR2,
                                ps_cycode   IN VARCHAR2,
                                ps_rates    IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    TransactionError EXCEPTION;
    ls_statement VARCHAR2(2000);
    ls_returncode  VARCHAR2(3):='000';
    lim  NUMBER;
    LimitErrorException     EXCEPTION;
    imza  NUMBER;
    imzacy  VARCHAR2(3) ;
    ln_rate1      NUMBER ;
    ln_rate2      NUMBER ;
    lim_kz      NUMBER ;
    imza_kz      NUMBER ;
BEGIN
    OPEN pc_ref FOR
        SELECT 'OK' FROM dual;

    lim := TO_NUMBER(pn_amount,'99999999999.99');

    SELECT IMZA_SIRKULERI_IMZA_LIMIT,IMZA_SIRKULERI_CY
    INTO imza,imzacy
    FROM TBL_COMPANY
    WHERE CUSTOMER_NO = pn_cust
    AND PERSON_ID   = ps_personid;


    IF ps_cycode = 'USD' THEN
        ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.99');
    ELSIF ps_cycode = 'EUR' THEN
        ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.99');
    ELSE
        ln_rate1:=1;
    END IF;
    lim_kz := lim * ln_rate1;

    IF imzacy = 'USD' THEN
        ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.99');
    ELSIF imzacy = 'EUR' THEN
        ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.99');
    ELSE
        ln_rate2:=1;
    END IF;
    imza_kz := imza * ln_rate2;

    IF lim_kz > imza_kz
    THEN
      ls_returncode:='054';
      RAISE LimitErrorException;
    END IF;
    RETURN ls_returncode;

EXCEPTION
         WHEN LimitErrorException THEN
               RETURN ls_returncode;
         WHEN OTHERS THEN
               Pkg_Log.AddCustomLog(SQLERRM,ps_rates);
               RETURN '050';
END;
-----------------------------------------------------------------------------------
FUNCTION CheckSpecLimitForAdminSite(ps_personid IN VARCHAR2,
                                 pn_cust       IN VARCHAR2,
                                 pn_amount     IN VARCHAR2,
                                 ps_cycode     IN VARCHAR2,
                                ps_rates      IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    TransactionError EXCEPTION;
    ls_statement VARCHAR2(2000);
    ls_returncode  VARCHAR2(3):='000';
    lim  NUMBER;
    LimitErrorException     EXCEPTION;
    imza  NUMBER;
    imzacy  VARCHAR2(3) ;
    ln_rate1      NUMBER ;
    ln_rate2      NUMBER ;
    lim_kz      NUMBER ;
    imza_kz      NUMBER ;
BEGIN
    OPEN pc_ref FOR
        SELECT 'OK' FROM dual;

    lim := TO_NUMBER(pn_amount,'99999999999.99');

    SELECT IMZA_SIRKULERI_IMZA_LIMIT,IMZA_SIRKULERI_CY
    INTO imza,imzacy
    FROM TBL_SPEC_COMPANY
    WHERE CUSTOMER_NO = pn_cust
    AND PERSON_ID   = ps_personid;


    IF ps_cycode = 'USD' THEN
        ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.99');
    ELSIF ps_cycode = 'EUR' THEN
        ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.99');
    ELSE
        ln_rate1:=1;
    END IF;
    lim_kz := lim * ln_rate1;

    IF imzacy = 'USD' THEN
        ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.99');
    ELSIF imzacy = 'EUR' THEN
        ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.99');
    ELSE
        ln_rate2:=1;
    END IF;
    imza_kz := imza * ln_rate2;

    IF lim_kz > imza_kz
    THEN
      ls_returncode:='054';
      RAISE LimitErrorException;
    END IF;
    RETURN ls_returncode;

EXCEPTION
         WHEN LimitErrorException THEN
               RETURN ls_returncode;
         WHEN OTHERS THEN
               Pkg_Log.AddCustomLog(SQLERRM,ps_rates);
               RETURN '050';
END;
-----------------------------------------------------------------------------------
FUNCTION GetUsedLimit(pn_musteri_no IN NUMBER,
                         pn_personid IN NUMBER,
                         ps_trancd IN VARCHAR2,
                         ps_channel IN VARCHAR2) RETURN NUMBER IS
     ln_used NUMBER;
BEGIN

     SELECT NVL(USED_LIMIT,0)
     INTO ln_used
     FROM TBL_LIMIT_USED
     WHERE PERSON_ID=pn_personid
     AND TRAN_CD=ps_trancd
     AND CHANNEL_CD=ps_channel
     AND TRUNC(USED_DATE)=TRUNC(SYSDATE);

     RETURN ln_used;

EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN 0;
END;
--------------------------------------------------------------------------------
FUNCTION UpdateRetailDefaultLimits(ps_option IN VARCHAR2,
                    ps_TRAN_CD IN VARCHAR2,
                    ps_DAILY_LIMIT IN VARCHAR2,
                    ps_TRAN_LIMIT IN VARCHAR2,
                    ps_CURRENCY_CD IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count           NUMBER;
    i              NUMBER:=1;
    ln_trancount  NUMBER:=6;
BEGIN

    IF ps_option='VIEW' THEN
         OPEN pc_ref FOR
                SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
                FROM TBL_RETAIL_LIMITS;

    ELSIF ps_option='UPDATE' THEN

        WHILE i<ln_trancount LOOP
            UPDATE TBL_DEFAULT_LIMITS_ISLEM
            SET
                DAILY_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_DAILY_LIMIT,';',i-1),'99999999999.99'),0),
                TRAN_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_TRAN_LIMIT,';',i-1),'99999999999.99'),0),
                CURRENCY_CD = Pkg_Admin.SPLIT(ps_CURRENCY_CD,';',i-1),
                STATUS_CD='sWAIT'
            WHERE TRAN_CD=Pkg_Admin.SPLIT(ps_TRAN_CD,';',i-1)
            AND CHANNEL_CD='cDKBRIB';

            i:=i+1;
        END LOOP;

      OPEN pc_ref FOR
        SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
        FROM TBL_DEFAULT_LIMITS_ISLEM
        WHERE CHANNEL_CD='cDKBRIB';
    END IF;

RETURN ls_returncode;
EXCEPTION
     WHEN OTHERS THEN
             Pkg_Log.AddCustomLog('LIM-4',SQLERRM);
           RETURN '050';
END;

--------------------------------------------------------------------------------
FUNCTION UpdateCorpDefaultLimits(ps_option IN VARCHAR2,
                    ps_TRAN_CD IN VARCHAR2,
                    ps_DAILY_LIMIT IN VARCHAR2,
                    ps_TRAN_LIMIT IN VARCHAR2,
                    ps_CURRENCY_CD IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count           NUMBER;
    i              NUMBER:=1;
    ln_trancount  NUMBER:=12; ----ChyngyzO cq4960 28.12.15 changed from 11 to 12
BEGIN
     IF ps_option='VIEW' THEN
          OPEN pc_ref FOR
            SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
            FROM TBL_CORP_LIMITS;

    ELSIF ps_option='UPDATE' THEN

        WHILE i<ln_trancount
    LOOP
        UPDATE TBL_DEFAULT_LIMITS_ISLEM
        SET
            DAILY_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_DAILY_LIMIT,';',i-1),'99999999999.99'),0),
            TRAN_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_TRAN_LIMIT,';',i-1),'99999999999.99'),0),
            CURRENCY_CD = Pkg_Admin.SPLIT(ps_CURRENCY_CD,';',i-1),
            STATUS_CD='sWAIT'
        WHERE TRAN_CD=Pkg_Admin.SPLIT(ps_TRAN_CD,';',i-1)
        AND CHANNEL_CD='cDKBCIB';

        i:=i+1;
    END LOOP;

  OPEN pc_ref FOR
    SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
    FROM TBL_DEFAULT_LIMITS_ISLEM
    WHERE CHANNEL_CD='cDKBCIB';


END IF;

    RETURN ls_returncode;
    EXCEPTION
         WHEN OTHERS THEN
                 Pkg_Log.AddCustomLog('LIM-4',SQLERRM);
               RETURN '050';
END;
--------------------------------------------------------------------------------
FUNCTION ApproveDefaultLimits(ps_option IN VARCHAR2,
                    ps_CHANNEL_CD IN VARCHAR2,
                    ps_TRAN_CD IN VARCHAR2,
                    ps_DAILY_LIMIT IN VARCHAR2,
                    ps_TRAN_LIMIT IN VARCHAR2,
                    ps_CURRENCY_CD IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count           NUMBER;
    i              NUMBER:=1;
    ln_trancount  NUMBER:=0;
BEGIN
     IF ps_option='LIST' THEN
          OPEN pc_ref FOR
            SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
            FROM TBL_DEFAULT_LIMITS_ISLEM
            WHERE CHANNEL_CD=ps_CHANNEL_CD
            AND STATUS_CD='sWAIT';

    ELSIF ps_option='APPROVE' AND ps_CHANNEL_CD='cDKBCIB'THEN

    ln_trancount:=12; --ChyngyzO cq4960 28.12.2015

    UPDATE TBL_DEFAULT_LIMITS_ISLEM
    SET STATUS_CD = 'sDONE'
    WHERE CHANNEL_CD='cDKBCIB';

     WHILE i<ln_trancount


    LOOP
        UPDATE TBL_CORP_LIMITS
        SET
            DAILY_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_DAILY_LIMIT,';',i-1),'99999999999.99'),0),
            TRAN_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_TRAN_LIMIT,';',i-1),'99999999999.99'),0),
            CURRENCY_CD = Pkg_Admin.SPLIT(ps_CURRENCY_CD,';',i-1)
        WHERE TRAN_CD=Pkg_Admin.SPLIT(ps_TRAN_CD,';',i-1);

        i:=i+1;

    END LOOP;

OPEN pc_ref FOR
    SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
    FROM TBL_DEFAULT_LIMITS_ISLEM
    WHERE CHANNEL_CD='cDKBCIB';

    ELSIF ps_option='APPROVE' AND ps_CHANNEL_CD='cDKBRIB'THEN

    ln_trancount:=12; 

    UPDATE TBL_DEFAULT_LIMITS_ISLEM
    SET STATUS_CD = 'sDONE'
    WHERE CHANNEL_CD='cDKBRIB';

            WHILE i<ln_trancount
    LOOP
        UPDATE TBL_RETAIL_LIMITS
        SET
            DAILY_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_DAILY_LIMIT,';',i-1),'99999999999.99'),0),
            TRAN_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_TRAN_LIMIT,';',i-1),'99999999999.99'),0),
            CURRENCY_CD = Pkg_Admin.SPLIT(ps_CURRENCY_CD,';',i-1)
        WHERE TRAN_CD=Pkg_Admin.SPLIT(ps_TRAN_CD,';',i-1);

        i:=i+1;

    END LOOP;

  OPEN pc_ref FOR
    SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
    FROM TBL_DEFAULT_LIMITS_ISLEM
    WHERE CHANNEL_CD='cDKBRIB';



ELSIF ps_option='CANCEL' AND ps_CHANNEL_CD='cDKBRIB'THEN

    UPDATE TBL_DEFAULT_LIMITS_ISLEM
    SET STATUS_CD = 'sCANCEL'
    WHERE CHANNEL_CD='cDKBRIB';


  OPEN pc_ref FOR
    SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
    FROM TBL_DEFAULT_LIMITS_ISLEM
    WHERE CHANNEL_CD='cDKBRIB';

ELSIF ps_option='CANCEL' AND ps_CHANNEL_CD='cDKBCIB'THEN

    UPDATE TBL_DEFAULT_LIMITS_ISLEM
    SET STATUS_CD = 'sCANCEL'
    WHERE CHANNEL_CD='cDKBCIB';


  OPEN pc_ref FOR
    SELECT TRAN_CD, DAILY_LIMIT, TRAN_LIMIT, CURRENCY_CD
    FROM TBL_DEFAULT_LIMITS_ISLEM
    WHERE CHANNEL_CD='cDKBCIB';

END IF;

    RETURN ls_returncode;
    EXCEPTION
         WHEN OTHERS THEN
                 Pkg_Log.AddCustomLog('LIM-4',SQLERRM);
               RETURN '050';
END;

FUNCTION GetLimitInfoV2(pn_musteri_no IN VARCHAR2,
                      pn_personid   IN VARCHAR2,
                      ps_trancd     IN VARCHAR2,
                      ps_channel    IN VARCHAR2,
                      ps_rates      IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    LimitErrorException     EXCEPTION;
    ln_count VARCHAR2(3):='000';
    l_dl      NUMBER ;
    l_dl_cy   VARCHAR2(3) ;
    l_used    NUMBER ;
    l_pl      NUMBER ;
    l_pl_cy   VARCHAR2(3) ;
    l_kalan   NUMBER;
    l_maxl    NUMBER;

    l_dl_kz      NUMBER ;
    l_pl_kz      NUMBER ;
    l_used_kz    NUMBER ;
    l_kalan_kz   NUMBER;
    l_maxl_kz   NUMBER;
    l_dl_rate  NUMBER;
    l_pl_rate  NUMBER;
    l_rate1  NUMBER;
    l_rate2  NUMBER;
    
    ln_DailyLimit           NUMBER;
    ls_DailyLimitCurrency   VARCHAR2(3);
    ln_UsedLimit            NUMBER;
    ln_TranLimit            NUMBER;
    ls_TranLimitCurrency    VARCHAR2(3);
    ln_RemainLimit          NUMBER;

BEGIN

    OPEN pc_ref FOR SELECT 'DUMMY' FROM dual;
    pkg_log.addcustomlog('GetLimitInfo',1,to_char(pn_musteri_no));
    

    IF ps_channel='cDKBRIB' THEN

        SELECT    a.DAILY_LIMIT, a.CURRENCY_CODE,Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel) used,a.ONETIME_LIMIT, a.CURRENCY_CODE,(a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel)) kalan
        INTO    l_dl,    l_dl_cy,    l_used,    l_pl,    l_pl_cy,    l_kalan
        FROM TBL_LIMIT_DEFAULTS a
        WHERE a.TRAN_CD = ps_trancd
        AND a.CHANNEL_CD = ps_channel
        AND a.PERSON_ID = pn_personid;

        OPEN pc_ref FOR
            SELECT    a.DAILY_LIMIT, a.CURRENCY_CODE,Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel) used,a.ONETIME_LIMIT, a.CURRENCY_CODE,(a.DAILY_LIMIT - Pkg_Limit.GetUsedLimit(pn_musteri_no,pn_personid,ps_trancd,ps_channel)) kalan
            FROM TBL_LIMIT_DEFAULTS a
            WHERE a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND a.PERSON_ID = pn_personid;

    ELSE --cDKBCIB
        IF ps_trancd IN ('CLEARING','UTILPAY','CLEARCNCL','CLEARPENS','TRANSPYM','PAYMORD','PORDCNCL', 'GROSS', 'SALARY') THEN --ChyngyzO cq4960 28.12.15 Salary added
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID;
pkg_log.addcustomlog('GetLimitInfo',2,to_char(ln_count));

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
            a.DAILY_LIMIT, a.LIMIT_CURRENCY,
            DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
            b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
            (c.MAX_DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan,
            c.MAX_DAILY_LIMIT
            INTO
            l_dl, l_dl_cy,
            l_used,
            l_pl, l_pl_cy,
            l_kalan, l_maxl
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;
            pkg_log.addcustomlog('GetLimitInfo',3,to_char(l_maxl));

            IF l_dl_cy = 'USD' THEN
                l_dl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',0),',',''),'.',','));
            ELSIF l_dl_cy = 'EUR' THEN
                l_dl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',1),',',''),'.',','));
            ELSE
                l_dl_rate :=1;
            END IF;

            l_dl_kz := l_dl * l_dl_rate;
            l_kalan_kz := l_kalan * l_dl_rate;
            l_used_kz := l_used * l_dl_rate;
            l_maxl_kz := l_maxl * l_dl_rate;

            IF l_pl_cy = 'USD' THEN
                l_pl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',0),',',''),'.',','));
            ELSIF l_pl_cy = 'EUR' THEN
                l_pl_rate := TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_rates,';',1),',',''),'.',','));
            ELSE
                l_pl_rate :=1;
            END IF;

            l_pl_kz := l_pl * l_pl_rate;
pkg_log.addcustomlog('GetLimitInfo',3,'max '||to_char(l_maxl_kz)||',dl '||to_char(l_dl_kz)||',used '||to_char(l_used_kz)||',kalan '||to_char(l_kalan_kz));
        OPEN pc_ref FOR
            SELECT l_dl_kz, 'KGS',
                   DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                   l_pl_kz, 'KGS', l_kalan_kz, l_maxl_kz
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;
        END IF;
    /**************************************************
    *****************   EXCHNGBUY **********************
    ***************************************************/
        IF ps_trancd IN ('EXCHNGBUY','FXORDER') THEN
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;
            pkg_log.addcustomlog('GetLimitInfo',4);

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT  a.DAILY_LIMIT, a.LIMIT_CURRENCY,
                    DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                    b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
                    (c.MAX_DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan,
                    c.MAX_DAILY_LIMIT
            INTO
                    l_dl, l_dl_cy,
                    l_used,
                    l_pl, l_pl_cy,
                    l_kalan, l_maxl
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;

            OPEN pc_ref FOR
                SELECT  l_dl, l_dl_cy,
                        DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                        l_pl, l_pl_cy, l_kalan, l_maxl
                FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
                WHERE a.CUSTOMER_ID = pn_musteri_no
                AND a.CUSTOMER_ID = b.CUSTOMER_NO
                AND a.TRAN_CD = ps_trancd
                AND a.CHANNEL_CD = ps_channel
                AND b.PERSON_ID = pn_personid 
                and c.CUSTOMER_NO=a.CUSTOMER_ID
                and c.TRAN_CD = a.TRAN_CD;
        END IF;
    /**************************************************
    *****************   EXCHNGSELL **********************
    ***************************************************/
        IF ps_trancd IN ('EXCHNGSELL','ARBITRAGE') THEN
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;
            pkg_log.addcustomlog('GetLimitInfo',5);

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
                    a.DAILY_LIMIT, a.LIMIT_CURRENCY,
                    DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                    b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
                    (c.MAX_DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan,
                    c.MAX_DAILY_LIMIT
            INTO
                    l_dl, l_dl_cy,
                    l_used,
                    l_pl, l_pl_cy,
                    l_kalan, l_maxl
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;

            OPEN pc_ref FOR
                SELECT
                l_dl, l_dl_cy,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                l_pl, l_pl_cy, l_kalan, l_maxl
                FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
                WHERE a.CUSTOMER_ID = pn_musteri_no
                AND a.CUSTOMER_ID = b.CUSTOMER_NO
                AND a.TRAN_CD = ps_trancd
                AND a.CHANNEL_CD = ps_channel
                AND b.PERSON_ID = pn_personid 
                and c.CUSTOMER_NO=a.CUSTOMER_ID
                and c.TRAN_CD = a.TRAN_CD;
        END IF;

    /**************************************************
    *****************  MONEY TRANSFER ****************
    ***************************************************/
        IF ps_trancd IN ('B2OBHVL','CARDPYM','SALARYPAY','P2OCARD','DDSINVOICE', 'CARDDEBT') THEN
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;
            pkg_log.addcustomlog('GetLimitInfo',6);

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
                a.DAILY_LIMIT, a.LIMIT_CURRENCY,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                b.ISLEM_LIMIT, b.ISLEM_LIMIT_CY,
                (c.MAX_DAILY_LIMIT - DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0)) kalan,
                c.MAX_DAILY_LIMIT
            INTO
                l_dl, l_dl_cy,
                l_used,
                l_pl, l_pl_cy,
                l_kalan, l_maxl
            FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
            WHERE a.CUSTOMER_ID = pn_musteri_no
            AND a.CUSTOMER_ID = b.CUSTOMER_NO
            AND a.TRAN_CD = ps_trancd
            AND a.CHANNEL_CD = ps_channel
            AND b.PERSON_ID = pn_personid 
            and c.CUSTOMER_NO=a.CUSTOMER_ID
            and c.TRAN_CD = a.TRAN_CD;


                 
            OPEN pc_ref FOR
                SELECT
                l_dl, l_dl_cy,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used,
                l_pl, l_pl_cy, l_kalan, l_maxl
                FROM TBL_APPROVAL_TRAN a,TBL_COMPANY b, TBL_APPROVAL_TRAN_MAX_LIMIT c
                WHERE a.CUSTOMER_ID = pn_musteri_no
                AND a.CUSTOMER_ID = b.CUSTOMER_NO
                AND a.TRAN_CD = ps_trancd
                AND a.CHANNEL_CD = ps_channel
                AND b.PERSON_ID = pn_personid 
                and c.CUSTOMER_NO=a.CUSTOMER_ID
                and c.TRAN_CD = a.TRAN_CD;
        END IF;

        IF ps_trancd IN ('SWIFT') and false THEN --chyngyzo 14012015 cq509  disabled
            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_LIMITS
            WHERE CHANNEL_CD = ps_channel
            AND CUSTOMER_NO = pn_musteri_no
            AND PERSON_ID = pn_personid
            AND TRAN_CD = ps_trancd;
            pkg_log.addcustomlog('GetLimitInfo',7);

            IF ln_count = 0 THEN
                RAISE LimitErrorException;
            END IF;

            SELECT
                DAILY_LIMIT, DAILY_LIMIT_CURRENCY,
                DECODE(TRUNC(USED_LIMIT_DATE),TO_CHAR(SYSDATE,'YYYYMMDD'),NVL(USED_LIMIT,0),0) used,
                TRAN_LIMIT, TRAN_LIMIT_CURRENCY,
                (DAILY_LIMIT - DECODE(TRUNC(USED_LIMIT_DATE),TO_CHAR(SYSDATE,'YYYYMMDD'),NVL(USED_LIMIT,0),0)) remain
            INTO
                ln_DailyLimit, ls_DailyLimitCurrency,
                ln_UsedLimit,
                ln_TranLimit, ls_TranLimitCurrency,
                ln_RemainLimit
            FROM TBL_LIMITS
            WHERE CHANNEL_CD = ps_channel
            AND CUSTOMER_NO = pn_musteri_no
            AND PERSON_ID = pn_personid
            AND TRAN_CD = ps_trancd;

            OPEN pc_ref FOR
                SELECT
                    ln_DailyLimit, ls_DailyLimitCurrency,
                    ln_UsedLimit,
                    ln_TranLimit, ls_TranLimitCurrency,
                    ln_RemainLimit
                FROM DUAL;
        END IF;
    END IF;--ChannelCD

  RETURN ls_returncode;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '050';
    WHEN LimitErrorException THEN
        OPEN pc_ref FOR
            SELECT SYSDATE FROM dual;
        RETURN '053';
    WHEN OTHERS THEN
        pkg_log.addcustomlog('GetLimitInfo',sqlerrm);
        RETURN '999';
END;

--------------------------------------------------------------------------------
END;
/

