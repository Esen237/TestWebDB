create PACKAGE BODY         "PKG_CUSTOMER" IS

-----------------------------------------------------------------------------
FUNCTION GetPersonInfo(ps_customerid IN NUMBER,
                      ps_channel IN VARCHAR2,
                      ps_personid     OUT VARCHAR2,
                       ps_channelcd     OUT VARCHAR2,
                      ps_customername    OUT VARCHAR2,
                     ps_birthdate OUT VARCHAR2,
                     ps_sex OUT VARCHAR2,
                     ps_pfc OUT VARCHAR2,
                     ps_expiredate OUT VARCHAR2,
                     ps_personstatus OUT VARCHAR2,
                     ps_identitystatus OUT VARCHAR2
                     ) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_returncode VARCHAR2(3):='000';

         CURSOR cursor_customer IS
            SELECT i.person_id,i.channel_cd,i.status_cd,i.EXPIREDATE,i.PWDFORCECHANGE
            ,p.FIRSTNAME,NVL(p.BIRTH_DATE,TO_DATE('01/01/1900','DD/MM/YYYY')) BIRTH_DATE,p.STATUS_CD IDSTATUS,NVL(p.SEX, ' ') SEX
            FROM TBL_IDENTIFICATION i, TBL_PERSON p
            WHERE i.person_id=p.person_id
                 AND p.customer_id=ps_customerid
                 AND i.channel_cd=ps_channel;

        row_customer cursor_customer%ROWTYPE;
BEGIN

     OPEN cursor_customer;
    FETCH cursor_customer INTO row_customer;
    IF cursor_customer%NOTFOUND THEN
        ls_returncode:='018';--customer not found
        RAISE TransactionError;
    END IF;
    CLOSE cursor_customer;

    ps_personid:=row_customer.PERSON_ID;
    ps_channelcd:=row_customer.channel_cd;
    ps_customername:=row_customer.FIRSTNAME;
    ps_birthdate:=row_customer.BIRTH_DATE;
    ps_sex:=row_customer.SEX;
    ps_pfc:=row_customer.PWDFORCECHANGE;
    ps_expiredate:=row_customer.EXPIREDATE;
    ps_personstatus:=row_customer.IDSTATUS;
    ps_identitystatus:=row_customer.status_CD;

 RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         Pkg_Log.AddCustomLog(SQLERRM);
         RETURN '009';


END;
-----------------------------------------------------------------------------------
FUNCTION GetPersonID(pn_customerid IN NUMBER,ps_channel VARCHAR2) RETURN NUMBER IS
     ls_personid                 NUMBER;
BEGIN
     SELECT p.PERSON_ID
     INTO    ls_personid
     FROM TBL_PERSON p, TBL_IDENTIFICATION i
     WHERE i.person_id=p.person_id
     AND p.CUSTOMER_ID=pn_customerid
     AND i.channel_cd=ps_channel 
     AND p.STATUS_CD='sENAB'
     AND i.STATUS_CD='sENAB';

     RETURN ls_personid;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
              RETURN NULL;
END;
-----------------------------------------------------------------------------------
FUNCTION GetCustomerID(pn_personrid IN NUMBER) RETURN VARCHAR2 IS
     ls_customerid                 VARCHAR2(13);
BEGIN
     SELECT p.CUSTOMER_ID
     INTO    ls_customerid
     FROM TBL_PERSON p
     WHERE p.PERSON_ID=pn_personrid;

     RETURN ls_customerid;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
              RETURN NULL;
END;
-----------------------------------------------------------------------------------
FUNCTION GetUserInfo(pn_customerid IN NUMBER,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_statement VARCHAR2(2000);
     TransactionError     EXCEPTION;
     ls_returncode         VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR
        SELECT p.CUSTOMER_ID,p.PERSON_ID, p.FIRSTNAME, p.MIDDLENAME,
             p.LASTNAME, p.EMAIL, p.BIRTH_DATE, p.STATUS_CD,
             i.CHANNEL_CD, i.USERNAME, i.EXPIREDATE, i.STATUS_CD, i.PWDFORCECHANGE,
             i.PWD_TYPE
        FROM TBL_IDENTIFICATION i, TBL_PERSON p
        WHERE p.person_id=i.person_id
        AND p.customer_id=pn_customerid;

 RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-------------------------------------------------------------------------------------
FUNCTION AddPayeeInfo(ps_option    IN VARCHAR2,
                      ps_PAYEE_ID IN VARCHAR2,
                      ps_PERSON_ID IN VARCHAR2,
                      ps_PAYEE_TYPE IN VARCHAR2,--EFT/MO
                     ps_SENDERNAME IN VARCHAR2,
                     ps_BANKCD IN VARCHAR2,
                     ps_PAYEENAME IN VARCHAR2,
                     ps_TOACCOUNT IN VARCHAR2,
                     ps_PAYMENTCD IN VARCHAR2,
                     ps_NICKNAME IN VARCHAR2,
                     ps_CURRCODE IN VARCHAR2,
                     ps_SENDERPHONE IN VARCHAR2 DEFAULT ' ',
                     ps_PAYEEPHONE IN VARCHAR2 DEFAULT ' ',
                     ps_rnn IN VARCHAR2,
                     ps_stat IN VARCHAR2,
                     ps_income IN VARCHAR2,
                     ps_docno IN VARCHAR2,
                     ps_PAYEE_NAME IN VARCHAR2,
                     ps_SUBACCOUNT_NO IN VARCHAR2,
                     ps_PAY_SUBNAME IN VARCHAR2
                     ) RETURN VARCHAR2 IS
    ln_payeeid                     NUMBER;
BEGIN
     IF ps_option='I' THEN

         ln_payeeid:=Pkg_Common.GetSequenceID('PAYEEID');

        INSERT INTO TBL_PAYEE
        (PAYEE_ID,
         PERSON_ID,
         PAYEE_TYPE,
         PAYEE_KIND,
         SENDERNAME,
         BANKCD,
         CITYCD,
         BRANCHCD,
         PAYEENAME,
         TOACCOUNT,
         PAYMENTCD,
         NICKNAME,
         CURRCODE,
         SENDERPHONE,
         SENDERADDRESS,
         PAYEEPHONE,
         RNN,
         STAT,
         INCOME_CODE,
         DOC_NO,
         PAYEE_NAME,
         SUBACCOUNT_NO,
         PAY_SUBNAME)
        VALUES
        (ln_payeeid,
         ps_PERSON_ID,
         ps_PAYEE_TYPE,
         'TO_ACCOUNT',
         SUBSTR(ps_SENDERNAME,0,80),
         ps_BANKCD,
         NULL,
         NULL,
         SUBSTR(ps_PAYEENAME,0,80),
         NVL(ps_TOACCOUNT,' '),
         ps_PAYMENTCD,
         SUBSTR(ps_NICKNAME,0,35),
         ps_CURRCODE,
         ps_SENDERPHONE,
         NULL,
          ps_PAYEEPHONE,
         ps_rnn,
         ps_stat,
         ps_income,
         ps_docno,
         ps_PAYEE_NAME,
         ps_SUBACCOUNT_NO,
         ps_PAY_SUBNAME);

     ELSIF ps_option='U' THEN

          UPDATE TBL_PAYEE p
         SET p.BANKCD=ps_BANKCD,
             p.PAYEENAME=SUBSTR(ps_PAYEENAME,0,80),
             p.TOACCOUNT=NVL(ps_TOACCOUNT,' '),
             p.NICKNAME=ps_NICKNAME,
             --p.RNN=ps_rnn,
            p.PAYEE_NAME=ps_PAYEE_NAME,
            p.SUBACCOUNT_NO=ps_SUBACCOUNT_NO,
            p.PAY_SUBNAME=ps_PAY_SUBNAME
         WHERE
              PAYEE_ID=TO_NUMBER(ps_PAYEE_ID);
     ELSIF ps_option='D' THEN
         DELETE FROM TBL_PAYEE
        WHERE
              PAYEE_ID=TO_NUMBER(ps_PAYEE_ID);
     END IF;
     RETURN '000';
EXCEPTION
         WHEN OTHERS THEN
              Pkg_Log.AddCustomLog(SQLERRM);
              RETURN '990';
END;
-------------------------------------------------------------------------------------
FUNCTION GetPayeeInfo(ps_PERSON_ID IN VARCHAR2,
                      ps_PAYEE_TYPE IN VARCHAR2 DEFAULT NULL,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode         VARCHAR2(3):='000';
BEGIN

IF ps_PAYEE_TYPE = 'HVL'
THEN
     OPEN pc_ref FOR
        SELECT NVL(PAYEE_ID,0),
             NVL(PERSON_ID,0),
             NVL(PAYEE_TYPE,' '),
             NVL(PAYEE_KIND,' '),
             NVL(SENDERNAME,' '),

             NVL(PAYEENAME,' '),
             NVL(TOACCOUNT,' '),
             NVL(NICKNAME,' '),
             NVL(CURRCODE,' '),
             NVL(SUBACCOUNT_NO,' '),
             NVL(PAY_SUBNAME,' ')

        FROM TBL_PAYEE
        WHERE PERSON_ID = NVL(TO_NUMBER(ps_PERSON_ID), PERSON_ID)
        AND PAYEE_TYPE=NVL(ps_PAYEE_TYPE,PAYEE_TYPE)
        ORDER BY PAYEE_KIND,NICKNAME,PAYEENAME;
ELSE
     OPEN pc_ref FOR
        SELECT NVL(PAYEE_ID,0),
             NVL(PERSON_ID,0),
             NVL(PAYEE_TYPE,' '),
             NVL(PAYEE_KIND,' '),
             NVL(SENDERNAME,' '),

             NVL(BANKCD,' '),
             NVL(PAYEENAME,' '),
             NVL(TOACCOUNT,' '),
             NVL(PAYMENTCD,' '),
             NVL(NICKNAME,' '),

             NVL(CURRCODE,' '),
             NVL(SENDERPHONE,' '),
             NVL(SENDERADDRESS,' '),
             NVL(PAYEEPHONE,' '),
             NVL(RNN,' '),

             NVL(STAT,0),
             NVL(INCOME_CODE,0),
             NVL(DOC_NO,0),
             NVL(SUBACCOUNT_NO,' '),
             NVL(PAY_SUBNAME,' '),
             NVL(CITYCD,' ')


        FROM TBL_PAYEE
        WHERE PERSON_ID = NVL(TO_NUMBER(ps_PERSON_ID), PERSON_ID)
        AND PAYEE_TYPE=NVL(ps_PAYEE_TYPE,PAYEE_TYPE)
        ORDER BY PAYEE_KIND,NICKNAME,PAYEENAME;
END IF;

 RETURN ls_returncode;
END;
-------------------------------------------------------------------------------------
FUNCTION SetUserMessage(ps_STARTDATE IN VARCHAR2,
                      ps_ENDDATE IN VARCHAR2,
                     ps_MESSAGE IN VARCHAR2,
                        ps_CHANNELCD IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode         VARCHAR2(3):='000';
 ln_warningid NUMBER:=0;
 BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

 ln_warningid:=Pkg_Common.GetSequenceID('WARNINGID');

    INSERT INTO TBL_USER_WARNINGS
    (CHANNEL_CD,WARNINGID,STARTDATE, ENDDATE, MESSAGE, STATUS)
    VALUES
    (ps_CHANNELCD,ln_warningid,TO_DATE(ps_STARTDATE,'YYYYMMDD'),TO_DATE(ps_ENDDATE,'YYYYMMDD'),ps_MESSAGE,'sENAB');

 RETURN ls_returncode;
 EXCEPTION
    WHEN OTHERS THEN
    RETURN '990';
END;
-------------------------------------------------------------------------------------
FUNCTION GetUserMessages(ps_PERSONID IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode         VARCHAR2(3):='000';
 ls_channelcd         VARCHAR2(20);

 BEGIN

    --Customer can see only same channel messages
    SELECT CHANNEL_CD
    INTO ls_channelcd
    FROM TBL_IDENTIFICATION
    WHERE person_id=TO_NUMBER(ps_PERSONID);

    OPEN pc_ref FOR
    SELECT
         MESSAGE,WARNINGID
    FROM
         TBL_USER_WARNINGS
    WHERE
          (STARTDATE - 1 <= SYSDATE) AND
         (ENDDATE + 1 >= SYSDATE) AND
         STATUS='sENAB' AND
         channel_cd=ls_channelcd AND
         (LIST_ID=0 OR LIST_ID IN (SELECT LIST_ID FROM TBL_USER_WARNINGS_LIST
                        WHERE CUSTOMER_ID=CORPINT.Pkg_Customer.GetCustomerID(TO_NUMBER(ps_PERSONID))
                         )
         ) AND
         WARNINGID NOT IN -- kullan?c? daha ?nceden iptal etmi? ise g?r?nt?leme
                        (SELECT WARNINGID FROM TBL_USER_WARNINGS_CANCEL
                        WHERE PERSONID=ps_PERSONID );

    RETURN ls_returncode;
 EXCEPTION
    WHEN NO_DATA_FOUND THEN
     OPEN pc_ref FOR
     SELECT SYSDATE FROM DUAL;

    WHEN OTHERS THEN
     RETURN '990';
END;
-------------------------------------------------------------------------------------
FUNCTION CancelUserMessage(ps_PERSONID IN VARCHAR2,
                            ps_MESSAGEID IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
ls_returncode          VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

    INSERT INTO TBL_USER_WARNINGS_CANCEL(WARNINGID, PERSONID)
    VALUES (ps_MESSAGEID,ps_PERSONID);

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
     RETURN '990';
END;

-----------------------------------------------------------------------------------
FUNCTION DisableUserMessage(ps_MESSAGEID IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
ls_returncode          VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

    UPDATE TBL_USER_WARNINGS
    SET STATUS='sDISABLED'
    WHERE
     WARNINGID=TO_NUMBER(ps_MESSAGEID);

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
     RETURN '990';
END;
-------------------------------------------------------------------------------------
FUNCTION SetEkstreInfo(ps_customerid IN VARCHAR2,
                       ps_password IN VARCHAR2,
                       ps_hatirlatmasoru IN VARCHAR2,
                       ps_hatirlatmacevap IN VARCHAR2,
                       ps_birthdate IN VARCHAR2,
                       ps_cinsiyet IN VARCHAR2,
                       ps_email IN VARCHAR2,
                       ps_firstname IN VARCHAR2,
                       ps_secondname IN VARCHAR2,
                       ps_surname IN VARCHAR2,
                       ps_accountid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode          VARCHAR2(3):='000';
    ls_ekstre_counter     NUMBER := 0;
    ps_ekstre_mevcut      EXCEPTION;
    ln_personid           NUMBER;

    BEGIN
    -- hata vermemesi i?in

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

    SELECT COUNT(*)
    INTO ls_ekstre_counter
    FROM TBL_EKSTRE_MAIN e
    WHERE e.CUSTOMERID = TO_NUMBER(ps_customerid)
    AND e.ACCOUNTID=TO_NUMBER(ps_accountid);

    IF (ls_ekstre_counter > 0) THEN
    RAISE ps_ekstre_mevcut;
    END IF;

    -- TBL_EKSTRE kayd? yap?l?yor
    INSERT INTO TBL_EKSTRE_MAIN(CUSTOMERID, PASSWD, HATIRLATMACEVABI, ACCOUNTID, HATIRLATMASORUSU)
    VALUES(TO_NUMBER(ps_customerid),ps_password,ps_hatirlatmacevap,TO_NUMBER(ps_accountid),ps_hatirlatmasoru);

    -- TBL_EKSTRE tablosuna ait eklenen kayda ba?l? olarak TBL_PERSON tablosuna da kay?t yap?l?yor
    --1) Get Person ID
    ln_personid:=Pkg_Common.GetSequenceID('pqPERSONID');

     --2) Insert Personal Info
     INSERT INTO TBL_PERSON
     (PERSON_ID, FIRSTNAME, MIDDLENAME, LASTNAME, EMAIL, CUSTOMER_ID, STATUS_CD)
      VALUES
     (ln_personid, ps_firstname, ps_secondname, ps_surname, ps_email, TO_NUMBER(ps_customerid), 'sENAB');

     UPDATE TBL_EKSTRE_MAIN m
     SET PERSONID=ln_personid
     WHERE m.ACCOUNTID =TO_NUMBER(ps_accountid)
     AND m.CUSTOMERID = TO_NUMBER(ps_customerid);

     RETURN ls_returncode;

EXCEPTION
  WHEN ps_ekstre_mevcut THEN
    RETURN '203';
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN '999';

END;
-------------------------------------------------------------------------------------
FUNCTION CheckEkstreInfo(ps_customerid IN VARCHAR2,
                         ps_password IN VARCHAR2,
                         ps_hatirlatmasoru IN VARCHAR2,
                         ps_hatirlatmacevap IN VARCHAR2,
                         ps_accountid IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode          VARCHAR2(3):='000';
    ls_count               NUMBER := 0;

    BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

    SELECT  COUNT(*)
    INTO  ls_count
    FROM    TBL_EKSTRE_MAIN m
    WHERE m.CUSTOMERID=TO_NUMBER(ps_customerid) AND m.ACCOUNTID=TO_NUMBER(ps_accountid) AND
    m.PASSWD = ps_password AND m.HATIRLATMASORUSU=TO_NUMBER(ps_hatirlatmasoru)
    AND m.HATIRLATMACEVABI=ps_hatirlatmacevap;

    IF  (ls_count > 0 ) THEN
    ls_returncode:= '000';
    ELSE
    ls_returncode:= '205';
    END IF;

    RETURN ls_returncode;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN '205';
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN '999';
END;
-------------------------------------------------------------------------------------
FUNCTION ChangePwdforEkstre(ps_oldpassword IN VARCHAR2,
                            ps_newpassword IN VARCHAR2,
                            ps_customerid IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode          VARCHAR2(3):='000';
    ls_count               NUMBER := 0;

    BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

    -- ?nce eski password do?ru mu ona bakaca??m
    SELECT COUNT(*)
    INTO ls_count
    FROM TBL_EKSTRE_MAIN
    WHERE CUSTOMERID=TO_NUMBER(ps_customerid)
          AND PASSWD=ps_oldpassword;

    IF (ls_count=0) THEN
    ls_returncode := '207'; -- yanl?? ?ifre
    ELSE
    UPDATE TBL_EKSTRE_MAIN
    SET PASSWD=ps_newpassword
    WHERE CUSTOMERID=TO_NUMBER(ps_customerid);
    END IF;

    RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN '999';
END;
-------------------------------------------------------------------------------------
FUNCTION ChangeAnsforEkstre(ps_question IN VARCHAR2,
                            ps_newanswer IN VARCHAR2,
                            ps_customerid IN VARCHAR2,
                            ps_accountid IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode          VARCHAR2(3):='000';
    ls_count               NUMBER := 0;

    BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;

    UPDATE TBL_EKSTRE_MAIN m
    SET m.HATIRLATMASORUSU=TO_NUMBER(ps_question) ,
        m.HATIRLATMACEVABI=ps_newanswer
    WHERE m.CUSTOMERID=TO_NUMBER(ps_customerid) AND
          m.ACCOUNTID=ps_accountid;

    RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN '999';
END;

-------------------------------------------------------------------------------------
FUNCTION GetUygunModulTurforExactDate(ps_date IN VARCHAR2,
                            ps_bankdate IN VARCHAR2,
                            ps_currcode IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode          VARCHAR2(3):='000';
    pl_uruntur           VARCHAR2(15):='TASARRF-TP';

    BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL; -- dummy

    IF (ps_currcode = 'TRY') THEN
    pl_uruntur:='TASARRF-TP';
    ELSE
    pl_uruntur:='TASARRF-YP';
    END IF;

    OPEN pc_ref FOR
    SELECT MODUL_TUR, URUN_TUR, URUN_SINIF
    FROM TBL_VADELI_HESAP_PARAMETRE
    WHERE URUN_TUR=pl_uruntur AND
    VADE_1 <= (TO_DATE(ps_date,'YYYYMMDD')-TO_DATE(ps_bankdate,'YYYYMMDD')) AND VADE_2 >= (TO_DATE(ps_date,'YYYYMMDD')-TO_DATE(ps_bankdate,'YYYYMMDD'));

    RETURN ls_returncode;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN '219';
  WHEN OTHERS THEN
    RETURN '999';
END;
----------------------------------------------------

FUNCTION GetUygunModulTurforDate(ps_date IN VARCHAR2,
                            ps_currcode IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode          VARCHAR2(3):='000';
    pl_uruntur           VARCHAR2(15):='TASARRF-TP';

    BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL; -- dummy

    IF (ps_currcode = 'TRY') THEN
    pl_uruntur:='TASARRF-TP';
    ELSE
    pl_uruntur:='TASARRF-YP';
    END IF;

    OPEN pc_ref FOR
    SELECT MODUL_TUR, URUN_TUR, URUN_SINIF
    FROM TBL_VADELI_HESAP_PARAMETRE
    WHERE URUN_TUR=pl_uruntur AND
    VADE_1 <= TO_NUMBER(ps_date) AND VADE_2 >= TO_NUMBER(ps_date);

    RETURN ls_returncode;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN '219';
  WHEN OTHERS THEN
    RETURN '999';
END;
----------------------------------------------
FUNCTION GetAgendaInfo(ps_personid IN VARCHAR2,
                       ps_channelid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode          VARCHAR2(3):='000';
 ls_count               NUMBER := 0;

BEGIN

    -- ?nce tarihi ge?enleri set edelim...
--    update tbl_agenda a
--    set a.STATUS='sDONE'
--    where trunc(a.MESSAGEDATE) < trunc(sysdate) and
--  a.PERSONID=to_number(ps_personid) and a.CHANNELID=ps_channelid
--    and a.STATUS <> 'sDONE';


    OPEN pc_ref FOR
     SELECT a.MESSAGE_ID,TO_CHAR(a.MESSAGESTR),TO_CHAR(a.MESSAGEDATE,'YYYYMMDD') FROM TBL_AGENDA a
    WHERE a.PERSONID=TO_NUMBER(ps_personid) AND a.CHANNELID=ps_channelid
    AND a.STATUS='sNEW'
    --and trunc(a.MESSAGEDATE) >= trunc(sysdate)
    ORDER BY a.MESSAGEDATE DESC;

    RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
    RETURN '999';
END;
-------------------------------------------------------------------
FUNCTION SetAgendaInfo(ps_personid IN VARCHAR2,
                       ps_channelid IN VARCHAR2,
                       ps_message IN VARCHAR2,
                       ps_messagedate IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode          VARCHAR2(3):='000';
 ln_messageid         NUMBER;

 not_valid_date EXCEPTION;
 PRAGMA EXCEPTION_INIT(not_valid_date,-01839); -- yanl?? zaman girilmesi durumunda

BEGIN

    ln_messageid:=Pkg_Common.GetSequenceID('AGENDAMSG');

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    IF (TO_DATE(ps_messagedate,'YYYYMMDD') >= TRUNC(SYSDATE)) THEN

    INSERT INTO TBL_AGENDA(MESSAGE_ID, PERSONID, STATUS, MESSAGEDATE, MESSAGESTR, SHOWONCE, EMAILME, EMAILADDRES, CHANNELID)
    VALUES (ln_messageid,TO_NUMBER(ps_personid),'sNEW',TO_DATE(ps_messagedate,'YYYYMMDD'),ps_message,'Y','N','',ps_channelid);

    ELSE
    ls_returncode:= '413';
    END IF;

    RETURN ls_returncode;

EXCEPTION
  WHEN not_valid_date THEN
    ls_returncode:='414';
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    RETURN ls_returncode;

  WHEN OTHERS THEN
    ls_returncode:= '999';
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    RETURN ls_returncode;

END;
-----------------------------------------------
FUNCTION ShowAgendaInfo(ps_personid IN VARCHAR2,
                       ps_channelid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode          VARCHAR2(3):='000';
 ls_count               NUMBER := 0;

BEGIN


    OPEN pc_ref FOR
     SELECT a.MESSAGE_ID,TO_CHAR(a.MESSAGESTR),TO_CHAR(a.MESSAGEDATE,'YYYYMMDD') FROM TBL_AGENDA a
    WHERE a.PERSONID=TO_NUMBER(ps_personid) AND a.CHANNELID=ps_channelid
    AND a.STATUS='sNEW' AND TRUNC(a.MESSAGEDATE) <= TRUNC(SYSDATE)
    ORDER BY a.MESSAGEDATE DESC;

    -- tarihi ge?enleri ve bug?nk?leri set edelim...
    UPDATE TBL_AGENDA a
    SET a.STATUS='sDONE'
    WHERE TRUNC(a.MESSAGEDATE) < TRUNC(SYSDATE) AND
    a.PERSONID=TO_NUMBER(ps_personid) AND a.CHANNELID=ps_channelid
    AND a.STATUS <> 'sDONE';


    RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
    RETURN '999';
END;
------------------------------------------
FUNCTION DelAgendaInfo(ps_messageid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode          VARCHAR2(3):='000';

BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    UPDATE TBL_AGENDA a
    SET a.STATUS='sDELETE'
    WHERE a.MESSAGE_ID=TO_NUMBER(ps_messageid);

    RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
    RETURN '999';
END;
------------------------------------------------------------------------------------
FUNCTION CreateIslemParola(
           ps_customerid VARCHAR2,
           ps_personid VARCHAR2,
           ps_islemtur VARCHAR2,
             ps_parola VARCHAR2,
              ps_raw_parola VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

           ls_returncode          VARCHAR2(3):='000';
           ln_parolaid NUMBER;
BEGIN

    ln_parolaid:=Pkg_Common.GetSequenceID('ISLEMPAROLA');

    OPEN pc_ref FOR
    SELECT ln_parolaid,ps_raw_parola FROM DUAL;

    INSERT INTO TBL_ISLEMPAROLA(PAROLAID, PERSONID, CUSTOMERID, PASSCODE, STATUS, ISLEMTUR)
    VALUES (ln_parolaid,TO_NUMBER(ps_personid),TO_NUMBER(ps_customerid),ps_parola,'sNEW',ps_islemtur);

    RETURN ls_returncode;

EXCEPTION
  WHEN OTHERS THEN
    RETURN '999';
END;
------------------------------------------------------
FUNCTION  CheckIslemParola(
           ps_parolaid IN VARCHAR2,
           ps_parola IN VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ls_count NUMBER:=0;
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;/*dummy expressions*/

    SELECT COUNT(*)
    INTO ls_count
    FROM TBL_ISLEMPAROLA T
    WHERE T.PAROLAID=ps_parolaid
    AND T.PASSCODE=ps_parola;

    IF (ls_count <> 1) THEN
    RETURN '641'; -- YANL?? ?IFRE
    END IF;

   RETURN ls_returncode;
   EXCEPTION
        WHEN OTHERS THEN
      RETURN '999';
END;
--------------------------------------------------------
FUNCTION  CheckTokenPresent(
              ps_personid VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ls_count NUMBER:=0;
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;/*dummy expressions*/

    SELECT COUNT(*)
    INTO ls_count
    FROM TBL_IDENTIFICATION T
    WHERE T.TOKEN_ID IS NOT NULL
    AND T.PERSON_ID=ps_personid;

    IF (ls_count <> 1) THEN
    RETURN '645'; -- token yok
    END IF;

   RETURN ls_returncode;
   EXCEPTION
        WHEN OTHERS THEN
      RETURN '999';
END;
---------------------------------------------------------------
FUNCTION  CheckparolaKilitlimi(
           ps_personid VARCHAR2,
           ps_chanelcd VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ls_count NUMBER:=0;
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;/*dummy expressions*/

    SELECT COUNT(*)
    INTO ls_count
    FROM TBL_PAROLA p
    WHERE p.PERSONID=ps_personid
    AND p.CHANNELCD=ps_chanelcd
    AND p.STATUS='sLOCKED';

    IF (ls_count > 0) THEN
    RETURN 634;
    END IF;

    RETURN ls_returncode;

END;
----------------------------------------
FUNCTION  GetCustomerNo(
           ps_personid VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
    SELECT p.CUSTOMER_ID
    FROM TBL_PERSON P
    WHERE P.PERSON_ID=ps_personid;
    RETURN ls_returncode;
END;
------------------------------------------------------
FUNCTION GetPersonName(pn_personid IN NUMBER) RETURN VARCHAR2 IS
     ls_customername                   VARCHAR2(200);
BEGIN
     SELECT p.FIRSTNAME
     INTO    ls_customername
     FROM TBL_PERSON p
     WHERE p.PERSON_ID=pn_personid;

     RETURN ls_customername;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN NULL;
END;
------------------------------------------------------
FUNCTION  GetPersonName2(ps_personid NUMBER,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
    SELECT p.FIRSTNAME || p.MIDDLENAME || p.LASTNAME UNVAN
    FROM TBL_PERSON P
    WHERE P.PERSON_ID=ps_personid;
    RETURN ls_returncode;
END;

------------------------------------------------------
FUNCTION CheckLimit(pn_musteri_no IN VARCHAR2,
                         ps_trancd IN VARCHAR2,
                         pn_amount IN VARCHAR2,
                        pn_personid IN VARCHAR2,
                        ps_channel  IN VARCHAR2,
                           ps_rates    IN VARCHAR2,
                           ps_cycode   IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_returncode        VARCHAR2(3);

BEGIN

     ls_returncode:=Pkg_Limit.CheckLimit(pn_musteri_no,ps_trancd,pn_amount , pn_personid,ps_channel,
                                            ps_rates ,  ps_cycode,    pc_ref);

    RETURN ls_returncode;
END;
-------------------------------------------------------
FUNCTION UpdateLimit(pn_musteri_no IN VARCHAR2,
                      ps_trancd IN VARCHAR2,
                      pn_amount IN VARCHAR2,
                     ps_currcode IN VARCHAR2,
                     ps_personid IN VARCHAR2,
                     ps_channel IN VARCHAR2,
                     ps_rates IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode        VARCHAR2(3);

BEGIN

     ls_returncode:=Pkg_Limit.UpdateLimit(pn_musteri_no ,ps_trancd,     pn_amount , ps_currcode,
                                          ps_personid , ps_channel, ps_rates, pc_ref);

    RETURN ls_returncode;
END;

--------------------------------------------------------
FUNCTION SetVerifyUpdateFlag(ps_txNo IN VARCHAR2,
                        ps_customerid IN VARCHAR2,
                        ps_verifiedapprovedid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode        VARCHAR2(3);
 ls_retcode            VARCHAR2(3);
BEGIN

     ls_returncode:=Pkg_Auth.SetVerifyUpdateFlag(ps_txNo,ps_customerid,ps_verifiedapprovedid,pc_ref);
     log_at('testbagdash', ls_returncode);

     IF ls_returncode='003' THEN--verify
         ls_retcode:=Pkg_Auth.SetVerifyMaker(ps_txNo,ps_verifiedapprovedid,pc_ref);
     ELSIF ls_returncode='005' THEN--check
         ls_retcode:=Pkg_Auth.SetCheckMaker(ps_txNo,ps_verifiedapprovedid,pc_ref);
     ELSIF ls_returncode='006' THEN--approve
         ls_retcode:=Pkg_Auth.SetApproveMaker(ps_txNo,ps_verifiedapprovedid,pc_ref);
     ELSIF ls_returncode='008' THEN--control
         ls_retcode:=Pkg_Auth.SetCurrencyController(ps_txNo,ps_verifiedapprovedid,pc_ref);
     END IF;

     RETURN ls_returncode;
END;
----------------------------------------------------------
FUNCTION GetMakerInfo(ps_customerid     IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2(3):='000';

BEGIN

    OPEN pc_ref FOR
          SELECT DISTINCT(a.PERSON_ID), a.FIRSTNAME
          FROM TBL_PERSON a, TBL_PERSON_AUTH b
          WHERE a.CUSTOMER_ID=ps_customerid
          AND a.person_id=b.person_id
          AND b.AUTH_CD LIKE 'aMAKE%';

    RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------
FUNCTION GetPersonInfo1(pn_customerid IN NUMBER,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR
        SELECT p.PERSON_ID, p.FIRSTNAME, p.MIDDLENAME,
               p.LASTNAME
        FROM TBL_PERSON p
        WHERE p.customer_id=pn_customerid;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;

---------------------------------------------------------------------------------------
FUNCTION GetPaymentCodes(ps_langcd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     IF (ps_langcd='ENG') THEN
     OPEN pc_ref FOR
         SELECT t.KOD, SUBSTR(t.ACIKLAMA_ING,1,70)||'...'
        FROM cbs.cbs_PAYMENT_CODE t
        WHERE t.ACIKLAMA_ING IS NOT NULL
        ORDER BY t.KOD;
     ELSE
     OPEN pc_ref FOR
     SELECT t.KOD, SUBSTR(t.ACIKLAMA_RUS,1,70)||'...'
        FROM cbs.cbs_PAYMENT_CODE t
        WHERE t.ACIKLAMA_RUS IS NOT NULL
        ORDER BY t.KOD;
    END IF;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
----------------------------------------------------------------------------------------
FUNCTION GetEmailStatementRates(ps_personid IN VARCHAR2,
                      pn_customerno IN VARCHAR2,
                      ps_channelcd IN VARCHAR2,
                       ps_rate IN VARCHAR2,
                       ps_move IN VARCHAR2,
                       ps_period1 IN VARCHAR2 ,
                      ps_period2 IN VARCHAR2 ,
                      ps_email1 IN VARCHAR2 ,
                        ps_email2 IN VARCHAR2 ,
                      pn_accountno IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode      VARCHAR2(3):='000';
     ls_count1 NUMBER:=0;
     ls_count2 NUMBER:=0;
     SubscribeException EXCEPTION;
     ln_period_count1 NUMBER:=0;
     ln_period_count2 NUMBER:=0;

BEGIN
     OPEN pc_ref FOR
     SELECT SYSDATE FROM dual;
     --check if customer subscribed for currency
     SELECT COUNT(*)
     INTO    ls_count1
     FROM    TBL_EMAIL_SUBSCRIPTION t
     WHERE    t.ACCOUNT_NO = pn_accountno
     AND    t.MSG_TYPE = 'CURRENCY';
     --check if customer subscribed for movement
      SELECT COUNT(*)
     INTO    ls_count2
     FROM    TBL_EMAIL_SUBSCRIPTION t
     WHERE    t.ACCOUNT_NO = pn_accountno
     AND    t.MSG_TYPE = 'MOVEMENT';

     ln_period_count1 := nvl(pkg_message.SPLIT(ps_email2,'###',0),'1');
     ln_period_count2 := nvl(pkg_message.SPLIT(ps_email2,'###',1),'1');

      IF (ps_rate = 'Y' AND ls_count1=0) THEN --subscribe for currency
        INSERT INTO TBL_EMAIL_SUBSCRIPTION
        (PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE,
        MSG_TYPE, PERIOD, NEXTRUNDATE, EMAIL,STATUS_CD,ACCOUNT_NO,PERIOD_COUNT)
        VALUES
        (TO_NUMBER(ps_personid),TO_NUMBER(pn_customerno),ps_channelcd,TRUNC(SYSDATE),
        'CURRENCY',ps_period1,DECODE(ps_period1,'G',TRUNC(SYSDATE+1*ln_period_count1),'H',TRUNC(SYSDATE+7*ln_period_count1),'A',TRUNC(ADD_MONTHS(SYSDATE,1*ln_period_count1))),
        ps_email1,'sENAB',TO_NUMBER(pn_accountno),ln_period_count1);
     END IF;

     IF (ps_move = 'Y' AND ls_count2=0) THEN --subscrive for movement
        INSERT INTO TBL_EMAIL_SUBSCRIPTION
        (PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE,
        MSG_TYPE, PERIOD, NEXTRUNDATE, EMAIL,STATUS_CD,ACCOUNT_NO,PERIOD_COUNT)
        VALUES
        (TO_NUMBER(ps_personid),TO_NUMBER(pn_customerno),ps_channelcd,TRUNC(SYSDATE),
        'MOVEMENT',ps_period2,DECODE(ps_period2,'G',TRUNC(SYSDATE+1*ln_period_count2),'H',TRUNC(SYSDATE+7*ln_period_count2),'A',TRUNC(ADD_MONTHS(SYSDATE,1*ln_period_count2))),
        ps_email1,'sENAB',TO_NUMBER(pn_accountno),ln_period_count2);
     END IF;

     RETURN ls_returncode;
EXCEPTION
         WHEN SubscribeException THEN
               RETURN '999';
END;
-------------------------------------------------------------------------------
FUNCTION GetPaymentCodesForB2OBHVL(ps_langcd IN VARCHAR2,
                                   ps_channelcd IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        SELECT LEVEL AS pathlength, PARENT_GROUP_ID, ID, DECODE(ps_langcd, 'ENG', DESCRIPTION_ENG, DESCRIPTION_RUS), TYPE, TRAN_CODE from
        (
            select ID, PARENT_GROUP_ID, DESCRIPTION_ENG, DESCRIPTION_RUS, 'GROUP' TYPE, TRAN_CODE
            from cbs_payment_code_group aa
            where CHANNEL_CODE = ps_channelcd
            and status_cd='sENAB'
            union
            select to_number(bb.KOD), aa.ID PARENT_GROUP_ID, bb.ACIKLAMA_ING, bb.ACIKLAMA_RUS, 'PAYMENT', aa.TRAN_CODE
            from cbs_payment_code_group aa, cbs_payment_code bb
            where instr(aa.children, bb.kod, 1, 1)>0
            and aa.status_cd='sENAB'
        )
        START WITH PARENT_GROUP_ID IS NULL CONNECT BY PRIOR ID = PARENT_GROUP_ID;

        /*SELECT t.KOD, DECODE(ps_langcd,'ENG',SUBSTR(t.ACIKLAMA_ING,1,70)||'...',SUBSTR(t.ACIKLAMA_RUS,1,70)||'...')
            FROM TBL_PAYMENT_CODE t
            WHERE t.ACIKLAMA_ING IS NOT NULL
            ORDER BY t.KOD;*/

    RETURN ls_returncode;
EXCEPTION
    WHEN TransactionError THEN
         RETURN ls_returncode;
END;
-------------------------------------------------------------------------------
FUNCTION UpdatePaymentCode4B2OBHVL(ps_option        IN VARCHAR2,
                                   ps_langcd        IN VARCHAR2,
                                   pn_paymentcode   IN VARCHAR2,
                                   pn_parentcode    IN VARCHAR2,
                                   ps_paynameeng    IN VARCHAR2,
                                   ps_paynamerus    IN VARCHAR2,
                                   ps_trancode      IN VARCHAR2,
                                   ps_channelcode   IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ls_count      NUMBER;
    ls_type       VARCHAR2(20):='PAYMENT';
    ls_parentsChildren VARCHAR2(2000) := '';
    ls_paymentcode VARCHAR2(200);

    CURSOR cursor_groups(pn_payment_code VARCHAR2) IS
        SELECT * FROM CBS_PAYMENT_CODE_GROUP
        WHERE INSTR(CHILDREN, pn_payment_code, 1, 1) > 0
        AND STATUS_CD='sENAB';

    row_groups cursor_groups%ROWTYPE;

BEGIN

    log_at('UpdatePaymentCode4B2OBHVL','f1');
    OPEN pc_ref FOR
        SELECT '', '', '', '', '', '', ps_channelcode, '' FROM dual;

     IF ps_option='INQUIRY' THEN

        OPEN pc_ref FOR
            SELECT KOD, DECODE(ps_langcd,'ENG', ACIKLAMA_ING, ACIKLAMA_RUS), CLEARING, 0 PARENT_GROUP_ID, 'PAYMENT', ps_channelcode
            FROM CBS_PAYMENT_CODE bb
            WHERE ACIKLAMA_ING IS NOT NULL
            AND KOD=pn_paymentcode
            ORDER BY KOD;

     ELSIF ps_option='ALL_PAYMENTS' THEN

        OPEN pc_ref FOR
            SELECT KOD, DECODE(ps_langcd,'ENG', ACIKLAMA_ING, ACIKLAMA_RUS), CLEARING, 0 PARENT_GROUP_ID, 'PAYMENT', ps_channelcode
            FROM CBS_PAYMENT_CODE bb
            WHERE ACIKLAMA_ING IS NOT NULL
            AND KOD=nvl(pn_paymentcode, KOD)
            ORDER BY KOD;

     ELSIF ps_option='DETAIL' THEN
        SELECT COUNT(*)
        INTO ls_count
        FROM CBS_PAYMENT_CODE_GROUP
        WHERE ID=pn_paymentcode
        AND STATUS_CD='sENAB';

        if (ls_count>0) then
            OPEN pc_ref FOR
                SELECT ID, DESCRIPTION_ENG, TRAN_CODE, DESCRIPTION_RUS, PARENT_GROUP_ID, 'GROUP', CHANNEL_CODE, CHILDREN
                FROM CBS_PAYMENT_CODE_GROUP aa
                WHERE ID=pn_paymentcode
                AND STATUS_CD='sENAB';
        else

            --5)Get Customer Info
            OPEN cursor_groups(pn_paymentcode);
            FETCH cursor_groups INTO row_groups;
            WHILE  cursor_groups%FOUND LOOP
                IF  cursor_groups%FOUND THEN
                    ls_parentsChildren := ls_parentsChildren || row_groups.ID || ',';
                END IF;
            FETCH cursor_groups INTO row_groups;
            END LOOP;
            CLOSE cursor_groups;


            OPEN pc_ref FOR
                SELECT KOD, ACIKLAMA_ING, CLEARING, ACIKLAMA_RUS, 0 PARENT_GROUP_ID, 'PAYMENT', ps_channelcode, ls_parentsChildren
                FROM CBS_PAYMENT_CODE bb
                WHERE KOD=pn_paymentcode;
        end if;

     ELSIF ps_option='GROUPS' THEN

        OPEN pc_ref FOR
            SELECT LEVEL AS pathlength, PARENT_GROUP_ID, ID, DESCRIPTION_ENG, DESCRIPTION_RUS, 'GROUP' TYPE, CHANNEL_CODE
            FROM CBS_PAYMENT_CODE_GROUP aa
            WHERE aa.STATUS_CD='sENAB'
            START WITH PARENT_GROUP_ID IS NULL CONNECT BY PRIOR ID = PARENT_GROUP_ID;

     ELSIF ps_option='GROUPSBYCHANNEL' THEN

        OPEN pc_ref FOR
            SELECT LEVEL AS pathlength, PARENT_GROUP_ID, ID, DESCRIPTION_ENG, DESCRIPTION_RUS, 'GROUP' TYPE, CHANNEL_CODE
            FROM CBS_PAYMENT_CODE_GROUP aa
            WHERE CHANNEL_CODE = ps_channelcode
            AND TRAN_CODE = ps_trancode
            AND aa.STATUS_CD='sENAB'
            START WITH PARENT_GROUP_ID IS NULL CONNECT BY PRIOR ID = PARENT_GROUP_ID;

     ELSIF ps_option='PAYMENTCODESBYGROUP' THEN

        OPEN pc_ref FOR
            select  bb.KOD, DECODE(ps_langcd,'ENG', ACIKLAMA_ING, ACIKLAMA_RUS), CLEARING, aa.ID PARENT_GROUP_ID, 'PAYMENT', ps_channelcode
            from cbs.cbs_payment_code_group aa, cbs_payment_code bb
            WHERE INSTR(aa.children, bb.kod, 1, 1)>0
            AND ACIKLAMA_ING IS NOT NULL
            --AND CLEARING = decode(ps_trancode,'CLEARING','E','H')
            AND TRAN_CODE = ps_trancode
            AND aa.ID = pn_parentcode
            AND aa.STATUS_CD='sENAB'
            ORDER BY KOD;

     ELSIF ps_option='UPDATE' THEN

        ls_paymentcode := pn_paymentcode;
        ls_parentsChildren := pkg_message.SPLIT(pn_parentcode,'###',1);

        SELECT COUNT(*)
        INTO ls_count
        FROM CBS_PAYMENT_CODE_GROUP
        WHERE ID=ls_paymentcode
        AND STATUS_CD='sENAB';

        if (ls_count>0) then
            UPDATE CBS_PAYMENT_CODE_GROUP
            SET  DESCRIPTION_ENG=ps_paynameeng,
                 DESCRIPTION_RUS=ps_paynamerus,
                 PARENT_GROUP_ID=to_number(pkg_message.SPLIT(pn_parentcode,'###',0)),
                 CHILDREN = pkg_message.SPLIT(pn_parentcode,'###',1),
                 TRAN_CODE = ps_trancode,
                 CHANNEL_CODE = ps_channelcode
            WHERE ID=ls_paymentcode
            AND STATUS_CD='sENAB';
        else

            SELECT COUNT(*)
            INTO ls_count
            FROM CBS_PAYMENT_CODE
            WHERE KOD=ls_paymentcode;

            IF ls_count=0 THEN

                UPDATE CBS_PAYMENT_CODE_GROUP
                SET  CHILDREN = replace(CHILDREN, ls_paymentcode || ',','') || ls_paymentcode || ','
                WHERE INSTR(','||pn_parentcode||',', TO_CHAR(','||ID||','), 1, 1) > 0
                AND STATUS_CD='sENAB';

                INSERT INTO CBS.CBS_PAYMENT_CODE
                (KOD, ACIKLAMA_ING, CLEARING, ACIKLAMA_RUS)
                VALUES
                (ls_paymentcode, ps_paynameeng, decode(ps_trancode,'CLEARING','E','H'), ps_paynamerus);
            ELSE

                UPDATE CBS_PAYMENT_CODE_GROUP
                SET CHILDREN = REPLACE(CHILDREN, ls_paymentcode || ',', '')
                WHERE INSTR(','||CHILDREN||',', ','||ls_paymentcode||',', 1, 1) > 0
                AND STATUS_CD='sENAB';

                UPDATE CBS_PAYMENT_CODE_GROUP
                SET  CHILDREN = replace(CHILDREN, ls_paymentcode || ',','') || ls_paymentcode || ','
                WHERE INSTR(','||pkg_message.SPLIT(pn_parentcode,'###',1)||',', TO_CHAR(','||ID||','), 1, 1) > 0
                AND STATUS_CD='sENAB';

                UPDATE CBS_PAYMENT_CODE
                SET  ACIKLAMA_ING=ps_paynameeng,
                     ACIKLAMA_RUS=ps_paynamerus,
                     CLEARING = decode(ps_trancode,'CLEARING','E','H')
                WHERE KOD=ls_paymentcode;
            END IF;
        end if;

        OPEN pc_ref FOR
            SELECT KOD, ACIKLAMA_ING, CLEARING, ACIKLAMA_RUS, 0 PARENT_GROUP_ID, 'PAYMENT', ps_channelcode, ''
            FROM CBS_PAYMENT_CODE bb
            WHERE KOD=ls_paymentcode;

     ELSIF ps_option='DELETE' THEN

        ls_count:=1;
        while pkg_message.SPLIT(pn_paymentcode,',',ls_count) is not null loop
            ls_paymentcode := pkg_message.SPLIT(pn_paymentcode,',',ls_count);

            UPDATE CBS_PAYMENT_CODE_GROUP
            SET CHILDREN = REPLACE( REPLACE(CHILDREN, ls_paymentcode || ',', ''), ',' || ls_paymentcode, '')
            WHERE INSTR(','||CHILDREN||',', ','||ls_paymentcode||',', 1, 1) > 0
            AND STATUS_CD='sENAB';

            ls_count:=ls_count+1;
        end loop;

        UPDATE CBS_PAYMENT_CODE_GROUP
        SET STATUS_CD='sDISAB'
        WHERE INSTR(','||pn_paymentcode||',', ','||TO_CHAR(ID)||',', 1, 1) > 0;

     ELSIF ps_option='NEW' THEN

        INSERT INTO CBS_PAYMENT_CODE_GROUP
        (ID, PARENT_GROUP_ID, DESCRIPTION_ENG, DESCRIPTION_RUS, CHANNEL_CODE, TRAN_CODE, CHILDREN, STATUS_CD)
        VALUES
        (Pkg_Common.GetSequenceID('pqPAYMENTGROUP'), to_number(pkg_message.SPLIT(pn_parentcode,'###',0)), ps_paynameeng,
        ps_paynamerus, ps_channelcode, ps_trancode, pkg_message.SPLIT(pn_parentcode,'###',1),'sENAB');

     ELSE
        OPEN pc_ref FOR
            SELECT '', '', '', '', '', '', ps_channelcode, '' FROM dual;
     END IF;


     RETURN ls_returncode;

EXCEPTION
     WHEN OTHERS THEN
         OPEN pc_ref FOR SELECT '-' FROM dual;
         PKG_LOG.ADDCUSTOMLOG('UpdatePaymentCode4B2OBHVL', sqlerrm);
         RETURN '999';
END;
-------------------------------------------------------------------------------
FUNCTION GetSubscribedAccounts(ps_person_id IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     RETURN ls_returncode;
EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-------------------------------------------------------------------------------------
FUNCTION Beneficiaries(ps_option    IN VARCHAR2,
                       ps_PAYEE_ID IN VARCHAR2,
                       ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2,
                       ps_SENDERNAME IN VARCHAR2,
                       ps_BANKCD IN VARCHAR2,
                       ps_PAYEENAME IN VARCHAR2,
                       ps_TOACCOUNT IN VARCHAR2,
                       ps_PAYMENTCD IN VARCHAR2,
                       ps_NICKNAME IN VARCHAR2,
                       ps_CURRCODE IN VARCHAR2,
                       ps_SENDERPHONE IN VARCHAR2 DEFAULT ' ',
                       ps_PAYEEPHONE IN VARCHAR2 DEFAULT ' ',
                       ps_rnn IN VARCHAR2,
                       ps_stat IN VARCHAR2,
                       ps_income IN VARCHAR2,
                       ps_docno IN VARCHAR2,
                       ps_PAYEE_NAME IN VARCHAR2,
                       ps_SUBACCOUNT_NO IN VARCHAR2,
                       ps_PAY_SUBNAME IN VARCHAR2,
                       ps_CUSTOMER_NO IN VARCHAR2,
                       ps_ADDRESS IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ln_payeeid NUMBER;
BEGIN
    OPEN pc_ref FOR
        SELECT SYSDATE FROM DUAL;

    IF ps_option='NEW' THEN

        ln_payeeid:=Pkg_Common.GetSequenceID('PAYEEID');

        INSERT INTO TBL_PAYEE
        (PAYEE_ID, PERSON_ID, PAYEE_TYPE, PAYEE_KIND, SENDERNAME,
        BANKCD, CITYCD, BRANCHCD, PAYEENAME, TOACCOUNT,
        PAYMENTCD, NICKNAME, CURRCODE, SENDERPHONE, SENDERADDRESS,
        PAYEEPHONE, RNN, STAT, INCOME_CODE, DOC_NO,
        PAYEE_NAME, SUBACCOUNT_NO, PAY_SUBNAME)
        VALUES
        (ln_payeeid, ps_PERSON_ID, ps_PAYEE_TYPE, 'TO_ACCOUNT', SUBSTR(ps_SENDERNAME,0,80),
        ps_BANKCD, NULL, NULL, SUBSTR(ps_PAYEENAME,0,80), NVL(ps_TOACCOUNT,' '),
        ps_PAYMENTCD, SUBSTR(ps_NICKNAME,0,35), ps_CURRCODE, DECODE(ps_PAYEE_TYPE,'SWIFT','***',ps_SENDERPHONE), ps_ADDRESS,
        ps_PAYEEPHONE, ps_rnn, ps_stat, ps_income, ps_docno,
        ps_PAYEE_NAME, ps_SUBACCOUNT_NO, ps_PAY_SUBNAME);

    ELSIF ps_option='UPDATE' THEN

        UPDATE TBL_PAYEE p
        SET p.BANKCD=ps_BANKCD,
            p.PAYEENAME=SUBSTR(ps_PAYEENAME,0,80),
            p.TOACCOUNT=NVL(ps_TOACCOUNT,' '),
            p.NICKNAME=ps_NICKNAME,
            p.PAYEE_NAME=ps_PAYEE_NAME,
            p.SUBACCOUNT_NO=ps_SUBACCOUNT_NO,
            p.PAY_SUBNAME=ps_PAY_SUBNAME,
            p.SENDERNAME = SUBSTR(ps_SENDERNAME,0,80),
            p.SENDERADDRESS = ps_ADDRESS,
            p.CURRCODE = ps_CURRCODE
        WHERE PAYEE_ID=TO_NUMBER(ps_PAYEE_ID);

    ELSIF ps_option='GET' THEN

        OPEN pc_ref FOR
            SELECT NVL(PAYEE_ID,0), NVL(PERSON_ID,0), NVL(PAYEE_TYPE,' '), NVL(PAYEE_KIND,' '), NVL(SENDERNAME,' '),
                   NVL(BANKCD,' '), NVL(PAYEENAME,' '), NVL(TOACCOUNT,' '), NVL(PAYMENTCD,' '), NVL(NICKNAME,' '),
                   NVL(CURRCODE,' '), NVL(SENDERPHONE,' '), NVL(SENDERADDRESS,' '), NVL(PAYEEPHONE,'***'), NVL(RNN,' '),
                   NVL(STAT,0), NVL(INCOME_CODE,0), NVL(DOC_NO,0), NVL(SUBACCOUNT_NO,' '), NVL(PAY_SUBNAME,' '),
                   NVL(CITYCD,' ')
            FROM CORPINT.TBL_PAYEE
            WHERE PERSON_ID IN (SELECT PERSON_ID FROM CORPINT.TBL_PERSON WHERE CUSTOMER_ID = NVL(ps_CUSTOMER_NO, CUSTOMER_ID))
            AND PAYEE_TYPE = NVL(ps_PAYEE_TYPE,PAYEE_TYPE)
            AND PAYEE_ID = NVL(ps_PAYEE_ID,PAYEE_ID)
            ORDER BY PAYEE_KIND,NICKNAME,PAYEENAME;

    ELSIF ps_option='DELETE' THEN

        DELETE FROM TBL_PAYEE
        WHERE PAYEE_ID=TO_NUMBER(ps_PAYEE_ID);

    END IF;

    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
        Pkg_Log.AddCustomLog('Beneficiaries', SQLERRM);
        RETURN '999';
END;
-------------------------------------------------------------------------------------
FUNCTION PayeeRestrictions(ps_option    IN VARCHAR2,
                           ps_CUSTOMER_NO IN VARCHAR2,
                           ps_TRAN_TYPE IN VARCHAR2,
                           ps_PAYEE_RESTRICTED IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ln_count NUMBER;
BEGIN

    OPEN pc_ref FOR
        SELECT CUSTOMER_ID,
               TRAN_TYPE,
               PAYEE_RESTRICTED
        FROM CORPINT.TBL_PAYEE_RESTRICTED
        WHERE CUSTOMER_ID=NVL(TO_NUMBER(ps_CUSTOMER_NO), CUSTOMER_ID);

    IF ps_option='UPDATE' THEN

        select count(1) into ln_count
        from CORPINT.TBL_PAYEE_RESTRICTED
        WHERE CUSTOMER_ID=TO_NUMBER(ps_CUSTOMER_NO);

        if (ln_count>0) then
            UPDATE CORPINT.TBL_PAYEE_RESTRICTED
            SET TRAN_TYPE=ps_TRAN_TYPE,
                PAYEE_RESTRICTED=ps_PAYEE_RESTRICTED
            WHERE CUSTOMER_ID=TO_NUMBER(ps_CUSTOMER_NO);
        else
            INSERT INTO CORPINT.TBL_PAYEE_RESTRICTED
            (CUSTOMER_ID, TRAN_TYPE, PAYEE_RESTRICTED)
            VALUES
            (ps_CUSTOMER_NO, ps_TRAN_TYPE, ps_PAYEE_RESTRICTED);
        end if;

    ELSIF ps_option='GET_CUSTOMERS' THEN
        OPEN pc_ref FOR
            SELECT DISTINCT CUSTOMER_ID
            FROM CORPINT.TBL_PAYEE_RESTRICTED
            WHERE INSTR(PAYEE_RESTRICTED, 'Y', 1) > 0;
    END IF;

    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
        Pkg_Log.AddCustomLog('PayeeRestrictions', SQLERRM);
        RETURN '999';
END;
-------------------------------------------------------------------------------------
--B-O-M ernestk 17032014 cqdb00000498 to get payee info by payee id
/*******************************************************************************
    Name: GetPayeeInfoByPayeeId
    Author: Ernest Kuttubaev
    Modify Date: 16.10.2013
    
    Desc: Returns cursot to payee data that is retrieved by payee id
*******************************************************************************/
FUNCTION getPayeeInfoByPayeeId( ps_person_id    IN  varchar2,
                                ps_payee_id     IN  varchar2,
                                pc_ref          OUT CursorReferenceType) RETURN VARCHAR2
IS
    ls_returncode   varchar2(3)     :=  '000';
BEGIN
    open pc_ref for
        select  payee_id,
                person_id,
                payee_type,
                payee_kind,
                sendername,
                bankcd,
                payeename,
                toaccount,
                paymentcd,
                nickname,
                currcode,
                branchcd,
                citycd,
                senderphone,
                senderaddress,
                payeephone,
                rnn,
                stat,
                income_code,
                doc_no,
                payee_name,
                subaccount_no,
                pay_subname,
                dlm
        from    corpint.tbl_payee
        where   payee_id=to_number(ps_payee_id)
                and person_id=to_number(ps_person_id);
    
    return ls_returncode;
exception
    when no_data_found then
        RETURN '888';
    when others then
        Pkg_Log.AddCustomLog('GetPayeeInfoByPayeeId', SQLERRM);
        RETURN '999';
--E-O-M ernestk 17032014 cqdb00000498 to get payee info by payee id
                
END;



/*******************************************************************************
    Name            :setSwiftOption
    Prepared By :Chyngyz Omurov (cq509)
    Modify Date :10.02.2015
    Pupose      : To set swift option ON/OFF
*******************************************************************************/
FUNCTION setSwiftOption( ps_customerid VARCHAR2,
                                               ps_personid VARCHAR2,
                                               ps_status VARCHAR2,
                                               pc_ref OUT   cursorreferencetype) RETURN VARCHAR2
                                               IS
        ls_returncode            VARCHAR2 (2000) := '000';
        
        ls_check VARCHAR2(1) := 'N';
        ls_verify VARCHAR2(1) := 'N';
        ls_approve VARCHAR2(1) := 'Y';
        
        CURSOR cursor_makers IS 
            SELECT DISTINCT person_id  
            FROM corpint.tbl_person_auth 
            WHERE person_id IN (SELECT person_id FROM corpint.tbl_person WHERE customer_id=TO_NUMBER(ps_customerid))  AND auth_cd LIKE '%MAKE%';
            
       CURSOR cursor_viewers IS 
            SELECT DISTINCT person_id  
            FROM corpint.tbl_person_auth 
            WHERE person_id IN (SELECT person_id FROM corpint.tbl_person WHERE customer_id=TO_NUMBER(ps_customerid))  AND auth_cd LIKE '%VIEW%';
        
       CURSOR cursor_checkers IS 
            SELECT DISTINCT person_id  
            FROM corpint.tbl_person_approval 
            WHERE person_id IN (SELECT person_id FROM corpint.tbl_person WHERE customer_id=TO_NUMBER(ps_customerid))  AND auth_cd LIKE '%CHCK%';
         
       CURSOR cursor_verifiers IS 
            SELECT DISTINCT person_id  
            FROM corpint.tbl_person_approval 
            WHERE person_id IN (SELECT person_id FROM corpint.tbl_person WHERE customer_id=TO_NUMBER(ps_customerid))  AND auth_cd LIKE '%VRFY%';
        
       CURSOR cursor_approvers IS 
            SELECT DISTINCT person_id  
            FROM corpint.tbl_person_approval 
            WHERE person_id IN (SELECT person_id FROM corpint.tbl_person WHERE customer_id=TO_NUMBER(ps_customerid))  AND auth_cd LIKE '%APPR%';
            
BEGIN
    
    --add to swift insiders for corporates----------------------------------------
    DELETE FROM CORPINT.TBL_SWIFT_INSIDERS_CIB WHERE CUSTOMER_ID = ps_customerid;
    
     INSERT INTO CORPINT.TBL_SWIFT_INSIDERS_CIB(CUSTOMER_ID, CREATE_PERSON_ID, STATUS, CREATE_DATE)
     VALUES(ps_customerid, ps_personid, UPPER(ps_status), SYSDATE);
     
    --if customer declined swift option return
    IF UPPER(ps_status) <> 'ON' THEN
          COMMIT;
          OPEN pc_ref FOR SELECT  ls_returncode FROM dual;
          return ls_returncode;
    END IF;  
         
    --------------------------------------------------------GIVE VIEWER, MAKER,  CHECKER, VERIFIER AND APPROVER RIGHTS-----------------------------------------------------
     --GIVE MAKER RIGHTS        
    FOR maker_person in cursor_makers
    LOOP
         --GIVE VIEWER RIGHTS FOR MAKER----
        DELETE FROM corpint.tbl_person_auth
        WHERE person_id=maker_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aVIEWSWIFT' ;
        
        INSERT INTO corpint.tbl_person_auth(person_id, channel_cd, auth_cd)
        VALUES(maker_person.person_id, 'cDKBCIB', 'aVIEWSWIFT');
        ----------------------------------
        
        DELETE FROM corpint.tbl_person_auth
        WHERE person_id=maker_person.person_id AND channel_cd='cDKBCIB' AND  auth_cd='aMAKESWIFT';
        
        INSERT INTO corpint.tbl_person_auth(person_id, channel_cd, auth_cd)
        VALUES(maker_person.person_id, 'cDKBCIB', 'aMAKESWIFT');
    END LOOP;
    
    --GIVE VIEWER RIGHTS 
    FOR viewer_person in cursor_viewers
    LOOP
        
        DELETE FROM corpint.tbl_person_auth
        WHERE person_id=viewer_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aVIEWSWIFT' ;
        
        INSERT INTO corpint.tbl_person_auth(person_id, channel_cd, auth_cd)
        VALUES(viewer_person.person_id, 'cDKBCIB', 'aVIEWSWIFT');
    END LOOP;
    
    --GIVE CHECKER RIGHTS
    FOR checker_person in cursor_checkers
    LOOP
        --GIVE VIEWER RIGHTS FOR CHECKER----
        DELETE FROM corpint.tbl_person_auth
        WHERE person_id=checker_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aVIEWSWIFT' ;
        
        INSERT INTO corpint.tbl_person_auth(person_id, channel_cd, auth_cd)
        VALUES(checker_person.person_id, 'cDKBCIB', 'aVIEWSWIFT');
        ----------------------------------
        DELETE FROM corpint.tbl_person_approval
        WHERE person_id=checker_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aCHCKSWIFT' ;
        
        INSERT INTO corpint.tbl_person_approval(person_id, channel_cd, auth_cd)
        VALUES(checker_person.person_id, 'cDKBCIB', 'aCHCKSWIFT');
        
        ls_check := 'Y';
    END LOOP;
    
    --GIVE VERIFIER RIGHTS
    FOR verifier_person in cursor_verifiers
    LOOP
         --GIVE VIEWER RIGHTS FOR VERIFIER----
        DELETE FROM corpint.tbl_person_auth
        WHERE person_id=verifier_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aVIEWSWIFT' ;
        
        INSERT INTO corpint.tbl_person_auth(person_id, channel_cd, auth_cd)
        VALUES(verifier_person.person_id, 'cDKBCIB', 'aVIEWSWIFT');
        ----------------------------------
        DELETE FROM corpint.tbl_person_approval
        WHERE person_id=verifier_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aVRFYSWIFT' ;
        
        INSERT INTO corpint.tbl_person_approval(person_id, channel_cd, auth_cd)
        VALUES(verifier_person.person_id, 'cDKBCIB', 'aVRFYSWIFT');
        
        ls_verify := 'Y';
    END LOOP;
    
     --GIVE APPROVER RIGHTS
    FOR approver_person in cursor_approvers
    LOOP
          --GIVE VIEWER RIGHTS FOR APPROVER----
        DELETE FROM corpint.tbl_person_auth
        WHERE person_id=approver_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aVIEWSWIFT' ;
        
        INSERT INTO corpint.tbl_person_auth(person_id, channel_cd, auth_cd)
        VALUES(approver_person.person_id, 'cDKBCIB', 'aVIEWSWIFT');
        ----------------------------------
        DELETE FROM corpint.tbl_person_approval
        WHERE person_id=approver_person.person_id AND channel_cd='cDKBCIB' AND auth_cd='aAPPRSWIFT' ;
        
        INSERT INTO corpint.tbl_person_approval(person_id, channel_cd, auth_cd)
        VALUES(approver_person.person_id, 'cDKBCIB', 'aAPPRSWIFT');
        
        ls_approve := 'Y';
    END LOOP;
          
    --SET AUTHORIZATION and LIMITS--------------------------------------------------------------------------------
    --maximum daily limit of a company for transaction
    DELETE FROM corpint.tbl_approval_tran_max_limit --main table
    WHERE customer_no=ps_customerid AND tran_cd='SWIFT' AND channel_cd='cDKBCIB';
    
    DELETE FROM corpint.tbl_specapp_tran_max_limit  --before approve table
    WHERE customer_no=ps_customerid AND tran_cd='SWIFT' AND channel_cd='cDKBCIB';
    
    INSERT INTO corpint.tbl_approval_tran_max_limit(customer_no, tran_cd, max_daily_limit, currency_code, channel_cd) --main table
    VALUES(ps_customerid, 'SWIFT', 3000000, 'KGS', 'cDKBCIB');
    
    INSERT INTO corpint.tbl_specapp_tran_max_limit(customer_no, tran_cd, max_daily_limit, currency_code, channel_cd) --before approve table
    VALUES(ps_customerid, 'SWIFT', 3000000, 'KGS', 'cDKBCIB');
    
    --transaction authorizations check/verify/approve and company limits per transaction
    DELETE FROM corpint.tbl_approval_tran
    WHERE customer_id=ps_customerid AND tran_cd='SWIFT';
    
    DELETE FROM corpint.tbl_spec_approval_tran
    WHERE customer_id=ps_customerid AND tran_cd='SWIFT';
    
    INSERT INTO corpint.tbl_approval_tran(customer_id, tran_cd, verify, approve, checker, daily_limit, limit_currency, channel_cd, order_id, used_limit, limit_date)
    VALUES(ps_customerid, 'SWIFT',  ls_verify, ls_approve, ls_check, 3000000, 'KGS', 'cDKBCIB', 8, 0, null);
    
    INSERT INTO corpint.tbl_spec_approval_tran(customer_id, tran_cd, verify, approve, checker, daily_limit, limit_currency, channel_cd, order_id, used_limit, limit_date)
    VALUES(ps_customerid, 'SWIFT',  ls_verify, ls_approve, ls_check, 3000000, 'KGS', 'cDKBCIB', 8, 0, null);
            
    COMMIT;
    
    OPEN pc_ref FOR SELECT  ls_returncode FROM dual;
      
     return ls_returncode;
EXCEPTION
     /*WHEN NoMaker THEN
        ls_returncode :='999';
        ROLLBACK;
        Pkg_Log.AddCustomLog('SWIFTCIB setSwiftOption',ls_returncode,ps_customerid||'#'||ps_personid||'#'||ps_status, 'Customer does not have a "Maker" user!');
        OPEN pc_ref FOR  SELECT  ls_returncode FROM dual;
        RETURN ls_returncode;*/
    
      WHEN OTHERS   THEN
        ls_returncode :='999';
        ROLLBACK;
        Pkg_Log.AddCustomLog('swiftcib setSwiftOption',ls_returncode,ps_customerid||'#'||ps_personid||'#'||ps_status, SQLERRM);
        OPEN pc_ref FOR  SELECT  ls_returncode FROM dual;
        RETURN ls_returncode;
END;

/*******************************************************************************
    Name            :showSwiftPopupToUser
    Prepared By :Chyngyz Omurov (cq509)
    Modify Date :10.02.2015
    Pupose      : return flag to show swift pop-up or not
*******************************************************************************/
FUNCTION showSwiftPopupToUser( ps_customerid VARCHAR2,
							   ps_personid VARCHAR2,
							   ps_forceToShow VARCHAR2,
							   pc_ref OUT cursorreferencetype) RETURN VARCHAR2
 IS
        ls_4003_CIB_SWITCH VARCHAR2(5);
		--ls_4003_TEST_CUSTOMER_NOS VARCHAR2(500);--CBS-620 14.05.2022
        LN_COUNT NUMBER;
 BEGIN
                 
        Pkg_Log.AddCustomLog('SWIFTCIB showSwiftPopupToUser','test',ps_customerid||'#'||ps_personid||'#'||ps_forceToShow);
    
        OPEN pc_ref FOR  SELECT  1 FROM dual;
        
        CBS.PKG_PARAMETRE.DEGER('4003_CIB_SWITCH', ls_4003_CIB_SWITCH);
		
		--CBS.PKG_PARAMETRE.DEGER('4003_SWIFT_TEST_CUSTOMER_NOS', ls_4003_TEST_CUSTOMER_NOS);--CBS-620 14.05.2022
		 
        
       SELECT COUNT(*) INTO ln_count 
         FROM cbs_swift_access
          WHERE CUSTOMER_NO = ps_customerid AND SWIFT_STATUS='OPEN';--CBS-620 14.05.2022
        
        
        if nvl(ls_4003_CIB_SWITCH,'OFF') = 'OFF' AND ln_count = 0 then --CBS-620 14.05.2022
            OPEN pc_ref FOR  SELECT  0 FROM dual;
            RETURN '000';
        end if;
                            
        OPEN pc_ref FOR 
        SELECT COUNT(*) 
        FROM corpint.TBL_IDENTIFICATION 
        WHERE person_id = TO_NUMBER(ps_personid) AND channel_cd = 'cDKBCIB' 
                   AND
                   /*  EXISTS( SELECT TOKEN_ID --AT LEAST ONE USER OF THE CUSTOMER SHOULD HAVE ETOKEN
                                  FROM CORPINT.TBL_IDENTIFICATION I 
                                                LEFT JOIN CORPINT.TBL_PERSON P ON I.PERSON_ID = P.PERSON_ID 
                                  WHERE P.CUSTOMER_ID = ps_customerid AND I.TOKEN_ID IS NOT NULL  )
                                   AND*/
                     EXISTS (SELECT person_id 
                                  FROM corpint.tbl_person_approval
                                  WHERE  person_id = ps_personid and auth_cd LIKE '%APPR%')  --jf person is approver
                     AND
                     NOT EXISTS (SELECT A.PERSON_ID
                                           FROM CORPINT.TBL_PERSON_AUTH A
                                                        LEFT JOIN CORPINT.TBL_PERSON P ON A.PERSON_ID = P.PERSON_ID
                                           WHERE P.CUSTOMER_ID = ps_customerid AND A.AUTH_CD = 'aMAKESWIFT' ) --customer doesnot have makeswift authorization
                     AND
                     (NOT EXISTS (SELECT customer_id 
                                                  FROM CORPINT.TBL_SWIFT_INSIDERS_CIB 
                                                  WHERE  customer_id=ps_customerid)   --if customer has not accepted/declined before
                         OR
                         ps_forceToShow='Y' AND EXISTS (SELECT customer_id 
                                                  FROM CORPINT.TBL_SWIFT_INSIDERS_CIB 
                                                  WHERE  customer_id=ps_customerid AND status = 'OFF')  ); -- if customer declined before
        RETURN '000';
        EXCEPTION
            WHEN OTHERS THEN
                 Pkg_Log.AddCustomLog('SWIFTCIB showSwiftPopupToUser','999',ps_customerid||'#'||ps_personid, SQLERRM);
                OPEN pc_ref FOR  SELECT  0 FROM dual;
                RETURN '999';
 END;
 
 /*******************************************************************************
    Name        :showMessageToMaker
    Prepared By :Chyngyz Omurov  (cq509)
    Modify Date :10.02.2015
    Pupose      : return flag to show swift option related message to the maker
*******************************************************************************/
FUNCTION showMessageToMaker(  ps_customerid VARCHAR2,
                                                              ps_personid VARCHAR2,
                                                              pc_ref OUT cursorreferencetype) RETURN VARCHAR2
  IS
    ls_4003_CIB_SWITCH VARCHAR2(5);
   -- ls_4003_TEST_CUSTOMER_NOS VARCHAR2(500);--CBS-620 14.05.2022
    ln_count  NUMBER;
 BEGIN
         
        Pkg_Log.AddCustomLog('SWIFTCIB showMessageToMaker','test',ps_customerid||'#'||ps_personid);
 
        OPEN pc_ref FOR  SELECT  1 FROM dual;
        
        CBS.PKG_PARAMETRE.DEGER('4003_CIB_SWITCH', ls_4003_CIB_SWITCH);

        --CBS.PKG_PARAMETRE.DEGER('4003_SWIFT_TEST_CUSTOMER_NOS', ls_4003_TEST_CUSTOMER_NOS);--CBS-620 14.05.2022
        
        SELECT COUNT(*) INTO ln_count 
         FROM cbs_swift_access
        WHERE CUSTOMER_NO = ps_customerid AND SWIFT_STATUS='OPEN';--CBS-620 14.05.2022
         
        if nvl(ls_4003_CIB_SWITCH,'OFF') = 'OFF' AND ln_count = 0 then--CBS-620 14.05.2022
            OPEN pc_ref FOR  SELECT  0 FROM dual;
            RETURN '000';
        end if;
                            
        OPEN pc_ref FOR 
        SELECT COUNT(*) 
        FROM corpint.TBL_IDENTIFICATION 
        WHERE person_id = TO_NUMBER(ps_personid) AND channel_cd = 'cDKBCIB' 
                   AND
                     EXISTS (SELECT person_id 
                                  FROM corpint.tbl_person_auth
                                  WHERE  person_id = ps_personid and auth_cd LIKE '%MAKE%')  --jf person is maker
                     AND
                     NOT EXISTS (SELECT A.PERSON_ID
                                           FROM CORPINT.TBL_PERSON_AUTH A
                                                        LEFT JOIN CORPINT.TBL_PERSON P ON A.PERSON_ID = P.PERSON_ID
                                           WHERE P.CUSTOMER_ID = ps_customerid AND A.AUTH_CD = 'aMAKESWIFT' ); --customer doesnot have makeswift authorization
                    /* AND
                     (NOT EXISTS (SELECT customer_id 
                                                  FROM CORPINT.TBL_SWIFT_INSIDERS_CIB 
                                                  WHERE  customer_id=ps_customerid)   --if customer has not accepted/declined before
                         OR
                         ps_forceToShow='Y' AND EXISTS (SELECT customer_id 
                                                  FROM CORPINT.TBL_SWIFT_INSIDERS_CIB 
                                                  WHERE  customer_id=ps_customerid AND status = 'OFF')  ); -- if customer declined before    */                                              
        RETURN '000';
        EXCEPTION
            WHEN OTHERS THEN
                 Pkg_Log.AddCustomLog('SWIFTCIB showMessageToMaker','999',ps_customerid||'#'||ps_personid, SQLERRM);
                OPEN pc_ref FOR  SELECT  0 FROM dual;
                RETURN '999';
 END;
 
------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION GetPersonNamesHistory
   Prepared By : Nursultan Mukhambet uulu
   Date        : 15.12.2021
******************************************************************************/
FUNCTION  GetPersonNamesHistory(ps_personid NUMBER,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
    SELECT FIELD2
    FROM TBL_ACTIVITY a
    WHERE a.CHANNEL_CD = 'cCORPADM'
    AND a.TRAN_CD = 'ACCRENAME' 
    AND a.PAGE_ID = 4 
    AND a.FIELD1 =  ps_personid
    ORDER BY DLM DESC;
    RETURN ls_returncode;
END;

------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION GetPersonNameAndChannel
   Prepared By : Nursultan Mukhambet uulu
   Date        : 15.12.2021
******************************************************************************/
FUNCTION  GetPersonNameAndChannel(ps_personid NUMBER,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
    SELECT p.FIRSTNAME, i.CHANNEL_CD
    FROM TBL_PERSON p, TBL_IDENTIFICATION i
    WHERE p.PERSON_ID=ps_personid
    AND i.PERSON_ID=p.PERSON_ID;
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetPayeeInfoForSwift
   Prepared By : Omurchiev Esen
   Date        : 15.12.2021
******************************************************************************/
FUNCTION GetPayeeInfoForSwift(ps_PERSON_ID IN VARCHAR2,
                       ps_PAYEE_TYPE IN VARCHAR2 DEFAULT NULL,
                       ps_currency IN VARCHAR2 DEFAULT NULL,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode         VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR
        SELECT NVL(PAYEE_ID,0),
             NVL(PERSON_ID,0),
             NVL(PAYEE_TYPE,' '),
             NVL(PAYEE_KIND,' '),
             NVL(SENDERNAME,' '),

             NVL(BANKCD,' '),
             NVL(PAYEENAME,' '),
             NVL(TOACCOUNT,' '),
             NVL(PAYMENTCD,' '),
             NVL(NICKNAME,' '),

             NVL(CURRCODE,' '),
             NVL(SENDERPHONE,' '),
             NVL(SENDERADDRESS,' '),
             NVL(PAYEEPHONE,' '),
             NVL(RNN,' '),

             NVL(STAT,0),
             NVL(INCOME_CODE,0),
             NVL(DOC_NO,0),
             NVL(SUBACCOUNT_NO,' '),
             NVL(PAY_SUBNAME,' '),
             NVL(CITYCD,' '),
             NVL(BRANCHCD,' ') -- Nursultan Mulhambet uulu ibc-74 -> Inn Kpp


        FROM TBL_PAYEE
        WHERE PERSON_ID = NVL(TO_NUMBER(ps_PERSON_ID), PERSON_ID)
        AND PAYEE_TYPE=NVL(ps_PAYEE_TYPE,PAYEE_TYPE)
        AND CURRCODE in (select trim(regexp_substr(ps_currency, '[^;]+', 1, level ) )from dual 
                                          connect by trim(regexp_substr(ps_currency, '[^;]+', 1, level )) is not null)
        ORDER BY PAYEE_KIND,NICKNAME,PAYEENAME;


 RETURN ls_returncode;
END;
     
END;
/

