create PACKAGE         PKG_CINT_LIMIT IS

TYPE CursorReferenceType IS REF CURSOR;
/******************************************************************************
   NAME       : FUNCTION  GetLimitInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose   : Display Limit Information
******************************************************************************/
FUNCTION GetLimitInfo(pn_CustomerId IN VARCHAR2,
                      pn_PersonId   IN VARCHAR2,
                      ps_TranCd     IN VARCHAR2,
                      ps_ChannelCd  IN VARCHAR2,
                      pn_Rates      IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  CheckLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose   : Check Limits
******************************************************************************/
FUNCTION CheckLimit(pn_CustomerID  IN VARCHAR2,
                    ps_TranCd      IN VARCHAR2,
                    pn_Amount      IN VARCHAR2,
                    pn_PersonId    IN VARCHAR2,
                    ps_ChannelCd   IN VARCHAR2,
                    pn_Rates       IN VARCHAR2,
                    ps_CurrencyCd  IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  UpdateLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose   : Update Limit
******************************************************************************/
FUNCTION UpdateLimit(pn_CustomerId   IN VARCHAR2,
                     ps_TranCd       IN VARCHAR2,
                     pn_Amount       IN VARCHAR2,
                     ps_CurrencyCd   IN VARCHAR2,
                     ps_PersonId     IN VARCHAR2,
                     ps_ChannelCd    IN VARCHAR2,
                     pn_Rates        IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  CheckLimitForAdminSite
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Check Admin sites limit
******************************************************************************/
FUNCTION CheckLimitForAdminSite(pn_PersonId    IN VARCHAR2,
                                pn_CustomerId  IN VARCHAR2,
                                pn_Amount      IN VARCHAR2,
                                ps_CurrencyCd  IN VARCHAR2,
                                pn_Rates       IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetUsedLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Display used limit
******************************************************************************/
FUNCTION GetUsedLimit(pn_CustomerId IN NUMBER,
                      pn_PersonId   IN NUMBER,
                       ps_TranCd     IN VARCHAR2,
                       ps_ChannelCd  IN VARCHAR2) RETURN NUMBER;
/******************************************************************************
   NAME       : FUNCTION  GetIBLimitInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 05.06.08
   Purpose    : Display Limit Information
******************************************************************************/
FUNCTION GetIBLimitInfo(pn_CustomerId IN VARCHAR2,
                      pn_PersonId   IN VARCHAR2,
                      ps_TranCd     IN VARCHAR2,
                      ps_ChannelCd  IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  CheckIBLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 06.06.08
   Purpose   : Check Limits
******************************************************************************/
FUNCTION CheckIBLimit(pn_CustomerID  IN VARCHAR2,
                      ps_TranCd      IN VARCHAR2,
                      pn_Amount      IN VARCHAR2,
                      pn_PersonId    IN VARCHAR2,
                      ps_ChannelCd   IN VARCHAR2,
                      ps_CurrencyCd  IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  UpdateLimit
   Created By : Muzaffar Khalyknazarov
   Date       : 03.12.07
   Purpose   : Update Limit
******************************************************************************/
FUNCTION UpdateIBLimit(pn_CustomerId   IN VARCHAR2,
                       ps_TranCd       IN VARCHAR2,
                       pn_Amount       IN VARCHAR2,
                       ps_CurrencyCd   IN VARCHAR2,
                       pn_PersonId     IN VARCHAR2,
                       ps_ChannelCd    IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
END Pkg_CINT_Limit;
/

