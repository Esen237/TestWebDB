create PACKAGE                 PKG_CINT_MAIN IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  CheckCurrencyControl
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Return User Information and last login date
******************************************************************************/
FUNCTION CheckCurrencyControl(ps_channelcd     IN VARCHAR2,
                              ps_customer_id    IN VARCHAR2,
                              ps_tran IN VARCHAR2,
                              ps_controlstr IN VARCHAR2,
                              ps_currencycd IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  AddSecurityInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 01.04.08
   Purpose   : Return User Information and last login date
******************************************************************************/
FUNCTION AddSecurityInfo(pn_PersonId         IN VARCHAR2,
                         ps_IpStatus         IN VARCHAR2,
                         ps_TimeStatus       IN VARCHAR2,
                         ps_Monday           IN VARCHAR2,
                         ps_Tuesday          IN VARCHAR2,
                         ps_Wednesday        IN VARCHAR2,
                         ps_Thursday         IN VARCHAR2,
                         ps_Friday           IN VARCHAR2,
                         ps_Saturday         IN VARCHAR2,
                         ps_Sunday           IN VARCHAR2,
                         pn_Ip_1_1           IN VARCHAR2,
                         pn_Ip_1_2           IN VARCHAR2,
                         pn_Ip_2_1           IN VARCHAR2,
                         pn_Ip_2_2           IN VARCHAR2,
                         pd_StartTime      IN VARCHAR2,
                         pd_EndTime        IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetPersonName
   Created By : Muzaffar Khalyknazarov
   Date       : 02.04.08
   Purpose   : Return Person name
******************************************************************************/
FUNCTION GetPersonName(pn_personid IN NUMBER) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  SPLIT
   Created By : Muzaffar Khalyknazarov
   Date       : 15.04.08
   Purpose   : Split
******************************************************************************/
FUNCTION SPLIT(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  IpCheck
   Created By : Muzaffar Khalyknazarov
   Date       : 02.04.08
   Purpose   : Return Person name
******************************************************************************/
FUNCTION IpCheck(ps_ClientIP IN VARCHAR2,
                  ps_Ip_1_1   IN VARCHAR2,
                 ps_Ip_1_2   IN VARCHAR2,
                 ps_Ip_2_1   IN VARCHAR2,
                 ps_Ip_2_2   IN VARCHAR2) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  TimeCheck
   Created By : Muzaffar Khalyknazarov
   Date       : 02.04.08
   Purpose   : Return Person name
******************************************************************************/
FUNCTION TimeCheck(ps_StartTime IN VARCHAR2,
                    ps_EndTime   IN VARCHAR2) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  SavePersonAgendaDatas
   Created By : Almas Adilbek
   Date       : 23.04.08
   Purpose    : Save Person Agenda Event
******************************************************************************/
FUNCTION SavePersonAgendaEvent(pn_personcd IN VARCHAR2,
                           ps_langCD IN VARCHAR2,
                           pn_eventID IN VARCHAR2,
                           ps_eventType IN VARCHAR2,
                           ps_eventTitle IN VARCHAR2,
                           ps_eventDesc IN VARCHAR2,
                           ps_eventDate IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  DeletePersonAgendaEvent
   Created By : Almas Adilbek
   Date       : 23.04.08
   Purpose    : Delete Person Agenda Event
******************************************************************************/
FUNCTION DeletePersonAgendaEvent(pn_personcd IN VARCHAR2,
                           ps_langCD IN VARCHAR2,
                           pn_eventID IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetAuthStatus
   Created By : Muzaffar Khaltyknazarov
   Date       : 10.06.08
   Purpose    : Get Authority Status
******************************************************************************/
FUNCTION GetAuthStatus(ps_CustomerId    IN VARCHAR2,
                        ps_TranCd IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  UpdateEmployee
   Created By : Almas Nurkhozhayev
   Date       : 14.03.11
   Purpose    : Update Employee Position
******************************************************************************/
FUNCTION UpdateEmployee(ps_Option IN VARCHAR2,
                        ps_Id IN VARCHAR2,
                        ps_BranchCD IN VARCHAR2,
                        ps_Name IN VARCHAR2,
                        ps_Position IN VARCHAR2,
                        ps_PersonId IN VARCHAR2,
                        ps_StatusCd IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION UpdateEmbassyLetter
   Created By : Almas Nurkhozhayev
   Date       : 15.03.11
   Purpose    : Update Embassy Letter
******************************************************************************/
FUNCTION UpdateEmbassyLetter(ps_Option IN VARCHAR2,
                             ps_Id IN VARCHAR2,
                             ps_document_no IN VARCHAR2,
                             ps_lang_cd IN VARCHAR2,
                             ps_name_of_embassy IN VARCHAR2,
                             ps_place_of_embassy IN VARCHAR2,
                             ps_customer_no IN VARCHAR2,
                             ps_customer_name IN VARCHAR2,
                             ps_passport_no IN VARCHAR2,
                             ps_issued_by IN VARCHAR2,
                             ps_issued_date IN VARCHAR2,
                             ps_int_passport_no IN VARCHAR2,
                             ps_int_issued_by IN VARCHAR2,
                             ps_int_issued_date IN VARCHAR2,
                             ps_signatures_of IN VARCHAR2,
                             ps_demand_dep_acc_no IN VARCHAR2,
                             ps_time_dep_acc_no IN VARCHAR2,
                             ps_total_amount_in IN VARCHAR2,
                             ps_PersonId IN VARCHAR2,
                             ps_subject IN VARCHAR2,
                             ps_balance_date IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION UpdateEmbassyLetter
   Created By : Almas Nurkhozhayev
   Date       : 15.03.11
   Purpose    : Update Embassy Letter
******************************************************************************/
FUNCTION UpdateMultiLanguageData(ps_Option IN VARCHAR2,
                                 ps_Source IN VARCHAR2,
                                 ps_LangCd IN VARCHAR2,
                                 ps_Desciption IN VARCHAR2,
                                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
END Pkg_CINT_Main;
/

