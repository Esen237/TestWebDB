create PACKAGE BODY         "PKG_AUTOPAYMENT" IS

/******************************************************************************
   Name       : FUNCTION createAutopayment
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : create/update automatic payment
******************************************************************************/   
FUNCTION createAutopayment(ps_payment_name VARCHAR2,
                                              pn_person_id VARCHAR2,
                                              pn_tran_code NUMBER,
                                              ps_tran_cd VARCHAR2,
                                              ps_payment_type VARCHAR2,
                                              ps_status VARCHAR2,
                                              ps_payment_details CLOB,
                                              ps_user_created VARCHAR2,
                                              ps_option VARCHAR2,
                                              ps_seq_id VARCHAR2 DEFAULT NULL,
                                              ps_defined_date VARCHAR2 DEFAULT NULL,
                                              ps_exec_time VARCHAR2 DEFAULT NULL,
                                              ps_period VARCHAR2 DEFAULT NULL,
                                              pn_account_no NUMBER DEFAULT NULL,
                                              pn_customer_id NUMBER DEFAULT NULL,
                                              ps_channel_cd VARCHAR2 DEFAULT NULL,
                                              ps_next_date VARCHAR2 DEFAULT NULL) RETURN VARCHAR2 IS
    ls_details VARCHAR2(500);
    ln_seq_id NUMBER;
    ld_next_date DATE;
    ld_defined_date DATE;
    ls_returncode VARCHAR2(3):= '000';
    ls_user_created VARCHAR2(50) := SUBSTR(ps_user_created, 1, 50);
    CURSOR exautopmnt IS
    SELECT * 
    FROM CORPINT.TBL_AUTOPAYMENT
    WHERE seq_id = ln_seq_id AND
          person_id = pn_person_id;
          
    res_pmnt exautopmnt%ROWTYPE;
BEGIN
    log_at('test_autopmnt', 1, ps_payment_name, pn_person_id);

    IF ps_seq_id is null THEN
        ln_seq_id := 0;
    ELSE
        ln_seq_id := to_number(ps_seq_id, '9999999');
    END IF;
    log_at('test_autopmnt', 2, ps_payment_name, pn_person_id);
    IF ps_next_date is null THEN
        ld_next_date := to_date(ps_defined_date, 'dd/mm/yyyy');
    ELSE
        ld_next_date := to_date(ps_next_date, 'dd/mm/yyyy');
    END IF;
    ld_defined_date := to_date(ps_defined_date, 'dd/mm/yyyy');
    log_at('test_autopmnt', 3, ps_payment_name, pn_person_id);
    IF ps_option = 'NEW' THEN
        IF ps_payment_type = 'SCHEDULED' THEN
            log_at('test_autopmnt', 4, ps_payment_name, pn_person_id);
            INSERT INTO CORPINT.TBL_AUTOPAYMENT (payment_name, person_id, customer_id, tran_code, tran_cd, channel_cd, payment_type, status, payment_details, 
                                                 defined_date, execution_time, period, created_by, created_date, approved_by, approved_date)
            VALUES (ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd, ps_channel_cd, ps_payment_type, ps_status, ps_payment_details,  
                    ld_defined_date, ps_exec_time, ps_period, ls_user_created, sysdate, ls_user_created, sysdate);
            ls_details := 'NEW SCHEDULED AUTOPAYMENT IS CREATED';
        ELSIF ps_payment_type = 'TRIGGERED' THEN
            log_at('test_autopmnt', 5, ps_payment_name, pn_person_id);
            INSERT INTO CORPINT.TBL_AUTOPAYMENT (payment_name, person_id, customer_id, tran_code, tran_cd, channel_cd, payment_type, status, payment_details, 
                                                created_by, created_date, approved_by, approved_date, account_no)
            VALUES (ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd, ps_channel_cd, ps_payment_type, ps_status, ps_payment_details, 
                                                ls_user_created, sysdate, ls_user_created, sysdate, pn_account_no);
            ls_details := 'NEW TRIGGERED AUTOPAYMENT IS CREATED';            
        END IF;
        BEGIN
            SELECT MAX(seq_id)
            INTO ln_seq_id
            FROM CORPINT.TBL_AUTOPAYMENT
            WHERE person_id = pn_person_id AND
                        tran_code = pn_tran_code AND
                        payment_type = ps_payment_type AND
                        payment_name = ps_payment_name;
        EXCEPTION WHEN NO_DATA_FOUND THEN
            ln_seq_id := 0;
        END;
    ELSE
        log_at('test_autopmnt', 6, ps_payment_name, pn_person_id);
        OPEN exautopmnt;
        FETCH exautopmnt INTO res_pmnt;
        IF exautopmnt%FOUND THEN
        log_at('test_autopmnt', 7, ps_payment_name, pn_person_id);
           PKG_LOG.addAutopaymentLog(ps_option, res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, 
                                      res_pmnt.channel_cd, res_pmnt.payment_type, res_pmnt.status, res_pmnt.payment_details, res_pmnt.defined_date, res_pmnt.execution_time, 
                                      res_pmnt.period, res_pmnt.created_by, res_pmnt.created_date, res_pmnt.approved_by, res_pmnt.approved_date, res_pmnt.seq_id, res_pmnt.next_date_time, 
                                      res_pmnt.account_no, res_pmnt.prev_date, res_pmnt.prev_ret_code, res_pmnt.prev_err_details, 'EXISTING AUTOPAYMENT BEFORE MODIFICATION', '');
            UPDATE CORPINT.TBL_AUTOPAYMENT
            SET payment_name = ps_payment_name,
                status = ps_status,
                payment_details = ps_payment_details,
                defined_date = ld_defined_date,
                execution_time = ps_exec_time,
                next_date_time = ld_next_date,
                period = ps_period,
                created_by = ls_user_created,
                created_date = sysdate,
                approved_by = ls_user_created,
                approved_date = sysdate,
                account_no = pn_account_no
            WHERE seq_id = ln_seq_id AND
                  person_id = pn_person_id;       
        ELSE
            log_at('test_autopmnt', 8, ps_payment_name, pn_person_id);
            return '999';
        END IF;
        CLOSE exautopmnt;

        ls_details := 'EXISTING AUTOPAYMENT AFTER MODIFICATION';
    END IF;
    PKG_LOG.addAutopaymentLog(ps_option, ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd, 
                              ps_channel_cd, ps_payment_type, ps_status, ps_payment_details, ld_defined_date, ps_exec_time, ps_period, 
                              ls_user_created, sysdate, ls_user_created, sysdate, ln_seq_id, ld_next_date, pn_account_no, '', '', '', ls_details);
    
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('test_autopmnt', 10, SQLERRM, pn_person_id);
    PKG_LOG.addAutopaymentLog('ERROR', ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd,
                                                   ps_channel_cd, ps_payment_type, ps_status, ps_payment_details, ld_defined_date,
                                                   ps_exec_time, ps_period, ls_user_created, sysdate, ls_user_created, sysdate, ln_seq_id, ld_next_date,
                                                   pn_account_no, sysdate, '999',  'ERROR ' || SUBSTR(SQLERRM, 1, 480), 'ERROR ' || SUBSTR(SQLERRM,  480, 900));        
END;

/******************************************************************************
   Name       : FUNCTION modifyAutopayment
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : modify automatic payment
******************************************************************************/   
FUNCTION modifyAutopayment(pn_seq_id IN NUMBER,
                                               ps_operation IN VARCHAR2,
                                               ps_maker IN VARCHAR2,
                                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_status VARCHAR2(10) := '';
    ls_returncode VARCHAR2(3) := '000';
    CURSOR autopmnt IS
    SELECT * 
    FROM CORPINT.TBL_AUTOPAYMENT
    WHERE seq_id = pn_seq_id
    FOR UPDATE;
          
    res_pmnt autopmnt%ROWTYPE;    
BEGIN
    IF ps_operation = 'ENABLE'  THEN
        ls_status := 'sENAB';
    ELSIF ps_operation = 'DISABLE' THEN
        ls_status := 'sDISAB';
    ELSIF ps_operation = 'DELETE' THEN
        ls_status := 'sDLTED';
    END IF;
    
    IF ls_status in ('sENAB','sDISAB','sDLTED') THEN
        OPEN autopmnt;
        FETCH autopmnt INTO res_pmnt;
        IF autopmnt%FOUND THEN
            PKG_LOG.addAutopaymentLog(ps_operation, res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd,
                                      res_pmnt.payment_type, res_pmnt.status, res_pmnt.payment_details, res_pmnt.defined_date, res_pmnt.execution_time, res_pmnt.period, 
                                      res_pmnt.created_by, res_pmnt.created_date, res_pmnt.approved_by, res_pmnt.approved_date, res_pmnt.seq_id, res_pmnt.next_date_time,
                                      res_pmnt.account_no, res_pmnt.prev_date, res_pmnt.prev_ret_code, res_pmnt.prev_err_details, 'EXISTING AUTOPAYMENT BEFORE MODIFICATION');  
                                                    
            UPDATE corpint.tbl_autopayment
            SET status = ls_status
            WHERE seq_id = pn_seq_id;    

            PKG_LOG.addAutopaymentLog(ps_operation, res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd, 
                                      res_pmnt.payment_type, ls_status, res_pmnt.payment_details, res_pmnt.defined_date, res_pmnt.execution_time, res_pmnt.period, 
                                      ps_maker, sysdate, ps_maker, sysdate, res_pmnt.seq_id, res_pmnt.next_date_time, res_pmnt.account_no, 
                                      res_pmnt.prev_date, res_pmnt.prev_ret_code, res_pmnt.prev_err_details, 'EXISTING AUTOPAYMENT AFTER MODIFICATION');                 
        ELSE
            ls_returncode := '999';
             log_at('pkg_autopayment.modifyAutopayment', 1);
        END IF;
        CLOSE autopmnt;
    ELSE
        ls_returncode := '999';
        log_at('pkg_autopayment.modifyAutopayment', 2);
    END IF;
    OPEN pc_ref FOR SELECT ls_status FROM dual;
    log_at('pkg_autopayment.modifyAutopayment', 3, ls_status, ps_operation);
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    ls_returncode := '999';
    log_at('pkg_autopayment.modifyAutopayment', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    OPEN pc_ref FOR SELECT sysdate FROM dual;
    return ls_returncode;
END;

/******************************************************************************
   Name       : FUNCTION createPmntToDo
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : make preliminary create/update automatic payment
******************************************************************************/   
FUNCTION createPmntToDo(ps_payment_name VARCHAR2,
                                          pn_person_id VARCHAR2,
                                          pn_tran_code NUMBER,
                                          ps_tran_cd VARCHAR2,
                                          ps_payment_type VARCHAR2,
                                          ps_status VARCHAR2,
                                          ps_payment_details CLOB,
                                          ps_user_created VARCHAR2,
                                          ps_option VARCHAR2,
                                          ps_seq_id VARCHAR2,
                                          ps_defined_date VARCHAR2,
                                          ps_exec_time VARCHAR2,
                                          ps_period VARCHAR2,
                                          pn_account_no NUMBER,
                                          pn_customer_id NUMBER,
                                          ps_channel_cd VARCHAR2,
                                          ps_upd_info CLOB) RETURN VARCHAR2 IS
    ls_details VARCHAR2(500);
    ln_seq_id NUMBER;
    ld_defined_date DATE;
    ls_status VARCHAR2(15);
    ls_returncode VARCHAR2(3):= '000';
    ls_user_created VARCHAR2(50) := SUBSTR(ps_user_created, 1, 50);
    CURSOR exautopmnt IS
    SELECT * 
    FROM CORPINT.TBL_AUTOPAYMENT
    WHERE seq_id = ln_seq_id AND
          customer_id = pn_customer_id;
          
    res_pmnt exautopmnt%ROWTYPE;
BEGIN
    log_at('test_autopmnt_to_do', 1, ps_payment_name, pn_person_id);
    ls_status := ps_status;
    IF ps_seq_id is null THEN
        ln_seq_id := 0;
    ELSE
        ln_seq_id := to_number(ps_seq_id, '9999999');
    END IF;
    log_at('test_autopmnt_to_do', 2, ps_payment_name, pn_person_id);
    ld_defined_date := to_date(ps_defined_date, 'dd/mm/yyyy');
    log_at('test_autopmnt_to_do', 3, ps_payment_name, pn_person_id);
    IF ps_option = 'NEW' THEN
        ls_status := 'sNEW';
        log_at('test_autopmnt_to_do', 4, ps_payment_name, pn_person_id);
        INSERT INTO CORPINT.TBL_AUTOPAYMENT (payment_name, person_id, customer_id, tran_code, tran_cd, channel_cd, payment_type, 
            status, payment_details, created_by, defined_date, execution_time, period, account_no, upd_info)
        VALUES (ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd, ps_channel_cd, ps_payment_type, 
            ls_status, ps_payment_details, ls_user_created, ld_defined_date, ps_exec_time, ps_period, pn_account_no, ps_upd_info);
        ls_details := 'NEW AUTOPAYMENT TO DO IS CREATED';            
        BEGIN
            SELECT MAX(seq_id)
            INTO ln_seq_id
            FROM CORPINT.TBL_AUTOPAYMENT
            WHERE customer_id = pn_customer_id AND
                        tran_code = pn_tran_code AND
                        payment_type = ps_payment_type AND
                        payment_name = ps_payment_name;
        EXCEPTION WHEN NO_DATA_FOUND THEN
            ln_seq_id := 0;
        END;
        PKG_LOG.addAutopaymentLog(ps_option, ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd, ps_channel_cd,
                               ps_payment_type, ps_status, ps_payment_details, ld_defined_date, ps_exec_time, ps_period, ls_user_created, sysdate,
                               '', '', ln_seq_id, '', pn_account_no, '', '', '', ls_details, ps_upd_info);
    ELSE
        log_at('test_autopmnt_to_do', 6, ps_payment_name, pn_person_id);
        OPEN exautopmnt;
        FETCH exautopmnt INTO res_pmnt;
        IF exautopmnt%FOUND THEN
        log_at('test_autopmnt_to_do', 7, ps_payment_name, pn_person_id);
            UPDATE CORPINT.TBL_AUTOPAYMENT
            SET upd_info = ps_upd_info
            WHERE seq_id = ln_seq_id AND
                  customer_id = pn_customer_id;    
           PKG_LOG.addAutopaymentLog(ps_option, res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd,
                                      res_pmnt.payment_type, res_pmnt.status, res_pmnt.payment_details, res_pmnt.defined_date, res_pmnt.execution_time, res_pmnt.period,
                                      res_pmnt.created_by, res_pmnt.created_date, res_pmnt.approved_by, res_pmnt.approved_date, res_pmnt.seq_id, res_pmnt.next_date_time, res_pmnt.account_no, 
                                      res_pmnt.prev_date, res_pmnt.prev_ret_code, res_pmnt.prev_err_details, 'EXISTING AUTOPAYMENT AFTER MODIFY TO DO IS CREATED', ps_upd_info);   
        ELSE
            log_at('test_autopmnt_to_do', 8, ps_payment_name, pn_person_id || ' ' || pn_customer_id);
            return '999';
        END IF;
        CLOSE exautopmnt;
    END IF;
    
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('test_autopmnt_to_do', 10, SQLERRM, pn_person_id || ' ' || pn_customer_id);
    PKG_LOG.addAutopaymentLog('ERROR', ps_payment_name, pn_person_id, pn_customer_id, pn_tran_code, ps_tran_cd,
                                                   ps_channel_cd, ps_payment_type, ps_status, ps_payment_details, ld_defined_date,
                                                   ps_exec_time, ps_period, ls_user_created, '', '','',  ln_seq_id, '',
                                                   pn_account_no, sysdate, '999',  'ERROR ' || SUBSTR(SQLERRM, 1, 480), 'ERROR ' || SUBSTR(SQLERRM,  480, 900), ps_upd_info);        
END;

/******************************************************************************
   Name       : FUNCTION approvePmntToDo
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : approve preliminary created/updated automatic payment
******************************************************************************/   
FUNCTION approvePmntToDo(ps_seq_id VARCHAR2,
                                            pn_customer_id NUMBER,
                                            pn_person_id NUMBER,
                                            ps_channel_cd VARCHAR2,
                                            ps_user_approved VARCHAR2,
                                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_upd_info CLOB;
    ln_seq_id NUMBER;
    ls_status VARCHAR2(15);
    ls_returncode VARCHAR2(3) := '000';
    ld_def_date DATE;
    CURSOR upd_info IS
    SELECT p.*
    FROM CORPINT.TBL_AUTOPAYMENT P, CORPINT.TBL_PERSON_APPROVAL A
    WHERE p.customer_id = pn_customer_id AND
                (INSTR(ps_seq_id, ',' || TO_CHAR(p.seq_id) || ',')>0 OR
                (ps_seq_id = 'ALL' AND p.status = 'sNEW' AND p.upd_info is not null)) AND
                a.person_id = pn_person_id AND 
                a.auth_cd = DECODE(p.tran_cd, 'B2BHVL', 'aAPPRTMY',
                                                                'B2OBHVL', 'aAPPRTOY',
                                                                'CLEARING', 'aAPPREFT',
                                                                'GROSS', 'aAPPRGRS',
                                                                'EXCHNGBUY', 'aAPPRBFX',
                                                                'EXCHNGSELL', 'aAPPRSFX',
                                                                'CRDDEBTPYMNT', 'aAPPRCDP',
                                                                'SALARY', 'aAPPRSLRY',
                                                                'PAYMENTS', 'aAPPRPYM', '');
    res_upd upd_info%ROWTYPE;
BEGIN
    log_at('test_autopmnt_approve', 1, ps_seq_id, pn_customer_id || ' ' || ps_user_approved);
    OPEN upd_info;
    LOOP
       FETCH upd_info INTO res_upd;
       EXIT WHEN upd_info%NOTFOUND; 
       
       ls_upd_info := res_upd.upd_info;
       
       IF  res_upd.status <> 'sNEW' THEN
        log_at('test_autopmnt_approve', 10, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
       END IF;
       
       IF  ls_upd_info IS NOT NULL THEN
        log_at('test_autopmnt_approve', 11, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
       END IF;       
       
       IF length(trim(to_char(ls_upd_info))) <> 0 THEN
        log_at('test_autopmnt_approve', 12, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
       END IF;       
       
       log_at('test_autopmnt_approve', 2, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
        IF res_upd.status <> 'sNEW' AND ls_upd_info IS NOT NULL AND length(trim(to_char(ls_upd_info))) <> 0 THEN  
            ls_status := parseDetails(ls_upd_info, 5);
            
            IF parseDetails(ls_upd_info, 10) IS NOT NULL AND trim(parseDetails(ls_upd_info, 10)) <> '' THEN
                ld_def_date := to_date(parseDetails(ls_upd_info, 10), 'dd/mm/yyyy');
            ELSE
                ld_def_date := null;
            END IF;
            log_at('test_autopmnt_approve', 4, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
            UPDATE corpint.tbl_autopayment
            SET payment_name = parseDetails(ls_upd_info, 0),
                   person_id = pn_person_id,
                   status = parseDetails(ls_upd_info, 5),
                   payment_details = extractClob(ls_upd_info, 6),
                   defined_date = ld_def_date,
                   execution_time = parseDetails(ls_upd_info, 11),
                   next_date_time = '',
                   period = parseDetails(ls_upd_info, 12),
                   account_no = parseDetails(ls_upd_info, 14),
                   approved_by = ps_user_approved,
                   approved_date = sysdate,
                   prev_date = '',
                   prev_ret_code = '',
                   prev_err_details = '',
                   upd_info = ''
            WHERE seq_id = res_upd.seq_id and
                        customer_id = pn_customer_id;
        ELSIF res_upd.status = 'sNEW' THEN
            log_at('test_autopmnt_approve', 3, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
            UPDATE corpint.tbl_autopayment
            SET status = 'sENAB',
                   approved_by = ps_user_approved,
                   approved_date = sysdate,                   
                   upd_info = ''
            WHERE seq_id = res_upd.seq_id and
                        customer_id = pn_customer_id;   
        END IF;   
        log_at('test_autopmnt_approve', 5, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved || ' ' || res_upd.status);
        PKG_LOG.addAutopaymentLog('sAPPROVE', res_upd.payment_name, pn_person_id, res_upd.customer_id, res_upd.tran_code, res_upd.tran_cd, res_upd.channel_cd,
                                      res_upd.payment_type, res_upd.status, res_upd.payment_details, res_upd.defined_date, res_upd.execution_time, res_upd.period,
                                      res_upd.created_by, res_upd.created_date, ps_user_approved, sysdate, res_upd.seq_id, res_upd.next_date_time, res_upd.account_no, 
                                      res_upd.prev_date, res_upd.prev_ret_code, res_upd.prev_err_details, 'EXISTING AUTOPAYMENT AFTER MODIFICATION', res_upd.upd_info); 
       COMMIT;
    END LOOP;
    CLOSE upd_info;    
    
    log_at('test_autopmnt_approve', 6, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
    ls_returncode := pkg_autopayment.getWaitPmnts('sAPPROVE',
                                                                             ps_seq_id,
                                                                             ps_channel_cd,
                                                                             pn_customer_id,
                                                                             pn_person_id,
                                                                             pc_ref);

    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    log_at('pkg_autopayment.approvePmntToDo', ps_seq_id || ' ' || pn_customer_id || ' ' || ps_user_approved, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);   
    open pc_ref for select sysdate from dual;
    return '999'; 
END;

/******************************************************************************
   Name       : FUNCTION declinePmntToDo
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : decline preliminary created/updated automatic payment
******************************************************************************/   
FUNCTION declinePmntToDo(ps_seq_id VARCHAR2,
                                            pn_customer_id NUMBER,
                                            pn_person_id NUMBER,
                                            ps_channel_cd VARCHAR2,
                                            ps_user_approved VARCHAR2,
                                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_upd_info CLOB;
    ln_seq_id NUMBER;
    ls_status VARCHAR2(15);
    ls_returncode VARCHAR2(3) := '000';
    CURSOR upd_info IS
    SELECT p.*
    FROM CORPINT.TBL_AUTOPAYMENT P, CORPINT.TBL_PERSON_APPROVAL A
    WHERE p.customer_id = pn_customer_id AND
                (INSTR(ps_seq_id, ',' || TO_CHAR(p.seq_id) || ',')>0 OR
                (ps_seq_id = 'ALL' AND p.status = 'sNEW' AND p.upd_info is not null)) AND
                a.person_id = pn_person_id AND 
                a.auth_cd = DECODE(p.tran_cd, 'B2BHVL', 'aAPPRTMY',
                                                                'B2OBHVL', 'aAPPRTOY',
                                                                'CLEARING', 'aAPPREFT',
                                                                'GROSS', 'aAPPRGRS',
                                                                'EXCHNGBUY', 'aAPPRBFX',
                                                                'EXCHNGSELL', 'aAPPRSFX',
                                                                'CRDDEBTPYMNT', 'aAPPRCDP',
                                                                'SALARY', 'aAPPRSLRY',
                                                                'PAYMENTS', 'aAPPRPYM', '');
    res_upd upd_info%ROWTYPE;
BEGIN
    log_at('test_autopmnt_decline', 1, ps_seq_id, pn_customer_id || ' ' || ps_user_approved);
    OPEN upd_info;
    LOOP
       FETCH upd_info INTO res_upd;
       EXIT WHEN upd_info%NOTFOUND; 
       
       ls_upd_info := res_upd.upd_info;
       
       log_at('test_autopmnt_decline', 2, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
       IF ls_upd_info IS NOT NULL AND  trim(ls_upd_info) <> '' THEN
            ls_status := parseDetails(ls_upd_info, 5);
            log_at('test_autopmnt_decline', 4, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
            UPDATE corpint.tbl_autopayment
            SET upd_info = ''
            WHERE seq_id = res_upd.seq_id and
                        customer_id = pn_customer_id;
       ELSE
            IF res_upd.status = 'sNEW' THEN
                log_at('test_autopmnt_decline', 3, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
                UPDATE corpint.tbl_autopayment
                SET status = 'sDLTED',
                       approved_by = ps_user_approved,
                       approved_date = sysdate
                WHERE seq_id = res_upd.seq_id and
                            customer_id = pn_customer_id;        
            END IF;
       END IF;   
        log_at('test_autopmnt_decline', 5, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
        PKG_LOG.addAutopaymentLog('sDELETE', res_upd.payment_name, pn_person_id, res_upd.customer_id, res_upd.tran_code, res_upd.tran_cd, res_upd.channel_cd,
                                      res_upd.payment_type, res_upd.status, res_upd.payment_details, res_upd.defined_date, res_upd.execution_time, res_upd.period,
                                      res_upd.created_by, res_upd.created_date, ps_user_approved, sysdate, res_upd.seq_id, res_upd.next_date_time, res_upd.account_no, 
                                      res_upd.prev_date, res_upd.prev_ret_code, res_upd.prev_err_details, 'EXISTING AUTOPAYMENT AFTER MODIFICATION', ls_upd_info); 
       COMMIT;
    END LOOP;
    CLOSE upd_info;    
    
    log_at('test_autopmnt_decline', 6, to_char(ls_upd_info), ls_status || ' ' || ps_user_approved);
    ls_returncode := pkg_autopayment.getWaitPmnts('sDELETED',
                                                                             ps_seq_id,
                                                                             ps_channel_cd,
                                                                             pn_customer_id,
                                                                             pn_person_id,
                                                                             pc_ref);

    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    log_at('pkg_autopayment.declinePmntToDo', ps_seq_id || ' ' || pn_customer_id || ' ' || ps_user_approved, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);   
    open pc_ref for select sysdate from dual;
    return '999'; 
END;

/******************************************************************************
   Name       : FUNCTION makeAutopayment
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : make automatic payment
******************************************************************************/   
FUNCTION makeAutopayment(pn_person_id IN NUMBER,
                                             pn_customer_id IN NUMBER,
                                             pn_tran_code IN NUMBER,
                                             ps_tran_cd IN VARCHAR2,
                                             ps_channel_cd IN VARCHAR2,
                                             ps_payment_details IN CLOB,
                                             ps_trig_amount IN VARCHAR2,
                                             ps_trig_curr IN VARCHAR2,
                                             ps_error OUT VARCHAR2) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3) := '000';
    ls_pmnt CLOB;
    ls_parameter_0 VARCHAR2(500);
    ls_parameter_1 VARCHAR2(500);
    ls_parameter_2 VARCHAR2(500);
    ls_parameter_3 VARCHAR2(500);
    ls_parameter_4 VARCHAR2(500);
    ls_parameter_5 VARCHAR2(500);
    ls_parameter_6 VARCHAR2(500);
    ls_check_one VARCHAR2(3) := '000';
    ls_fx_rates VARCHAR2(50);
    ls_commAmount VARCHAR2(15);
    ls_commTax VARCHAR2(15);
    ld_date DATE;
    ls_trig_type VARCHAR2(10);
    ls_amount VARCHAR2(15);
    ls_currency VARCHAR2(10);
    ls_curr_amount VARCHAR2(15);
    ls_total_amount VARCHAR2(15);
    ls_rate VARCHAR2(10);
    ls_parity VARCHAR2(10);
    ls_from_amount VARCHAR2(15);
    ls_to_amount VARCHAR2(15);
    ls_maturity_date VARCHAR2(50);
    pc_ref cursorreferencetype;
    pc_ref_2 cursorreferencetype;
    pc_ref_3 cursorreferencetype;
    pc_ref_4 cursorreferencetype;
    pc_ref_5 cursorreferencetype;
    --r_res_cur pc_ref%ROWTYPE;
BEGIN
    ps_error := '';
    ls_pmnt := ps_payment_details;
    log_at('check_pmnt', 1, SUBSTR(to_char(ls_pmnt), 0, 1990), pn_person_id || ' ' || pn_tran_code || ' ' || ps_tran_cd || ' ' || ps_channel_cd);
    IF ps_channel_cd = 'cDKBRIB' THEN 
        IF pn_tran_code = 1203 and ps_tran_cd = 'B2BHVL' THEN
            log_at('check_pmnt', 2, SUBSTR(to_char(ls_pmnt), 0, 1990));
            log_at('check_pmnt', 2, ls_parameter_0 || ' ' || ls_parameter_1);
            ls_returncode := cbs.pkg_soa_common.HesapMusteriKontrol(parseDetails(ls_pmnt, 0), --  from account
                                                                                                     parseDetails(ls_pmnt, 8), --  customer id
                                                                                                     pc_ref);
            IF ls_returncode <> '000' THEN 
                return ls_returncode; 
            END IF;
            log_at('check_pmnt', 3, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_transaction.BooktoBookTransfer(parseDetails(ls_pmnt, 0), -- from account
                                                                                                        parseDetails(ls_pmnt, 1), -- to account
                                                                                                        parseDetails(ls_pmnt, 2), -- amount
                                                                                                        parseDetails(ls_pmnt, 3), -- description
                                                                                                        parseDetails(ls_pmnt, 4), -- currency code
                                                                                                        parseDetails(ls_pmnt, 5), -- dekont istemiyorum 'X'
                                                                                                        parseDetails(ls_pmnt, 6), -- payment code
                                                                                                        pc_ref);
            log_at('check_pmnt', 3, ls_returncode || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 4, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 8), -- customer id
                                                                                parseDetails(ls_pmnt, 11), -- tran cd
                                                                                parseDetails(ls_pmnt, 2), -- amount
                                                                                parseDetails(ls_pmnt, 4), -- currency code
                                                                                pn_person_id,
                                                                                parseDetails(ls_pmnt, 9), -- channel cd      
                                                                                ls_fx_rates, -- FX rates
                                                                                pc_ref); 
        ELSIF (pn_tran_code = 1203 OR pn_tran_code = 9501) and ps_tran_cd = 'B2OBHVL' THEN
            ls_currency := parseDetails(ls_pmnt, 4);
            ls_amount := parseDetails(ls_pmnt, 2);
            IF pn_tran_code = 9501 THEN
                ls_trig_type := parseDetails(ls_pmnt, 16);
                IF ls_trig_type = 'FULL' THEN
                    IF ls_currency = ps_trig_curr THEN
                        ls_amount := ps_trig_amount;
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(ps_trig_curr, ls_currency, NULL,
                                                                                        ps_trig_amount, 1, NULL, NULL, 'N', 'A'), '999999999.99');      
                    END IF;       
                ELSE
                    IF ls_currency = parseDetails(ls_pmnt, 19) THEN
                        ls_amount := parseDetails(ls_pmnt, 17);
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(parseDetails(ls_pmnt, 19), ls_currency, NULL,
                                                                                        parseDetails(ls_pmnt, 17), 1, NULL, NULL, 'N', 'A'), '999999999.99');     
                    END IF;
                END IF;
            END IF;
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 5, pn_tran_code || ' ' || ls_amount || ' ' ||  ls_fx_rates , ls_parameter_3 || ' ' || ls_currency || ' ' || ls_trig_type || ' ' || ps_trig_amount);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 10), -- customer id
                                                                                parseDetails(ls_pmnt, 13), -- tran cd
                                                                                ls_amount, -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 11), -- channel cd    
                                                                                ls_fx_rates, -- FX rates    
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 6, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_transaction.BooktoBookTransfer(parseDetails(ls_pmnt, 0), -- from account
                                                                                                        parseDetails(ls_pmnt, 1), -- to account
                                                                                                        ls_amount, -- amount
                                                                                                        parseDetails(ls_pmnt, 3), -- description
                                                                                                        ls_currency, -- currency code
                                                                                                        parseDetails(ls_pmnt, 5), -- dekont 'X'
                                                                                                        parseDetails(ls_pmnt, 6), -- payment code   
                                                                                                        pc_ref);        
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 7, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 10), -- customer id
                                                                                  parseDetails(ls_pmnt, 13), -- tran cd
                                                                                  ls_amount, -- amount
                                                                                  ls_currency, -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 11), -- channel cd      
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);        
        ELSIF (pn_tran_code = 3555 OR pn_tran_code = 9502) and ps_tran_cd = 'CLEARING' THEN
            ls_currency := parseDetails(ls_pmnt, 26);
            ls_amount := parseDetails(ls_pmnt, 8);
            IF pn_tran_code = 9502 THEN
                ls_trig_type := parseDetails(ls_pmnt, 28);
                IF ls_trig_type = 'FULL' THEN
                    IF ls_currency = ps_trig_curr THEN
                        ls_amount := ps_trig_amount;
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(ps_trig_curr, ls_currency, NULL,
                                                                                        ps_trig_amount, 1, NULL, NULL, 'N', 'A'), '999999999.99');      
                    END IF;       
                ELSE
                    IF ls_currency = parseDetails(ls_pmnt, 31) THEN
                        ls_amount := parseDetails(ls_pmnt, 29);
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(parseDetails(ls_pmnt, 31), ls_currency, NULL,
                                                                                        parseDetails(ls_pmnt, 29), 1, NULL, NULL, 'N', 'A'), '999999999.99');     
                    END IF;
                END IF;
            END IF;
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 8, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 21), -- customer id
                                                                                parseDetails(ls_pmnt, 24), -- tran cd
                                                                                ls_amount, -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 22), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 8, '0 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getCommissionIB(parseDetails(ls_pmnt, 24), -- tran cd
                                                                                                        parseDetails(ls_pmnt, 0), -- from account
                                                                                                        parseDetails(ls_pmnt, 7), -- to account
                                                                                                        ls_amount, -- amount
                                                                                                        ls_currency, -- currency
                                                                                                        'cDKBRIB', -- channel cd
                                                                                                        ls_commAmount,
                                                                                                        ls_commTax); 
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    

            log_at('check_pmnt', 8, '1 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getMaturityDate(parseDetails(ls_pmnt, 2), -- tran date
                                                                                                     ps_tran_cd, -- tran cd 
                                                                                                     '', -- type
                                                                                                     ls_maturity_date); --  return maturity date                                  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;              

            log_at('check_pmnt', 9, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_transaction.MakeEFT(parseDetails(ls_pmnt, 0), -- from account
                                                                                        parseDetails(ls_pmnt, 1), -- payee info
                                                                                        ls_maturity_date, -- tran date
                                                                                        parseDetails(ls_pmnt, 3), -- sender name
                                                                                        parseDetails(ls_pmnt, 4), -- sender phone
                                                                                        parseDetails(ls_pmnt, 5), -- bank code
                                                                                        parseDetails(ls_pmnt, 6), -- payee name
                                                                                        parseDetails(ls_pmnt, 7), -- to account 
                                                                                        ls_amount, -- amount
                                                                                        parseDetails(ls_pmnt, 9), -- description
                                                                                        parseDetails(ls_pmnt, 10), -- save payee flag
                                                                                        parseDetails(ls_pmnt, 11), -- payee nickname
                                                                                        parseDetails(ls_pmnt, 12), -- sender IRS 
                                                                                        parseDetails(ls_pmnt, 13), -- RNN
                                                                                        parseDetails(ls_pmnt, 14), -- Doc no
                                                                                        parseDetails(ls_pmnt, 15), -- stat
                                                                                        parseDetails(ls_pmnt, 16), -- paycodes
                                                                                        parseDetails(ls_pmnt, 17), -- income code
                                                                                        parseDetails(ls_pmnt, 18), -- bank codes
                                                                                        pc_ref);        
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            log_at('check_pmnt', 10, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 21), -- customer id
                                                                                  parseDetails(ls_pmnt, 24), -- tran cd
                                                                                  ls_amount, -- amount
                                                                                  ls_currency, -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 22), -- channel cd     
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);              
        ELSIF pn_tran_code = 4003 and ps_tran_cd = 'SWIFT' THEN
            log_at('check_pmnt', 11, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 2), -- account
                                                                                              parseDetails(ls_pmnt, 28), -- amount
                                                                                              pc_ref);     
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 2, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 12, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 29), -- customer id
                                                                                parseDetails(ls_pmnt, 30), -- tran cd
                                                                                parseDetails(ls_pmnt, 31), -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 33), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 32), -- currency code
                                                                                pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 12, '1 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getMaturityDate(parseDetails(ls_pmnt, 4), -- tran date
                                                                                                     'CLEARING', -- tran cd
                                                                                                     parseDetails(ls_pmnt, 23), -- type
                                                                                                     ls_maturity_date);     -- return maturity date                               
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 13, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_transaction.MAKESwift(parseDetails(ls_pmnt, 0), -- amount
                                                                                            parseDetails(ls_pmnt, 1), -- currency
                                                                                            parseDetails(ls_pmnt, 2), -- account id
                                                                                            parseDetails(ls_pmnt, 3), -- county code
                                                                                            ls_maturity_date, -- effective date
                                                                                            parseDetails(ls_pmnt, 5), -- description
                                                                                            to_char(sysdate, 'YYYYMMDD'), -- opening date
                                                                                            parseDetails(ls_pmnt, 7), --payee name
                                                                                            parseDetails(ls_pmnt, 8), -- payee address
                                                                                            parseDetails(ls_pmnt, 9), -- to account no
                                                                                            parseDetails(ls_pmnt, 10), --correspondent commission
                                                                                            parseDetails(ls_pmnt, 11), -- payment no
                                                                                            parseDetails(ls_pmnt, 12), -- swift code
                                                                                            parseDetails(ls_pmnt, 13), -- statcode
                                                                                            parseDetails(ls_pmnt, 14), -- bank name
                                                                                            parseDetails(ls_pmnt, 15), -- charge amount
                                                                                            parseDetails(ls_pmnt, 16), -- telpass
                                                                                            parseDetails(ls_pmnt, 17), -- rec desc
                                                                                            parseDetails(ls_pmnt, 18), -- recvisite
                                                                                            parseDetails(ls_pmnt, 19), -- city name      
                                                                                            parseDetails(ls_pmnt, 20), -- comm account
                                                                                            pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;     
            
            log_at('check_pmnt', 14, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 29), -- customer id
                                                                                  parseDetails(ls_pmnt, 30), -- tran cd
                                                                                  parseDetails(ls_pmnt, 31), -- amount
                                                                                  parseDetails(ls_pmnt, 32), -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 33), -- channel cd      
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);         
        ELSIF pn_tran_code = 4025 and ps_tran_cd = 'EXCHNGBUY' THEN
            IF parseDetails(ls_pmnt, 25) = 'LC' THEN
                ls_amount := parseDetails(ls_pmnt, 15);
                ls_currency := 'KGS';
            ELSE
                ls_amount := parseDetails(ls_pmnt, 8);    
                ls_currency := parseDetails(ls_pmnt, 24);        
            END IF;

            log_at('check_pmnt', 15, '0 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.ExchangeTransactions(parseDetails(ls_pmnt, 0), -- option
                                                                                                      parseDetails(ls_pmnt, 18), -- customer id
                                                                                                      pn_person_id, -- person id
                                                                                                      parseDetails(ls_pmnt, 19), -- channel cd
                                                                                                      parseDetails(ls_pmnt, 21), -- tran cd
                                                                                                      parseDetails(ls_pmnt, 5), -- tran type
                                                                                                      ls_amount, -- amount
                                                                                                      ls_currency, -- currency 
                                                                                                      parseDetails(ls_pmnt, 24), --  foreign currency
                                                                                                      parseDetails(ls_pmnt, 11), -- reservation no 
                                                                                                      pc_ref,
                                                                                                      pc_ref_2,
                                                                                                      pc_ref_3,
                                                                                                      pc_ref_4,
                                                                                                      pc_ref_5);         
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    

            log_at('check_pmnt', 15, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getExchangeRatioIB(pc_ref_2, parseDetails(ls_pmnt, 5), ls_curr_amount, ls_total_amount, ls_rate);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
        
            log_at('check_pmnt', 15, ls_total_amount || ' ' || ls_curr_amount || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 6), -- account
                                                                                              ls_total_amount, -- amount
                                                                                              pc_ref);            
            log_at('check_pmnt', 15, ls_returncode || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 16, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 18), -- customer id
                                                                                parseDetails(ls_pmnt, 21), -- tran cd
                                                                                ls_total_amount, -- total amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 19), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 17, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.CallExchangeTran(parseDetails(ls_pmnt, 0), -- option
                                                                                                parseDetails(ls_pmnt, 1), -- customer id
                                                                                                parseDetails(ls_pmnt, 2), -- person_id
                                                                                                parseDetails(ls_pmnt, 3), -- channel cd
                                                                                                parseDetails(ls_pmnt, 4), -- tran cd      
                                                                                                parseDetails(ls_pmnt, 5), -- tran type    
                                                                                                parseDetails(ls_pmnt, 6), -- from account
                                                                                                parseDetails(ls_pmnt, 7), -- to account
                                                                                                ls_curr_amount, -- amount
                                                                                                parseDetails(ls_pmnt, 24), -- amount currency
                                                                                                ls_rate, -- rate  
                                                                                                parseDetails(ls_pmnt, 11), -- reservation no    
                                                                                                parseDetails(ls_pmnt, 12), -- description
                                                                                                parseDetails(ls_pmnt, 13), -- expense     
                                                                                                parseDetails(ls_pmnt, 14), -- statistic code    
                                                                                                ls_total_amount, -- total amount
                                                                                                pc_ref,
                                                                                                pc_ref_2,
                                                                                                pc_ref_3,
                                                                                                pc_ref_4,
                                                                                                pc_ref_5);
        ELSIF pn_tran_code = 1202 and ps_tran_cd = 'EXCHNGSELL' THEN
            IF parseDetails(ls_pmnt, 25) = 'LC' THEN
                ls_amount := parseDetails(ls_pmnt, 15);
                ls_currency := 'KGS';
            ELSE
                ls_amount := parseDetails(ls_pmnt, 8);          
                ls_currency := parseDetails(ls_pmnt, 24);  
            END IF;
            
            log_at('check_pmnt', 18, '0 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.ExchangeTransactions(parseDetails(ls_pmnt, 0), -- option
                                                                                                      parseDetails(ls_pmnt, 18), -- customer id
                                                                                                      pn_person_id, -- person id
                                                                                                      parseDetails(ls_pmnt, 19), -- channel cd
                                                                                                      parseDetails(ls_pmnt, 21), -- tran cd
                                                                                                      parseDetails(ls_pmnt, 5), -- tran type
                                                                                                      ls_amount, -- amount
                                                                                                      ls_currency, -- currency 
                                                                                                      parseDetails(ls_pmnt, 24), --  foreign currency
                                                                                                      parseDetails(ls_pmnt, 11), -- reservation no 
                                                                                                      pc_ref,
                                                                                                      pc_ref_2,
                                                                                                      pc_ref_3,
                                                                                                      pc_ref_4,
                                                                                                      pc_ref_5);         
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    

            log_at('check_pmnt', 18, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getExchangeRatioIB(pc_ref_2, parseDetails(ls_pmnt, 5), ls_curr_amount, ls_total_amount, ls_rate);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
            
            log_at('check_pmnt', 18, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 6), -- account
                                                                                              ls_curr_amount, -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 19, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 18), -- customer id
                                                                                parseDetails(ls_pmnt, 21), -- tran cd
                                                                                ls_total_amount, -- total amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 19), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 20, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.CallExchangeTran(parseDetails(ls_pmnt, 0), -- option
                                                                                                parseDetails(ls_pmnt, 1), -- customer id
                                                                                                parseDetails(ls_pmnt, 2), -- person_id
                                                                                                parseDetails(ls_pmnt, 3), -- channel cd
                                                                                                parseDetails(ls_pmnt, 4), -- tran cd      
                                                                                                parseDetails(ls_pmnt, 5), -- tran type    
                                                                                                parseDetails(ls_pmnt, 6), -- from account
                                                                                                parseDetails(ls_pmnt, 7), -- to account
                                                                                                ls_curr_amount, -- amount
                                                                                                parseDetails(ls_pmnt, 24), -- amount currency
                                                                                                ls_rate, -- rate  
                                                                                                parseDetails(ls_pmnt, 11), -- reservation no    
                                                                                                parseDetails(ls_pmnt, 12), -- description
                                                                                                parseDetails(ls_pmnt, 13), -- expense     
                                                                                                parseDetails(ls_pmnt, 14), -- statistic code    
                                                                                                ls_total_amount, -- total amount
                                                                                                pc_ref,
                                                                                                pc_ref_2,
                                                                                                pc_ref_3,
                                                                                                pc_ref_4,
                                                                                                pc_ref_5);
        ELSIF pn_tran_code = 1207 and ps_tran_cd = 'ARBITRAGE' THEN  
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 4, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;   

            log_at('check_pmnt', 21, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 14), -- customer id
                                                                                parseDetails(ls_pmnt, 17), -- tran cd
                                                                                parseDetails(ls_pmnt, 11), -- total amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 15), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 8), -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 22, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.CheckArbitraje('NULLOPTION', -- option
                                                                                           parseDetails(ls_pmnt, 14), -- customer id
                                                                                           pn_person_id, -- person id
                                                                                           parseDetails(ls_pmnt, 15), -- channel cd
                                                                                           parseDetails(ls_pmnt, 17), -- tran cd
                                                                                           parseDetails(ls_pmnt, 5), -- to account
                                                                                           parseDetails(ls_pmnt, 6), -- from account
                                                                                           parseDetails(ls_pmnt, 7), -- to account currency
                                                                                           parseDetails(ls_pmnt, 8), -- from account currency
                                                                                           parseDetails(ls_pmnt, 21), -- amount
                                                                                           parseDetails(ls_pmnt, 22), -- amount currency
                                                                                           --'', -- reservation no is null
                                                                                           pc_ref,
                                                                                           pc_ref_2,
                                                                                           pc_ref_3,
                                                                                           pc_ref_4,
                                                                                           pc_ref_5);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF; 
            
            log_at('check_pmnt', 23, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := pkg_autopayment.getExchangeParityIB(pc_ref,
                                                                                                pc_ref_2,
                                                                                                parseDetails(ls_pmnt, 22),
                                                                                                ls_parity,
                                                                                                ls_from_amount,
                                                                                                ls_to_amount);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;             
            log_at('check_pmnt', 23, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.CallArbitTran(parseDetails(ls_pmnt, 0), -- option
                                                                                        parseDetails(ls_pmnt, 1), -- customer id
                                                                                        parseDetails(ls_pmnt, 2), -- person_id
                                                                                        parseDetails(ls_pmnt, 3), -- channel cd
                                                                                        parseDetails(ls_pmnt, 4), -- tran cd      
                                                                                        parseDetails(ls_pmnt, 5), -- to account    
                                                                                        parseDetails(ls_pmnt, 6), -- from account
                                                                                        parseDetails(ls_pmnt, 7), -- to account currency
                                                                                        parseDetails(ls_pmnt, 8), -- from account currency
                                                                                        ls_parity, -- parity
                                                                                        ls_to_amount, -- to amount 
                                                                                        ls_from_amount, -- from amount    
                                                                                        pc_ref,
                                                                                        pc_ref_2,
                                                                                        pc_ref_3,
                                                                                        pc_ref_4,
                                                                                        pc_ref_5);        
        ELSIF pn_tran_code = 3555 and ps_tran_cd = 'TAXPYMNTS' THEN
            log_at('check_pmnt', 24, '0 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getCommissionIB(parseDetails(ls_pmnt, 17), -- tran cd
                                                                                                        parseDetails(ls_pmnt, 8), -- from account
                                                                                                        '', -- to account
                                                                                                        parseDetails(ls_pmnt, 6), -- amount
                                                                                                        parseDetails(ls_pmnt, 19), -- currency
                                                                                                        'cDKBRIB', -- channel cd
                                                                                                        ls_commAmount,
                                                                                                        ls_commTax); 
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
            
            log_at('check_pmnt', 24, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 8), -- account
                                                                                              parseDetails(ls_pmnt, 13), -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;   
            
            log_at('check_pmnt', 25, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.getWsTaxInfo(parseDetails(ls_pmnt, 0),
                                                                                         pc_ref); 
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;   

            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
                 
            log_at('check_pmnt', 26, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 14), -- customer id
                                                                                'CLEARING', -- tran cd
                                                                                parseDetails(ls_pmnt, 18), -- total amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 15), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 19), -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 27, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_transaction.makeTaxPayment(parseDetails(ls_pmnt, 0), -- tin number
                                                                                                    parseDetails(ls_pmnt, 1), -- name surname
                                                                                                    parseDetails(ls_pmnt, 2), -- type id
                                                                                                    parseDetails(ls_pmnt, 3), -- region id
                                                                                                    parseDetails(ls_pmnt, 4), -- district id    
                                                                                                    parseDetails(ls_pmnt, 5), -- subdistrict id   
                                                                                                    parseDetails(ls_pmnt, 6), -- amount
                                                                                                    parseDetails(ls_pmnt, 7), -- explanation id
                                                                                                    parseDetails(ls_pmnt, 8), -- fom account
                                                                                                    parseDetails(ls_pmnt, 9), -- person id
                                                                                                    '',--parseDetails(ls_pmnt, 10), --vehicle plate
                                                                                                    pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF; 
            
            log_at('check_pmnt', 28, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 14), -- customer id
                                                                                  'CLEARING', -- tran cd
                                                                                  parseDetails(ls_pmnt, 18), -- amount
                                                                                  parseDetails(ls_pmnt, 19), -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 15), -- channel cd      
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);    
        ELSIF (pn_tran_code = 6330 OR pn_tran_code = 9503) and ps_tran_cd = 'PAYMENTS' THEN
            ls_currency := parseDetails(ls_pmnt, 3);
            ls_amount := parseDetails(ls_pmnt, 1);
            IF pn_tran_code = 9503 THEN
                ls_trig_type := parseDetails(ls_pmnt, 15);
                IF ls_trig_type = 'FULL' THEN
                    IF ls_currency = ps_trig_curr THEN
                        ls_amount := ps_trig_amount;
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(ps_trig_curr, ls_currency, NULL,
                                                                                        ps_trig_amount, 1, NULL, NULL, 'N', 'A'), '999999999.99');      
                    END IF;       
                ELSE
                    IF ls_currency = parseDetails(ls_pmnt, 18) THEN
                        ls_amount := parseDetails(ls_pmnt, 16);
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(parseDetails(ls_pmnt, 18), ls_currency, NULL,
                                                                                        parseDetails(ls_pmnt, 16), 1, NULL, NULL, 'N', 'A'), '999999999.99');     
                    END IF;
                END IF;
            END IF;
            log_at('check_pmnt', 29, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 0), -- account
                                                                                              ls_amount, -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;   
            
            log_at('check_pmnt', 30, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_transaction.PayForServices(parseDetails(ls_pmnt, 0), -- from account
                                                                                                    ls_amount, -- amount
                                                                                                    parseDetails(ls_pmnt, 2), -- description
                                                                                                    ls_currency, -- currency code
                                                                                                    parseDetails(ls_pmnt, 4), -- institution  
                                                                                                    parseDetails(ls_pmnt, 5), -- phone area code
                                                                                                    parseDetails(ls_pmnt, 6), -- phone no
                                                                                                    parseDetails(ls_pmnt, 7), -- service code
                                                                                                    parseDetails(ls_pmnt, 8), -- service no
                                                                                                    pc_ref);
        ELSIF pn_tran_code = 7723 and ps_tran_cd = 'CRDDEBTPYMNT' THEN
            log_at('check_pmnt', 64, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 2), -- account
                                                                                              parseDetails(ls_pmnt, 3), -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            log_at('check_pmnt', 65, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 66, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 0), -- customer id
                                                                                parseDetails(ls_pmnt, 13), -- tran cd
                                                                                parseDetails(ls_pmnt, 3), -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 15), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 16), -- currency code
                                                                                pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            log_at('check_pmnt', 67, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_int_tx.CreditCardCPaymentTx(parseDetails(ls_pmnt, 0), -- customer id
                                                                                                parseDetails(ls_pmnt, 1), -- person id
                                                                                                parseDetails(ls_pmnt, 2), -- from account
                                                                                                parseDetails(ls_pmnt, 3), -- amount
                                                                                                parseDetails(ls_pmnt, 4), -- credit card no
                                                                                                '',--parseDetails(ls_pmnt, 5), -- pseudopan
                                                                                                pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;     
            
            log_at('check_pmnt', 68, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 12), -- customer id
                                                                                  parseDetails(ls_pmnt, 13), -- tran cd
                                                                                  parseDetails(ls_pmnt, 3), -- amount
                                                                                  parseDetails(ls_pmnt, 16), -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 15), -- channel cd      
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);       
        ELSIF pn_tran_code = 7723 and ps_tran_cd = 'OCRDDEBTPYMNT' THEN
            log_at('check_pmnt', 31, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 2), -- account
                                                                                              parseDetails(ls_pmnt, 3), -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 32, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 6), -- customer id
                                                                                parseDetails(ls_pmnt, 9), -- tran cd
                                                                                parseDetails(ls_pmnt, 3), -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 7), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 11), -- currency code
                                                                                pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            log_at('check_pmnt', 33, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_int_tx.CreditCardCPaymentTx(parseDetails(ls_pmnt, 0), -- customer id
                                                                                                parseDetails(ls_pmnt, 1), -- person id
                                                                                                parseDetails(ls_pmnt, 2), -- from account
                                                                                                parseDetails(ls_pmnt, 3), -- amount
                                                                                                parseDetails(ls_pmnt, 4), -- credit card no
                                                                                                '',--parseDetails(ls_pmnt, 5), -- pseudopan
                                                                                                pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;     
            
            log_at('check_pmnt', 34, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 6), -- customer id
                                                                                  parseDetails(ls_pmnt, 9), -- tran cd
                                                                                  parseDetails(ls_pmnt, 3), -- amount
                                                                                  parseDetails(ls_pmnt, 11), -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 7), -- channel cd      
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);                     
        END IF;
    ELSIF ps_channel_cd = 'cDKBCIB' THEN
        IF pn_tran_code = 1203 and ps_tran_cd = 'B2BHVL' THEN
            log_at('check_pmnt', 39, ls_parameter_0 || ' ' || ls_parameter_1);
            ls_returncode := cbs.pkg_soa_common.HesapMusteriKontrol(parseDetails(ls_pmnt, 0), --  from account
                                                                                                     parseDetails(ls_pmnt, 8), --  customer id
                                                                                                     pc_ref);
            IF ls_returncode <> '000' THEN 
                return ls_returncode; 
            END IF;
            log_at('check_pmnt', 40, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_int_transfer.BooktoBookTransfer(parseDetails(ls_pmnt, 0), -- from account
                                                                                                    parseDetails(ls_pmnt, 1), -- to account
                                                                                                    parseDetails(ls_pmnt, 2), -- amount
                                                                                                    parseDetails(ls_pmnt, 3), -- description
                                                                                                    parseDetails(ls_pmnt, 4), -- currency code
                                                                                                    parseDetails(ls_pmnt, 5), -- dekont istemiyorum 'X'
                                                                                                    parseDetails(ls_pmnt, 6), -- payment code
                                                                                                    parseDetails(ls_pmnt, 7), -- order number
                                                                                                    pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 41, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 42, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 8), -- customer id
                                                                                parseDetails(ls_pmnt, 11), -- tran cd
                                                                                parseDetails(ls_pmnt, 2), -- amount
                                                                                parseDetails(ls_pmnt, 4), -- currency code
                                                                                pn_person_id,
                                                                                parseDetails(ls_pmnt, 9), -- channel cd      
                                                                                ls_fx_rates, -- FX rates
                                                                                pc_ref);  
        ELSIF (pn_tran_code = 1203 OR pn_tran_code = 9501) and ps_tran_cd = 'B2OBHVL' THEN
            ls_currency := parseDetails(ls_pmnt, 4);
            ls_amount := parseDetails(ls_pmnt, 2);
            IF pn_tran_code = 9501 THEN
                ls_trig_type := parseDetails(ls_pmnt, 15);
                IF ls_trig_type = 'FULL' THEN
                    IF ls_currency = ps_trig_curr THEN
                        ls_amount := ps_trig_amount;
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(ps_trig_curr, ls_currency, NULL,
                                                                                        ps_trig_amount, 1, NULL, NULL, 'N', 'A'), '999999999.99');      
                    END IF;       
                ELSE
                    IF ls_currency = parseDetails(ls_pmnt, 18) THEN
                        ls_amount := parseDetails(ls_pmnt, 16);
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(parseDetails(ls_pmnt, 18), ls_currency, NULL,
                                                                                        parseDetails(ls_pmnt, 16), 1, NULL, NULL, 'N', 'A'), '999999999.99');     
                    END IF;
                END IF;
            END IF;
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 43, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 11), -- customer id
                                                                                parseDetails(ls_pmnt, 12), -- tran cd
                                                                                ls_amount, -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 14), -- channel cd    
                                                                                ls_fx_rates, -- FX rates    
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 44, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_int_transfer.BooktoBookTransfer(parseDetails(ls_pmnt, 0), -- from account
                                                                                                    parseDetails(ls_pmnt, 1), -- to account
                                                                                                    ls_amount, -- amount
                                                                                                    parseDetails(ls_pmnt, 3), -- description
                                                                                                    ls_currency, -- currency code
                                                                                                    parseDetails(ls_pmnt, 5), -- dekont 'X'
                                                                                                    parseDetails(ls_pmnt, 6), -- payment code   
                                                                                                    parseDetails(ls_pmnt, 7), -- order number   
                                                                                                    pc_ref);        
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 45, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 11), -- customer id
                                                                                  parseDetails(ls_pmnt, 12), -- tran cd
                                                                                  ls_amount, -- amount
                                                                                  ls_currency, -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 14), -- channel cd      
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);    
        ELSIF (pn_tran_code = 3555 OR pn_tran_code = 9502) and ps_tran_cd = 'CLEARING' THEN
            ls_currency := parseDetails(ls_pmnt, 26);
            ls_amount := parseDetails(ls_pmnt, 8);
            IF pn_tran_code = 9502 THEN
                ls_trig_type := parseDetails(ls_pmnt, 28);
                IF ls_trig_type = 'FULL' THEN
                    IF ls_currency = ps_trig_curr THEN
                        ls_amount := ps_trig_amount;
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(ps_trig_curr, ls_currency, NULL,
                                                                                        ps_trig_amount, 1, NULL, NULL, 'N', 'A'), '999999999.99');      
                    END IF;       
                ELSE
                    IF ls_currency = parseDetails(ls_pmnt, 31) THEN
                        ls_amount := parseDetails(ls_pmnt, 29);
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(parseDetails(ls_pmnt, 31), ls_currency, NULL,
                                                                                        parseDetails(ls_pmnt, 29), 1, NULL, NULL, 'N', 'A'), '999999999.99');     
                    END IF;
                END IF;
            END IF;        
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 35, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 21), -- customer id
                                                                                parseDetails(ls_pmnt, 24), -- tran cd
                                                                                ls_amount, -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 22), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;   
                 
            log_at('check_pmnt', 36, '0 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getCommissionIB(parseDetails(ls_pmnt, 24), -- tran cd
                                                                                                        parseDetails(ls_pmnt, 0), -- from account
                                                                                                        parseDetails(ls_pmnt, 7), -- to account
                                                                                                        ls_amount, -- amount
                                                                                                        ls_currency, -- currency
                                                                                                        'cDKBCIB', -- channel cd
                                                                                                        ls_commAmount,
                                                                                                        ls_commTax); 
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
            
            log_at('check_pmnt', 36, '1 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getMaturityDate(parseDetails(ls_pmnt, 2), -- tran date
                                                                                                     parseDetails(ls_pmnt, 24), -- tran cd
                                                                                                     '', -- type
                                                                                                     ls_maturity_date);     -- return maturity date                               
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;            
            
            log_at('check_pmnt', 37, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_int_transfer.MakeEFT(parseDetails(ls_pmnt, 0), -- from account
                                                                                    parseDetails(ls_pmnt, 1), -- payee info
                                                                                    ls_maturity_date, -- tran date
                                                                                    parseDetails(ls_pmnt, 3), -- sender name
                                                                                    parseDetails(ls_pmnt, 4), -- sender phone
                                                                                    parseDetails(ls_pmnt, 5), -- bank code
                                                                                    parseDetails(ls_pmnt, 6), -- payee name
                                                                                    parseDetails(ls_pmnt, 7), -- to account
                                                                                    ls_amount, -- amount
                                                                                    parseDetails(ls_pmnt, 9), -- description
                                                                                    parseDetails(ls_pmnt, 10), -- save payee flag
                                                                                    parseDetails(ls_pmnt, 11), -- payee nickname
                                                                                    parseDetails(ls_pmnt, 12), -- payment code
                                                                                    parseDetails(ls_pmnt, 13), -- sub account
                                                                                    parseDetails(ls_pmnt, 14), -- sub name
                                                                                    parseDetails(ls_pmnt, 15), -- payment for services
                                                                                    parseDetails(ls_pmnt, 16), -- transfer option
                                                                                    parseDetails(ls_pmnt, 17), -- order number
                                                                                    pc_ref);        
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
                
            log_at('check_pmnt', 38, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 21), -- customer id
                                                                                  parseDetails(ls_pmnt, 24), -- tran cd
                                                                                  ls_amount, -- amount
                                                                                  ls_currency, -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 22), -- channel cd     
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);     
        ELSIF pn_tran_code = 4025 and ps_tran_cd = 'EXCHNGBUY' THEN
            IF parseDetails(ls_pmnt, 19) = 'LC' THEN
                ls_amount := parseDetails(ls_pmnt, 10);
                ls_currency := 'KGS';
            ELSE
                ls_amount := parseDetails(ls_pmnt, 4);   
                ls_currency := parseDetails(ls_pmnt, 18); 
            END IF;

            log_at('check_pmnt', 46, '0 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.ExchangeTransactions('', -- option
                                                                                                      parseDetails(ls_pmnt, 13), -- customer id
                                                                                                      pn_person_id, -- person id
                                                                                                      parseDetails(ls_pmnt, 16), -- channel cd
                                                                                                      parseDetails(ls_pmnt, 14), -- tran cd
                                                                                                      parseDetails(ls_pmnt, 0), -- tran type
                                                                                                      ls_amount, -- amount
                                                                                                      ls_currency, -- currency 
                                                                                                      parseDetails(ls_pmnt, 18), --  foreign currency
                                                                                                      parseDetails(ls_pmnt, 8), -- reservation no 
                                                                                                      pc_ref,
                                                                                                      pc_ref_2,
                                                                                                      pc_ref_3,
                                                                                                      pc_ref_4,
                                                                                                      pc_ref_5);                               
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
            
            log_at('check_pmnt', 47, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getExchangeRatioIB(pc_ref_2, parseDetails(ls_pmnt, 0), ls_curr_amount, ls_total_amount, ls_rate);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
         
            log_at('check_pmnt', 47, ls_total_amount || ' ' || ls_rate || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 1), -- account
                                                                                              ls_total_amount, -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 48, ls_fx_rates || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 13), -- customer id
                                                                                parseDetails(ls_pmnt, 14), -- tran cd
                                                                                ls_total_amount, -- total amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 16), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 17), -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 49, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.PKG_INT_CURRENCY.FXBuySell(parseDetails(ls_pmnt, 0), -- tran type
                                                                                            parseDetails(ls_pmnt, 1), -- from account
                                                                                            parseDetails(ls_pmnt, 18), -- currency code
                                                                                            ls_rate, -- fx rate
                                                                                            ls_curr_amount, -- amount      
                                                                                            parseDetails(ls_pmnt, 5), -- to account    
                                                                                            parseDetails(ls_pmnt, 6), -- statistical code
                                                                                            parseDetails(ls_pmnt, 7), -- description
                                                                                            parseDetails(ls_pmnt, 8), -- reservation no
                                                                                            parseDetails(ls_pmnt, 9), -- commission
                                                                                            ls_total_amount, -- total amount
                                                                                            pc_ref);
        ELSIF pn_tran_code = 1202 and ps_tran_cd = 'EXCHNGSELL' THEN
            IF parseDetails(ls_pmnt, 20) = 'LC' THEN
                ls_amount := parseDetails(ls_pmnt, 10);
                ls_currency := 'KGS';
            ELSE
                ls_amount := parseDetails(ls_pmnt, 4);          
                ls_currency := parseDetails(ls_pmnt, 18);  
            END IF;
            log_at('check_pmnt', 50, '0 ' || ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.ExchangeTransactions('', -- option
                                                                                                      parseDetails(ls_pmnt, 11), -- customer id
                                                                                                      pn_person_id, -- person id
                                                                                                      parseDetails(ls_pmnt, 14), -- channel cd
                                                                                                      parseDetails(ls_pmnt, 12), -- tran cd
                                                                                                      parseDetails(ls_pmnt, 0), -- tran type
                                                                                                      ls_amount, -- amount
                                                                                                      ls_currency, -- currency 
                                                                                                      parseDetails(ls_pmnt, 18), --  foreign currency
                                                                                                      parseDetails(ls_pmnt, 8), -- reservation no 
                                                                                                      pc_ref,
                                                                                                      pc_ref_2,
                                                                                                      pc_ref_3,
                                                                                                      pc_ref_4,
                                                                                                      pc_ref_5);         
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
            
            log_at('check_pmnt', 51, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getExchangeRatioIB(pc_ref_2, parseDetails(ls_pmnt, 0), ls_curr_amount, ls_total_amount, ls_rate);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;    
            
            log_at('check_pmnt', 51, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 1), -- account
                                                                                              ls_curr_amount, -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            
            log_at('check_pmnt', 52, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 11), -- customer id
                                                                                parseDetails(ls_pmnt, 12), -- tran cd
                                                                                ls_total_amount, -- total amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 14), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        

            log_at('check_pmnt', 53, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.PKG_INT_CURRENCY.FXBuySell(parseDetails(ls_pmnt, 0), -- tran type
                                                                                            parseDetails(ls_pmnt, 1), -- from account
                                                                                            parseDetails(ls_pmnt, 18), -- currency code
                                                                                            ls_rate, -- fx rate
                                                                                            ls_curr_amount, -- amount      
                                                                                            parseDetails(ls_pmnt, 5), -- to account    
                                                                                            parseDetails(ls_pmnt, 6), -- statistical code
                                                                                            parseDetails(ls_pmnt, 7), -- description
                                                                                            parseDetails(ls_pmnt, 8), -- reservation no
                                                                                            parseDetails(ls_pmnt, 9), -- commission
                                                                                            ls_total_amount, -- total amount
                                                                                            pc_ref);
        /* ELSIF pn_tran_code = 1207 and ps_tran_cd = 'ARBITRAGE' THEN  
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;   

            log_at('check_pmnt', 54, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 7), -- customer id
                                                                                parseDetails(ls_pmnt, 8), -- tran cd
                                                                                parseDetails(ls_pmnt, 9), -- total amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 11), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 13), -- currency code
                                                                                pc_ref);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            log_at('check_pmnt', 55, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_inquiry.CheckArbitraje('NULLOPTION', -- option
                                                                                           parseDetails(ls_pmnt, 7), -- customer id
                                                                                           pn_person_id, -- person id
                                                                                           parseDetails(ls_pmnt, 11), -- channel cd
                                                                                           parseDetails(ls_pmnt, 8), -- tran cd
                                                                                           '', -- to account
                                                                                           parseDetails(ls_pmnt, 0), -- from account
                                                                                           parseDetails(ls_pmnt, 3), -- to account currency
                                                                                           parseDetails(ls_pmnt, 2), -- from account currency
                                                                                           parseDetails(ls_pmnt, 17), -- amount
                                                                                           parseDetails(ls_pmnt, 16), -- amount currency
                                                                                           pc_ref,
                                                                                           pc_ref_2,
                                                                                           pc_ref_3,
                                                                                           pc_ref_4,
                                                                                           pc_ref_5);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;                                                                                    
                    
            log_at('check_pmnt', 56, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.PKG_INT_CURRENCY.MakeArbitrage(parseDetails(ls_pmnt, 0), -- from account
                                                                                                   parseDetails(ls_pmnt, 1), -- to account 
                                                                                                   parseDetails(ls_pmnt, 2), -- from currency
                                                                                                   parseDetails(ls_pmnt, 3), -- to currency
                                                                                                   parseDetails(ls_pmnt, 4), -- parity
                                                                                                   parseDetails(ls_pmnt, 5), -- from amount
                                                                                                   parseDetails(ls_pmnt, 6), -- to amount
                                                                                                   pc_ref);       */     
        ELSIF pn_tran_code = 7723 and ps_tran_cd = 'CRDDEBTPYMNT' THEN
            log_at('check_pmnt', 57, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 2), -- account
                                                                                              parseDetails(ls_pmnt, 3), -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            log_at('check_pmnt', 58, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            log_at('check_pmnt', 59, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.CheckLimit(parseDetails(ls_pmnt, 0), -- customer id
                                                                                parseDetails(ls_pmnt, 5), -- tran cd
                                                                                parseDetails(ls_pmnt, 3), -- amount
                                                                                pn_person_id, -- person id
                                                                                parseDetails(ls_pmnt, 7), -- channel cd      
                                                                                ls_fx_rates, -- FX rates    
                                                                                parseDetails(ls_pmnt, 6), -- currency code
                                                                                pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;        
            
            log_at('check_pmnt', 60, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_int_transfer.MakeCardDebtPayment(parseDetails(ls_pmnt, 1), -- person id
                                                                                                        parseDetails(ls_pmnt, 2), -- from account
                                                                                                        parseDetails(ls_pmnt, 3), -- amount
                                                                                                        parseDetails(ls_pmnt, 4), -- credit card no
                                                                                                        '',--parseDetails(ls_pmnt, 5), -- pseudopan
                                                                                                        pc_ref);  
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;     
            
            log_at('check_pmnt', 61, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := corpint.pkg_limit.UpdateLimit(parseDetails(ls_pmnt, 0), -- customer id
                                                                                  parseDetails(ls_pmnt, 5), -- tran cd
                                                                                  parseDetails(ls_pmnt, 3), -- amount
                                                                                  parseDetails(ls_pmnt, 6), -- currency code
                                                                                  pn_person_id,
                                                                                  parseDetails(ls_pmnt, 7), -- channel cd      
                                                                                  ls_fx_rates, -- FX rates
                                                                                  pc_ref);  
        ELSIF (pn_tran_code = 6330 OR pn_tran_code = 9503) and ps_tran_cd = 'PAYMENTS' THEN
            ls_currency := parseDetails(ls_pmnt, 3);
            ls_amount := parseDetails(ls_pmnt, 1);
            IF pn_tran_code = 9503 THEN
                ls_trig_type := parseDetails(ls_pmnt, 15);
                IF ls_trig_type = 'FULL' THEN
                    IF ls_currency = ps_trig_curr THEN
                        ls_amount := ps_trig_amount;
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(ps_trig_curr, ls_currency, NULL,
                                                                                        ps_trig_amount, 1, NULL, NULL, 'N', 'A'), '999999999.99');      
                    END IF;       
                ELSE
                    IF ls_currency = parseDetails(ls_pmnt, 18) THEN
                        ls_amount := parseDetails(ls_pmnt, 16);
                    ELSE
                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(parseDetails(ls_pmnt, 18), ls_currency, NULL,
                                                                                        parseDetails(ls_pmnt, 16), 1, NULL, NULL, 'N', 'A'), '999999999.99');     
                    END IF;
                END IF;
            END IF;    
            log_at('check_pmnt', 62, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(parseDetails(ls_pmnt, 0), -- account
                                                                                              ls_amount, -- amount
                                                                                              pc_ref);            
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;   
            
            log_at('check_pmnt', 63, ls_parameter_0 || ' ' || ls_parameter_1 || ' ' ||  ls_parameter_2 , ls_parameter_3 || ' ' || ls_parameter_4 || ' ' || ls_parameter_5 || ' ' || ls_parameter_6);
            ls_returncode := cbs.pkg_soa_transaction.PayForServices(parseDetails(ls_pmnt, 0), -- from account
                                                                                                    ls_amount, -- amount
                                                                                                    parseDetails(ls_pmnt, 2), -- description
                                                                                                    ls_currency, -- currency code
                                                                                                    parseDetails(ls_pmnt, 4), -- institution  
                                                                                                    parseDetails(ls_pmnt, 5), -- phone area code
                                                                                                    parseDetails(ls_pmnt, 6), -- phone no
                                                                                                    parseDetails(ls_pmnt, 7), -- service code
                                                                                                    parseDetails(ls_pmnt, 8), -- service no
                                                                                                    pc_ref);                                                                                                       
        END IF;         
    END IF;
    
    log_at('check_pmnt', 99, ls_returncode);
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.makeAutopayment', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ps_error := substr(to_char(SQLERRM), 1, 500);
    ls_returncode := Pkg_Int_Api.GetErrorCode(SQLERRM);
    return ls_returncode;
END;

/******************************************************************************
   Name       : PROCEDURE processAutopayments
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : process automatic payments
******************************************************************************/   
PROCEDURE processAutopayments(pd_start_date DATE) IS
    ls_start_time VARCHAR2(20);
    ls_returncode VARCHAR2(3) := '000';
    ls_status VARCHAR2(10) := 'sENAB';
    ld_run_date DATE;
    ld_next_run_date DATE;
    CURSOR pmnt_list IS
    SELECT CORPINT.TBL_AUTOPAYMENT.*,
                nvl(defined_date, next_date_time) run_date
    FROM CORPINT.TBL_AUTOPAYMENT
    WHERE status = 'sPROC' and
          payment_type = 'SCHEDULED' and
          to_char(job_start_date, 'DD.MM.YYYY HH24:MI:SS') = to_char(pd_start_date, 'DD.MM.YYYY HH24:MI:SS');
          
    res_pmnt pmnt_list%ROWTYPE;
    ls_error VARCHAR2(500);
BEGIN
    log_at('payments_processing', 1, to_char(pd_start_date, 'DD.MM.YYYY HH24:MI:SS'));
    SELECT to_char(pd_start_date,'HH24') || ':' || to_char(pd_start_date,'MI')
    INTO ls_start_time
    FROM dual;
    log_at('payments_processing', 2, ls_start_time); 
    UPDATE CORPINT.TBL_AUTOPAYMENT
    SET job_start_date = pd_start_date,
           status = 'sPROC'
    WHERE status = 'sENAB' and
          payment_type = 'SCHEDULED' and
          ((next_date_time is null and
            defined_date = trunc(pd_start_date)) or
            next_date_time = trunc(pd_start_date)) and
          ls_start_time > execution_time and
          job_start_date is null;
    log_at('payments_processing', 3, ls_start_time);
    COMMIT;
    OPEN pmnt_list;
    
    LOOP
       FETCH pmnt_list INTO res_pmnt;
       EXIT WHEN pmnt_list%NOTFOUND; 
       
       PKG_LOG.addAutopaymentLog('SCHEDULED MAKE', res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd,
                                  res_pmnt.payment_type, res_pmnt.status, res_pmnt.payment_details, res_pmnt.defined_date, res_pmnt.execution_time,  res_pmnt.period,
                                  res_pmnt.created_by, res_pmnt.created_date, res_pmnt.approved_by, res_pmnt.approved_date, res_pmnt.seq_id, res_pmnt.next_date_time, res_pmnt.account_no, 
                                  res_pmnt.prev_date, res_pmnt.prev_ret_code, res_pmnt.prev_err_details, 'BEFORE MAKING AUTOPAYMENT', '');
        ls_returncode := pkg_autopayment.makeAutopayment(res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd, res_pmnt.payment_details, '', '', ls_error);
        log_at('payments_processing', 4, res_pmnt.person_id || ' ' || res_pmnt.tran_cd || ' ' || ls_returncode);
        ls_status := 'sENAB';
        ld_run_date := res_pmnt.run_date;
        IF res_pmnt.period = 'Once' THEN
            ls_status := 'sDISAB';
            ld_next_run_date := res_pmnt.run_date;
        ELSIF res_pmnt.period = 'Daily' THEN
            ld_next_run_date := ld_run_date + 1;
        ELSIF res_pmnt.period = 'Weekly' THEN
            ld_next_run_date := ld_run_date + 7;
        ELSIF res_pmnt.period = 'Monthly' THEN
            ld_next_run_date := add_months(ld_run_date, 1);
        END IF;
        UPDATE CORPINT.TBL_AUTOPAYMENT
        SET status = ls_status,
              job_start_date = null,
              defined_date = null,
              next_date_time = ld_next_run_date,
              prev_date = pd_start_date,
              prev_ret_code = ls_returncode
        WHERE seq_id = res_pmnt.seq_id;
       PKG_LOG.addAutopaymentLog('SCHEDULED MAKE', res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, 
                                  res_pmnt.channel_cd, res_pmnt.payment_type, res_pmnt.status, res_pmnt.payment_details, null, res_pmnt.execution_time, res_pmnt.period, 
                                  res_pmnt.created_by,  res_pmnt.created_date, res_pmnt.approved_by, res_pmnt.approved_date, res_pmnt.seq_id, ld_next_run_date, res_pmnt.account_no, 
                                  res_pmnt.prev_date, res_pmnt.prev_ret_code, res_pmnt.prev_err_details, 'AFTER MAKING AUTOPAYMENT');
       COMMIT;
    END LOOP;
    CLOSE pmnt_list;
    log_at('payments_processing', 5, ls_start_time);
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.processAutopayments', pd_start_date, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
END;

/******************************************************************************
   Name       : PROCEDURE processTrigAutopayments
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : process triggered automatic payments
******************************************************************************/   
PROCEDURE processTrigAutopayments(pd_start_date DATE) IS
    ls_returncode VARCHAR2(3) := '000';
    CURSOR pmnt_list IS
        SELECT a.*,
                    l.tx_no,
                    s.dv_tutar,
                    s.doviz_kod
        FROM cbs_satir s, cbs_tran_autopmnt_list l, corpint.tbl_autopayment a
        WHERE l.status = 'sPROC' and
                    l.execution_date = pd_start_date  and
                    l.tx_no = s.fis_islem_numara and
                    s.tur = 'A' and
                    s.hesap_tur_kodu = 'VS' and
                    a.account_no = s.hesap_numara and
                    a.payment_type = 'TRIGGERED'
        ORDER BY SEQ_ID;
          
    res_pmnt pmnt_list%ROWTYPE;
    ls_error VARCHAR2(500);
    ln_tx_no NUMBER;
    ls_trigger_list VARCHAR2(500);
BEGIN
    log_at('trig_payments_processing', 1, to_char(pd_start_date, 'DD.MM.YYYY HH24:MI:SS'));
    pkg_parametre.deger('TRIGGER_TRAN_LIST', ls_trigger_list); 
          
    UPDATE CBS_TRAN_AUTOPMNT_LIST
    SET execution_date = pd_start_date
    WHERE status = 'sWAIT';
    
    UPDATE CBS_TRAN_AUTOPMNT_LIST
    SET status = 'sPROC'
    WHERE execution_date = pd_start_date and
                exists (select hesap_numara 
                          from cbs_satir
                          where fis_islem_numara = tx_no and
                                    tur = 'A' and
                                    hesap_numara in (select account_no
                                                                from corpint.tbl_autopayment
                                                                where payment_type = 'TRIGGERED' and
                                                                          INSTR(ls_trigger_list, to_char(tran_code)) <> 0));
    log_at('trig_payments_processing', 2, ls_returncode);                 
   
    OPEN pmnt_list;
    FETCH pmnt_list INTO res_pmnt;
    WHILE pmnt_list%FOUND
    LOOP
       PKG_LOG.addAutopaymentLog('TRIGGERED MAKE', res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd,
                                   res_pmnt.payment_type, res_pmnt.status, res_pmnt.payment_details, res_pmnt.defined_date, res_pmnt.execution_time, res_pmnt.period,
                                   res_pmnt.created_by, res_pmnt.created_date, res_pmnt.approved_by, res_pmnt.approved_date, res_pmnt.seq_id, res_pmnt.next_date_time, res_pmnt.account_no, 
                                  res_pmnt.prev_date, res_pmnt.prev_ret_code, res_pmnt.prev_err_details, 'BEFORE MAKING AUTOPAYMENT');    
        ls_returncode := pkg_autopayment.makeAutopayment(res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd, res_pmnt.payment_details, res_pmnt.dv_tutar, res_pmnt.doviz_kod, ls_error);
        log_at('trig_payments_processing', 3, res_pmnt.seq_id || ' ' || res_pmnt.person_id || ' ' || res_pmnt.tran_cd || ' ' || ls_returncode);    
        UPDATE CORPINT.TBL_AUTOPAYMENT
        SET prev_date = sysdate,
              prev_ret_code = ls_returncode,
              prev_err_details = ls_error
        WHERE seq_id = res_pmnt.seq_id;
       PKG_LOG.addAutopaymentLog('TRIGGERED MAKE', res_pmnt.payment_name, res_pmnt.person_id, res_pmnt.customer_id, res_pmnt.tran_code, res_pmnt.tran_cd, res_pmnt.channel_cd,
                                   res_pmnt.payment_type, res_pmnt.status, res_pmnt.payment_details, res_pmnt.defined_date, res_pmnt.execution_time, res_pmnt.period,
                                   res_pmnt.created_by, res_pmnt.created_date, res_pmnt.approved_by, res_pmnt.approved_date, res_pmnt.seq_id, res_pmnt.next_date_time, res_pmnt.account_no, 
                                  sysdate, ls_returncode, ls_error, 'AFTER MAKING AUTOPAYMENT');
        UPDATE CBS_TRAN_AUTOPMNT_LIST
        SET status = 'sDONE'
        WHERE execution_date = pd_start_date and 
                    tx_no = res_pmnt.tx_no and
                    (status = 'sPROC' or status = 'sWAIT');
        COMMIT;
        FETCH pmnt_list INTO res_pmnt;
    END LOOP;
    CLOSE pmnt_list;
    log_at('trig_payments_processing', 4, ls_returncode);

    UPDATE CBS_TRAN_AUTOPMNT_LIST
    SET status = 'sSKIP'
    WHERE  execution_date = pd_start_date and
                 status = 'sWAIT';

    log_at('trig_payments_processing', 5, ls_returncode);
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.processTrigAutopayments', pd_start_date, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ln_tx_no :=  res_pmnt.tx_no;
    CLOSE pmnt_list;
    ROLLBACK;
    UPDATE CBS_TRAN_AUTOPMNT_LIST
    SET status = 'sERROR'
    WHERE tx_no = ln_tx_no;
    COMMIT;    
END;

/******************************************************************************
   Name       : FUNCTION getWaitPmnts
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get waiting automatic payments
******************************************************************************/   
FUNCTION getWaitPmnts(ps_option IN VARCHAR2,
                                     ps_seq_id IN VARCHAR2,
                                     ps_channel_cd IN VARCHAR2,
                                     ps_customer_id IN VARCHAR2,
                                     ps_person_id IN VARCHAR2,
                                     pc_ref   OUT   CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3) := '000';
    pc_ref2 CursorReferenceType;
    ls_user_name VARCHAR2(300);
BEGIN
    log_at('test_getwaitpmnts', 0, ps_option);
    IF ps_option = 'sWAIT' or ps_option = 'sDELETE' or ps_option = 'ALL' or ps_option is null THEN
        IF ps_option = 'sDELETE' THEN
            ls_returncode := corpint.pkg_customer.GetPersonName2(ps_person_id, pc_ref2);
            
            LOOP
                fetch pc_ref2 into ls_user_name;
                exit when pc_ref2%notfound;
            END LOOP;
            CLOSE pc_ref2;      
            log_at('test_getwaitpmnts', 1, ps_option);
            ls_returncode := declinePmntToDo(ps_seq_id, ps_customer_id, ps_person_id, ps_channel_cd, SUBSTR(ls_user_name, 1, 100), pc_ref);
            log_at('test_getwaitpmnts', 1, ls_returncode);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
        END IF;
        log_at('test_getwaitpmnts', 1, ps_option);
        OPEN pc_ref FOR
          SELECT seq_id,
                      tran_code,
                      tran_cd,
                      to_char(upd_info),
                      to_char(created_date, 'dd.mm.yyyy'),
                      status
          FROM corpint.tbl_autopayment
          WHERE customer_id = ps_customer_id and
                      channel_cd = ps_channel_cd and
                      (status = 'sNEW' or status = 'sENAB' or status = 'sDISAB') and 
                      upd_info is not null
          ORDER BY seq_id;
    ELSIF ps_option = 'sLIST' THEN
        log_at('test_getwaitpmnts', 2, ps_option, ps_seq_id);
        OPEN pc_ref FOR
          SELECT seq_id,
                      tran_code,
                      tran_cd,
                      to_char(upd_info),
                      to_char(created_date, 'dd.mm.yyyy'),
                      status
          FROM corpint.tbl_autopayment
          WHERE customer_id = ps_customer_id and
                      channel_cd = ps_channel_cd and
                      (status = 'sNEW' or status = 'sENAB' or status = 'sDISAB') and
                      INSTR(ps_seq_id, to_char(seq_id)) <> 0
          ORDER BY seq_id;
    ELSIF ps_option = 'sAPPROVE' THEN
        log_at('test_getwaitpmnts', 3, ps_option, ps_seq_id);
        OPEN pc_ref FOR
          SELECT seq_id,
                      payment_name,
                      tran_code,
                      tran_cd,
                      payment_type,
                      status, 
                      to_char(payment_details),
                      to_char(nvl(defined_date, next_date_time), 'dd.mm.yyyy') run_date,
                      execution_time,
                      period,
                      created_by,
                      to_char(created_date, 'DD.MM.YYYY HH24:MI:SS'),
                      approved_by,
                      to_char(approved_date, 'DD.MM.YYYY HH24:MI:SS'),
                      account_no
          FROM corpint.tbl_autopayment
          WHERE customer_id = ps_customer_id and
                      channel_cd = ps_channel_cd and
                      (status = 'sNEW' or status = 'sENAB' or status = 'sDISAB') and
                      INSTR(ps_seq_id, to_char(seq_id)) <> 0
          ORDER BY seq_id;    
    ELSIF ps_option = 'sDELETED' THEN
        log_at('test_getwaitpmnts', 4, ps_option, ps_seq_id);
        OPEN pc_ref FOR
          SELECT seq_id,
                      payment_name,
                      tran_code,
                      tran_cd,
                      payment_type,
                      status, 
                      to_char(payment_details),
                      to_char(nvl(defined_date, next_date_time), 'dd.mm.yyyy') run_date,
                      execution_time,
                      period,
                      created_by,
                      to_char(created_date, 'DD.MM.YYYY HH24:MI:SS'),
                      approved_by,
                      to_char(approved_date, 'DD.MM.YYYY HH24:MI:SS'),
                      account_no
          FROM corpint.tbl_autopayment
          WHERE customer_id = ps_customer_id and
                      channel_cd = ps_channel_cd and
                      (status = 'sDLTED' or status = 'sENAB' or status = 'sDISAB') and
                      INSTR(ps_seq_id, to_char(seq_id)) <> 0
          ORDER BY seq_id; 
    END IF;
    log_at('test_getwaitpmnts', 5, ps_option);
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    LOG_AT('pkg_autopayment.getWaitPmnts', ps_option || ' ' || ps_customer_id || ' '  || ps_seq_id, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/******************************************************************************
   Name       : FUNCTION parseDetails
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : parse clob containing payment details
******************************************************************************/   
FUNCTION parseDetails(ps_details CLOB,
                                    pn_order NUMBER) RETURN VARCHAR2 IS
    ls_result VARCHAR2(500) := '';
    ls_check VARCHAR2(10) := '"' || pn_order || '":';
    ls_str CLOB;
BEGIN
    IF INSTR(to_char(ps_details), ls_check) > 0 THEN 
        ls_str := SUBSTR(to_char(ps_details), INSTR(to_char(ps_details), ls_check)+LENGTH(ls_check), LENGTH(to_char(ps_details)));
        ls_result := SUBSTR(to_char(ls_str), INSTR(to_char(ls_str), '"', 1)+1, INSTR(to_char(ls_str), '"', 2)-2); 
    END IF;
    return ls_result;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.parseDetails ' || pn_order, SUBSTR(to_char(ps_details), 0, 1990), SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return '';
END;

/******************************************************************************
   Name       : FUNCTION extractClob
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : extract clob containing payment details
******************************************************************************/   
FUNCTION extractClob(ps_details CLOB,
                                   pn_order NUMBER) RETURN VARCHAR2 IS
    ls_result VARCHAR2(2000) := '';
    ls_check VARCHAR2(10) := '"' || pn_order || '":';
    ls_str CLOB;
BEGIN
    IF INSTR(to_char(ps_details), ls_check) > 0 THEN 
        ls_str := SUBSTR(to_char(ps_details), INSTR(to_char(ps_details), ls_check)+LENGTH(ls_check), LENGTH(to_char(ps_details)));
        log_at('extract_clob', 0, ls_str);
        ls_result := SUBSTR(to_char(ls_str), INSTR(to_char(ls_str), '"{', 1)+1, INSTR(to_char(ls_str), '}"', 2)-1); 
        log_at('extract_clob', 1, ls_result);
        ls_result := regexp_replace(ls_result, '\\"', '"', 1, 0);
    END IF;
    return ls_result;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.extractClob' || pn_order, SUBSTR(to_char(ps_details), 0, 1990), SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return '';
END;

/******************************************************************************
   Name       : FUNCTION getExchangeRatesIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange rates for IB transactions
******************************************************************************/   
FUNCTION getExchangeRatesIB(pd_date IN DATE,
                                                pn_option IN NUMBER,
                                                ps_result OUT VARCHAR2) RETURN VARCHAR2 IS
    pc_ref cursorreferencetype;   
    ls_returncode VARCHAR2(3) := '000';
    str1 varchar2(15);
    str2 varchar2(15);
    str3 varchar2(15);
    str4 varchar2(15);
    str5 varchar2(15);
    str6 varchar2(50);
    str7 varchar2(15);
    str_usd varchar2(10);
    str_eur varchar2(10);
    str_kzt varchar2(10);
    str_rub varchar2(10);
BEGIN
    ls_returncode := cbs.pkg_int_currency.GetExchangeRates(pd_date, pc_ref);
    IF ls_returncode <> '000' THEN
        return ls_returncode;
    END IF;
    
    LOOP
        fetch pc_ref into str1, str2, str3, str4, str5, str6, str7;
        exit when pc_ref%notfound;
        IF str1 = 'USD' THEN
            str_usd := str2;
        ELSIF str1 = 'EUR' THEN
            str_eur := str2;
        ELSIF str1 = 'KZT' AND pn_option = 3 THEN  
            str_kzt := str2;
        ELSIF str1 = 'RUB' AND pn_option = 4 THEN  
            str_rub := str2;
        END IF;
    END LOOP;
    CLOSE pc_ref;    
    IF pn_option = 2 THEN
        ps_result := str_usd || ';' || str_eur;     
    ELSIF pn_option = 3 THEN
        ps_result := str_usd || ';' || str_eur || ';' || str_kzt;     
    ELSIF pn_option = 4 THEN
        ps_result := str_usd || ';' || str_eur || ';' || str_rub;     
    END IF;
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.getExchangeRatesIB', pd_date || ' ' || pn_option, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/******************************************************************************
   Name       : FUNCTION getExchangeRatioIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange ratios for currencies
******************************************************************************/   
FUNCTION getExchangeRatioIB(pc_ref IN CursorReferenceType,
                                               rate_type IN VARCHAR2,
                                               ps_fc_amount OUT VARCHAR2,
                                               ps_total_amount OUT VARCHAR2,
                                               ps_rate OUT VARCHAR2) RETURN VARCHAR2 IS
    str1 varchar2(15);
    str2 varchar2(15);
    str3 varchar2(15);
    str4 varchar2(15);
    str5 varchar2(15);
    str6 varchar2(50);
    str7 varchar2(15);
    ls_returncode VARCHAR2(3) := '000';
BEGIN
    LOOP
        fetch pc_ref into str1, str2, str3, str4, str5, str6, str7;
        exit when pc_ref%notfound;    
        ps_total_amount := str5;
        ps_fc_amount := str6;
        IF rate_type = 'A' THEN
            ps_rate := str4;
        ELSE
            ps_rate := str3;
        END IF;
        
    END LOOP;
    CLOSE pc_ref;   
    log_at('exchange_ratio', '0: ' || str1 || ' 1: ' || str2 || ' 2: ' || str3 || ' 3: ' || str4 || ' 4: ' || str5 || ' 5: ' || str6 || ' 6: ' || str7);
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.getExchangeRatioIB', ps_total_amount || ' ' || ps_rate, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/******************************************************************************
   Name       : FUNCTION getExchangeParityIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange parity for currencies
******************************************************************************/   
FUNCTION getExchangeParityIB(pc_ref IN CursorReferenceType,
                                                pc_ref2 IN CursorReferenceType,
                                                ps_amount_currency IN VARCHAR2,
                                                ps_parity OUT VARCHAR2,
                                                ps_from_amount OUT VARCHAR2,
                                                ps_to_amount OUT VARCHAR2) RETURN VARCHAR2 IS         
    str1 varchar2(15);
    str2 varchar2(15);
    ls_returncode VARCHAR2(3) := '000';
BEGIN
    LOOP
        fetch pc_ref into str1;
        exit when pc_ref%notfound;    
        ps_parity := str1;
    END LOOP;
    CLOSE pc_ref;   
    
    LOOP
        fetch pc_ref2 into str1, str2;
        exit when pc_ref2%notfound;    
        IF ps_amount_currency = 'LC' THEN
            ps_from_amount := str1;
            ps_to_amount := str2;
        ELSE
            ps_from_amount := str2;
            ps_to_amount := str1;            
        END IF;

    END LOOP;
    CLOSE pc_ref2;   
        
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.getExchangeParityIB', ps_parity || ' ' || ps_from_amount || ' ' || ps_to_amount, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/******************************************************************************
   Name       : FUNCTION getCommissionIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get commission amounts for IB transactions
******************************************************************************/   
FUNCTION getCommissionIB(ps_TranCd     IN VARCHAR2,
                                           pn_FromAccNo  IN VARCHAR2,
                                           pn_ToAccNo    IN VARCHAR2,
                                           pn_Amount     IN VARCHAR2,
                                           ps_CurrCd     IN VARCHAR2,
                                           ps_ChannelCd IN VARCHAR2,
                                           ps_amountComm OUT VARCHAR2,
                                           ps_taxComm OUT VARCHAR2) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3) := '000';
    pc_ref cursorreferencetype;   
    str1 varchar2(15);
    str2 varchar2(15);
    str3 varchar2(15);
    str4 varchar2(15);
    str5 varchar2(15);
    str6 varchar2(15);
    str7 varchar2(15);
    str8 varchar2(15);
    str9 varchar2(15);
BEGIN
    IF ps_ChannelCd = 'cDKBRIB' THEN
        ls_returncode := cbs.pkg_soa_inquiry.GetCommission(ps_TranCd, 
                                                                                        pn_FromAccNo,
                                                                                        pn_ToAccNo,
                                                                                        pn_Amount,
                                                                                        ps_CurrCd,
                                                                                        pc_ref);
        IF ls_returncode <> '000' THEN
            return ls_returncode;
        END IF;

        LOOP
            fetch pc_ref into str1, str2, str3, str4, str5, str6, str7, str8, str9;
            exit when pc_ref%notfound;
            ps_amountComm := str1;
            ps_taxComm := str3;
        END LOOP;
        CLOSE pc_ref;   
    ELSE
        ls_returncode := cbs.pkg_int.GetCommission(ps_TranCd, 
                                                                            pn_FromAccNo,
                                                                            pn_ToAccNo,
                                                                            pn_Amount,
                                                                            ps_CurrCd,
                                                                            pc_ref);
        IF ls_returncode <> '000' THEN
            return ls_returncode;
        END IF;     
        
        LOOP
            fetch pc_ref into str1, str2, str3;
            exit when pc_ref%notfound;
            ps_amountComm := str1;
            ps_taxComm := str3;
        END LOOP;
        CLOSE pc_ref;      
    END IF;
    
    return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.getCommissionIB', ps_TranCd || ' ' || pn_FromAccNo || ' ' || pn_ToAccNo || ' ' || pn_Amount || ' ' || ps_CurrCd, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/******************************************************************************
   Name       : FUNCTION getMaturityDate
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get maturity date for clearing and swift
******************************************************************************/   
FUNCTION getMaturityDate(ps_tran_date IN VARCHAR2,
                                          ps_tran_cd IN VARCHAR2,
                                          ps_type IN VARCHAR2,
                                          ps_maturity_date OUT VARCHAR2) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3) := '000';
    ls_tran_date VARCHAR2(50);
    pc_ref cursorreferencetype;   
    str1 varchar2(50);
    str2 varchar2(50);
    str3 varchar2(50);
    str4 varchar2(50);
    str5 varchar2(50);
    str6 varchar2(50);     
    clearing_str varchar2(50);     
    swift_str1 varchar2(50);
    swift_str2 varchar2(50);                                    
BEGIN
        IF to_date(ps_tran_date, 'YYYYMMDD') <= trunc(sysdate) THEN
            ls_tran_date := to_char(trunc(sysdate), 'YYYYMMDD');
        ELSE
            ls_tran_date := ps_tran_date;
        END IF;
        ls_returncode := cbs.pkg_soa_inquiry.GetEFTDate(ls_tran_date, 
                                                                                    ps_tran_cd,
                                                                                    pc_ref);
        IF ls_returncode <> '000' THEN
            return ls_returncode;
        END IF;

        LOOP
            fetch pc_ref into str1, str2, str3, str4, str5;
            exit when pc_ref%notfound;
            clearing_str := str1;
            swift_str1 := str3;
            swift_str2 := str4;
        END LOOP;
        CLOSE pc_ref;       
        log_at('autopayment_maturity', clearing_str || ' ' || swift_str1, ps_type || ' ' || swift_str2);
        IF ps_type = 'NORMAL' THEN
            ps_maturity_date := swift_str1;
        ELSIF ps_type = 'URGENT' THEN
            ps_maturity_date := swift_str2;
        ELSE
            ps_maturity_date := clearing_str;
        END IF;
        log_at('autopayment_maturity', ps_tran_date || ' ' || ps_tran_cd, ps_type || ' ' || ps_maturity_date);
        return ls_returncode;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.getMaturityDate', ps_tran_date || ' ' || ps_tran_cd || ' ' || ps_type, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;                                          

/*FUNCTION getTimeLimit(ps_start_time VARCHAR2) RETURN VARCHAR2 IS
    ls_time_limit VACHAR2(10);
    ln_hour NUMBER;
    ln_minute NUMBER;
BEGIN
    ls_time_limit := trim(ps_start_time);
    ls_hour := SUBSTR(ls_time_limit, 1, INSTR(ls_time_limit, ':')-1);
    ls_minute := SUBSTR(ls_time_limit, INSTR(ls_time_limit, ':')+1, LENGTH(ls_time_limit));
    
    return ls_time_limit;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_autopayment.getTimeLimit', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;
*/



END;
/

