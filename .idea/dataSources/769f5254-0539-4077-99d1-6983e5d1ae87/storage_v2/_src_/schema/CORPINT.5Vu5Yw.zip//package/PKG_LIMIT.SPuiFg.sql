create PACKAGE         "PKG_LIMIT" IS

TYPE CursorReferenceType IS REF CURSOR;
-----------------------------------------------------------------------------------
FUNCTION GetLimitInfo(pn_musteri_no IN VARCHAR2,
                         pn_personid IN VARCHAR2,
                         ps_trancd IN VARCHAR2,
                         ps_channel IN VARCHAR2,
                           ps_rates        IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION CheckLimit(pn_musteri_no IN VARCHAR2,
                         ps_trancd IN VARCHAR2,
                         pn_amount IN VARCHAR2,
                        pn_personid IN VARCHAR2,
                        ps_channel IN VARCHAR2,
                           ps_rates        IN VARCHAR2,
                           ps_cycode   IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION UpdateLimitNew(pn_musteri_no IN VARCHAR2,
                         ps_trancd IN VARCHAR2,
                         pn_amount IN VARCHAR2,
                           ps_cycode   IN VARCHAR2,
                        pn_personid IN VARCHAR2,
                        ps_channel  IN VARCHAR2,
                           ps_rates    IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION UpdateLimit(pn_musteri_no IN VARCHAR2,
                      ps_trancd IN VARCHAR2,
                      pn_amount IN VARCHAR2,
                     ps_currcode IN VARCHAR2,
                     ps_personid IN VARCHAR2,
                     ps_channel IN VARCHAR2,
                     ps_rates IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION CheckLimitForAdminSite(ps_personid IN VARCHAR2,
                                 pn_cust       IN VARCHAR2,
                                 pn_amount       IN VARCHAR2,
                                 ps_cycode     IN VARCHAR2,
                                ps_rates        IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION CheckSpecLimitForAdminSite(ps_personid IN VARCHAR2,
                                 pn_cust       IN VARCHAR2,
                                 pn_amount       IN VARCHAR2,
                                 ps_cycode     IN VARCHAR2,
                                ps_rates        IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-----------------------------------------------------------------------------------
FUNCTION GetUsedLimit(pn_musteri_no IN NUMBER,
                         pn_personid IN NUMBER,
                         ps_trancd IN VARCHAR2,
                         ps_channel IN VARCHAR2) RETURN NUMBER;
--------------------------------------------------------------------------------
FUNCTION UpdateRetailDefaultLimits(ps_option in varchar2,
                    ps_TRAN_CD in varchar2,
                    ps_DAILY_LIMIT in varchar2,
                    ps_TRAN_LIMIT in varchar2,
                    ps_CURRENCY_CD in varchar2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION UpdateCorpDefaultLimits(ps_option in varchar2,
                    ps_TRAN_CD in varchar2,
                    ps_DAILY_LIMIT in varchar2,
                    ps_TRAN_LIMIT in varchar2,
                    ps_CURRENCY_CD in varchar2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION ApproveDefaultLimits(ps_option in varchar2,
                    ps_CHANNEL_CD in varchar2,
                    ps_TRAN_CD in varchar2,
                    ps_DAILY_LIMIT in varchar2,
                    ps_TRAN_LIMIT in varchar2,
                    ps_CURRENCY_CD in varchar2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------

FUNCTION GetLimitInfoV2(pn_musteri_no IN VARCHAR2,
                         pn_personid IN VARCHAR2,
                         ps_trancd IN VARCHAR2,
                         ps_channel IN VARCHAR2,
                           ps_rates        IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;

END;
/

