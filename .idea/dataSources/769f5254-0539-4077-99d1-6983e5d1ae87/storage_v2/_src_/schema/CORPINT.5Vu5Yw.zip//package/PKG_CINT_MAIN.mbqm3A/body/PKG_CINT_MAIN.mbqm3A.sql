create PACKAGE BODY         "PKG_CINT_MAIN" IS
-----------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  CheckCurrencyControl
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Return User Information and last login date
******************************************************************************/
FUNCTION CheckCurrencyControl(ps_channelcd     IN VARCHAR2,
                              ps_customer_id    IN VARCHAR2,
                              ps_tran IN VARCHAR2,
                              ps_controlstr IN VARCHAR2,
                              ps_currencycd IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    TransactionError EXCEPTION;
    ls_auths VARCHAR2(2000);
    ls_returncode  VARCHAR2(3):='000';
    l_c     VARCHAR2(1) ;
    l_v     VARCHAR2(1) ;
    l_a     VARCHAR2(1) ;
    l_ret   VARCHAR2(10) ;
    l_currencycontrol     VARCHAR2(1):='N';
BEGIN

    IF ps_tran='CLEARING' THEN
       IF SUBSTR(ps_controlstr,1,1)='2' OR SUBSTR(ps_controlstr,3,1)='2' THEN
             l_currencycontrol:='Y';
       END IF;
    ELSIF ps_tran='EXCHNGBUY' THEN
          l_currencycontrol:='N';
    ELSIF ps_tran='B2OBHVL' THEN
       IF SUBSTR(ps_controlstr,1,1)='2' OR SUBSTR(ps_controlstr,3,1)='2' THEN
             l_currencycontrol:='Y';
       END IF;
    END IF;

    IF l_currencycontrol='Y' THEN
          l_ret := 'sCONTROL';
          ls_returncode:='606';
    ELSE
          l_ret := 'sMAKE';
          ls_returncode:='000';
    END IF;

    OPEN pc_ref FOR     SELECT l_ret FROM dual;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '707';
END;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  AddSecurityInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 01.04.08
   Purpose   : Add security info
******************************************************************************/
FUNCTION AddSecurityInfo(pn_PersonId         IN VARCHAR2,
                         ps_IpStatus         IN VARCHAR2,
                         ps_TimeStatus       IN VARCHAR2,
                         ps_Monday           IN VARCHAR2,
                         ps_Tuesday          IN VARCHAR2,
                         ps_Wednesday        IN VARCHAR2,
                         ps_Thursday         IN VARCHAR2,
                         ps_Friday           IN VARCHAR2,
                         ps_Saturday         IN VARCHAR2,
                         ps_Sunday           IN VARCHAR2,
                         pn_Ip_1_1           IN VARCHAR2,
                         pn_Ip_1_2           IN VARCHAR2,
                         pn_Ip_2_1           IN VARCHAR2,
                         pn_Ip_2_2           IN VARCHAR2,
                         pd_StartTime           IN VARCHAR2,
                         pd_EndTime             IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS


    ls_returncode   VARCHAR2(3):='000';
    ln_PersonId NUMBER:=TO_NUMBER(pn_PersonId );
    ln_count NUMBER;


BEGIN

    OPEN pc_ref FOR     SELECT '-' FROM dual;

    SELECT COUNT(*)
    INTO ln_count
    FROM TBL_IBSECURITY
    WHERE PERSON_ID=ln_PersonId;
   /* pkg_log.AddCustomLog('test',ln_PersonId||'-'||pn_Ip_2_1||'-'
               ||pn_Ip_2_2||'-'||ps_IpStatus||'-'||pd_StartTime||'-'||pd_EndTime||'-'||
               ps_TimeStatus, ps_Monday, ps_Tuesday, ps_Wednesday,
               ps_Thursday, ps_Friday, ps_Saturday, ps_Sunday)*/
   IF ln_count=0 THEN

       INSERT INTO TBL_IBSECURITY(PERSON_ID, PERSON_NAME, IP_1_1, IP_1_2, IP_2_1,
                                   IP_2_2, IP_STATUS, START_TIME, END_TIME,
                                   TIME_STATUS, MONDAY, TUESDAY, WEDNESDAY,
                                   THURSDAY, FRIDAY, SATURDAY, SUNDAY, LAST_UPDATE_DATE)
        VALUES(ln_PersonId, pkg_cint_main.GetPersonName(ln_PersonId), pn_Ip_1_1,pn_Ip_1_2, pn_Ip_2_1,
               pn_Ip_2_2, ps_IpStatus, pd_StartTime, pd_EndTime,
               ps_TimeStatus, ps_Monday, ps_Tuesday, ps_Wednesday,
               ps_Thursday, ps_Friday, ps_Saturday, ps_Sunday, SYSDATE);

    ELSE

        UPDATE TBL_IBSECURITY
        SET PERSON_ID=ln_PersonId,
            PERSON_NAME=pkg_cint_main.GetPersonName(ln_PersonId),
            IP_1_1=pn_Ip_1_1,
            IP_1_2=pn_Ip_1_2,
            IP_2_1=pn_Ip_2_1,
            IP_2_2=pn_Ip_2_2,
            IP_STATUS=ps_IpStatus,
            START_TIME=pd_StartTime,
            END_TIME=pd_EndTime,
            TIME_STATUS=ps_TimeStatus,
            MONDAY=ps_Monday,
            TUESDAY=ps_Tuesday,
            WEDNESDAY=ps_Wednesday,
            THURSDAY=ps_Thursday,
            FRIDAY=ps_Friday,
            SATURDAY=ps_Saturday,
            SUNDAY=ps_Sunday,
            LAST_UPDATE_DATE=SYSDATE
         WHERE PERSON_ID=ln_PersonId;
    END IF;


    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         pkg_log.ADDCUSTOMLOG('IBSECURITY',SQLERRM);
         OPEN pc_ref FOR     SELECT '-' FROM dual;
         ls_returncode:='999';
    RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  GetPersonName
   Created By : Muzaffar Khalyknazarov
   Date       : 02.04.08
   Purpose   : Return Person name
******************************************************************************/
FUNCTION GetPersonName(pn_personid IN NUMBER) RETURN VARCHAR2 IS
     ls_customername                   VARCHAR2(200);
BEGIN
     SELECT p.FIRSTNAME
     INTO    ls_customername
     FROM TBL_PERSON p
     WHERE p.PERSON_ID=pn_personid;

     RETURN ls_customername;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN NULL;
END;
-------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  SPLIT
   Created By : Muzaffar Khalyknazarov
   Date       : 15.04.08
   Purpose   : Split
******************************************************************************/
FUNCTION SPLIT(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2 IS
        ln_i                NUMBER:=1;
        ln_itemindx       NUMBER:=0;
        ls_strOut        VARCHAR2(2000);
BEGIN

       LOOP
       EXIT WHEN NOT (ln_i<=LENGTH(ps_str) OR INSTR(ps_str,ps_delimeter,ln_i)>0);
            IF ln_itemindx=pn_valindx THEN
                IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
                   ls_strOut:=SUBSTR(ps_str,ln_i,INSTR(ps_str,ps_delimeter,ln_i)-ln_i);
                ELSE
                   ls_strOut:=SUBSTR(ps_str,ln_i);
                END IF;
               RETURN ls_strOut;
            END IF;
            IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
               ln_i:=INSTR(ps_str,ps_delimeter,ln_i)+LENGTH(ps_delimeter);
            ELSE
                ln_i:=LENGTH(ps_str)+1;
            END IF;
            ln_itemindx:=ln_itemindx+1;

       END LOOP;

       RETURN '';
END;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  IpCheck
   Created By : Muzaffar Khalyknazarov
   Date       : 02.04.08
   Purpose   : Return Person name
******************************************************************************/
FUNCTION IpCheck(ps_ClientIP IN VARCHAR2,
                  ps_Ip_1_1    IN VARCHAR2,
                 ps_Ip_1_2   IN VARCHAR2,
                 ps_Ip_2_1   IN VARCHAR2,
                 ps_Ip_2_2   IN VARCHAR2) RETURN VARCHAR2 IS

    ls_delimeter VARCHAR2(1):='.';
    ls_return VARCHAR2(10):='100';

    ln_ClientIP1 varchar2(20):=lpad(SPLIT(ps_ClientIP,ls_delimeter,0),3,0);
    ln_ClientIP2 varchar2(20):=lpad(SPLIT(ps_ClientIP,ls_delimeter,1),3,0);
    ln_ClientIP3 varchar2(20):=lpad(SPLIT(ps_ClientIP,ls_delimeter,2),3,0);
    ln_ClientIP4 varchar2(20):=lpad(SPLIT(ps_ClientIP,ls_delimeter,3),3,0);
    ln_ClientIP number:=to_number(ln_ClientIP1||ln_ClientIP2||ln_ClientIP3||ln_ClientIP4);

    ln_Ip_1_1_1 varchar2(20):=lpad(SPLIT(ps_Ip_1_1 ,ls_delimeter,0),3,0);
    ln_Ip_1_1_2 varchar2(20):=lpad(SPLIT(ps_Ip_1_1 ,ls_delimeter,1),3,0);
    ln_Ip_1_1_3 varchar2(20):=lpad(SPLIT(ps_Ip_1_1 ,ls_delimeter,2),3,0);
    ln_Ip_1_1_4 varchar2(20):=lpad(SPLIT(ps_Ip_1_1 ,ls_delimeter,3),3,0);
    ln_Ip_1_1 number:=to_number(ln_Ip_1_1_1||ln_Ip_1_1_2||ln_Ip_1_1_3||ln_Ip_1_1_4);

    ln_Ip_1_2_1 varchar2(20):=lpad(SPLIT(ps_Ip_1_2 ,ls_delimeter,0),3,0);
    ln_Ip_1_2_2 varchar2(20):=lpad(SPLIT(ps_Ip_1_2 ,ls_delimeter,1),3,0);
    ln_Ip_1_2_3 varchar2(20):=lpad(SPLIT(ps_Ip_1_2 ,ls_delimeter,2),3,0);
    ln_Ip_1_2_4 varchar2(20):=lpad(SPLIT(ps_Ip_1_2 ,ls_delimeter,3),3,0);
    ln_Ip_1_2 number:=to_number(ln_Ip_1_2_1||ln_Ip_1_2_2||ln_Ip_1_2_3||ln_Ip_1_2_4);

    ln_Ip_2_1_1 varchar2(20):=lpad(SPLIT(ps_Ip_2_1 ,ls_delimeter,0),3,0);
    ln_Ip_2_1_2 varchar2(20):=lpad(SPLIT(ps_Ip_2_1 ,ls_delimeter,1),3,0);
    ln_Ip_2_1_3 varchar2(20):=lpad(SPLIT(ps_Ip_2_1 ,ls_delimeter,2),3,0);
    ln_Ip_2_1_4 varchar2(20):=lpad(SPLIT(ps_Ip_2_1 ,ls_delimeter,3),3,0);
    ln_Ip_2_1 number:=to_number(ln_Ip_2_1_1||ln_Ip_2_1_2||ln_Ip_2_1_3||ln_Ip_2_1_4);

    ln_Ip_2_2_1 varchar2(20):=lpad(SPLIT(ps_Ip_2_2 ,ls_delimeter,0),3,0);
    ln_Ip_2_2_2 varchar2(20):=lpad(SPLIT(ps_Ip_2_2 ,ls_delimeter,1),3,0);
    ln_Ip_2_2_3 varchar2(20):=lpad(SPLIT(ps_Ip_2_2 ,ls_delimeter,2),3,0);
    ln_Ip_2_2_4 varchar2(20):=lpad(SPLIT(ps_Ip_2_2 ,ls_delimeter,3),3,0);
    ln_Ip_2_2 number:=to_number(ln_Ip_2_2_1||ln_Ip_2_2_2||ln_Ip_2_2_3||ln_Ip_2_2_4);

BEGIN

     IF (ln_ClientIP BETWEEN ln_Ip_1_1 AND ln_Ip_1_2) OR (ln_ClientIP BETWEEN ln_Ip_2_1 AND ln_Ip_2_2) THEN
         ls_return:='000';
     END IF;

     RETURN ls_return;
EXCEPTION
         WHEN OTHERS THEN
               RETURN '999';
END;
-----------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  TimeCheck
   Created By : Muzaffar Khalyknazarov
   Date       : 02.04.08
   Purpose   : Return Person name
******************************************************************************/
FUNCTION TimeCheck(ps_StartTime IN VARCHAR2,
                    ps_EndTime   IN VARCHAR2) RETURN VARCHAR2 IS

    ls_return VARCHAR2(10);

    ls_time varchar2(10):=to_char(sysdate,'hh24mi');
    ls_starttime varchar2(10):=replace(trim(ps_StartTime),':','');
    ls_endtime varchar2(10):=replace(trim(ps_EndTime),':','');
    ls_day varchar2(1):='0';
    ls_day2 varchar2(1):='0';

BEGIN
    ls_starttime := replace(ls_starttime,'-','');
    ls_starttime := replace(ls_starttime,'.','');
    ls_endtime := replace(ls_endtime,'-','');
    ls_endtime := replace(ls_endtime,'.','');
    
    if (to_number(ls_starttime)>to_number(ls_endtime)) then ls_day := '1'; else ls_day := '0'; end if;
    if (to_number(ls_starttime)>to_number(ls_time)) then ls_day2 := '1'; else ls_day2 := '0'; end if;

    ls_time := ls_day2||ls_time;
    ls_starttime := '0'||ls_starttime;
    ls_endtime := ls_day||ls_endtime;

    if (to_number(ls_time) between to_number(ls_starttime) and to_number(ls_endtime)) then ls_return:='000'; else ls_return:='100'; end if;


     RETURN ls_return;
EXCEPTION
         WHEN OTHERS THEN
               RETURN '999';
END;
/******************************************************************************
   NAME       : FUNCTION  SavePersonAgendaEvent
   Created By : Almas Adilbek
   Date       : 23.04.08
   Purpose    : Save Person Agenda Event
******************************************************************************/
FUNCTION SavePersonAgendaEvent(pn_personcd IN VARCHAR2,
                           ps_langCD IN VARCHAR2,
                           pn_eventID IN VARCHAR2,
                           ps_eventType IN VARCHAR2,
                           ps_eventTitle IN VARCHAR2,
                           ps_eventDesc IN VARCHAR2,
                           ps_eventDate IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode VARCHAR2(3):='000';
   ls_newID NUMBER;

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

    IF pn_eventID = 'new' THEN
       --log_at('Almas>');
       ls_newID := corpint.pkg_common.GetSequenceID('my_agenda_sequance');

       INSERT INTO corpint.TBL_AGENDA_PERSON(EVENT_ID, PERSON_ID, STATUS_CD, EVENT_TYPE, TITLE, DESCRIPTION, EVENT_DATE)
                 VALUES(ls_newID,pn_personcd,'sENAB',ps_eventType,ps_eventTitle,ps_eventDesc,TO_DATE(ps_eventDate,'DD-MM-YYYY'));
              OPEN pc_ref FOR SELECT ls_newID FROM dual;
    ELSE
       UPDATE corpint.TBL_AGENDA_PERSON SET EVENT_TYPE = ps_eventType, TITLE = ps_eventTitle, DESCRIPTION = ps_eventDesc, EVENT_DATE = TO_DATE(ps_eventDate,'DD-MM-YYYY')
             WHERE EVENT_ID = pn_eventID
            AND PERSON_ID = pn_personcd;
    END IF;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        ls_returncode:='999';
      --  LOG_AT('SaveAgendaEvent',ls_returncode,sqlerrm);
        RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  DeletePersonAgendaEvent
   Created By : Almas Adilbek
   Date       : 23.04.08
   Purpose    : Delete Person Agenda Event
******************************************************************************/
FUNCTION DeletePersonAgendaEvent(pn_personcd IN VARCHAR2,
                           ps_langCD IN VARCHAR2,
                           pn_eventID IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode VARCHAR2(3):='000';

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

    DELETE FROM corpint.TBL_AGENDA_PERSON
           WHERE EVENT_ID = pn_eventID
             AND PERSON_ID = pn_personcd;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        ls_returncode:='999';
      --  LOG_AT('DeleteAgendaEvent',ls_returncode,sqlerrm);
        RETURN ls_returncode;

END;
/******************************************************************************
   NAME       : FUNCTION  GetAuthStatus
   Created By : Muzaffar Khaltyknazarov
   Date       : 10.06.08
   Purpose    : Get Authority Status
******************************************************************************/
FUNCTION GetAuthStatus(ps_CustomerId    IN VARCHAR2,
                        ps_TranCd IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    TransactionError EXCEPTION;
    ls_returncode  VARCHAR2(3):='000';
    ls_Check       VARCHAR2(1) ;
    ls_Verify      VARCHAR2(1) ;
    ls_Approve     VARCHAR2(1) ;
    ls_Return      VARCHAR2(10) ;
BEGIN

    SELECT CHECK_AUTH, VERIFY_AUTH, APPROVE_AUTH
    INTO ls_Check,ls_Verify,ls_Approve
    FROM TBL_COMPANY_AUTHORITY
    WHERE CUSTOMER_ID = TO_NUMBER(ps_CustomerId)
    AND   TRAN_CD  = ps_TranCd ;

    IF ls_Check = 'Y' THEN
             ls_Return := 'sCHECK';
    ELSIF ls_Verify = 'Y' THEN
          ls_Return := 'sVERIFY';
    ELSIF ls_Approve = 'Y' THEN
         ls_Return := 'sAPPROVE';
    END IF;


 OPEN pc_ref FOR SELECT ls_Return FROM dual;

 RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '707';
END;
-------------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  UpdateWarningModule
   Created By : Almas Nurkhozhayev
   Date       : 20.12.09
   Purpose    : Update Warning Module
******************************************************************************/
FUNCTION UpdateWarningModule(ps_Option IN VARCHAR2,
                             ps_PersonID IN VARCHAR2,
                             ps_SessionID IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    TransactionError EXCEPTION;
    ls_returncode  VARCHAR2(3):='000';
    ln_times       number;
    ln_id          number;
    ls_Verify      VARCHAR2(1) ;
    ls_Approve     VARCHAR2(1) ;
    ls_Return      VARCHAR2(10) ;
BEGIN
    OPEN pc_ref FOR SELECT sysdate FROM dual;

    select times, id into ln_times, ln_id
    from corpint.tbl_warning_modules
    where status_cd='sENAB'
    and channel_cd='cDKBRIB';

    if ps_Option='LATER' then

        update corpint.tbl_warning_module_person
        set TIMES = decode(TIMES,ln_times,TIMES,TIMES+1),
            SESSION_ID=ps_SessionID
        where PERSON_ID = ps_PersonID
        and MODULE_ID = ln_id;

    elsif ps_Option='UPDATE' then

        update corpint.tbl_warning_module_person
        set TIMES = (ln_times+1),
            SESSION_ID=ps_SessionID
        where PERSON_ID = ps_PersonID
        and MODULE_ID = ln_id;

    elsif ps_Option='CONFIRM' then

        update corpint.tbl_warning_module_person
        set TIMES = (ln_times+1),
            SESSION_ID=ps_SessionID
        where PERSON_ID = ps_PersonID
        and MODULE_ID = ln_id;

    end if;

 OPEN pc_ref FOR
    SELECT * from corpint.tbl_warning_modules aa, corpint.tbl_warning_module_person bb
    where AA.ID = BB.MODULE_ID
    and BB.PERSON_ID=ps_PersonID;

 RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
         pkg_log.ADDCUSTOMLOG('UpdateWarningModule',SQLERRM);
    RETURN '999';
END;
-------------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  UpdateEmployee
   Created By : Almas Nurkhozhayev
   Date       : 14.03.11
   Purpose    : Update Employee Position
******************************************************************************/
FUNCTION UpdateEmployee(ps_Option IN VARCHAR2,
                        ps_Id IN VARCHAR2,
                        ps_BranchCD IN VARCHAR2,
                        ps_Name IN VARCHAR2,
                        ps_Position IN VARCHAR2,
                        ps_PersonId IN VARCHAR2,
                        ps_StatusCd IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR SELECT sysdate FROM dual;

    if ps_Option='BRANCHES' then

        OPEN pc_ref FOR
            SELECT KODU, ADI
            FROM CBS_BOLUM
            WHERE INSTR(KODU, '0', 1) > 0
            ORDER BY KODU;

    elsif ps_Option='LIST' then

        OPEN pc_ref FOR
            SELECT ID, BRANCH_CODE, NAME_SURNAME, POSITION, CREATED_PERSON, CREATED_AT, STATUS_CD
            FROM TBL_EMBASSY_LETTER_EMPLOYEES
            WHERE STATUS_CD = NVL(ps_StatusCd, STATUS_CD);

    elsif ps_Option='BANK_DATE' then

        OPEN pc_ref FOR
            SELECT CBS.PKG_MUHASEBE.BANKA_TARIHI_BUL, TO_CHAR(SYSDATE,'DD.MM.YYYY') FROM DUAL;

    elsif ps_Option='UPDATE' then

        UPDATE TBL_EMBASSY_LETTER_EMPLOYEES
        SET BRANCH_CODE = ps_BranchCD,
            NAME_SURNAME = ps_Name,
            POSITION = ps_Position
        WHERE ID = ps_Id;

    elsif ps_Option='NEW' then

        INSERT INTO TBL_EMBASSY_LETTER_EMPLOYEES
        (ID, BRANCH_CODE, NAME_SURNAME, POSITION, CREATED_PERSON, STATUS_CD)
        VALUES
        (pkg_common.GetSequenceID('EMPLOYEE_ID'), ps_BranchCD, ps_Name, ps_Position, ps_PersonId, 'sENAB');

    elsif ps_Option='DELETE' then

        UPDATE TBL_EMBASSY_LETTER_EMPLOYEES
        SET STATUS_CD = 'sDELETE'
        WHERE ID = ps_Id;

    elsif ps_Option='ACTIVATE_STATUS' then

        UPDATE TBL_EMBASSY_LETTER_EMPLOYEES
        SET STATUS_CD = 'sENAB'
        WHERE ID = ps_Id;

    end if;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
         pkg_log.ADDCUSTOMLOG('UpdateEmployee',SQLERRM);
    RETURN '999';
END;
-------------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION UpdateEmbassyLetter
   Created By : Almas Nurkhozhayev
   Date       : 15.03.11
   Purpose    : Update Embassy Letter
******************************************************************************/
FUNCTION UpdateEmbassyLetter(ps_Option IN VARCHAR2,
                             ps_Id IN VARCHAR2,
                             ps_document_no IN VARCHAR2,
                             ps_lang_cd IN VARCHAR2,
                             ps_name_of_embassy IN VARCHAR2,
                             ps_place_of_embassy IN VARCHAR2,
                             ps_customer_no IN VARCHAR2,
                             ps_customer_name IN VARCHAR2,
                             ps_passport_no IN VARCHAR2,
                             ps_issued_by IN VARCHAR2,
                             ps_issued_date IN VARCHAR2,
                             ps_int_passport_no IN VARCHAR2,
                             ps_int_issued_by IN VARCHAR2,
                             ps_int_issued_date IN VARCHAR2,
                             ps_signatures_of IN VARCHAR2,
                             ps_demand_dep_acc_no IN VARCHAR2,
                             ps_time_dep_acc_no IN VARCHAR2,
                             ps_total_amount_in IN VARCHAR2,
                             ps_PersonId IN VARCHAR2,
                             ps_subject IN VARCHAR2,
                             ps_balance_date IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2(3):='000';
    pc_ref2 CursorReferenceType;
    ls_dd_accounts VARCHAR2(2000):='';
    ls_td_accounts VARCHAR2(2000):='';
    ls_dd_amounts_curr VARCHAR2(2000):='';
    ls_dd_amounts_word_curr VARCHAR2(2000):='';
    ls_td_amounts_curr VARCHAR2(2000):='';
    ls_td_amounts_word_curr VARCHAR2(2000):='';

    amount varchar2(100):='';
    accounts varchar2(100):='';
    curr varchar2(10):='';
    curr2 varchar2(10):='';
    total_amount_in varchar2(100):='';
    i number := 1;
    j number := 1;
    total_amount number:=0;
    ln_count number:=0;

    ls_total_amounts_curr VARCHAR2(2000):='';
    ls_total_amounts_word_curr VARCHAR2(2000):='';
    ls_amount_mask VARCHAR2(20):='9999999999999999.99';
    ls_branch_names VARCHAR2(500):='';
    ls_lang_cd VARCHAR2(3):='ENG';

    ln_buy_rate number;
    ln_sell_rate number;

    ld_start_date date;
    ld_end_date date;
    ld_balance_date date:=to_date(ps_balance_date,'YYYYMMDD');

    ln_id number := 0;
    ls_decimal_delimeter VARCHAR2(10):='.';
    ls_user_name VARCHAR2(50):='';
    ls_word_amount VARCHAR2(2000):='';
BEGIN
    OPEN pc_ref FOR SELECT sysdate FROM dual;

    if ps_Option='LIST' then
        ld_start_date := sysdate;

        if (ps_Id is not null) then
            SELECT DEMAND_DEP_ACC_NO, TIME_DEP_ACC_NO, TOTAL_AMOUNT_IN, BALANCE_DATE, nvl(LANG_CD,'ENG')
            INTO   ls_dd_accounts, ls_td_accounts, total_amount_in, ld_balance_date, ls_lang_cd
            FROM TBL_EMBASSY_LETTER_INFO
            WHERE ID = NVL(ps_Id, ID);

            IF (ls_dd_accounts is not null) THEN
                -- DEMAD DEPOSIT ACCOUNT TO AMOUT AND WORD
                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_dd_accounts,'#',i) is not null loop
                    accounts := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_accounts,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_accounts,'#',i),';',1);

                    ls_branch_names := ls_branch_names || pkg_hesap.HesaptanSubeAl(accounts) || '#';
                    ls_dd_amounts_curr := ls_dd_amounts_curr || '#' || Pkg_Hesap.OncekiGunBakiyeAl(accounts, to_number(to_char(ld_balance_date+1,'YYYY')), to_number(to_char(ld_balance_date+1,'MM')), to_number(to_char(ld_balance_date+1,'DD')) ) || ';' || curr;

                    i:=i+1;
                end loop;

                if (instr(ls_dd_amounts_curr,'.',1,1)>0) then
                    ls_decimal_delimeter := '.';
                elsif (instr(ls_dd_amounts_curr,',',1,1)>0) then
                    ls_decimal_delimeter := ',';
                end if;

                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i) is not null loop
                    amount := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',1);

                    if (ls_lang_cd='RUS') then
                        ls_word_amount:= PKG_REPORT.Number_To_Word_Rus(nvl(substr(amount,1,instr(amount,ls_decimal_delimeter,1,1)-1),0), curr);
                        for ln_id in TRUNC(length(PKG_REPORT.Number_To_Word_Rus(amount, curr))/2)..length(PKG_REPORT.Number_To_Word_Rus(amount, curr)) loop

                            if (instr('0123456789',substr(PKG_REPORT.Number_To_Word_Rus(amount, curr),ln_id,1),1,1)>0) then
                                ls_word_amount := substr(PKG_REPORT.Number_To_Word_Rus(amount, curr),1,ln_id-1);
                                exit;
                            end if;

                        end loop;
                    else
                        ls_word_amount:= PKG_REPORT.Number_To_Word_Eng(nvl(substr(amount,1,instr(amount,ls_decimal_delimeter,1,1)-1),0), curr);
                       for ln_id in TRUNC(length(PKG_REPORT.Number_To_Word_Eng(amount, curr))/2)..length(PKG_REPORT.Number_To_Word_Eng(amount, curr)) loop

                            if (instr('0123456789',substr(PKG_REPORT.Number_To_Word_Eng(amount, curr),ln_id,1),1,1)>0) then
                                ls_word_amount := substr(PKG_REPORT.Number_To_Word_Eng(amount, curr),1,ln_id-1);
                                exit;
                            end if;

                        end loop;
                    end if;

                    ls_dd_amounts_word_curr := ls_dd_amounts_word_curr || '#' || ls_word_amount;

                    if (instr(amount,ls_decimal_delimeter,1,1)>0) and (to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount)))>0) then

                        if (length(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount)))=1) then
                            amount := amount || '0';
                        end if;



                        ls_dd_amounts_word_curr := ls_dd_amounts_word_curr || ' ' ||
                        to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))) ||'/'||
                        power(10,length(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))));
                    else
                        ls_dd_amounts_word_curr := ls_dd_amounts_word_curr || ', 00/100';
                    end if;

                    i:=i+1;
                end loop;
            END IF;

            IF (ls_td_accounts is not null) THEN
                -- TIME DEPOSIT ACCOUNT TO AMOUT AND WORD
                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_td_accounts,'#',i) is not null loop
                    accounts := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_accounts,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_accounts,'#',i),';',1);

                    ls_branch_names := ls_branch_names || pkg_hesap.HesaptanSubeAl(accounts) || '#';

                    ls_td_amounts_curr := ls_td_amounts_curr || '#' || Pkg_Hesap.OncekiGunBakiyeAl(accounts, to_number(to_char(ld_balance_date+1,'YYYY')), to_number(to_char(ld_balance_date+1,'MM')), to_number(to_char(ld_balance_date+1,'DD')) ) || ';' || curr;

                    i:=i+1;
                end loop;

                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_td_amounts_curr,'#',i) is not null loop
                    amount := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_amounts_curr,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_amounts_curr,'#',i),';',1);

                    if (ls_lang_cd='RUS') then
                        ls_word_amount:= PKG_REPORT.Number_To_Word_Rus(nvl(substr(amount,1,instr(amount,ls_decimal_delimeter,1,1)-1),0), curr);
                        for ln_id in TRUNC(length(PKG_REPORT.Number_To_Word_Rus(amount, curr))/2)..length(PKG_REPORT.Number_To_Word_Rus(amount, curr)) loop

                            if (instr('0123456789',substr(PKG_REPORT.Number_To_Word_Rus(amount, curr),ln_id,1),1,1)>0) then
                                ls_word_amount := substr(PKG_REPORT.Number_To_Word_Rus(amount, curr),1,ln_id-1);
                                exit;
                            end if;

                        end loop;
                    else
                        ls_word_amount:= PKG_REPORT.Number_To_Word_Eng(nvl(substr(amount,1,instr(amount,ls_decimal_delimeter,1,1)-1),0), curr);
                       for ln_id in TRUNC(length(PKG_REPORT.Number_To_Word_Eng(amount, curr))/2)..length(PKG_REPORT.Number_To_Word_Eng(amount, curr)) loop

                            if (instr('0123456789',substr(PKG_REPORT.Number_To_Word_Eng(amount, curr),ln_id,1),1,1)>0) then
                                ls_word_amount := substr(PKG_REPORT.Number_To_Word_Eng(amount, curr),1,ln_id-1);
                                exit;
                            end if;

                        end loop;
                    end if;

                    ls_td_amounts_word_curr := ls_td_amounts_word_curr || '#' || ls_word_amount;

                    if (instr(amount,ls_decimal_delimeter,1,1)>0) and (to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount)))>0) then

                        if (length(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount)))=1) then
                            amount := amount || '0';
                        end if;



                        ls_td_amounts_word_curr := ls_td_amounts_word_curr || ' ' ||
                        to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))) ||'/'||
                        power(10,length(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))));
                    else
                        ls_td_amounts_word_curr := ls_td_amounts_word_curr || ', 00/100';
                    end if;

                    i:=i+1;
                end loop;
            END IF;
        end if;

        j:=1;
        while CORPINT.PKG_ADMIN.SPLIT(total_amount_in,'#',j) is not null loop
            curr2 := CORPINT.PKG_ADMIN.SPLIT(total_amount_in,'#',j);

            total_amount := 0;
            i:=1;
            while CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i) is not null loop
                amount := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',0);
                curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',1);

                select count(1) into ln_count
                from CBS_MBKUR
                where TARIH = trunc(ld_balance_date)
                and DVZ = curr;

                if (ln_count>0) then
                    select DVZALIS into ln_buy_rate
                    from CBS_MBKUR
                    where TARIH = trunc(ld_balance_date)
                    and DVZ = curr;

                    select DVZSATIS into ln_sell_rate
                    from CBS_MBKUR
                    where TARIH = trunc(ld_balance_date)
                    and DVZ = curr2;
                else
                    select DVZALIS into ln_buy_rate
                    from CBS_MBKUR
                    where TARIH in (select max(TARIH) from CBS_MBKUR)
                    and DVZ = curr;

                    select DVZSATIS into ln_sell_rate
                    from CBS_MBKUR
                    where TARIH in (select max(TARIH) from CBS_MBKUR)
                    and DVZ = curr2;
                end if;

                if curr <> curr2 then
                    total_amount := total_amount + ( to_number(amount)*ln_buy_rate/ln_sell_rate  );
                else
                    total_amount := total_amount + to_number(amount);
                end if;

                i:=i+1;
            end loop;

            j:=j+1;

            ls_total_amounts_curr := ls_total_amounts_curr || '#' || to_char(total_amount,ls_amount_mask) || ';' || curr2;

            if (ls_lang_cd='RUS') then
                ls_word_amount:= PKG_REPORT.Number_To_Word_Rus(nvl(substr(total_amount,1,instr(total_amount,ls_decimal_delimeter,1,1)-1),0), curr2);
                for ln_id in TRUNC(length(PKG_REPORT.Number_To_Word_Rus(total_amount, curr2))/2)..length(PKG_REPORT.Number_To_Word_Rus(total_amount, curr2)) loop

                    if (instr('0123456789',substr(PKG_REPORT.Number_To_Word_Rus(total_amount, curr2),ln_id,1),1,1)>0) then
                        ls_word_amount := substr(PKG_REPORT.Number_To_Word_Rus(total_amount, curr2),1,ln_id-1);
                        exit;
                    end if;

                end loop;
            else
                ls_word_amount:= PKG_REPORT.Number_To_Word_Eng(nvl(substr(total_amount,1,instr(total_amount,ls_decimal_delimeter,1,1)-1),0), curr2);
               for ln_id in TRUNC(length(PKG_REPORT.Number_To_Word_Eng(total_amount, curr2))/2)..length(PKG_REPORT.Number_To_Word_Eng(total_amount, curr2)) loop

                    if (instr('0123456789',substr(PKG_REPORT.Number_To_Word_Eng(total_amount, curr2),ln_id,1),1,1)>0) then
                        ls_word_amount := substr(PKG_REPORT.Number_To_Word_Eng(total_amount, curr2),1,ln_id-1);
                        exit;
                    end if;

                end loop;
            end if;

            ls_total_amounts_word_curr := ls_total_amounts_word_curr || '#' || ls_word_amount;

            if (instr(ls_total_amounts_curr,'.',1,1)>0) then
                ls_decimal_delimeter := '.';
            elsif (instr(ls_total_amounts_curr,',',1,1)>0) then
                ls_decimal_delimeter := ',';
            end if;


            if (instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)>0) and (to_number(substr(to_char(total_amount,ls_amount_mask),instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)+1,length(to_char(total_amount,ls_amount_mask))))>0) then
                ls_total_amounts_word_curr := ls_total_amounts_word_curr || ' ' ||
                to_number(substr(to_char(total_amount,ls_amount_mask),instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)+1,length(to_char(total_amount,ls_amount_mask)))) ||'/'||
                power(10,length(substr(to_char(total_amount,ls_amount_mask),instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)+1,length(to_char(total_amount,ls_amount_mask)))));
            end if;


        end loop;


        OPEN pc_ref FOR
            SELECT ID, DOCUMENT_NO, LANG_CD, NAME_OF_EMBASSY, CUSTOMER_NO,
                   CUSTOMER_NAME, nvl(PASSPORT_NO,''), nvl(ISSUED_BY,''), to_char(ISSUED_DATE,'YYYYMMDD'), nvl(INT_PASSPORT_NO,''),
                   nvl(INT_ISSUED_BY,''), to_char(INT_ISSUED_DATE,'YYYYMMDD'), SIGNATURES_OF, nvl(DEMAND_DEP_ACC_NO,''), nvl(TIME_DEP_ACC_NO,''),
                   TOTAL_AMOUNT_IN, CREATED_PERSON, CREATED_AT,
                   ls_dd_amounts_curr, ls_dd_amounts_word_curr, ls_td_amounts_curr, ls_td_amounts_word_curr,
                   ls_total_amounts_curr, ls_total_amounts_word_curr,
                   PLACE_OF_EMBASSY, SUBJECT, to_char(BALANCE_DATE,'YYYYMMDD'), ls_branch_names, (select firstname from corpint.tbl_person where person_id=CREATED_PERSON and rownum=1)

            FROM TBL_EMBASSY_LETTER_INFO
            WHERE ID = NVL(ps_Id, ID)
            order by ID desc;

        ld_end_date := sysdate;


    elsif ps_Option='UPDATE' then

        UPDATE TBL_EMBASSY_LETTER_INFO
        SET --DOCUMENT_NO = ps_document_no,
            LANG_CD = ps_lang_cd,
            NAME_OF_EMBASSY = ps_name_of_embassy,
            CUSTOMER_NO = ps_customer_no,
            CUSTOMER_NAME = ps_customer_name,
            PASSPORT_NO = ps_passport_no,
            ISSUED_BY = ps_issued_by,
            ISSUED_DATE = to_date(ps_issued_date,'YYYYMMDD'),
            INT_PASSPORT_NO = ps_int_passport_no,
            INT_ISSUED_BY = ps_int_issued_by,
            INT_ISSUED_DATE = to_date(ps_int_issued_date,'YYYYMMDD'),
            SIGNATURES_OF = ps_signatures_of,
            DEMAND_DEP_ACC_NO = ps_demand_dep_acc_no,
            TIME_DEP_ACC_NO = ps_time_dep_acc_no,
            TOTAL_AMOUNT_IN = ps_total_amount_in,
            PLACE_OF_EMBASSY = ps_place_of_embassy,
            SUBJECT = ps_subject,
            BALANCE_DATE = to_date(ps_balance_date,'YYYYMMDD')
        WHERE ID = ps_Id;

        OPEN pc_ref FOR
            SELECT ID, DOCUMENT_NO, LANG_CD, NAME_OF_EMBASSY, CUSTOMER_NO,
                   CUSTOMER_NAME, nvl(PASSPORT_NO,''), nvl(ISSUED_BY,''), to_char(ISSUED_DATE,'YYYYMMDD'), nvl(INT_PASSPORT_NO,''),
                   nvl(INT_ISSUED_BY,''), to_char(INT_ISSUED_DATE,'YYYYMMDD'), SIGNATURES_OF, nvl(DEMAND_DEP_ACC_NO,''), nvl(TIME_DEP_ACC_NO,''),
                   TOTAL_AMOUNT_IN, CREATED_PERSON, CREATED_AT,
                   ls_dd_amounts_curr, ls_dd_amounts_word_curr, ls_td_amounts_curr, ls_td_amounts_word_curr,
                   ls_total_amounts_curr, ls_total_amounts_word_curr,
                   PLACE_OF_EMBASSY, SUBJECT, to_char(BALANCE_DATE,'YYYYMMDD')
            FROM TBL_EMBASSY_LETTER_INFO
            WHERE ID = ps_Id;

    elsif ps_Option='NEW' then

        ln_id := pkg_common.GetSequenceID('EMBASSY_LETTER_ID');

        INSERT INTO TBL_EMBASSY_LETTER_INFO
        (ID, DOCUMENT_NO, LANG_CD, NAME_OF_EMBASSY, PLACE_OF_EMBASSY, SUBJECT, CUSTOMER_NO, CUSTOMER_NAME, PASSPORT_NO, ISSUED_BY, ISSUED_DATE, INT_PASSPORT_NO, INT_ISSUED_BY, INT_ISSUED_DATE, SIGNATURES_OF, DEMAND_DEP_ACC_NO, TIME_DEP_ACC_NO, TOTAL_AMOUNT_IN, CREATED_PERSON, BALANCE_DATE)
        VALUES
        (ln_id, 100000+pkg_common.GetSequenceID('EMBASSY_DOC_NO'), ps_lang_cd, ps_name_of_embassy, ps_place_of_embassy, ps_subject, ps_customer_no, ps_customer_name, ps_passport_no, ps_issued_by, to_date(ps_issued_date,'YYYYMMDD'), ps_int_passport_no, ps_int_issued_by, to_date(ps_int_issued_date,'YYYYMMDD'), ps_signatures_of, ps_demand_dep_acc_no, ps_time_dep_acc_no, ps_total_amount_in, ps_PersonId, to_date(ps_balance_date,'YYYYMMDD'));

        OPEN pc_ref FOR
            SELECT ID, DOCUMENT_NO, LANG_CD, NAME_OF_EMBASSY, CUSTOMER_NO,
                   CUSTOMER_NAME, nvl(PASSPORT_NO,''), nvl(ISSUED_BY,''), to_char(ISSUED_DATE,'YYYYMMDD'), nvl(INT_PASSPORT_NO,''),
                   nvl(INT_ISSUED_BY,''), to_char(INT_ISSUED_DATE,'YYYYMMDD'), SIGNATURES_OF, nvl(DEMAND_DEP_ACC_NO,''), nvl(TIME_DEP_ACC_NO,''),
                   TOTAL_AMOUNT_IN, CREATED_PERSON, CREATED_AT,
                   ls_dd_amounts_curr, ls_dd_amounts_word_curr, ls_td_amounts_curr, ls_td_amounts_word_curr,
                   ls_total_amounts_curr, ls_total_amounts_word_curr,
                   PLACE_OF_EMBASSY, SUBJECT, to_char(BALANCE_DATE,'YYYYMMDD')
            FROM TBL_EMBASSY_LETTER_INFO
            WHERE ID = ln_id;

    elsif ps_Option='DELETE' then

        DELETE FROM TBL_EMBASSY_LETTER_INFO
        WHERE ID = ps_Id;

    elsif ps_Option='GET_DDACCOUNTS' then

        ls_returncode := cbs.pkg_soa_inquiry.GetAccounts('ALL',ps_customer_no,'0','',pc_ref,pc_ref2,pc_ref2,pc_ref2,pc_ref2);

    elsif ps_Option='GET_TDACCOUNTS' then

        ls_returncode := cbs.pkg_soa_inquiry.GetAccounts('ALL',ps_customer_no,'0','',pc_ref2,pc_ref,pc_ref2,pc_ref2,pc_ref2);

    elsif ps_Option='GET_CUSTOMER_INFO' then

        OPEN pc_ref FOR
            select NVL2(ISIM, ISIM || ' ' || IKINCI_ISIM || ' ' || SOYADI, TICARI_UNVAN) NAME,
            PASAPORT_NO, VERILDIGI_YER, TO_CHAR(VERILDIGI_TARIH,'YYYYMMDD')
            from cbs_musteri
            where musteri_no=ps_customer_no;

    elsif ps_Option='GET_DATE_BALANCE' then
        -- DEMAD DEPOSIT ACCOUNT TO AMOUT AND WORD
        i:=1;
        while CORPINT.PKG_ADMIN.SPLIT(ps_demand_dep_acc_no,'#',i) is not null loop
            accounts := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ps_demand_dep_acc_no,'#',i),';',0);

            select Pkg_Hesap.OncekiGunBakiyeAl(accounts, to_number(to_char(ld_balance_date+1,'YYYY')), to_number(to_char(ld_balance_date+1,'MM')), to_number(to_char(ld_balance_date+1,'DD')) )
            into total_amount
            from dual;

            if total_amount is null then
                return '135'; -- if customer entered wrong calendar date or there is no balance for this date
            end if;

            i:=i+1;
        end loop;

        -- TIME DEPOSIT ACCOUNT TO AMOUT AND WORD
        i:=1;
        while CORPINT.PKG_ADMIN.SPLIT(ps_time_dep_acc_no,'#',i) is not null loop
            accounts := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ps_time_dep_acc_no,'#',i),';',0);

            select Pkg_Hesap.OncekiGunBakiyeAl(accounts, to_number(to_char(ld_balance_date+1,'YYYY')), to_number(to_char(ld_balance_date+1,'MM')), to_number(to_char(ld_balance_date+1,'DD')) )
            into total_amount
            from dual;

            if total_amount is null then
                return '135'; -- if customer entered wrong calendar date or there is no balance for this date
            end if;

            i:=i+1;
        end loop;

        OPEN pc_ref FOR
            select total_amount from dual;

    elsif ps_Option='INQUIRY' then

        ld_start_date := sysdate;

        if (ps_document_no is not null and ps_passport_no is not null) then
            SELECT DEMAND_DEP_ACC_NO, TIME_DEP_ACC_NO, TOTAL_AMOUNT_IN, BALANCE_DATE
            INTO   ls_dd_accounts, ls_td_accounts, total_amount_in, ld_balance_date
            FROM TBL_EMBASSY_LETTER_INFO
            WHERE DOCUMENT_NO = ps_document_no
            AND NVL(PASSPORT_NO,INT_PASSPORT_NO) = ps_passport_no;

            IF (ls_dd_accounts is not null) THEN
                -- DEMAD DEPOSIT ACCOUNT TO AMOUT AND WORD
                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_dd_accounts,'#',i) is not null loop
                    accounts := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_accounts,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_accounts,'#',i),';',1);
                    ls_dd_amounts_curr := ls_dd_amounts_curr || '#' || Pkg_Hesap.OncekiGunBakiyeAl(accounts, to_number(to_char(ld_balance_date+1,'YYYY')), to_number(to_char(ld_balance_date+1,'MM')), to_number(to_char(ld_balance_date+1,'DD')) ) || ';' || curr;
                    i:=i+1;
                end loop;

                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i) is not null loop
                    amount := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',1);
                    ls_dd_amounts_word_curr := ls_dd_amounts_word_curr || '#' || PKG_TUTAR.NUMBER2WORDS(amount, curr, 'ENG');

                    if (instr(amount,ls_decimal_delimeter,1,1)>0) and (to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount)))>0) then
                        ls_dd_amounts_word_curr := ls_dd_amounts_word_curr || ' ' ||
                        to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))) ||'/'||
                        power(10,length(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))));
                    end if;

                    i:=i+1;
                end loop;
            END IF;

            IF (ls_td_accounts is not null) THEN
                -- TIME DEPOSIT ACCOUNT TO AMOUT AND WORD
                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_td_accounts,'#',i) is not null loop
                    accounts := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_accounts,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_accounts,'#',i),';',1);
                    ls_td_amounts_curr := ls_td_amounts_curr || '#' || Pkg_Hesap.OncekiGunBakiyeAl(accounts, to_number(to_char(ld_balance_date+1,'YYYY')), to_number(to_char(ld_balance_date+1,'MM')), to_number(to_char(ld_balance_date+1,'DD')) ) || ';' || curr;
                    i:=i+1;
                end loop;

                i:=1;
                while CORPINT.PKG_ADMIN.SPLIT(ls_td_amounts_curr,'#',i) is not null loop
                    amount := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_amounts_curr,'#',i),';',0);
                    curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_td_amounts_curr,'#',i),';',1);
                    ls_td_amounts_word_curr := ls_td_amounts_word_curr || '#' || PKG_TUTAR.NUMBER2WORDS(amount, curr, 'ENG');

                    if (instr(amount,ls_decimal_delimeter,1,1)>0) and (to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount)))>0) then
                        ls_td_amounts_word_curr := ls_td_amounts_word_curr || ' ' ||
                        to_number(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))) ||'/'||
                        power(10,length(substr(amount,instr(amount,ls_decimal_delimeter,1,1)+1,length(amount))));
                    end if;

                    i:=i+1;
                end loop;
            END IF;
        end if;

        j:=1;
        while CORPINT.PKG_ADMIN.SPLIT(total_amount_in,'#',j) is not null loop
            curr2 := CORPINT.PKG_ADMIN.SPLIT(total_amount_in,'#',j);

            total_amount := 0;
            i:=1;
            while CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i) is not null loop
                amount := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',0);
                curr := CORPINT.PKG_ADMIN.SPLIT(CORPINT.PKG_ADMIN.SPLIT(ls_dd_amounts_curr,'#',i),';',1);

                select DVZALIS into ln_buy_rate
                from CBS_MBKUR
                where TARIH in (select max(TARIH) from CBS_MBKUR)
                and DVZ = curr;

                select DVZSATIS into ln_sell_rate
                from CBS_MBKUR
                where TARIH in (select max(TARIH) from CBS_MBKUR)
                and DVZ = curr2;

                if curr <> curr2 then
                    total_amount := total_amount + ( to_number(amount)*ln_buy_rate/ln_sell_rate  );
                else
                    total_amount := total_amount + to_number(amount);
                end if;

                i:=i+1;
            end loop;

            j:=j+1;

            ls_total_amounts_curr := ls_total_amounts_curr || '#' || to_char(total_amount,ls_amount_mask) || ';' || curr2;

            ls_total_amounts_word_curr := ls_total_amounts_word_curr || '#' || PKG_TUTAR.NUMBER2WORDS(total_amount, curr2, 'ENG');
            if (instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)>0) and (to_number(substr(to_char(total_amount,ls_amount_mask),instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)+1,length(to_char(total_amount,ls_amount_mask))))>0) then
                ls_total_amounts_word_curr := ls_total_amounts_word_curr || ' ' ||
                to_number(substr(to_char(total_amount,ls_amount_mask),instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)+1,length(to_char(total_amount,ls_amount_mask)))) ||'/'||
                power(10,length(substr(to_char(total_amount,ls_amount_mask),instr(to_char(total_amount,ls_amount_mask),ls_decimal_delimeter,1,1)+1,length(to_char(total_amount,ls_amount_mask)))));
            end if;

        end loop;

        OPEN pc_ref FOR
            SELECT ID, DOCUMENT_NO, LANG_CD, NAME_OF_EMBASSY, CUSTOMER_NO,
                   CUSTOMER_NAME, nvl(PASSPORT_NO,''), nvl(ISSUED_BY,''), to_char(ISSUED_DATE,'YYYYMMDD'), nvl(INT_PASSPORT_NO,''),
                   nvl(INT_ISSUED_BY,''), to_char(INT_ISSUED_DATE,'YYYYMMDD'), SIGNATURES_OF, nvl(DEMAND_DEP_ACC_NO,''), nvl(TIME_DEP_ACC_NO,''),
                   TOTAL_AMOUNT_IN, CREATED_PERSON, CREATED_AT,
                   ls_dd_amounts_curr, ls_dd_amounts_word_curr, ls_td_amounts_curr, ls_td_amounts_word_curr,
                   ls_total_amounts_curr, ls_total_amounts_word_curr,
                   PLACE_OF_EMBASSY, SUBJECT, to_char(BALANCE_DATE,'YYYYMMDD')
            FROM TBL_EMBASSY_LETTER_INFO
            WHERE DOCUMENT_NO = ps_document_no
            AND NVL(PASSPORT_NO,INT_PASSPORT_NO) = ps_passport_no;

        ld_end_date := sysdate;

    end if;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
         pkg_log.ADDCUSTOMLOG('UpdateEmbassyLetter',SQLERRM);
    RETURN '999';
END;
-------------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION UpdateMultiLanguageData
   Created By : Almas Nurkhozhayev
   Date       : 15.03.11
   Purpose    : Update Multi Language Data
******************************************************************************/
FUNCTION UpdateMultiLanguageData(ps_Option IN VARCHAR2,
                                 ps_Source IN VARCHAR2,
                                 ps_LangCd IN VARCHAR2,
                                 ps_Desciption IN VARCHAR2,
                                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER := 0;

    DataExistError EXCEPTION;

    ls_lang_cd VARCHAR2(30):='ENG';
    ls_system_cd VARCHAR2(3):='SYS';
    ls_error_cd VARCHAR2(3):='000';

    ls_tran_cd VARCHAR2(15):='';
    ls_page_id VARCHAR2(10):='0';
    ls_label_id VARCHAR2(10):='0';

    ls_channel_cd VARCHAR2(15):='cDKBRIB';

    ls_news_id VARCHAR2(10):='0';

    ls_Subject VARCHAR2(500 CHAR):='';
    ls_Description VARCHAR2(4000 CHAR):='';
    ls_User_Description VARCHAR2(4000 CHAR):='';
BEGIN

    OPEN pc_ref FOR SELECT sysdate FROM dual;

    IF (ps_Source = 'ERRORS') THEN

        ls_lang_cd := SPLIT(ps_LangCd, ';;;', 0);
        ls_system_cd := SPLIT(ps_LangCd, ';;;', 1);
        ls_error_cd := SPLIT(ps_LangCd, ';;;', 2);

        ls_Description := SPLIT(ps_Desciption, ';;;', 0);
        ls_User_Description := SPLIT(ps_Desciption, ';;;', 1);

        if ps_Option='LIST' then

            OPEN pc_ref FOR
                SELECT SYSTEM_CD, ERROR_CD, LANG_CD, ERROR_DESC,
                       USER_DESC, ERROR_TYPE, DLM
                FROM CORPINT.TBL_ERROR
                WHERE INSTR(ls_lang_cd, LANG_CD, 1, 1) > 0
                AND NVL(ls_system_cd,SYSTEM_CD) = SYSTEM_CD
                AND NVL(ls_error_cd,ERROR_CD) = ERROR_CD;

        elsif ps_Option='UPDATE' then

            UPDATE CORPINT.TBL_ERROR
            SET ERROR_DESC = ls_Description,
                USER_DESC = ls_User_Description,
                DLM = SYSDATE
            WHERE LANG_CD=ls_lang_cd
            AND SYSTEM_CD=ls_system_cd
            AND ERROR_CD=ls_error_cd;

        elsif ps_Option='NEW' then

            SELECT COUNT(1) INTO ln_count
            FROM CORPINT.TBL_ERROR
            WHERE LANG_CD=ls_lang_cd
            AND SYSTEM_CD=ls_system_cd
            AND ERROR_CD=ls_error_cd;

            if (ln_count>0) then
                raise DataExistError;
            end if;

            INSERT INTO CORPINT.TBL_ERROR
            (SYSTEM_CD, ERROR_CD, LANG_CD, ERROR_DESC, USER_DESC, ERROR_TYPE, DLM)
            VALUES
            (ls_system_cd, ls_error_cd, ls_lang_cd, ls_Description, ls_User_Description, 'BUS', SYSDATE);

        end if;

    ELSIF (ps_Source = 'LABELS') THEN

        ls_lang_cd := SPLIT(ps_LangCd, ';;;', 0);
        ls_tran_cd := SPLIT(ps_LangCd, ';;;', 1);
        ls_page_id := SPLIT(ps_LangCd, ';;;', 2);
        ls_label_id := SPLIT(ps_LangCd, ';;;', 3);

        ls_Description := SPLIT(ps_Desciption, ';;;', 1);

        if ps_Option='LIST' then

            OPEN pc_ref FOR
                SELECT TRAN_CD, PAGE_ID, LABEL_ID, LANG_CD, EXPLANATION, ACTION_URL, SORT_ORDER
                FROM CORPINT.TBL_LANG_LABELS
                WHERE INSTR(ls_lang_cd, LANG_CD, 1, 1) > 0
                AND NVL(ls_tran_cd,TRAN_CD) = TRAN_CD
                AND NVL(ls_page_id,PAGE_ID) = PAGE_ID
                AND NVL(ls_label_id,LABEL_ID) = LABEL_ID;

        elsif ps_Option='UPDATE' then

            UPDATE CORPINT.TBL_LANG_LABELS
            SET EXPLANATION = ls_Description
            WHERE LANG_CD=ls_lang_cd
            AND TRAN_CD=ls_tran_cd
            AND PAGE_ID=ls_page_id
            AND LABEL_ID=ls_label_id;

        elsif ps_Option='NEW' then

            SELECT COUNT(1) INTO ln_count
            FROM CORPINT.TBL_LANG_LABELS
            WHERE LANG_CD=ls_lang_cd
            AND TRAN_CD=ls_tran_cd
            AND PAGE_ID=ls_page_id
            AND LABEL_ID=ls_label_id;

            if (ln_count>0) then
                raise DataExistError;
            end if;

            INSERT INTO CORPINT.TBL_LANG_LABELS
            (TRAN_CD, PAGE_ID, LABEL_ID, LANG_CD, EXPLANATION, ACTION_URL, SORT_ORDER)
            VALUES
            (ls_tran_cd, ls_page_id, ls_label_id, ls_lang_cd, ls_Description, NULL, ls_label_id);

        end if;

    ELSIF (ps_Source = 'MENUS') THEN

        ls_lang_cd := SPLIT(ps_LangCd, ';;;', 0);
        ls_tran_cd := SPLIT(ps_LangCd, ';;;', 1);
        ls_channel_cd := SPLIT(ps_LangCd, ';;;', 2);

        ls_Description := SPLIT(ps_Desciption, ';;;', 1);

        if ps_Option='LIST' then

            OPEN pc_ref FOR
                SELECT CHANNEL_CD, TRAN_CD, LANG_CD, EXPLANATION
                FROM CORPINT.TBL_MENU_DESCRIPTION
                WHERE INSTR(ls_lang_cd, LANG_CD, 1, 1) > 0
                AND NVL(ls_tran_cd,TRAN_CD) = TRAN_CD
                AND NVL(ls_channel_cd,CHANNEL_CD) = CHANNEL_CD;

        elsif ps_Option='UPDATE' then

            UPDATE CORPINT.TBL_MENU_DESCRIPTION
            SET EXPLANATION = ls_Description
            WHERE LANG_CD=ls_lang_cd
            AND TRAN_CD=ls_tran_cd
            AND CHANNEL_CD=ls_channel_cd;

        /*elsif ps_Option='NEW' then

            SELECT COUNT(1) INTO ln_count
            FROM CORPINT.TBL_MENU_DESCRIPTION
            WHERE LANG_CD=ls_lang_cd
            AND TRAN_CD=ls_tran_cd
            AND CHANNEL_CD=ls_channel_cd;

            if (ln_count>0) then
                raise DataExistError;
            end if;

            INSERT INTO CORPINT.TBL_MENU_DESCRIPTION
            (CHANNEL_CD, TRAN_CD, LANG_CD, EXPLANATION)
            VALUES
            (ls_channel_cd, ls_tran_cd, ls_lang_cd, ls_Description);*/

        end if;

    ELSIF (ps_Source = 'TRANSACTIONS') THEN

        ls_lang_cd := SPLIT(ps_LangCd, ';;;', 0);
        ls_tran_cd := SPLIT(ps_LangCd, ';;;', 1);

        ls_Description := SPLIT(ps_Desciption, ';;;', 1);

        if ps_Option='LIST' then

            OPEN pc_ref FOR
                SELECT TRAN_CD, LANGUAGE_CD, DEFINITION
                FROM CORPINT.TBL_TRANSACTION
                WHERE INSTR(ls_lang_cd, LANGUAGE_CD, 1, 1) > 0
                AND NVL(ls_tran_cd,TRAN_CD) = TRAN_CD;

        elsif ps_Option='UPDATE' then

            UPDATE CORPINT.TBL_TRANSACTION
            SET DEFINITION = ls_Description
            WHERE LANGUAGE_CD=ls_lang_cd
            AND TRAN_CD=ls_tran_cd;

        elsif ps_Option='NEW' then

            SELECT COUNT(1) INTO ln_count
            FROM CORPINT.TBL_TRANSACTION
            WHERE LANGUAGE_CD=ls_lang_cd
            AND TRAN_CD=ls_tran_cd;

            if (ln_count>0) then
                raise DataExistError;
            end if;

            INSERT INTO CORPINT.TBL_TRANSACTION
            (TRAN_CD, LANGUAGE_CD, DEFINITION)
            VALUES
            (ls_tran_cd, ls_lang_cd, ls_Description);

        end if;

    ELSIF (ps_Source = 'NEWS') THEN

        ls_lang_cd := SPLIT(ps_LangCd, ';;;', 0);
        ls_news_id := SPLIT(ps_LangCd, ';;;', 1);

        ls_Subject := SPLIT(ps_Desciption, ';;;', 0);
        ls_Description := SPLIT(ps_Desciption, ';;;', 1);

        if ps_Option='LIST' then

            OPEN pc_ref FOR
                SELECT NEWS_ID, LANG_CD, SUBJECT_TEXT, BODY_TEXT, LINK_TEXT, SECOND_BODY
                FROM CORPINT.TBL_NEWS_DESCRIPTION
                WHERE INSTR(ls_lang_cd, LANG_CD, 1, 1) > 0
                AND NVL(ls_news_id,NEWS_ID) = NEWS_ID;

        elsif ps_Option='UPDATE' then

            UPDATE CORPINT.TBL_NEWS_DESCRIPTION
            SET SUBJECT_TEXT = ls_Subject,
                BODY_TEXT = ls_Description
            WHERE LANG_CD=ls_lang_cd
            AND NEWS_ID=ls_news_id;

        elsif ps_Option='NEW' then

            SELECT COUNT(1) INTO ln_count
            FROM CORPINT.TBL_NEWS_DESCRIPTION
            WHERE LANG_CD=ls_lang_cd
            AND NEWS_ID=ls_news_id;

            if (ln_count>0) then
                raise DataExistError;
            end if;

            INSERT INTO CORPINT.TBL_NEWS_DESCRIPTION
            (NEWS_ID, LANG_CD, SUBJECT_TEXT, BODY_TEXT)
            VALUES
            (ls_news_id, ls_lang_cd, ls_Subject, ls_Description);

        end if;

    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN DataExistError then
        return '778';
    WHEN OTHERS THEN
        pkg_log.ADDCUSTOMLOG('UpdateMultiLanguageData',SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
END;
-------------------------------------------------------------------------------------------------------------
END Pkg_CINT_Main;
/

