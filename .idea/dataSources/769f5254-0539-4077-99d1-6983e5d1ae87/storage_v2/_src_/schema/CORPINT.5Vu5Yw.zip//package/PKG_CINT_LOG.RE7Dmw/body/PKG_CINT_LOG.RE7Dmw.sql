create PACKAGE BODY         "PKG_CINT_LOG" IS

/******************************************************************************
   NAME       : FUNCTION  LogTransaction
   Created By : Muzaffar Khalyknazarov
   Date       : 04.12.07
   Purpose    : LogTransaction
******************************************************************************/
FUNCTION LogTransaction(ps_channelcd    IN VARCHAR2,
                        pn_sessionid    IN NUMBER,
                        pn_personid     IN NUMBER,
                        ps_trancd       IN VARCHAR2,
                        pn_pageid       IN NUMBER,
                        ps_systemcd     IN VARCHAR2,
                        ps_errorcd      IN VARCHAR2,
                        ps_langcd       IN VARCHAR2,
                        ps_errordesc    IN VARCHAR2,
                        ps_actvtime     IN VARCHAR2,
                        pn_amount       IN VARCHAR2,
                        ps_currency     IN VARCHAR2,
                        ps_servername   IN VARCHAR2,
                        ps_ipaddress    IN VARCHAR2,
                        ps_jspduration  IN VARCHAR2 DEFAULT 0,
                        ps_beanduration IN VARCHAR2 DEFAULT 0,
                        ps_field1       IN VARCHAR2 DEFAULT NULL,
                        ps_field2       IN VARCHAR2 DEFAULT NULL,
                        ps_field3       IN VARCHAR2 DEFAULT NULL,
                        ps_field4       IN VARCHAR2 DEFAULT NULL,
                        ps_field5       IN VARCHAR2 DEFAULT NULL,
                        ps_field6       IN VARCHAR2 DEFAULT NULL,
                        ps_field7       IN VARCHAR2 DEFAULT NULL,
                        ps_field8       IN VARCHAR2 DEFAULT NULL,
                        ps_field9       IN VARCHAR2 DEFAULT NULL,
                        ps_field10      IN VARCHAR2 DEFAULT NULL,
                        ps_field11      IN VARCHAR2 DEFAULT NULL,
                        ps_field12      IN VARCHAR2 DEFAULT NULL,
                        ps_field13      IN VARCHAR2 DEFAULT NULL,
                        ps_field14      IN VARCHAR2 DEFAULT NULL,
                        ps_field15      IN VARCHAR2 DEFAULT NULL,
                        ps_userdesc     OUT VARCHAR2) RETURN VARCHAR2 IS

         ls_errortype   VARCHAR2(10);
         ls_userdesc    VARCHAR2(1000);
         ls_tatement    VARCHAR2(2000);
         ln_actvnbr     NUMBER;
         ls_returncode  VARCHAR2(3):='000';
         ln_amount      NUMBER;
         ld_actvitydate DATE;
         ls_content     VARCHAR2(4000);
         ls_inv         varchar2(200);
         TransactionError          EXCEPTION;
         to_much_numer_after_dot   EXCEPTION;

         CURSOR cursor_error IS
             SELECT error_type, user_desc
             FROM TBL_ERROR
             WHERE system_cd=RTRIM(LTRIM(ps_systemcd))
             AND error_cd=RTRIM(LTRIM(ps_errorcd))
             AND lang_cd=RTRIM(LTRIM(ps_langcd));

         row_error                   cursor_error%ROWTYPE;

         PRAGMA EXCEPTION_INIT(to_much_numer_after_dot,-06502); -- yanl?? rakam girilmesi durumunda

         PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN

     --Get Activity number
     ln_actvnbr:=Pkg_Common.GetSequenceID('sqACTIVITY');

     ld_actvitydate:=TO_DATE(ps_actvtime,'DDMMYYYY HH24:MI:SS');

     OPEN cursor_error;
     FETCH cursor_error INTO row_error;

        IF  cursor_error%NOTFOUND THEN
            ls_errortype:='SYS';
            ls_userdesc:='Please Try Again.';
        ELSE
            ls_errortype:=row_error.error_type;
            ls_userdesc:=row_error.user_desc;
        END IF;

     CLOSE cursor_error;

     ln_amount:=TO_NUMBER(pn_amount,'99999999999.99');

     INSERT INTO TBL_ACTIVITY
     (ACTV_NBR, CHANNEL_CD, SESSION_ID, PERSON_ID, TRAN_CD, PAGE_ID, SYSTEM_CD, ERROR_CD, ERROR_TYPE, AMOUNT, CURRENCY, ACTV_TIME, DLM, SERVERNAME, ERROR_DESC,CLIENT_IP_ADDRESS,
     FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,FIELD6,FIELD7,FIELD8,FIELD9,FIELD10,FIELD11,FIELD12,FIELD13,FIELD14,FIELD15,JSPDURATION, BEANDURATION)
     VALUES
     (ln_actvnbr, ps_channelcd, pn_sessionid,pn_personid, ps_trancd, pn_pageid, ps_systemcd, ps_errorcd, ls_errortype, ln_amount, ps_currency, ld_actvitydate, SYSDATE, ps_servername, substr(ps_errordesc,0,250),ps_ipaddress,
     ps_field1,ps_field2,ps_field3,ps_field4,ps_field5,ps_field6,ps_field7,ps_field8,ps_field9,ps_field10,ps_field11,ps_field12,ps_field13,ps_field14,ps_field15,ps_jspduration,ps_beanduration);

     ls_tatement:= 'select ' || TO_CHAR(ln_actvnbr)|| ls_userdesc || ' from dual';

     ps_userdesc:=ls_userdesc;

     begin
        select adi into ls_inv
        from cbs_system
        where rownum=1;
        
        if (ps_errorcd='999') then
            CBS.Pkg_Int_Email.SENDHTMLEMAIL ('info@demirbank.kg', 'almas.nurkhozhayev@bankpozitif.com.tr;gurayy@demirbank.kg;Aidjan.Jeenbaeva@demirbank.kg;Natalia.Slugina@demirbank.kg;Guray.YILMAZ@demirbank.kg;tynarbek.arzymatov@demirbank.kg', ps_channelcd || ' Channel System Error '||'('||ls_inv||')', ps_errordesc);
        end if;
     exception
        when others then
            Pkg_Log.AddCustomLog('Error Email Send',SQLERRM);
     end;
     
     COMMIT;

     RETURN ls_returncode;

EXCEPTION
      WHEN to_much_numer_after_dot THEN
      ls_returncode:='712';
       Pkg_Log.AddCustomLog(SQLERRM);
      RETURN ls_returncode;

      WHEN OTHERS THEN
      ls_returncode:='999';
      Pkg_Log.AddCustomLog(SQLERRM);
      log_at('PKG_CINT_LOG_ADI', ls_returncode, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN ls_returncode;


END;
/******************************************************************************
   NAME       : FUNCTION  GetUserInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Return User Information and last login date
******************************************************************************/
PROCEDURE AddCustomLog(pid1 VARCHAR2,
                         pid2 VARCHAR2 DEFAULT NULL,
                       pid3 VARCHAR2 DEFAULT NULL,
                       pid4 VARCHAR2 DEFAULT NULL) IS

    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    INSERT INTO TBL_CUSTOMLOG
    (FIELD1, FIELD2, FIELD3, FIELD4)
    VALUES
    (pid1, pid2, pid3, pid4);

    COMMIT;
END;
-----------------------------------------------------------------------------------------------------

FUNCTION GetErrorDescByCode (ps_systemcd   IN VARCHAR2,
                             ps_langcd     IN VARCHAR2,
                             ps_errorcd    IN VARCHAR2)
   RETURN VARCHAR2
IS
   ls_returnVal   VARCHAR2(500) := ''; 
BEGIN
   SELECT   NVL(T.ERROR_DESC,T.USER_DESC)  
     INTO   ls_returnVal
     FROM   TBL_ERROR T
    WHERE   T.SYSTEM_CD = ps_systemcd
            AND T.ERROR_CD = ps_errorcd
            AND T.LANG_CD = ps_langcd
            AND ROWNUM = 1;

   RETURN ls_returnVal;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      RETURN ls_returnVal;
END; 
END Pkg_Cint_Log;
/

