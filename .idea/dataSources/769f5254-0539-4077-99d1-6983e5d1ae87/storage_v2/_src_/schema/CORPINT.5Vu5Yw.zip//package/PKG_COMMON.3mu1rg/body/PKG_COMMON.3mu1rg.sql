create PACKAGE BODY         Pkg_Common IS

-----------------------------------------------------------------------------
FUNCTION  GetSequenceID(ps_sequencename IN VARCHAR2) RETURN NUMBER IS
      PRAGMA AUTONOMOUS_TRANSACTION;

      CURSOR cursor_sequence IS
        SELECT * FROM corpint.TBL_SEQUENCE
        WHERE sq_name = ps_sequencename FOR UPDATE;

      row_sequence cursor_sequence%ROWTYPE;
      ln_sqid NUMBER;

BEGIN

        OPEN cursor_sequence;
        FETCH cursor_sequence INTO row_sequence;

        IF  cursor_sequence%NOTFOUND THEN
            INSERT INTO TBL_SEQUENCE
            (sq_name, sq_value)
            VALUES (ps_sequencename, 1);
            ln_sqid := 1;
        ELSE
            ln_sqid := row_sequence.sq_value + 1;
            UPDATE TBL_SEQUENCE
            SET sq_value=sq_value + 1,
            dlm=SYSDATE
            WHERE CURRENT OF cursor_sequence;
        END IF;

        COMMIT;
        CLOSE cursor_sequence;

        RETURN(ln_sqid);
END;
-----------------------------------------------------------------------------------
FUNCTION  GetTicketID RETURN VARCHAR2 IS
        ls_ticketid VARCHAR2(40);
BEGIN

        SELECT sys_guid()
        INTO    ls_ticketid
        FROM dual;

        RETURN(ls_ticketid);
END;
-----------------------------------------------------------------------------------
FUNCTION GetBankCodes( ps_langcd    IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
     ls_langcd              VARCHAR2(3):=NULL;
     ls_customerid          NUMBER:=NULL;
     ls_errorcd              VARCHAR2(3):=NULL;
BEGIN

     OPEN pc_ref FOR
         SELECT  b.BANKCODE,b.BANKNAME,b.LANGCD
        FROM TBL_BANKCODES b
        WHERE b.LANGCD=NVL(ps_langcd,b.LANGCD)
        AND STATUSCD='sVALID'
        ORDER BY b.BANKNAME ASC;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;

-----------------------------------------------------------------------------------
FUNCTION GetPaymentCodes(ps_langcd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     IF (ps_langcd='ENG') THEN
     OPEN pc_ref FOR
         SELECT t.ISTATISTIK_KODU, SUBSTR(t.ACIKLAMA2,1,70)||'...'
        FROM cbs.cbs_istatistik_kodlari t;
     ELSE
     OPEN pc_ref FOR
        SELECT t.ISTATISTIK_KODU, SUBSTR(t.ACIKLAMA2,1,70)||'...'
        FROM cbs.cbs_istatistik_kodlari t;
    END IF;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
FUNCTION AddPaymentCodes(ps_option IN VARCHAR2,
                         ps_paymentcd IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                      ps_paymentdesc    IN VARCHAR2) RETURN VARCHAR2 IS


         CURSOR cursor_code IS
             SELECT * FROM TBL_PAYMENTCODES
            WHERE PAYMENTCD=ps_paymentcd
            AND LANGCD=ps_langcd;

         row_code cursor_code%ROWTYPE;
         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN
    IF ps_option='D' THEN --delete
       UPDATE TBL_PAYMENTCODES
        SET STATUSCD='sCANCEL'
        WHERE PAYMENTCD=ps_paymentcd;
    ELSE
         OPEN cursor_code;
        FETCH cursor_code INTO row_code;
        IF  cursor_code%NOTFOUND THEN
            INSERT INTO TBL_PAYMENTCODES
            (PAYMENTCD, PAYMENTNAME, LANGCD)
            VALUES
            (ps_paymentcd, ps_paymentdesc,ps_langcd);
        ELSE
            UPDATE TBL_PAYMENTCODES
            SET PAYMENTNAME=ps_paymentdesc
            WHERE PAYMENTCD=ps_paymentcd
            AND LANGCD=ps_langcd;
        END IF;
        CLOSE cursor_code;
     END IF;
    RETURN ls_returncode;
END;
--------------------------------------------------------------------------------

-----------------------------------------------------------------------------------
FUNCTION AddBankCodes(ps_option IN VARCHAR2,
                       ps_bankcd IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                      ps_bankdesc    IN VARCHAR2) RETURN VARCHAR2 IS

         CURSOR cursor_code IS
             SELECT * FROM TBL_BANKCODES
            WHERE BANKCODE=ps_bankcd
            AND LANGCD=ps_langcd;

         row_code cursor_code%ROWTYPE;
         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN
    IF ps_option='D' THEN --delete
       UPDATE TBL_BANKCODES
        SET STATUSCD='sCANCEL'
        WHERE BANKCODE=ps_bankcd;
    ELSE
         OPEN cursor_code;
        FETCH cursor_code INTO row_code;
        IF  cursor_code%NOTFOUND THEN
            INSERT INTO TBL_BANKCODES
            (BANKCODE, BANKNAME, LANGCD)
            VALUES
            (ps_bankcd , ps_bankdesc,ps_langcd);
        ELSE
            UPDATE TBL_BANKCODES
            SET BANKNAME=ps_bankdesc
            WHERE BANKCODE=ps_bankcd
            AND LANGCD=ps_langcd;
        END IF;
        CLOSE cursor_code;
     END IF;
    RETURN ls_returncode;
END;
--------------------------------------------------------------------------------
FUNCTION GetTheDayAfter(ps_daycount IN NUMBER,returnDate OUT TIMESTAMP) RETURN VARCHAR2 IS
     ls_returncode  VARCHAR2(3):='000';
BEGIN
     SELECT SYSDATE + ps_daycount INTO returnDate
     FROM dual;
     RETURN ls_returncode;
END;
---------------------------------------------------------------------------------------------------
FUNCTION GetTranDescription(ps_trancd IN VARCHAR2, ps_langcd IN VARCHAR2) RETURN VARCHAR2 IS
         ls_desc VARCHAR2(250);
BEGIN
     SELECT DEFINITION
     INTO ls_desc
     FROM TBL_TRANSACTION
     WHERE tran_cd=ps_trancd
     AND LANGUAGE_CD=ps_langcd;

     RETURN ls_desc;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN ' ';

END;
-----------------------------------------------------------------------------------------------------
FUNCTION GetTXTODOInfo(pn_customerno   IN VARCHAR2,
                        ps_trantype     IN VARCHAR2,
                       ps_status       IN VARCHAR2,
                        pd_startdate       IN VARCHAR2,
                       pd_enddate      IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_returncode          VARCHAR2(3):='000';
BEGIN


     IF pn_customerno IS NULL THEN

     OPEN pc_ref FOR
           SELECT TX_NO, TRANCD, MAKERID, MAKEDATE, NVL(VERIFYID,' '),
                    VERIFYDATE, NVL(APPROVALID,' '), APPROVALDATE, NVL(STATUS,' '), NVL(FIELD1,' '),
                    NVL(FIELD2,' '), NVL(FIELD3,' '), NVL(FIELD4,' '), NVL(FIELD5,' '), NVL(FIELD6,' '),
                    NVL(FIELD7,' '), NVL(FIELD8,' '), NVL(FIELD9,' '), NVL(FIELD10,' '), NVL(FIELD11,' '),
                    NVL(FIELD12,' '), NVL(FIELD13,' '), NVL(FIELD14,' '), NVL(FIELD15,' '), NVL(AUTHCD,' '),
                    NVL(CHECKID,' '), CHECKDATE, NVL(FIELD16,' '), NVL(FIELD17,' '), NVL(FIELD18,' '),
                    NVL(FIELD19,' '), NVL(FIELD20,' '), DLM, CONTROL_DATE, CONTROL_ID
          FROM TBL_TXTODO
          WHERE STATUS IN DECODE(ps_status,'ALL',STATUS,ps_status)
          AND TRANCD IN DECODE(ps_trantype,'ALL',TRANCD,ps_trantype)
          AND TO_DATE(pd_startdate,'YYYYMMDD') <= TRUNC(MAKEDATE)
          AND TO_DATE(pd_enddate,'YYYYMMDD') >= TRUNC(MAKEDATE)
          ORDER BY MAKERID ASC;

     ELSE

     OPEN pc_ref FOR
           SELECT TX_NO, TRANCD, MAKERID, MAKEDATE, NVL(VERIFYID,' '),
                    VERIFYDATE, NVL(APPROVALID,' '), APPROVALDATE, NVL(STATUS,' '), NVL(FIELD1,' '),
                    NVL(FIELD2,' '), NVL(FIELD3,' '), NVL(FIELD4,' '), NVL(FIELD5,' '), NVL(FIELD6,' '),
                    NVL(FIELD7,' '), NVL(FIELD8,' '), NVL(FIELD9,' '), NVL(FIELD10,' '), NVL(FIELD11,' '),
                    NVL(FIELD12,' '), NVL(FIELD13,' '), NVL(FIELD14,' '), NVL(FIELD15,' '), NVL(AUTHCD,' '),
                    NVL(CHECKID,' '), CHECKDATE, NVL(FIELD16,' '), NVL(FIELD17,' '), NVL(FIELD18,' '),
                    NVL(FIELD19,' '), NVL(FIELD20,' '), DLM, CONTROL_DATE, CONTROL_ID
          FROM TBL_TXTODO
          WHERE MAKERID IN (SELECT person_id FROM TBL_PERSON WHERE customer_id=pn_customerno)
          AND STATUS IN DECODE(ps_status,'ALL',STATUS,ps_status)
          AND TRANCD IN DECODE(ps_trantype,'ALL',TRANCD,ps_trantype)
          AND TO_DATE(pd_startdate,'YYYYMMDD') <= TRUNC(MAKEDATE)
          AND TO_DATE(pd_enddate,'YYYYMMDD') >= TRUNC(MAKEDATE)
          ORDER BY MAKERID ASC;

    END IF;

     RETURN ls_returncode;

END;
--------------------------------------------------------------------------------
FUNCTION GetTermInfo(ps_paramid IN VARCHAR2,
                      ps_param1 OUT VARCHAR2,
                      ps_param2 OUT VARCHAR2,
                      ps_param3 OUT VARCHAR2,
                     ps_param4 OUT VARCHAR2,
                     ps_param5 OUT VARCHAR2,
                     ps_param6 OUT VARCHAR2,
                     ps_param7 OUT VARCHAR2,
                     ps_param8 OUT VARCHAR2,
                     ps_param9 OUT VARCHAR2,
                     ps_param10 OUT VARCHAR2,
                     ps_param11 OUT VARCHAR2,
                     ps_param12 OUT VARCHAR2,
                     ps_param13 OUT VARCHAR2,
                     ps_param14 OUT VARCHAR2,
                     ps_param15 OUT VARCHAR2,
                     ps_param16 OUT VARCHAR2,
                     ps_paramstr1 OUT VARCHAR2,
                     ps_paramstr2 OUT VARCHAR2,
                     ps_paramstr3 OUT VARCHAR2,
                     ps_paramstr4 OUT VARCHAR2,
                     ps_paramstr5 OUT VARCHAR2,
                     ps_paramstr6 OUT VARCHAR2,
                     ps_paramstr7 OUT VARCHAR2,
                     ps_paramstr8 OUT VARCHAR2,
                      ps_param1_os OUT VARCHAR2,
                      ps_param2_os OUT VARCHAR2,
                      ps_param3_os OUT VARCHAR2,
                     ps_param4_os OUT VARCHAR2,
                     ps_param5_os OUT VARCHAR2,
                     ps_param6_os OUT VARCHAR2,
                     ps_param7_os OUT VARCHAR2,
                     ps_param8_os OUT VARCHAR2,
                     ps_param9_os OUT VARCHAR2,
                     ps_param10_os OUT VARCHAR2,
                     ps_param11_os OUT VARCHAR2,
                     ps_param12_os OUT VARCHAR2,
                     ps_param13_os OUT VARCHAR2,
                     ps_param14_os OUT VARCHAR2,
                     ps_param15_os OUT VARCHAR2,
                     ps_param16_os OUT VARCHAR2,
                     ps_paramstr9 OUT VARCHAR2,
                     ps_paramstr10 OUT VARCHAR2,
                     ps_paramstr11 OUT VARCHAR2,
                      ps_channelcd OUT VARCHAR2
                     ) RETURN VARCHAR2 IS


BEGIN

pkg_log.AddCustomLog('tran',ps_paramid);

     SELECT NVL(PARAM_1,' '), NVL(PARAM_2,' '), NVL(PARAM_3,' '), NVL(PARAM_4,' '), NVL(PARAM_5,' '),NVL(PARAM_6,' '), NVL(PARAM_7,' '), NVL(PARAM_8,' '),
     NVL(PARAM_9,' '), NVL(PARAM_10,' '), NVL(PARAM_11,' '), NVL(PARAM_12,' '),NVL(PARAM_13,' '), NVL(PARAM_14,' '), NVL(PARAM_15,' '), NVL(PARAM_16,' ') ,
     NVL(STRPARAM_1,' '), NVL(STRPARAM_2,' '), NVL(STRPARAM_3,' '), NVL(STRPARAM_4,' '), NVL(STRPARAM_5,' '), NVL(STRPARAM_6,' '), NVL(STRPARAM_7,' '), NVL(STRPARAM_8,' '),
     NVL(PARAM_1_OS,' '),NVL(PARAM_2_OS,' '),NVL(PARAM_3_OS,' '),NVL(PARAM_4_OS,' '),NVL(PARAM_5_OS,' '),NVL(PARAM_6_OS,' '),NVL(PARAM_7_OS,' '),NVL(PARAM_8_OS,' '),
     NVL(PARAM_9_OS,' '),NVL(PARAM_10_OS,' '),NVL(PARAM_11_OS,' '),NVL(PARAM_12_OS,' '),NVL(PARAM_13_OS,' '),NVL(PARAM_14_OS,' '),NVL(PARAM_15_OS,' '),NVL(PARAM_16_OS,' '),
     NVL(STRPARAM_9,' '),NVL(STRPARAM_10,' '),NVL(STRPARAM_11,' ')

     INTO
     ps_param1,ps_param2,ps_param3,ps_param4,ps_param5,ps_param6,ps_param7,ps_param8,
     ps_param9,ps_param10,ps_param11,ps_param12,ps_param13,ps_param14,ps_param15,ps_param16,
     ps_paramstr1,ps_paramstr2,ps_paramstr3,ps_paramstr4,ps_paramstr5,ps_paramstr6,ps_paramstr7,ps_paramstr8,
     ps_param1_os,ps_param2_os,ps_param3_os,ps_param4_os,ps_param5_os,ps_param6_os,ps_param7_os,ps_param8_os,
      ps_param9_os,ps_param10_os,ps_param11_os,ps_param12_os,ps_param13_os,ps_param14_os,ps_param15_os,ps_param16_os,
     ps_paramstr9,ps_paramstr10,ps_paramstr11

     FROM TBL_TERMCOND
     WHERE param_id=ps_paramid;

     RETURN '000';
END;
--------------------------------------------------------------------------------
FUNCTION UpdateTermInfo(ps_paramid IN VARCHAR2,
                      ps_param1 IN VARCHAR2,
                      ps_param2 IN VARCHAR2,
                      ps_param3 IN VARCHAR2,
                     ps_param4 IN VARCHAR2,
                     ps_param5 IN VARCHAR2,
                     ps_param6 IN VARCHAR2,
                     ps_param7 IN VARCHAR2,
                     ps_param8 IN VARCHAR2,
                     ps_param9 IN VARCHAR2,
                     ps_param10 IN VARCHAR2,
                     ps_param11 IN VARCHAR2,
                     ps_param12 IN VARCHAR2,
                     ps_param13 IN VARCHAR2,
                     ps_param14 IN VARCHAR2,
                     ps_param15 IN VARCHAR2,
                     ps_param16 IN VARCHAR2,
                     ps_paramstr1 IN VARCHAR2,
                     ps_paramstr2 IN VARCHAR2,
                     ps_paramstr3 IN VARCHAR2,
                     ps_paramstr4 IN VARCHAR2,
                     ps_paramstr5 IN VARCHAR2,
                     ps_paramstr6 IN VARCHAR2,
                     ps_paramstr7 IN VARCHAR2,
                     ps_paramstr8 IN VARCHAR2,
                      ps_param1_os IN VARCHAR2,
                      ps_param2_os IN VARCHAR2,
                      ps_param3_os IN VARCHAR2,
                     ps_param4_os IN VARCHAR2,
                     ps_param5_os IN VARCHAR2,
                     ps_param6_os IN VARCHAR2,
                     ps_param7_os IN VARCHAR2,
                     ps_param8_os IN VARCHAR2,
                     ps_param9_os IN VARCHAR2,
                     ps_param10_os IN VARCHAR2,
                     ps_param11_os IN VARCHAR2,
                     ps_param12_os IN VARCHAR2,
                     ps_param13_os IN VARCHAR2,
                     ps_param14_os IN VARCHAR2,
                     ps_param15_os IN VARCHAR2,
                     ps_param16_os IN VARCHAR2,
                     ps_paramstr9 IN VARCHAR2,
                     ps_paramstr10 IN VARCHAR2,
                     ps_paramstr11 IN VARCHAR2,
                     ps_option IN VARCHAR2,
                     ps_channelcd IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode          VARCHAR2(3):='000';

BEGIN
pkg_log.AddCustomLog('view',ps_channelcd,ps_paramid);

     IF PS_OPTION='VIEW' THEN

            OPEN pc_ref FOR
             SELECT NVL(PARAM_1,' '), NVL(PARAM_2,' '), NVL(PARAM_3,' '), NVL(PARAM_4,' '), NVL(PARAM_5,' '),NVL(PARAM_6,' '), NVL(PARAM_7,' '), NVL(PARAM_8,' '),
                     NVL(PARAM_9,' '), NVL(PARAM_10,' '), NVL(PARAM_11,' '), NVL(PARAM_12,' '),NVL(PARAM_13,' '), NVL(PARAM_14,' '), NVL(PARAM_15,' '), NVL(PARAM_16,' ') ,
                     NVL(STRPARAM_1,' '), NVL(STRPARAM_2,' '), NVL(STRPARAM_3,' '), NVL(STRPARAM_4,' '), NVL(STRPARAM_5,' '), NVL(STRPARAM_6,' '), NVL(STRPARAM_7,' '), NVL(STRPARAM_8,' '),
                     NVL(PARAM_1_OS,' '),NVL(PARAM_2_OS,' '),NVL(PARAM_3_OS,' '),NVL(PARAM_4_OS,' '),NVL(PARAM_5_OS,' '),NVL(PARAM_6_OS,' '),NVL(PARAM_7_OS,' '),NVL(PARAM_8_OS,' '),
                     NVL(PARAM_9_OS,' '),NVL(PARAM_10_OS,' '),NVL(PARAM_11_OS,' '),NVL(PARAM_12_OS,' '),NVL(PARAM_13_OS,' '),NVL(PARAM_14_OS,' '),NVL(PARAM_15_OS,' '),NVL(PARAM_16_OS,' '),
                     NVL(STRPARAM_9,' '),NVL(STRPARAM_10,' '),NVL(STRPARAM_11,' ')
             FROM TBL_TERMCOND
             WHERE param_id=TO_NUMBER(ps_paramid)
             AND CHANNEL_CD=ps_channelcd;

    pkg_log.AddCustomLog('update',ps_channelcd,ps_paramid);
      ELSIF PS_OPTION='UPDATE' THEN

       UPDATE TBL_TERMCOND
       SET  PARAM_1=ps_param1,
            PARAM_2=ps_param2,
            PARAM_3=ps_param3,
            PARAM_4=ps_param4,
            PARAM_5=ps_param5,
            PARAM_6=ps_param6,
            PARAM_7=ps_param7,
            PARAM_8=ps_param8,
            PARAM_9=ps_param9,
            PARAM_10=ps_param10,
            PARAM_11=ps_param11,
            PARAM_12=ps_param12,
            PARAM_13=ps_param13,
            PARAM_14=ps_param14,
            PARAM_15=ps_param15,
            PARAM_16=ps_param16,
            PARAM_1_OS=ps_param1_os,
            PARAM_2_OS=ps_param2_os,
            PARAM_3_OS=ps_param3_os,
            PARAM_4_OS=ps_param4_os,
            PARAM_5_OS=ps_param5_os,
            PARAM_6_OS=ps_param6_os,
            PARAM_7_OS=ps_param7_os,
            PARAM_8_OS=ps_param8_os,
            PARAM_9_OS=ps_param9_os,
            PARAM_10_OS=ps_param10_os,
            PARAM_11_OS=ps_param11_os,
            PARAM_12_OS=ps_param12_os,
            PARAM_13_OS=ps_param13_os,
            PARAM_14_OS=ps_param14_os,
            PARAM_15_OS=ps_param15_os,
            PARAM_16_OS=ps_param16_os
      WHERE param_id=TO_NUMBER(ps_paramid)
      AND CHANNEL_CD=ps_channelcd;

      OPEN pc_ref FOR
             SELECT NVL(PARAM_1,' '), NVL(PARAM_2,' '), NVL(PARAM_3,' '), NVL(PARAM_4,' '), NVL(PARAM_5,' '),NVL(PARAM_6,' '), NVL(PARAM_7,' '), NVL(PARAM_8,' '),
                     NVL(PARAM_9,' '), NVL(PARAM_10,' '), NVL(PARAM_11,' '), NVL(PARAM_12,' '),NVL(PARAM_13,' '), NVL(PARAM_14,' '), NVL(PARAM_15,' '), NVL(PARAM_16,' ') ,
                     NVL(STRPARAM_1,' '), NVL(STRPARAM_2,' '), NVL(STRPARAM_3,' '), NVL(STRPARAM_4,' '), NVL(STRPARAM_5,' '), NVL(STRPARAM_6,' '), NVL(STRPARAM_7,' '), NVL(STRPARAM_8,' '),
                     NVL(PARAM_1_OS,' '),NVL(PARAM_2_OS,' '),NVL(PARAM_3_OS,' '),NVL(PARAM_4_OS,' '),NVL(PARAM_5_OS,' '),NVL(PARAM_6_OS,' '),NVL(PARAM_7_OS,' '),NVL(PARAM_8_OS,' '),
                     NVL(PARAM_9_OS,' '),NVL(PARAM_10_OS,' '),NVL(PARAM_11_OS,' '),NVL(PARAM_12_OS,' '),NVL(PARAM_13_OS,' '),NVL(PARAM_14_OS,' '),NVL(PARAM_15_OS,' '),NVL(PARAM_16_OS,' '),
                     NVL(STRPARAM_9,' '),NVL(STRPARAM_10,' '),NVL(STRPARAM_11,' ')
             FROM TBL_TERMCOND
             WHERE param_id=TO_NUMBER(ps_paramid)
             AND CHANNEL_CD=ps_channelcd;

    END IF;

     RETURN ls_returncode;
END;
--------------------------------------------------------------------------------
FUNCTION GetOnlineSubInquary(pn_hesapno   IN VARCHAR2,
                             ps_status    IN VARCHAR2,
                             pd_startdate IN VARCHAR2,
                             pd_enddate   IN VARCHAR2,
                             ps_msg_type  IN VARCHAR2,
                             pc_ref       OUT CursorReferenceType) RETURN VARCHAR2 IS

ls_returncode VARCHAR2(3):='000';

BEGIN

OPEN pc_ref FOR

    SELECT DISTINCT
           e.PERSONID,
           e.CUSTOMER_NO,
           e.CHANNEL_CD,
           TO_CHAR(e.SUBSCRIBE_DATE,'YYYYMMDD'),
           e.MSG_TYPE,
           e.PERIOD,
           TO_CHAR(e.NEXTRUNDATE,'YYYYMMDD'),
           e.EMAIL,
           ASSNDATE,
           e.ENDDATE,
           e.STATUS_CD,
           i.EXTERNAL_HESAP_NO,
           cbs.pkg_musteri.Sf_Musteri_Adi(e.CUSTOMER_NO)
    FROM   TBL_EMAIL_SUBSCRIPTION e,
           cbs.cbs_hesap i
    WHERE  e.ACCOUNT_NO = nvl(pn_hesapno,e.ACCOUNT_NO)
      AND  e.CUSTOMER_NO=i.MUSTERI_NO
      AND  e.SUBSCRIBE_DATE BETWEEN nvl(TO_DATE(pd_startdate,'YYYYMMDD'),e.SUBSCRIBE_DATE)
                                 AND     nvl(TO_DATE(pd_enddate,'YYYYMMDD'),e.SUBSCRIBE_DATE)
      AND  e.STATUS_CD=NVL(ps_status,e.STATUS_CD)
      AND  e.MSG_TYPE=NVL(ps_msg_type,e.MSG_TYPE);

RETURN ls_returncode;

END;

---------------------------------------------------------------------------------
FUNCTION GetEtokenUsers(pn_hesapno   IN VARCHAR2,
                                                   ps_name    IN VARCHAR2,
                                                     pn_customerid       IN VARCHAR2,
                                                    pd_assigndate       IN VARCHAR2,
                                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_returncode          VARCHAR2(3):='000';
       ln_customerno NUMBER;

BEGIN

    /* ln_customerno:=pn_customerid;
            IF pn_customerid IS NULL AND ps_name  IS NULL THEN
           ln_customerno:=0;
        END IF;*/

         OPEN pc_ref FOR
                SELECT e.PERSON_ID,e.CHANNEL_CD,e.EXPIREDATE,e.STATUS_CD,e.TOKEN_ID,
                              g.FIRSTNAME,g.CUSTOMER_ID, g.BIRTH_DATE, to_char(e.ASSIGN_TOKEN_DATE,'yyyymmdd')
                FROM TBL_IDENTIFICATION e,
                         TBL_PERSON g
                WHERE e.TOKEN_ID IS NOT NULL
                AND e.PERSON_ID=g.PERSON_ID
                AND g.FIRSTNAME LIKE '%'|| UPPER(ps_name) ||'%'
                AND NVL(g.CUSTOMER_ID,0)=NVL(pn_customerid,NVL(g.CUSTOMER_ID,0))
                ORDER BY e.PERSON_ID;

     RETURN ls_returncode;

END;
---------------------------------------------------------------------------------
FUNCTION UpdateEmailAdvertisement(ps_option IN VARCHAR2,
       ps_advertisement IN VARCHAR2,
       ps_end_date        in varchar2,
      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode    VARCHAR2(3):='000';

BEGIN
    IF ps_option='VIEW' THEN

        OPEN pc_ref FOR
            SELECT ADVERTISE_ID, ADVERTISE_TEXT, to_char(ADV_END_DATE,'yyyymmdd')
            FROM TBL_EMAIL_ADVERTISEMENT;

    ELSIF ps_option='UPDATE' THEN

        UPDATE TBL_EMAIL_ADVERTISEMENT
        SET  ADVERTISE_TEXT=ps_advertisement,
        ADV_END_DATE = to_date(ps_end_date,'yyyymmdd');

        OPEN pc_ref FOR
            SELECT ADVERTISE_ID, ADVERTISE_TEXT, to_char(ADV_END_DATE,'yyyymmdd')
            FROM TBL_EMAIL_ADVERTISEMENT;

    END IF;

  RETURN ls_returncode;
END;
---------------------------------------------------------------------------------
FUNCTION UpdateEmailSubscription(ps_option IN VARCHAR2,
                                                   pn_hesapno   IN VARCHAR2,
                                                   ps_status       IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode          VARCHAR2(3):='000';

BEGIN

     IF ps_option='VIEW' THEN

            OPEN pc_ref FOR
                SELECT e.PERSONID, e.CUSTOMER_NO, e.CHANNEL_CD,
                                TO_CHAR(e.SUBSCRIBE_DATE,'YYYYMMDD'), e.MSG_TYPE, e.PERIOD,
                                TO_CHAR(e.NEXTRUNDATE,'YYYYMMDD'), e.EMAIL, ASSNDATE, e.ENDDATE, e.STATUS_CD,
                                i.EXTERNAL_HESAP_NO,cbs.pkg_musteri.Sf_Musteri_Adi(e.CUSTOMER_NO)
                FROM TBL_EMAIL_SUBSCRIPTION e,
                            cbs.cbs_hesap i
                WHERE e.CUSTOMER_NO=i.MUSTERI_NO
                AND i.HESAP_NO=pn_hesapno;

      ELSIF ps_option='UPDATE' THEN

       UPDATE TBL_EMAIL_SUBSCRIPTION
       SET  STATUS_CD=ps_status
       WHERE ACCOUNT_NO=pn_hesapno;

      OPEN pc_ref FOR
            SELECT e.PERSONID, e.CUSTOMER_NO, e.CHANNEL_CD,
                                TO_CHAR(e.SUBSCRIBE_DATE,'YYYYMMDD'), e.MSG_TYPE, e.PERIOD,
                                TO_CHAR(e.NEXTRUNDATE,'YYYYMMDD'), e.EMAIL, ASSNDATE, e.ENDDATE, e.STATUS_CD,
                                i.EXTERNAL_HESAP_NO,cbs.pkg_musteri.Sf_Musteri_Adi(e.CUSTOMER_NO)
                FROM TBL_EMAIL_SUBSCRIPTION e,
                            cbs.cbs_hesap i
                WHERE e.CUSTOMER_NO=i.MUSTERI_NO
                AND i.HESAP_NO=pn_hesapno;

    END IF;

     RETURN ls_returncode;
END;
---------------------------------------------------------------------------------
FUNCTION GetCustomerNoFromSession(ps_sessionid IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
     OPEN pc_ref FOR SELECT '0' from dual;

     OPEN pc_ref FOR
        select customer_id from corpint.tbl_person
        where person_id in (select person_id from corpint.tbl_session where session_id=ps_sessionid);

     RETURN ls_returncode;
EXCEPTION
        WHEN Others THEN
             RETURN '999';
END;
---------------------------------------------------------------------------------
FUNCTION SendEmailDekont(ps_channel_cd IN VARCHAR2,
                         ps_email IN VARCHAR2,
                         ps_tx_no IN VARCHAR2,
                         ps_lang_cd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_return_code varchar2(3) := '000';
BEGIN
    open pc_ref for select 'DONE' from dual;

   
     cbs.PKG_JOBS.SENDDEALSLIP(ps_channel_cd, ps_email, ps_tx_no, ps_lang_cd,pc_ref);

    return ls_return_code;
Exception
    when others then
        open pc_ref for select 'ERROR' from dual;
        PKG_LOG.ADDCUSTOMLOG('SendEmailDekont',sqlerrm);
        Raise_application_error(-20100, sqlerrm);
END;
---------------------------------------------------------------------------------
FUNCTION SendAccountHistoryDekont(ps_channel_cd IN VARCHAR2,
                                  ps_lang_cd IN VARCHAR2,
                                  ps_person_id IN VARCHAR2,
                                  ps_email IN VARCHAR2,
                                  ps_start_date IN VARCHAR2,
                                  ps_end_date IN VARCHAR2,
                                  ps_type IN VARCHAR2,
                                  ps_account_no IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_return_code varchar2(3) := '000';
BEGIN
    open pc_ref for select 'DONE' from dual;

    cbs.PKG_JOBS.SendAccountHistory(ps_channel_cd, ps_lang_cd, ps_person_id, ps_email, ps_start_date, ps_end_date, ps_type, ps_account_no);

    return ls_return_code;
Exception
    when others then
        open pc_ref for select 'ERROR' from dual;
        PKG_LOG.ADDCUSTOMLOG('SendEmailDekont',sqlerrm);
        Raise_application_error(-20100, sqlerrm);
END;
---------------------------------------------------------------------------------
FUNCTION SendCreditCardDekont(ps_TranCD IN VARCHAR2,
                              ps_From IN VARCHAR2,
                              ps_To IN VARCHAR2,
                              ps_Subject IN VARCHAR2,
                              ps_Data IN CLOB,
                              ps_channel_cd IN VARCHAR2,
                              ps_lang_cd IN VARCHAR2,
                              ps_person_id IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_return_code varchar2(3) := '000';
BEGIN
    open pc_ref for select 'DONE' from dual;

    cbs.PKG_JOBS.SendCreditCardTranList(ps_TranCD, ps_From, ps_To, ps_Subject, ps_Data, ps_channel_cd, ps_lang_cd, ps_person_id);

    return ls_return_code;
Exception
    when others then
        open pc_ref for select 'ERROR' from dual;
        PKG_LOG.ADDCUSTOMLOG('SendCreditCardDekont',sqlerrm);
        Raise_application_error(-20100, sqlerrm);
END;
---------------------------------------------------------------------------------
FUNCTION VCardAgreementWithOption(ps_OptionCD IN VARCHAR2,
                                  ps_AgreementID IN VARCHAR2,
                                  ps_AgreementText IN VARCHAR2,
                                  ps_LangCD IN VARCHAR2,
                                  ps_PersonID IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_return_code varchar2(3) := '000';
    ln_count NUMBER;
    ln_id NUMBER;
BEGIN
    open pc_ref for
        select ID, LANG_CD, AGREEMENT_TEXT, CREATED_BY, to_char(CREATED_AT,'YYYYMMDD')
        from CORPINT.TBL_VCARD_AGREEMENT
        order by ID desc;
        
    select count(1) into ln_count
    from CORPINT.TBL_VCARD_AGREEMENT
    where ID = ps_AgreementID
    and LANG_CD=ps_LangCD;
    
    IF (ps_OptionCD = 'GET') THEN

        open pc_ref for
            select ID, LANG_CD, AGREEMENT_TEXT, CREATED_BY, to_char(CREATED_AT,'YYYYMMDD')
            from CORPINT.TBL_VCARD_AGREEMENT
            where LANG_CD=ps_LangCD
            order by ID desc;

    ELSIF (ps_OptionCD = 'UPDATE') THEN

        if (ln_count > 0) then

            update CORPINT.TBL_VCARD_AGREEMENT
            set AGREEMENT_TEXT = ps_AgreementText
            where ID = ps_AgreementID
            and LANG_CD = ps_LangCD;

        else

            ln_id := Pkg_Common.GetSequenceID('pqVCARDAGREEMENT');

            insert into CORPINT.TBL_VCARD_AGREEMENT
            (ID, LANG_CD, AGREEMENT_TEXT, CREATED_BY)
            values
            (ln_id, ps_LangCD, ps_AgreementText, ps_PersonID);

        end if;

    END IF;
    
    return ls_return_code;
Exception
    when others then
        PKG_LOG.ADDCUSTOMLOG('VCardAgreementWithOption',sqlerrm);
        Raise_application_error(-20100, sqlerrm);
END;

END;
/

