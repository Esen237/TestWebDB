create PACKAGE         Pkg_Admin IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
FUNCTION GetAuthCodes( ps_channelcd IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION SetAuthCodes( ps_authcodes  IN VARCHAR2,
                        ps_personid     IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
                  
-----------------------------------------------------------------------------------
FUNCTION AddAuthTranCd(ps_trancd     IN VARCHAR2,
                    ps_authcd    IN VARCHAR2,
                    ps_langcd     IN VARCHAR2,
                    ps_trandesc   IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION AddPersonAuth(pn_personid IN NUMBER,
                        ps_channelcd    IN VARCHAR2,
                        ps_authcd    IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION ChangeUserStatus( ps_personid IN VARCHAR2,
                                                ps_newstatus IN VARCHAR2,
                                               ps_expiredate OUT VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION CreateUser(ps_channelcd IN VARCHAR2,
                    ps_username    IN VARCHAR2,
                       ps_passcode IN VARCHAR2,
                       ps_pincode IN VARCHAR2,
                   ps_firstname IN VARCHAR2,
                   ps_middlename IN VARCHAR2,
                   ps_lastname IN VARCHAR2,
                   ps_email IN VARCHAR2,
                   pn_customerid IN NUMBER,
                   pn_personid OUT NUMBER) RETURN VARCHAR2;
-----------------------------------------------------------------------------------
FUNCTION GetErrorCodes(ps_systemcd IN VARCHAR2,
                        ps_errorcd IN VARCHAR2,
                        ps_langcd    IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

-----------------------------------------------------------------------------------
FUNCTION AddErrorMsg(ps_systemcd IN VARCHAR2,
                      ps_errorcd IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                      ps_errortype    IN VARCHAR2,
                     ps_errordesc    IN VARCHAR2,
                     ps_userdesc    IN VARCHAR2) RETURN VARCHAR2;

-----------------------------------------------------------------------------------
FUNCTION GetActivityHistory(ps_channelcd    IN       VARCHAR2,
                            pn_customerid   IN       VARCHAR2,
                            pn_sessionid    IN       VARCHAR2,
                            ps_langcd       IN       VARCHAR2,
                            ps_startdate    IN       VARCHAR2,
                            ps_enddate      IN       VARCHAR2,
                            ps_errorcd      IN       VARCHAR2,
                            ps_ipaddress    IN       VARCHAR2,
                            ps_personid     IN       VARCHAR2,
                            pc_ref          OUT      cursorreferencetype) RETURN VARCHAR2;
------------------------------------------------------------------------------------
FUNCTION AddLangParam(ps_pageid IN VARCHAR2,
                      ps_paramid IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                     ps_paramdesc    IN VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------------------------
FUNCTION GetLangParam(ps_pageid IN VARCHAR2,
                      ps_paramid IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

--------------------------------------------------------------------------------------
FUNCTION GetUserInfos(ps_customerid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------------------
FUNCTION GetCustomerPersons(ps_customerid IN VARCHAR2,ps_channelcd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION GetSuperStatus(pn_personid IN NUMBER) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION showalllogonattemp(ps_ChannelCD IN VARCHAR2,
                            ps_AccessType IN VARCHAR2,
                            ps_CustomerID IN VARCHAR2,
                            ps_LangCD IN VARCHAR2,
                            ps_StartDate IN VARCHAR2,
                            ps_EndDate IN VARCHAR2,
                            ps_IPAdress IN VARCHAR2,
                            ps_PersonID IN VARCHAR2,
                            ps_SessionID IN VARCHAR2,
                            pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
---------------------------------------------------------------------------
FUNCTION SetSuperUser( ps_chanelcd    IN VARCHAR2,
                       ps_personid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------
FUNCTION AddToken(ps_tokenid IN VARCHAR2,
                       ps_chanelcd    IN VARCHAR2,
                       ps_personid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------
FUNCTION DeleteToken(ps_personid IN VARCHAR2,ps_channelid IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

---------------------------------------------------------------------------
FUNCTION ActivityDetail(ps_activity IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------
FUNCTION GetAdminPerson(ps_channelid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------
FUNCTION GetAdminAuth(ps_personid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------
FUNCTION CheckRetailControl(ps_customerid IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------
FUNCTION listallcintuser(ps_channelid IN  VARCHAR2,
                         pc_ref       OUT cursorreferencetype) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetPassIDList(ps_customerid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetPersonName(ps_personid IN VARCHAR2) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetSystemMessage(ps_dummy IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION DelParola( ps_channelcd IN VARCHAR2,
                      ps_personid IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetApprovalTrans(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                        ps_langid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
 -----------------------------------------------------
FUNCTION GetSpecApprovalTrans(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                        ps_langid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
 -----------------------------------------------------
FUNCTION ControlTranAuth(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------
FUNCTION ControlSpecTranAuth(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------
FUNCTION SPLIT(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2;
--------------------------------------------------------------------------------------
FUNCTION SetApproval(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_check    IN VARCHAR2,
                       ps_verify    IN VARCHAR2,
                       ps_approve    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                       ps_currency     IN VARCHAR2,
                       ps_rates        IN VARCHAR2,
                       ps_flag        IN VARCHAR2,
                       ps_swift_specGroup IN VARCHAR2, --ChyngyzO cq509 17.03.15
                       ps_salaryCurrency IN VARCHAR2, --ChyngyzO cq4960 28.12.15
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION SetSpecApproval(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_check    IN VARCHAR2,
                       ps_verify    IN VARCHAR2,
                       ps_approve    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                       ps_currency     IN VARCHAR2,
                       ps_rates        IN VARCHAR2,
                       ps_flag        IN VARCHAR2,
                       ps_swift_specGroup IN VARCHAR2, --ChyngyzO cq509 17.03.15
                       ps_salaryCurrency IN VARCHAR2, --ChyngyzO cq4960 28.12.15
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION GetGnLimitInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION SetGnLimitInfo(ps_trancd IN VARCHAR2,
                        ps_limit IN VARCHAR2,
                        ps_cycode IN VARCHAR2,
                        ps_tr IN VARCHAR2,
                        ps_customer IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION GetSpecGnLimitInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION SetSpecGnLimitInfo(ps_trancd IN VARCHAR2,
                        ps_limit IN VARCHAR2,
                        ps_cycode IN VARCHAR2,
                        ps_tr IN VARCHAR2,
                        ps_customer IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION SetUserAuthForAdminSite(ps_personid IN VARCHAR2,
                        ps_channelid     IN VARCHAR2,
                       ps_viewstr     IN VARCHAR2,
                       ps_makestr     IN VARCHAR2,
                       ps_verifystr     IN VARCHAR2,
                       ps_checkstr     IN VARCHAR2,
                       ps_approvestr IN VARCHAR2,
                       ps_makerid     IN VARCHAR2,
                       pn_amount     IN VARCHAR2,
                       pn_cust       IN VARCHAR2,
                       ps_cycode     IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION SetSpecUserAuthForAdminSite(ps_personid IN VARCHAR2,
                        ps_channelid     IN VARCHAR2,
                       ps_viewstr     IN VARCHAR2,
                       ps_makestr     IN VARCHAR2,
                       ps_verifystr     IN VARCHAR2,
                       ps_checkstr     IN VARCHAR2,
                       ps_approvestr IN VARCHAR2,
                       ps_makerid     IN VARCHAR2,
                       pn_amount     IN VARCHAR2,
                       pn_cust       IN VARCHAR2,
                       ps_cycode     IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION GetVerifyApproveToDo(ps_customerID IN VARCHAR2,
                        ps_channelCD IN VARCHAR2,
                        ps_PersonID IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION GetVerifyApproveTranInfo(ps_txNo IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION GetAuthCodesLimit( ps_channelcd IN VARCHAR2,
                        ps_customer_id    IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION GetSpecAuthCodesLimit( ps_channelcd IN VARCHAR2,
                        ps_customer_id    IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION NeedApprove( ps_customer_id    IN VARCHAR2,
                       ps_tran IN VARCHAR2,
                      ps_controlstr IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------------
FUNCTION GetUserInfosIR(ps_channel IN VARCHAR2,
                         ps_customer IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION GetLimitInfo( ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                        ps_langid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION GetCustomerSuperPersons(ps_customerid IN VARCHAR2,ps_channelcd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
-------------------------------------------------------------------------
FUNCTION CnclSuperUser(ps_chanelcd    IN VARCHAR2,
                       ps_personid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 ;
----------------------------------------------------------------------------
FUNCTION GetVerifyApproveControlToDo(ps_statuscd IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION CheckCurrencyControl(ps_channelcd     IN VARCHAR2,
                        ps_customer_id    IN VARCHAR2,
                        ps_tran IN VARCHAR2,
                        ps_controlstr IN VARCHAR2,
                        ps_currencycd IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetRetailLimits(ps_ChannelCd IN VARCHAR2,
                             ps_CustomerId    IN VARCHAR2,
                         ps_LangId    IN VARCHAR2,
                             pc_Ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION SetRetailLimits(ps_ChannelCd IN VARCHAR2,
                             ps_CustomerId    IN VARCHAR2,
                         ps_Amount    IN VARCHAR2,
                         ps_TranLimit IN VARCHAR2,
                         ps_Currency     IN VARCHAR2,
                         ps_TranCd IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetFxAccess(ps_customerno IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetFxAccessControl(ps_customerno IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetPassIDInquiry(ps_customerid IN VARCHAR2,
                                           ps_passid IN VARCHAR2,
                                            pd_startdate       IN VARCHAR2,
                                           pd_enddate      IN VARCHAR2,
                                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION GetUserInfosCR(ps_customerid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION getActivityPersonInfo(ps_activity_nbr IN NUMBER) RETURN VARCHAR2;
-----------------------------------------------------------------------------
FUNCTION getuserinfo (ps_channelcd     IN       VARCHAR2,
                      ps_customer_id   IN       VARCHAR2,
                      ps_personid      IN       VARCHAR2,
                      ps_username      IN       VARCHAR2,
                      ps_useralias     IN       VARCHAR2,
                      ps_status        IN       VARCHAR2,
                      pc_ref           OUT      cursorreferencetype) RETURN VARCHAR2;

FUNCTION getuserauthinfo (ps_customer_id   IN       VARCHAR2,
                          ps_personid      IN       VARCHAR2,
                          ps_name          IN       VARCHAR2,
                          pc_ref           OUT      cursorreferencetype) RETURN VARCHAR2;

FUNCTION getauthname (ps_authcd IN VARCHAR2) RETURN VARCHAR2;

FUNCTION gettrancd (ps_authcd IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

FUNCTION gettranname (ps_trancd IN VARCHAR2) RETURN VARCHAR2;

Function Statics(ps_chanelcd in varchar2,
                 ps_queryno  in varchar2,
                 pc_ref      out CursorReferenceType) return varchar2;

FUNCTION GetDebugLog(ps_startdate IN  VARCHAR2,
                     ps_enddate   IN  VARCHAR2,
                     pc_ref       OUT CursorReferenceType) RETURN VARCHAR2;

FUNCTION baglantirpr (ps_dummy IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

FUNCTION bankaistatistikleri(ps_option IN  VARCHAR2,
                             ilk_tarih IN  VARCHAR,
                             son_tarih IN  VARCHAR,
                             pc_ref    OUT cursorreferencetype) RETURN VARCHAR2;

FUNCTION GetDetailedUserInfoList(ps_option          IN VARCHAR2,
                                 ps_start_date      IN VARCHAR2,
                                 ps_end_date        IN VARCHAR2,
                                 ps_status_cd       IN VARCHAR2,
                                 ps_channel_cd      IN VARCHAR2,
                                 ps_customer_type   IN VARCHAR2,
                                 pc_ref             OUT cursorreferencetype) RETURN VARCHAR2;

/*******************************************************************************
    Name:   GetSpecialCustomerDetails
    Prepared By:    Chyngyz Omurov
    Date:   17.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:   for keeping special customer details in Corp IB, specifically it keeps if customer is in special group
    who can send swift in special time interval
*******************************************************************************/

FUNCTION GetSpecialCustomerDetails(ps_customerno IN VARCHAR2,
                                                                   ps_pendingTx IN VARCHAR2 DEFAULT '0',  --ChyngyzO cq4960 Salary Payments 28.12.2015, set to 1 to get pending approval values
                                                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
                                                                   
                                                                   
-----------------------------------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION UpdateUserName
   Prepared By : Nursultan Mukhambet uulu
   Date        : 15.12.2021
******************************************************************************/
FUNCTION UpdateUserName( ps_personid IN VARCHAR2,
                       ps_name IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2; 
                           
---------------------------------------------
/******************************************************************************
   NAME        : FUNCTION CopyPayee
   Prepared By : Nursultan Mukhambet uulu
   Date        : 20.12.2021
******************************************************************************/
FUNCTION CopyPayee( ps_personid IN VARCHAR2,
                    ps_copypersonid IN VARCHAR2,
                    ps_payeeid IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
                    
/******************************************************************************
   NAME        : FUNCTION GetBeneSwiftLimits
   Prepared By : Nursultan Mukhambet uulu
   Date        : 06.04.2022
******************************************************************************/   
FUNCTION GetBeneSwiftLimits( 
    ps_trancd IN VARCHAR2,
    ps_customerid    IN VARCHAR2,
    ps_langid    IN VARCHAR2,
    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
END;
/

