create PACKAGE         "PKG_CINT_AUTHORITY" IS

TYPE CursorReferenceType IS REF CURSOR;

-----------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  GetUserInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Return User Information and last login date
******************************************************************************/
FUNCTION CheckTicket(pn_sessionid   IN NUMBER,
                     ps_ticketid    IN VARCHAR2,
                     ps_channelcd   IN VARCHAR2,
                     ps_trancd      IN VARCHAR2,
                     ps_pageid      IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  MultipleCheckCustomerSession
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Check Customer Session and get menu
******************************************************************************/
FUNCTION MultipleCheckCustomerSession(ps_channelcd IN VARCHAR2,
                                      ps_sessionid IN VARCHAR2,
                                      ps_ticketid  IN VARCHAR2,
                                      ps_langid    IN VARCHAR2,
                                      ps_personid  IN VARCHAR2,
                                      ps_trancd    IN VARCHAR2,
                                      ps_pageid    IN VARCHAR2,
                                      pc_ref OUT CursorReferenceType,
                                      pc_ref2 OUT CursorReferenceType,
                                      pc_ref3 OUT CursorReferenceType,
                                      pc_ref4 OUT CursorReferenceType,
                                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetLabelInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Get Label Info
******************************************************************************/
PROCEDURE  GetLabelInfo(ps_channelcd IN VARCHAR2,
                        ps_trancd    IN VARCHAR2,
                        ps_pageid    IN VARCHAR2,
                        ps_langcd    IN VARCHAR2,
                        ps_personid  IN VARCHAR2,
                        pc_ref OUT CursorReferenceType);
/******************************************************************************
   NAME       : FUNCTION  GetMainMenuInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose   : Get Main Menu Info
******************************************************************************/
PROCEDURE  GetMainMenuInfo(ps_channelcd IN VARCHAR2,
                           ps_trancd    IN VARCHAR2,
                           ps_pageid    IN VARCHAR2,
                           ps_langcd    IN VARCHAR2,
                           ps_personid  IN VARCHAR2,
                           pc_ref OUT CursorReferenceType);

/******************************************************************************
   NAME       : FUNCTION  GetSubMenuInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Get Sub Menu Info
******************************************************************************/
PROCEDURE  GetSubMenuInfo(ps_channelcd IN VARCHAR2,
                          ps_trancd    IN VARCHAR2,
                          ps_pageid    IN VARCHAR2,
                          ps_langcd    IN VARCHAR2,
                          ps_personid  IN VARCHAR2,
                             pc_ref OUT CursorReferenceType);
/******************************************************************************
   NAME       : FUNCTION  GetNewsInfo
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Get New Info
******************************************************************************/
PROCEDURE  GetNewsInfo(ps_channelcd IN VARCHAR2,
                          ps_trancd    IN VARCHAR2,
                          ps_pageid    IN VARCHAR2,
                       ps_langcd    IN VARCHAR2,
                       ps_personid  IN VARCHAR2,
                          pc_ref OUT CursorReferenceType);
/******************************************************************************
   NAME       : FUNCTION  ChangeAlias
   Created By : Muzaffar Khalyknazarov
   Date       : 22.11.07
   Purpose    : Change Alias
******************************************************************************/
FUNCTION ChangeAlias(ps_channelcd   IN VARCHAR2,
                     pn_personid    IN VARCHAR2,
                     ps_newusername IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  ChangePwdPin
   Created By : Muzaffar Khalyknazarov
   Date       : 07.12.07
   Purpose    : Change Password or Pin
******************************************************************************/
FUNCTION ChangePwdPin(ps_option    IN VARCHAR2,
                      ps_channelcd IN VARCHAR2,
                      pn_personid  IN VARCHAR2,
                      ps_oldcode   IN VARCHAR2,
                      ps_newcode   IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  SetTokenData
   Created By : Muzaffar Khalyknazarov
   Date       : 07.12.07
   Purpose    : Change Pin and Password
******************************************************************************/
FUNCTION SetTokenData(ps_DIGIPASS IN VARCHAR2,
                      ps_DIGIDATA IN VARCHAR2,
                      pc_ref OUT CursorReferenceType)RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  SafeExit
   Created By : Muzaffar Khalyknazarov
   Date       : 11.12.07
   Purpose    : Safe Exit
******************************************************************************/
FUNCTION SafeExit(pn_sessionid IN NUMBER,
                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  CheckUserNameandPassword
   Created By : Muzaffar Khalyknazarov
   Date       : 12.12.07
   Purpose    : Safe Exit
******************************************************************************/
FUNCTION CheckUserNameandPassword(ps_channelcd IN VARCHAR2,
                                  ps_username  IN VARCHAR2,
                                  ps_password  IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  CheckUserPinCode
   Created By : Muzaffar Khalyknazarov
   Date       : 12.12.07
   Purpose    : Check pin code
******************************************************************************/
FUNCTION CheckUserPinCode(ps_channelcd IN VARCHAR2,
                          ps_pincode   IN VARCHAR2,
                          ps_sessionid IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  CheckUserPinCode
   Created By : Muzaffar Khalyknazarov
   Date       : 12.12.07
   Purpose    : Check pin code
******************************************************************************/
FUNCTION GetParentMenuID(ps_trancd VARCHAR2,ps_channelcd VARCHAR2) RETURN VARCHAR2;
--------------------------------------------------------------------------------
/******************************************************************************
   NAME       : FUNCTION  CheckUser
   Created By : Muzaffar Khalyknazarov
   Date       : 24.12.07
   Purpose    : Check User
******************************************************************************/
FUNCTION CheckUser( ps_channelcd IN VARCHAR2,
                    ps_username IN VARCHAR2,
                    ps_passcode IN VARCHAR2,
                    ps_pincode IN VARCHAR2,
                    pn_ClientIP IN VARCHAR2,
                    pn_sessionid OUT NUMBER,
                    ps_ticketid OUT VARCHAR2,
                    pn_personid OUT NUMBER,
                    ps_pwdforcechange OUT VARCHAR2,
                    ps_tokenid OUT VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  CheckAvailableEtoken
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Check Available Etoken
******************************************************************************/
FUNCTION CheckAvailableEtoken(ps_channelcd IN VARCHAR2,
                              ps_username IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  GetCustomerTokenData
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Get Customer Token Data
******************************************************************************/
FUNCTION GetCustomerTokenData(ps_username IN VARCHAR2,
                              pc_ref OUT CursorReferenceType
                              )RETURN VARCHAR2;


/******************************************************************************
   NAME       : FUNCTION  SetWrongTokenAttemp
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Set Wrong Token Attemp
******************************************************************************/
FUNCTION SetWrongTokenAttemp(ps_channelcd IN VARCHAR2,
                             ps_username IN VARCHAR2,
                             pc_ref OUT CursorReferenceType
                             )RETURN VARCHAR2;


/******************************************************************************
   NAME       : FUNCTION  SetSessionStatus
   Created By : Tastan Zhaylibayev
   Date       : 25.02.08
   Purpose    : Set Session Status
******************************************************************************/
FUNCTION SetSessionStatus(ps_DIGIPASS IN VARCHAR2,
                             pc_ref OUT CursorReferenceType
                          )RETURN VARCHAR2;

FUNCTION AssignCustomerAccounts(ps_CustomerNo IN VARCHAR2,
                                 ps_PersonID      IN VARCHAR2,
                                ps_Params      IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

FUNCTION CheckUserForPartner( ps_channelcd IN VARCHAR2,
                    ps_username IN VARCHAR2,
                    ps_passcode IN VARCHAR2,
                    ps_pincode IN VARCHAR2,
                    pn_sessionid OUT NUMBER,
                    ps_ticketid OUT VARCHAR2,
                    pn_personid OUT NUMBER,
                    ps_pwdforcechange OUT VARCHAR2,
                    ps_tokenid OUT VARCHAR2) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  IBCheckTicket
   Created By : Muzaffar Khalyknazarov
   Date       : 03.05.08
   Purpose   : Check Ticket
******************************************************************************/

FUNCTION IBCheckTicket(pn_sessionid   IN NUMBER,
                       ps_ticketid    IN VARCHAR2,
                         ps_channelcd   IN VARCHAR2,
                          ps_trancd      IN VARCHAR2,
                       ps_pageid      IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  IBMultipleCheckCustomerSession
   Created By : Muzaffar Khalyknazarov
   Date       : 03.06.08
   Purpose   : MultipleCheckCustomerSession
******************************************************************************/
FUNCTION IBMultipleCheckCustomerSession(ps_channelcd IN VARCHAR2,
                                      ps_sessionid IN VARCHAR2,
                                      ps_ticketid  IN VARCHAR2,
                                      ps_langid    IN VARCHAR2,
                                      ps_personid  IN VARCHAR2,
                                      ps_trancd    IN VARCHAR2,
                                      ps_pageid    IN VARCHAR2,
                                      pc_ref  OUT CursorReferenceType,
                                      pc_ref2 OUT CursorReferenceType,
                                      pc_ref3 OUT CursorReferenceType,
                                      pc_ref4 OUT CursorReferenceType,
                                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  SetStatus
   Created By : Muzaffar Khalyknazarov
   Date       : 13.06.08
   Purpose   : SetStatus
******************************************************************************/
FUNCTION SetStatus(ps_txNo                IN VARCHAR2,
                   ps_customerid          IN VARCHAR2,
                   ps_verifiedapprovedid  IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  SetVerifyUpdateFlag
   Created By : Muzaffar Khalyknazarov
   Date       : 13.06.08
   Purpose   : SetVerifyUpdateFlag
******************************************************************************/
FUNCTION SetVerifyUpdateFlag(ps_txNo               IN VARCHAR2,
                             ps_customerid         IN VARCHAR2,
                             ps_verifiedapprovedid IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

FUNCTION CheckTicketAlert(ps_count      IN VARCHAR2,
                          ps_sessionid  IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  SWIFTTODO
   Created By : Almas NURKHOZHAYEV
   Date       : 23.01.11
   Purpose   : Save SWIFT info to ToDo List
******************************************************************************/
FUNCTION SWIFTTODO(pn_amount        IN VARCHAR2,
                   ps_currency      IN VARCHAR2,
                   pn_accountid     IN VARCHAR2,
                   ps_ulkekodu      IN VARCHAR2,
                   pd_valor_tarihi  IN VARCHAR2,
                   ps_aciklama      IN VARCHAR2,
                   ps_acilistarihi  IN VARCHAR2,
                   ps_PayeeName     IN VARCHAR2,
                   ps_PayeeAddress  IN VARCHAR2,
                   pn_toAccountNo   IN VARCHAR2,
                   ps_muhabirmasraf IN VARCHAR2,
                   pn_paymentno     IN VARCHAR2,
                   ps_swiftcode     IN VARCHAR2,
                   ps_statcode      IN VARCHAR2,
                   ps_BankName      IN VARCHAR2,
                   pn_CHARGE_AMOUNT IN VARCHAR2,
                   ps_telpass       IN VARCHAR2,
                   ps_RecDesc       IN VARCHAR2,
                   ps_Recvisite     IN VARCHAR2,
                   ps_CityName      IN VARCHAR2,
                   pn_person        IN VARCHAR2,
                   ps_TranStatus    IN VARCHAR2,
                   pn_CommAccount   IN VARCHAR2,
                   pc_ref           OUT cursorreferencetype) RETURN VARCHAR2;

FUNCTION OTPPassword(ps_option        IN VARCHAR2,
                     pn_pwd_id        IN VARCHAR2,
                     pn_person_id     IN VARCHAR2,
                     ps_mobile_number IN VARCHAR2,
                     ps_otp_pwd       IN VARCHAR2,
                     ps_session_id    IN VARCHAR2,
                     ps_result        IN VARCHAR2,
                     pc_ref           OUT cursorreferencetype) RETURN VARCHAR2;

FUNCTION ChngPinbyID(ps_tokenid IN VARCHAR2,
                     ps_pincode IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME       : FUNCTION  GetRetailClientPwdType,UpdateRetailClientPwdType
   Created By : NURHAT UCA
   Date       : 02.11.2012
   Purpose   : Returns users pwd type -SDLC00020992
******************************************************************************/
FUNCTION GetRetailClientPwdType(ps_customerId IN VARCHAR2) RETURN VARCHAR2;

FUNCTION UpdateRetailClientPwdType(ps_customerId IN VARCHAR2,
                                    ps_personId   IN VARCHAR2,
                                   ps_otpChoice IN VARCHAR2) RETURN VARCHAR2;
END Pkg_Cint_Authority;
/

