create trigger TRG_SETCUSTOMERID_TXTODO
    before insert
    on TBL_TXTODO
    for each row
declare 
begin 
 SELECT p.CUSTOMER_ID INTO :new.CUSTOMER_ID FROM CORPINT.TBL_PERSON P WHERE P.PERSON_ID=:new.MAKERID;
END;
/

