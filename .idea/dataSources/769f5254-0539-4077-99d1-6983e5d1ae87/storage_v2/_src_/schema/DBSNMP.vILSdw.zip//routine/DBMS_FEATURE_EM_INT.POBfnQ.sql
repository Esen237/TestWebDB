create PROCEDURE dbms_feature_em_int
(feature_boolean OUT number,
 aux_count       OUT number,
 info            OUT clob,
 l_src           IN  varchar2)
AS
BEGIN
 select count(1), null, null
   into feature_boolean, aux_count, info
   from dbsnmp.mgmt_db_feature_log a
  where a.source = l_src
    and CAST(a.last_update_date AS DATE) >=
         (select nvl(max(last_sample_date), sysdate-7)
            from sys.wri$_dbu_usage_sample);
END;
/

