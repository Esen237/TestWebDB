create view MGMT_BSLN_BASELINES (BSLN_GUID, TARGET_UID, NAME, TYPE, SUBINTERVAL_KEY, STATUS) as
select bb.bsln_guid
      ,bsln.target_uid(bb.dbid, i.instance_number)
      ,ab.baseline_name
      ,DECODE(ab.baseline_type,
              'MOVING_WINDOW', 'R',
                               'S')
      ,bb.timegrouping
      ,bb.status
  from bsln_baselines bb, dba_hist_baseline_metadata ab, gv$instance i
 where ab.dbid = bb.dbid
   and ab.baseline_id = bb.baseline_id
   and bb.instance_name = i.instance_name
   and ab.baseline_type in ('MOVING_WINDOW', 'STATIC', 'GENERATED')
/

comment on table MGMT_BSLN_BASELINES is 'Database Metric Baselines (10.2)'
/

