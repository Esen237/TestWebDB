create procedure recover_balance 
is 
    cursor acc_cur is 
    select * 
      from accounts a, (select acc_ref, sum (case when dt=1 then -1*sum else sum end) saldo_sum from records group by acc_ref ) r
     where a.id = r.acc_ref
       and a.saldo <> r.saldo_sum
       for update of saldo; --заблокировать столбец saldo строк с дисбалансами, чтобы клиент не смог воспользоваться счетом
    
    acc_rec acc_cur%rowtype;
begin
    open acc_cur; --открытие курсора и блокировка баланса всех строк в курсоре
    loop
        fetch acc_cur into acc_rec; 
        exit when acc_cur%notfound;
        
        update accounts 
           set saldo = acc_rec.saldo_sum 
         where id = acc_rec.id;
        
    end loop;
    
    commit; -- фиксация изменений и снятие блокировки
end;
/

