create view TBLIDENTIFICATIONVIEW as
select idf.person_id as PERSONID, 
                                                        idf.useralias as USERALIAS, 
                                                        idf.customer_no as CUSTOMERNO,
                                                        idf.passcode as USERPASSWORD, 
                                                        idf.pincode as PINCODE, 
                                                        idf.fullname as FULLNAME, 
                                                        idf.status_cd as STATUS
                                                from corpint2.tbl_identification idf
/

