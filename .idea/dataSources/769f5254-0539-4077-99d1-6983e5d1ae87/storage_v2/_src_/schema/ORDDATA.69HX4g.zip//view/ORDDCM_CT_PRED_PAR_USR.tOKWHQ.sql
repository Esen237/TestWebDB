create view ORDDCM_CT_PRED_PAR_USR as
select PID, PARNAME, PARVAL
  from ORDDATA.ORDDCM_CT_PRED_PAR_TMP
  with read only
/

