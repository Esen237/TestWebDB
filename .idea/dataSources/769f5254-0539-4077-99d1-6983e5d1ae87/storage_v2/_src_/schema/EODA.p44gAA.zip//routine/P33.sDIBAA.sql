create procedure p33 
as
begin
	dbms_output.put_line('hhh');
exception when others then null;
end;
/

