create package state_pkg 
is 
    type array is table of t_hashed.object_id%type;
    g_data array;
end;
/

