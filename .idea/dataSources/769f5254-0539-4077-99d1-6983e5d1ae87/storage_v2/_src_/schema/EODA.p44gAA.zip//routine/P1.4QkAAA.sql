create procedure p1 is
begin
null;
end;
/

