create procedure do_update (p_n in number ) 
as 
    pragma autonomous_transaction;
    l_rec t%rowtype;
    resource_busy exception ;
    pragma exception_init (resource_busy, -54);
begin
    select * 
      into l_rec
      from t 
     where x = p_n 
       for update NOWAIT;
    do_update(p_n+1);
    commit;
exception 
    when resource_busy then 
        dbms_output.put_line('locked out trying to selet row ' || p_n);
        commit;
    when no_data_found then 
        dbms_output.put_line('we finished - no problems');
        commit;
end;
/

