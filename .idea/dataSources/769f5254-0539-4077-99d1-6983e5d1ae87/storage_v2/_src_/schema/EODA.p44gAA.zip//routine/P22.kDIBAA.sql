create procedure p22
    as
   begin
      insert into t values(1);
      insert into t values(-1);
   end;
/

