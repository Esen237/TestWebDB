create package demo_pkg is
type array is table of char(2000) index by binary_integer;
g_data array;
end;
/

