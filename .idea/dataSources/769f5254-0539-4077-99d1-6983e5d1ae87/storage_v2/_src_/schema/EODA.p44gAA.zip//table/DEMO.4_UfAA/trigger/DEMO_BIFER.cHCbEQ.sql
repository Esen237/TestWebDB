create trigger DEMO_BIFER
    before insert
    on DEMO
    for each row
declare
	l_lock_id number;
	resource_busy exception;
	pragma exception_init(resource_busy,-54);
begin
	l_lock_id :=
		dbms_utility.get_hash_value(to_char(:new.x), 0, 1024);
	if (dbms_lock.request
		(id		=> l_lock_id,
		lock_mode	=> dbms_lock.x_mode,
		timeout		=> 0,
		release_on_commit => true) not in (0,4))
	then
		raise resource_busy;
	end if;
end;
/

