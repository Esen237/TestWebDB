create view EMP1_V as
select ename, substr(my_soundex(ename),1,6) ename_soundex, hiredate from emp1
/

