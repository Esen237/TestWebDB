create package stats_pkg as
    cnt number default 0;
end;
/

