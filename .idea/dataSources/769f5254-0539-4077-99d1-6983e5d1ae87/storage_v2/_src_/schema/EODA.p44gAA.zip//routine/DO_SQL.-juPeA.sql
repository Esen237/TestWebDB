create procedure do_sql (p_sql in varchar2) 
as 
    l_start_redo number;
    l_redo number;
begin
    l_start_redo := get_stat_val('redo size');
    execute immediate p_sql;
    commit;
    l_redo := get_stat_val('redo size') - l_start_redo;
    dbms_output.put_line(
        to_char(l_redo, '99,999,999') || ' bytes of redo geerated for "' ||
            substr(replace(p_sql, chr(10), ''),1,25) || '"...'
    );
end;
/

