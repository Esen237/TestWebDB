create type person_type as object
(
    name            varchar2(30),
    dob             date,
    home_address    address_type,
    work_address    address_type
);
/

