create type address_type as object 
(
    city    varchar2(30),
    street  varchar2(30),
    state   varchar2(2),
    zip     number
);
/

