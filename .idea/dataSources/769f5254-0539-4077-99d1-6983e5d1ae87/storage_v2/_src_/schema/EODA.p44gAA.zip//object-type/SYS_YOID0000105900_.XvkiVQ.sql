create type        "SYS_YOID0000105900$"              as object( "NAME" VARCHAR2(30 BYTE))
/

