create PACKAGE BODY           pkg_parametre IS
  PROCEDURE Deger (pKod in varchar2, pdeger out number) is
  begin
    select to_number(p.deger)
      into pdeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod ||pkg_hata.getUCPOINTER);
  end;

  PROCEDURE Deger (pKod in varchar2, pdeger out varchar2) is
  temp_Deger varchar2(2000);
  begin
    select p.deger
      into temp_Deger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    pdeger  := substr(temp_deger,2,length(temp_deger)-2);
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod||pkg_hata.getUCPOINTER);
  end;

  PROCEDURE Deger (pKod in varchar2, pdeger out date) is
  begin
    select to_date(p.deger,'dd/mm/yyyy')
      into pdeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod||pkg_hata.getUCPOINTER);
  end;

  PROCEDURE Deger (pKod in varchar2, pdeger out boolean) is
    ddeger varchar2(5);
  begin
    select DECODE(UPPER(TRIM(deger)),'T','TRUE','1','TRUE','D','TRUE','FALSE')
      into ddeger
      from cbs_parametre p
     where p.tur in ('G','T')
       and p.kod=pKod;
    pdeger:=ddeger='TRUE';
  exception
    when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1115'|| pkg_hata.getDELIMITER ||pKod||pkg_hata.getUCPOINTER);
  end;


END;
/

