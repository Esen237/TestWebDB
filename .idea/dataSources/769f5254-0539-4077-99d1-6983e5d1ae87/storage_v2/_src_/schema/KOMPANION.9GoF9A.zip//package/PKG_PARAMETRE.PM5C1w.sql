create PACKAGE           pkg_parametre IS
  PROCEDURE Deger (pKod in varchar2, pdeger out number);
  PROCEDURE Deger (pKod in varchar2, pdeger out date);
  PROCEDURE Deger (pKod in varchar2, pdeger out varchar2);
  PROCEDURE Deger (pKod in varchar2, pdeger out boolean);

END;
/

