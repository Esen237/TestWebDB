create PACKAGE BODY               Pkg_ATM_Api IS

/************************************************************************************* */
----------------------------------------------------------------------------------------
 FUNCTION GetErrorCode(ps_errortext IN VARCHAR2) RETURN VARCHAR2 IS
    ls_returncode           VARCHAR2(3) := '096';
 BEGIN

    IF  INSTR(ps_errortext,'-1403') > 0     THEN
        ls_returncode:='051'; --Bakiye yetersiz
    ELSIF  INSTR(ps_errortext,'-1578') > 0     THEN
        ls_returncode:='051'; --Bakiye yetersiz
    ELSIF  INSTR(ps_errortext,'-1575') > 0     THEN
        ls_returncode:='051'; --Bakiye yetersiz
    ELSIF INSTR(ps_errortext,'-441') > 0     THEN
        ls_returncode:='051' ; -- bakiye yetersiz hatasi
    ELSIF  INSTR(ps_errortext,'-1156') > 0     THEN -- hesap bulunamadi hatas?
        ls_returncode:='205';
    ELSIF INSTR(ps_errortext,'-1704') > 0    THEN -- hesap bulunamadi hatas?
        ls_returncode:='205';
    ELSIF INSTR(ps_errortext,'-1487') > 0    THEN
        ls_returncode:='051'; -- bakiye yetersiz hatasi
    ELSIF  INSTR(ps_errortext,'-1171') > 0    THEN
        ls_returncode:='205'; -- INVALID ACCOUNT NUMBER --Hesap no mevcut degil ise
    ELSE
        ls_returncode:='096'; --System Error
    END IF;

    RETURN ls_returncode;

  Exception when others then
      log_at('ps_errortext',ps_errortext,sqlcode,sqlerrm);
              RETURN ls_returncode;


 END;
----------------------------------------------------------------------------------------
FUNCTION GetErrorDesc(
                        ps_errorcd IN VARCHAR2 ,
                        ps_langcd    IN VARCHAR2 DEFAULT 'ENG',
                       ps_systemcd IN VARCHAR2 DEFAULT 'CBS'
                       ) RETURN VARCHAR2 IS


     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_aciklama          VARCHAR2(2000) :='EXCEPTION ERROR';
     ls_langcd              VARCHAR2(3):='ENG';
     ls_systemcd          VARCHAR2(10):='CBS';
     ls_errorcd              VARCHAR2(200):=NULL;

     CURSOR cur_error IS
          SELECT NVL(e.USER_DESC,e.ERROR_DESC) description
         FROM cbs_atm_error_mesajlari e
         WHERE e.SYSTEM_CD=NVL(ls_systemcd,e.SYSTEM_CD)
         AND  e.ERROR_CD=NVL(ps_errorcd,e.ERROR_CD)
         AND e.LANG_CD=NVL(ls_langcd,e.LANG_CD)
         ORDER BY e.SYSTEM_CD,e.ERROR_CD,e.LANG_CD;

BEGIN

      IF ps_systemcd='' THEN
         ls_systemcd:=NULL;
     ELSE
          ls_systemcd:=ps_systemcd;
     END IF;

       IF ps_errorcd='' THEN
         ls_errorcd:=NULL;
     ELSE
          ls_errorcd:=ps_errorcd;
     END IF;

     IF ps_langcd='' THEN
         ls_langcd:=NULL;
     ELSE
         ls_langcd:=ps_langcd;
     END IF;

     FOR c_error IN cur_error LOOP
          ls_aciklama := c_error.description ;
     END LOOP;

     RETURN ls_aciklama;

EXCEPTION
--'ERROR IS NOT DEFINED IN ERROR TABLE';
        WHEN OTHERS THEN   RETURN 'EXCEPTION ERROR';
END;
----------------------------------------------------------------------------------------
END;
/

