create PACKAGE BODY           PKG_COMMON IS

FUNCTION  get_common_id(ps_code_name IN VARCHAR2) RETURN NUMBER IS
  PRAGMA AUTONOMOUS_TRANSACTION;

  ln_ret_val NUMBER;

  CURSOR cur_c1 IS
    SELECT * FROM TBL_COMMON_CODE
    WHERE code_name = ps_code_name FOR UPDATE;

  row_c1 TBL_COMMON_CODE%ROWTYPE;

BEGIN
    IF cur_c1%ISOPEN THEN
       CLOSE cur_c1;
    END IF;

    OPEN cur_c1;
    FETCH cur_c1 INTO row_c1;

    IF  cur_c1%NOTFOUND THEN
      CLOSE cur_c1;
      INSERT INTO TBL_COMMON_CODE
                  (code_name, code_val, last_user, last_date, user_created, creation_date)
           VALUES (ps_code_name, 1, USER, SYSDATE, USER, SYSDATE);
      ln_ret_val := 1;
     ELSE
       ln_ret_val := row_c1.code_val + 1;
       UPDATE TBL_COMMON_CODE
         SET code_val=code_val + 1,
             last_user = USER,
             last_date = SYSDATE
        WHERE CURRENT OF cur_c1;
     END IF;
     COMMIT;
     RETURN(ln_ret_val );
EXCEPTION
      WHEN OTHERS THEN
      log_at('get_common_id',ps_code_name, SUBSTR(SQLERRM,1,2000), DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;    
------------------------------------------------------------------------------

PROCEDURE get_param_value (ps_param_code in varchar2, pn_param_value out number) is
  begin
    select to_number(p.VALUE)
      into pn_param_value
      from TBL_PARAMETER p
     where p.TYPE in ('G','T')
       and p.CODE=ps_param_code;
  exception
    when others then
      Raise_application_error(-20100,pkg_error.getUCPOINTER||'1115'|| pkg_error.getDELIMITER ||ps_param_code ||pkg_error.getUCPOINTER);
  end;
  

END;
/

