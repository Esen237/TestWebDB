create PACKAGE           PKG_COMMON IS
   --TYPE T_REFCUR IS REF CURSOR;
   FUNCTION  get_common_id(ps_code_name IN VARCHAR2) RETURN NUMBER;
END;
/

