create PACKAGE BODY           pkg_atm IS
------------------------------------------------------------------------------
Procedure GetTranCode(ps_gelen_message varchar2,ps_transaction_code out varchar2)
is
  ls_header_message                   varchar2(2000);
Begin
    ps_transaction_code := substr(ps_gelen_message,9,4);
EXCEPTION
      WHEN OTHERS THEN
      log_at('GetTranCode',ps_gelen_message,SQLCODE,SUBSTR(SQLERRM,1,2000));
End;
------------------------------------------------------------------------------

Procedure Parse_Incoming_Message(ps_gelen_message        varchar2,
                                  ps_ayrilan_message  out varchar2,
                                 ps_transaction_name out varchar2,
                                 ps_transaction_code out varchar2,
                                 ps_Orig_authorization_reversal out varchar2,
                                 ps_user                 out varchar2,
                                 ps_transaction_type  out varchar2,
                                 ps_source_code        out    varchar2,
                                 ps_terminal_type        out varchar2,
                                 ps_branch            out    varchar2,
                                 ps_terminal_id        out varchar2,
                                 ps_transaction_date   out varchar2,
                                 ps_transaction_time  out varchar2,
                                 ps_reference_number    out varchar2)

is
  ls_header_message                   varchar2(2000);
  ls_gelen_message                   varchar2(2000);
Begin
    ls_gelen_message := substr(ps_gelen_message,5); --Ilk 4 hane uzunluk, bize lazim degil

    ps_ayrilan_message := substr(ls_gelen_message,66); --65 lik header haricindeki kisim atanir

    ls_header_message :=  substr(ls_gelen_message,1,65) ;
-- asagidaki kisim da header alanlari ayrilir.
    ps_transaction_name := pkg_atm.satir_ayir( ls_header_message   ,4  );
    ps_transaction_code := pkg_atm.satir_ayir( ls_header_message   ,4  );
    ps_Orig_authorization_reversal := pkg_atm.satir_ayir( ls_header_message   ,1  );
    ps_user := pkg_atm.satir_ayir( ls_header_message   ,8  );
    ps_transaction_type := pkg_atm.satir_ayir( ls_header_message   ,2  );
    ps_source_code := pkg_atm.satir_ayir( ls_header_message   ,2  );
    ps_terminal_type:= pkg_atm.satir_ayir( ls_header_message   ,1  );
    ps_branch:= pkg_atm.satir_ayir( ls_header_message   ,4  );

    ps_terminal_id:= pkg_atm.satir_ayir( ls_header_message   ,8  );
    ps_transaction_date:= pkg_atm.satir_ayir( ls_header_message   ,8  );
    ps_transaction_time:= pkg_atm.satir_ayir( ls_header_message   ,6  );
    ps_reference_number:= pkg_atm.satir_ayir( ls_header_message   ,17  );

EXCEPTION
      WHEN OTHERS THEN
      log_at('Parse_Incoming_Message',ps_gelen_message,SQLCODE,SUBSTR(SQLERRM,1,2000));
End;


Function StandardResponseHeader(ps_referans_number varchar2,
                                   ps_authorization_decline_flag varchar2,
                                 ps_detail_response_code    varchar2,
                                  ps_resp_explanation varchar2) return varchar2-- decline response code explanation
is
  ls_StandardResponseHeader         CHAR(58);
  ls_decline_explanation varchar2(37);
Begin

     if   nvl(ps_authorization_decline_flag,'0') = '1' then
           ls_decline_explanation := substr( nvl(ps_resp_explanation,G_DECLINE_RESPONSE_EXPLANATION),1,37);
     end if;

    ls_StandardResponseHeader:= substr(lpad(ps_referans_number,17,'0') ||
                                nvl(ps_authorization_decline_flag,'0')||
                                lpad(NVL(ps_detail_response_code,'0'),'3','0') ||
                                substr(rpad(nvl(ps_resp_explanation,' ') ,37,' '),1,37),1,58);

    return ls_StandardResponseHeader;

  Exception
    when others then
          return null;
End;

 FUNCTION  satir_ayir( ps_mesaj IN OUT VARCHAR2 ,pn_uzunluk number ) RETURN VARCHAR2 IS
  ls_mesaj      VARCHAR2(20000);
  ln_tag        NUMBER := 0;
  ls_ayrilan_mesaj      VARCHAR2(20000);
 BEGIN

    IF  ( ps_mesaj IS NOT NULL ) THEN
             ls_mesaj :=SUBSTR( ps_mesaj ,  pn_uzunluk+1 );
         ls_ayrilan_mesaj:= SUBSTR( ps_mesaj,1,pn_uzunluk);
    END IF;

    ps_mesaj :=ls_mesaj;

  RETURN ls_ayrilan_mesaj;
  EXCEPTION WHEN OTHERS THEN RETURN NULL;
 END;


FUNCTION Terminal_Active(ps_terminal_id varchar2) RETURN varchar2
is
  ls_durum varchar2(3) := 'OK';
 Begin

    /* select decode( durum_kodu,'A','OK','NOK')
     into   ls_durum
     from   cbs_atm_parametre
     where  terminal_id =trim(ps_terminal_id) and
             durum_kodu = 'A' ;
*/
     return  ls_durum;

    Exception when others then return  ls_durum;
End;

Function Time_Out(pd_start_date date, pd_end_date date) RETURN varchar2
is
    ln_par number;
    ld_max_date  date;
Begin
    Pkg_Parametre.deger('ATM_TIMEOUT_SEC',ln_par);

    ld_max_date := pd_start_date+ln_par/86400;

    if  ld_max_date < pd_end_date
    then
        return 'E';
    else
        return 'H';
    end if;
End;

Function Need_Reversal(ps_trancode varchar2) RETURN varchar2
is
Begin
    if ps_trancode in ('0090','0091','0092','0553','0555','0515','0503','1007','1009','0520',
                           '0701','0711','0607','0609','0707','0801','0805','0901','1103','1203','1110',
                        '0803','1207','1107','1103','0096','1217','1219') --sevalb 11042012 1217 ,1219  eklendi 
    then
        return 'E';
    else
        return 'H';
    end if;
End;
----------------------------------------------------------------------
FUNCTION bakiye_formatla( pn_bakiye number ) RETURN VARCHAR2
is
    ls_sayi   varchar2(19);
Begin
    select decode( sign(pn_bakiye),'-1','-','+') ||  To_char( ABS(NVL(pn_bakiye,0) ),'FM099999999999999.00')
    into ls_sayi
    from dual;

    return ls_Sayi;
End;
----------------------------------------------------------------------
FUNCTION bsof_bakiye_to_number(ps_bakiye varchar2) RETURN number
is
    ln_ret   number;
Begin
    ln_ret :=to_number(ps_bakiye);

    return ln_ret;

Exception when others then
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '1576' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER));
End;
----------------------------------------------------------------------
Procedure CURRENCY_CONVERT(ps_bsof_dvz in out varchar2,ps_our_dvz in out varchar2)
is
  ls_ret   varchar2(3);
Begin
    if ps_bsof_dvz is not null and ps_our_dvz is null
    then
      begin
        select doviz_kodu
        into   ps_our_dvz
        from   cbs_doviz_kodlari
        where  iso_code = ps_bsof_dvz;
        /*if ps_bsof_dvz = '417' then ps_our_dvz := 'KGS'; end if;
        if ps_bsof_dvz = '840' then ps_our_dvz := 'USD'; end if;
        if ps_bsof_dvz = '792' then ps_our_dvz := 'TRY'; end if;
        if ps_bsof_dvz = '978' then ps_our_dvz := 'EUR'; end if;
        */
        exception
           when others then
                  select doviz_kodu
                  into   ps_our_dvz
                  from cbs_atm_doviz_kodlari
                  where  iso_code = ps_bsof_dvz;
        end;
    end if;
    if ps_bsof_dvz is null and ps_our_dvz is not null then
          begin
            select iso_code
            into   ps_bsof_dvz
            from   cbs_doviz_kodlari
            where  doviz_kodu = ps_our_dvz;
          exception
              when others then
                     select iso_code
                   into   ps_bsof_dvz
                   from   cbs_doviz_kodlari
                   where  doviz_kodu = ps_our_dvz;
         end;
    end if;
    Exception when others then null;
         --   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '1576' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER));

End;
----------------------------------------------------------------------
FUNCTION is_reversal_received(ps_reference VARCHAR2) RETURN varchar2 IS
    ls_ret_code VARCHAR2(3) := 'N';
    ln_count NUMBER := 0;
BEGIN
    begin
        select count(*)
        into ln_count
        from cbs_atm_pos_tran_log
        where referance =trim(ps_reference) and
                  in_authorization_reversal = 'I';
    exception when no_data_found then
        ln_count := 0;
    end;
    
    if ln_count > 0 then
        ls_ret_code := 'Y';
    end if;
    
    return ls_ret_code;
END;

END;
/

