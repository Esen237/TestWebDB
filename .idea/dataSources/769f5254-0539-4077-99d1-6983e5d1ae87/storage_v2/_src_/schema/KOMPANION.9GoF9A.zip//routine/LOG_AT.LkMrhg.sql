create Procedure           log_at(pid1 varchar2, pid2 varchar2 default null,
                                   pid3 varchar2 default null, pid4 varchar2 default null) is
    pragma AUTONOMOUS_TRANSACTION;
  begin
    insert into CBS_DEBUG_LOG(d1, d2, d3, d4) values (pid1, pid2, pid3, pid4);
    commit;
  end;
/

