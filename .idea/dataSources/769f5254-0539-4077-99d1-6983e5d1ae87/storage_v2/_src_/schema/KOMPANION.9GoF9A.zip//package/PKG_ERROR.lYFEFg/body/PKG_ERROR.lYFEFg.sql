create PACKAGE BODY           PKG_ERROR IS
    
 FUNCTION GetDELIMITER RETURN VARCHAR2 IS
   BEGIN
        RETURN G_DELIMITER;
   END;
   ------------------------------------------------
   FUNCTION GetUCPOINTER RETURN VARCHAR2 IS
   BEGIN
        RETURN G_UC_POINTER;
   END;
   
END;
/

