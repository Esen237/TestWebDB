create PACKAGE BODY PKG_ATM_LOG IS
------------------------------------------------------------------------------
Procedure LogTransaction(pn_LOG_NO    in number,
                           p_MESSAGE_TYPE VARCHAR2,
                         p_REFERANCE VARCHAR2,
                         p_MESSAGE VARCHAR2,
                         p_IN_TRANSACTION_NAME VARCHAR2 default null ,
                         p_IN_TRANSACTION_CODE VARCHAR2 default null ,
                         p_IN_AUTHORIZATION_REVERSAL VARCHAR2 default null ,
                         p_IN_USER_ID_CODE VARCHAR2 default null ,
                         p_IN_TRANSACTION_TYPE VARCHAR2 default null ,
                         p_IN_SOURCE_CODE VARCHAR2 default null ,
                         p_IN_TERMINAL_TYPE VARCHAR2 default null ,
                         p_IN_BRANCH VARCHAR2 default null ,
                         p_IN_TERMINAL_ID VARCHAR2 default null ,
                         p_IN_BS_TRANSACTION_DATE VARCHAR2 default null ,
                         p_IN_BS_TRANSACTION_TIME VARCHAR2 default null ,
                         p_OUT_RESPONSE_CODE VARCHAR2 default null ,
                         p_OUT_RESPONSE_EXPLANATION VARCHAR2 default null ,
                         p_ACCOUNT_NO VARCHAR2 default null ,
                         p_CBS_TRANSACTION_NO NUMBER default null ,
                         p_ERROR_CD NUMBER default null ,
                         p_ERROR_DESC VARCHAR2 default null ,
                         p_CBS_ERROR_DESC VARCHAR2 default null ,
                         p_AMOUNT NUMBER default null ,
                         p_CURRENCY VARCHAR2 default null ,
                         p_FIELD1 VARCHAR2 default null ,
                         p_FIELD2 VARCHAR2 default null ,
                         p_FIELD3 VARCHAR2 default null ,
                         p_FIELD4 VARCHAR2 default null ,
                         p_FIELD5 VARCHAR2 default null ,
                         p_FIELD6 VARCHAR2 default null ,
                         p_FIELD7 VARCHAR2 default null ,
                         p_FIELD8 VARCHAR2 default null ,
                         p_FIELD9 VARCHAR2 default null ,
                         p_FIELD10 VARCHAR2 default null ,
                         p_FIELD11 VARCHAR2 default null ,
                         p_FIELD12 VARCHAR2 default null ,
                         p_FIELD13 VARCHAR2 default null ,
                         p_FIELD14 VARCHAR2 default null ,
                         p_FIELD15 VARCHAR2 default null)

is PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
     INSERT INTO CBS_ATM_POS_TRAN_LOG
     (LOG_NO,MESSAGE_TYPE,REFERANCE,MESSAGE,IN_TRANSACTION_NAME,IN_TRANSACTION_CODE,
      IN_AUTHORIZATION_REVERSAL,IN_USER_ID_CODE,IN_TRANSACTION_TYPE,IN_SOURCE_CODE,
      IN_TERMINAL_TYPE,IN_BRANCH,IN_TERMINAL_ID,IN_BS_TRANSACTION_DATE,IN_BS_TRANSACTION_TIME,
      OUT_RESPONSE_CODE,OUT_RESPONSE_EXPLANATION,ACCOUNT_NO,CBS_TRANSACTION_NO,ERROR_CD,
      ERROR_DESC,CBS_ERROR_DESC,AMOUNT,CURRENCY,FIELD1,FIELD2,FIELD3,FIELD4,FIELD5,FIELD6,
      FIELD7,FIELD8,FIELD9,FIELD10,FIELD11,FIELD12,FIELD13,FIELD14,FIELD15)
     VALUES
     (pn_LOG_NO,p_MESSAGE_TYPE,p_REFERANCE,p_MESSAGE,p_IN_TRANSACTION_NAME,p_IN_TRANSACTION_CODE,
      p_IN_AUTHORIZATION_REVERSAL,p_IN_USER_ID_CODE,p_IN_TRANSACTION_TYPE,p_IN_SOURCE_CODE,
      p_IN_TERMINAL_TYPE,p_IN_BRANCH,p_IN_TERMINAL_ID,p_IN_BS_TRANSACTION_DATE,p_IN_BS_TRANSACTION_TIME,
      p_OUT_RESPONSE_CODE,p_OUT_RESPONSE_EXPLANATION,p_ACCOUNT_NO,p_CBS_TRANSACTION_NO,p_ERROR_CD,
      p_ERROR_DESC,P_CBS_ERROR_DESC,p_AMOUNT,p_CURRENCY,p_FIELD1,p_FIELD2,p_FIELD3,p_FIELD4,p_FIELD5,p_FIELD6,
      p_FIELD7,p_FIELD8,p_FIELD9,p_FIELD10,p_FIELD11,p_FIELD12,p_FIELD13,p_FIELD14,p_FIELD15);
     commit;
--EXCEPTION
--      WHEN OTHERS THEN
--      log_at('LogTransactionERR',p_REFERANCE,SQLCODE,SUBSTR(SQLERRM,1,2000));

END;
------------------------------------------------------------------------------------------------------------
END;
/

