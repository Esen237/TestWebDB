create PACKAGE               PKG_KUR IS


  FUNCTION YUVARLA(p_doviz_kod varchar2, p_tutar number) RETURN NUMBER;
  FUNCTION fun_truncate(ps_currency varchar2, pn_amount number) RETURN NUMBER;
  
  Function DAK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
  Function EAK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
  Function DSK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
  Function ESK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;

  Function MB_DAK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
END;
/

