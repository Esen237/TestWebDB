create PACKAGE BODY           PKG_ATM_POS_CHYNGYZ IS
--------------------------------------------------------
FUNCTION Atm_Pos_Transactions(ps_message varchar2) RETURN VARCHAR2
is
    pn_log_no                                   NUMBER;
    ls_response_message                      varchar2(2000);
    ls_transaction_code                      varchar2(2000);
    ld_start_date                             date;
    ld_end_date                                 date;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;
    ln_count_reverse                            number := 0;
BEGIN
    ld_start_date := sysdate;
--
-- ASAGIDAKILER OK
--
--
--   TYPE : BALANCE INQUIRY - 1
/*Acc Inquiry-1                                                             *//*0518- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';
/*SWC ATM-FR-Debit Bakiye Sorma                                  *//*1110- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';
/*VISA OU Bakiye Sorma                                           *//*1210- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';
/*ATM-FR-Debit Bakiye Sorma                                      *//*0807- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';

--
--   TYPE : BALANCE INQUIRY - 2
/*Acc Inquiry-2                                                            *//*0021- */--ps_message := '0356BSOF0021O7777    100110010DK001   2007011510101000000000000000001000000000000001481';

--
--   TYPE : MINI STATEMENT
/*Last 15 Statements - Reversal                                  *//*0521- */--ps_message := '0356BSOF1521O7777    100110010DK001   2007011510101000000000000000001000000000000000002';

--
--   TYPE : CASH OPERATIONS
/*EOD                                                            *//*0090- */--ps_message := '0356BSOF0090O7777    100110010DK001   2006110310101000000000000000001417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';
/*EOD - Reversal                                                 *//*0093- */--ps_message := '0356BSOF0093I7777    100110010DK001   2007011510101000000000000000001417+000000000000010.00840+000000000000020.002007011520070116';
/*Money In                                                       *//*0091- */--ps_message := '0356BSOF0091O7777    100110010DK001   2006110310101000000000000000001417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';
/*Money In - Reversal                                            *//*0094- */--ps_message := '0356BSOF0094I7777    100110010DK001   2007011510101000000000000000001417+000000000000010.00840+000000000000020.002007011520070116';
/*Money Out                                                      *//*0092- */--ps_message := '0356BSOF0092O7777    100110010DK001   2006110310101000000000000000001417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';
/*Money Out Reversal                                             *//*0091- */--ps_message := '0356BSOF0095I7777    100110010DK001   2006110310101000000000000000444417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';

--
--   TYPE : FINANCIAL TRANSACTIONS
/*Rate Inquiry                                                             *//*0551- */--ps_message := '0356BSOF0551O7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00840+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Rate Inquiry                                                           *//*0552- */--ps_message := '0356BSOF0552O7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00840+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Buy FX                                                                    *//*0553- */--ps_message := '0356BSOF0553O7777    100110010DK001   2007011510101000000000000000223000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000100.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001480ACIKLAMA SAHASI               ';
/*Buy FX - Reversal                                                      *//*0554- */--ps_message := '0356BSOF0554I7777    100110010DK001   2007011510101000000000000000223000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000100.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001480ACIKLAMA SAHASI               ';
/*Sell FX                                                                 *//*0555- */--ps_message := '0356BSOF0555O7777    100110010DK001   2007011510101000000000000000224000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000500.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Sell FX - Reversal                                                      *//*0556- */--ps_message := '0356BSOF0556I7777    100110010DK001   2007011510101000000000000000224000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000500.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Money Transfer                                                          *//*0515- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Money Transfer - Reversal                                                 *//*0516- */--ps_message := '0356BSOF0516I7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Money Withdrawal                                                         *//*0503- */--ps_message := '0356BSOF0503O7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000150.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               ';
/*Money Withdrawal - Reversal                                              *//*0504- */--ps_message := '0356BSOF0504I7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               '
/*Pos Transaction                                                *//*1007- */--ps_message := '0356BSOF1007O7777    100110010DK001   2006110310101000000000000001007000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Pos Transaction - Reversal                                     *//*1008- */--ps_message := '0356BSOF1008I7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               '
/*Pos Refund Transaction                                         *//*1307- */--ps_message := '0356BSOF1307O7777    100110010DK001   2006110310101000000000000001007000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Pos Refund Transaction - Reversal                              *//*1308- */--ps_message := '0356BSOF1308I7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               '
/*Nakit Avans - Reversal                                         *//*0702- */--ps_message := '0356BSOF0702O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Kredi Kart Borc Odeme - Reversal                               *//*0712- */--ps_message := '0356BSOF0712O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Hesaptan Iade                                                  *//*1009- */--ps_message := '0356BSOF1009O7777    100110010DK001   2006110310101000000000000009009000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Hesaptan Iade - Reversal                                       *//*1010- */--ps_message := '0356BSOF1010I7777    100110010DK001   2006110310101000000000000009009000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Hesaba Cash Para Yatirma (SOM) - Reversal                      *//*0608- */--ps_message := '0356BSOF0608O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Hesaba Cash Para Yatirma (USD) - Reversal                      *//*0610- */--ps_message := '0356BSOF0610O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Kredi Kart Borc Odeme Cash Para Yatirarak (SOM) - Reversal     *//*0708- */--ps_message := '0356BSOF0708O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Para Cekme DO - Reversal                                       *//*0802- */--ps_message := '0356BSOF0802O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*VISA OU Para Cekme - Reversal                                  *//*1204- */--ps_message := '0356BSOF1204O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*SWC Para Cekme FR - Reversal                                   *//*1104- */--ps_message := '0356BSOF1104O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Para Cekme FR                                                  *//*0805- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Para Cekme FR - Reversal                                       *//*0806- */--ps_message := '0356BSOF0806O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Nakit Avans                                                    *//*0901- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Nakit Avans - Reversal                                         *//*0902- */--ps_message := '0356BSOF0902O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Last 15 Statements                                             *//*0520- */--ps_message := '0356BSOF0520O7777    100110010DK001   2007011510101000000000000000001000000000000000002';
/*Nakit Avans                                                    *//*0701- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Kredi Kart Borc Odeme                                          *//*0711- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- ---- -- -- -- -- -- -- -- -- -- -- ---- -- -- -- -- -- -- -- -- -- -- --

--
-- ASAGIDAKILER NOK
--

/*VISA OU Para Cekme                                             *//*1203- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*VISA OU Para Cekme                                             *//*1207- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';

    pn_log_no := PKG_GENEL.genel_kod_al('ATMLOGINC');
    INSERT INTO CBS_ATM_POS_TRAN_LOG_INC
    (LOG_NO, MESSAGE_TYPE,  MESSAGE)
    VALUES
    (pn_log_no,'INCOMING',ps_message);

    pkg_atm.GetTranCode(ps_message,ls_transaction_code);  
    

--   TYPE : BALANCE INQUIRY - 1

    /*Balance Inquiry*/
    if ls_transaction_code = '0518'    then ls_response_message := POS_ATM_0518(ps_message); end if;
    
     /*Balance Inquiry - 2*/
    if ls_transaction_code = '0021'    then ls_response_message := ATM_0021(ps_message); end if;
    
    
--   TYPE : FINANCIAL TRANSACTIONS

    /*Money Withdrawal*/
    if ls_transaction_code = '0503'    then ls_response_message := ATM_0503(ps_message); end if;
    /*Money Transfer*/
    if ls_transaction_code = '0515'    then ls_response_message := ATM_0515(ps_message); end if;
    
     /*Buying FX Inquiry*/
    if ls_transaction_code = '0551'    then ls_response_message := ATM_0551(ps_message); end if;
    
    /*Selling FX Inquiry*/
    if ls_transaction_code = '0552' then ls_response_message := ATM_0552(ps_message); end if;
     /*Buying Fx Currency*/
    if ls_transaction_code = '0553'    then ls_response_message := ATM_0553(ps_message); end if;
    
     /*Selling Fx Currency*/
     if ls_transaction_code = '0555'    then ls_response_message := ATM_0555(ps_message); end if;
     /*Nakit Avans*/
    if ls_transaction_code = '0701'    then ls_response_message := ATM_0701(ps_message); end if;
        /*Kredi Kart Borc Odeme*/
    if ls_transaction_code = '0711'    then ls_response_message := ATM_0711(ps_message); end if;
        
       /*ATM Domestic Debit Cash Withdrawal*/
    if ls_transaction_code = '0801'    then ls_response_message := ATM_0801(ps_message); end if;
    
      /*ATM Domestic Credit Cash Advance*/
    if ls_transaction_code = '0803'    then ls_response_message := ATM_0803(ps_message); end if;
      /*Para Cekme FR*/
    if ls_transaction_code = '0805'    then ls_response_message := ATM_0805(ps_message);    end if;
    
--   TYPE : MINI STATEMENT
    /*Last 15 Statements*/
    if ls_transaction_code = '0520'    then ls_response_message := ATM_0520(ps_message); end if;
    
    --   TYPE : CASH OPERATIONS
    /*ATM EOD*/
    if ls_transaction_code = '0090'    then ls_response_message := ATM_0090(ps_message); end if;
    /*ATM Money In*/
    if ls_transaction_code = '0091'    then ls_response_message := ATM_0091(ps_message); end if;
    /*ATM Money Out*/
    if ls_transaction_code = '0092'    then ls_response_message := ATM_0092(ps_message); end if;

    ld_end_date := sysdate;
         

 IF Pkg_Atm.Need_Reversal(ls_transaction_code)='E' THEN
        pkg_atm.Parse_Incoming_Message(ps_message ,       
                                        ls_ayrilan_message  ,
                                       ls_transaction_name ,
                                       ls_transaction_code ,
                                       ls_Orig_authorization_reversal,
                                       ls_user                 ,
                                       ls_transaction_type  ,
                                       ls_source_code        ,
                                       ls_terminal_type        ,
                                       ls_branch            ,
                                       ls_terminal_id        ,
                                       ls_transaction_date  ,
                                       ls_transaction_time  ,
                                       ls_reference_number);
        SELECT COUNT(*)
        INTO ln_count_reverse
         FROM cbs_atm_pos_tran_log A, cbs_atm_tran_kodlari b
        WHERE referance = ls_reference_number
             AND A.in_transaction_code = b.tran_kod
             AND b.tip = 'Iptal';
         
     IF Pkg_Atm.Time_Out(ld_start_date,ld_end_date) = 'E' THEN
        --MAKE TRANSACTION REVERSE
        ls_response_message := ATM_REVERSAL(ps_message);  
        ls_response_message := Pkg_Atm.STANDARDRESPONSEHEADER(ls_reference_number,'1' ,'096','TIMEOUT');   
     ELSIF ln_count_reverse > 0 THEN
        --MAKE TRANSACTION REVERSE
        ls_response_message := ATM_REVERSAL(ps_message);  
        ls_response_message := Pkg_Atm.STANDARDRESPONSEHEADER(ls_reference_number,'1' ,'096','CBS REVERSAL');         
     End if;
       
 END IF; 

    pn_log_no := PKG_GENEL.genel_kod_al('ATMLOGINC');
    INSERT INTO CBS_ATM_POS_TRAN_LOG_INC
    (LOG_NO, MESSAGE_TYPE,  MESSAGE)
    VALUES
    (pn_log_no,'OUTGOING',ls_response_message);

    RETURN ls_response_message;
END;

--start+++++++++++++++++++++++++++++++++++++++++++++++++

FUNCTION ATM_0805(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8818;
    ln_from_account                 number;
    ls_from_dvz                     varchar2(3);
    ln_to_account                 number;
    ls_to_dvz                       varchar2(3);

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  := substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    ln_from_account                 := null;
    ls_from_dvz                     := null;
    ln_to_account                 := null;
    ls_to_dvz                     := null;

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('USD','KGS')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
      --KTDL  ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
------------------------------------------------------------------

---------------------------------------------------------------------------------
FUNCTION ATM_0803(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8833;
    ln_from_account                 number;
    ls_from_dvz                     varchar2(3);
    ln_to_account                 number;
    ls_to_dvz                       varchar2(3);

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  := substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    ln_from_account                 := null;
    ls_from_dvz                     := null;
    ln_to_account                 := null;
    ls_to_dvz                     := null;

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('USD','KGS')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
    --KTDL    ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;

---------------------------------------------------------------------------------
FUNCTION ATM_0801(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8832;
    ln_from_account                 number;
    ls_from_dvz                     varchar2(3);
    ln_to_account                 number;
    ls_to_dvz                       varchar2(3);

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  := substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    ln_from_account                 := null;
    ls_from_dvz                     := null;
    ln_to_account                 := null;
    ls_to_dvz                     := null;

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('USD','KGS')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
       --KTDL ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------

FUNCTION ATM_0711(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                       varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ls_hesap_varmi                              varchar(3);
    ls_resp_explanation                         varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8823;
    ln_BAKIYE                                 number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                         number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_cnt                                    number;
    ls_ret                                      varchar2(2000);
    ln_islem_no                                  number;
    ls_cbs_error_desc                         varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account_number       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account_number         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');

    ls_branch_3 :=substr(ls_branch,2,3);

    if substr(ls_ayrilan_message,226,18) in ('                  ','000000000000000000')
    then
        ln_from_account_number       := null;
        ls_from_dvz                  := null;
    else
        ln_from_account_number       := to_number(substr(ls_ayrilan_message,226,18));
        ls_from_dvz                  :=  null;  -- KTDL get_account_currency(ln_from_account_number); -> pkg_hesap.HesaptanDovizKoduAl(ln_from_account_number);
    end if;

    if substr(ls_ayrilan_message,244,18) in ('                  ','000000000000000000')
    then
        ln_to_account_number         := null;
        ls_to_dvz                    := null;
    else
        ln_to_account_number         := to_number(substr(ls_ayrilan_message,244,18));
        ls_to_dvz                    := null; -- KTDL get_account_currency(ln_to_account_number); ->  pkg_hesap.HesaptanDovizKoduAl(ln_to_account_number);
    end if;

    ls_explain                   := substr(ls_ayrilan_message,262,30);


    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account_number,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------
--    select count(*)
--    into ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account_number
--      and durum_kodu = 'A' ;

-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);

    if ls_hesap_varmi = 'N' 
    then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account_number;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('KGS') or ls_original_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------

 -- if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account_number) < ln_original_amount
   --KTDL if getAvailBalance(ln_from_account_number) < ln_original_amount then
   
   if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account_number;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        
        --KTDL  getBalancesForAccount(ln_from_account_number, ln_bakiye, ln_blocked_amount);        
        --KTDL ln_kull_bak := getAvailBalance(ln_from_account_number)
        --KTDL ln_pending_total := getPendingTotal(ln_hesap_no);
        
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

   --KTDL ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account_number,
--                                              ls_from_dvz,
--                                              ln_to_account_number,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);
    if ls_ret = '000'
    then
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account_number;

         --KTDL  getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount);        
        --KTDL ln_kull_bak := getAvailBalance(ln_from_account)



       -- pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        --KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz);
        
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
--        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
--           if ls_from_dvz = pkg_genel.lc_al then
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
--            else
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
--            end if;
--        end if;

    if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
       if ls_from_dvz = pkg_genel.lc_al then
           null;
         --KTDL ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz  ,'KGS',nvl(ln_masraf_toplam,0),1,'N','S') );
        else
            null;
          --KTDL ln_usd_comm_amount := pkg_kur.yuvarla('USD',convertCurrency(ls_masraf_Doviz  ,'USD',nvl(ln_masraf_toplam,0),1,'N','S')) ;
        end if;
     end if;
     
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;

---------------------------------------------------------------------------------------
FUNCTION ATM_0707(ps_message varchar2) RETURN VARCHAR2
is
BEGIN
    null;
END;
------------------------------------------------
FUNCTION ATM_0701(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8822;
    ln_from_account                 number;
    ls_from_dvz                     varchar2(3);
    ln_to_account                 number;
    ls_to_dvz                       varchar2(3);

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  := substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    ln_from_account                 := null;
    ls_from_dvz                     := null;
    ln_to_account                 := null;
    ls_to_dvz                     := null;

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('USD','KGS')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--  KTDL      ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------------

FUNCTION ATM_0609(ps_message varchar2) RETURN VARCHAR2
is
BEGIN
    null;
END;


FUNCTION ATM_0607(ps_message varchar2) RETURN VARCHAR2
is
BEGIN
    null;
END;


FUNCTION ATM_0555(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                           varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                                  number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                         number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ls_bill_dvz     varchar2(3);
    ln_bill_amount  number;
    ln_from_account number;
    ln_to_account   number;
    ln_comm_rate   number;
    ls_explain      varchar2(30);
    ls_from_dvz     varchar2(3);
    ls_to_dvz       varchar2(3);
    --ls_dvz          varchar2(3);
    ln_usd_comm_amnt                 number;
    ln_eur_comm_amnt                   number;
    ln_kur                              number;
    ln_som_amnt                          number;
    ln_fc_amnt                     number;
    ls_ret                           varchar2(2000);
    ln_islem_no                       number;
    ls_cbs_error_desc              varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8812;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ln_from_account       := null;
    else
        ln_from_account       := to_number(substr(ls_ayrilan_message,226,18));
    end if;
    ls_from_dvz                  := null; -- KTDL get_account_currency(ln_from_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    if trim(substr(ls_ayrilan_message,244,18)) is null then
        ln_to_account         := null;
    else
        ln_to_account         := to_number(substr(ls_ayrilan_message,244,18));
    end if;
    ls_to_dvz                    := null; -- KTDL get_account_currency(ln_to_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_to_account);
    
    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;
-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);

    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- To Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_to_account
--      and durum_kodu = 'A' ;
-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_to_account);

    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_to_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_to_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       ls_from_dvz not in ('USD','EUR') or
       ls_to_dvz not in ('KGS') or
       ls_bill_dvz not in (ls_from_dvz,ls_to_dvz)
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
---------------------------------- Simdi basliyor ----------------------------------
    ln_kur := PKG_KUR.DAK_to_LC(ls_from_dvz,1);
    if ls_bill_dvz = 'KGS'
    then
        ln_som_amnt := ln_bill_amount;
        ln_fc_amnt := ln_som_amnt/ln_kur;
    else
        ln_fc_amnt := ln_bill_amount;
        ln_som_amnt := ln_fc_amnt*ln_kur;
    end if;

--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < ln_fc_amnt
 -- KTDL if getAvailBalance(ln_from_account) < ln_som_amnt then
   if false   
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
        
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);

        --KTDL  getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount);        
        --KTDL ln_kull_bak := getAvailBalance(ln_from_account)
        --KTDL ln_pending_total := getPendingTotal(ln_hesap_no);
        
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

    --ls_ret := PKG_ATM_TRANSACTION.FX_Sell(ln_from_account,ls_from_dvz,ln_kur,ln_fc_amnt,ln_to_account,ls_explain,0,ls_terminal_id,ls_reference_number,ln_islem_no,ls_cbs_error_Desc);
    
--    KTDL   ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account,
--                                              ls_from_dvz,
--                                              ln_to_account,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);
    if ls_ret = '000'
    then
         --ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        --KTDL ln_pending_total := getPendingTotal(ln_hesap_no);
        
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
    
        --KTDL  getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount);        
        --KTDL ln_kull_bak := getAvailBalance(ln_from_account)
        

--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        --KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz);
        
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        
--        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
--           if ls_from_dvz = pkg_genel.lc_al then
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
--            else
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
--            end if;
--        end if;
--      
   if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
       if ls_from_dvz = pkg_genel.lc_al then
           null;
         --KTDL ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz  ,'KGS',nvl(ln_masraf_toplam,0),1,'N','S') );
        else
            null;
          --KTDL ln_usd_comm_amount := pkg_kur.yuvarla('USD',convertCurrency(ls_masraf_Doviz  ,'USD',nvl(ln_masraf_toplam,0),1,'N','S')) ;
        end if;
     end if;
       
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_0553(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_som_amnt                              number ;
    ln_fc_amnt                                  number;
    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8810;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);
    ln_kull_bak                     number;
BEGIN

    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ln_from_account       := null;
    else
        ln_from_account       := to_number(substr(ls_ayrilan_message,226,18));
    end if;
    ls_from_dvz                  := null; -- KTDL get_account_currency(ln_from_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_from_account);

    if trim(substr(ls_ayrilan_message,244,18)) is null then
        ln_to_account         := null;
    else
        ln_to_account         := to_number(substr(ls_ayrilan_message,244,18));
    end if;
    ls_to_dvz                    := null; -- KTDL get_account_currency(ln_to_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_to_account);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;
-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);

    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- To Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_to_account
--      and durum_kodu = 'A' ;

-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_to_account);

    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_to_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_to_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       ls_from_dvz not in ('KGS') or
       ls_to_dvz not in ('USD','EUR') or
       ls_bill_dvz not in (ls_from_dvz,ls_to_dvz)
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
    ln_kur := PKG_KUR.DSK_to_LC(ls_to_dvz,1);
    if ls_bill_dvz = 'KGS'
    then
        ln_som_amnt := ln_bill_amount;
        ln_fc_amnt := ln_som_amnt/ln_kur;
    else
        ln_fc_amnt := ln_bill_amount;
        ln_som_amnt := ln_fc_amnt*ln_kur;
    end if;

    --if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < ln_som_amnt
   --KTDL if getAvailBalance(ln_from_account) < ln_som_amnt then
   if false
     then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        --KTDL  getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount);        
        --KTDL ln_kull_bak := getAvailBalance(ln_from_account)
        --KTDL ln_pending_total := getPendingTotal(ln_hesap_no);


        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;


--    ls_ret := PKG_ATM_TRANSACTION.FX_Buy(ln_from_account,ls_to_dvz,ln_kur,ln_fc_amnt,ln_to_account,ls_explain,0,ls_terminal_id,ls_reference_number,ln_islem_no,ls_cbs_error_Desc);
      
    
   --KTDL   ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account,
--                                              ls_from_dvz,
--                                              ln_to_account,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then

        --ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        --KTDL ln_pending_total := getPendingTotal(ln_hesap_no);
        
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

--      --KTDL  getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount);        
        --KTDL ln_kull_bak := getAvailBalance(ln_from_account)

        --pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        --KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz);
        
        
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        
       if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
       if ls_from_dvz = pkg_genel.lc_al then
           null;
         --KTDL ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz  ,'KGS',nvl(ln_masraf_toplam,0),1,'N','S') );
        else
            null;
          --KTDL ln_usd_comm_amount := pkg_kur.yuvarla('USD',convertCurrency(ls_masraf_Doviz  ,'USD',nvl(ln_masraf_toplam,0),1,'N','S')) ;
        end if;
     end if;
        
----        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
--           if ls_from_dvz = pkg_genel.lc_al then
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
--            else
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
--            end if;
--        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;

 ---------------------------------------------------------------------------------
 
FUNCTION ATM_0552(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                           varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                                  number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                         number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ls_bill_dvz     varchar2(3);
    ln_bill_amount  number;
    ln_from_account number;
    ln_to_account   number;
    ln_comm_rate   number;
    ls_explain      varchar2(30);
    ls_from_dvz     varchar2(3);
    ls_to_dvz       varchar2(3);
    --ls_dvz          varchar2(3);
    ln_usd_comm_amnt                 number;
    ln_eur_comm_amnt                   number;
    ln_kur                              number;
    ln_som_amnt                          number;
    ln_fc_amnt                     number;
    ls_ret                           varchar2(2000);
    ln_islem_no                       number;
    ls_cbs_error_desc              varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8813;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ln_from_account       := null;
    else
        ln_from_account       := to_number(substr(ls_ayrilan_message,226,18));
    end if;
    ls_from_dvz                  := null; -- KTDL get_account_currency(ln_from_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_from_account);

    if trim(substr(ls_ayrilan_message,244,18)) is null then
        ln_to_account         := null;
    else
        ln_to_account         := to_number(substr(ls_ayrilan_message,244,18));
    end if;
    ls_to_dvz                    :=  null; -- KTDL get_account_currency(ln_to_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_to_account);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

   --KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);
    
    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- To Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_to_account
--      and durum_kodu = 'A' ;
       --KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);
       
    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_to_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_to_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('USD','KGS','EUR') or
       ls_from_dvz not in ('USD','EUR') or
       ls_to_dvz not in ('KGS') or
       ls_original_dvz not in (ls_from_dvz,ls_to_dvz)
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
---------------------------------- Simdi basliyor ----------------------------------
--        ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account,
--                                              ls_from_dvz,
--                                              ln_to_account,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);
    if ls_ret = '000'
    then
        if ls_original_dvz =pkg_genel.lc_al
        then
            ln_pending_total := PKG_KUR.DAK_to_LC(ls_from_dvz,1);
            ln_bakiye := ln_original_amount / ln_pending_total;
        else
            ln_pending_total := PKG_KUR.DAK_to_LC(ls_from_dvz,1);
            ln_bakiye := ln_original_amount * ln_pending_total;
        end if;

        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

        -- KTDL getCommission(ln_islem_no, ln_masraf_toplam, ls_masraf_doviz) ->  pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
          if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
               null;
             --KTDL ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz  ,'KGS',nvl(ln_masraf_toplam,0),1,'N','S') );
            else
                null;
              --KTDL ln_usd_comm_amount := pkg_kur.yuvarla('USD',convertCurrency(ls_masraf_Doviz  ,'USD',nvl(ln_masraf_toplam,0),1,'N','S')) ;
            end if;
        end if;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;



--------------------------------------------------------------------------------------
FUNCTION ATM_0551(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_som_amnt                              number ;
    ln_fc_amnt                                  number;
    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8811;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ln_from_account       := null;
    else
        ln_from_account       := to_number(substr(ls_ayrilan_message,226,18));
    end if;
    ls_from_dvz                  :=  null; -- KTDL get_account_currency(ln_from_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_from_account);

    if trim(substr(ls_ayrilan_message,244,18)) is null then
        ln_to_account         := null;
    else
        ln_to_account         := to_number(substr(ls_ayrilan_message,244,18));
    end if;
    --ls_to_dvz                    := --KTDL get_account_currency(ln_to_account); -> pkg_hesap.HesaptanDovizKoduAl(ln_to_account);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------
    /*select count(*)
    into  ln_hesap_varmi
    from cbs_hesap
    where hesap_no = ln_from_account
      and durum_kodu = 'A' ;*/
    
    --KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);
    
  --  if nvl(ls_hesap_varmi,0) = 0 then
 
    if ls_hesap_varmi = 'Y' then 
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- To Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_to_account
--      and durum_kodu = 'A' ;
--
--    if nvl(ln_hesap_varmi,0) = 0 then

   --KTDL ls_hesap_varmi := isThereActiveAccount(ln_to_account);
    
  --  if nvl(ls_hesap_varmi,0) = 0 then
 
    if ls_hesap_varmi = 'Y' then 
    
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_to_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_to_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('USD','KGS','EUR') or
       ls_from_dvz not in ('KGS') or
       ls_to_dvz not in ('USD','EUR') or
       ls_original_dvz not in (ls_from_dvz,ls_to_dvz)
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------

--KTDL
--        ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account,
--                                              ls_from_dvz,
--                                              ln_to_account,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        if ls_original_dvz =pkg_genel.lc_al
        then
            ln_pending_total := PKG_KUR.DSK_to_LC(ls_to_dvz,1);
            ln_bakiye := ln_original_amount / ln_pending_total;
        else
            ln_pending_total := PKG_KUR.DSK_to_LC(ls_to_dvz,1);
            ln_bakiye := ln_original_amount * ln_pending_total;
        end if;

        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

        --KTDL getCommission(ln_islem_no, ln_masraf_toplam, ls_masraf_doviz); -> pkg_atm_masraf.toplam_masraf(ln_islem_no,ln_masraf_toplam,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
               null;
             --KTDL ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz  ,'KGS',nvl(ln_masraf_toplam,0),1,'N','S') );
            else
                null;
              --KTDL ln_usd_comm_amount := pkg_kur.yuvarla('USD',convertCurrency(ls_masraf_Doviz  ,'USD',nvl(ln_masraf_toplam,0),1,'N','S')) ;
            end if;
        end if;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
 
------------------------------------------------------------------------------------------------------------
FUNCTION ATM_0520(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    number;
    ls_count                                     number := 0;
    ls_response_message                       varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    ls_detail_response_code                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;
    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_bakiye                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_cnt                                    number;
    ls_cbs_error_desc                         varchar2(2000);
    ls_ret                                      varchar2(2000);
    ls_tran_message                             varchar2(2000);
    ln_islem_no                                  number;
    ls_dvz                                   varchar(3);
    ln_tran_count                             number;
    ls_branch_3                               varchar(3);
    ln_kull_bak                                  number;
    

    
/*cursor cur_transactions is
    select fis_islem_numara tx_no,
           lpad(to_char(fis_muhasebelestigi_tarih,'MMDD'),4,' ') ||
           substr(rpad(nvl( satir_musteri_aciklama,' '),15,' '),1,15)||
           decode(satir_tur,'B','-','+')              ||
           To_char( ABS(NVL(satir_dv_tutar,0) ),'FM099999999999999.00') send_msg
    from cbs_vw_fis_satir_vsziz
    where fis_tur = 'G' and
          fis_muhasebelestigi_tarih is not null and
          FIS_IPTAL_EDILDIGI_TARIH is null and
          satir_hesap_tur_kodu = 'VS' and
          satir_hesap_numara = ls_account_no
          order  by  fis_islem_numara desc;*/

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no             :=to_char(to_number(substr(ls_ayrilan_message,1,18)));

-------------------------------- LOG --------------------------------

    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no      ,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --terminal Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no      ,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

------- ATM Account control -------
   /* select count(*)
    into  ln_hesap_varmi
    from cbs_hesap
    where hesap_no =ls_account_no
      and durum_kodu = 'A' ;*/
   -- KTDL ls_hesap_varmi =  isThereActiveAccount(ls_account_no);
   if ls_hesap_varmi = 'N' then  
         ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no      ,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_cbs_error_desc);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
    else
            ln_hesap_no := to_number(ls_account_no);
            ls_dvz      := null; --KTDL get_account_currency(ln_hesap_no) -> pkg_hesap.HesaptanDovizKoduAl(ln_hesap_no);
            ls_branch_3 := substr(ls_branch,2,3);
    
--        KTDL
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions
--                                     (  8803,
--                                         ln_hesap_no ,
--                                         ls_branch_3         ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number     ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                            ln_islem_no       ,
--                                            ls_cbs_error_desc);

    if ls_ret = '000'
    then
        /*select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
        from cbs_hesap_Bakiye
        where hesap_no = ln_hesap_no;
        KTDL getBalancesForAccount(ln_bakiye, ln_blocked_amount, ln_hesap_no);
      
        */

        --  KTDL ln_pending_total := getPendingTotal(ln_hesap_no); -> ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        
        ln_overdraft_limit := 0; --Sevalb Henuz KG de limit tanimli degil yapildiginda burasi degisitirilmeli

            -- transactions max(15)
            
      --KTDL getAccountHistory(ls_account_no, cur_transactions)
      
      ln_tran_count := 0;
     begin
        
     --KTDL getAccountHistory(ls_account_no, 15, ls_tran_message);
    
     null;
         /*for c_transaction in cur_transactions loop
               ln_tran_count :=       ln_tran_count + 1;
             if ln_tran_count > 15 then  ln_tran_count := 15; exit;
             else
                  ls_tran_message  := ls_tran_message || c_transaction.send_msg;
             end if;
         end loop;*/
         
         
         exception when others then null;
     end ;
          ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   lpad(ln_tran_count,2,'0') ;-- Transaction number;
       ls_response_message := ls_response_message||  ls_tran_message;
     -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => null,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
  end if;

EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
FUNCTION ATM_0515(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
--    ls_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8806;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);
    ln_kull_bak                     number;
BEGIN

    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := pkg_atm.bsof_bakiye_to_number(to_number(substr(ls_ayrilan_message,94,19)));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := pkg_atm.bsof_bakiye_to_number(to_number(substr(ls_ayrilan_message,116,19)));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := pkg_atm.bsof_bakiye_to_number(to_number(substr(ls_ayrilan_message,138,19)));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3 :=substr(ls_branch,2,3);

    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ln_from_account := 0; --CQ1025 AlmasN 14.07.2014 Cash In
    else
        ln_from_account := to_number(substr(ls_ayrilan_message,226,18));
    end if;

    ln_to_account   := to_number(substr(ls_ayrilan_message,244,18));
    ls_explain                   := substr(ls_ayrilan_message,262,30);

    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ls_from_dvz     := ''; --CQ1025 AlmasN 14.07.2014 Cash In
    else
        ls_from_dvz     := null; --KTDL get_account_currency -> pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    end if;

    ls_to_dvz                    := null; --KTDL get_account_currency -> p pkg_hesap.HesaptanDovizKoduAl(ln_to_account);
    --KTDLpkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    --KTDL pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    --KTDL pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;
-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);
    
    if ls_hesap_varmi = 'Y' then
    --if (ln_from_account > 0 and nvl(ls_hesap_varmi,0) = 0) then --CQ1025 AlmasN 14.07.2014 Cash In
        ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
------- To Account Control -------
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_to_account
--      and durum_kodu = 'A' ;
--
--    if nvl(ln_hesap_varmi,0) = 0 then

-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_to_account);
    
    if ls_hesap_varmi = 'Y' then
    
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_to_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_to_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       (ls_bill_dvz <> ls_from_dvz and length(ls_from_dvz) > 0) or --CQ1025 AlmasN 14.07.2014 Cash In
       ls_bill_dvz <> ls_to_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
    ln_amnt := ln_bill_amount;

    if (ln_from_account > 0  /*and pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < ln_amnt*/) then --KTDL getAvailBalance -> pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) 
        ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
        --KTDL getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount)
        -- KTDL ln_kull_bak := getAvailBalance(ln_from_account);

        --KTDL getPendingTotal(ln_hesap_no) -> ln_pending_total := pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no); 
        
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

    --KTDL ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account,
--                                              ls_from_dvz,
--                                              ln_to_account,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        -- BOM --CQ1025 AlmasN 14.07.2014 Cash In
        if (ln_from_account > 0) then 
            /*select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
            from cbs_hesap_Bakiye
            where hesap_no = ln_from_account;*/
            
               --KTDL getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount)
                -- KTDL ln_kull_bak := getAvailBalance(ln_from_account);
            null;
        else
            /*select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
            from cbs_hesap_Bakiye
            where hesap_no = ln_to_account;*/
            
             --KTDL getBalancesForAccount(ln_to_account, ln_bakiye, ln_blocked_amount)
             -- KTDL ln_kull_bak := getAvailBalance(ln_to_account);
                null;
        end if;
        -- EOM

--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz);
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        begin
        /*
        
        KTDL getCommission(ln_islem_no, ln_masraf_toplam,ls_masraf_Doviz);
        
        select TAHSIL_EDILEN_MASRAF_TUTAR, MASRAF_DOVIZ_KODU
        into ln_masraf_toplam,ls_masraf_Doviz
        from CBS_ATM_MASRAF_TAHSIL_ISLEM
        where TX_NO = ln_islem_no;*/

        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if null then /* KTDL pkg_genel.lc_al ->  ls_from_dvz = pkg_genel.lc_al  then*/
             --KTDL convertCurrency -> ln_som_comm_amount :=pkg_kur.yuvarla(ls_from_dvz,pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz,ls_from_dvz,null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
             null;
            else
             --KTDL convertCurrency -> ln_usd_comm_amount :=pkg_kur.yuvarla(ls_from_dvz,pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz,ls_from_dvz,null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
             null;
            end if;
        end if;
        exception
         when others then null;
        end;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
FUNCTION ATM_0096(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8899;

    ln_cnt   number;
    ls_bill_dvz     varchar2(3);
    ln_bill_amount  number;
    ln_from_account number;
    ln_to_account   number;
    ln_comm_rate   number;
    ls_explain      varchar2(30);
    ls_from_dvz     varchar2(3);
    ls_to_dvz       varchar2(3);
    ls_dvz          varchar2(3);
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_cy_1        varchar2(3);
    ln_amnt_1   number;
    ls_cy_2      varchar2(3);
    ln_amnt_2   number;
    ls_y_cy_1      varchar2(3);
    ln_y_amnt_1   number;
    ls_y_cy_2      varchar2(3);
    ln_y_amnt_2   number;
    ld_today   date;
    ld_tomorrow date;
    ls_branch_3  varchar2(3);
    ls_dv1   varchar2(3);
    ls_dv2   varchar2(3);
    ls_y_dv1   varchar2(3);
    ls_y_dv2   varchar2(3);
    pn_usd_today    number;
    pn_kgs_today    number;
    ln_error    number;

    ld_date        date;
BEGIN

    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_dv1 := substr(ls_ayrilan_message,1,3);
    --KTDL pkg_atm.CURRENCY_CONVERT(ls_dv1,ls_cy_1);
    ln_amnt_1   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,4,19));

    ls_dv2 := substr(ls_ayrilan_message,23,3);
    --KTDL  pkg_atm.CURRENCY_CONVERT(ls_dv2,ls_cy_2);
    ln_amnt_2   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,26,19));

    ls_y_dv1 := substr(ls_ayrilan_message,45,3);
    --KTDL  pkg_atm.CURRENCY_CONVERT(ls_y_dv1,ls_y_cy_1);
    ln_y_amnt_1 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,48,19));

    ls_y_dv2 := substr(ls_ayrilan_message,67,3);
    --KTDL  pkg_atm.CURRENCY_CONVERT(ls_y_dv2,ls_y_cy_2);
    ln_y_amnt_2 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,70,19));

    ld_today    := to_date(substr(ls_ayrilan_message,89,8),'yyyymmdd');
    ld_tomorrow := to_date(substr(ls_ayrilan_message,97,8),'yyyymmdd');
    ls_branch_3 := substr(ls_branch,2,3);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
        pn_usd_today := 0;
        ld_date := null; --KTDL pkg_muhasebe.Banka_Tarihi_Bul;

--       select /*+ FIRST_ROWS */ sum(NVL(satir_dv_tutar,0))*(-1)
--        into pn_usd_today
--        from CBS_VW_ATM_DK_SATIR
--        where terminal_id = rtrim(ltrim(ls_terminal_id))
--        and FIS_MUHASEBELESTIGI_TARIH = ld_date
--        and SATIR_DOVIZ_KOD = 'USD';
--
--        select /*+ FIRST_ROWS */ sum(NVL(satir_dv_tutar,0))*(-1)
--        into pn_kgs_today
--        from CBS_VW_ATM_DK_SATIR
--        where terminal_id = rtrim(ltrim(ls_terminal_id))
--        and FIS_MUHASEBELESTIGI_TARIH = ld_date
--        and SATIR_DOVIZ_KOD = 'KGS';

      --KTDL
        -- pn_usd_today := get_transactions_total_amount(ls_terminal_id, ld_date, 'USD')

          --KTDL
        -- pn_kgs_today := get_transactions_total_amount(ls_terminal_id, ld_date, 'KGS')
        
    ln_error := 0;

    if ls_cy_1 = 'KGS'
    then
        if ln_amnt_1 <> nvl(pn_kgs_today,0) or ln_amnt_2 <> nvl(pn_usd_today,0)
        then
            ln_error := 1;
        end if;
    else
        if ln_amnt_2 <> nvl(pn_kgs_today,0) or ln_amnt_1 <> nvl(pn_usd_today,0)
        then
            ln_error := 1;
        end if;
    end if;

    if ln_error = 1
    then
           ls_detail_response_code := '949';
        ls_resp_explanation := 'INCORRECT AMOUNTS';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Amount kontrol -------
--
--
------- Dvz Control -------
    if ls_cy_1 not in ('USD','KGS','EUR') or ls_cy_2 not in ('USD','KGS','EUR') or
       ls_y_cy_1 not in ('USD','KGS','EUR') or ls_y_cy_2 not in ('USD','KGS','EUR')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
  --KTDL  ls_ret := PKG_ATM_TRANSACTION.Cash_Operations (ln_islem_kod,
--                                                        ls_cy_1,
--                                                   ln_amnt_1,
--                                                   ls_cy_2,
--                                                   ln_amnt_2,
--                                                   ls_y_cy_1,
--                                                   ln_y_amnt_1,
--                                                   ls_y_cy_2,
--                                                   ln_y_amnt_2,
--                                                   ls_branch_3,
--                                                          ld_today,
--                                                   ld_tomorrow,
--                                                   ls_terminal_id,
--                                                   ls_reference_number,
--                                                    ls_transaction_name ,
--                                                    ls_transaction_code,
--                                                    ls_Orig_authorization_reversal,
--                                                    ls_source_code,
--                                                    ls_terminal_type,
--                                                    ls_transaction_date ,
--                                                    ls_transaction_time,
--                                                   ln_islem_no,
--                                                     ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK');
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------

FUNCTION ATM_0092(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8892;

    ln_cnt   number;
    ls_bill_dvz     varchar2(3);
    ln_bill_amount  number;
    ln_from_account number;
    ln_to_account   number;
    ln_comm_rate   number;
    ls_explain      varchar2(30);
    ls_from_dvz     varchar2(3);
    ls_to_dvz       varchar2(3);
    ls_dvz          varchar2(3);
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_cy_1        varchar2(3);
    ln_amnt_1   number;
    ls_cy_2      varchar2(3);
    ln_amnt_2   number;
    ls_y_cy_1      varchar2(3);
    ln_y_amnt_1   number;
    ls_y_cy_2      varchar2(3);
    ln_y_amnt_2   number;
    ld_today   date;
    ld_tomorrow date;
    ls_branch_3  varchar2(3);
    ls_dv1   varchar2(3);
    ls_dv2   varchar2(3);
    ls_y_dv1   varchar2(3);
    ls_y_dv2   varchar2(3);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--

    ls_dv1 := substr(ls_ayrilan_message,1,3);
    if  trim(ls_dv1 ) is not null then
        --KTDL  pkg_atm.CURRENCY_CONVERT(ls_dv1,ls_cy_1);
        ln_amnt_1   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,4,19));
    end if;

    ls_dv2 := substr(ls_ayrilan_message,23,3);
    if  trim(ls_dv2 ) is not null then
         --KTDL pkg_atm.CURRENCY_CONVERT(ls_dv2,ls_cy_2);
        ln_amnt_2   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,26,19));
    end if;

    ls_y_dv1 := substr(ls_ayrilan_message,45,3);
    if  trim(ls_y_dv1) is not null then
         --KTDL pkg_atm.CURRENCY_CONVERT(ls_y_dv1,ls_y_cy_1);
        ln_y_amnt_1 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,48,19));
    end if;
    ls_y_dv2 := substr(ls_ayrilan_message,67,3);
    if trim(ls_y_dv2) is not null then
         --KTDL pkg_atm.CURRENCY_CONVERT(ls_y_dv2,ls_y_cy_2);
       ln_y_amnt_2 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,70,19));
     end if;

    begin
    ld_today    := to_date(substr(ls_ayrilan_message,89,8),'yyyymmdd');
    exception when others then null;
    end ;
    begin
    ld_tomorrow := to_date(substr(ls_ayrilan_message,97,8),'yyyymmdd');
    exception when others then null;
    end ;

    ls_branch_3 := substr(ls_branch,2,3);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Dvz Control -------
    if ls_cy_1 not in ('USD','KGS','EUR') or ls_cy_2 not in ('USD','KGS','EUR') or
       ls_y_cy_1 not in ('USD','KGS','EUR') or ls_y_cy_2 not in ('USD','KGS','EUR')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
   --KTDL  ls_ret := PKG_ATM_TRANSACTION.Cash_Operations (ln_islem_kod,
--                                                        ls_cy_1,
--                                                   ln_amnt_1,
--                                                   ls_cy_2,
--                                                   ln_amnt_2,
--                                                   ls_y_cy_1,
--                                                   ln_y_amnt_1,
--                                                   ls_y_cy_2,
--                                                   ln_y_amnt_2,
--                                                   ls_branch_3,
--                                                          ld_today,
--                                                   ld_tomorrow,
--                                                   ls_terminal_id,
--                                                   ls_reference_number,
--                                                    ls_transaction_name ,
--                                                    ls_transaction_code,
--                                                    ls_Orig_authorization_reversal,
--                                                    ls_source_code,
--                                                    ls_terminal_type,
--                                                    ls_transaction_date ,
--                                                    ls_transaction_time,
--                                                   ln_islem_no,
--                                                     ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK');
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;

---------------------------------------------------------------------------------
FUNCTION ATM_0091(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8891;

    ln_cnt   number;
    ls_bill_dvz     varchar2(3);
    ln_bill_amount  number;
    ln_from_account number;
    ln_to_account   number;
    ln_comm_rate   number;
    ls_explain      varchar2(30);
    ls_from_dvz     varchar2(3);
    ls_to_dvz       varchar2(3);
    ls_dvz          varchar2(3);
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_cy_1        varchar2(3);
    ln_amnt_1   number;
    ls_cy_2      varchar2(3);
    ln_amnt_2   number;
    ls_y_cy_1      varchar2(3);
    ln_y_amnt_1   number;
    ls_y_cy_2      varchar2(3);
    ln_y_amnt_2   number;
    ld_today   date;
    ld_tomorrow date;
    ls_branch_3  varchar2(3);
    ls_dv1   varchar2(3);
    ls_dv2   varchar2(3);
    ls_y_dv1   varchar2(3);
    ls_y_dv2   varchar2(3);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--

    ls_dv1 := substr(ls_ayrilan_message,1,3);
    if trim(ls_dv1) is not null then
        --KTDL pkg_atm.CURRENCY_CONVERT(ls_dv1,ls_cy_1);
        ln_amnt_1   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,4,19));
    end if;

    ls_dv2 := substr(ls_ayrilan_message,23,3);
    if trim(ls_dv2 ) is not null then
        --KTDL pkg_atm.CURRENCY_CONVERT(ls_dv2,ls_cy_2);
        ln_amnt_2   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,26,19));
    end if;

    ls_y_dv1 := substr(ls_ayrilan_message,45,3);
    if trim(ls_y_dv1 ) is not null then
        --KTDL pkg_atm.CURRENCY_CONVERT(ls_y_dv1,ls_y_cy_1);
        ln_y_amnt_1 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,48,19));
    end if;
    ls_y_dv2 := substr(ls_ayrilan_message,67,3);
    if trim(ls_y_dv2 ) is not null then
        --KTDL pkg_atm.CURRENCY_CONVERT(ls_y_dv2,ls_y_cy_2);
        ln_y_amnt_2 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,70,19));
    end if;

    begin
    ld_today    := to_date(substr(ls_ayrilan_message,89,8),'yyyymmdd');
    exception when others then null;
    end ;
    begin
    ld_tomorrow := to_date(substr(ls_ayrilan_message,97,8),'yyyymmdd');
    exception when others then null;
    end ;

    ls_branch_3 := substr(ls_branch,2,3);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Dvz Control -------
    if ls_cy_1 not in ('USD','KGS','EUR') or ls_cy_2 not in ('USD','KGS','EUR') or
       ls_y_cy_1 not in ('USD','KGS','EUR') or ls_y_cy_2 not in ('USD','KGS','EUR')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
-- KTDL
--    ls_ret := PKG_ATM_TRANSACTION.Cash_Operations (ln_islem_kod,
--                                                        ls_cy_1,
--                                                   ln_amnt_1,
--                                                   ls_cy_2,
--                                                   ln_amnt_2,
--                                                   ls_y_cy_1,
--                                                   ln_y_amnt_1,
--                                                   ls_y_cy_2,
--                                                   ln_y_amnt_2,
--                                                   ls_branch_3,
--                                                          ld_today,
--                                                   ld_tomorrow,
--                                                   ls_terminal_id,
--                                                   ls_reference_number,
--                                                    ls_transaction_name ,
--                                                    ls_transaction_code,
--                                                    ls_Orig_authorization_reversal,
--                                                    ls_source_code,
--                                                    ls_terminal_type,
--                                                    ls_transaction_date ,
--                                                    ls_transaction_time,
--                                                   ln_islem_no,
--                                                     ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK');
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;

FUNCTION ATM_0090(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8890;

    ln_cnt   number;
    ls_bill_dvz     varchar2(3);
    ln_bill_amount  number;
    ln_from_account number;
    ln_to_account   number;
    ln_comm_rate   number;
    ls_explain      varchar2(30);
    ls_from_dvz     varchar2(3);
    ls_to_dvz       varchar2(3);
    ls_dvz          varchar2(3);
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_cy_1        varchar2(3);
    ln_amnt_1   number;
    ls_cy_2      varchar2(3);
    ln_amnt_2   number;
    ls_y_cy_1      varchar2(3);
    ln_y_amnt_1   number;
    ls_y_cy_2      varchar2(3);
    ln_y_amnt_2   number;
    ld_today   date;
    ld_tomorrow date;
    ls_branch_3  varchar2(3);
    ls_dv1   varchar2(3);
    ls_dv2   varchar2(3);
    ls_y_dv1   varchar2(3);
    ls_y_dv2   varchar2(3);
    pn_usd_today    number;
    pn_kgs_today    number;
    ln_error    number;

    ld_date        date;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_dv1 := substr(ls_ayrilan_message,1,3);
    --KTDL
    --pkg_atm.CURRENCY_CONVERT(ls_dv1,ls_cy_1);
    ln_amnt_1   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,4,19));

    ls_dv2 := substr(ls_ayrilan_message,23,3);
     --KTDL
    --pkg_atm.CURRENCY_CONVERT(ls_dv2,ls_cy_2);
    ln_amnt_2   := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,26,19));

    ls_y_dv1 := substr(ls_ayrilan_message,45,3);
    --KTDL
    --pkg_atm.CURRENCY_CONVERT(ls_y_dv1,ls_y_cy_1);
    ln_y_amnt_1 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,48,19));

    ls_y_dv2 := substr(ls_ayrilan_message,67,3);
    --KTDL
    --pkg_atm.CURRENCY_CONVERT(ls_y_dv2,ls_y_cy_2);
    ln_y_amnt_2 := pkg_atm.bsof_bakiye_to_number(substr(ls_ayrilan_message,70,19));

    ld_today    := to_date(substr(ls_ayrilan_message,89,8),'yyyymmdd');
    ld_tomorrow := to_date(substr(ls_ayrilan_message,97,8),'yyyymmdd');
    ls_branch_3 := substr(ls_branch,2,3);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Amount kontrol -------
--    select count(*)
--    into ln_cnt
--    from CBS_VW_ATM_DK_SATIR
--    where terminal_id = rtrim(ltrim(ls_terminal_id))
--    and FIS_MUHASEBELESTIGI_TARIH = pkg_muhasebe.Banka_Tarihi_Bul
--    and SATIR_DOVIZ_KOD = 'USD';

--    if ln_cnt = 0
--    then
--        pn_usd_today := 0;
--    else
        --KTDL  
        --ld_date := pkg_muhasebe.Banka_Tarihi_Bul;


        --KTDL
        -- pn_usd_today := get_transactions_total_amount(ls_terminal_id, ld_date, 'USD')
        
--        select /*+ FIRST_ROWS */ sum(NVL(satir_dv_tutar,0))*(-1)
--        into pn_usd_today
--        from CBS_VW_ATM_DK_SATIR
--        where terminal_id = rtrim(ltrim(ls_terminal_id))
--        and FIS_MUHASEBELESTIGI_TARIH = ld_date
----        and FIS_MUHASEBELESTIGI_TARIH = pkg_muhasebe.Banka_Tarihi_Bul
--        and SATIR_DOVIZ_KOD = 'USD';
        
        
--    end if;
-- Today, KGS
--    select count(*)
--    into ln_cnt
--    from CBS_VW_ATM_DK_SATIR
--    where terminal_id = rtrim(ltrim(ls_terminal_id))
--    and FIS_MUHASEBELESTIGI_TARIH = pkg_muhasebe.Banka_Tarihi_Bul
--    and SATIR_DOVIZ_KOD = 'KGS';

--    if ln_cnt = 0
--    then
--        pn_kgs_today := 0;
--    else

         --KTDL
        -- pn_kgs_today := get_transactions_total_amount(ls_terminal_id, ld_date, 'KGS')
        
--        select /*+ FIRST_ROWS */ sum(NVL(satir_dv_tutar,0))*(-1)
--        into pn_kgs_today
--        from CBS_VW_ATM_DK_SATIR
--        where terminal_id = rtrim(ltrim(ls_terminal_id))
--        and FIS_MUHASEBELESTIGI_TARIH = ld_date
----        and FIS_MUHASEBELESTIGI_TARIH = pkg_muhasebe.Banka_Tarihi_Bul
--        and SATIR_DOVIZ_KOD = 'KGS';
--    end if;

    ln_error := 0;

    if ls_cy_1 = 'KGS'
    then
        if ln_amnt_1 <> nvl(pn_kgs_today,0) or ln_amnt_2 <> nvl(pn_usd_today,0)
        then
            ln_error := 1;
        end if;
    else
        if ln_amnt_2 <> nvl(pn_kgs_today,0) or ln_amnt_1 <> nvl(pn_usd_today,0)
        then
            ln_error := 1;
        end if;
    end if;

    if ln_error = 1
    then
           ls_detail_response_code := '949';
        ls_resp_explanation := 'INCORRECT AMOUNTS';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Amount kontrol -------
--
--
------- Dvz Control -------
    if ls_cy_1 not in ('USD','KGS','EUR') or ls_cy_2 not in ('USD','KGS','EUR') or
       ls_y_cy_1 not in ('USD','KGS','EUR') or ls_y_cy_2 not in ('USD','KGS','EUR')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
-- KTDL    
-- ls_ret := PKG_ATM_TRANSACTION.Cash_Operations (ln_islem_kod,
--                                                        ls_cy_1,
--                                                   ln_amnt_1,
--                                                   ls_cy_2,
--                                                   ln_amnt_2,
--                                                   ls_y_cy_1,
--                                                   ln_y_amnt_1,
--                                                   ls_y_cy_2,
--                                                   ln_y_amnt_2,
--                                                   ls_branch_3,
--                                                          ld_today,
--                                                   ld_tomorrow,
--                                                   ls_terminal_id,
--                                                   ls_reference_number,
--                                                    ls_transaction_name ,
--                                                    ls_transaction_code,
--                                                    ls_Orig_authorization_reversal,
--                                                    ls_source_code,
--                                                    ls_terminal_type,
--                                                    ls_transaction_date ,
--                                                    ls_transaction_time,
--                                                   ln_islem_no,
--                                                     ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK');
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;

----------------------------------------------------------------------------------------------------------

FUNCTION ATM_0021(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                          varchar2(200);
    ls_CBS_ERROR_DESC                         varchar2(2000);
    ln_hesap_no                                 number;
    ls_ret                                      varchar2(2000);
    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_BAKIYE                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_islem_no                                number;
    ls_name        varchar2(60);
    ls_adres       varchar2(150);
    ls_semt        varchar2(20);
    ls_il_kod      varchar2(3);
    ls_city        varchar2(20);
    ln_posta_kod   number;
    ls_zip         varchar2(8);
    ls_ulke_kod    varchar2(5);
    ls_town        varchar2(20);
    ls_telefon     varchar2(14);
    ls_sign        varchar2(1);
    ls_status      varchar2(1);
    ln_musteri_no  number;
    a20               varchar2(20);
    a60             varchar2(60);
    a120           varchar2(120);
    ln_cnt            number;
    ls_branch_3       varchar2(3);
    a320           varchar2(320);
    ls_sube_kodu    varchar2(4);
    ls_doviz_kodu     varchar2(10);
    ls_kisa_isim        varchar2(20);
    ls_bs_dvz          varchar2(10);
    ls_musteri_no      varchar2(40);
    ln_kull_bak          number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no :=to_number(substr(ls_ayrilan_message,1,18));
    ls_musteri_no :=rtrim(ltrim(substr(ls_ayrilan_message,19,13)));
    a320 := '                                                                                                                                                                                                                                                                                                                                ';

--
--
-------------------------------- LOG --------------------------------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>null,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL);
-------------------------------- LOG --------------------------------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --Hesap Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   '                                                                                                                                                                                                                                                  00';
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>null,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--

    --KTDL ls_hesap_varmi :=  isThereActiveAccount(ls_account_no)
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no =ls_account_no
--      and durum_kodu = 'A' ;

    --if nvl(ln_hesap_varmi,0) = 0 then
     --KTDL
     if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   '                                                                                                                                                                                                                                                  00';
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
    end if;

--KTDL ln_musteri_no := get_account_cust_no(ls_account_no)
--    select musteri_no
--    into  ln_musteri_no
--    from  cbs_hesap
--    where hesap_no =ls_account_no ;

    if nvl(ln_musteri_no,0) <> to_number(nvl(ls_musteri_no,'0')) and
       to_number(nvl(ls_musteri_no,'0')) <> 0 then
           ls_detail_response_code := '908'; --Hesap Yok
        ls_resp_explanation := 'ACCOUNT NOT BELONG TO CUSTOMER' ;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   '                                                                                                                                                                                                                                                  00';
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
    end if;
--
    
    --if pkg_Atm_transaction.Hesap_Card_hesap_mi(to_number(ls_account_no) ) = 'E' then
    if false then --KTDL if is_card_account(ls_account_no) = 'Y' then
        ls_detail_response_code := '907'; --Hesap Yok
        ls_resp_explanation :=  'ACCOUNT TYPE IS NOT VALID';--'INVALID ACCOUNT NUMBER : ' || ls_account_no;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   '                                                                                                                                                                                                                                                  00';
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
    else
        ln_hesap_no := to_number(ls_account_no);
        ls_branch_3 := substr(ls_branch,2,3);
        
          --KTDL need to replace with common inquiry function
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions(
--                                            8817,
--                                         ln_hesap_no ,
--                                         ls_branch_3          ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                       ln_islem_no       ,
--                                            ls_cbs_error_desc);

        if ls_ret = '000'
        then
        -- KTDL    ln_pending_total := getPendingTotal(ln_from_account);
         -- ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli


---KTDL
        --ln_musteri_no := get_account_cust_no(ln_hesap_no);
        --ls_sube_kodu := get_account_branch(ln_hesap_no);
        --ls_doviz_kodu := get_account_currency(ln_hesap_no);
        --ls_kisa_isim := get_account_short_name(ln_hesap_no);        
--        select musteri_no,
--               sube_kodu,
--               doviz_kodu,
--               kisa_isim
--        into   ln_musteri_no,
--               ls_sube_kodu,
--               ls_doviz_kodu,
--               ls_kisa_isim
--        from   cbs_hesap
--        where hesap_no = ln_hesap_no;
        
        --KTDL
        --pkg_atm.CURRENCY_CONVERT(ls_bs_dvz,ls_doviz_kodu);

        
        -- KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_hesap_no;


        ---KTDL ln_musteri_no := get_account_cust_no(ln_hesap_no);
        -- ls_status := get_account_status(ln_hesap_no);
        
--        select musteri_no ,decode( durum_kodu,'K','4','I','4',
--                                        DECODE(HESAP_HAREKET_KODU,'1','0',
--                                                                 '2','1',
--                                                                '3','2',0))
--        into ln_musteri_no, ls_status
--        from   cbs_hesap
--        where  hesap_no = ln_hesap_no;

        a20 :=  lpad(' ',20,' ') ;
        a60 :=  lpad(' ',60,' ');
        a120 := lpad(' ',120,' ');

        --KTDL pkg_musteri.sf_lokal_ad_al(ln_musteri_no
        --KTDL pkg_musteri.Sf_Musteri_Adi(ln_musteri_no)
        
        --ls_name := substr((rtrim(ltrim( nvl(pkg_musteri.sf_lokal_ad_al(ln_musteri_no), pkg_musteri.Sf_Musteri_Adi(ln_musteri_no))))||a60),1,60);

        --KTDL
        --pkg_musteri.Sp_Musteri_Adres( ln_musteri_no,ls_adres,ls_semt,ls_il_adi,ln_posta_kod,ls_ulke_kod);
        
        
        ls_adres := substr((rtrim(ltrim(ls_adres))||a120),1,120);
        ls_town := substr((rtrim(ltrim(ls_semt))||a20),1,20);
        
       --KTDL pkg_musteri.Sp_Musteri_Adres will return city name (ls_il_adi)
       
       
      /*  SELECT count(*)
        into ln_cnt
        FROM CBS_IL_KODLARI
        WHERE il_kodu = rtrim(ltrim(ls_il_kod));
        if ln_cnt = 1
        then
            SELECT il_adi
            into ls_city
            FROM CBS_IL_KODLARI
            WHERE il_kodu = rtrim(ltrim(ls_il_kod));
        end if;*/
        
        --KTDL 
        --ls_city := ls_il_adi
        
        --ls_city := substr((rtrim(ltrim(ls_city))||a20),1,20);
        
        ls_zip :=  SUBSTR((rtrim(ltrim(to_char(ln_posta_kod)))||'        '),1,8);
        --KTDL pkg_musteri.sf_telefon_al
        --ls_telefon := SUBSTR((rtrim(ltrim(to_char(pkg_musteri.sf_telefon_al(ln_musteri_no))))||'              '),1,14);
        ls_sign := '0';

       ls_detail_response_code := '000';
    ls_resp_explanation := 'OK';
    ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                    '0' ,
                                                               ls_detail_response_code,
                                                               ls_resp_explanation)||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                               ls_name||ls_adres||ls_town||ls_city||
                                                               ls_zip||ls_telefon||ls_sign||ls_status||
                                                               lpad(ls_bs_dvz,3,' ')||
                                                               lpad( to_char(ln_musteri_no),13,'0')||
                                                               lpad( ls_sube_kodu,4,'0')||
                                                               'A'|| --account type
                                                                  rpad(ls_kisa_isim,20,' ')|| --alias
                                                               rpad(' ',8,' ') ;
--
-------------------------------- LOG --------------------------------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL);
                    RETURN ls_response_message;
            else
                  ls_detail_response_code := ls_ret;
                ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
                ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '1' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       '                                                                                                                                                                                                                                                  00';
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL);
-------------------------------- LOG --------------------------------
        RETURN ls_response_message;
      end if;

     end if;
-------------------------------- LOG --------------------------------
--
    RETURN ls_response_message;

EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
--end++++++++++++++++++++++++++++++++++++++++++++++++++
---------------------------------------------------------------------------------
FUNCTION ATM_REVERSAL(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ln_fis_no            number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO =>  NULL,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT =>  NULL,
                                p_CURRENCY =>  NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--------------------------------------------------------------------------------
-- iptal edilecek islemin numarasi ve fis numarasi sorgulanir.
--------------------------------------------------------------------------------
------- Referecneand Transaction and Journal Control -------
  if nvl(ls_reference_number,'X') ='X' then
   -- reference bos olamaz
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(902);
           ls_detail_response_code := '096';
        ls_resp_explanation :=  ls_CBS_ERROR_DESC||' REFERANCE : '|| ls_reference_number;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
  end if;

  --- KTDL ln_islem_no := pkg_atm_api.GetIslemNoFromReferance(ls_reference_number);

   if nvl(ln_islem_no,0) = 0 then
   -- islem no bulanamadi
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(903);
           ls_detail_response_code := '096';
        ls_resp_explanation :=ls_CBS_ERROR_DESC ||' REFERANCE : '||ls_reference_number;
        ls_response_message  :=PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
  end if;

   --KTDL ln_fis_no := pkg_atm_api.GetFisNoFromReferance(ls_reference_number);

---------------------------------- Simdi basliyor ----------------------------------
   --KTDL pkg_Atm_Api.cancel_transaction(ln_islem_no, ls_ret,ls_CBS_ERROR_DESC);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK');
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO =>  null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO =>  null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO =>  null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
FUNCTION ATM_0503(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8800;
    ln_kull_bak                     number;
    i                             number :=0;
    ls_bad_list                     varchar2(1);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
    ls_from_dvz                  := '';--KTDL pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    -- KTDL pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    -- KTDL pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    -- KTDL pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------
-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
------- Badlist Control -------
-- KTDL ls_bad_list := isAccountInBadList(ln_from_account);
--    select nvl(BADLIST_FLAG,'H')
--    into  ls_bad_list
--    from cbs_hesap
--    where hesap_no = ln_from_account;

    if ls_bad_list  = 'Y'
    then
           ls_detail_response_code := '907'; --Hesap Yok
        ls_resp_explanation := 'ACCOUNT IS IN BADLIST  : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- Badlist Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
-- KTDL getAvailBalance(ln_from_account) < convertCurrency(ls_bill_dvz, ls_from_dvz, nvl(ln_bill_amount,0), 1, 'N', 'S')
-- if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_bill_dvz,ls_from_dvz,null,nvl(ln_bill_amount,0),1,null,null,'N','S')
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

-- KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_from_account);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

-- KTDL processFinTran;
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
    ln_overdraft_limit := 0;       
-- KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_from_account);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
--         getCommission(ln_islem_no, ln_masraf_toplam, ls_masraf_doviz);        

--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
             -- KTDL  ln_som_comm_amount := convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0),1, 'N', 'S');
             null;--ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
            -- KTDL  ln_usd_comm_amount := convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0),1, 'N', 'S');
             null;-- ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_cbs_error_desc := ls_cbs_error_desc||'|'||pkg_hata.generatemessage(pkg_hata.getucpointer || '2595' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        ls_ret :=pkg_atm_api.geterrorcode(ls_cbs_error_desc);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------


FUNCTION POS_ATM_0518(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ls_hesap_varmi                              Varchar2(3);
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_BAKIYE                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_cnt                                    number;
    ls_CBS_ERROR_DESC                         varchar2(2000);
    ls_ret                                      varchar2(2000);
    ls_branch_3                               varchar(3);
    ln_islem_no                                number;
    ln_kull_bak                                  number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no :=to_number(substr(ls_ayrilan_message,1,18));
--
--
--
-------------------------------- LOG --------------------------------

    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --Hesap Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
-- KTDL ls_hesap_varmi :=  isThereActiveAccount(ln_account_no IN NUMBER)
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no =ls_account_no
--      and durum_kodu = 'A' ;

    --if nvl(ln_hesap_varmi,0) = 0 then
    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
     else
        ln_hesap_no := to_number(ls_account_no);
        ls_branch_3 := substr(ls_branch,2,3);
        
       --KTDL need to replace with common inquiry function
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions
--                                     (  8805,
--                                         ln_hesap_no ,
--                                         ls_branch_3         ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number     ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                            ln_islem_no       ,
--                                            ls_cbs_error_desc);

        -- response balance values
        if ls_ret = '000'
        then
        
          ln_overdraft_limit := 0; 
          

            -- KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_from_account);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

       /*ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
         
            select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
            from cbs_hesap_Bakiye
            where hesap_no = ln_hesap_no;*/

            ls_detail_response_code := '000';
            ls_resp_explanation := 'OK';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0));

            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

           RETURN ls_response_message;
          else
                    ls_detail_response_code := ls_ret;
                ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
                ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0));

    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
      end if;
   end if;

    RETURN ls_response_message;

    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;


END;
/

