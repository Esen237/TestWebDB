create PACKAGE Pkg_ATM_Api IS

TYPE CursorReferenceType IS REF CURSOR;
------------------------------------------------------------------------------------------
FUNCTION GetErrorCode(ps_errortext IN VARCHAR2) RETURN VARCHAR2 ;

FUNCTION GetErrorDesc(
                        ps_errorcd IN VARCHAR2 ,
                        ps_langcd    IN VARCHAR2 DEFAULT 'ENG',
                       ps_systemcd IN VARCHAR2 DEFAULT 'CBS'
                       ) RETURN VARCHAR2 ;


END;
/

