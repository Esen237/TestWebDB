create PACKAGE           pkg_atm_pos IS
--------------------------------------------------------------------------------
FUNCTION Atm_Pos_Transactions(ps_message varchar2) RETURN VARCHAR2;
--------------------------------------------------------------------------------
FUNCTION ATM_0021(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0090(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0091(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0092(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0096(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0515(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0520(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0551(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0552(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0553(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0555(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0607(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0609(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0701(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0707(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0711(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0801(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0803(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0805(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0807(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0901(ps_message varchar2) RETURN VARCHAR2;
FUNCTION POS_1007(ps_message varchar2) RETURN VARCHAR2;
FUNCTION POS_1307(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1009(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1102(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1103(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1107(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1110(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1203(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1207(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1211(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1210(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1213(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1215(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1217(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1219(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1309(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1310(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1311(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_1312(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_0023(ps_message varchar2) RETURN VARCHAR2;
FUNCTION ATM_REVERSAL(ps_message varchar2) RETURN VARCHAR2;

FUNCTION POS_ATM_0518(ps_message varchar2) RETURN VARCHAR2;

FUNCTION ATM_0503(ps_message varchar2) RETURN VARCHAR2;
END;
/

