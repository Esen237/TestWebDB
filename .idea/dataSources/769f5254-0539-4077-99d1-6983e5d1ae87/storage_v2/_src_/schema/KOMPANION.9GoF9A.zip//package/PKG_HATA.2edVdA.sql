create package           PKG_HATA is

  G_DELIMITER varchar(3):='###';
  G_UC_POINTER varchar(3):='***';
  
   FUNCTION GetDELIMITER RETURN VARCHAR2;
   
   FUNCTION GetUCPOINTER RETURN VARCHAR2;

   Function HataMesajiGetir(hata_kodu NUMBER,dil_kodu varchar2) return varchar2;

   Function GenerateMessage(p_dbms_errtxt varchar2) return varchar2;   
 END;
/

