create PACKAGE BODY               Pkg_Kur IS


  c_kur_tip    CONSTANT NUMBER := 3;
  g_uc_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  g_ara_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getDELIMITER;
 
FUNCTION YUVARLA(p_doviz_kod VARCHAR2, p_tutar NUMBER) RETURN NUMBER IS
    v_kuruslu                VARCHAR2(1);
BEGIN
  SELECT    kuruslu_mu
    INTO    v_kuruslu
    FROM    CBS_DOVIZ_KODLARI
   WHERE    doviz_kodu = p_doviz_kod;

  IF v_kuruslu = 'H' THEN
      RETURN(ROUND(p_tutar,0));
  ELSE
      RETURN(ROUND(p_tutar,2));
  END IF;


END;

FUNCTION fun_truncate(ps_currency VARCHAR2, pn_amount NUMBER) RETURN NUMBER IS
    v_kuruslu                VARCHAR2(1);
BEGIN
  SELECT    kuruslu_mu
    INTO    v_kuruslu
    FROM    CBS_DOVIZ_KODLARI
   WHERE    doviz_kodu = ps_currency;

  IF v_kuruslu = 'H' THEN
      RETURN(TRUNC(pn_amount,0));
  ELSE
      RETURN(TRUNC(pn_amount,2));
  END IF;
END;
 
 FUNCTION DAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
--                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
--                                                        Pkg_Genel.lc_al,
--                                                        NULL,
--                                                        pn_tutar,
--                                                        1,
--                                                        NULL,
--                                                        NULL,
--                                                        'O',
--                                                        'A')
                            1
                            ));
 END;
/*****************************************************************************/
 FUNCTION EAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
--                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
--                                                        Pkg_Genel.lc_al,
--                                                        NULL,
--                                                        pn_tutar,
--                                                        2,
--                                                        NULL,
--                                                        NULL,
--                                                        'O',
--                                                        'S')
                            1
                            ));
 END;
/*****************************************************************************/
 FUNCTION DSK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
--                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
--                                                        Pkg_Genel.lc_al,
--                                                        NULL,
--                                                        pn_tutar,
--                                                        1,
--                                                        NULL,
--                                                        NULL,
--                                                        'O',
--                                                        'S')
                            1
                            ));
 END;
/*****************************************************************************/
 FUNCTION ESK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
--                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
--                                                        Pkg_Genel.lc_al,
--                                                        NULL,
--                                                        pn_tutar,
--                                                        2,
--                                                        NULL,
--                                                        NULL,
--                                                        'O',
--                                                        'S')
                            1
                            ));
 END;
/*****************************************************************************/

FUNCTION MB_DAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
--                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
--                                                        Pkg_Genel.lc_al,
--                                                        NULL,
--                                                        pn_tutar,
--                                                        1,
--                                                        NULL,
--                                                        NULL,
--                                                        'N',
--                                                        'A')
                            1
                            ));
 END;


END;
/

