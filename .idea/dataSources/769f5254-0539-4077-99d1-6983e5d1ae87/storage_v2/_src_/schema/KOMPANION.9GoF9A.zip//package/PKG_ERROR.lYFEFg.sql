create package           PKG_ERROR is

  G_DELIMITER varchar(3):='###';
  G_UC_POINTER varchar(3):='***';
  
   FUNCTION GetDELIMITER RETURN VARCHAR2;
   
   FUNCTION GetUCPOINTER RETURN VARCHAR2;
   
 END;
/

