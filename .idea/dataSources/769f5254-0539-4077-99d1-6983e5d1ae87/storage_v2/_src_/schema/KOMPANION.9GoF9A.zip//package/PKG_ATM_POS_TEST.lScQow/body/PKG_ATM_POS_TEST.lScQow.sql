create PACKAGE BODY           "PKG_ATM_POS_TEST" IS
--------------------------------------------------------
FUNCTION Atm_Pos_Transactions(ps_message varchar2) RETURN VARCHAR2
is
    pn_log_no                                   NUMBER;
    ls_response_message                      varchar2(2000);
    ls_transaction_code                      varchar2(2000);
    ld_start_date                             date;
    ld_end_date                                 date;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;
    ln_count_reverse                            number := 0;
BEGIN
    ld_start_date := sysdate;
--
-- ASAGIDAKILER OK
--
--
--   TYPE : BALANCE INQUIRY - 1
/*Acc Inquiry-1                                                             *//*0518- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';
/*SWC ATM-FR-Debit Bakiye Sorma                                  *//*1110- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';
/*VISA OU Bakiye Sorma                                           *//*1210- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';
/*ATM-FR-Debit Bakiye Sorma                                      *//*0807- */--ps_message := '0356BSOF0518O7777    100110010DK001   2007011510101000000000000000001000000000000001481';

--
--   TYPE : BALANCE INQUIRY - 2
/*Acc Inquiry-2                                                            *//*0021- */--ps_message := '0356BSOF0021O7777    100110010DK001   2007011510101000000000000000001000000000000001481';

--
--   TYPE : MINI STATEMENT
/*Last 15 Statements - Reversal                                  *//*0521- */--ps_message := '0356BSOF1521O7777    100110010DK001   2007011510101000000000000000001000000000000000002';

--
--   TYPE : CASH OPERATIONS
/*EOD                                                            *//*0090- */--ps_message := '0356BSOF0090O7777    100110010DK001   2006110310101000000000000000001417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';
/*EOD - Reversal                                                 *//*0093- */--ps_message := '0356BSOF0093I7777    100110010DK001   2007011510101000000000000000001417+000000000000010.00840+000000000000020.002007011520070116';
/*Money In                                                       *//*0091- */--ps_message := '0356BSOF0091O7777    100110010DK001   2006110310101000000000000000001417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';
/*Money In - Reversal                                            *//*0094- */--ps_message := '0356BSOF0094I7777    100110010DK001   2007011510101000000000000000001417+000000000000010.00840+000000000000020.002007011520070116';
/*Money Out                                                      *//*0092- */--ps_message := '0356BSOF0092O7777    100110010DK001   2006110310101000000000000000001417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';
/*Money Out Reversal                                             *//*0091- */--ps_message := '0356BSOF0095I7777    100110010DK001   2006110310101000000000000000444417+000000000000010.00840+000000000000020.00417+000000000000030.00840+000000000000040.002007110320071106';

--
--   TYPE : FINANCIAL TRANSACTIONS
/*Rate Inquiry                                                             *//*0551- */--ps_message := '0356BSOF0551O7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00840+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Rate Inquiry                                                           *//*0552- */--ps_message := '0356BSOF0552O7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00840+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Buy FX                                                                    *//*0553- */--ps_message := '0356BSOF0553O7777    100110010DK001   2007011510101000000000000000223000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000100.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001480ACIKLAMA SAHASI               ';
/*Buy FX - Reversal                                                      *//*0554- */--ps_message := '0356BSOF0554I7777    100110010DK001   2007011510101000000000000000223000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000100.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001480ACIKLAMA SAHASI               ';
/*Sell FX                                                                 *//*0555- */--ps_message := '0356BSOF0555O7777    100110010DK001   2007011510101000000000000000224000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000500.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Sell FX - Reversal                                                      *//*0556- */--ps_message := '0356BSOF0556I7777    100110010DK001   2007011510101000000000000000224000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000500.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001480000000000000001481ACIKLAMA SAHASI               ';
/*Money Transfer                                                          *//*0515- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Money Transfer - Reversal                                                 *//*0516- */--ps_message := '0356BSOF0516I7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Money Withdrawal                                                         *//*0503- */--ps_message := '0356BSOF0503O7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000150.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               ';
/*Money Withdrawal - Reversal                                              *//*0504- */--ps_message := '0356BSOF0504I7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               '
/*Pos Transaction                                                *//*1007- */--ps_message := '0356BSOF1007O7777    100110010DK001   2006110310101000000000000001007000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Pos Transaction - Reversal                                     *//*1008- */--ps_message := '0356BSOF1008I7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               '
/*Pos Refund Transaction                                         *//*1307- */--ps_message := '0356BSOF1307O7777    100110010DK001   2006110310101000000000000001007000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Pos Refund Transaction - Reversal                              *//*1308- */--ps_message := '0356BSOF1308I7777    100110010DK001   2007011510101000000000000000001000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481                  ACIKLAMA SAHASI               '
/*Nakit Avans - Reversal                                         *//*0702- */--ps_message := '0356BSOF0702O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Kredi Kart Borc Odeme - Reversal                               *//*0712- */--ps_message := '0356BSOF0712O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Hesaptan Iade                                                  *//*1009- */--ps_message := '0356BSOF1009O7777    100110010DK001   2006110310101000000000000009009000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Hesaptan Iade - Reversal                                       *//*1010- */--ps_message := '0356BSOF1010I7777    100110010DK001   2006110310101000000000000009009000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU417+000000000000000.00417+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020061103000000000000000007                  ACIKLAMA SAHASI               ';
/*Hesaba Cash Para Yatirma (SOM) - Reversal                      *//*0608- */--ps_message := '0356BSOF0608O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Hesaba Cash Para Yatirma (USD) - Reversal                      *//*0610- */--ps_message := '0356BSOF0610O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Kredi Kart Borc Odeme Cash Para Yatirarak (SOM) - Reversal     *//*0708- */--ps_message := '0356BSOF0708O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Para Cekme DO - Reversal                                       *//*0802- */--ps_message := '0356BSOF0802O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*VISA OU Para Cekme - Reversal                                  *//*1204- */--ps_message := '0356BSOF1204O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*SWC Para Cekme FR - Reversal                                   *//*1104- */--ps_message := '0356BSOF1104O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Para Cekme FR                                                  *//*0805- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Para Cekme FR - Reversal                                       *//*0806- */--ps_message := '0356BSOF0806O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Nakit Avans                                                    *//*0901- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Nakit Avans - Reversal                                         *//*0902- */--ps_message := '0356BSOF0902O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Last 15 Statements                                             *//*0520- */--ps_message := '0356BSOF0520O7777    100110010DK001   2007011510101000000000000000001000000000000000002';
/*Nakit Avans                                                    *//*0701- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*Kredi Kart Borc Odeme                                          *//*0711- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- ---- -- -- -- -- -- -- -- -- -- -- ---- -- -- -- -- -- -- -- -- -- -- --

--
-- ASAGIDAKILER NOK
--

/*VISA OU Para Cekme                                             *//*1203- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';
/*VISA OU Para Cekme                                             *//*1207- */--ps_message := '0356BSOF0515O7777    100110010DK001   2007011510101000000000000000222000000000001000000000000001MERCHANT NAME                           1234567890123456   DPOU075+000000000000000.00075+000000000000000.00417+000000000000010.000000+000000000000000.00+000000000000000.00+000000000000000.0020070115000000000000001481000000000000001488ACIKLAMA SAHASI               ';

    pn_log_no := PKG_GENEL.genel_kod_al('ATMLOGINC');
    INSERT INTO CBS_ATM_POS_TRAN_LOG_INC
    (LOG_NO, MESSAGE_TYPE,  MESSAGE)
    VALUES
    (pn_log_no,'INCOMING',ps_message);

    pkg_atm.GetTranCode(ps_message,ls_transaction_code);  
    

--   TYPE : BALANCE INQUIRY - 1

    /*Balance Inquiry*/
    if ls_transaction_code = '0518'    then ls_response_message := POS_ATM_0518(ps_message); end if;

    
--   TYPE : FINANCIAL TRANSACTIONS

    /*Money Withdrawal*/
    if ls_transaction_code = '0503'    then ls_response_message := ATM_0503(ps_message); end if;
    
    

    ld_end_date := sysdate;
         

 IF Pkg_Atm.Need_Reversal(ls_transaction_code)='E' THEN
        pkg_atm.Parse_Incoming_Message(ps_message ,       
                                        ls_ayrilan_message  ,
                                       ls_transaction_name ,
                                       ls_transaction_code ,
                                       ls_Orig_authorization_reversal,
                                       ls_user                 ,
                                       ls_transaction_type  ,
                                       ls_source_code        ,
                                       ls_terminal_type        ,
                                       ls_branch            ,
                                       ls_terminal_id        ,
                                       ls_transaction_date  ,
                                       ls_transaction_time  ,
                                       ls_reference_number);
        SELECT COUNT(*)
        INTO ln_count_reverse
         FROM cbs_atm_pos_tran_log A, cbs_atm_tran_kodlari b
        WHERE referance = ls_reference_number
             AND A.in_transaction_code = b.tran_kod
             AND b.tip = 'Iptal';
         
     IF Pkg_Atm.Time_Out(ld_start_date,ld_end_date) = 'E' THEN
        --MAKE TRANSACTION REVERSE
        ls_response_message := ATM_REVERSAL(ps_message);  
        ls_response_message := Pkg_Atm.STANDARDRESPONSEHEADER(ls_reference_number,'1' ,'096','TIMEOUT');   
     ELSIF ln_count_reverse > 0 THEN
        --MAKE TRANSACTION REVERSE
        ls_response_message := ATM_REVERSAL(ps_message);  
        ls_response_message := Pkg_Atm.STANDARDRESPONSEHEADER(ls_reference_number,'1' ,'096','CBS REVERSAL');         
     End if;
       
 END IF; 

    pn_log_no := PKG_GENEL.genel_kod_al('ATMLOGINC');
    INSERT INTO CBS_ATM_POS_TRAN_LOG_INC
    (LOG_NO, MESSAGE_TYPE,  MESSAGE)
    VALUES
    (pn_log_no,'OUTGOING',ls_response_message);

    RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_REVERSAL(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ln_fis_no            number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO =>  NULL,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT =>  NULL,
                                p_CURRENCY =>  NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--------------------------------------------------------------------------------
-- iptal edilecek islemin numarasi ve fis numarasi sorgulanir.
--------------------------------------------------------------------------------
------- Referecneand Transaction and Journal Control -------
  if nvl(ls_reference_number,'X') ='X' then
   -- reference bos olamaz
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(902);
           ls_detail_response_code := '096';
        ls_resp_explanation :=  ls_CBS_ERROR_DESC||' REFERANCE : '|| ls_reference_number;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
  end if;

  --- KTDL ln_islem_no := pkg_atm_api.GetIslemNoFromReferance(ls_reference_number);

   if nvl(ln_islem_no,0) = 0 then
   -- islem no bulanamadi
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(903);
           ls_detail_response_code := '096';
        ls_resp_explanation :=ls_CBS_ERROR_DESC ||' REFERANCE : '||ls_reference_number;
        ls_response_message  :=PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
  end if;

   --KTDL ln_fis_no := pkg_atm_api.GetFisNoFromReferance(ls_reference_number);

---------------------------------- Simdi basliyor ----------------------------------
   --KTDL pkg_Atm_Api.cancel_transaction(ln_islem_no, ls_ret,ls_CBS_ERROR_DESC);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK');
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO =>  null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO =>  null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO =>  null,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
FUNCTION ATM_0503(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_hesap_varmi                              varchar2(3);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8800;
    ln_kull_bak                     number;
    i                             number :=0;
    ls_bad_list                     varchar2(1);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
    ls_from_dvz                  := '';--KTDL pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------
-- KTDL ls_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
------- Badlist Control -------
-- KTDL ls_bad_list := isAccountInBadList(ln_from_account);
--    select nvl(BADLIST_FLAG,'H')
--    into  ls_bad_list
--    from cbs_hesap
--    where hesap_no = ln_from_account;

    if ls_bad_list  = 'Y'
    then
           ls_detail_response_code := '907'; --Hesap Yok
        ls_resp_explanation := 'ACCOUNT IS IN BADLIST  : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- Badlist Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
-- KTDL getAvailBalance(ln_from_account) < convertCurrency(ls_bill_dvz, ls_from_dvz, nvl(ln_bill_amount,0), 1, 'N', 'S')
-- if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_bill_dvz,ls_from_dvz,null,nvl(ln_bill_amount,0),1,null,null,'N','S')
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

-- KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_from_account);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

-- KTDL processFinTran;
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
    ln_overdraft_limit := 0;       
-- KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_from_account);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
--         getCommission(ln_islem_no, ln_masraf_toplam, ls_masraf_doviz);        

--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
             -- KTDL  ln_som_comm_amount := convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0),1, 'N', 'S');
             null;--ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
            -- KTDL  ln_usd_comm_amount := convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0),1, 'N', 'S');
             null;-- ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_cbs_error_desc := ls_cbs_error_desc||'|'||pkg_hata.generatemessage(pkg_hata.getucpointer || '2595' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        ls_ret :=pkg_atm_api.geterrorcode(ls_cbs_error_desc);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------


FUNCTION POS_ATM_0518(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ls_hesap_varmi                              Varchar2(3);
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_BAKIYE                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_cnt                                    number;
    ls_CBS_ERROR_DESC                         varchar2(2000);
    ls_ret                                      varchar2(2000);
    ls_branch_3                               varchar(3);
    ln_islem_no                                number;
    ln_kull_bak                                  number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no :=to_number(substr(ls_ayrilan_message,1,18));
--
--
--
-------------------------------- LOG --------------------------------

    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --Hesap Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
-- KTDL ls_hesap_varmi :=  isThereActiveAccount(ln_account_no IN NUMBER)
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no =ls_account_no
--      and durum_kodu = 'A' ;

    --if nvl(ln_hesap_varmi,0) = 0 then
    if ls_hesap_varmi = 'N' then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
     else
        ln_hesap_no := to_number(ls_account_no);
        ls_branch_3 := substr(ls_branch,2,3);
        
       --KTDL need to replace with common inquiry function
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions
--                                     (  8805,
--                                         ln_hesap_no ,
--                                         ls_branch_3         ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number     ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                            ln_islem_no       ,
--                                            ls_cbs_error_desc);

        -- response balance values
        if ls_ret = '000'
        then
        
          ln_overdraft_limit := 0; 
          

            -- KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_from_account);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

       /*ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
         
            select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
            from cbs_hesap_Bakiye
            where hesap_no = ln_hesap_no;*/

            ls_detail_response_code := '000';
            ls_resp_explanation := 'OK';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0));

            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

           RETURN ls_response_message;
          else
                    ls_detail_response_code := ls_ret;
                ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
                ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0));

    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
      end if;
   end if;

    RETURN ls_response_message;

    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_0807(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_BAKIYE                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_cnt                                    number;
    ls_CBS_ERROR_DESC                         varchar2(2000);
    ls_ret                                      varchar2(2000);
    ls_branch_3                               varchar(3);
    ln_islem_no                                number;
    ln_kull_bak                                  number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no :=to_number(substr(ls_ayrilan_message,1,18));
--
--
--
-------------------------------- LOG --------------------------------

    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --Hesap Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no =ls_account_no
--      and durum_kodu = 'A' ;
-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_account_no);

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
     else
        ln_hesap_no := to_number(ls_account_no);
        ls_branch_3 := substr(ls_branch,2,3);
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions
--                                     (  8816,
--                                         ln_hesap_no ,
--                                         ls_branch_3         ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number     ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                            ln_islem_no       ,
--                                            ls_cbs_error_desc);
-- KTDL inquiry call

        -- response balance values
        if ls_ret = '000'
        then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
--            ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--  KTDL          ln_pending_total := getPendingTotal(ln_hesap_no);
--          ln_kull_bak := getAvailBalance(hesap_no);
--           getBalancesForAccount(hesap_no, ln_bakiye, ln_blocked_amount); 

--            select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--            from cbs_hesap_Bakiye
--            where hesap_no = ln_hesap_no;


            ls_detail_response_code := '000';
            ls_resp_explanation := 'OK';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0));

            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

           RETURN ls_response_message;
          else
                    ls_detail_response_code := ls_ret;
                ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
                ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0));

    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
      end if;
   end if;

    RETURN ls_response_message;

    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_0901(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8819;
    ln_from_account                 number;
    ls_from_dvz                     varchar2(3);
    ln_to_account                 number;
    ls_to_dvz                       varchar2(3);

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  := substr(ls_branch,2,3);
    ls_explain                   := substr(ls_ayrilan_message,262,30);
    ln_from_account                 := null;
    ls_from_dvz                     := null;
    ln_to_account                 := null;
    ls_to_dvz                     := null;

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_original_amount,
                                p_CURRENCY => ls_original_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- Dvz Control -------
    if ls_original_dvz not in ('USD','KGS')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
-- KTDL financial transaction
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_original_amount,
                                    p_CURRENCY => ls_original_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION POS_1007(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                       varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                         varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8807;
    ln_BAKIYE                                 number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                         number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_cnt                                    number;
    ls_ret                                      varchar2(2000);
    ln_islem_no                                  number;
    ls_cbs_error_desc                         varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account_number       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account_number         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_kull_bak                     number;
    ls_fx_convert                    varchar2(1);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    --CQ845 if this on us virtual pos, then run 1007 transaction BEGIN 13022014 almasn
    if (ls_source_code = '10' and substr(ls_ayrilan_message,87,1) = 'D' and substr(ls_ayrilan_message,89,2) = 'OU') then
        pkg_parametre.deger('G_ATM_MERKEZ_SUBE', ls_branch);
        ls_branch := ' ' || ls_branch;
    end if;
    --CQ845 if this on us virtual pos, then run 1007 transaction END 13022014 almasn
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');

    ls_branch_3 :=substr(ls_branch,2,3);

    if substr(ls_ayrilan_message,226,18) in ('                  ','000000000000000000')
    then
        ln_from_account_number       := null;
        ls_from_dvz                  := null;
    else
        ln_from_account_number       := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL 
--        ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account_number);
    end if;

    if substr(ls_ayrilan_message,244,18) in ('                  ','000000000000000000')
    then
        ln_to_account_number         := null;
        ls_to_dvz                    := null;
    else
        ln_to_account_number         := to_number(substr(ls_ayrilan_message,244,18));
-- KTDL        
--        ls_to_dvz                    := pkg_hesap.HesaptanDovizKoduAl(ln_to_account_number);
    end if;

    ls_explain                   := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account_number,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- From Account Control -------

-- KTDL ls_fx_convert := getFXConvert(ln_from_account_number);
--    select nvl(fx_convert,'H')
--    into ls_fx_convert
--    from cbs_musteri
--    where musteri_no = pkg_hesap.HesaptanMusteriNoAl(ln_from_account_number);

    if ls_fx_convert = 'H'
    then
-- KTDL     ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
--          check if currency code is equal to KGS and only then proceed
        null;
--        select count(*)
--        into ln_hesap_varmi
--        from cbs_hesap
--        where hesap_no = ln_from_account_number
--          and DOVIZ_KODU = pkg_genel.LC_al
--          and durum_kodu = 'A' ;
    else
        null;    
-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
--        select count(*)
--        into ln_hesap_varmi
--        from cbs_hesap
--        where hesap_no = ln_from_account_number
--          and durum_kodu = 'A' ;
    end if;
          
    if nvl(ln_hesap_varmi,0) = 0
    then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account_number;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('KGS','USD','EUR') --or ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account_number) < ln_bill_amount

-- KTDL getTotalBalance(ln_from_account_number, ls_bill_dvz_ls_card_number) < ln_bill_amount
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account_number,ls_bill_dvz, ls_card_number),0) < ln_bill_amount
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account_number;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);

-- KTDL ln_kull_bak := getAvailBalance(ln_from_account_number);
--          ln_pending_total := getPendingTotal(ln_from_account_number);
--         getBalancesForAccount(ln_from_account_number, ln_bakiye, ln_blocked_amount); 

        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;


-- KTDL financial transaction
--    ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account_number,
--                                              ls_from_dvz,
--                                              ln_to_account_number,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
-- KTDL ln_kull_bak := getAvailBalance(ln_from_account_number);
--         getBalancesForAccount(ln_from_account_number, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account_number;


        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
         ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION POS_1307(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                       varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                         varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8840;
    ln_BAKIYE                                 number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                         number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_cnt                                    number;
    ls_ret                                      varchar2(2000);
    ln_islem_no                                  number;
    ls_cbs_error_desc                         varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account_number       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account_number         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_kull_bak                     number;
    ls_fx_convert                    varchar2(1);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    --CQ845 if this on us virtual pos, then run 1007 transaction BEGIN 13022014 almasn
    if (ls_source_code = '10' and substr(ls_ayrilan_message,87,1) = 'D' and substr(ls_ayrilan_message,89,2) = 'OU') then
        pkg_parametre.deger('G_ATM_MERKEZ_SUBE', ls_branch);
        ls_branch := ' ' || ls_branch;
    end if;
    --CQ845 if this on us virtual pos, then run 1007 transaction END 13022014 almasn
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');

    ls_branch_3 :=substr(ls_branch,2,3);

    if substr(ls_ayrilan_message,226,18) in ('                  ','000000000000000000')
    then
        ln_from_account_number       := null;
        ls_from_dvz                  := null;
    else
        ln_from_account_number       := to_number(substr(ls_ayrilan_message,226,18));
--  KTDL 
--        ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account_number);
    end if;

    if substr(ls_ayrilan_message,244,18) in ('                  ','000000000000000000')
    then
        ln_to_account_number         := null;
        ls_to_dvz                    := null;
    else
        ln_to_account_number         := to_number(substr(ls_ayrilan_message,244,18));
--  KTDL
--        ls_to_dvz                    := pkg_hesap.HesaptanDovizKoduAl(ln_to_account_number);
    end if;

    ls_explain                   := substr(ls_ayrilan_message,262,30);


    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account_number,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- From Account Control -------

-- KTDL ls_fx_convert := getFXConvert(ln_from_account_number);

--    select nvl(fx_convert,'H')
--    into ls_fx_convert
--    from cbs_musteri
--    where musteri_no = pkg_hesap.HesaptanMusteriNoAl(ln_from_account_number);

    if ls_fx_convert = 'H'
    then
    null;
-- KTDL     ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
--          check if currency code is equal to KGS and only then proceed    
    
--        select count(*)
--        into ln_hesap_varmi
--        from cbs_hesap
--        where hesap_no = ln_from_account_number
--          and DOVIZ_KODU = pkg_genel.LC_al
--          and durum_kodu = 'A' ;
    else
    null;
-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
    
--        select count(*)
--        into ln_hesap_varmi
--        from cbs_hesap
--        where hesap_no = ln_from_account_number
--          and durum_kodu = 'A' ;
    end if;
          
    if nvl(ln_hesap_varmi,0) = 0
    then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account_number;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('KGS','USD','EUR') --or ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account_number) < ln_bill_amount

-- KTDL getTotalBalance(ln_from_account_number, ls_bill_dvz, ls_card_number) < ln_bill_amount
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account_number,ls_bill_dvz, ls_card_number),0) < ln_bill_amount
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

-- KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account_number;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

-- KTDL financial transaction
--    ls_ret := pkg_Atm_transaction.Financial_transactions(ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                              ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account_number,
--                                              ls_from_dvz,
--                                              ln_to_account_number,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);
    if ls_ret = '000'
    then
-- KTDL ln_kull_bak := getAvailBalance(ln_from_account_number);
--         getBalancesForAccount(ln_from_account_number, ln_bakiye, ln_blocked_amount);      
    
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account_number;


        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
         ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_1009(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                       varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal           varchar2(2000);
    ls_user                                   varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                          varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                         varchar2(200);
    ln_hesap_no                                 number;
    ln_islem_kod                             number := 8809;
    ln_BAKIYE                                 number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                         number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_cnt                                    number;
    ls_ret                                      varchar2(2000);
    ln_islem_no                                  number;
    ls_cbs_error_desc                         varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account_number       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account_number         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);
    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         := to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');

    ls_branch_3 :=substr(ls_branch,2,3);

    if substr(ls_ayrilan_message,226,18) in ('                  ','000000000000000000')
    then
        ln_from_account_number       := null;
        ls_from_dvz                  := null;
    else
        ln_from_account_number       := to_number(substr(ls_ayrilan_message,226,18));
--  KTDL 
--        ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account_number);
    end if;

    if substr(ls_ayrilan_message,244,18) in ('                  ','000000000000000000')
    then
        ln_to_account_number         := null;
        ls_to_dvz                    := null;
    else
        ln_to_account_number         := to_number(substr(ls_ayrilan_message,244,18));
--  KTDL 
--        ls_to_dvz                    := pkg_hesap.HesaptanDovizKoduAl(ln_to_account_number);
    end if;

    ls_explain                   := substr(ls_ayrilan_message,262,30);


    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);
--
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account_number,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
--    select count(*)
--    into ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account_number
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0
    then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account_number;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('KGS','USD','EUR') or ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
-- KTDL financial transaction
--    ls_ret := pkg_Atm_transaction.Financial_transactions (ln_islem_kod,
--                                                   ls_acquirer_bank,
--                                              ls_merchant_number,
--                                              ls_merchant_location,
--                                              ls_card_number,
--                                              ls_card_type,
--                                              ls_card_brand,
--                                              ls_card_domain,
--                                               ls_original_dvz,
--                                              ln_original_amount,
--                                              ls_settlement_dvz,
--                                              ln_settlement_amount,
--                                              ls_bill_dvz,
--                                              ln_bill_amount,
--                                              ln_commission_rate,
--                                              ln_minimum_commission_amount,
--                                              ln_maximum_commission_amount,
--                                              ln_fixed_commission_amount,
--                                              ld_business_date,
--                                              ln_from_account_number,
--                                              ls_from_dvz,
--                                              ln_to_account_number,
--                                              ls_to_dvz,
--                                              ls_explain,
--                                              ls_branch_3,
--                                              ls_terminal_id,
--                                              ls_reference_number,
--                                              ls_transaction_name ,
--                                              ls_transaction_code,
--                                              ls_Orig_authorization_reversal,
--                                              ls_source_code,
--                                              ls_terminal_type,
--                                              ls_transaction_date ,
--                                              ls_transaction_time,
--                                              ln_islem_no,
--                                              ls_cbs_error_Desc);
    if ls_ret = '000'
    then
-- KTDL ln_kull_bak := getAvailBalance(ln_from_account_number);
--         getBalancesForAccount(ln_from_account_number, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account_number;


        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account_number,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_1102(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_BAKIYE                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_cnt                                    number;
    ls_CBS_ERROR_DESC                         varchar2(2000);
    ls_ret                                      varchar2(2000);
    ls_branch_3                               varchar(3);
    ln_islem_no                                number;
    ln_kull_bak                                  number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no :=to_number(substr(ls_ayrilan_message,1,18));
--
--
--
-------------------------------- LOG --------------------------------

    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --Hesap Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
-- KTDL ln_hesap_varmi := isThereActiveAccount(ls_account_no);

--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no =ls_account_no
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
     else
        ln_hesap_no := to_number(ls_account_no);
        ls_branch_3 := substr(ls_branch,2,3);
-- KTDL inquiry transaction        
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions
--                                     (  8834,
--                                         ln_hesap_no ,
--                                         ls_branch_3         ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number     ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                            ln_islem_no       ,
--                                            ls_cbs_error_desc);
        -- response balance values
        if ls_ret = '000'
        then
            ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
            
--  KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount);             
            
--            ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--            select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--            from cbs_hesap_Bakiye
--            where hesap_no = ln_hesap_no;

            ls_detail_response_code := '000';
            ls_resp_explanation := 'OK';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0));

            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

           RETURN ls_response_message;
          else
                    ls_detail_response_code := ls_ret;
                ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
                ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0));

    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
      end if;
   end if;

    RETURN ls_response_message;

    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_1103(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8830;
    ln_kull_bak                     number;
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
--  KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz not in ('USD','KGS')
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_settlement_dvz,ls_from_dvz,null,nvl(ln_settlement_amount,0),1,null,null,'N','S')

    -- KTDL ln_bloke_marj := getMarginAmount(ln_islem_kod);
    --ln_bloke_marj := pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
-- KTDL getTotalBalance(ln_from_account, ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                     p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;


-- KTDL financial transaction
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount); 

--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;


-- KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz)
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
                null;
-- KTDL ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S'));
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
-- KTDL ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1 , 'N', 'S'));
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------
FUNCTION ATM_1107(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8835;
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz not in ('USD','KGS') then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------

--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_settlement_dvz,ls_from_dvz,null,nvl(ln_settlement_amount,0),1,null,null,'N','S')

-- KTDL ln_bloke_marj := getMarginAmount(ln_islem_kod);
--    ln_bloke_marj := pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
-- KTDL     getTotalBalance(ln_from_account,ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

-- KTDL financial transaction
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
        
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

-- KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
               null;
--             ln_som_comm_amount := pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S'));                
--             ln_som_comm_amount := pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------
FUNCTION ATM_1110(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_BAKIYE                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_cnt                                    number;
    ls_CBS_ERROR_DESC                         varchar2(2000);
    ls_ret                                      varchar2(2000);
    ls_branch_3                               varchar(3);
    ln_islem_no                                number;
    ln_kull_bak                                  number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no :=to_number(substr(ls_ayrilan_message,1,18));
--
--
--
-------------------------------- LOG --------------------------------

    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --Hesap Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
-- KTDL ln_hesap_varmi := isThereActiveAccount(ls_account_no);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no =ls_account_no
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
     else
        ln_hesap_no := to_number(ls_account_no);
        ls_branch_3 := substr(ls_branch,2,3);

-- KTDL inquiry transaction        
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions
--                                     (  8814,
--                                         ln_hesap_no ,
--                                         ls_branch_3         ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number     ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                            ln_islem_no       ,
--                                            ls_cbs_error_desc);
        -- response balance values
        if ls_ret = '000'
        then            
            ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount); 

--            ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--            select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--            from cbs_hesap_Bakiye
--            where hesap_no = ln_hesap_no;



            ls_detail_response_code := '000';
            ls_resp_explanation := 'OK';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0));

            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

           RETURN ls_response_message;
          else
                    ls_detail_response_code := ls_ret;
                ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
                ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0));

    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
      end if;
   end if;

    RETURN ls_response_message;

    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_1203(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8820;
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz <> 'USD'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_settlement_dvz,ls_from_dvz,null,nvl(ln_settlement_amount,0),1,null,null,'N','S')

-- KTDL ln_bloke_marj := getMarginAmount(ln_islem_kod);
--    ln_bloke_marj := pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
--  KTDL getTotalBalance(ln_from_account,ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);

        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
    
-- KTDL financial transaction    
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

-- KTDL getCommission(ln_islem_no, ln_masraf_toplam, ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
                null;
--                ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S') );
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
--                ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_1207(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8821;
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz <> 'USD' then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------

--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_settlement_dvz,ls_from_dvz,null,nvl(ln_settlement_amount,0),1,null,null,'N','S')


-- KTDL ln_bloke_marj := getMarginAmount(ln_islem_kod);
--    ln_bloke_marj := pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
-- KTDL getTotalBalance(ln_from_account,ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

-- KTDL financial transaction
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount);         
        
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

-- KTDL getMarginAmount(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
                null;
-- KTDL     ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S') );
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
-- KTDL      ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------
FUNCTION ATM_1211(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8824;
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz <> 'USD'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_settlement_dvz,ls_from_dvz,null,nvl(ln_settlement_amount,0),1,null,null,'N','S')


-- KTDL ln_bloke_marj := getMarginAmount(ln_islem_kod);
--    ln_bloke_marj := pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
    
-- KTDL     getTotalBalance(ln_from_account,ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);

        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

-- KTDL financial transaction
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--   KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
        
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;


-- KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
                null;
-- KTDL     ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S') );           
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
-- KTDL      ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;        
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_1210(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                          varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                          varchar2(200);
    ln_hesap_no                                 number;

    ln_overdraft_limit                         number := 0;
    ln_pending_total                         number := 0;
    ln_BAKIYE                                 number := 0;
    ln_blocked_amount                         number := 0;
    ln_cnt                                    number;
    ls_CBS_ERROR_DESC                         varchar2(2000);
    ls_ret                                      varchar2(2000);
    ls_branch_3                               varchar(3);
    ln_islem_no                                number;
    ln_kull_bak                                  number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    ls_account_no :=to_number(substr(ls_ayrilan_message,1,18));
--
--
--
-------------------------------- LOG --------------------------------

    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096'; --Hesap Yok
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => null,
                                    p_CURRENCY => null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ls_account_no);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no =ls_account_no
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ls_account_no;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
     else
        ln_hesap_no := to_number(ls_account_no);
        ls_branch_3 := substr(ls_branch,2,3);

-- KTDL inquiry transaction        
--        ls_ret := pkg_Atm_transaction.Inquiry_Statement_Transactions
--                                     (  8815,
--                                         ln_hesap_no ,
--                                         ls_branch_3         ,
--                                         ls_terminal_id    ,
--                                         ls_reference_number     ,
--                                        ls_transaction_name ,
--                                        ls_transaction_code,
--                                        ls_Orig_authorization_reversal,
--                                        ls_source_code,
--                                        ls_terminal_type,
--                                        ls_transaction_date ,
--                                        ls_transaction_time,
--                                            ln_islem_no       ,
--                                            ls_cbs_error_desc);
        -- response balance values
        if ls_ret = '000'
        then
            ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_hesap_no);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_hesap_no, ln_bakiye, ln_blocked_amount); 

--            ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--            select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--            from cbs_hesap_Bakiye
--            where hesap_no = ln_hesap_no;

            ls_detail_response_code := '000';
            ls_resp_explanation := 'OK';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0));

            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ls_account_no,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => NULL,
                                p_CURRENCY => NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

           RETURN ls_response_message;
          else
                    ls_detail_response_code := ls_ret;
                ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
                ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_OVERDRAFT_limit,0));

    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
          RETURN ls_response_message;
      end if;
   end if;

    RETURN ls_response_message;

    EXCEPTION
    WHEN others THEN
        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        ls_ret :=pkg_atm_api.GetErrorCode(ls_CBS_ERROR_DESC);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ls_account_no,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
---------------------------------------------------------------------------------
FUNCTION ATM_1213(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8825;
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz <> 'USD'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_settlement_dvz,ls_from_dvz,null,nvl(ln_settlement_amount,0),1,null,null,'N','S')

-- KTDL  ln_bloke_marj := getMarginAmount(ln_islem_kod);
--    ln_bloke_marj := pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
--  KTDL getTotalBalance(ln_from_account,ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;


-- KTDL financial transaction
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
        
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

-- KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
                null;
-- KTDL     ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S') );                
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
-- KTDL      ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;           
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
-------------------------------- LOG --------------------------------
 FUNCTION ATM_1215(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8826;
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);

    --CQ845 if this on us virtual pos, then run 1007 transaction BEGIN 13022014 almasn
    if (ls_source_code = '10' and substr(ls_ayrilan_message,87,1) = 'D' and substr(ls_ayrilan_message,89,2) = 'OU') then
        return POS_1007(ps_message);
    end if;
    --CQ845 if this on us virtual pos, then run 1007 transaction END 13022014 almasn
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
--  KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz <> 'USD'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_settlement_dvz,ls_from_dvz,null,nvl(ln_settlement_amount,0),1,null,null,'N','S')

-- KTDL 
--    ln_bloke_marj := pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
-- KTDL     getTotalBalance(ln_from_account,ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 
 
--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);

        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;


-- KTDL financial transaction
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount);         
        
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;

-- KTDL getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
             null;
-- KTDL     ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S') );         
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
              null;
-- KTDL      ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;         
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
 END;
---------------------------------------------------------------------------------
FUNCTION ATM_1217(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8837;
    ln_kull_bak                     number;
BEGIN

    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--

    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    --ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
    --ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);

    ls_explain                  := substr(ls_ayrilan_message,262,30);
    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ln_from_account       := null;
    else
        ln_from_account       := to_number(substr(ls_ayrilan_message,226,18));
    end if;
-- KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);

    if trim(substr(ls_ayrilan_message,244,18)) is null then
        ln_to_account         := null;
    else
        ln_to_account         := to_number(substr(ls_ayrilan_message,244,18));
    end if;
-- KTDL 
--    ls_to_dvz                    := pkg_hesap.HesaptanDovizKoduAl(ln_to_account);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);
--log_at('1217',5);
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--

------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_to_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz <> 'USD'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
    ln_bloke_marj :=  0; --pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod);
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);
    -- para yatirma isleminde bakiye kontrolune gerek yok
    /*if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
        from cbs_hesap_Bakiye
        where hesap_no = ln_from_account;
        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := CBS.PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
        */

-- KTDL
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

--  KTDL ln_kull_bak := getAvailBalance(ln_to_account);
--          ln_pending_total := getPendingTotal(ln_to_account);
--         getBalancesForAccount(ln_to_account, ln_bakiye, ln_blocked_amount); 

--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_to_account);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_to_account;


--  KTDL  getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
               null;
-- KTDL     ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S') );          
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
-- KTDL      ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;         
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

        RETURN ls_response_message;
 END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_1219(ps_message varchar2) RETURN VARCHAR2
is
    ln_bloke_marj          number;
    ln_marjli_tutar          number;
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account                number;
    ls_from_dvz                  varchar2(3);
    ln_to_account                  number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8838;
    ln_kull_bak                     number;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
--
--
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
   -- ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
    --ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);
    if trim(substr(ls_ayrilan_message,226,18) ) is null then
        ln_from_account       := null;
    else
        ln_from_account       := to_number(substr(ls_ayrilan_message,226,18));
    end if;
-- KTDL
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);

    if trim(substr(ls_ayrilan_message,244,18)) is null then
        ln_to_account         := null;
    else
        ln_to_account         := to_number(substr(ls_ayrilan_message,244,18));
    end if;
-- KTDL
--    ls_to_dvz                    := pkg_hesap.HesaptanDovizKoduAl(ln_to_account);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account_number);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
--
--
------- Dvz Control -------
    if ls_settlement_dvz <> 'USD'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;

------- To Account Control -------
--
---------------------------------- Simdi basliyor ----------------------------------
    ln_bloke_marj :=  0; --pkg_atm_transaction.bloke_marj_tutar_al(ln_islem_kod); --bloke konmayacagindan marj sifir.
    ln_marjli_tutar := nvl(ln_settlement_amount,0) + nvl(ln_settlement_amount,0) *nvl(ln_bloke_marj,0);

--  KTDL getTotalBalance(ln_from_account,ls_settlement_dvz, ls_card_number) < ln_marjli_tutar
--    if nvl(pkg_atm.Musteri_Toplam_Bakiye(ln_from_account,ls_settlement_dvz, ls_card_number),0) < ln_marjli_tutar
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
    
-- KTDL financial transaction    
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);

    if ls_ret = '000'
    then
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
                
--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;


--  KTDL  getCommission(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
--        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
               null;
-- KTDL     ln_som_comm_amount :=pkg_kur.yuvarla('KGS', convertCurrency(ls_masraf_Doviz, 'KGS', nvl(ln_masraf_toplam,0), 1, 'N', 'S') );          
--             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
                null;
-- KTDL      ln_usd_comm_amount := pkg_kur.yuvarla('USD', convertCurrency(ls_masraf_Doviz, 'USD', nvl(ln_masraf_toplam,0), 1, 'N', 'S')) ;         
--              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;

        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
--
        RETURN ls_response_message;
 END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_1309(ps_message varchar2) RETURN VARCHAR2
IS
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 1200;
    ln_kull_bak                     number;
    i                             number :=0;
    ls_bad_list                     varchar2(1);
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
                                   
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);

--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
------- Badlist Control -------

-- KTDL ls_bad_list := isAccountInBadList(ln_from_account);

--    select nvl(BADLIST_FLAG,'H')
--    into  ls_bad_list
--    from cbs_hesap
--    where hesap_no = ln_from_account;

    if ls_bad_list  = 'E'
    then
           ls_detail_response_code := '907'; --Hesap Yok
        ls_resp_explanation := 'ACCOUNT IS IN BADLIST  : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- Badlist Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------

---------------------------------- Simdi basliyor ----------------------------------

-- KTDL getAvailBalance(ln_from_account) < convertCurrency(ls_bill_dvz, ls_from_dvz, nvl(ln_bill_amount,0), 1, 'N', 'S')
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_bill_dvz,ls_from_dvz,null,nvl(ln_bill_amount,0),1,null,null,'N','S')
    if false
    then
           ls_detail_response_code := '051';
        ls_resp_explanation := 'INSUFFICIENT BALANCE';

--  KTDL ln_kull_bak := getAvailBalance(ln_from_account);
--          ln_pending_total := getPendingTotal(ln_hesap_no);
--         getBalancesForAccount(ln_from_account, ln_bakiye, ln_blocked_amount); 

--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
    
-- KTDL financial transaction
--    ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);
    
    if ls_ret = '000'
    then
-- KTDL blockAmount(ln_islem_kod, 
--                                ln_islem_no, 
--                                ln_from_account, 
--                                trim(ls_terminal_id),
--                                trim(ls_reference_number),
--                                ln_original_amount ,
--                                ls_original_dvz);

--        pkg_atm_transaction.bloke_yarat (ln_islem_kod,
--                                               ln_islem_no,
--                                               ln_from_account,
--                                               trim(ls_terminal_id),
--                                               trim(ls_reference_number),
--                                               ln_original_amount ,
--                                               ls_original_dvz);

    /*
        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

        select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
        from cbs_hesap_Bakiye
        where hesap_no = ln_from_account;

        pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
        ln_som_comm_amount := 0;
        ln_usd_comm_amount := 0;
        if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
           if ls_from_dvz = pkg_genel.lc_al then
             ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
            else
              ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
            end if;
        end if;
*/
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
    
    --
    -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
    -------------------------------- LOG --------------------------------
    --
        RETURN ls_response_message;
    else
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
EXCEPTION
    WHEN others THEN
        ls_cbs_error_desc := ls_cbs_error_desc||'|'||pkg_hata.generatemessage(pkg_hata.getucpointer || '2595' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        ls_ret :=pkg_atm_api.geterrorcode(ls_cbs_error_desc);
        ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
--
        RETURN ls_response_message;
END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_1310(ps_message varchar2) RETURN VARCHAR2
IS
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 1201;
    ln_kull_bak                     number;
    i                             number :=0;
    ls_bad_list                     varchar2(1);
    
-- KTDL
--    CURSOR c_isl(ps_ref VARCHAR2) IS
--    SELECT * FROM cbs_atm_finansal_islem
--        WHERE islem_kod = 1200 AND tran_code = 1309 AND referance = ps_ref;
        
--    r_isl c_isl%rowtype;

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
                                   
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL    
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
------- Badlist Control -------

-- KTDL ls_bad_list := isAccountInBadList(ln_from_account); 
--    select nvl(BADLIST_FLAG,'H')
--    into  ls_bad_list
--    from cbs_hesap
--    where hesap_no = ln_from_account;

    if ls_bad_list  = 'E'
    then
           ls_detail_response_code := '907'; --Hesap Yok
        ls_resp_explanation := 'ACCOUNT IS IN BADLIST  : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- Badlist Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------

---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_bill_dvz,ls_from_dvz,null,nvl(ln_bill_amount,0),1,null,null,'N','S')
--    then
--           ls_detail_response_code := '051';
--        ls_resp_explanation := 'INSUFFICIENT BALANCE';
--
--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
--        ln_som_comm_amount := 0;
--        ln_usd_comm_amount := 0;
--        ls_response_message := CBS.PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
--                                                                        '1' ,
--                                                                   ls_detail_response_code,
--                                                                   ls_resp_explanation)||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
--        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
--        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
--                                    p_MESSAGE_TYPE=>'ERROR',
--                                    p_REFERANCE => ls_reference_number,
--                                    p_MESSAGE => ls_response_message,
--                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
--                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
--                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
--                                    p_IN_USER_ID_CODE => ls_user,
--                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
--                                    p_IN_SOURCE_CODE => ls_source_code,
--                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
--                                    p_IN_BRANCH => ls_branch,
--                                    p_IN_TERMINAL_ID => ls_terminal_id,
--                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
--                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
--                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
--                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
--                                    p_ACCOUNT_NO => ln_from_account,
--                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
--                                    p_ERROR_CD => ls_detail_response_code,
--                                    p_ERROR_DESC => ls_resp_explanation,
--                                    p_AMOUNT => ln_bill_amount,
--                                    p_CURRENCY => ls_bill_dvz,
--                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
--        RETURN ls_response_message;
--    end if;
 

-- KTDL    ln_islem_no :=
--    ln_islem_no := pkg_atm_api.GetIslemNoFromReferance(ls_reference_number);
    
    if ln_islem_no is not null then
-- KTDL unblockAmount(ln_islem_no);
--        pkg_atm_transaction.bloke_kapat (ln_islem_no);
        
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK');
        --
        -------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                    p_MESSAGE_TYPE=>'OUTGOING',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => NULL,
                                    p_ERROR_DESC => NULL,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        -------------------------------- LOG --------------------------------
        --
        RETURN ls_response_message;
    ELSE
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(903);
            ls_detail_response_code := '096';
            ls_resp_explanation :=ls_CBS_ERROR_DESC ||' REFERANCE : '||ls_reference_number;
            ls_response_message  :=PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
            RETURN ls_response_message;
    END IF;
EXCEPTION
    WHEN others THEN
        ls_cbs_error_desc := ls_cbs_error_desc||'|'||pkg_hata.generatemessage(pkg_hata.getucpointer || '2595' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        ls_ret :=pkg_atm_api.geterrorcode(ls_cbs_error_desc);
        ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
        RETURN ls_response_message;
END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_1311(ps_message varchar2) RETURN VARCHAR2
IS
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8842;
    ln_kull_bak                     number;
    i                             number :=0;
    ls_bad_list                     varchar2(1);
    ls_1309_ref          varchar2(50);
    ln_1309_islem_no     number;
    
-- KTDL 
--    cursor c_1309(pn_islem_no number) is
--    select * from cbs_atm_finansal_islem a
--    where tx_no = pn_islem_no ;
--
--    r_1309    c_1309%rowtype;

BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
                                   
    ls_acquirer_bank             := substr(ls_ayrilan_message,1,12);
    ls_merchant_number           := substr(ls_ayrilan_message,13,15);
    ls_merchant_location         := substr(ls_ayrilan_message,28,40);
    ls_card_number               := substr(ls_ayrilan_message,68,19);
    ls_card_type                 := substr(ls_ayrilan_message,87,1);
    ls_card_brand                := substr(ls_ayrilan_message,88,1);
    ls_card_domain               := substr(ls_ayrilan_message,89,2);
    ls_original_cy_code          := substr(ls_ayrilan_message,91,3);

    ln_original_amount           := to_number(substr(ls_ayrilan_message,94,19));
    ls_settlement_cy_code        := substr(ls_ayrilan_message,113,3);
    ln_settlement_amount         :=to_number(substr(ls_ayrilan_message,116,19));
    ls_bill_cy_code              := substr(ls_ayrilan_message,135,3);
    ln_bill_amount               := to_number(substr(ls_ayrilan_message,138,19));
    ln_commission_rate           := to_number(substr(ls_ayrilan_message,157,4));
    ln_minimum_commission_amount := to_number(substr(ls_ayrilan_message,161,19));
    ln_maximum_commission_amount := to_number(substr(ls_ayrilan_message,180,19));
    ln_fixed_commission_amount   := to_number(substr(ls_ayrilan_message,199,19));
    ld_business_date             := to_date(substr(ls_ayrilan_message,218,8),'yyyymmdd');
    ls_branch_3                  :=substr(ls_branch,2,3);
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
-- KTDL 
--    ls_from_dvz                  := pkg_hesap.HesaptanDovizKoduAl(ln_from_account);
    ls_explain                  := substr(ls_ayrilan_message,262,30);
    ls_1309_ref := trim(substr(ls_ayrilan_message,244));

    pkg_atm.CURRENCY_CONVERT(ls_original_cy_code,ls_original_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_settlement_cy_code,ls_settlement_dvz);
    pkg_atm.CURRENCY_CONVERT(ls_bill_cy_code,ls_bill_dvz);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
------- From Account Control -------

-- KTDL ln_hesap_varmi := isThereActiveAccount(ln_from_account);
--    select count(*)
--    into  ln_hesap_varmi
--    from cbs_hesap
--    where hesap_no = ln_from_account
--      and durum_kodu = 'A' ;

    if nvl(ln_hesap_varmi,0) = 0 then
           ls_detail_response_code := '205'; --Hesap Yok
        ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- From Account Control -------
------- Badlist Control -------

-- KTDL ls_bad_list := isAccountInBadList(ln_from_account);
--    select nvl(BADLIST_FLAG,'H')
--    into  ls_bad_list
--    from cbs_hesap
--    where hesap_no = ln_from_account;

    if ls_bad_list  = 'E'
    then
           ls_detail_response_code := '907'; --Hesap Yok
        ls_resp_explanation := 'ACCOUNT IS IN BADLIST  : ' || ln_from_account;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                    );
        RETURN ls_response_message;
    end if;
------- Badlist Control -------
--
--
------- Dvz Control -------
    if ls_bill_dvz not in ('USD','KGS','EUR') or
       ls_bill_dvz <> ls_from_dvz
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'INVALID CURRENCY CODE';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- Dvz Control -------

---------------------------------- Simdi basliyor ----------------------------------
--    if pkg_hesap.Kullanilabilir_Bakiye_Al(ln_from_account) < pkg_kur.doviz_doviz_karsilik(ls_bill_dvz,ls_from_dvz,null,nvl(ln_bill_amount,0),1,null,null,'N','S')
--    then
--           ls_detail_response_code := '051';
--        ls_resp_explanation := 'INSUFFICIENT BALANCE';
--
--        select bakiye,bloke_tutari,pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
--        into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
--        from cbs_hesap_Bakiye
--        where hesap_no = ln_from_account;
--        ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
--        ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli
--        ln_som_comm_amount := 0;
--        ln_usd_comm_amount := 0;
--        ls_response_message := CBS.PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
--                                                                        '1' ,
--                                                                   ls_detail_response_code,
--                                                                   ls_resp_explanation)||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
--                                                                   PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
--        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
--        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
--                                    p_MESSAGE_TYPE=>'ERROR',
--                                    p_REFERANCE => ls_reference_number,
--                                    p_MESSAGE => ls_response_message,
--                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
--                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
--                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
--                                    p_IN_USER_ID_CODE => ls_user,
--                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
--                                    p_IN_SOURCE_CODE => ls_source_code,
--                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
--                                    p_IN_BRANCH => ls_branch,
--                                    p_IN_TERMINAL_ID => ls_terminal_id,
--                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
--                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
--                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
--                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
--                                    p_ACCOUNT_NO => ln_from_account,
--                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
--                                    p_ERROR_CD => ls_detail_response_code,
--                                    p_ERROR_DESC => ls_resp_explanation,
--                                    p_AMOUNT => ln_bill_amount,
--                                    p_CURRENCY => ls_bill_dvz,
--                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
--        RETURN ls_response_message;
--    end if;  
    
-- KTDL
--    ln_1309_islem_no := pkg_atm_api.GetIslemNoFromReferance(ls_1309_ref);
    
    if ln_1309_islem_no is not null then
        
-- KTDL
--        OPEN c_1309(ln_1309_islem_no);
--        FETCH c_1309 INTO  r_1309;
--        CLOSE c_1309;
        
        --check currency
-- KTDL
--        if (ls_original_dvz != r_1309.original_currency_code) then
            if false then
            ls_detail_response_code := '096';
            ls_resp_explanation := 'INVALID CURRENCY CODE';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '1' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
            RETURN ls_response_message;
        end if;
        
        --check sum
-- KTDL 
--        if (ln_original_amount > r_1309.original_amount) then
           if false then
            ls_detail_response_code := '096';
            ls_resp_explanation := 'INVALID AMOUNT';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '1' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
            RETURN ls_response_message;
        end if;

--  KTDL unblockAmount(ln_1309_islem_no);    
--        pkg_atm_transaction.bloke_kapat (ln_1309_islem_no);
        
        --block delta
        /*
        if (ln_original_amount <= r_1309.original_amount) then
            pkg_atm_transaction.bloke_yarat (1200,
                                               ln_1309_islem_no,
                                               ln_from_account,
                                               trim(ls_terminal_id),
                                               trim(ls_1309_ref),
                                               r_1309.original_amount - ln_original_amount ,
                                               ls_original_dvz);
        end if;
        */


-- KTDL financial transaction        
--        ls_ret := pkg_Atm_transaction.Financial_transactions( ln_islem_kod,
--                                                                   ls_acquirer_bank,
--                                                              ls_merchant_number,
--                                                              ls_merchant_location,
--                                                              ls_card_number,
--                                                              ls_card_type,
--                                                              ls_card_brand,
--                                                              ls_card_domain,
--                                                              ls_original_dvz,
--                                                              ln_original_amount,
--                                                              ls_settlement_dvz,
--                                                              ln_settlement_amount,
--                                                              ls_bill_dvz,
--                                                              ln_bill_amount,
--                                                              ln_commission_rate,
--                                                              ln_minimum_commission_amount,
--                                                              ln_maximum_commission_amount,
--                                                              ln_fixed_commission_amount,
--                                                              ld_business_date,
--                                                              ln_from_account,
--                                                              ls_from_dvz,
--                                                              ln_to_account,
--                                                              ls_to_dvz,
--                                                              ls_explain,
--                                                              ls_branch_3,
--                                                              ls_terminal_id,
--                                                              ls_reference_number,
--                                                              ls_transaction_name ,
--                                                              ls_transaction_code,
--                                                              ls_Orig_authorization_reversal,
--                                                              ls_source_code,
--                                                              ls_terminal_type,
--                                                              ls_transaction_date ,
--                                                              ls_transaction_time,
--                                                              ln_islem_no,
--                                                              ls_cbs_error_Desc);
    
        if ls_ret = '000'
        then
        /*
            ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_hesap_no);
            ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

            select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
            into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
            from cbs_hesap_Bakiye
            where hesap_no = ln_from_account;

            pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
            ln_som_comm_amount := 0;
            ln_usd_comm_amount := 0;
            if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
               if ls_from_dvz = pkg_genel.lc_al then
                 ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
                else
                  ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
                end if;
            end if;
            */

            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '0' ,
                                                                       '000',
                                                                       'OK')||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                                       PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
        --
        -------------------------------- LOG --------------------------------
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                        p_MESSAGE_TYPE=>'OUTGOING',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => NULL,
                                        p_ERROR_DESC => NULL,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        -------------------------------- LOG --------------------------------
        --
            RETURN ls_response_message;
        else
               ls_detail_response_code := ls_ret;
            ls_resp_explanation := pkg_atm_api.GetErrorDesc(ls_ret);
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '1' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
            RETURN ls_response_message;
        end if;

    ELSE
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(903);
            ls_detail_response_code := '096';
            ls_resp_explanation :=ls_CBS_ERROR_DESC ||' REFERANCE : '||ls_1309_ref;
            ls_response_message  :=PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
            RETURN ls_response_message;
    END IF;
EXCEPTION
    WHEN others THEN
        ls_cbs_error_desc := ls_cbs_error_desc||'|'||pkg_hata.generatemessage(pkg_hata.getucpointer || '2595' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        ls_ret :=pkg_atm_api.geterrorcode(ls_cbs_error_desc);
        ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
--
        RETURN ls_response_message;
END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_1312(ps_message varchar2) RETURN VARCHAR2 
IS
    ln_log_no                                    NUMBER;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ls_resp_explanation                 varchar2(200);
    ls_ret         varchar2(2000);
    ls_ret2         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ln_fis_no            number;

    ls_count                                     NUMBER := 0;
    ln_hesap_varmi                              number;
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 1200;
    ln_kull_bak                     number;
    i                             number :=0;
    ls_bad_list                     varchar2(1);
    
-- KTDL
--    cursor c_1311(pn_islem_no number) is
--    select * from cbs_atm_finansal_islem a
--    where tx_no = pn_islem_no ;
--
--    r_1311    c_1311%rowtype;
BEGIN
    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
                                   
    ln_from_account              := to_number(substr(ls_ayrilan_message,226,18));
    
------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO =>  ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT =>  NULL,
                                p_CURRENCY =>  NULL,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
--
--------------------------------------------------------------------------------
-- iptal edilecek islemin numarasi ve fis numarasi sorgulanir.
--------------------------------------------------------------------------------
------- Referecneand Transaction and Journal Control -------
  if nvl(ls_reference_number,'X') ='X' then
   -- reference bos olamaz
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(902);
           ls_detail_response_code := '096';
        ls_resp_explanation :=  ls_CBS_ERROR_DESC||' REFERANCE : '|| ls_reference_number;
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
  end if;

-- KTDL 
--   ln_islem_no := pkg_atm_api.GetIslemNoFromReferance(ls_reference_number);

   if nvl(ln_islem_no,0) = 0 then
   -- islem no bulanamadi
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(903);
           ls_detail_response_code := '096';
        ls_resp_explanation :=ls_CBS_ERROR_DESC ||' REFERANCE : '||ls_reference_number;
        ls_response_message  :=PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
  end if;

-- KTDL  
--  OPEN c_1311(ln_islem_no);
--  FETCH c_1311 INTO r_1311;
--  CLOSE c_1311;
  
-- KTDL 
--  if trunc(r_1311.transaction_date) != Pkg_Muhasebe.banka_tarihi_bul then
  if false then
   -- islem no bulanamadi
        ls_CBS_ERROR_DESC  := PKG_ATM_API.GetErrorDesc(903);
           ls_detail_response_code := '096';
        ls_resp_explanation := 'CANNOT CANCEL';
        ls_response_message  := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => NULL,
                                    p_CURRENCY => NULL,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
  end if;

---------------------------------- Simdi basliyor ----------------------------------
-- KTDL 
--    pkg_Atm_Api.cancel_transaction(ln_islem_no, ls_ret,ls_CBS_ERROR_DESC);

    /*
    ln_pending_total :=pkg_hesap.eod_bekleyen_bakiye(ln_from_account);
    ln_overdraft_limit := 0; --sevalb henuz kg de limit tanimli degil yapildiginda burasi degisitirilmeli

    select bakiye,bloke_tutari, pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)
    into  ln_bakiye ,ln_blocked_amount, ln_kull_bak
    from cbs_hesap_Bakiye
    where hesap_no = ln_from_account;

    pkg_atm_masraf.toplam_masraf(ln_islem_no, ln_masraf_toplam  ,ls_masraf_Doviz) ;
    ln_som_comm_amount := 0;
    ln_usd_comm_amount := 0;
    if ls_masraf_Doviz is not null and  ls_from_dvz is not null then
       if ls_from_dvz = pkg_genel.lc_al then
         ln_som_comm_amount :=pkg_kur.yuvarla('KGS',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'KGS',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S') );
        else
          ln_usd_comm_amount := pkg_kur.yuvarla('USD',pkg_kur.doviz_doviz_karsilik(ls_masraf_Doviz  ,'USD',null,nvl(ln_masraf_toplam,0),1,null,null,'N','S')) ;
        end if;
    end if;
    */

    ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                    '0' ,
                                                               '000',
                                                               'OK')||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_BAKIYE,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_PENDING_TOTAL,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_BLOCKED_AMOUNT,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_kull_bak,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_SOM_COMM_AMOUNT,0))||
                                                               PKG_ATM.bakiye_formatla(nvl(ln_USD_COMM_AMOUNT,0));
--
-------------------------------- LOG --------------------------------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'OUTGOING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ls_response_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
-------------------------------- LOG --------------------------------
--
    RETURN ls_response_message;
---------------------------------------------------------------------------
    EXCEPTION
    WHEN others THEN
           ls_detail_response_code := '096';
        ls_resp_explanation := 'EXCEPTION ERROR';
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');

        ls_CBS_ERROR_DESC := ls_CBS_ERROR_DESC||'|'||Pkg_Hata.GenerateMessage(Pkg_Hata.getUCPOINTER || '2595' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO =>  ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT =>  null,
                                    p_CURRENCY =>  null,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
--
        RETURN ls_response_message;
 END;
-------------------------------- LOG --------------------------------
FUNCTION ATM_0023(ps_message varchar2) RETURN VARCHAR2
is
    ln_log_no                                    NUMBER;
    ls_count                                     NUMBER := 0;
    ls_response_message                           varchar2(2000);
    ls_ayrilan_message                        varchar2(2000);
    ls_account_no                              varchar2(2000);
    lS_DETAIL_RESPONSE_CODE                     varchar2(3) := '000';
    ls_transaction_name                       varchar2(2000);
    ls_transaction_code                       varchar2(2000);
    ls_Orig_authorization_reversal               varchar2(2000);
    ls_user                                       varchar2(2000);
    ls_transaction_type                        varchar2(2000);
    ls_source_code                             varchar2(2000);
    ls_terminal_type                              varchar2(2000);
    ls_branch                                 varchar2(2000);
    ls_terminal_id                              varchar2(2000);
    ls_transaction_date                         varchar2(2000);
    ls_transaction_time                        varchar2(2000);
    ls_reference_number                      varchar2(2000);
    ln_hesap_varmi                              number;
    ln_cr_hesap_varmi                           number;
    ls_resp_explanation                 varchar2(200);
    ln_hesap_no                                 number;

    ln_BAKIYE                         number := 0;
    ln_PENDING_TOTAL                         number := 0;
    ln_BLOCKED_AMOUNT                                 number := 0;
    ln_OVERDRAFT_limit                         number := 0;
    ln_SOM_COMM_AMOUNT                         number := 0;
    ln_USD_COMM_AMOUNT                         number := 0;
    ln_masraf_toplam               number := 0;
    ls_masraf_Doviz                 Varchar2(3);

    ln_cnt   number;
    ln_comm_rate   number;
    ln_kur   number;
    ln_amnt   number;
    ls_ret         varchar2(2000);
    ln_islem_no     number;
    ls_cbs_error_desc    varchar2(2000);
    ls_acquirer_bank             varchar2(12);
    ls_merchant_number           varchar2(15);
    ls_merchant_location         varchar2(40);
    ls_card_number               varchar2(19);
    ls_card_type                 varchar2(1);
    ls_card_brand                varchar2(1);
    ls_card_domain               varchar2(2);
    ls_original_cy_code          varchar2(3);
    ln_original_amount           number;
    ls_settlement_cy_code        varchar2(3);
    ln_settlement_amount         number;
    ls_bill_cy_code              varchar2(3);
    ln_bill_amount               number;
    ln_commission_rate           number;
    ln_minimum_commission_amount number;
    ln_maximum_commission_amount number;
    ln_fixed_commission_amount   number;
    ld_business_date             date;
    ln_from_account       number;
    ls_from_dvz                  varchar2(3);
    ln_to_account         number;
    ls_to_dvz                    varchar2(3);
    ls_explain                   varchar2(30);
    ls_original_dvz              varchar2(3);
    ls_settlement_dvz            varchar2(3);
    ls_bill_dvz                  varchar2(3);
    ls_branch_3                  varchar2(3);
    ln_islem_kod                 number := 8800;
    ln_kull_bak                     number;
    i                             number :=0;
    ls_bad_list                     varchar2(1);
    
    ln_cust_no           number;
    ln_acc_count         number;
    
    ls_accounts          varchar2(2000);
    ls_acc               varchar2(18);
    ls_crd_acc_type      varchar2(9);
    ls_crd_type          varchar2(1);
    ls_curr              varchar2(4);
    ls_acc_sign          varchar2(1);
    ls_acc_bal           varchar2(18);
    ls_acc_dvz           varchar2(3);
    
    ret_str              varchar2(2000) :='';
BEGIN

    pkg_atm.Parse_Incoming_Message(ps_message ,
                                    ls_ayrilan_message  ,
                                   ls_transaction_name ,
                                   ls_transaction_code ,
                                   ls_Orig_authorization_reversal,
                                   ls_user                 ,
                                   ls_transaction_type  ,
                                   ls_source_code        ,
                                   ls_terminal_type        ,
                                   ls_branch            ,
                                   ls_terminal_id        ,
                                   ls_transaction_date  ,
                                   ls_transaction_time  ,
                                   ls_reference_number);
                                   
    ls_branch_3         := substr(ls_branch,2,3);
    ln_cust_no          := substr(ls_ayrilan_message,1,13);
    ln_acc_count        := to_number(substr(ls_ayrilan_message,14,2));
    ls_accounts         := substr(ls_ayrilan_message,16);

------- INCOMING MSG LOG -------
    ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
    pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no    ,
                                p_MESSAGE_TYPE=>'INCOMING',
                                p_REFERANCE => ls_reference_number,
                                p_MESSAGE => ps_message,
                                p_IN_TRANSACTION_NAME => ls_transaction_name,
                                p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                p_IN_USER_ID_CODE => ls_user,
                                p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                p_IN_SOURCE_CODE => ls_source_code,
                                p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                p_IN_BRANCH => ls_branch,
                                p_IN_TERMINAL_ID => ls_terminal_id,
                                p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                p_OUT_RESPONSE_CODE => NULL,
                                p_OUT_RESPONSE_EXPLANATION => NULL,
                                p_ACCOUNT_NO => ln_from_account,
                                p_CBS_TRANSACTION_NO =>ln_islem_no,
                                p_ERROR_CD => NULL,
                                p_ERROR_DESC => NULL,
                                p_AMOUNT => ln_bill_amount,
                                p_CURRENCY => ls_bill_dvz,
                                P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
------- INCOMING MSG LOG -------    
--
--
------- ATM Terminal control -------
    if pkg_atm.Terminal_Active(substr(ls_terminal_id,1,5))= 'NOK'
    then
           ls_detail_response_code := '096';
        ls_resp_explanation := 'UNDEFINED ATM TERMINAL : '||substr(ls_terminal_id,1,5);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
        RETURN ls_response_message;
    end if;
------- ATM Terminal control -------
    FOR i in 1..11
     LOOP
        ls_acc := ltrim(substr(ls_accounts,1,18),'0');
        ls_accounts := substr(ls_accounts,19);
        
        ------- From Account Control -------
-- KTDL ln_hesap_varmi := isThereActiveAccount(ls_acc);        
--        select count(*)
--        into  ln_hesap_varmi
--        from cbs_hesap
--        where hesap_no = to_number(ls_acc)
--          and durum_kodu = 'A' ;
          
-- KTDL ln_cr_hesap_varmi := isThereCreditAccount(ls_acc);
--        select count(*)
--        into  ln_cr_hesap_varmi
--        from cbs_hesap_kredi
--        where hesap_no = to_number(ls_acc);
        
        if nvl(ln_hesap_varmi,0) = 0 and nvl(ln_cr_hesap_varmi,0) = 0  then
               ls_detail_response_code := '205'; --Hesap Yok
            ls_resp_explanation := 'INVALID ACCOUNT NUMBER : ' || ln_from_account;
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '1' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                        );
            RETURN ls_response_message;
        end if;
    ------- From Account Control -------
        ------- Badlist Control -------
-- KTDL ls_bad_list := isAccountInBadList(ls_acc);        
--        select nvl(BADLIST_FLAG,'H')
--        into  ls_bad_list
--        from cbs_hesap
--        where hesap_no = to_number(ls_acc);

        if ls_bad_list  = 'E'
        then
               ls_detail_response_code := '907'; --Hesap Yok
            ls_resp_explanation := 'ACCOUNT IS IN BADLIST  : ' || ln_from_account;
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '1' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC
                                        );
            RETURN ls_response_message;
        end if;
    ------- Badlist Control -------
-- KTDL get currency code
--       select T.DOVIZ_KODU into ls_acc_dvz  from cbs_hesap t where t.hesap_no = to_number(ls_acc);
       ------- Dvz Control -------
        if ls_acc_dvz not in ('USD','KGS','EUR')
        then
               ls_detail_response_code := '096';
            ls_resp_explanation := 'INVALID CURRENCY CODE';
            ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                            '1' ,
                                                                       ls_detail_response_code,
                                                                       ls_resp_explanation)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0)||
                                                                       PKG_ATM.bakiye_formatla(0);
            ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
            pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                        p_MESSAGE_TYPE=>'ERROR',
                                        p_REFERANCE => ls_reference_number,
                                        p_MESSAGE => ls_response_message,
                                        p_IN_TRANSACTION_NAME => ls_transaction_name,
                                        p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                        p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                        p_IN_USER_ID_CODE => ls_user,
                                        p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                        p_IN_SOURCE_CODE => ls_source_code,
                                        p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                        p_IN_BRANCH => ls_branch,
                                        p_IN_TERMINAL_ID => ls_terminal_id,
                                        p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                        p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                        p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                        p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                        p_ACCOUNT_NO => ln_from_account,
                                        p_CBS_TRANSACTION_NO =>ln_islem_no,
                                        p_ERROR_CD => ls_detail_response_code,
                                        p_ERROR_DESC => ls_resp_explanation,
                                        p_AMOUNT => ln_bill_amount,
                                        p_CURRENCY => ls_bill_dvz,
                                        P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);
            RETURN ls_response_message;
        end if;
    ------- To Account Control -------
-- KTDL get ISO code for currency
--       select DK.ISO_CODE into ls_curr  from cbs_hesap t, cbs_doviz_kodlari dk where T.DOVIZ_KODU = DK.DOVIZ_KODU
--       and t.hesap_no = to_number(ls_acc);

--       begin       
-- KTDL          CBS_ATM_POS_TRAN_LOG_INC(ls_acc, ls_acc_type);  
--       select decode(T.CARD_ACCOUNT_TYPE,'PRIMARY','PRIMR '||ls_acc_dvz,'SECONDARY','SCNDR '||ls_acc_dvz,'NNNNNNNNN') into ls_crd_acc_type
--        from cbs_debit_card_account t where T.ACCOUNT_NO = to_number(ls_acc)
--        and rownum = 1;
--        
--       select decode(T.CARD_ACCOUNT_TYPE,'PRIMARY','A','SECONDARY','V','H') into ls_crd_type
--        from cbs_debit_card_account t where T.ACCOUNT_NO = to_number(ls_acc)
--        and rownum = 1;
--       exception
--        when no_data_found then
--            ls_crd_acc_type := 'PRIMR '||ls_acc_dvz;
--            ls_crd_type := 'A';
--       end; 
       
-- KTDL ls_acc_sign := getBalanceSign(ls_acc)       
--       select decode(sign(bakiye),1,'+',-1,'-','+') into ls_acc_sign from cbs_hesap_bakiye hb
--       where hb.hesap_no = to_number(ls_acc);

-- KTDL     ls_acc_bal :=  getAvailBalance(to_number(ls_acc))
--       ls_acc_bal := pkg_hesap.kullanilabilir_bakiye_al (to_number(ls_acc));
       
--       ret_str := ret_str||lpad(ls_acc,18,'0')||ls_crd_acc_type||ls_crd_type||ls_curr||ls_acc_sign||lpad(ls_acc_bal,18,'0');
        
       exit when i = ln_acc_count;
     END LOOP;
     
 ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '0' ,
                                                                   '000',
                                                                   'OK')||lpad(ln_acc_count,2,'0')||ret_str;
 RETURN ls_response_message;
 
   EXCEPTION
    WHEN others THEN
        ls_cbs_error_desc := ls_cbs_error_desc||'|'||pkg_hata.generatemessage(pkg_hata.getucpointer || '2595' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        ls_ret :=pkg_atm_api.geterrorcode(ls_cbs_error_desc);
           ls_detail_response_code := ls_ret;
        ls_resp_explanation := pkg_atm_api.GetErrorDESC(ls_ret);
        ls_response_message := PKG_ATM.STANDARDRESPONSEHEADER ( ls_reference_number,
                                                                        '1' ,
                                                                   ls_detail_response_code,
                                                                   ls_resp_explanation)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0)||
                                                                   PKG_ATM.bakiye_formatla(0);
--
-------------------------------- LOG --------------------------------
        ln_log_no := PKG_GENEL.genel_kod_al('ATMLOGNO');
        pkg_atm_log.LogTransaction (pn_log_no =>ln_log_no,
                                    p_MESSAGE_TYPE=>'ERROR',
                                    p_REFERANCE => ls_reference_number,
                                    p_MESSAGE => ls_response_message,
                                    p_IN_TRANSACTION_NAME => ls_transaction_name,
                                    p_IN_TRANSACTION_CODE  => ls_transaction_code,
                                    p_IN_AUTHORIZATION_REVERSAL => ls_Orig_authorization_reversal,
                                    p_IN_USER_ID_CODE => ls_user,
                                    p_IN_TRANSACTION_TYPE => ls_transaction_type,
                                    p_IN_SOURCE_CODE => ls_source_code,
                                    p_IN_TERMINAL_TYPE =>  ls_terminal_type    ,
                                    p_IN_BRANCH => ls_branch,
                                    p_IN_TERMINAL_ID => ls_terminal_id,
                                    p_IN_BS_TRANSACTION_DATE => ls_transaction_date    ,
                                    p_IN_BS_TRANSACTION_TIME => ls_transaction_time,
                                    p_OUT_RESPONSE_CODE => lS_DETAIL_RESPONSE_CODE,
                                    p_OUT_RESPONSE_EXPLANATION => ls_resp_explanation,
                                    p_ACCOUNT_NO => ln_from_account,
                                    p_CBS_TRANSACTION_NO =>ln_islem_no,
                                    p_ERROR_CD => ls_detail_response_code,
                                    p_ERROR_DESC => ls_resp_explanation,
                                    p_AMOUNT => ln_bill_amount,
                                    p_CURRENCY => ls_bill_dvz,
                                    P_CBS_ERROR_DESC => ls_CBS_ERROR_DESC);

--
        RETURN ls_response_message;
 END;
-------------------------------- LOG --------------------------------
  
END;
/

