create PACKAGE BODY           Pkg_Genel IS

 FUNCTION  genel_kod_al(ps_kod_adi IN VARCHAR2) RETURN NUMBER IS
  PRAGMA AUTONOMOUS_TRANSACTION;

  ln_ret_val NUMBER;

  CURSOR cur_genel_kod IS
    SELECT * FROM CBS_GENEL_KOD
     WHERE kod_adi = ps_kod_adi FOR UPDATE;

  row_genel_kod CBS_GENEL_KOD%ROWTYPE;

  BEGIN
    IF cur_genel_kod%ISOPEN THEN
       CLOSE cur_genel_kod;
    END IF;

      OPEN cur_genel_kod;
    FETCH cur_genel_kod INTO row_genel_kod;

    IF  cur_genel_kod%NOTFOUND THEN
      CLOSE cur_genel_kod;
      INSERT INTO CBS_GENEL_KOD
                  (kod_adi, kod_deger, son_kod_alan, son_tarih, yaratan_kullanici, yaratildigi_tarih)
           VALUES (ps_kod_adi, 1, USER, SYSDATE, USER, SYSDATE);
      ln_ret_val := 1;
     ELSE
       ln_ret_val := row_genel_kod.kod_deger + 1;
       UPDATE CBS_GENEL_KOD
         SET kod_deger=kod_deger + 1,
             son_kod_alan = USER,
             son_tarih = SYSDATE
        WHERE CURRENT OF cur_genel_kod;
     END IF;
     COMMIT;
     RETURN(ln_ret_val );
  END;

  FUNCTION LC_al RETURN VARCHAR2 IS
  BEGIN
    RETURN 'KGS';
  END;
  
END;
/

