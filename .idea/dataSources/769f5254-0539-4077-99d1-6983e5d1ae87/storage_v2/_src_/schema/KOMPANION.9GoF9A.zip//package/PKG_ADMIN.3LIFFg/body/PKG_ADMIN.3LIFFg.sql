create PACKAGE BODY         "PKG_ADMIN" IS

-----------------------------------------------------------------------------
FUNCTION GetAuthCodes( ps_channelcd IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        CURSOR cursor_auth IS
            SELECT * FROM TBL_PERSON_AUTH a
            WHERE a.person_id=ps_personid
            AND a.CHANNEL_CD=ps_channelcd
            UNION
            SELECT * FROM TBL_PERSON_APPROVAL a
            WHERE a.person_id=ps_personid
            AND a.CHANNEL_CD=ps_channelcd;

        row_auth cursor_auth%ROWTYPE;

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN
     OPEN cursor_auth;
    FETCH cursor_auth INTO row_auth;
    WHILE  cursor_auth%FOUND
    LOOP
        ls_auths:= ls_auths || ',' ||row_auth.AUTH_CD;
        FETCH cursor_auth INTO row_auth;
    END LOOP;
    CLOSE cursor_auth;

     OPEN pc_ref FOR
           SELECT ls_auths FROM dual;
     RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------------------
FUNCTION SetAuthCodes( ps_authcodes  IN VARCHAR2,
                        ps_personid     IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN
     DELETE FROM TBL_PERSON_AUTH
     WHERE person_id=TO_NUMBER(ps_personid)
     AND auth_cd NOT IN ('aDKBCIB','aAUTHORITY');

     INSERT INTO TBL_PERSON_AUTH (person_id,channel_cd,auth_cd)
     SELECT TO_NUMBER(ps_personid),CHANNEL_CD,AUTH_CD FROM TBL_AUTHORITY
     WHERE channel_cd='cCORP'
     AND auth_cd NOT IN ('aCORP','aAUTHORITY')
     AND INSTR(ps_authcodes,auth_cd)>0;


     OPEN pc_ref FOR
           SELECT 'OK' FROM dual;

     RETURN ls_returncode;

END;
-----------------------------------------------------------------------------------
FUNCTION AddAuthTranCd(ps_trancd     IN VARCHAR2,
                    ps_authcd    IN VARCHAR2,
                    ps_langcd     IN VARCHAR2,
                    ps_trandesc   IN VARCHAR2) RETURN VARCHAR2 IS

           CURSOR cursor_tran IS
            SELECT * FROM TBL_TRANSACTION t
            WHERE t.TRAN_CD=ps_trancd
               AND t.LANGUAGE_CD = ps_langcd;

         row_tran cursor_tran%ROWTYPE;
         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';

BEGIN


    OPEN cursor_tran;
    FETCH cursor_tran INTO row_tran;
    IF  cursor_tran%NOTFOUND THEN
         INSERT INTO TBL_TRANSACTION
         (TRAN_CD)
         VALUES
         (ps_trancd);

         INSERT INTO TBL_DESCRIPTION
         (DESC_CD, LANG_CD, DESC_TEXT)
         VALUES
         (ps_trancd,ps_langcd,ps_trandesc);

          INSERT INTO TBL_AUTH_TRAN
         (AUTH_CD,TRAN_CD)
         VALUES
         (ps_authcd,ps_trancd);
    ELSE
         INSERT INTO TBL_AUTH_TRAN
         (AUTH_CD,TRAN_CD)
         VALUES
         (ps_authcd,ps_trancd);
    END IF;
    CLOSE cursor_tran;

     RETURN ls_returncode;


END;
-----------------------------------------------------------------------------------
FUNCTION AddPersonAuth(pn_personid IN NUMBER,
                        ps_channelcd    IN VARCHAR2,
                        ps_authcd    IN VARCHAR2) RETURN VARCHAR2 IS

            CURSOR cursor_personauth IS
            SELECT * FROM TBL_PERSON_AUTH pa
            WHERE pa.PERSON_ID=pn_personid
            AND pa.CHANNEL_CD=ps_channelcd
            AND pa.AUTH_CD=ps_authcd;

         row_personauth cursor_personauth%ROWTYPE;
         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN

    OPEN cursor_personauth;
    FETCH cursor_personauth INTO row_personauth;
    IF  cursor_personauth%NOTFOUND THEN
         INSERT INTO TBL_PERSON_AUTH
         (PERSON_ID, CHANNEL_CD, AUTH_CD)
         VALUES
         (pn_personid, ps_channelcd, ps_authcd);
    END IF;
    CLOSE cursor_personauth;

     RETURN ls_returncode;

END;
-------------------------------------------------------------------------------------
FUNCTION ChangeUserStatus( ps_personid IN VARCHAR2,
                                                ps_newstatus IN VARCHAR2,
                                               ps_expiredate OUT VARCHAR2) RETURN VARCHAR2 IS

     TransactionError EXCEPTION;
     ls_statement VARCHAR2(2000);
     ls_returncode  VARCHAR2(3):='000';
     ls_previousStatus  VARCHAR2(10);
     ld_expiredate DATE;
     ln_personid        NUMBER;
BEGIN
     IF ps_newstatus='E' THEN
         SELECT STATUS_CD,EXPIREDATE INTO ls_previousStatus,ld_expiredate FROM  TBL_IDENTIFICATION WHERE PERSON_ID=TO_NUMBER(ps_personid);
         
         UPDATE TBL_IDENTIFICATION
         SET EXPIREDATE=DECODE(ls_previousStatus,'sLOCKED',EXPIREDATE,SYSDATE+60),
              STATUS_CD='sENAB',
             PWDFORCECHANGE=DECODE(ls_previousStatus,'sLOCKED',PWDFORCECHANGE,'E'),
             ATTEMPT_COUNT=0
         WHERE PERSON_ID=TO_NUMBER(ps_personid);
         

         UPDATE TBL_PERSON
         SET STATUS_CD='sENAB'
         WHERE PERSON_ID=TO_NUMBER(ps_personid);
         SELECT DECODE(ls_previousStatus,'sLOCKED',ld_expiredate,SYSDATE+60) into ld_expiredate from dual; 
         ps_expiredate:=TO_CHAR(ld_expiredate,'DD/MM/YYYY');
     ELSE
         UPDATE TBL_IDENTIFICATION
         SET EXPIREDATE=SYSDATE,
              STATUS_CD='sCANCEL',
             PWDFORCECHANGE='E',
             ATTEMPT_COUNT=0
         WHERE PERSON_ID=TO_NUMBER(ps_personid);

         UPDATE TBL_PERSON
         SET STATUS_CD='sCANCEL'
         WHERE PERSON_ID=TO_NUMBER(ps_personid);


          ps_expiredate:=TO_CHAR(SYSDATE,'DD/MM/YYYY');

     END IF;

     RETURN ls_returncode;

EXCEPTION
     WHEN NO_DATA_FOUND THEN
           RETURN '009';
END;

-----------------------------------------------------------------------------------
FUNCTION CreateUser(ps_channelcd IN VARCHAR2,
                    ps_username    IN VARCHAR2,
                       ps_passcode IN VARCHAR2,
                       ps_pincode IN VARCHAR2,
                   ps_firstname IN VARCHAR2,
                   ps_middlename IN VARCHAR2,
                   ps_lastname IN VARCHAR2,
                   ps_email IN VARCHAR2,
                   pn_customerid IN NUMBER,
                   pn_personid OUT NUMBER) RETURN VARCHAR2 IS
     ls_statement  VARCHAR2(2000);
     ln_personid   NUMBER;
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
     CURSOR cursor_alias IS
             SELECT *
            FROM TBL_IDENTIFICATION
            WHERE (username=ps_username OR useralias=ps_username);

     row_alias      cursor_alias%ROWTYPE;
 BEGIN

     OPEN cursor_alias;
    FETCH cursor_alias INTO row_alias;
    IF  cursor_alias%FOUND THEN
        ls_returncode:='011';
        RAISE TransactionError;
    END IF;
    CLOSE cursor_alias;

     --1) Get Person ID
     ln_personid:=Pkg_Common.GetSequenceID('pqPERSONID');

     --2) Insert Personal Info
     INSERT INTO TBL_PERSON
     (PERSON_ID, FIRSTNAME, MIDDLENAME, LASTNAME, EMAIL, CUSTOMER_ID, STATUS_CD)
     VALUES
     (ln_personid, ps_firstname, ps_middlename, ps_lastname, ps_email, pn_customerid, 'sDISAB');

     --3) Insert Identification Info
     INSERT INTO TBL_IDENTIFICATION
     (PERSON_ID, CHANNEL_CD, USERNAME, USERALIAS, PASSCODE, PINCODE, EXPIREDATE, STATUS_CD, PWDFORCECHANGE)
     VALUES
     (ln_personid, ps_channelcd, NULL, ps_username, ps_passcode, ps_pincode, SYSDATE, 'sDISAB', 'E');

     --4) Return PersonID
      /*ls_statement:= 'select ' || to_char(ln_personid) || ' from dual';

     OPEN pc_ref for ls_statement;
     */
     pn_personid:=ln_personid;
     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
FUNCTION GetChannel( ps_channelcd IN VARCHAR2,
                        ps_langcd    IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
     ls_channelcd          VARCHAR2(10):=NULL;
     ls_langcd              VARCHAR2(3):=NULL;
BEGIN

     IF ps_channelcd!='' THEN
         ls_channelcd:=ps_channelcd;
     END IF;
     IF ps_langcd='' THEN
         ls_langcd:='ENG';
     END IF;

     OPEN pc_ref FOR
          SELECT c.CHANNEL_CD,d.DESC_TEXT
         FROM TBL_CHANNEL c,TBL_DESCRIPTION d
         WHERE c.CHANNEL_CD=d.DESC_CD
         AND d.LANG_CD=ps_langcd
         AND c.CHANNEL_CD=NVL(ls_channelcd,c.CHANNEL_CD);

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
FUNCTION GetErrorCodes(ps_systemcd IN VARCHAR2,
                        ps_errorcd IN VARCHAR2,
                        ps_langcd    IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
     ls_langcd              VARCHAR2(3):=NULL;
     ls_systemcd          VARCHAR2(10):=NULL;
     ls_errorcd              VARCHAR2(3):=NULL;
BEGIN

      IF ps_systemcd='' THEN
         ls_systemcd:=NULL;
     ELSE
          ls_systemcd:=ps_systemcd;
     END IF;

       IF ps_errorcd='' THEN
         ls_errorcd:=NULL;
     ELSE
          ls_errorcd:=ps_errorcd;
     END IF;

     IF ps_langcd='' THEN
         ls_langcd:=NULL;
     ELSE
         ls_langcd:=ps_langcd;
     END IF;

     OPEN pc_ref FOR
          SELECT e.SYSTEM_CD,e.ERROR_CD,e.LANG_CD,e.ERROR_TYPE,e.ERROR_DESC,e.USER_DESC
         FROM TBL_ERROR e
         WHERE e.SYSTEM_CD=NVL(ls_systemcd,e.SYSTEM_CD)
         AND  e.ERROR_CD=NVL(ps_errorcd,e.ERROR_CD)
         AND e.LANG_CD=NVL(ls_langcd,e.LANG_CD)
         ORDER BY e.SYSTEM_CD,e.ERROR_CD,e.LANG_CD;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
----------------------------------------------------------------------------------------
FUNCTION AddErrorMsg(ps_systemcd IN VARCHAR2,
                      ps_errorcd IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                      ps_errortype    IN VARCHAR2,
                     ps_errordesc    IN VARCHAR2,
                     ps_userdesc    IN VARCHAR2) RETURN VARCHAR2 IS


         CURSOR cursor_error IS
             SELECT * FROM TBL_ERROR
            WHERE SYSTEM_CD=ps_systemcd
            AND ERROR_CD=ps_errorcd
            AND LANG_CD=ps_langcd;

         row_error cursor_error%ROWTYPE;
         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN
     OPEN cursor_error;
    FETCH cursor_error INTO row_error;
    IF  cursor_error%NOTFOUND THEN
        INSERT INTO TBL_ERROR
        (SYSTEM_CD, ERROR_CD, LANG_CD,ERROR_TYPE, ERROR_DESC, USER_DESC)
        VALUES
        (ps_systemcd,ps_errorcd,ps_langcd,ps_errortype,ps_errordesc,ps_userdesc);
    ELSE
        UPDATE TBL_ERROR
        SET ERROR_TYPE=ps_errortype, ERROR_DESC=ps_errordesc,USER_DESC=ps_userdesc
        WHERE SYSTEM_CD=ps_systemcd
        AND ERROR_CD=ps_errorcd
        AND LANG_CD=ps_langcd;
    END IF;
    CLOSE cursor_error;

    RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------
FUNCTION GetActivityHistory(ps_channelcd    IN       VARCHAR2,
                            pn_customerid   IN       VARCHAR2,
                            pn_sessionid    IN       VARCHAR2,
                            ps_langcd       IN       VARCHAR2,
                            ps_startdate    IN       VARCHAR2,
                            ps_enddate      IN       VARCHAR2,
                            ps_errorcd      IN       VARCHAR2,
                            ps_ipaddress    IN       VARCHAR2,
                            ps_personid     IN       VARCHAR2,
                            pc_ref          OUT      cursorreferencetype) RETURN VARCHAR2 IS

    ls_statement       VARCHAR2 (2000);
    transactionerror   EXCEPTION;
    ls_returncode      VARCHAR2 (3)    := '000';
    ls_langcd          VARCHAR2 (3)    := NULL;
    ls_customerid      NUMBER          := NULL;
    ls_errorcd         VARCHAR2 (3)    := NULL;
    ld_startdate       DATE;
    ld_enddate         DATE;
    not_valid_date     EXCEPTION;
    PRAGMA EXCEPTION_INIT (not_valid_date, -01839);
    -- yanl?s zaman girilmesi durumunda
BEGIN
    IF ps_startdate IS NULL AND ld_enddate IS NULL
    THEN
        ld_startdate := SYSDATE;
        ld_enddate := SYSDATE + 1;
    ELSE
        ld_startdate := TO_DATE (LTRIM (RTRIM (ps_startdate)) || ' 00:00', 'YYYYMMDD HH24:MI');
        ld_enddate := TO_DATE (LTRIM (RTRIM (ps_enddate)) || ' 23:59', 'YYYYMMDD HH24:MI');
    END IF;

    OPEN pc_ref FOR
        select NVL (pp.firstname || pp.middlename || pp.lastname, '-'),
        aa.SESSION_ID, nvl(tt.DEFINITION,aa.TRAN_CD ), aa.PAGE_ID,
        aa.SYSTEM_CD, aa.ERROR_CD, aa.ERROR_TYPE,
        (select ee.error_desc from CORPINT.tbl_error ee where aa.error_cd=ee.error_cd and ee.lang_cd='ENG' and rownum=1) error_desc,
        to_char(aa.ACTV_TIME,'dd.mm.yyyy hh24:mi:ss'), aa.ACTV_NBR, pp.CUSTOMER_ID, aa.CHANNEL_CD, ii.USERNAME,
        ii.USERALIAS, aa.PERSON_ID, aa.TRAN_CD, aa.DLM, aa.SERVERNAME, aa.CLIENT_IP_ADDRESS,
        aa.FIELD1, aa.FIELD2, aa.FIELD3, aa.FIELD4, aa.FIELD5,
        aa.FIELD6, aa.FIELD7, aa.FIELD8, aa.FIELD9, aa.FIELD10,
        aa.FIELD11, aa.FIELD12, aa.FIELD13, aa.FIELD14, aa.FIELD15
        from CORPINT.tbl_activity aa, CORPINT.tbl_person pp, CORPINT.tbl_identification ii, CORPINT.tbl_transaction tt
        where aa.PERSON_ID=pp.PERSON_ID
        and aa.PERSON_ID=ii.PERSON_ID
        and pp.PERSON_ID=ii.PERSON_ID
        and aa.TRAN_CD=tt.TRAN_CD(+)
        and aa.TRAN_CD not in ('LEFTMENU')
        AND NVL(aa.channel_cd, '-')=NVL(ps_channelcd, NVL(aa.channel_cd, '-'))
        AND NVL(aa.error_cd, '-')=NVL(ps_errorcd, NVL(aa.error_cd, '-'))
        AND NVL(pp.customer_id, '')=NVL(TO_NUMBER(pn_customerid), NVL(pp.customer_id, ''))
        AND aa.session_id=DECODE(pn_sessionid, '', aa.session_id, pn_sessionid)
        AND aa.actv_time BETWEEN ld_startdate AND ld_enddate
        and NVL(aa.CLIENT_IP_ADDRESS, '-')=NVL(ps_ipaddress, NVL(aa.CLIENT_IP_ADDRESS, '-'))
        and aa.PERSON_ID=DECODE(ps_personid, '', aa.PERSON_ID, ps_personid)
        order by aa.ACTV_NBR desc;

RETURN ls_returncode;
EXCEPTION
    WHEN not_valid_date THEN
        ls_returncode := '414';
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
        RETURN ls_returncode;
    WHEN transactionerror THEN
        RETURN '030';
    WHEN OTHERS THEN
        pkg_log.addcustomlog ('GetActivityHistory', SQLERRM);
        RETURN '999';
END;
----------------------------------------------------------------------------------------
FUNCTION AddLangParam(ps_pageid IN VARCHAR2,
                      ps_paramid IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                     ps_paramdesc    IN VARCHAR2) RETURN VARCHAR2 IS


         CURSOR cursor_error IS
             SELECT * FROM TBL_LANGUAGE_DESC
            WHERE PAGE_ID=ps_pageid
            AND PARAM_ID=ps_paramid
            AND LANG_CD=ps_langcd;

         row_error cursor_error%ROWTYPE;
         TransactionError EXCEPTION;
         ls_returncode  VARCHAR2(3):='000';
BEGIN

     OPEN cursor_error;
    FETCH cursor_error INTO row_error;
    IF  cursor_error%NOTFOUND THEN
        INSERT INTO TBL_LANGUAGE_DESC
        (PAGE_ID, PARAM_ID, LANG_CD, PARAM_DESC)
        VALUES
        (ps_pageid ,ps_paramid,ps_langcd,ps_paramdesc);
    ELSE
        UPDATE TBL_LANGUAGE_DESC
        SET PARAM_DESC=ps_paramdesc
        WHERE PAGE_ID=ps_pageid
        AND PARAM_ID=ps_paramid
        AND LANG_CD=ps_langcd;
    END IF;
    CLOSE cursor_error;

    RETURN ls_returncode;
END;

--------------------------------------------------------------------------------------
FUNCTION GetLangParam(ps_pageid IN VARCHAR2,
                      ps_paramid IN VARCHAR2,
                      ps_langcd    IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2    IS
     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
     ls_langcd              VARCHAR2(3):=NULL;
     ls_pageid          VARCHAR2(25):=NULL;
     ls_paramid              VARCHAR2(2):=NULL;
BEGIN

      IF ps_pageid='' THEN
         ls_pageid:=NULL;
     ELSE
          ls_pageid:=ps_pageid;
     END IF;

       IF ps_paramid='' THEN
         ls_paramid:=NULL;
     ELSE
          ls_paramid:=ps_paramid;
     END IF;

     IF ps_langcd='' THEN
         ls_langcd:=NULL;
     ELSE
         ls_langcd:=ps_langcd;
     END IF;

     OPEN pc_ref FOR
          SELECT PAGE_ID, PARAM_ID, LANG_CD, PARAM_DESC
         FROM TBL_LANGUAGE_DESC
         WHERE PAGE_ID=NVL(ps_pageid,PAGE_ID)
         AND PARAM_ID=NVL(ps_paramid,PARAM_ID)
         AND LANG_CD=NVL(ps_langcd,LANG_CD)
         ORDER BY PAGE_ID, PARAM_ID, LANG_CD;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------
FUNCTION GetSuperStatus(pn_personid IN NUMBER) RETURN VARCHAR2 IS
    ls_authcd VARCHAR2(20);
BEGIN

     SELECT auth_cd
     INTO ls_authcd
     FROM TBL_PERSON_AUTH
     WHERE person_id=pn_personid
     AND auth_cd='aAUTHORITY'
     AND channel_cd='cDKBCIB';

     RETURN 'Y';
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN 'N';
END;
-------------------------------------
FUNCTION GetUserInfos(ps_customerid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR
          SELECT
               p.PERSON_ID,
               p.FIRSTNAME ||' '|| p.MIDDLENAME ||' '|| p.LASTNAME AS UNVAN,
               p.CUSTOMER_ID,
               Pkg_Admin.GetSuperStatus(p.PERSON_ID)
        FROM TBL_PERSON p,TBL_IDENTIFICATION i
        WHERE  i.CHANNEL_CD='cDKBCIB'
        AND p.PERSON_ID=i.PERSON_ID
        AND customer_id=TO_NUMBER(ps_customerid)
        AND p.status_cd='sENAB' AND i.status_cd='sENAB';

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-------------------------------------------------------------------------------
FUNCTION GetUserInfosIR(ps_channel IN VARCHAR2,
                         ps_customer IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR
          SELECT
               p.PERSON_ID,
               p.FIRSTNAME ||' '|| p.MIDDLENAME ||' '|| p.LASTNAME AS UNVAN,
               p.CUSTOMER_ID,
               Pkg_Admin.GetSuperStatus(p.PERSON_ID)
        FROM TBL_PERSON p,TBL_IDENTIFICATION i
        WHERE  i.CHANNEL_CD = ps_channel
        AND p.PERSON_ID=i.PERSON_ID
        AND customer_id = TO_NUMBER(ps_customer)
        AND p.status_cd='sENAB' AND i.status_cd='sENAB';

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-------------------------------------------------------------------------------
FUNCTION GetCustomerPersons(ps_customerid IN VARCHAR2,ps_channelcd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';

      CURSOR cursor_user IS
         SELECT
               i.person_id
        FROM TBL_PERSON p,TBL_IDENTIFICATION i
        WHERE  i.CHANNEL_CD=ps_channelcd
        AND p.PERSON_ID=i.PERSON_ID
        AND customer_id=TO_NUMBER(ps_customerid);

    row_user      cursor_user%ROWTYPE;

BEGIN
     OPEN pc_ref FOR
          SELECT
               i.person_id,i.channel_cd,TO_CHAR(i.EXPIREDATE,'YYYYMMDD'),
               i.PWDFORCECHANGE,p.FIRSTNAME,i.status_cd,p.STATUS_CD IDSTATUS,
                  TO_CHAR(i.END_DATE,'YYYYMMDD'),i.PWD_TYPE
        FROM TBL_PERSON p,TBL_IDENTIFICATION i
        WHERE  i.CHANNEL_CD=ps_channelcd
        AND p.PERSON_ID=i.PERSON_ID
        AND p.customer_id=TO_NUMBER(ps_customerid);

        OPEN cursor_user;
        FETCH cursor_user INTO row_user;
        IF  cursor_user%NOTFOUND THEN
            ls_returncode:='018';--passid not found
            RAISE TransactionError;
        END IF;
        CLOSE cursor_user;


     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------
FUNCTION GetCustomerSuperPersons(ps_customerid IN VARCHAR2,ps_channelcd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
      CURSOR cursor_user IS
         SELECT
               i.person_id
        FROM TBL_PERSON p,TBL_IDENTIFICATION i, TBL_PERSON_AUTH a
        WHERE  i.CHANNEL_CD=ps_channelcd
        AND p.PERSON_ID=i.PERSON_ID
        AND p.customer_id=TO_NUMBER(ps_customerid)
        AND p.person_id=a.person_id
        AND a.channel_cd = ps_channelcd
        AND a.auth_cd = 'aAUTHORITY' ;

    row_user      cursor_user%ROWTYPE;
BEGIN
     OPEN pc_ref FOR
          SELECT
               i.person_id,i.channel_cd,i.EXPIREDATE,
               i.PWDFORCECHANGE,p.FIRSTNAME,i.status_cd,p.STATUS_CD IDSTATUS
        FROM TBL_PERSON p,TBL_IDENTIFICATION i, TBL_PERSON_AUTH a
        WHERE  i.CHANNEL_CD=ps_channelcd
        AND p.PERSON_ID=i.PERSON_ID
        AND p.customer_id=TO_NUMBER(ps_customerid)
        AND p.person_id=a.person_id
        AND a.channel_cd = ps_channelcd
        AND a.auth_cd = 'aAUTHORITY' ;

        OPEN cursor_user;
        FETCH cursor_user INTO row_user;
        IF  cursor_user%NOTFOUND THEN
            ls_returncode:='725';--passid not found
            RAISE TransactionError;
        END IF;
        CLOSE cursor_user;
     RETURN ls_returncode;
EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------
FUNCTION showalllogonattemp(ps_ChannelCD IN VARCHAR2,
                            ps_AccessType IN VARCHAR2,
                            ps_CustomerID IN VARCHAR2,
                            ps_LangCD IN VARCHAR2,
                            ps_StartDate IN VARCHAR2,
                            ps_EndDate IN VARCHAR2,
                            ps_IPAdress IN VARCHAR2,
                            ps_PersonID IN VARCHAR2,
                            ps_SessionID IN VARCHAR2,
                            pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode   VARCHAR2 (3) := '000';
    ld_startdate date;
    ld_enddate date;
BEGIN
    IF ps_startdate IS NULL AND ld_enddate IS NULL THEN
        ld_startdate := SYSDATE;
        ld_enddate := SYSDATE + 1;
    ELSE
        ld_startdate := TO_DATE (LTRIM (RTRIM (ps_StartDate)) || ' 00:00', 'YYYYMMDD HH24:MI');
        ld_enddate := TO_DATE (LTRIM (RTRIM (ps_EndDate)) || ' 23:59', 'YYYYMMDD HH24:MI');
    END IF;

    OPEN pc_ref FOR
        select NVL (pp.firstname || pp.middlename || pp.lastname, '-'),
               aa.SESSION_ID, DECODE(aa.TRAN_CD,'LOGON','password + pin','TLOGON','e-Token',aa.TRAN_CD), DECODE(aa.PAGE_ID,'0','End',aa.PAGE_ID),
               aa.SYSTEM_CD, aa.ERROR_CD, aa.ERROR_TYPE,
               (select ee.error_desc from corpint.tbl_error ee where aa.error_cd=ee.error_cd and ee.lang_cd='ENG' and rownum=1) error_desc,
               to_char(aa.ACTV_TIME,'dd.mm.yyyy hh24:mi:ss'), aa.ACTV_NBR, pp.CUSTOMER_ID, aa.CHANNEL_CD, ii.USERNAME,
               nvl(ii.USERALIAS,' '), aa.PERSON_ID, aa.TRAN_CD, aa.DLM, aa.SERVERNAME, aa.CLIENT_IP_ADDRESS,
               aa.FIELD1, aa.FIELD2, aa.FIELD3, aa.FIELD4, aa.FIELD5,
               aa.FIELD6, aa.FIELD7, aa.FIELD8, aa.FIELD9, aa.FIELD10,
               aa.FIELD11, aa.FIELD12, aa.FIELD13, aa.FIELD14, aa.FIELD15
        from corpint.tbl_activity aa, corpint.tbl_person pp, corpint.tbl_identification ii, corpint.tbl_transaction tt, corpint.tbl_channel cc
        where aa.PERSON_ID=pp.PERSON_ID
        and aa.PERSON_ID=ii.PERSON_ID
        and pp.PERSON_ID=ii.PERSON_ID
        and aa.TRAN_CD=tt.TRAN_CD(+)
        and aa.CHANNEL_CD=cc.CHANNEL_CD
        and aa.TRAN_CD in ('LOGON', 'TLOGON')
        and aa.TRAN_CD=decode(ps_AccessType ,'ANY',aa.TRAN_CD,ps_AccessType )
        AND NVL(aa.channel_cd, '-')=NVL(ps_ChannelCD , NVL(aa.CHANNEL_CD, '-'))
        AND pp.customer_id=DECODE(ps_CustomerID, '', pp.customer_id, ps_CustomerID)
        AND aa.actv_time BETWEEN ld_startdate AND ld_enddate
        AND aa.session_id=DECODE(ps_SessionID, '', aa.session_id, ps_SessionID)
        and NVL(aa.CLIENT_IP_ADDRESS, '-')=NVL(ps_IPAdress, NVL(aa.CLIENT_IP_ADDRESS, '-'))
        and aa.PERSON_ID=DECODE(ps_PersonID, '', aa.PERSON_ID, ps_PersonID)
        UNION
        select info, SESSION_ID, TranType, PageID, SYSTEM_CD, ERROR_CD, ERROR_TYPE, error_desc, actv_time,
        ACTV_NBR, id1, CHANNEL_CD, name1, name2, PERSON_ID, TRAN_CD, DLM, SERVERNAME, CLIENT_IP_ADDRESS,
        FIELD1, FIELD2, FIELD3, FIELD4, FIELD5, FIELD6, FIELD7, FIELD8, FIELD9, FIELD10,
        FIELD11, FIELD12, FIELD13, FIELD14, FIELD15 from (
        select corpint.pkg_admin.getActivityPersonInfo(aa.ACTV_NBR) info,
        aa.SESSION_ID, DECODE(aa.TRAN_CD,'LOGON','password + pin','TLOGON','e-Token',aa.TRAN_CD) TranType, DECODE(aa.PAGE_ID,'0','End',aa.PAGE_ID) PageID,
        aa.SYSTEM_CD, aa.ERROR_CD, aa.ERROR_TYPE,
        (select ee.error_desc from corpint.tbl_error ee where aa.error_cd=ee.error_cd and ee.lang_cd='RUS' and rownum=1) error_desc,
        to_char(aa.ACTV_TIME,'dd.mm.yyyy hh24:mi:ss') actv_time, aa.ACTV_NBR, -1 id1, aa.CHANNEL_CD, 'UNKNOWN' name1,
        'UNKNOWN' name2, aa.PERSON_ID, aa.TRAN_CD, aa.DLM, aa.SERVERNAME, aa.CLIENT_IP_ADDRESS,
        aa.FIELD1, aa.FIELD2, aa.FIELD3, aa.FIELD4, aa.FIELD5,
        aa.FIELD6, aa.FIELD7, aa.FIELD8, aa.FIELD9, aa.FIELD10,
        aa.FIELD11, aa.FIELD12, aa.FIELD13, aa.FIELD14, aa.FIELD15
        from corpint.tbl_activity aa, corpint.tbl_transaction tt, corpint.tbl_channel cc
        where aa.PERSON_ID=0
        and aa.TRAN_CD=tt.TRAN_CD(+)
        AND aa.actv_time BETWEEN ld_startdate AND ld_enddate
        AND aa.session_id=DECODE(ps_SessionID, '', aa.session_id, ps_SessionID)
        and aa.CHANNEL_CD=cc.CHANNEL_CD
        and aa.TRAN_CD in ('LOGON', 'TLOGON')
        and aa.TRAN_CD=decode(ps_AccessType ,'ANY',aa.TRAN_CD,ps_AccessType )
        AND NVL(aa.channel_cd, '-')=NVL(ps_ChannelCD , NVL(aa.CHANNEL_CD, '-'))
        and NVL(aa.CLIENT_IP_ADDRESS, '-')=NVL(ps_IPAdress, NVL(aa.CLIENT_IP_ADDRESS, '-'))
        )
        where DECODE(ps_CustomerID,'',info,corpint.pkg_message.SPLIT(info,'###',1))=decode(ps_CustomerID, '', info, ps_CustomerID)
        and   DECODE(ps_PersonID,'',info,corpint.pkg_message.SPLIT(info,'###',2))=decode(ps_PersonID, '', info, ps_PersonID);

RETURN ls_returncode;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
        ls_returncode := '999';                                --alias found
        RETURN ls_returncode;
    WHEN OTHERS THEN
        pkg_log.addcustomlog ('ShowAllLogonAttemp', SQLERRM);
        RAISE_APPLICATION_ERROR(-20100, SQLERRM);
        RETURN '999';
END;

---------------------------------------------
FUNCTION SetSuperUser( ps_chanelcd    IN VARCHAR2,
                       ps_personid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
            ls_count NUMBER := 0;
            ls_returncode VARCHAR2(3):='000';
BEGIN
         OPEN pc_ref FOR
         SELECT SYSDATE FROM dual;

         SELECT COUNT(*)
         INTO ls_count
         FROM TBL_PERSON_AUTH t
         WHERE t.CHANNEL_CD=ps_chanelcd AND
         t.PERSON_ID=TO_NUMBER(ps_personid)
         AND t.AUTH_CD='aAUTHORITY';

         IF (ls_count <> 0) THEN
         ls_returncode:='331';
         ELSE
         INSERT INTO TBL_PERSON_AUTH(PERSON_ID, CHANNEL_CD, AUTH_CD)
         VALUES (TO_NUMBER(ps_personid),ps_chanelcd,'aAUTHORITY');
         END IF;
         RETURN ls_returncode;

EXCEPTION
              WHEN NO_DATA_FOUND THEN
             ls_returncode:='331';--alias found
             RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------
FUNCTION AddToken(ps_tokenid    IN VARCHAR2,
                       ps_chanelcd    IN VARCHAR2,
                       ps_personid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
            ls_digipass VARCHAR2(50):='';
            ls_returncode VARCHAR2(3):='000';
            ln_count      NUMBER;
BEGIN

         OPEN pc_ref FOR
         SELECT SYSDATE FROM dual;

         SELECT DIGIPASS
         INTO ls_digipass
         FROM TBL_TOKEN
         WHERE INSTR(DIGIPASS,ps_tokenid)>0;

         IF (LENGTH(ls_digipass) <> 0 ) THEN

            SELECT COUNT(*)
            INTO ln_count
            FROM TBL_IDENTIFICATION
            WHERE TOKEN_ID=ls_digipass;

            IF ln_count=0 THEN
                UPDATE TBL_IDENTIFICATION t
                SET t.TOKEN_ID=ls_digipass,
                    ASSIGN_TOKEN_DATE=sysdate
                WHERE t.PERSON_ID=ps_personid
                AND t.CHANNEL_CD=ps_chanelcd;
            ELSE--already in use
                ls_returncode:='124';
            END IF;
         END IF;

         RETURN ls_returncode;

EXCEPTION
              WHEN NO_DATA_FOUND THEN
             ls_returncode:='112';--alias found
             RETURN ls_returncode;

END;
----------------------------------------------------------------------------------------
FUNCTION DeleteToken(ps_personid IN VARCHAR2,ps_channelid IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
         ln_token      VARCHAR2(50);
         ls_returncode VARCHAR2(3) :='000';
BEGIN

     OPEN pc_ref FOR
     SELECT SYSDATE FROM dual;

     SELECT T.TOKEN_ID
     INTO ln_token
     FROM TBL_IDENTIFICATION t
     WHERE  t.PERSON_ID =TO_NUMBER(ps_personid)
     AND t.CHANNEL_CD=ps_channelid;

     IF LENGTH(ln_token)>0 THEN
         UPDATE TBL_IDENTIFICATION t
         SET t.TOKEN_ID=NULL
         WHERE t.PERSON_ID =TO_NUMBER(ps_personid)
         AND t.CHANNEL_CD=ps_channelid;
     ELSE
          ls_returncode:='452';
      END IF;

     RETURN ls_returncode;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
         RETURN '452';
    WHEN OTHERS THEN
         RETURN '999';

END;
------------------------------------------------------------
FUNCTION ActivityDetail(ps_activity IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
         ls_returncode VARCHAR2(3) :='000';
BEGIN

     OPEN pc_ref FOR
     SELECT A.SESSION_ID, A.ACTV_TIME, C.DEFINITION , A.CLIENT_IP_ADDRESS , e.ERROR_DESC , NVL(t.DEFINITION,a.TRAN_CD),
     A.PAGE_ID, NVL(A.FIELD1,' ') ,NVL(A.FIELD2,' ') ,NVL(A.FIELD3,' ') ,NVL(A.FIELD4,' ') ,NVL(A.FIELD5,' ') ,NVL(A.FIELD6,' ') ,NVL(A.FIELD7,' ') ,NVL(A.FIELD8,' ') ,NVL(A.FIELD9,' ') ,NVL(A.FIELD10,' ') ,
     NVL(A.FIELD11,' ') ,NVL(A.FIELD12,' ') ,NVL(A.FIELD13,' ') ,NVL(A.FIELD14,' ') ,NVL(A.FIELD15,' ')

     FROM TBL_ACTIVITY A , TBL_TRANSACTION T ,TBL_CHANNEL C,TBL_ERROR e
     WHERE A.ACTV_NBR=TO_NUMBER(ps_activity)
     AND a.SYSTEM_CD=e.SYSTEM_CD
     AND a.ERROR_CD=e.ERROR_CD
     AND t.TRAN_CD =A.TRAN_CD
     AND t.LANGUAGE_CD = 'ENG'
     AND a.CHANNEL_CD= C.CHANNEL_CD(+);

     RETURN ls_returncode;
  EXCEPTION
    WHEN OTHERS THEN
         RETURN '999';

END;
-----------------------------------------------------------------------
FUNCTION GetAdminPerson(ps_channelid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

            ls_returncode VARCHAR2(3) :='000';
BEGIN
     OPEN pc_ref FOR
     SELECT A.PERSON_ID, P.FIRSTNAME ||' '||P.MIDDLENAME||' '||P.LASTNAME
     FROM TBL_IDENTIFICATION A,TBL_PERSON P
     WHERE a.CHANNEL_CD=ps_channelid AND
     a.STATUS_CD='sENAB' AND
     a.PERSON_ID=p.PERSON_ID;

     RETURN ls_returncode;
  EXCEPTION
    WHEN OTHERS THEN
         RETURN '999';
END;
----------------------------------------------
FUNCTION GetAdminAuth(ps_personid IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
            ls_returncode VARCHAR2(3) :='000';
BEGIN
     OPEN pc_ref FOR
     SELECT P.PERSON_ID,P.AUTH_CD
     FROM TBL_PERSON_AUTH P
     WHERE P.CHANNEL_CD='cCORPADM' AND P.PERSON_ID=ps_personid;

     RETURN ls_returncode;
  EXCEPTION
    WHEN OTHERS THEN
         RETURN '999';
END;
-------------------------------------------------
FUNCTION CheckRetailControl(ps_customerid IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
                             ls_returncode VARCHAR2(3) :='000';
                            ls_count  NUMBER := 0;
BEGIN

     OPEN pc_ref FOR
     SELECT SYSDATE FROM dual;

     SELECT COUNT(*)
     INTO ls_count
     FROM TBL_PERSON P,TBL_IDENTIFICATION D
     WHERE P.CUSTOMER_ID=TO_NUMBER(ps_customerid)
     AND P.PERSON_ID=D.PERSON_ID AND
     D.CHANNEL_CD='cRETAIL';

     IF (ls_count > 0) THEN
     ls_returncode:= '671';
     END IF;

     RETURN ls_returncode;
  EXCEPTION
    WHEN OTHERS THEN
         RETURN '999';
END;
---------------------------------------------------------------------
FUNCTION listallcintuser(ps_channelid IN  VARCHAR2,
                         pc_ref       OUT cursorreferencetype) RETURN VARCHAR2 IS
  ls_returncode   VARCHAR2 (3) := '000';
BEGIN
  OPEN pc_ref FOR
     SELECT NVL (d.useralias, d.username), c.definition,
            DECODE (d.status_cd,
                    'sENAB', 'Active',
                    'sDISAB', 'Disabled',
                    'sLOCKED', 'Locked',
                    'sCANCEL', 'Cancelled',
                    '-'),
            TO_CHAR (d.expiredate, 'YYYYMMDD'),
            p.firstname || ' ' || p.middlename || ' ' || p.lastname,
            p.customer_id,
            DECODE (p.status_cd,
                    'sENAB', 'Active',
                    'sDISAB', 'Disabled',
                    'sLOCKED', 'Locked',
                    'sCANCEL', 'Cancelled',
                    '-'),
            NVL (SUBSTR (d.token_id, 3, 7), '-')
     FROM tbl_person p, tbl_identification d, tbl_channel c
     WHERE d.channel_cd = ps_channelid
     AND d.person_id = p.person_id
     AND d.channel_cd = c.channel_cd;

  RETURN ls_returncode;
EXCEPTION
  WHEN OTHERS
  THEN
     pkg_log.addcustomlog ('ListAllCINTUser', SQLERRM);
     RETURN '999';
END;
---------------------------------------------------------------------------
FUNCTION GetPassIDList(ps_customerid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN
         OPEN pc_ref FOR
         SELECT PASSID,
                  --ASSIGNEDTO,
                Pkg_Admin.GetPersonName(t.PERSON_ID),
                C.DEFINITION,
                t.STATUS_CD,
                TO_CHAR(ASSIGNDATE,'YYYYMMDD'),
                GetPersonName(ASSIGNEDBY)
         FROM TBL_DUMMY_PASSID p, TBL_IDENTIFICATION t, TBL_CHANNEL C
         WHERE p.USERNAME=t.USERNAME
         AND C.CHANNEL_CD=t.CHANNEL_CD
         AND p.ASSIGNEDTO=ps_customerid
         ORDER BY PASSID;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
---------------------------------------------------------------
FUNCTION GetPersonName(ps_personid IN VARCHAR2) RETURN VARCHAR2 IS
              ls_fullname VARCHAR2(200):=' ';
              ls_count    NUMBER:=0;
BEGIN

   SELECT COUNT(*)
   INTO ls_count
   FROM TBL_PERSON p
   WHERE p.PERSON_ID=ps_personid;

   IF (ls_count > 0)   THEN

   SELECT p.FIRSTNAME||' '||p.MIDDLENAME||' '||p.LASTNAME
   INTO ls_fullname
   FROM TBL_PERSON p
   WHERE p.PERSON_ID=ps_personid;
   ELSE
   ls_fullname:=' ';
   END IF;

   RETURN ls_fullname;

END;
---------------------------------------------------------------
FUNCTION GetSystemMessage(ps_dummy IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
              ls_returncode          VARCHAR2(3):='000';
BEGIN
      OPEN pc_ref FOR
      SELECT W.MESSAGE,W.WARNINGID FROM TBL_USER_WARNINGS W
      WHERE w.STATUS='sENAB' AND
      TRUNC(w.STARTDATE) <= TRUNC(SYSDATE) AND
      TRUNC(w.ENDDATE) >= TRUNC(SYSDATE);

      RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------
FUNCTION DelParola( ps_channelcd IN VARCHAR2,
                      ps_personid IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

                  ls_returncode VARCHAR2(3):='000';
                 ls_recordcount NUMBER:=0;
BEGIN
      OPEN pc_ref FOR
      SELECT SYSDATE FROM dual;

      SELECT COUNT(*)
      INTO ls_recordcount
      FROM TBL_PAROLA P
      WHERE P.CHANNELCD=ps_channelcd
      AND P.PERSONID=ps_personid;

      IF (ls_recordcount = 0 ) THEN
            ls_returncode:='427';--parola yok
      ELSE
          DELETE FROM TBL_PAROLA P
          WHERE P.CHANNELCD=ps_channelcd
          AND P.PERSONID=ps_personid;
      END IF;

      RETURN ls_returncode;
END;

----------------------------------------------------------------------------------------
FUNCTION GetApprovalTrans( ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                        ps_langid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         ln_isPresent NUMBER:=0;
BEGIN
    SELECT COUNT(*)
    INTO ln_isPresent
    FROM TBL_APPROVAL_TRAN a
    WHERE a.customer_id=ps_customerid
    AND a.CHANNEL_CD=ps_channelcd;

    IF ln_isPresent=0 THEN
        INSERT INTO TBL_APPROVAL_TRAN
        (CUSTOMER_ID,CHANNEL_CD,TRAN_CD,VERIFY,APPROVE,
         CHECKER,DAILY_LIMIT,LIMIT_CURRENCY,ORDER_ID)
        SELECT ps_customerid,ps_channelcd,a.TRAN_CD,'Y','Y','Y',0,'KGS',
               DECODE(a.tran_cd,'CLEARING',1,'EXCHNGBUY',2,'EXCHNGSELL',3,'B2BHVL',4,'B2OBHVL',5,'CLEARCNCL',6, 'ARBITRAGE', 7, 'SWIFT', 8, 'GROSS', 9, 'CARDDEBT', 10, 'PAYMENTS', 11, 'SALARY', 12) --ChyngyzO cq4960 Salary Payments 28.12.2015
        FROM TBL_TRANSACTION a, TBL_APPROVAL_TRAN_MAX_LIMIT b
        WHERE a.tran_cd IN ('CLEARING','EXCHNGBUY','EXCHNGSELL','B2BHVL','B2OBHVL','CLEARCNCL', 'ARBITRAGE', 'SWIFT', 'GROSS', 'CARDDEBT', 'PAYMENTS', 'SALARY') --ChyngyzO cq4960 Salary Payments 28.12.2015
        AND a.LANGUAGE_CD = ps_langid
        AND a.tran_cd = b.tran_cd
        AND b.customer_no = ps_customerid
        AND b.channel_cd = 'cDKBCIB';
    END IF;

    OPEN pc_ref FOR
        SELECT
        a.CUSTOMER_ID,
        a.CHANNEL_CD,
        a.TRAN_CD,
        Pkg_Common.GetTranDescription(a.TRAN_CD,ps_langid),
        a.CHECKER,
        a.VERIFY,
        a.APPROVE,
        NVL(LTRIM(RTRIM(TO_CHAR(a.DAILY_LIMIT))),'0'),
        a.LIMIT_CURRENCY,
        m.MAX_DAILY_LIMIT,
        m.CURRENCY_CODE,
        a.ORDER_ID
        FROM TBL_APPROVAL_TRAN a,TBL_APPROVAL_TRAN_MAX_LIMIT m
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND m.customer_no = ps_customerid
        AND m.CHANNEL_CD=ps_channelcd
        AND a.TRAN_CD=m.TRAN_CD
        ORDER BY a.ORDER_ID;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------------------------
FUNCTION GetSpecApprovalTrans( ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                        ps_langid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         ln_isPresent NUMBER:=0;
BEGIN
    SELECT COUNT(*)
    INTO ln_isPresent
    FROM TBL_SPEC_APPROVAL_TRAN a
    WHERE a.customer_id=ps_customerid
    AND a.CHANNEL_CD=ps_channelcd;

    IF ln_isPresent=0 THEN
        INSERT INTO TBL_SPEC_APPROVAL_TRAN
        (CUSTOMER_ID,CHANNEL_CD,TRAN_CD,VERIFY,APPROVE,
         CHECKER,DAILY_LIMIT,LIMIT_CURRENCY,ORDER_ID)
        SELECT ps_customerid,ps_channelcd,a.TRAN_CD,'Y','Y','Y',0,'KGS',
               DECODE(a.tran_cd,'CLEARING',1,'EXCHNGBUY',2,'EXCHNGSELL',3,'B2BHVL',4,'B2OBHVL',5,'CLEARCNCL',6, 'ARBITRAGE', 7, 'SWIFT', 8, 'GROSS', 9, 'CARDDEBT', 10, 'PAYMENTS', 11, 'SALARY', 12) --ChyngyzO cq4960 Salary Payments 28.12.2015
        FROM TBL_TRANSACTION a, TBL_SPECAPP_TRAN_MAX_LIMIT b
        WHERE a.tran_cd IN ('CLEARING','EXCHNGBUY','EXCHNGSELL','B2BHVL','B2OBHVL','CLEARCNCL', 'ARBITRAGE', 'SWIFT', 'GROSS', 'CARDDEBT', 'PAYMENTS', 'SALARY')  --ChyngyzO cq4960 Salary Payments 28.12.2015
        AND a.LANGUAGE_CD = ps_langid
        AND a.tran_cd = b.tran_cd
        AND b.customer_no = ps_customerid
        AND b.channel_cd = 'cDKBCIB' ;
    END IF;

    OPEN pc_ref FOR
        SELECT
        a.CUSTOMER_ID,
        a.CHANNEL_CD,
        a.TRAN_CD,
        Pkg_Common.GetTranDescription(a.TRAN_CD,ps_langid),
        a.CHECKER,
        a.VERIFY,
        a.APPROVE,
        NVL(LTRIM(RTRIM(TO_CHAR(a.DAILY_LIMIT))),'0'),
        a.LIMIT_CURRENCY,
        m.MAX_DAILY_LIMIT,
        m.CURRENCY_CODE,
        a.ORDER_ID
        FROM TBL_SPEC_APPROVAL_TRAN a,TBL_SPECAPP_TRAN_MAX_LIMIT m
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND m.customer_no = ps_customerid
        AND m.CHANNEL_CD=ps_channelcd
        AND a.TRAN_CD=m.TRAN_CD
        ORDER BY a.ORDER_ID;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------------------------
FUNCTION ControlTranAuth(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        CURSOR cursor_tran IS
        SELECT a.ORDER_ID,a.TRAN_CD,a.LIMIT_CURRENCY,a.DAILY_LIMIT,b.MAX_DAILY_LIMIT,b.CURRENCY_CODE
        FROM TBL_APPROVAL_TRAN a,TBL_APPROVAL_TRAN_MAX_LIMIT B
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND b.customer_no = ps_customerid
        AND b.CHANNEL_CD=ps_channelcd
        AND a.TRAN_CD = B.TRAN_CD;

           r1 cursor_tran%ROWTYPE;

        TransactionError EXCEPTION;
        ls_auths VARCHAR2(2000);
        ls_returncode  VARCHAR2(3):='000';
        i              NUMBER:=1;
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    OPEN cursor_tran;
        FETCH cursor_tran INTO r1;
        WHILE  cursor_tran%FOUND
          LOOP

    FETCH cursor_tran INTO r1;

    END LOOP;
    CLOSE cursor_tran;
    RETURN ls_returncode;
EXCEPTION
    WHEN TransactionError THEN
         RETURN ls_returncode;
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------
FUNCTION ControlSpecTranAuth(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        CURSOR cursor_tran IS
        SELECT a.ORDER_ID,a.TRAN_CD,a.LIMIT_CURRENCY,a.DAILY_LIMIT,b.MAX_DAILY_LIMIT,b.CURRENCY_CODE
        FROM TBL_SPEC_APPROVAL_TRAN a,TBL_SPECAPP_TRAN_MAX_LIMIT B
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND b.customer_no = ps_customerid
        AND b.CHANNEL_CD=ps_channelcd
        AND a.TRAN_CD = B.TRAN_CD;

           r1 cursor_tran%ROWTYPE;

        TransactionError EXCEPTION;
        ls_auths VARCHAR2(2000);
        ls_returncode  VARCHAR2(3):='000';
        i              NUMBER:=1;
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    OPEN cursor_tran;
        FETCH cursor_tran INTO r1;
        WHILE  cursor_tran%FOUND
          LOOP

    FETCH cursor_tran INTO r1;

    END LOOP;
    CLOSE cursor_tran;
    RETURN ls_returncode;
EXCEPTION
    WHEN TransactionError THEN
         RETURN ls_returncode;
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------
FUNCTION SPLIT(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2 IS
        ln_i                NUMBER:=1;
        ln_itemindx       NUMBER:=0;
        ls_strOut        VARCHAR2(2000);
BEGIN

       LOOP
       EXIT WHEN NOT (ln_i<=LENGTH(ps_str) OR INSTR(ps_str,ps_delimeter,ln_i)>0);
            IF ln_itemindx=pn_valindx THEN
                IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
                   ls_strOut:=SUBSTR(ps_str,ln_i,INSTR(ps_str,ps_delimeter,ln_i)-ln_i);
                ELSE
                   ls_strOut:=SUBSTR(ps_str,ln_i);
                END IF;
               RETURN ls_strOut;
            END IF;
            IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
               ln_i:=INSTR(ps_str,ps_delimeter,ln_i)+LENGTH(ps_delimeter);
            ELSE
                ln_i:=LENGTH(ps_str)+1;
            END IF;
            ln_itemindx:=ln_itemindx+1;

       END LOOP;

       RETURN '';
END;
---------------------------------------------------------------------------
FUNCTION SetApproval(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_check    IN VARCHAR2,
                       ps_verify    IN VARCHAR2,
                       ps_approve    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                       ps_currency     IN VARCHAR2,
                       ps_rates        IN VARCHAR2,
                       ps_flag        IN VARCHAR2,
                       ps_swift_specGroup IN VARCHAR2, --ChyngyzO cq509 17.03.15
                       ps_salaryCurrency IN VARCHAR2, --ChyngyzO cq4960 28.12.15
                       ps_salaryCommType IN VARCHAR2,--ChyngyzO cq4960 28.12.15
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        CURSOR cursor_tran IS
        SELECT a.ORDER_ID,a.TRAN_CD,a.DAILY_LIMIT,a.LIMIT_CURRENCY,b.MAX_DAILY_LIMIT,b.CURRENCY_CODE
        FROM TBL_APPROVAL_TRAN a,TBL_APPROVAL_TRAN_MAX_LIMIT B
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND b.customer_no = ps_customerid
        AND b.CHANNEL_CD=ps_channelcd
        AND a.TRAN_CD = B.TRAN_CD;

         row_tran cursor_tran%ROWTYPE;

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         i              NUMBER:=1;
         ln_newlimit  NUMBER;
         ln_maxlimit  NUMBER;
         ln_reallimit  NUMBER;
         ln_maxreallimit  NUMBER;
         ln_rate1       NUMBER;
         ln_rate2       NUMBER;
         ln_trancount  NUMBER:=13; --ChyngyzO cq509 17/03/15 changed from 12 to 13
         ln_count NUMBER := 0; --ChyngyzO cq4960 28.12.2015
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    OPEN cursor_tran;
    FETCH cursor_tran INTO row_tran;
    WHILE  cursor_tran%FOUND
    LOOP
         IF Pkg_Admin.SPLIT(ps_currency,';',row_tran.ORDER_ID) = 'USD' THEN
            ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.9999');
         ELSIF Pkg_Admin.SPLIT(ps_currency,';',row_tran.ORDER_ID) = 'EUR' THEN
            ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.9999');
         ELSE
              ln_rate1:=1;
         END IF;
         IF row_tran.CURRENCY_CODE='USD' THEN
            ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.9999');
         ELSIF row_tran.CURRENCY_CODE='EUR' THEN
            ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.9999');
         ELSE
              ln_rate2:=1;
         END IF;
         ln_newlimit := NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_amount,';',row_tran.ORDER_ID),'99999999999.99'),0);
         ln_maxlimit := row_tran.MAX_DAILY_LIMIT ;

         ln_reallimit := ln_newlimit * ln_rate1;

         ln_maxreallimit := ln_maxlimit * ln_rate2;
         IF ln_maxreallimit < ln_reallimit THEN
             ls_returncode:='076';
            RAISE TransactionError;
         END IF;
    FETCH cursor_tran INTO row_tran;

    END LOOP;
    CLOSE cursor_tran;

    WHILE i<ln_trancount
    LOOP
        UPDATE TBL_APPROVAL_TRAN
        SET
            CHECKER = DECODE(TRAN_CD,Pkg_Admin.SPLIT(ps_check,';',i),'Y','N'),
            VERIFY = DECODE(TRAN_CD,Pkg_Admin.SPLIT(ps_verify,';',i),'Y','N'),
            APPROVE = DECODE(TRAN_CD,Pkg_Admin.SPLIT(ps_approve,';',i),'Y','N'),
            --DAILY_LIMIT=NVL(TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_amount,';',i-1),',',''),'.',',')),0),
            DAILY_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_amount,';',i),'99999999999.99'),0),
            LIMIT_CURRENCY = Pkg_Admin.SPLIT(ps_currency,';',i)
        WHERE channel_cd=ps_channelcd
        AND CUSTOMER_ID=ps_customerid
        AND order_id=i;
        i:=i+1;
    END LOOP;

    UPDATE TBL_FXTRANSFER
    SET FLAG = NVL(ps_flag,'N')
    WHERE CUSTOMER_ID = ps_customerid;

    /*BOM ChyngyzO cq4960 28.12.2015 UPDATE CUSTOMERS GROUP (SPECIAL OR STANDARD)*/ 
    BEGIN
        SELECT COUNT(*) INTO ln_count 
        FROM CORPINT.TBL_CUSTOMER_SETTINGS 
        WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.currency';
        
        IF ln_count = 0 THEN
            INSERT INTO CORPINT.TBL_CUSTOMER_SETTINGS (CUSTOMER_NO, SETTINGS_CD, SETTINGS_VALUE, UPDATED_DATE, UPDATED_USER)
            VALUES(ps_customerid, 'salary.currency',  ps_salaryCurrency, SYSDATE, USER);
        ELSE
            UPDATE CORPINT.TBL_CUSTOMER_SETTINGS
            SET SETTINGS_VALUE =ps_salaryCurrency, UPDATED_DATE=SYSDATE, UPDATED_USER=USER
            WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.currency';
        END IF;
        
        SELECT COUNT(*) INTO ln_count 
        FROM CORPINT.TBL_CUSTOMER_SETTINGS 
        WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.comm.type';
        
        IF ln_count = 0 THEN
            INSERT INTO CORPINT.TBL_CUSTOMER_SETTINGS (CUSTOMER_NO, SETTINGS_CD, SETTINGS_VALUE, UPDATED_DATE, UPDATED_USER)
            VALUES(ps_customerid, 'salary.comm.type',  ps_salaryCommType, SYSDATE, USER);
        ELSE
            UPDATE CORPINT.TBL_CUSTOMER_SETTINGS
            SET SETTINGS_VALUE =ps_salaryCommType, UPDATED_DATE=SYSDATE, UPDATED_USER=USER
            WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.comm.type';
        END IF;
        
    EXCEPTION 
        WHEN OTHERS THEN
           Pkg_Log.AddCustomLog('pkg_admin.SetApproval salaryCurrency', '1='||ps_customerid||' 2='||ps_salaryCurrency||' 3='||ps_salaryCommType, SQLERRM);
    END;
     /*EOM ChyngyzO cq4960 28.12.2015 */
   
    /*BOM ChyngyzO cq509 17.03.15 UPDATE CUSTOMERS GROUP (SPECIAL OR STANDARD)*/ 
    BEGIN
        SELECT COUNT(*) INTO ln_count FROM CORPINT.TBL_SWIFT_SPECIAL_CUSTOMER WHERE CUSTOMER_ID = ps_customerid;
        
        IF ln_count = 0 THEN
            INSERT INTO CORPINT.TBL_SWIFT_SPECIAL_CUSTOMER(CUSTOMER_ID, SPECIAL_TIME, CREATE_DATE)
            VALUES(ps_customerid, UPPER(SUBSTR(ps_swift_specGroup, 1)), SYSDATE);
        ELSE
            UPDATE CORPINT.TBL_SWIFT_SPECIAL_CUSTOMER
            SET SPECIAL_TIME = UPPER(SUBSTR(ps_swift_specGroup, 1)), CREATE_DATE=SYSDATE
            WHERE CUSTOMER_ID = ps_customerid;
        END IF;
        EXCEPTION 
            WHEN OTHERS THEN
               Pkg_Log.AddCustomLog('swiftcib pkg_admin.SetApproval', '1='||ps_customerid||'2='||ps_swift_specGroup, SQLERRM);
    END;
    /*EOM ChyngyzO cq509 17.03.15 */
    

    OPEN pc_ref FOR
        SELECT a.CUSTOMER_ID, a.CHANNEL_CD, a.TRAN_CD,t.DEFINITION,a.VERIFY, a.APPROVE,NVL(LTRIM(RTRIM(TO_CHAR(a.DAILY_LIMIT,'999G999G999G999G999'))),'0'), A.LIMIT_CURRENCY
        FROM TBL_APPROVAL_TRAN a,TBL_TRANSACTION t
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND t.LANGUAGE_CD = 'ENG'
        AND t.TRAN_CD=a.TRAN_CD
        ORDER BY ORDER_ID;

    RETURN ls_returncode;

EXCEPTION
    WHEN TransactionError THEN
         RETURN ls_returncode;
    WHEN OTHERS THEN
         Pkg_Log.AddCustomLog(ps_amount,ps_rates,SQLERRM);
        RETURN '666';

END;
--------------------------------------------------------------------------------------
FUNCTION SetSpecApproval(ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                       ps_check    IN VARCHAR2,
                       ps_verify    IN VARCHAR2,
                       ps_approve    IN VARCHAR2,
                       ps_amount    IN VARCHAR2,
                       ps_currency     IN VARCHAR2,
                       ps_rates        IN VARCHAR2,
                       ps_flag        IN VARCHAR2,
                       ps_swift_specGroup IN VARCHAR2,--ChyngyzO cq509 17.03.2015
                       ps_salaryCurrency IN VARCHAR2, --ChyngyzO cq4960 28.12.15
                       ps_salaryCommType IN VARCHAR2,--ChyngyzO cq4960 28.12.15
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        CURSOR cursor_tran IS
        SELECT a.ORDER_ID,a.TRAN_CD,a.DAILY_LIMIT,a.LIMIT_CURRENCY,b.MAX_DAILY_LIMIT,b.CURRENCY_CODE
        FROM TBL_SPEC_APPROVAL_TRAN a,TBL_SPECAPP_TRAN_MAX_LIMIT B
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND b.customer_no = ps_customerid
        AND b.CHANNEL_CD=ps_channelcd
        AND a.TRAN_CD = B.TRAN_CD;

         row_tran cursor_tran%ROWTYPE;

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         i              NUMBER:=1;
         ln_newlimit  NUMBER;
         ln_maxlimit  NUMBER;
         ln_reallimit  NUMBER;
         ln_maxreallimit  NUMBER;
         ln_rate1       NUMBER;
         ln_rate2       NUMBER;
         ln_trancount  NUMBER:=13; --ChyngyzO cq509 17/03/15 changed from 12 to 13
         ln_count NUMBER := 0; --ChyngyzO cq509 17/03/15
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    
    OPEN cursor_tran;
    FETCH cursor_tran INTO row_tran;
    WHILE  cursor_tran%FOUND
    LOOP
         IF Pkg_Admin.SPLIT(ps_currency,';',row_tran.ORDER_ID) = 'USD' THEN
            ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.9999');
         ELSIF Pkg_Admin.SPLIT(ps_currency,';',row_tran.ORDER_ID) = 'EUR' THEN
            ln_rate1:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.9999');
         ELSE
              ln_rate1:=1;
         END IF;
         IF row_tran.CURRENCY_CODE='USD' THEN
            ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',0),'99999999999.9999');
         ELSIF row_tran.CURRENCY_CODE='EUR' THEN
            ln_rate2:=TO_NUMBER(Pkg_Admin.SPLIT(ps_rates,';',1),'99999999999.9999');
         ELSE
              ln_rate2:=1;
         END IF;
         ln_newlimit := NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_amount,';',row_tran.ORDER_ID),'99999999999.99'),0);
         ln_maxlimit := row_tran.MAX_DAILY_LIMIT ;

         ln_reallimit := ln_newlimit * ln_rate1;

         ln_maxreallimit := ln_maxlimit * ln_rate2;
         IF ln_maxreallimit < ln_reallimit THEN
             ls_returncode:='076';
            RAISE TransactionError;
         END IF;
    FETCH cursor_tran INTO row_tran;

    END LOOP;
    CLOSE cursor_tran;
    
    WHILE i<ln_trancount
    LOOP
        UPDATE TBL_SPEC_APPROVAL_TRAN
        SET
            CHECKER = DECODE(TRAN_CD,Pkg_Admin.SPLIT(ps_check,';',i),'Y','N'),
            VERIFY = DECODE(TRAN_CD,Pkg_Admin.SPLIT(ps_verify,';',i),'Y','N'),
            APPROVE = DECODE(TRAN_CD,Pkg_Admin.SPLIT(ps_approve,';',i),'Y','N'),
            --DAILY_LIMIT=NVL(TO_NUMBER(REPLACE(REPLACE(Pkg_Admin.SPLIT(ps_amount,';',i-1),',',''),'.',',')),0),
            DAILY_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_amount,';',i),'99999999999.99'),0),
            LIMIT_CURRENCY = Pkg_Admin.SPLIT(ps_currency,';',i)
        WHERE channel_cd=ps_channelcd
        AND CUSTOMER_ID=ps_customerid
        AND order_id=i;
        i:=i+1;
    END LOOP;

    UPDATE TBL_FXTRANSFER
    SET FLAG = NVL(ps_flag,'N')
    WHERE CUSTOMER_ID = ps_customerid;

     /*BOM ChyngyzO cq4960 28.12.2015 UPDATE CUSTOMERS GROUP (SPECIAL OR STANDARD)*/ 

    BEGIN
        SELECT COUNT(*) INTO ln_count 
        FROM CORPINT.TBL_CUSTOMER_SETTINGS 
        WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.currency.tx';
        
        IF ln_count = 0 THEN
            INSERT INTO CORPINT.TBL_CUSTOMER_SETTINGS (CUSTOMER_NO, SETTINGS_CD, SETTINGS_VALUE, UPDATED_DATE, UPDATED_USER)
            VALUES(ps_customerid, 'salary.currency.tx',  ps_salaryCurrency, SYSDATE, USER);
        ELSE
            UPDATE CORPINT.TBL_CUSTOMER_SETTINGS
            SET SETTINGS_VALUE =ps_salaryCurrency, UPDATED_DATE=SYSDATE, UPDATED_USER=USER
            WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.currency.tx';
        END IF;
        
        SELECT COUNT(*) INTO ln_count 
        FROM CORPINT.TBL_CUSTOMER_SETTINGS 
        WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.comm.type.tx';
        
        IF ln_count = 0 THEN
            INSERT INTO CORPINT.TBL_CUSTOMER_SETTINGS (CUSTOMER_NO, SETTINGS_CD, SETTINGS_VALUE, UPDATED_DATE, UPDATED_USER)
            VALUES(ps_customerid, 'salary.comm.type.tx',  ps_salaryCommType, SYSDATE, USER);
        ELSE
            UPDATE CORPINT.TBL_CUSTOMER_SETTINGS
            SET SETTINGS_VALUE =ps_salaryCommType, UPDATED_DATE=SYSDATE, UPDATED_USER=USER
            WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'salary.comm.type.tx';
        END IF;
        
        EXCEPTION 
            WHEN OTHERS THEN
               Pkg_Log.AddCustomLog('pkg_admin.SetSpecApproval salaryCurrency', '1='||ps_customerid||' 2='||ps_salaryCurrency||' 3='||ps_salaryCommType, SQLERRM);
    END;
     /*EOM ChyngyzO cq4960 28.12.2015 */
   
    /*BOM ChyngyzO cq509 17.03.15 UPDATE CUSTOMERS GROUP (SPECIAL OR STANDARD)*/ 
    BEGIN
    
        SELECT COUNT(*) INTO ln_count 
        FROM CORPINT.TBL_CUSTOMER_SETTINGS 
        WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'swift.time.tx';
        
        IF ln_count = 0 THEN
            INSERT INTO CORPINT.TBL_CUSTOMER_SETTINGS (CUSTOMER_NO, SETTINGS_CD, SETTINGS_VALUE, UPDATED_DATE, UPDATED_USER)
            VALUES(ps_customerid, 'swift.time.tx',  UPPER(SUBSTR(ps_swift_specGroup, 1)), SYSDATE, USER);
        ELSE
            UPDATE CORPINT.TBL_CUSTOMER_SETTINGS
            SET SETTINGS_VALUE =UPPER(SUBSTR(ps_swift_specGroup, 1)), UPDATED_DATE=SYSDATE, UPDATED_USER=USER
            WHERE CUSTOMER_NO = ps_customerid AND SETTINGS_CD= 'swift.time.tx';
        END IF;
        
        EXCEPTION 
            WHEN OTHERS THEN
               Pkg_Log.AddCustomLog('swiftcib pkg_admin.SetSpecApproval', '1='||ps_customerid||'2='||ps_swift_specGroup, SQLERRM);
    END;
    /*EOM ChyngyzO cq509 17.03.15 */

    OPEN pc_ref FOR
        SELECT a.CUSTOMER_ID, a.CHANNEL_CD, a.TRAN_CD,t.DEFINITION,a.VERIFY, a.APPROVE,NVL(LTRIM(RTRIM(TO_CHAR(a.DAILY_LIMIT,'999G999G999G999G999'))),'0')
        FROM TBL_SPEC_APPROVAL_TRAN a,TBL_TRANSACTION t
        WHERE a.customer_id=ps_customerid
        AND a.CHANNEL_CD=ps_channelcd
        AND t.LANGUAGE_CD = 'ENG'
        AND t.TRAN_CD=a.TRAN_CD
        ORDER BY ORDER_ID;
        
    RETURN ls_returncode;

EXCEPTION
    WHEN TransactionError THEN
         RETURN ls_returncode;
    WHEN OTHERS THEN
         Pkg_Log.AddCustomLog(ps_amount,ps_rates,SQLERRM);
        RETURN '666';

END;
--------------------------------------------------------------------------------------
FUNCTION GetGnLimitInfo(pn_musteri_no IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER ;
    TransactionError EXCEPTION;
BEGIN

         SELECT COUNT(*)
        INTO ln_count
        FROM TBL_APPROVAL_TRAN_MAX_LIMIT a, TBL_TRANSACTION t
        WHERE t.TRAN_CD = a.TRAN_CD
          AND t.LANGUAGE_CD = 'ENG'
          AND a.CHANNEL_CD = 'cDKBCIB'
          AND a.customer_no = pn_musteri_no ;

     IF ln_count = 0
     THEN
       RAISE TransactionError;
     END IF;

     OPEN pc_ref FOR
       SELECT
         a.TRAN_CD,
         NVL(a.MAX_DAILY_LIMIT,0),
         a.CURRENCY_CODE,
         a.CHANNEL_CD,
         t.DEFINITION
        FROM TBL_APPROVAL_TRAN_MAX_LIMIT a, TBL_TRANSACTION t
        WHERE t.TRAN_CD = a.TRAN_CD
          AND t.LANGUAGE_CD = 'ENG'
          AND a.CHANNEL_CD = 'cDKBCIB'
          AND a.customer_no = pn_musteri_no ;

    RETURN ls_returncode;

EXCEPTION
   WHEN TransactionError THEN
     OPEN pc_ref FOR
     SELECT SYSDATE
     FROM dual;
     RETURN '131';
END;
-------------------------------
FUNCTION GetSpecGnLimitInfo(pn_musteri_no IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER ;
    TransactionError EXCEPTION;
BEGIN

         SELECT COUNT(*)
        INTO ln_count
        FROM TBL_SPECAPP_TRAN_MAX_LIMIT a, TBL_TRANSACTION t
        WHERE t.TRAN_CD = a.TRAN_CD
          AND t.LANGUAGE_CD = 'ENG'
          AND a.CHANNEL_CD = 'cDKBCIB'
          AND a.customer_no = pn_musteri_no ;

     IF ln_count = 0
     THEN
       RAISE TransactionError;
     END IF;

     OPEN pc_ref FOR
       SELECT
         a.TRAN_CD,
         NVL(a.MAX_DAILY_LIMIT,0),
         a.CURRENCY_CODE,
         a.CHANNEL_CD,
         t.DEFINITION
        FROM TBL_SPECAPP_TRAN_MAX_LIMIT a, TBL_TRANSACTION t
        WHERE t.TRAN_CD = a.TRAN_CD
          AND t.LANGUAGE_CD = 'ENG'
          AND a.CHANNEL_CD = 'cDKBCIB'
          AND a.customer_no = pn_musteri_no ;

    RETURN ls_returncode;

EXCEPTION
   WHEN TransactionError THEN
     OPEN pc_ref FOR
     SELECT SYSDATE
     FROM dual;
     RETURN '132';
END;
-------------------------------
FUNCTION SetGnLimitInfo(ps_trancd IN VARCHAR2,
                        ps_limit IN VARCHAR2,
                        ps_cycode IN VARCHAR2,
                        ps_tr IN VARCHAR2,
                        ps_customer IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    LimitErrorException     EXCEPTION;
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    UPDATE TBL_SPECAPP_TRAN_MAX_LIMIT
    SET  MAX_DAILY_LIMIT = TO_NUMBER(REPLACE(ps_limit,',',''),'99999999999999.9999'),
         CURRENCY_CODE   = ps_cycode
    WHERE channel_cd = 'cDKBCIB'
      AND TRAN_CD = ps_tr
      AND customer_no = ps_customer;

    RETURN ls_returncode;

EXCEPTION
         WHEN OTHERS THEN
               pkg_log.AddCustomLog('SetGnLimitInfo',sqlerrm);
               RETURN '050';
END;
-------------------------------
FUNCTION SetSpecGnLimitInfo(ps_trancd IN VARCHAR2,
                        ps_limit IN VARCHAR2,
                        ps_cycode IN VARCHAR2,
                        ps_tr IN VARCHAR2,
                        ps_customer IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    LimitErrorException     EXCEPTION;
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    UPDATE TBL_APPROVAL_TRAN_MAX_LIMIT
    SET  MAX_DAILY_LIMIT = TO_NUMBER(REPLACE(ps_limit,',',''),'99999999999999.9999'),
         CURRENCY_CODE   = ps_cycode
    WHERE channel_cd = 'cDKBCIB'
      AND TRAN_CD = ps_tr
      AND customer_no = ps_customer;

    RETURN ls_returncode;

EXCEPTION
         WHEN OTHERS THEN
               RETURN '050';
END;
---------------------------------------------------------------------------------------
FUNCTION SetUserAuthForAdminSite(ps_personid IN VARCHAR2,
                        ps_channelid     IN VARCHAR2,
                       ps_viewstr     IN VARCHAR2,
                       ps_makestr     IN VARCHAR2,
                       ps_verifystr     IN VARCHAR2,
                       ps_checkstr     IN VARCHAR2,
                       ps_approvestr IN VARCHAR2,
                       ps_makerid     IN VARCHAR2,
                       pn_amount     IN VARCHAR2,
                       pn_cust       IN VARCHAR2,
                       ps_cycode     IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         lim  NUMBER;
BEGIN
     DELETE FROM TBL_PERSON_AUTH
     WHERE person_id=TO_NUMBER(ps_personid)
     AND channel_cd=ps_channelid
     AND auth_cd NOT IN ('aAUTHORITY',REPLACE(ps_channelid,'c','a'));

     INSERT INTO TBL_PERSON_AUTH (person_id,channel_cd,auth_cd)
     SELECT TO_NUMBER(ps_personid),CHANNEL_CD,AUTH_CD FROM TBL_AUTHORITY
     WHERE channel_cd=ps_channelid
     AND auth_cd NOT IN ('aAUTHORITY',REPLACE(ps_channelid,'c','a'))
     AND INSTR(ps_viewstr ||','|| ps_makestr ||',' ,auth_cd||',')>0;

      DELETE FROM TBL_PERSON_APPROVAL
      WHERE person_id=TO_NUMBER(ps_personid)
     AND channel_cd=ps_channelid;

     INSERT INTO TBL_PERSON_APPROVAL (person_id,channel_cd,auth_cd)
     SELECT TO_NUMBER(ps_personid),CHANNEL_CD,AUTH_CD FROM TBL_AUTHORITY
     WHERE channel_cd=ps_channelid
     AND INSTR(ps_verifystr ||','|| ps_checkstr ||',' || ps_approvestr ||',' ,auth_cd||',')>0;

    --lim := TO_NUMBER(REPLACE(REPLACE(pn_amount,',',''),'.','.'));
    lim := TO_NUMBER(pn_amount,'99999999999.99');

      UPDATE TBL_COMPANY
     SET ISLEM_LIMIT = lim,
         ISLEM_LIMIT_CY = ps_cycode
     WHERE CUSTOMER_NO = pn_cust
       AND PERSON_ID   = ps_personid;

     OPEN pc_ref FOR
           SELECT 'OK' FROM dual;

     RETURN ls_returncode;

END;
-----------------------------------------------------------------------------------
FUNCTION SetSpecUserAuthForAdminSite(ps_personid IN VARCHAR2,
                        ps_channelid     IN VARCHAR2,
                       ps_viewstr     IN VARCHAR2,
                       ps_makestr     IN VARCHAR2,
                       ps_verifystr     IN VARCHAR2,
                       ps_checkstr     IN VARCHAR2,
                       ps_approvestr IN VARCHAR2,
                       ps_makerid     IN VARCHAR2,
                       pn_amount     IN VARCHAR2,
                       pn_cust       IN VARCHAR2,
                       ps_cycode     IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_statement VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         lim  NUMBER;
BEGIN
     DELETE FROM TBL_PERSON_AUTH
     WHERE person_id=TO_NUMBER(ps_personid)
     AND channel_cd=ps_channelid
     AND auth_cd NOT IN ('aAUTHORITY',REPLACE(ps_channelid,'c','a'));

     INSERT INTO TBL_PERSON_AUTH (person_id,channel_cd,auth_cd)
     SELECT TO_NUMBER(ps_personid),CHANNEL_CD,AUTH_CD FROM TBL_AUTHORITY
     WHERE channel_cd=ps_channelid
     AND auth_cd NOT IN ('aAUTHORITY',REPLACE(ps_channelid,'c','a'))
     AND INSTR(ps_viewstr ||','|| ps_makestr ||',' ,auth_cd||',')>0;

      DELETE FROM TBL_PERSON_APPROVAL
      WHERE person_id=TO_NUMBER(ps_personid)
     AND channel_cd=ps_channelid;

     INSERT INTO TBL_PERSON_APPROVAL (person_id,channel_cd,auth_cd)
     SELECT TO_NUMBER(ps_personid),CHANNEL_CD,AUTH_CD FROM TBL_AUTHORITY
     WHERE channel_cd=ps_channelid
     AND INSTR(ps_verifystr ||','|| ps_checkstr ||',' || ps_approvestr ||',' ,auth_cd||',')>0;

    --lim := TO_NUMBER(REPLACE(REPLACE(pn_amount,',',''),'.','.'));
    lim := TO_NUMBER(pn_amount,'99999999999.99');

      UPDATE TBL_SPEC_COMPANY
     SET ISLEM_LIMIT = lim,
         ISLEM_LIMIT_CY = ps_cycode
     WHERE CUSTOMER_NO = pn_cust
       AND PERSON_ID   = ps_personid;

     OPEN pc_ref FOR
           SELECT 'OK' FROM dual;

     RETURN ls_returncode;

END;
-----------------------------------------------------------------------------------
FUNCTION GetVerifyApproveToDo(ps_customerID IN VARCHAR2,
                        ps_channelCD IN VARCHAR2,
                        ps_PersonID IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    -- once tum datalara bak?p sdone v scanceled olmayan tum datalar?
    -- al?p 1 gun gecmis ise siliyorum boylece aylarca bekletmiyorum
    --    statusunu de sREMOVE yap?yorum
    UPDATE TBL_TXTODO T
    SET T.STATUS='sEXPIRED'
    WHERE Pkg_Customer.GetCustomerID(T.MAKERID) = ps_customerID
    AND TO_DATE(FIELD3,'YYYYMMDD') < TRUNC(SYSDATE)
    AND TRANCD='CLEARING'
    AND ( (t.STATUS ='sVERIFY') OR (t.STATUS ='sCHECK') OR (t.STATUS ='sAPPROVE'));

    OPEN pc_ref FOR
    SELECT
       t.TX_NO,
       DECODE(T.TRANCD,'CLEARING',FIELD3,'CLEARCNCL',FIELD3,TO_CHAR(t.MAKEDATE,'YYYYMMDD')) TRAN_DATE,
       t.MAKERID,
       Pkg_Customer.GetPersonName(t.MAKERID),
       r.DEFINITION,
       t.STATUS,
       LTRIM(DECODE(T.TRANCD,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3,' '), '0') AMOUNT,
       DECODE(T.TRANCD,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,' ') CURRENCY,
       DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ',' ') PAYEE_NAME
    FROM TBL_TXTODO T,TBL_PERSON_APPROVAL A,TBL_TRANSACTION R
    WHERE
    Pkg_Customer.GetCustomerID(T.MAKERID)=ps_customerID AND
    A.PERSON_ID = TO_NUMBER(ps_PersonID) AND
    T.STATUS IN ('sAPPROVE','sVERIFY','sCHECK') AND
    A.CHANNEL_CD = ps_channelCD  AND
    A.AUTH_CD= T.AUTHCD AND
    r.LANGUAGE_CD = 'ENG' AND
    t.TRANCD = r.TRAN_CD;

    RETURN ls_returncode;

  EXCEPTION
    WHEN OTHERS THEN
         RETURN '999';
END;
----------------------------------------------------------------------------------------
FUNCTION GetVerifyApproveTranInfo(ps_txNo IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         ls_returncode  VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    OPEN pc_ref FOR
    SELECT
        NVL(Pkg_Customer.GetPersonName(MAKERID),' '),
        t.TX_NO,
        NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') ,
        t.AUTHCD,
        DECODE(T.TRANCD,'CLEARING',FIELD3,'CLEARCNCL',FIELD3,TO_CHAR(t.MAKEDATE,'YYYYMMDD')) TRAN_DATE,
        t.MAKERID,
        t.STATUS,
        r.DEFINITION,
        t.TRANCD,
        NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' '),
        t.VERIFYID,
        NVL(t.FIELD1,' '),
        NVL(t.FIELD2,' '),
        NVL(t.FIELD3,' '),
        NVL(t.FIELD4,' '),
        NVL(t.FIELD5,' '),
        NVL(t.FIELD6,' '),
        NVL(t.FIELD7,' '),
        NVL(t.FIELD8,' '),
        NVL(t.FIELD9,' '),
        NVL(t.FIELD10,' '),
        NVL(t.FIELD11,' '),
        NVL(t.FIELD12,' '),
        NVL(t.FIELD13,' '),
        NVL(t.FIELD14,' '),
        NVL(t.FIELD15,' '),
        NVL(t.FIELD16,' '),
        NVL(t.FIELD17,' '),
        NVL(t.FIELD18,' '),
        NVL(t.FIELD19,' '),
        NVL(t.FIELD20,' '),
        NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' '),
        NVL(Pkg_Customer.GetPersonName(t.CHECKID),' '),
        NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' '),
        NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' '),
        t.CHECKID,
        DECODE(T.TRANCD,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3,' ') AMOUNT,
        DECODE(T.TRANCD,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,' ')CURRENCY,
        DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ',' ')PAYEE_NAME,
        Pkg_Customer.GetCustomerID(MAKERID) CUSTOMERID
        FROM TBL_TXTODO t, TBL_TRANSACTION R
        WHERE INSTR(DECODE(ps_txNo,'ALL',',' || TO_CHAR(t.TX_NO) || ',',ps_txNo), ',' || TO_CHAR(t.TX_NO) || ',')>0
        AND t.TRANCD = r.TRAN_CD
        AND r.LANGUAGE_CD = 'ENG';

    RETURN ls_returncode;
  EXCEPTION
    WHEN OTHERS THEN
         RETURN '999';
END;
-------------------------------------------------------------
FUNCTION GetAuthCodesLimit( ps_channelcd IN VARCHAR2,
                        ps_customer_id    IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN
 OPEN pc_ref FOR
      SELECT
        ISLEM_LIMIT,
        ISLEM_LIMIT_CY,
        IMZA_SIRKULERI_IMZA_LIMIT,
        IMZA_SIRKULERI_CY
     FROM TBL_COMPANY
     WHERE CUSTOMER_NO = ps_customer_id
       AND PERSON_ID   = ps_personid;

 RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------------------
FUNCTION GetSpecAuthCodesLimit(ps_channelcd IN VARCHAR2,
                        ps_customer_id    IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
BEGIN
 OPEN pc_ref FOR
      SELECT
        ISLEM_LIMIT,
        ISLEM_LIMIT_CY,
        IMZA_SIRKULERI_IMZA_LIMIT,
        IMZA_SIRKULERI_CY
     FROM TBL_SPEC_COMPANY
     WHERE CUSTOMER_NO = ps_customer_id
       AND PERSON_ID   = ps_personid;

 RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------------------
FUNCTION NeedApprove( ps_customer_id    IN VARCHAR2,
                       ps_tran IN VARCHAR2,
                      ps_controlstr IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    TransactionError EXCEPTION;
    ls_auths VARCHAR2(2000);
    ls_returncode  VARCHAR2(3):='000';
    l_c     VARCHAR2(1) ;
    l_v     VARCHAR2(1) ;
    l_a     VARCHAR2(1) ;
    l_ret   VARCHAR2(10) ;
    l_currencycontrol     VARCHAR2(1):='N';
BEGIN
    IF ps_tran='CLEARING' THEN
       IF SUBSTR(ps_controlstr,1,1)='2' OR SUBSTR(ps_controlstr,3,1)='2' THEN
             l_currencycontrol:='Y';
       END IF;
    ELSIF ps_tran='EXCHNGBUY' THEN
          l_currencycontrol:='Y';
    END IF;

    SELECT VERIFY,CHECKER,APPROVE
    INTO l_v,l_c,l_a
    FROM TBL_APPROVAL_TRAN
    WHERE CUSTOMER_ID = ps_customer_id
    AND TRAN_CD  = ps_tran ;

    IF l_v = 'Y' THEN
             l_ret := 'sVERIFY';
    ELSIF l_c = 'Y' THEN
          l_ret := 'sCHECK';
    ELSIF l_a = 'Y' THEN
          l_ret := 'sAPPROVE';
    ELSIF l_currencycontrol='Y' THEN
          l_ret := 'sCONTROL';
    ELSE
          l_ret := 'sMAKE';
    END IF;

 OPEN pc_ref FOR     SELECT l_ret FROM dual;

 RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '707';
END;
-----------------------------------------------------------------------------------
FUNCTION GetLimitInfo( ps_channelcd IN VARCHAR2,
                        ps_customerid    IN VARCHAR2,
                        ps_personid    IN VARCHAR2,
                        ps_langid    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         ln_isPresent NUMBER:=0;
BEGIN

    IF ps_channelcd='cDKBRIB' THEN

        OPEN pc_ref FOR
          SELECT t.DEFINITION,
                   d.DAILY_LIMIT,
                   d.CURRENCY_CODE,
                 Pkg_Limit.GetUsedLimit(NULL,ps_personid,d.TRAN_CD,d.CHANNEL_CD) used,
                 d.ONETIME_LIMIT
                FROM TBL_LIMIT_DEFAULTS d,TBL_TRANSACTION t
                WHERE d.TRAN_CD=t.TRAN_CD
                AND d.CHANNEL_CD=ps_channelcd
                AND t.LANGUAGE_CD=ps_langid
                AND d.PERSON_ID=ps_personid
                ORDER BY 1;


    ELSE--cDKBCIB

        OPEN pc_ref FOR
            SELECT
                p.FIRSTNAME || p.MIDDLENAME || p.LASTNAME USERNAME,
                a.TRAN_CD,    t.DEFINITION,c.ISLEM_LIMIT,    c.ISLEM_LIMIT_CY, a.DAILY_LIMIT,a.LIMIT_CURRENCY,
                DECODE(a.LIMIT_DATE,TO_CHAR(SYSDATE,'yyyymmdd'),NVL(a.USED_LIMIT,0),0) used
                FROM TBL_APPROVAL_TRAN a,TBL_TRANSACTION t,TBL_COMPANY c, TBL_PERSON p
                WHERE a.customer_id=ps_customerid
                AND a.CHANNEL_CD=ps_channelcd
                AND t.LANGUAGE_CD = ps_langid
                AND t.TRAN_CD=a.TRAN_CD
                AND c.customer_no = ps_customerid
                AND c.customer_no = a.customer_id
                AND c.person_id = ps_personid
                AND p.customer_id = a.customer_id
                AND p.person_id = c.person_id
                ORDER BY a.ORDER_ID;

     END IF;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------------------------
FUNCTION CnclSuperUser(ps_chanelcd    IN VARCHAR2,
                       ps_personid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
            ls_count NUMBER := 0;
            ls_returncode VARCHAR2(3):='000';
BEGIN
         OPEN pc_ref FOR
         SELECT SYSDATE FROM dual;

         SELECT COUNT(*)
         INTO ls_count
         FROM TBL_PERSON_AUTH t
         WHERE t.CHANNEL_CD=ps_chanelcd AND
         t.PERSON_ID=TO_NUMBER(ps_personid)
         AND t.AUTH_CD='aAUTHORITY';

         IF (ls_count = 0) THEN
               ls_returncode:='332';
         ELSE
             DELETE
             FROM TBL_PERSON_AUTH
             WHERE PERSON_ID  = TO_NUMBER(ps_personid)
               AND CHANNEL_CD = ps_chanelcd
               AND AUTH_CD    = 'aAUTHORITY';
         END IF;
         RETURN ls_returncode;
EXCEPTION
              WHEN NO_DATA_FOUND THEN
             ls_returncode:='331';--alias found
             RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------
FUNCTION GetVerifyApproveControlToDo(ps_statuscd IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         ls_returncode  VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        SELECT
            t.TX_NO,
            TO_CHAR(t.MAKEDATE,'YYYYMMDD'),
            t.MAKERID,
            Pkg_Customer.GetPersonName(t.MAKERID),
            r.DEFINITION,
            t.STATUS,
            DECODE(T.TRANCD,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3,' ') AMOUNT,
            DECODE(T.TRANCD,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,' ')CURRENCY,
            DECODE(T.TRANCD,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ',' ')PAYEE_NAME
        FROM TBL_TXTODO T,TBL_TRANSACTION R
        WHERE
            T.STATUS ='sCONTROL' AND
            r.LANGUAGE_CD = 'ENG' AND
            t.TRANCD = r.TRAN_CD;

    RETURN ls_returncode;

  EXCEPTION
    WHEN OTHERS THEN
         RETURN '999';
END;

------------------------------------------------------------------------------------------
FUNCTION CheckCurrencyControl(ps_channelcd     IN VARCHAR2,
                               ps_customer_id    IN VARCHAR2,
                               ps_tran IN VARCHAR2,
                              ps_controlstr IN VARCHAR2,
                              ps_currencycd IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    TransactionError EXCEPTION;
    ls_auths VARCHAR2(2000);
    ls_returncode  VARCHAR2(3):='000';
    l_c     VARCHAR2(1) ;
    l_v     VARCHAR2(1) ;
    l_a     VARCHAR2(1) ;
    l_ret   VARCHAR2(10) ;
    l_currencycontrol     VARCHAR2(1):='N';
BEGIN

    IF ps_tran='CLEARING' THEN
       IF SUBSTR(ps_controlstr,1,1)='2' OR SUBSTR(ps_controlstr,3,1)='2' THEN
             l_currencycontrol:='Y';
       END IF;
    ELSIF ps_tran='EXCHNGBUY' THEN
          l_currencycontrol:='N';
    ELSIF ps_tran='B2OBHVL' THEN
       IF SUBSTR(ps_controlstr,1,1)='2' OR SUBSTR(ps_controlstr,3,1)='2' THEN
             l_currencycontrol:='Y';
       END IF;
    END IF;

    IF l_currencycontrol='Y' THEN
          l_ret := 'sCONTROL';
          ls_returncode:='606';
    ELSE
          l_ret := 'sMAKE';
          ls_returncode:='000';
    END IF;

    OPEN pc_ref FOR     SELECT l_ret FROM dual;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '707';
END;
----------------------------------------------------------------------------------------
FUNCTION GetRetailLimits(ps_ChannelCd IN VARCHAR2,
                             ps_CustomerId    IN VARCHAR2,
                         ps_LangId    IN VARCHAR2,
                             pc_Ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_auths VARCHAR2(2000);
         ls_returncode  VARCHAR2(3):='000';
         ln_isPresent NUMBER:=0;
BEGIN

    SELECT COUNT(*)
    INTO ln_isPresent
    FROM TBL_LIMIT_DEFAULTS a
    WHERE a.PERSON_ID=Pkg_Customer.GetPersonID(ps_CustomerId, ps_ChannelCd)
    AND a.CHANNEL_CD=ps_ChannelCd;

    --pkg_log.AddCustomLog(ps_customerid,ps_channelcd,ln_isPresent);

    OPEN pc_ref FOR
        SELECT
        a.PERSON_ID,
        a.CHANNEL_CD,
        a.TRAN_CD,
        Pkg_Common.GetTranDescription(a.TRAN_CD,ps_LangId),
        NVL(LTRIM(RTRIM(TO_CHAR(a.DAILY_LIMIT))),'0'),
        a.ONETIME_LIMIT,
        a.CURRENCY_CODE
        FROM TBL_LIMIT_DEFAULTS a
        WHERE a.PERSON_ID=Pkg_Customer.GetPersonID(ps_Customerid, ps_ChannelCd)
        AND a.CHANNEL_CD=ps_ChannelCd;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
         RETURN '666';
END;
-----------------------------------------------------------------------------------------
FUNCTION SetRetailLimits(ps_ChannelCd IN VARCHAR2,
                             ps_CustomerId    IN VARCHAR2,
                         ps_Amount    IN VARCHAR2,
                         ps_TranLimit IN VARCHAR2,
                         ps_Currency     IN VARCHAR2,
                         ps_TranCd IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         TransactionError EXCEPTION;
         ls_returncode  VARCHAR2(3):='000';
         i              NUMBER:=1;
         ln_trancount  NUMBER:=9;
BEGIN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    WHILE i<ln_trancount
    LOOP
        UPDATE TBL_LIMIT_DEFAULTS
        SET
            DAILY_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_Amount,';',i-1),'99999999999.99'),0),
            ONETIME_LIMIT=NVL(TO_NUMBER(Pkg_Admin.SPLIT(ps_TranLimit,';',i-1),'99999999999.99'),0),
            CURRENCY_CODE = Pkg_Admin.SPLIT(ps_Currency,';',i-1)
        WHERE channel_cd=ps_ChannelCd
        AND PERSON_ID=Pkg_Customer.GetPersonID(ps_CustomerId, ps_ChannelCd)
        AND TRAN_CD=Pkg_Admin.SPLIT(ps_TranCd,';',i-1);

        i:=i+1;

    END LOOP;

    RETURN ls_returncode;

EXCEPTION
    WHEN TransactionError THEN
         RETURN ls_returncode;
    WHEN OTHERS THEN
         Pkg_Log.AddCustomLog(ps_Amount,ps_TranLimit,SQLERRM);
        RETURN '666';

END;
--------------------------------------------------------------------------------
FUNCTION GetFxAccess(ps_customerno IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         ls_returncode  VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
     SELECT flag FROM TBL_FXTRANSFER
     WHERE customer_id=TO_NUMBER(ps_customerno);

    RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------
FUNCTION GetFxAccessControl(ps_customerno IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

         ls_returncode  VARCHAR2(3):='000';
         ls_flag VARCHAR2(1);
         TransactionError EXCEPTION;
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM  dual;

    SELECT flag INTO ls_flag FROM TBL_FXTRANSFER
    WHERE customer_id=TO_NUMBER(ps_customerno);

    IF ls_flag='N' THEN
       RAISE TransactionError;
    END IF;

    RETURN ls_returncode;

    EXCEPTION
    WHEN TransactionError THEN
         ls_returncode:='030';
    RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------
FUNCTION GetPassIDInquiry(ps_customerid IN VARCHAR2,
                                           ps_passid IN VARCHAR2,
                                            pd_startdate       IN VARCHAR2,
                                           pd_enddate      IN VARCHAR2,
                                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN
         OPEN pc_ref FOR
                 SELECT PASSID,
                          --ASSIGNEDTO,
                        Pkg_Admin.GetPersonName(t.PERSON_ID),
                        C.DEFINITION,
                        t.STATUS_CD,
                        TO_CHAR(ASSIGNDATE,'YYYYMMDD'),
                        Pkg_Admin.GetPersonName(ASSIGNEDBY)
                 FROM TBL_DUMMY_PASSID p, TBL_IDENTIFICATION t, TBL_CHANNEL C
                 WHERE p.USERNAME=t.USERNAME
                 AND C.CHANNEL_CD=t.CHANNEL_CD
                 AND p.ASSIGNEDTO=NVL(ps_customerid,p.ASSIGNEDTO)
                 AND p.PASSID=TO_NUMBER(NVL(ps_passid,p.PASSID))
                 AND p.ASSIGNDATE BETWEEN TO_DATE(pd_startdate,'YYYYMMDD') AND TO_DATE(pd_enddate||' 235959','YYYYMMDD HH24MISS')
                 ORDER BY PASSID;

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------
FUNCTION GetUserInfosCR(ps_customerid IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

     ls_statement  VARCHAR2(2000);
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR
          SELECT
               p.PERSON_ID,
               p.FIRSTNAME ||' '|| p.MIDDLENAME ||' '|| p.LASTNAME AS UNVAN,
               p.CUSTOMER_ID,
               Pkg_Admin.GetSuperStatus(p.PERSON_ID)
        FROM TBL_PERSON p,TBL_IDENTIFICATION i
        WHERE p.PERSON_ID=i.PERSON_ID
        AND customer_id=TO_NUMBER(ps_customerid)
        AND p.status_cd='sENAB' AND i.status_cd='sENAB'
        AND i.CHANNEL_CD in ('cDKBRIB','cDKBCIB');

     RETURN ls_returncode;

EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;
-------------------------------------------------------------------------------

FUNCTION getActivityPersonInfo(ps_activity_nbr IN NUMBER) RETURN VARCHAR2 IS
  ls_returnval VARCHAR2(2000);
  ld_actv_time date;
  ln_actv_nbr NUMBER;
  ls_ipaddress varchar2(15):='000.000.000.000';
BEGIN
  begin
      select nvl(trim(xx.firstname||' '||xx.middlename||' '||xx.lastname)||'###'||xx.CUSTOMER_ID||'###'||xx.PERSON_ID||'###'||rr.USERNAME||' ('||rr.USERALIAS||')###','UNKNOWN')
      into ls_returnval
      from corpint.tbl_identification rr, corpint.tbl_person xx, corpint.tbl_activity aa
      where rr.person_id=xx.person_id and (rr.USERALIAS=aa.FIELD1 or  rr.USERNAME=aa.FIELD1)
      and aa.ACTV_NBR=ps_activity_nbr
      and rownum=1;

      RETURN ls_returnval;
  exception
    when others then
        ls_returnval:=null;
  end;

  if ls_returnval is null then
      select ACTV_TIME, CLIENT_IP_ADDRESS into ld_actv_time, ls_ipaddress
      from corpint.tbl_activity
      where actv_nbr=ps_activity_nbr;

      select ACTV_NBR, FIELD1 into ln_actv_nbr, ls_returnval
      from corpint.tbl_activity
      where actv_time between ld_actv_time - interval '01' minute and ld_actv_time
      and CLIENT_IP_ADDRESS=ls_ipaddress
      and TRAN_CD like '%LOGON%'
      and length(FIELD1)>0
      and rownum=1;

      select nvl(trim(xx.firstname||' '||xx.middlename||' '||xx.lastname)||'###'||xx.CUSTOMER_ID||'###'||xx.PERSON_ID||'###'||rr.USERNAME||' ('||rr.USERALIAS||')###','UNKNOWN')
      into ls_returnval
      from corpint.tbl_identification rr, corpint.tbl_person xx, corpint.tbl_activity aa
      where rr.person_id=xx.person_id and (rr.USERALIAS=aa.FIELD1 or  rr.USERNAME=aa.FIELD1)
      and aa.ACTV_NBR=ln_actv_nbr
      and rownum=1;
  end if;

  RETURN ls_returnval;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
     RETURN ls_returnval;
END;

FUNCTION getuserinfo (ps_channelcd     IN       VARCHAR2,
                      ps_customer_id   IN       VARCHAR2,
                      ps_personid      IN       VARCHAR2,
                      ps_username      IN       VARCHAR2,
                      ps_useralias     IN       VARCHAR2,
                      ps_status        IN       VARCHAR2,
                      pc_ref           OUT      cursorreferencetype) RETURN VARCHAR2 IS
  ls_returncode   VARCHAR2 (3) := '000';
BEGIN
  OPEN pc_ref FOR
     SELECT i.channel_cd, i.person_id, i.username,
            NVL (i.useralias, '---'), i.attempt_count,
            NVL (i.token_id, '-'), 'N', i.status_cd,
            p.firstname || ' ' || p.lastname, p.customer_id
      FROM tbl_identification i, tbl_person p
      WHERE i.person_id = p.person_id
        AND p.person_id = NVL (ps_personid, p.person_id)
        AND i.username = NVL (ps_username, i.username)
        AND NVL (i.useralias, '-') LIKE '%' || NVL (ps_useralias, NVL (i.useralias, '-')) || '%'
        AND i.channel_cd = NVL (ps_channelcd, i.channel_cd)
        AND p.customer_id = NVL (ps_customer_id, p.customer_id)
        AND i.status_cd = NVL (ps_status, i.status_cd);

  RETURN ls_returncode;
END;

FUNCTION getuserauthinfo (ps_customer_id   IN       VARCHAR2,
                          ps_personid      IN       VARCHAR2,
                          ps_name          IN       VARCHAR2,
                          pc_ref           OUT      cursorreferencetype) RETURN VARCHAR2 IS
  ls_returncode   VARCHAR2 (3) := '000';
BEGIN
  OPEN pc_ref FOR
     SELECT DISTINCT p.person_id, p.channel_cd, p.auth_cd,
                     a.firstname || ' ' || a.lastname, a.customer_id,
                     getauthname (p.auth_cd)
                FROM tbl_person_auth p, tbl_person a
               WHERE p.person_id = a.person_id
                 AND a.person_id = NVL (ps_personid, a.person_id)
                 AND a.customer_id = NVL (ps_customer_id, a.customer_id)
                 AND a.firstname || ' ' || a.lastname LIKE '%' || NVL (ps_name, a.firstname || ' ' || a.lastname) || '%';

  RETURN ls_returncode;
END;

FUNCTION gettrancd (ps_authcd IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
  ls_returncode   VARCHAR2 (3) := '000';
BEGIN
  OPEN pc_ref FOR
     SELECT DISTINCT t.tran_cd, t.auth_cd, getauthname (p.auth_cd),
                     gettranname (t.tran_cd)
                FROM tbl_person_auth p, tbl_auth_tran t
               WHERE p.auth_cd = t.auth_cd
                 AND t.auth_cd = NVL (ps_authcd, t.auth_cd);

  RETURN ls_returncode;
END;

FUNCTION getauthname (ps_authcd IN VARCHAR2) RETURN VARCHAR2 IS
  ls_returncode   VARCHAR2 (3)   := '000';
  ls_authdesc     VARCHAR2 (200);
BEGIN
  SELECT auth_desc
    INTO ls_authdesc
    FROM tbl_authority
   WHERE auth_cd = ps_authcd
   AND rownum=1;

  RETURN ls_authdesc;
END;

FUNCTION gettranname (ps_trancd IN VARCHAR2) RETURN VARCHAR2 IS
  ls_returncode   VARCHAR2 (3)   := '000';
  ls_trandesc     VARCHAR2 (200);
BEGIN
  SELECT definition
    INTO ls_trandesc
    FROM tbl_transaction
   WHERE tran_cd = ps_trancd
   AND rownum=1;

  RETURN ls_trandesc;
END;

Function Statics(ps_chanelcd in varchar2,
                 ps_queryno  in varchar2,
                 pc_ref      out CursorReferenceType) return varchar2 IS
     ls_returncode          varchar2(3):='000';
BEGIN

    IF (ps_queryno = 1) THEN -- son 10 kullan?c?
        --  query 1
        open pc_ref for
        SELECT
          rownum,kullanici_adi,fullname,login_time,method,kanal_adi
        FROM
          (
            SELECT
            nvl(i.USERALIAS,i.USERNAME) kullanici_adi,
            p.FIRSTNAME||' '||P.MIDDLENAME||' '||P.LASTNAME fullname,
            a.DLM login_time,
            decode(a.TRAN_CD,'LOGON','Username + Password','TLOGON','E-Token','Username') method,
            decode(a.CHANNEL_CD,'cDKBRIB','Retail','cDKBCIB','Corporate','cCORPADM','Admin','-') kanal_adi
            from tbl_activity a, tbl_identification i,tbl_person p
            where
            (a.TRAN_CD = 'LOGON'  or
             a.TRAN_CD = 'TLOGON')
            and session_id <> 0
            and a.PERSON_ID <> 0
            and error_cd ='000'
            and a.PERSON_ID = i.PERSON_ID
            and i.PERSON_ID = p.PERSON_ID
            and i.CHANNEL_CD = ps_chanelcd
            order by a.ACTV_NBR desc
          )
        where rownum < 11;
        -- query 1
    ELSIF (ps_queryno = 0) THEN
        OPEN pc_ref FOR
        SELECT
        toplam_kullanici_sayisi,
        aktif_kullanici_sayisi,
        son_bir_aylik_logon,
        son_bir_haftalik_logon,
        o_gunku_logon,
        normal_hata_sayisi,
        sistem_hata_sayisi,
        round((normal_hata_sayisi/(normal_hata_sayisi+sistem_hata_sayisi))*100),
        aylik_distinct_logon,
        haftalik_distinct_logon,
        gunku_distinct_logon
        FROM
        (
        SELECT
          (   SELECT COUNT (*)
                from tbl_person f ,tbl_identification t
                where f.PERSON_ID = t.PERSON_ID
                AND t.CHANNEL_CD = ps_chanelcd
                and customer_id IN (SELECT musteri_no
                                      FROM cbs_musteri
                                     WHERE
                                      musteri_tipi_kod = DECODE(ps_chanelcd,'cDKBRIB','G','cCORPADM','G','K')
                                      or musteri_tipi_kod = DECODE(ps_chanelcd,'cDKBRIB','G','cCORPADM','G','T')))
               toplam_kullanici_sayisi,

            (
            SELECT COUNT (*)
            from tbl_person f ,tbl_identification t
            where f.PERSON_ID = t.PERSON_ID
            AND t.CHANNEL_CD = ps_chanelcd
            AND t.status_cd = 'sENAB'
            AND f.status_cd = 'sENAB'
            and customer_id IN (SELECT musteri_no
                                  FROM cbs_musteri
                                 WHERE
                                      musteri_tipi_kod = DECODE(ps_chanelcd,'cDKBRIB','G','cCORPADM','G','K')
                                      or musteri_tipi_kod = DECODE(ps_chanelcd,'cDKBRIB','G','cCORPADM','G','T')))
              aktif_kullanici_sayisi,

             (  select count(*) from tbl_session a
                where a.CHANNEL_CD = ps_chanelcd
                and trunc(a.DLM)>=sysdate-30
                and trunc(a.DLM)<=sysdate+1) son_bir_aylik_logon,

             (  select count(*) from tbl_session a
                where a.CHANNEL_CD = ps_chanelcd
                and trunc(a.DLM)>=sysdate-7
                and trunc(a.DLM)<=sysdate+1) son_bir_haftalik_logon,

             (  select count(*) from tbl_session a
                where a.CHANNEL_CD = ps_chanelcd
                and trunc(a.DLM) = trunc(sysdate)) o_gunku_logon,

            (select count(*) from  tbl_activity
             where CHANNEL_CD = ps_chanelcd
             and error_cd <> '999')  normal_hata_sayisi,

            (select count(*) from  tbl_activity
             where CHANNEL_CD = ps_chanelcd
             and error_cd = '999') sistem_hata_sayisi,

             (select count(distinct person_id) from tbl_session a
              where a.CHANNEL_CD = ps_chanelcd
              and trunc(a.DLM)>=sysdate-30
              and trunc(a.DLM)<=sysdate+1) aylik_distinct_logon,

             (select count(distinct person_id) from tbl_session a
              where a.CHANNEL_CD = ps_chanelcd
              and trunc(a.DLM)>=sysdate-7
              and trunc(a.DLM)<=sysdate+1) haftalik_distinct_logon,

             (select count(distinct person_id) from tbl_session a
              where a.CHANNEL_CD = ps_chanelcd
              and trunc(a.DLM) = trunc(sysdate)) gunku_distinct_logon

        FROM DUAL
        );

    ELSIF (ps_queryno = 2) THEN
            OPEN pc_ref FOR
            SELECT rownum,islem,sayi
            FROM
            (
            SELECT
             t.definition islem,
             count(person_id) sayi
            FROM tbl_activity a,tbl_error e, tbl_transaction t
            WHERE (trunc(actv_time)>=sysdate-30 and trunc(actv_time)<=sysdate+1)
                AND a.channel_cd = ps_chanelcd    AND a.ERROR_CD=e.ERROR_CD
                AND a.SYSTEM_CD=e.SYSTEM_CD    AND e.LANG_CD='ENG'
                AND t.TRAN_CD=a.tran_cd    AND a.PAGE_ID = 0
                AND a.ERROR_CD ='000' and T.LANGUAGE_CD='ENG'
            GROUP BY t.definition
            ORDER BY count(a.person_id) desc
            ) WHERE rownum < 11;

    ELSIF (ps_queryno = 3) THEN
            OPEN pc_ref FOR
            SELECT rownum,islem,sayi
            FROM
            (
            SELECT
             t.definition islem,
             count(person_id) sayi
            FROM tbl_activity a,tbl_error e, tbl_transaction t
            WHERE a.channel_cd = ps_chanelcd AND a.ERROR_CD=e.ERROR_CD
                AND a.SYSTEM_CD=e.SYSTEM_CD    AND e.LANG_CD='ENG'
                AND t.TRAN_CD=a.tran_cd    AND a.PAGE_ID = 0
                AND a.ERROR_CD ='000' and T.LANGUAGE_CD='ENG'
            GROUP BY t.definition
            ORDER BY count(a.person_id) desc
            ) WHERE rownum < 11;

    ELSIF (ps_queryno = 4) THEN

            OPEN pc_ref FOR
            SELECT rownum,TO_CHAR(dlmm,'DD.MM.YYYY'),hit from
            (
             SELECT
             trunc(dlm) dlmm,
             count(*) hit
             FROM tbl_session
             where channel_cd = ps_chanelcd
             group by trunc(dlm)
             order by trunc(dlm) desc
             )where rownum < 31 ;

      ELSIF (ps_queryno = 5) THEN
            OPEN pc_ref FOR
            SELECT
            SUM(T.AMOUNT) miktar,
            GetTranName(T.TRAN_CD)
            FROM
            TBL_ACTIVITY T
            WHERE T.AMOUNT IS NOT NULL
            AND T.CURRENCY IS NOT NULL
            AND CURRENCY = 'KGS'
            AND T.DLM between sysdate-30 and sysdate
            AND T.CHANNEL_CD = ps_chanelcd
            AND error_cd='000'
            and t.PAGE_ID='0'
            GROUP BY T.TRAN_CD
            order by miktar desc;
      ELSIF (ps_queryno = 6) THEN
            OPEN pc_ref FOR
            SELECT
            SUM(T.AMOUNT) miktar,
            GetTranName(T.TRAN_CD)
            FROM
            TBL_ACTIVITY T
            WHERE T.AMOUNT IS NOT NULL
            AND T.CURRENCY IS NOT NULL
            AND CURRENCY = 'USD'
            AND T.DLM between sysdate-30 and sysdate
            AND T.CHANNEL_CD = ps_chanelcd
            AND error_cd='000'
            and t.PAGE_ID='0'
            GROUP BY T.TRAN_CD
            order by miktar desc;
      ELSIF (ps_queryno = 7) THEN
            OPEN pc_ref FOR
            SELECT
            SUM(T.AMOUNT) miktar,
            GetTranName(T.TRAN_CD)
            FROM
            TBL_ACTIVITY T
            WHERE T.AMOUNT IS NOT NULL
            AND T.CURRENCY IS NOT NULL
            AND CURRENCY = 'EUR'
            AND T.DLM between sysdate-30 and sysdate
            AND T.CHANNEL_CD = ps_chanelcd
            AND error_cd='000'
            and t.PAGE_ID='0'
            GROUP BY T.TRAN_CD
            order by miktar desc;
    END IF;

     return ls_returncode;

exception
        when others then
        pkg_log.AddCustomLog('Statics',sqlerrm);
        return '999';
END;

FUNCTION GetDebugLog(ps_startdate IN  VARCHAR2,
                     ps_enddate   IN  VARCHAR2,
                     pc_ref       OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode   VARCHAR2 (3) := '000';
BEGIN
  OPEN pc_ref FOR
     SELECT   d1, d2, d3, d4, yarat_tarih, yaratan
        FROM cbs_debug_log
        WHERE TRUNC (yarat_tarih) BETWEEN TO_DATE (ps_startdate, 'yyyymmdd') AND TO_DATE (ps_enddate, 'yyyymmdd')
        AND yaratan = 'CINT_CALLER'
        ORDER BY yarat_tarih;

  RETURN ls_returncode;
END;

FUNCTION baglantirpr(ps_dummy IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_count        NUMBER       := 0;
    ls_returncode   VARCHAR2 (3) := '000';
BEGIN
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

    OPEN pc_ref FOR
        SELECT *
        FROM (SELECT   NVL (b.useralias, b.username),
             TO_CHAR (a.activity_date, 'YYYYMMDD') tarih,
             a.person_name adi, a.SECOND sure, a.DURATION dakika,
             a.person_id,
             DECODE (s.channel_cd,
                     'cDKBVIEW', 'View',
                     'cDKBRIB', 'Retail',
                     'cDKBCIB', 'Corporate',
                     'cCORPADM', 'Administrator',
                     s.channel_cd
                     ) kanal,
             ROWNUM
             FROM cbs_vw_rap_customer_activity a,
             tbl_identification b,
             tbl_session s
             WHERE a.person_id = b.person_id
             AND s.session_id = a.session_id
             ORDER BY a.session_id DESC)
        WHERE ROWNUM < 50;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addcustomlog ('baglantirpr', SQLERRM);
        RETURN '999';
END;

FUNCTION bankaistatistikleri(ps_option IN  VARCHAR2,
                             ilk_tarih IN  VARCHAR,
                             son_tarih IN  VARCHAR,
                             pc_ref    OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode   VARCHAR2 (3) := '000';
    ld_startdate  DATE;
    ld_enddate      DATE;
    not_valid_date EXCEPTION;
    PRAGMA EXCEPTION_INIT(not_valid_date,-01839);
BEGIN
    ld_startdate := TO_DATE(ilk_tarih,'YYYYMMDD');
    ld_enddate := TO_DATE(son_tarih,'YYYYMMDD');

    OPEN pc_ref FOR
        --En az bir kez login olmus toplam bireysel musteri say?s?
        select TO_CHAR(count(*)),'-'
        from tbl_person p,tbl_identification t
        where p.PERSON_ID = t.PERSON_ID
        and t.CHANNEL_CD = 'cDKBRIB'
        and p.PERSON_ID in (select distinct a.person_id from corpint.tbl_session a)
    UNION ALL
        --Son 1 y?l icerisinde en az bir kez login olmus toplam bireysel musteri say?s?
        select TO_CHAR(count(*)),'-'
        from tbl_person p,tbl_identification t
        where p.PERSON_ID = t.PERSON_ID
        and t.CHANNEL_CD = 'cDKBRIB'
        and p.PERSON_ID in (select distinct a.person_id from corpint.tbl_session a where trunc(a.DLM) >= ld_startdate - 365 and trunc(a.DLM) <= ld_enddate)
    UNION ALL
        --Son uc ay icinde en az bir kez islem yapm?s veya login olmus toplam bireysel musteri say?s?
        select TO_CHAR(count(*)),'-'
        from tbl_person p,tbl_identification t
        where p.PERSON_ID = t.PERSON_ID
        and t.CHANNEL_CD = 'cDKBRIB'
        and p.PERSON_ID in (select distinct a.person_id from corpint.tbl_session a where trunc(a.DLM) >= ld_startdate and trunc(a.DLM) <= ld_enddate)
    UNION ALL
        --En az bir kez login olmus toplam kurumsal/tuzel musteri say?s?
        select TO_CHAR(count(*)),'-'
        from tbl_person p,tbl_identification t
        where p.PERSON_ID = t.PERSON_ID
        and t.CHANNEL_CD = 'cDKBCIB'
        and p.PERSON_ID in (select distinct a.person_id from corpint.tbl_session a)
    UNION ALL
        --Son 1 y?l icerisinde en az bir kez login olmus toplam kurumsal/tuzel musteri say?s?
        select TO_CHAR(count(*)),'-'
        from tbl_person p,tbl_identification t
        where p.PERSON_ID = t.PERSON_ID
        and t.CHANNEL_CD = 'cDKBCIB'
        and p.PERSON_ID in (select distinct a.person_id from corpint.tbl_session a where trunc(a.DLM) >= ld_startdate - 365 and trunc(a.DLM) <= ld_enddate)
    UNION ALL
        --Son uc ay icinde en az bir kez islem yapm?s veya login olmus toplam tuzel/ kurumsal musteri say?s?
        select TO_CHAR(count(*)),'-'
        from tbl_person p,tbl_identification t
        where p.PERSON_ID = t.PERSON_ID
        and t.CHANNEL_CD = 'cDKBCIB'
        and p.PERSON_ID in (select distinct a.person_id from corpint.tbl_session a where trunc(a.DLM) >= ld_startdate and trunc(a.DLM) <= ld_enddate)
    UNION ALL
        --EFT
        SELECT TO_CHAR (COUNT (*)),  NVL(TO_CHAR (SUM (tutar )),0)
        FROM cbs_islem
        WHERE islem_kod IN (3001, 3005, 3013)
        AND kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(NUMARA)= 1
    UNION ALL
        --Kendi Hesaplar? Aras?nda Havale  KGS
        SELECT TO_CHAR (COUNT (*)),
               NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (ci.doviz_kod, pkg_genel.lc_al, NULL, NVL (ci.tutar, 0), 1, NULL, NULL, 'N', 'A' ) ) ), 0)
        FROM cbs_islem ci, CBS_VIRMAN_ISLEM cvi
        WHERE ci.islem_kod = 1203
        AND ci.kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (ci.kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (ci.kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(ci.NUMARA)= 1
        AND ci.doviz_kod = 'KGS'
        AND ci.NUMARA= cvi.TX_NO
        AND PKG_HESAP.HESAPTANMUSTERINOAL(cvi.BORC_HESAP_NO)= PKG_HESAP.HESAPTANMUSTERINOAL(cvi.ALACAK_HESAP_NO)
    UNION ALL
        --Kendi hesaplari arasinda havale YP
        SELECT TO_CHAR (COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (ci.doviz_kod, pkg_genel.lc_al, NULL, NVL (ci.tutar, 0), 1, NULL, NULL, 'N', 'A') ) ), 0)
        FROM cbs_islem ci, CBS_VIRMAN_ISLEM cvi
        WHERE ci.islem_kod = 1203
        AND ci.kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (ci.kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (ci.kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(ci.NUMARA)= 1
        AND ci.doviz_kod <> 'KGS'
        AND ci.NUMARA= cvi.TX_NO
        AND PKG_HESAP.HESAPTANMUSTERINOAL(cvi.BORC_HESAP_NO)= PKG_HESAP.HESAPTANMUSTERINOAL(cvi.ALACAK_HESAP_NO)
    UNION ALL
        --Baska Hesaba Havale TL
        SELECT TO_CHAR (COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (ci.doviz_kod, pkg_genel.lc_al, NULL, NVL (ci.tutar, 0), 1, NULL, NULL, 'N', 'A') ) ), 0)
        FROM cbs_islem ci, CBS_VIRMAN_ISLEM cvi
        WHERE ci.islem_kod = 1203
        AND ci.kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (ci.kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (ci.kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(ci.NUMARA)= 1
        AND ci.doviz_kod = 'KGS'
        AND ci.NUMARA= cvi.TX_NO
        AND PKG_HESAP.HESAPTANMUSTERINOAL(cvi.BORC_HESAP_NO)<> PKG_HESAP.HESAPTANMUSTERINOAL(cvi.ALACAK_HESAP_NO)
    UNION ALL
        --- Baska Hesaba Havale YP
        SELECT TO_CHAR (COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (ci.doviz_kod, pkg_genel.lc_al, NULL, NVL (ci.tutar, 0), 1, NULL, NULL, 'N', 'A') ) ), 0)
        FROM cbs_islem ci, CBS_VIRMAN_ISLEM cvi
        WHERE ci.islem_kod = 1203
        AND ci.kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (ci.kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (ci.kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(ci.NUMARA)= 1
        AND ci.doviz_kod <> 'KGS'
        AND ci.NUMARA= cvi.TX_NO
        AND PKG_HESAP.HESAPTANMUSTERINOAL(cvi.BORC_HESAP_NO)<> PKG_HESAP.HESAPTANMUSTERINOAL(cvi.ALACAK_HESAP_NO)
    UNION ALL
        --Doviz Transferleri
        SELECT TO_CHAR (COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (doviz_kod, pkg_genel.lc_al, NULL, NVL (tutar, 0), 1, NULL, NULL, 'N', 'A') ) ), 0)
        FROM cbs_islem
        WHERE islem_kod = 4003
        AND kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(NUMARA)= 1
    UNION ALL
        --Fatura Odemeleri
        SELECT TO_CHAR (COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (doviz_kod, pkg_genel.lc_al, NULL, NVL (tutar, 0), 1, NULL, NULL, 'N', 'A' ) ) ), 0)
        FROM cbs_islem
        WHERE islem_kod = 6330
        AND kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(NUMARA)= 1
    UNION ALL
        --Doviz Al?s
        SELECT TO_CHAR (COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (doviz_kod, pkg_genel.lc_al, NULL, NVL (tutar, 0), 1, NULL, NULL, 'N', 'A') ) ),0)
        FROM cbs_islem
        WHERE islem_kod = 4025
        AND kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(NUMARA)= 1
    UNION ALL
        --Doviz Sat?s
        SELECT TO_CHAR (COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (doviz_kod, pkg_genel.lc_al, NULL, NVL (tutar, 0), 1, NULL, NULL, 'N', 'A' ) ) ),0)
        FROM cbs_islem
        WHERE islem_kod = 1202
        AND kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(NUMARA)= 1
    UNION ALL
        --Arbitraj islemleri
        SELECT TO_CHAR(COUNT (*)),
        NVL(TO_CHAR (SUM (pkg_kur.doviz_doviz_karsilik (doviz_kod, pkg_genel.lc_al, NULL, NVL (tutar, 0), 1, NULL, NULL, 'N', 'A') ) ),0)
        FROM cbs_islem
        where ISLEM_KOD = 1204
        AND kayit_kullanici_kodu = 'CINT_CALLER'
        AND TRUNC (kayit_sistem_tarihi) >= ld_startdate
        AND TRUNC (kayit_sistem_tarihi) <= ld_enddate
        AND pkg_tx.Islem_bitmis_mi(NUMARA)= 1
    UNION ALL
        --Finansal olmayan diger islemler say?s?
        select TO_CHAR(count(*)),'-' from (
        SELECT  distinct a.session_id,a.tran_cd
        FROM CORPINT.TBL_ACTIVITY A
        WHERE CHANNEL_CD IN ('cDKBRIB', 'cDKBCIB' )
        AND ACTV_TIME BETWEEN ld_startdate AND ld_enddate
        AND A.TRAN_CD NOT IN  ('FONSATIS','SWIFT','EFT','EXCHNGBUY','FONALIS','FONALIS','B2BHVL',
                               'TOTALHVL','EFTCNCL','FONSATIPT','ARBITRAJ','EXCHNGSELL','LEFTMENU',
                               'WELCOME','FAVORI','PAYMORD','B2OBHVL','CLOGON','LOGON','PLOGON','PSMSLOGON',
                               'TLOGON','OTMFONTAL'));

RETURN ls_returncode;
EXCEPTION
    WHEN not_valid_date THEN
        ls_returncode := '414';
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
        RETURN ls_returncode;
END;

FUNCTION GetDetailedUserInfoList(ps_option          IN VARCHAR2,
                                 ps_start_date      IN VARCHAR2,
                                 ps_end_date        IN VARCHAR2,
                                 ps_status_cd       IN VARCHAR2,
                                 ps_channel_cd      IN VARCHAR2,
                                 ps_customer_type   IN VARCHAR2,
                                 pc_ref             OUT cursorreferencetype) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3) := '000';

BEGIN

  OPEN pc_ref FOR
    SELECT dd.BOLUM_KODU as "Branch Code", DD.MUSTERI_NO as "Customer Number", bb.PERSON_ID as "Personal Number", trim(DD.ISIM || ' ' || DD.IKINCI_ISIM || ' ' || DD.SOYADI || ' ' || DD.TICARI_UNVAN) as "Customer Name",
           bb.STATUS_CD as "Customer Status", bb.CHANNEL_CD as "Channel Code", DD.REPORT_CUSTOMER_TYPE as "Report Customer Type",
           (select to_char(max(aa.actv_time),'YYYY.MM.DD') from corpint.tbl_activity aa where aa.person_id = CC.PERSON_ID and aa.tran_cd='WELCOME') as "Last Time of Customer Activity"
    FROM corpint.tbl_identification bb, corpint.tbl_person cc,cbs_musteri dd
    WHERE bb.person_id=cc.person_id and CC.CUSTOMER_ID=DD.MUSTERI_NO 
    AND cc.DLM between to_date(ps_start_date || ' 000000','YYYYMMDD hh24miss') and to_date(ps_end_date || ' 235959','YYYYMMDD hh24miss')
    AND bb.status_cd = NVL(ps_status_cd, bb.status_cd)
    AND bb.channel_cd = NVL(ps_channel_cd, bb.channel_cd)
    AND dd.report_customer_type = NVL(ps_customer_type, dd.report_customer_type)
    ORDER BY cc.DLM DESC;

  RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addcustomlog ('GetDetailedUserInfoList', SQLERRM);
        RETURN '999';
END;

/*******************************************************************************
    Name:   GetSpecialCustomerDetails
    Prepared By:    Chyngyz Omurov
    Date:   17.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:   for keeping special customer details in Corp IB, specifically it keeps if customer is in special group
    who can send swift in special time interval
*******************************************************************************/

FUNCTION GetSpecialCustomerDetails(ps_customerno IN VARCHAR2,
                                                                   ps_pendingTx IN VARCHAR2 DEFAULT '0', --ChyngyzO cq4960 Salary Payments 28.12.2015, set to 1 to get pending approval values
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
         ls_returncode  VARCHAR2(3):='000';
         ls_group VARCHAR2(1);
         
         lc_result CursorReferenceType; --ChyngyzO cq4960 Salary Payments 28.12.2015
         ls_salaryCurrency VARCHAR2(3);--ChyngyzO cq4960 Salary Payments 28.12.2015
         ls_salaryCommType VARCHAR2(100);--ChyngyzO cq4960 Salary Payments 28.12.2015
BEGIN

 --BOM ChyngyzO cq4960 Salary Payments 28.12.2015
 
     IF ps_pendingTx = '0' THEN     
         BEGIN --approved swift special time settings
            SELECT SPECIAL_TIME INTO ls_group FROM TBL_SWIFT_SPECIAL_CUSTOMER
            WHERE customer_id=TO_NUMBER(ps_customerno) ;
        EXCEPTION WHEN OTHERS THEN ls_group:='N';
        END;
     ELSE
        BEGIN --not approved swift special time settings
            SELECT SETTINGS_VALUE  INTO ls_group  FROM CORPINT.TBL_CUSTOMER_SETTINGS
            WHERE CUSTOMER_NO=ps_customerno AND SETTINGS_CD='swift.time.tx' ;
        EXCEPTION WHEN OTHERS THEN ls_group:='N';
        END;
     END IF;
   
     BEGIN
            SELECT SETTINGS_VALUE  INTO ls_salaryCurrency  FROM CORPINT.TBL_CUSTOMER_SETTINGS
            WHERE CUSTOMER_NO=ps_customerno AND SETTINGS_CD=DECODE(ps_pendingTx, '0', 'salary.currency', 'salary.currency.tx') ; --salary currency (approved/not approved )             
     EXCEPTION WHEN OTHERS THEN ls_salaryCurrency:=NULL;
END;  
         
    BEGIN
        SELECT SETTINGS_VALUE  INTO ls_salaryCommType  FROM CORPINT.TBL_CUSTOMER_SETTINGS
        WHERE CUSTOMER_NO=ps_customerno AND SETTINGS_CD=DECODE(ps_pendingTx, '0', 'salary.comm.type', 'salary.comm.type.tx') ; --salary commission type (approved/not approved)            
    EXCEPTION WHEN OTHERS THEN ls_salaryCommType:=NULL;
    END;
   --EOM ChyngyzO cq4960 Salary Payments 28.12.2015
    
    OPEN pc_ref FOR
        SELECT ls_group, ls_salaryCurrency, ls_salaryCommType FROM DUAL;
        
    RETURN '000';

   EXCEPTION
        WHEN OTHERS THEN
               OPEN pc_ref FOR
                SELECT 'N', NULL, NULL FROM DUAL;
               RETURN '000';
END;  
         
END;
/

