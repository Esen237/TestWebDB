create PACKAGE PKG_ATM_LOG IS

/******************************************************************************
   Name       : PKG_ATM_LOG
   Created By : Seval Balci
   Date          : 30.12.06
   Purpose      : ATM &POS Log genel fonk & procedurleri
******************************************************************************/
Procedure LogTransaction(pn_LOG_NO    in number,
                           p_MESSAGE_TYPE VARCHAR2,
                         p_REFERANCE VARCHAR2,
                         p_MESSAGE VARCHAR2,
                         p_IN_TRANSACTION_NAME VARCHAR2 default null ,
                         p_IN_TRANSACTION_CODE VARCHAR2 default null ,
                         p_IN_AUTHORIZATION_REVERSAL VARCHAR2 default null ,
                         p_IN_USER_ID_CODE VARCHAR2 default null ,
                         p_IN_TRANSACTION_TYPE VARCHAR2 default null ,
                         p_IN_SOURCE_CODE VARCHAR2 default null ,
                         p_IN_TERMINAL_TYPE VARCHAR2 default null ,
                         p_IN_BRANCH VARCHAR2 default null ,
                         p_IN_TERMINAL_ID VARCHAR2 default null ,
                         p_IN_BS_TRANSACTION_DATE VARCHAR2 default null ,
                         p_IN_BS_TRANSACTION_TIME VARCHAR2 default null ,
                         p_OUT_RESPONSE_CODE VARCHAR2 default null ,
                         p_OUT_RESPONSE_EXPLANATION VARCHAR2 default null ,
                         p_ACCOUNT_NO VARCHAR2 default null ,
                         p_CBS_TRANSACTION_NO NUMBER default null ,
                         p_ERROR_CD NUMBER default null ,
                         p_ERROR_DESC VARCHAR2 default null ,
                         p_CBS_ERROR_DESC VARCHAR2 default null ,
                         p_AMOUNT NUMBER default null ,
                         p_CURRENCY VARCHAR2 default null ,
                         p_FIELD1 VARCHAR2 default null ,
                         p_FIELD2 VARCHAR2 default null ,
                         p_FIELD3 VARCHAR2 default null ,
                         p_FIELD4 VARCHAR2 default null ,
                         p_FIELD5 VARCHAR2 default null ,
                         p_FIELD6 VARCHAR2 default null ,
                         p_FIELD7 VARCHAR2 default null ,
                         p_FIELD8 VARCHAR2 default null ,
                         p_FIELD9 VARCHAR2 default null ,
                         p_FIELD10 VARCHAR2 default null ,
                         p_FIELD11 VARCHAR2 default null ,
                         p_FIELD12 VARCHAR2 default null ,
                         p_FIELD13 VARCHAR2 default null ,
                         p_FIELD14 VARCHAR2 default null ,
                         p_FIELD15 VARCHAR2 default null
                            );
END;
/

