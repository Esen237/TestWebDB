create PACKAGE           PKG_ATM IS

kanal_numara NUMBER :=8;
kanal_user      VARCHAR2(20):= 'ATM';
kanal_rol      NUMBER          := 888;
G_DECLINE_RESPONSE_EXPLANATION VARCHAR2(37):= 'TRANSACTION DECLINED';

Procedure GetTranCode(ps_gelen_message varchar2,ps_transaction_code out varchar2);
Procedure Parse_Incoming_Message(ps_gelen_message        varchar2,
                                  ps_ayrilan_message  out varchar2,
                                 ps_transaction_name out varchar2,
                                 ps_transaction_code out varchar2,
                                 ps_Orig_authorization_reversal out varchar2,
                                 ps_user                 out varchar2,
                                 ps_transaction_type  out varchar2,
                                 ps_source_code        out    varchar2,
                                 ps_terminal_type        out varchar2,
                                 ps_branch            out    varchar2,
                                 ps_terminal_id        out varchar2,
                                 ps_transaction_date   out varchar2,
                                 ps_transaction_time  out varchar2,
                                 ps_reference_number    out varchar2);

Function StandardResponseHeader(ps_referans_number varchar2,
                                   ps_authorization_decline_flag varchar2 default 0,
                                 ps_detail_response_code    varchar2 default '000',
                                  ps_resp_explanation varchar2) return VARCHAR2; -- decline response code explanation
FUNCTION  satir_ayir( ps_mesaj IN OUT VARCHAR2 ,pn_uzunluk number ) RETURN VARCHAR2 ;
FUNCTION Terminal_Active(ps_terminal_id varchar2) RETURN varchar2;
Function Time_Out(pd_start_date date, pd_end_date date) RETURN varchar2;
Function Need_Reversal(ps_trancode varchar2) RETURN varchar2;
FUNCTION  bakiye_formatla( pn_bakiye number ) RETURN VARCHAR2 ;
FUNCTION bsof_bakiye_to_number(ps_bakiye varchar2) RETURN number;
Procedure CURRENCY_CONVERT(ps_bsof_dvz in out varchar2,ps_our_dvz in out varchar2) ;
FUNCTION is_reversal_received(ps_reference VARCHAR2) RETURN varchar2;

END;
/

