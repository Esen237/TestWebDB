create trigger TRG_PARAMETRE_BEF_INS
    before insert
    on CBS_PARAMETRE
    for each row
declare
    p_seq_num number;
  begin
    :new.versiyon:=1;
    :new.yaratildigi_tarih := sysdate;
    :new.yaratan_kullanici_kodu := user;
    --if :new.numara is null or :new.numara = '' then
      select sq_parametre.nextval into p_seq_num from dual;
      :new.numara:=p_seq_num;
    --end if;
  end;

/

