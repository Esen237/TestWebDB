create package drv0ddl authid current_user is

   PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

   function generate_substrings(c sys_refcursor)
   return dr$substring_set
   pipelined;

   function generate_substrings2(c sys_refcursor)
   return dr$substring_set2
   pipelined;

end drv0ddl;
/

