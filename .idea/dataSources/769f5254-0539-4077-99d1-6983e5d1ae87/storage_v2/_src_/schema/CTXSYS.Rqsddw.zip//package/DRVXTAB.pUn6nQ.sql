create package drvxtab authid current_user as

  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  DEFAULT_SEPARATOR       constant varchar2(1) := '$';
  TMP1_SEPARATOR          constant varchar2(1) := 'M';
  TMP2_SEPARATOR          constant varchar2(1) := 'N';

  -- Constants for $S* table names
  TAB_SN                  constant number := 1;
  TAB_SV                  constant number := 2;
  TAB_SD                  constant number := 4;
  TAB_SR                  constant number := 8;
  TAB_SBF                 constant number := 16;
  TAB_SBD                 constant number := 32;
  TAB_ST                  constant number := 64;
  TAB_STZ                 constant number := 128;
  TAB_SIYM                constant number := 256;
  TAB_SIDS                constant number := 512;

  -- please change this number if you add/remove table names above
  NUM_SX_TABS             constant number := 10;

PROCEDURE part_events_off;
PROCEDURE part_events_on;

/* ====================================================================== */
/* ====================================================================== */
/*                             CONTEXT                                    */
/* ====================================================================== */
/* ====================================================================== */

/*------------------------- create_a_table --------------------------------*/
PROCEDURE create_a_table(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idx       in dr_def.idx_rec
);

/*------------------------- create_f_table --------------------------------*/
PROCEDURE create_f_table(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idx       in dr_def.idx_rec
);

/*---------------------------- create_s_tables -----------------------------*/
/* create $S & $S* tables by calling create_s_sort_table() and
 * create_s_search_table() */
PROCEDURE create_s_tables(
  idx       in dr_def.idx_rec,
  part_id   in number default null,
  sep       in varchar2,
  part      in boolean default FALSE,
  shadow    in boolean default FALSE,
  opt_for   in number  default DRISGP.SDATA_OPT_FOR_SORT_AND_SEARCH,
  p_new_tab_type in number default null,
  p_simplesyntax in boolean default FALSE,
  sysPart  in boolean default FALSE,
  sharded  in boolean default FALSE
);

/*------------------------- create_s_sort_table ----------------------------*/
/* create $S table */
PROCEDURE create_s_sort_table(
  idx       in dr_def.idx_rec,
  part_id   in number default null,
  sep       in varchar2,
  part      in boolean default FALSE,
  shadow    in boolean default FALSE,
  sysPart  in boolean default FALSE,
  sharded  in boolean default FALSE
);

/*---------------------- create_s_search_tables --------------------------*/
/* create $S* tables */
PROCEDURE create_s_search_tables(
  p_idx          in dr_def.idx_rec,
  p_part_id      in number default null,
  p_sep          in varchar2,
  p_part         in boolean default FALSE,
  p_shadow       in boolean default FALSE,
  p_new_tab_type in number default null,
  p_simplesyntax in boolean default FALSE,
  sysPart  in boolean default FALSE,
  sharded  in boolean default FALSE
);

/*---------------------- part_create_s_tables -----------------------------*/
PROCEDURE part_create_s_tables(
  idx            in dr_def.idx_rec,
  opt_for        in number default DRISGP.SDATA_OPT_FOR_SORT_AND_SEARCH,
  p_new_tab_type in number default null,
  p_simplesyntax in boolean default FALSE
);

/*---------------------------- create_s_index -----------------------------*/
PROCEDURE create_s_index(
  idx       in dr_def.idx_rec,
  part_id   in number default null,
  part      in boolean default FALSE,
  shadow    in boolean default FALSE,
  para      in number  default 1,
  sep         in varchar2 default DEFAULT_SEPARATOR,
  sysPart  in boolean default FALSE
);

/*----------------------- create_index_tables -----------------------------*/

PROCEDURE create_index_tables(
  idx       in dr_def.idx_rec,
  part_id   in number default null,
  temp      in boolean default FALSE,
  part      in boolean default FALSE,
  shadow    in boolean default FALSE,
  sys_part  in boolean default FALSE
);

/*--------------------------- create_g_table ---------------------------*/
procedure create_g_table(
  idx dr_def.idx_rec,
  part_id in number  default 0
);

/*--------------------------- drop_g_table --------------------------------*/
procedure drop_g_table(
  idx dr_def.idx_rec,
  part_id in number  default 0
);

/*--------------------------- add_offsets_column --------------------------*/
procedure add_offsets_column(
  idx dr_def.idx_rec
);

-- 8323978: Removed create_index_triggers

/*----------------------- create_index_indexes  ---------------------------*/

PROCEDURE create_index_indexes(
  idx       in dr_def.idx_rec,
  part_id   in number default null,
  temp      in boolean default FALSE,
  part      in boolean default FALSE,
  pardeg    in number default 1,
  sysPart   in boolean default FALSE
);

/*----------------------- drop_index_tables  ---------------------------*/

PROCEDURE drop_index_tables(
  idx       in dr_def.idx_rec,
  has_p     in boolean default null,
  part_id   in number default null,
  temp      in boolean default FALSE,
  isAlter   in boolean default FALSE,
  isDelete  in boolean default FALSE,
  partName  in varchar2 default null
);

/*----------------------- drop_FA_tables  -------------------------------*/

PROCEDURE drop_FA_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- drop_s_search_tables  ----------------------------*/

PROCEDURE drop_s_search_tables(
  p_idx         in dr_def.idx_rec,
  p_part_id     in number default null,
  p_shadow      in boolean default FALSE
);

/*----------------------- trunc_index_tables  ---------------------------*/

PROCEDURE trunc_index_tables(
  idx       in dr_def.idx_rec,
  part_id   in number default null
);

/*----------------------- rename_index_tables  ---------------------------*/

PROCEDURE rename_index_tables(
  idx       in dr_def.idx_rec,
  new_name  in varchar2,
  has_idx   in boolean,
  full_length_objects in boolean,
  thirty_character_names in boolean,
  part_id   in number default null
);

/*----------------------- exchange_index_tables  --------------------------*/

PROCEDURE exchange_index_tables(
  idxp       in dr_def.idx_rec,
  idxp_pid   in number,
  idxn       in dr_def.idx_rec,
  idxn_pid   in number default null,
  is_compart in boolean default FALSE,
  is_movechunk in boolean default FALSE,
  src_idxname  in varchar2 default NULL,
  src_ixpname in varchar2 default NULL
);

/*-------------------------- get_create_sql -------------------------------*/

FUNCTION get_create_sql(
  idx_owner      in varchar2,
  idx_name       in varchar2,
  idx            in dr_def.idx_rec,
  part_id        in number default null,
  which          in varchar2,
  sto            in out nocopy dr_def.vc500_tab,
  sep            in varchar2 default DEFAULT_SEPARATOR,
  x_part         in boolean default FALSE,
  char_semantics in varchar2 default 'BYTE',
  sys_part       in boolean default FALSE,
  base_table     in varchar2 default null,
  sharded        in boolean default FALSE,
  sharing        in varchar2 default null
) RETURN CLOB;

/*------------------------ get_constraint_name ------------------------------*/

FUNCTION get_constraint_name(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null,
  which     in varchar2,
  sep       in varchar2 default DEFAULT_SEPARATOR,
  full_length_objs in boolean default null,
  thirty_char_names in boolean default null
) RETURN VARCHAR2;

/*-------------------------- get_object_name ------------------------------*/

FUNCTION get_object_name(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  part_id   in number default null,
  which     in varchar2,
  sep       in varchar2 default DEFAULT_SEPARATOR,
  full_length_objs in boolean default null
) RETURN VARCHAR2;

/*-------------------------- get_object_prefix ------------------------------*/

FUNCTION get_object_prefix(
  idx_owner in varchar2,
  idx_name  in varchar2,
  part_id   in number default null,
  sep       in varchar2 default DEFAULT_SEPARATOR,
  full_length_objs in boolean default null
) RETURN VARCHAR2;

/*---------------------- swap_index_temp_tables -----------------------*/
PROCEDURE swap_index_temp_tables (
  idx_owner  in varchar2,
  idx_name   in varchar2,
  idxid      in number,
  idx_pid    in number,
  temp_owner in varchar2,
  temp_name  in varchar2,
  shadow_idxid in number default NULL,
  shadow_ixpid in number default NULL
);

/*----------------------- populate_ptable -----------------------------------*/

PROCEDURE populate_ptable(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idx       in dr_def.idx_rec,
  part_id   in number default NULL,
  shadow    in boolean default FALSE,
  ctxcat    in boolean default FALSE
);

/*----------------------- AlterDollarITType --------------------------------*/

PROCEDURE AlterDollarITType(
  idx in dr_def.idx_rec
);

PROCEDURE AdjustTType(
  idx    in dr_def.idx_rec,
  shad_i in varchar2
);

PROCEDURE AdjustShadowColumnWidth(
  idx    in dr_def.idx_rec,
  shad_i in varchar2
);

function GetTokenTypeWidth
(
  p_table_name  varchar2,
  p_table_owner varchar2
) RETURN INT;

PROCEDURE create_dataguide_table(idx in dr_def.idx_rec);
PROCEDURE drop_dataguide_table(idx in dr_def.idx_rec);

/*----------------------- rename_index_table_partitions  --------------------*/
PROCEDURE rename_idx_table_partitions(
  idx       in dr_def.idx_rec,
  part_id   in number,
  old_name  in varchar2,
  new_name  in varchar2,
  full_length_objects in boolean,
  thirty_character_names in boolean
);

/* --------------------------------- add_r --------------------------------- */

PROCEDURE add_r(
  idx         in out nocopy dr_def.idx_rec,
  ixp         in out nocopy dr_def.ixp_tab
);

/* -------------------------------- remove_r ------------------------------- */

PROCEDURE remove_r(
  idx         in out nocopy dr_def.idx_rec,
  ixp         in out nocopy dr_def.ixp_tab
);

/* ------------------------------ create_r_con ----------------------------- */

PROCEDURE create_r_con(
  idx_owner  varchar2,
  idx_name   varchar2,
  idx_id     number,
  ixp_id     number
);



end drvxtab;
/

