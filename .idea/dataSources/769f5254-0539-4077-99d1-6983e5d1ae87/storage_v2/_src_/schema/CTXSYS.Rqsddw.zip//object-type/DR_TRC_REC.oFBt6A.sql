create type dr$trc_rec as object (
  trc_id          number,
  trc_value       number
);
/

