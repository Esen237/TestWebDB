create package drirec as

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

/*--------------------------------- recover --------------------------------*/
/*
  NAME
  DESCRIPTION

  ARGUMENTS


  NOTES


  EXCEPTIONS

  RETURNS
    none
*/
PROCEDURE recover(component IN varchar2 default 'ALL');

/*------------------------------ recover_dict ------------------------------*/
/*
  NAME
    recover_dict - RECOVER textile DICTionary
  DESCRIPTION
    Remove policies and indexes that belong to an invalid user (i.e. one
    that has been dropped)

    Also removes indexes, or any other database objects created that are
    connected specifically to the policy

    Remove obsolete entries in dr$contains

    Remove thesaurus and sections groups that belongs to an invalid user

    If user_name is null, entries for all dropped users are removed.
  ARGUMENTS

  RETURNS

  NOTES
*/
PROCEDURE recover_dict(user_name in varchar2 := null);

end drirec;
/

