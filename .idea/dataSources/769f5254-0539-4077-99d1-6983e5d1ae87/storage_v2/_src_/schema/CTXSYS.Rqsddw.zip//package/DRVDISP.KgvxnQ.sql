create package drvdisp authid current_user is

  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  /*
   * NAME
   *   EXECTRUST - synchronous trust callout command
   *
   * RETURN
   *
   */
  procedure EXECTRUST(
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECTRUST_RET - synchronous trust callout command with return
   *
   * RETURN
   *
   */
  procedure EXECTRUST_RET(
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     ret1       out    varchar2,
                     ret2       out    varchar2,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECTRUST_RET1 - synchronous trust callout command with 1 return
   *
   * RETURN
   *
   */
  function EXECTRUST_RET1(
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    )
   return varchar2;

  /*
   * NAME
   *   EXECTRUST_ARRAY - synchronous trust callout command with arrays
   *
   * RETURN
   *
   */
  procedure EXECTRUST_ARRAY(
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     list1      in     sys.odcinumberlist,
                     list2      in     sys.odcinumberlist,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECASOWN - synchronous trust callout command
   *
   * RETURN
   *
   */
  procedure EXECASOWN(
                     idx_ownid  in     number,
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL,
  		     arg11      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECASOWN_CLOB - synchronous trust callout command w/ INOUT clob
   *
   * RETURN
   *
   */
  procedure EXECASOWN_CLOB(
                     idx_ownid  in     number,
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     argclob    in out nocopy clob,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL,
  		     arg11      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECASOWN_IN_CLOB - synchronous trust callout command w/ IN clob
   *
   * RETURN
   *
   */
  procedure EXECASOWN_IN_CLOB(
                     idx_ownid  in     number,
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     argclob    in     clob,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECASOWN_IN_OUT_CLOBS -
   *     synchronous trust callout command w/
   *       one IN clob and one IN OUT clob.
   *
   * RETURN
   *
   */
  procedure EXECASOWN_IN_OUT_CLOBS(
                     idx_ownid  in     number,
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     argclob1   in     clob,
                     argclob2   in out nocopy clob,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL,
  		     arg11      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECASOWN_IN_CLOB_RET - synchronous trust callout command with return
   *
   * RETURN
   *
   */
  procedure EXECASOWN_IN_CLOB_RET(
                     idx_ownid  in     number,
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     ret1       out    varchar2,
                     ret2       out    varchar2,
                     argclob    in     clob,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECASOWN_RET - synchronous trust callout command with return
   *
   * RETURN
   *
   */
  procedure EXECASOWN_RET(
                     idx_ownid  in     number,
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
                     ret1       out    varchar2,
                     ret2       out    varchar2,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    );

  /*
   * NAME
   *   EXECASOWN_RET1 - synchronous trust callout command with 1 return
   *
   * RETURN
   *
   */
  function EXECASOWN_RET1(
                     idx_ownid  in     number,
                     idx_owner  in     varchar2,
                     idx_name   in     varchar2,
                     part_name  in     varchar2,
                     func_code  in     number,
  		     arg1       in     varchar2 default NULL,
  		     arg2       in     varchar2 default NULL,
  		     arg3       in     varchar2 default NULL,
  		     arg4       in     varchar2 default NULL,
  		     arg5       in     varchar2 default NULL,
  		     arg6       in     varchar2 default NULL,
  		     arg7       in     varchar2 default NULL,
  		     arg8       in     varchar2 default NULL,
  		     arg9       in     varchar2 default NULL,
  		     arg10      in     varchar2 default NULL
                    )
   return varchar2;

/*-------------------------------EXECASOWN_CLOB_RET------------------*/

function EXECASOWN_CLOB_RET(
  idx_ownid  in     number,
  idx_owner  in     varchar2,
  idx_name   in     varchar2,
  part_name  in     varchar2,
  func_code  in     number,
  arglob     in out nocopy clob,
  arg1       in     varchar2 default NULL,
  arg2       in     varchar2 default NULL,
  arg3       in     varchar2 default NULL,
  arg4       in     varchar2 default NULL,
  arg5       in     varchar2 default NULL,
  arg6       in     varchar2 default NULL,
  arg7       in     varchar2 default NULL,
  arg8       in     varchar2 default NULL,
  arg9       in     varchar2 default NULL,
  arg10      in     varchar2 default NULL
) return varchar2;

/*--------------------------- tablefunc ----------------------------*/

FUNCTION tablefunc
(
  idxo      in  varchar2,
  idxn      in  varchar2,
  idxp      in  varchar2,
  cur       in  SYS_REFCURSOR,
  opcode    in  varchar2,
  memory    in  varchar2,
  tstamp    in  varchar2,
  direct_path in varchar2,
  maxtime     in varchar2
) return number;

/*--------------------------- tablefunc_asown ----------------------------*/

FUNCTION tablefunc_asown
(
  idxownid  in  number,
  idxo      in  varchar2,
  idxn      in  varchar2,
  idxp      in  varchar2,
  cur       in  SYS_REFCURSOR,
  opcode    in  varchar2,
  memory    in  varchar2,
  tstamp    in  varchar2,
  direct_path in varchar2,
  maxtime     in varchar2
) return number;

end drvdisp;
/

